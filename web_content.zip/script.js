"use strict";

/* =========================================================
   MATH QUEST
   SISTEMA PRINCIPAL
========================================================= */


/* =========================================================
   UTILIDADES
========================================================= */

const $ = id => document.getElementById(id);

const random = (min, max) =>
    Math.floor(Math.random() * (max - min + 1)) + min;

const shuffle = array =>
    [...array].sort(() => Math.random() - 0.5);

const gcd = (a, b) => {

    a = Math.abs(a);
    b = Math.abs(b);

    while (b !== 0) {

        const temp = b;

        b = a % b;

        a = temp;
    }

    return a;
};

const lcm = (a, b) =>
    Math.abs(a * b) / gcd(a, b);


/* =========================================================
   DADOS DO JOGADOR
========================================================= */

let player = JSON.parse(
    localStorage.getItem("mathQuestPlayer")
) || {

    xp: 0,

    streak: 0,

    bestStreak: 0,

    games: 0,

    correct: 0,

    wrong: 0,

    totalQuestions: 0,

    categoryStats: {},

    achievements: []

};


/* =========================================================
   SALVAR
========================================================= */

function savePlayer() {

    localStorage.setItem(
        "mathQuestPlayer",
        JSON.stringify(player)
    );

}


/* =========================================================
   CATEGORIAS
========================================================= */

const categories = [

    {
        id: "basic",
        name: "Operações",
        icon: "➕",
        className: "cat-basic",
        description: "Adição, subtração, multiplicação e divisão."
    },

    {
        id: "fraction",
        name: "Frações",
        icon: "½",
        className: "cat-fraction",
        description: "Operações e problemas com frações."
    },

    {
        id: "percent",
        name: "Porcentagem",
        icon: "%",
        className: "cat-percent",
        description: "Porcentagens, descontos e aumentos."
    },

    {
        id: "geometry",
        name: "Geometria",
        icon: "📐",
        className: "cat-geometry",
        description: "Áreas, perímetros, figuras e ângulos."
    },

    {
        id: "equation",
        name: "Equações",
        icon: "＝",
        className: "cat-equation",
        description: "Equações de primeiro grau."
    },

    {
        id: "bhaskara",
        name: "Bhaskara",
        icon: "Δ",
        className: "cat-bhaskara",
        description: "Equações do segundo grau."
    },

    {
        id: "power",
        name: "Potenciação",
        icon: "x²",
        className: "cat-power",
        description: "Potências e propriedades."
    },

    {
        id: "root",
        name: "Radiciação",
        icon: "√",
        className: "cat-root",
        description: "Raízes quadradas e operações."
    },

    {
        id: "statistics",
        name: "Estatística",
        icon: "📊",
        className: "cat-statistics",
        description: "Média, moda e mediana."
    },

    {
        id: "probability",
        name: "Probabilidade",
        icon: "🎲",
        className: "cat-probability",
        description: "Chances e probabilidades."
    },

    {
        id: "mmc",
        name: "MMC e MDC",
        icon: "🔢",
        className: "cat-mmc",
        description: "Mínimo múltiplo e máximo divisor."
    },

    {
        id: "algebra",
        name: "Álgebra",
        icon: "🔤",
        className: "cat-algebra",
        description: "Expressões algébricas."
    },

    {
        id: "measures",
        name: "Medidas",
        icon: "📏",
        className: "cat-measures",
        description: "Conversões e unidades."
    },

    {
        id: "problems",
        name: "Problemas",
        icon: "🧩",
        className: "cat-problems",
        description: "Problemas matemáticos."
    },

    {
        id: "trigonometry",
        name: "Trigonometria",
        icon: "📐",
        className: "cat-trigonometry",
        description: "Seno, cosseno e tangente."
    },

    {
        id: "mixed",
        name: "Misto",
        icon: "🎲",
        className: "cat-mixed",
        description: "Uma mistura de tudo."
    }

];


/* =========================================================
   NAVEGAÇÃO
========================================================= */

function showScreen(screenName) {

    document.querySelectorAll(".screen")
        .forEach(screen =>
            screen.classList.remove("active")
        );

    const screen = $(`${screenName}Screen`);

    if (screen) {

        screen.classList.add("active");

    }

    document.querySelectorAll(".menu-item")
        .forEach(item => {

            item.classList.toggle(
                "active",
                item.dataset.screen === screenName
            );

        });

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

    updateUI();

}


/* =========================================================
   MENU
========================================================= */

$("menuBtn").onclick = () => {

    $("sideMenu").classList.add("open");

    $("menuOverlay").classList.add("show");

};

$("closeMenu").onclick = closeMenu;

$("menuOverlay").onclick = closeMenu;

function closeMenu() {

    $("sideMenu").classList.remove("open");

    $("menuOverlay").classList.remove("show");

}

document.querySelectorAll("[data-screen]")
    .forEach(button => {

        button.addEventListener("click", () => {

            const screen = button.dataset.screen;

            showScreen(screen);

            closeMenu();

        });

    });


/* =========================================================
   RENDER CATEGORIAS
========================================================= */

function renderCategories() {

    const featured =
        categories.slice(0, 8);

    $("featuredCategories").innerHTML =
        featured.map(categoryCard).join("");

    $("allCategories").innerHTML =
        categories.map(categoryCard).join("");

    document.querySelectorAll(".category-card")
        .forEach(card => {

            card.addEventListener("click", () => {

                startQuiz(card.dataset.category);

            });

        });

}


function categoryCard(category) {

    return `

        <article
            class="category-card ${category.className}"
            data-category="${category.id}"
        >

            <div class="category-icon">
                ${category.icon}
            </div>

            <h3>
                ${category.name}
            </h3>

            <p>
                ${category.description}
            </p>

        </article>

    `;

}


/* =========================================================
   GERADOR DE QUESTÕES
========================================================= */

function generateQuestion(category, difficulty = "normal") {

    if (category === "mixed") {

        const available =
            categories
                .filter(c => c.id !== "mixed")
                .map(c => c.id);

        category =
            available[random(0, available.length - 1)];

    }

    switch (category) {

        case "basic":
            return basicQuestion(difficulty);

        case "fraction":
            return fractionQuestion();

        case "percent":
            return percentQuestion();

        case "geometry":
            return geometryQuestion();

        case "equation":
            return equationQuestion();

        case "bhaskara":
            return bhaskaraQuestion();

        case "power":
            return powerQuestion();

        case "root":
            return rootQuestion();

        case "statistics":
            return statisticsQuestion();

        case "probability":
            return probabilityQuestion();

        case "mmc":
            return mmcQuestion();

        case "algebra":
            return algebraQuestion();

        case "measures":
            return measuresQuestion();

        case "problems":
            return problemQuestion();

        case "trigonometry":
            return trigonometryQuestion();

        default:
            return basicQuestion();

    }

}


/* =========================================================
   OPERAÇÕES
========================================================= */

function basicQuestion(difficulty) {

    const max =
        difficulty === "hard"
            ? 100
            : 30;

    let a = random(1, max);
    let b = random(1, max);

    const operations =
        ["+", "-", "×", "÷"];

    const op =
        operations[random(0, operations.length - 1)];

    let answer;
    let text;

    if (op === "+") {

        answer = a + b;

        text = `${a} + ${b} = ?`;

    }

    else if (op === "-") {

        if (b > a) {

            [a, b] = [b, a];

        }

        answer = a - b;

        text = `${a} − ${b} = ?`;

    }

    else if (op === "×") {

        answer = a * b;

        text = `${a} × ${b} = ?`;

    }

    else {

        answer = random(1, max);

        b = random(1, max);

        a = answer * b;

        text = `${a} ÷ ${b} = ?`;

    }

    return createQuestion(
        "Operações",
        "🧮",
        text,
        answer,
        `Resolva a operação ${a} ${op} ${b}.`
    );

}


/* =========================================================
   FRAÇÕES
========================================================= */

function fractionQuestion() {

    const den = random(2, 9);

    const n1 = random(1, den - 1);

    const n2 = random(1, den - 1);

    const answer =
        n1 + n2;

    return createQuestion(

        "Frações",

        "½",

        `${n1}/${den} + ${n2}/${den} = ?`,

        `${answer}/${den}`,

        `Como os denominadores são iguais,
        somamos os numeradores.`

    );

}


/* =========================================================
   PORCENTAGEM
========================================================= */

function percentQuestion() {

    const values =
        [10,20,25,30,40,50];

    const percent =
        values[random(0, values.length - 1)];

    const value =
        random(2,20) * 10;

    const answer =
        value * percent / 100;

    return createQuestion(

        "Porcentagem",

        "%",

        `Quanto é ${percent}% de ${value}?`,

        answer,

        `${percent}% significa ${percent}/100.
        Multiplique o valor por essa fração.`

    );

}


/* =========================================================
   GEOMETRIA
========================================================= */

function geometryQuestion() {

    const width =
        random(3,15);

    const height =
        random(3,15);

    const answer =
        width * height;

    return createQuestion(

        "Geometria",

        "▭",

        `Qual é a área de um retângulo
         com ${width} cm × ${height} cm?`,

        `${answer} cm²`,

        `Área do retângulo = base × altura.`

    );

}


/* =========================================================
   EQUAÇÃO
========================================================= */

function equationQuestion() {

    const x =
        random(2,15);

    const a =
        random(2,9);

    const b =
        random(1,15);

    const result =
        a * x + b;

    return createQuestion(

        "Equação",

        "＝",

        `Resolva: ${a}x + ${b} = ${result}`,

        x,

        `Passe ${b} para o outro lado e
        depois divida pelo coeficiente de x.`

    );

}


/* =========================================================
   BHASKARA
========================================================= */

function bhaskaraQuestion() {

    let x1 =
        random(-8,8);

    let x2 =
        random(-8,8);

    while (x1 === x2) {

        x2 = random(-8,8);

    }

    const b =
        -(x1 + x2);

    const c =
        x1 * x2;

    const a = 1;

    const delta =
        b*b - 4*a*c;

    return createQuestion(

        "Bhaskara",

        "Δ",

        `Na equação
         x² ${formatSigned(b)}x
         ${formatSigned(c)} = 0,
         qual é o valor de Δ?`,

        delta,

        `Δ = b² − 4ac.
        Aqui a = ${a}, b = ${b} e c = ${c}.`

    );

}


/* =========================================================
   POTENCIAÇÃO
========================================================= */

function powerQuestion() {

    const base =
        random(2,9);

    const exponent =
        random(2,4);

    const answer =
        Math.pow(base, exponent);

    return createQuestion(

        "Potenciação",

        "x²",

        `${base}^${exponent} = ?`,

        answer,

        `A potência representa
        ${base} multiplicado ${exponent} vezes.`

    );

}


/* =========================================================
   RADICIAÇÃO
========================================================= */

function rootQuestion() {

    const n =
        random(2,15);

    const answer =
        n * n;

    return createQuestion(

        "Radiciação",

        "√",

        `√${answer} = ?`,

        n,

        `Procure o número que,
        multiplicado por ele mesmo,
        resulta em ${answer}.`

    );

}


/* =========================================================
   ESTATÍSTICA
========================================================= */

function statisticsQuestion() {

    const a = random(2,10);
    const b = random(2,10);
    const c = random(2,10);

    const answer =
        (a+b+c) / 3;

    return createQuestion(

        "Estatística",

        "📊",

        `Qual é a média de
         ${a}, ${b} e ${c}?`,

        answer,

        `Some todos os valores e
        divida pela quantidade de valores.`

    );

}


/* =========================================================
   PROBABILIDADE
========================================================= */

function probabilityQuestion() {

    const total =
        random(4,10);

    const favorable =
        random(1,total-1);

    const answer =
        `${favorable}/${total}`;

    return createQuestion(

        "Probabilidade",

        "🎲",

        `Uma situação possui
         ${total} resultados possíveis,
         sendo ${favorable} favoráveis.
         Qual é a probabilidade?`,

        answer,

        `Probabilidade =
        casos favoráveis ÷ casos possíveis.`

    );

}


/* =========================================================
   MMC / MDC
========================================================= */

function mmcQuestion() {

    const a = random(2,10);
    const b = random(2,10);

    const answer =
        lcm(a,b);

    return createQuestion(

        "MMC e MDC",

        "🔢",

        `Qual é o MMC de ${a} e ${b}?`,

        answer,

        `O MMC é o menor múltiplo
        positivo comum aos dois números.`

    );

}


/* =========================================================
   ÁLGEBRA
========================================================= */

function algebraQuestion() {

    const x =
        random(2,10);

    const coefficient =
        random(2,8);

    const answer =
        coefficient * x;

    return createQuestion(

        "Álgebra",

        "🔤",

        `Se x = ${x},
         quanto vale ${coefficient}x?`,

        answer,

        `Substitua x pelo valor informado:
        ${coefficient} × ${x}.`

    );

}


/* =========================================================
   MEDIDAS
========================================================= */

function measuresQuestion() {

    const meters =
        random(2,20);

    const answer =
        meters * 100;

    return createQuestion(

        "Medidas",

        "📏",

        `Quantos centímetros existem
         em ${meters} metros?`,

        `${answer} cm`,

        `1 metro possui 100 centímetros.`

    );

}


/* =========================================================
   PROBLEMAS
========================================================= */

function problemQuestion() {

    const price =
        random(5,30);

    const quantity =
        random(2,8);

    const answer =
        price * quantity;

    return createQuestion(

        "Problemas",

        "🧩",

        `Uma pessoa compra ${quantity}
         itens de R$ ${price}.
         Quanto ela paga?`,

        `R$ ${answer}`,

        `Multiplique o preço pela quantidade
        de itens.`

    );

}


/* =========================================================
   TRIGONOMETRIA
========================================================= */

function trigonometryQuestion() {

    const values = [

        {
            text: "sen(30°)",
            answer: "1/2"
        },

        {
            text: "cos(60°)",
            answer: "1/2"
        },

        {
            text: "sen(90°)",
            answer: "1"
        },

        {
            text: "cos(0°)",
            answer: "1"
        }

    ];

    const item =
        values[random(0,values.length-1)];

    return createQuestion(

        "Trigonometria",

        "📐",

        `${item.text} = ?`,

        item.answer,

        `Use os valores conhecidos
        do círculo trigonométrico.`

    );

}


/* =========================================================
   CRIAR QUESTÃO
========================================================= */

function createQuestion(
    type,
    visual,
    text,
    answer,
    explanation
) {

    const options =
        generateOptions(answer);

    return {

        type,

        visual,

        text,

        answer: normalize(answer),

        answerDisplay: answer,

        options,

        explanation

    };

}


/* =========================================================
   NORMALIZAÇÃO
========================================================= */

function normalize(value) {

    return String(value)
        .replace(",", ".")
        .trim()
        .toLowerCase();

}


/* =========================================================
   ALTERNATIVAS
========================================================= */

function generateOptions(answer) {

    const result = [];

    const normalized =
        normalize(answer);

    result.push(String(answer));

    let numeric =
        Number(answer);

    let attempts = 0;

    while (
        result.length < 4 &&
        attempts < 100
    ) {

        attempts++;

        let wrong;

        if (!Number.isNaN(numeric)) {

            const variation =
                random(
                    Math.max(1, Math.floor(Math.abs(numeric) * .15)),
                    Math.max(3, Math.floor(Math.abs(numeric) * .4))
                );

            wrong =
                numeric +
                (Math.random() > .5
                    ? variation
                    : -variation);

        }

        else {

            wrong =
                random(1,12);

        }

        wrong = String(wrong);

        if (
            normalize(wrong) !== normalized &&
            !result.includes(wrong)
        ) {

            result.push(wrong);

        }

    }

    return shuffle(result);

}


/* =========================================================
   FORMATAR NÚMEROS
========================================================= */

function formatSigned(number) {

    return number >= 0
        ? `+ ${number}`
        : `− ${Math.abs(number)}`;

}


/* =========================================================
   QUIZ
========================================================= */

let quiz = {

    category: "mixed",

    difficulty: "normal",

    questions: [],

    current: 0,

    correct: 0,

    wrong: 0,

    xp: 0,

    lives: 3,

    answered: false

};


function startQuiz(
    category = "mixed",
    difficulty = "normal"
) {

    quiz = {

        category,

        difficulty,

        questions: Array.from(
            {length: 10},
            () => generateQuestion(category,difficulty)
        ),

        current: 0,

        correct: 0,

        wrong: 0,

        xp: 0,

        lives: 3,

        answered: false

    };

    showScreen("quiz");

    renderQuestion();

}


/* =========================================================
   RENDER QUESTÃO
========================================================= */

function renderQuestion() {

    const question =
        quiz.questions[quiz.current];

    quiz.answered = false;

    $("quizCategory").textContent =
        question.type;

    $("questionType").textContent =
        "QUESTÃO";

    $("questionVisual").textContent =
        question.visual;

    $("questionText").textContent =
        question.text;

    $("answers").innerHTML =
        question.options
            .map(
                option => `
                    <button
                        class="answer-btn"
                        data-answer="${escapeHtml(option)}">
                        ${option}
                    </button>
                `
            )
            .join("");

    $("feedback").className =
        "feedback hidden";

    $("nextQuestion").classList.add(
        "hidden"
    );

    $("livesDisplay").textContent =
        quiz.lives;

    const progress =
        ((quiz.current) /
            quiz.questions.length) * 100;

    $("quizProgressFill")
        .style.width =
        `${progress}%`;

    $("questionCounter").textContent =
        `${quiz.current + 1} / ${quiz.questions.length}`;

    document.querySelectorAll(".answer-btn")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    answerQuestion(
                        button,
                        button.dataset.answer
                    );

                }
            );

        });

}


/* =========================================================
   RESPONDER
========================================================= */

function answerQuestion(
    button,
    selected
) {

    if (quiz.answered)
        return;

    quiz.answered = true;

    const question =
        quiz.questions[quiz.current];

    const isCorrect =
        normalize(selected) ===
        question.answer;

    document.querySelectorAll(".answer-btn")
        .forEach(btn => {

            btn.classList.add("disabled");

            if (
                normalize(btn.dataset.answer) ===
                question.answer
            ) {

                btn.classList.add("correct");

            }

        });

    if (isCorrect) {

        button.classList.add("correct");

        quiz.correct++;

        const earned =
            10 + quiz.current * 2;

        quiz.xp += earned;

        player.xp += earned;

        player.correct++;

        player.streak++;

        player.bestStreak =
            Math.max(
                player.bestStreak,
                player.streak
            );

        showFeedback(
            true,
            "Resposta correta! 🎉",
            `${question.explanation} Você ganhou ${earned} XP.`
        );

    }

    else {

        button.classList.add("wrong");

        quiz.wrong++;

        quiz.lives--;

        player.wrong++;

        player.streak = 0;

        showFeedback(
            false,
            "Quase! 😅",
            `A resposta correta é ${question.answerDisplay}. ${question.explanation}`
        );

    }

    player.totalQuestions++;

    updateCategoryStats(
        quiz.category,
        isCorrect
    );

    checkAchievements();

    savePlayer();

    $("livesDisplay").textContent =
        quiz.lives;

    $("nextQuestion")
        .classList.remove("hidden");

}


/* =========================================================
   FEEDBACK
========================================================= */

function showFeedback(
    correct,
    title,
    text
) {

    const feedback =
        $("feedback");

    feedback.className =
        `feedback ${correct ? "correct" : "wrong"}`;

    $("feedbackIcon").textContent =
        correct ? "✓" : "✕";

    $("feedbackTitle").textContent =
        title;

    $("feedbackText").textContent =
        text;

}


/* =========================================================
   PRÓXIMA
========================================================= */

$("nextQuestion").onclick = () => {

    if (quiz.lives <= 0) {

        finishQuiz();

        return;

    }

    quiz.current++;

    if (
        quiz.current >=
        quiz.questions.length
    ) {

        finishQuiz();

    }

    else {

        renderQuestion();

    }

};


/* =========================================================
   FINALIZAR
========================================================= */

function finishQuiz() {

    player.games++;

    savePlayer();

    $("resultScore").textContent =
        quiz.xp;

    $("resultCorrect").textContent =
        quiz.correct;

    $("resultWrong").textContent =
        quiz.wrong;

    $("resultXP").textContent =
        quiz.xp;

    let title;

    if (quiz.correct === 10)
        title = "Perfeito! 🏆";

    else if (quiz.correct >= 8)
        title = "Excelente! 🔥";

    else if (quiz.correct >= 6)
        title = "Muito bom! 😎";

    else if (quiz.correct >= 4)
        title = "Continue treinando! 💪";

    else
        title = "Vamos tentar novamente! 🚀";

    $("resultTitle").textContent =
        title;

    $("resultMessage").textContent =
        `Você acertou ${quiz.correct} de ${quiz.questions.length} questões.`;

    showScreen("result");

    updateUI();

}


/* =========================================================
   SAIR DO QUIZ
========================================================= */

$("quitQuiz").onclick = () => {

    if (
        confirm(
            "Deseja realmente sair do quiz?"
        )
    ) {

        showScreen("home");

    }

};


/* =========================================================
   JOGAR NOVAMENTE
========================================================= */

$("playAgain").onclick = () => {

    startQuiz(
        quiz.category,
        quiz.difficulty
    );

};

$("backHome").onclick = () => {

    showScreen("home");

};


/* =========================================================
   ESTATÍSTICAS POR CATEGORIA
========================================================= */

function updateCategoryStats(
    category,
    correct
) {

    if (
        !player.categoryStats[category]
    ) {

        player.categoryStats[category] = {

            correct: 0,

            total: 0

        };

    }

    player.categoryStats[category]
        .total++;

    if (correct) {

        player.categoryStats[category]
            .correct++;

    }

}


/* =========================================================
   CONQUISTAS
========================================================= */

const achievements = [

    {
        id: "first",
        icon: "🎯",
        name: "Primeiro passo",
        description: "Acerte sua primeira questão.",
        condition: () =>
            player.correct >= 1
    },

    {
        id: "ten",
        icon: "⭐",
        name: "10 acertos",
        description: "Acerte 10 questões.",
        condition: () =>
            player.correct >= 10
    },

    {
        id: "fifty",
        icon: "🔥",
        name: "Matemático",
        description: "Acerte 50 questões.",
        condition: () =>
            player.correct >= 50
    },

    {
        id: "hundred",
        icon: "💯",
        name: "Centena",
        description: "Acerte 100 questões.",
        condition: () =>
            player.correct >= 100
    },

    {
        id: "streak5",
        icon: "🔥",
        name: "Em chamas",
        description: "Consiga uma sequência de 5 acertos.",
        condition: () =>
            player.bestStreak >= 5
    },

    {
        id: "streak10",
        icon: "🚀",
        name: "Imparável",
        description: "Consiga uma sequência de 10 acertos.",
        condition: () =>
            player.bestStreak >= 10
    },

    {
        id: "xp1000",
        icon: "💎",
        name: "XP 1000",
        description: "Conquiste 1000 XP.",
        condition: () =>
            player.xp >= 1000
    },

    {
        id: "games10",
        icon: "🎮",
        name: "Veterano",
        description: "Complete 10 quizzes.",
        condition: () =>
            player.games >= 10
    }

];


function checkAchievements() {

    achievements.forEach(achievement => {

        if (
            achievement.condition() &&
            !player.achievements.includes(
                achievement.id
            )
        ) {

            player.achievements.push(
                achievement.id
            );

        }

    });

    savePlayer();

}


/* =========================================================
   RENDER CONQUISTAS
========================================================= */

function renderAchievements() {

    $("achievementGrid").innerHTML =
        achievements.map(achievement => {

            const unlocked =
                player.achievements.includes(
                    achievement.id
                );

            return `

                <div class="achievement
                    ${unlocked ? "unlocked" : ""}">

                    <div class="achievement-icon">
                        ${achievement.icon}
                    </div>

                    <h3>
                        ${achievement.name}
                    </h3>

                    <p>
                        ${achievement.description}
                    </p>

                </div>

            `;

        }).join("");

}


/* =========================================================
   APRENDER
========================================================= */

const learnData = [

    {
        category: "basic",
        icon: "➕",
        title: "Operações básicas",
        text: `
            <h3>Adição</h3>
            <p>
                A adição junta quantidades.
            </p>

            <div class="formula">
                5 + 3 = 8
            </div>

            <h3>Multiplicação</h3>
            <p>
                É uma forma rápida de representar
                várias adições iguais.
            </p>

            <div class="formula">
                4 × 3 = 12
            </div>
        `
    },

    {
        category: "fraction",
        icon: "½",
        title: "Frações",
        text: `
            <h3>Numerador</h3>
            <p>
                É o número de cima.
            </p>

            <h3>Denominador</h3>
            <p>
                É o número de baixo.
            </p>

            <div class="formula">
                3/4
            </div>
        `
    },

    {
        category: "percent",
        icon: "%",
        title: "Porcentagem",
        text: `
            <p>
                Porcentagem significa uma parte
                de 100.
            </p>

            <div class="formula">
                25% = 25/100
            </div>

            <p>
                Para calcular 25% de 200:
            </p>

            <div class="formula">
                200 × 25 ÷ 100 = 50
            </div>
        `
    },

    {
        category: "bhaskara",
        icon: "Δ",
        title: "Bhaskara",
        text: `
            <p>
                A fórmula de Bhaskara pode ser
                utilizada para encontrar as raízes
                de uma equação do segundo grau.
            </p>

            <div class="formula">
                Δ = b² − 4ac
            </div>

            <div class="formula">
                x = (−b ± √Δ) / 2a
            </div>

            <h3>Forma geral</h3>

            <div class="formula">
                ax² + bx + c = 0
            </div>
        `
    },

    {
        category: "geometry",
        icon: "📐",
        title: "Geometria",
        text: `
            <h3>Área do retângulo</h3>

            <div class="formula">
                A = b × h
            </div>

            <h3>Perímetro</h3>

            <div class="formula">
                P = soma dos lados
            </div>
        `
    },

    {
        category: "power",
        icon: "x²",
        title: "Potenciação",
        text: `
            <p>
                Uma potência representa uma
                multiplicação repetida.
            </p>

            <div class="formula">
                2³ = 2 × 2 × 2 = 8
            </div>
        `
    },

    {
        category: "root",
        icon: "√",
        title: "Radiciação",
        text: `
            <p>
                A raiz quadrada procura o número
                que multiplicado por ele mesmo
                produz determinado valor.
            </p>

            <div class="formula">
                √25 = 5
            </div>
        `
    }

];


function renderLearn() {

    $("learnGrid").innerHTML =
        learnData.map((item,index) => `

            <article
                class="learn-card"
                data-learn="${index}">

                <div class="learn-card-icon">
                    ${item.icon}
                </div>

                <h2>
                    ${item.title}
                </h2>

                <p>
                    Toque para aprender.
                </p>

            </article>

        `).join("");

    document.querySelectorAll(".learn-card")
        .forEach(card => {

            card.onclick = () => {

                openLearn(
                    Number(card.dataset.learn)
                );

            };

        });

}


/* =========================================================
   MODAL APRENDER
========================================================= */

let currentLearnCategory = null;

function openLearn(index) {

    const item =
        learnData[index];

    currentLearnCategory =
        item.category;

    $("learnIcon").textContent =
        item.icon;

    $("learnCategory").textContent =
        "MODO APRENDER";

    $("learnTitle").textContent =
        item.title;

    $("learnContent").innerHTML =
        item.text;

    $("learnModal")
        .classList.remove("hidden");

}

$("closeLearn").onclick = () => {

    $("learnModal")
        .classList.add("hidden");

};

$("learnModal").addEventListener(
    "click",
    event => {

        if (
            event.target ===
            $("learnModal")
        ) {

            $("learnModal")
                .classList.add("hidden");

        }

    }
);

$("learnPlay").onclick = () => {

    $("learnModal")
        .classList.add("hidden");

    startQuiz(
        currentLearnCategory
    );

};


/* =========================================================
   DESAFIOS
========================================================= */

document.querySelectorAll(
    ".challenge-card"
).forEach(card => {

    card.onclick = () => {

        const mode =
            card.dataset.challenge;

        if (mode === "hard") {

            startQuiz(
                "mixed",
                "hard"
            );

        }

        else if (mode === "mixed") {

            startQuiz(
                "mixed",
                "normal"
            );

        }

        else {

            startQuiz(
                categories[
                    random(
                        0,
                        categories.length - 2
                    )
                ].id
            );

        }

    };

});


/* =========================================================
   BOTÕES DA HOME
========================================================= */

$("startRandomBtn").onclick = () => {

    startQuiz("mixed");

};

$("dailyBtn").onclick = () => {

    startQuiz(
        categories[
            new Date().getDate()
            % (categories.length - 1)
        ].id
    );

};


/* =========================================================
   ESTATÍSTICAS
========================================================= */

function renderStats() {

    $("statsXP").textContent =
        player.xp;

    $("statsGames").textContent =
        player.games;

    $("statsCorrect").textContent =
        player.correct;

    const accuracy =
        player.totalQuestions
            ? Math.round(
                player.correct /
                player.totalQuestions *
                100
            )
            : 0;

    $("statsAccuracy").textContent =
        `${accuracy}%`;

    const html =
        categories
            .filter(c => c.id !== "mixed")
            .map(category => {

                const stats =
                    player.categoryStats[
                        category.id
                    ] || {
                        correct: 0,
                        total: 0
                    };

                const percentage =
                    stats.total
                        ? Math.round(
                            stats.correct /
                            stats.total *
                            100
                        )
                        : 0;

                return `

                    <div class="progress-item">

                        <div
                            class="progress-item-header">

                            <span>
                                ${category.icon}
                                ${category.name}
                            </span>

                            <span>
                                ${percentage}%
                            </span>

                        </div>

                        <div class="progress-bar">

                            <div
                                style="
                                width:${percentage}%;
                                height:100%;
                                background:
                                var(--primary);
                                border-radius:20px;
                                ">
                            </div>

                        </div>

                    </div>

                `;

            }).join("");

    $("categoryProgress").innerHTML =
        html;

}


/* =========================================================
   ATUALIZAR UI
========================================================= */

function updateUI() {

    checkAchievements();

    $("xpDisplay").textContent =
        player.xp;

    $("streakDisplay").textContent =
        player.streak;

    $("homeXP").textContent =
        player.xp;

    $("homeStreak").textContent =
        player.streak;

    $("homeAchievements").textContent =
        player.achievements.length;

    const accuracy =
        player.totalQuestions
            ? Math.round(
                player.correct /
                player.totalQuestions *
                100
            )
            : 0;

    $("homeAccuracy").textContent =
        `${accuracy}%`;

    renderStats();

    renderAchievements();

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHtml(value) {

    return String(value)

        .replaceAll("&","&amp;")

        .replaceAll("<","&lt;")

        .replaceAll(">","&gt;")

        .replaceAll('"',"&quot;")

        .replaceAll("'","&#039;");

}


/* =========================================================
   INICIALIZAÇÃO
========================================================= */

function init() {

    renderCategories();

    renderLearn();

    updateUI();

    showScreen("home");

}

init();