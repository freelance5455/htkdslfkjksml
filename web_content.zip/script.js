/**
 * RAYNOX AI — Frontend Application Logic (script.js)
 *
 * Security & Architecture:
 * - ZERO hardcoded API keys in frontend code or localStorage.
 * - Automatically connects to the Raynox AI Backend (/api/health, /api/chat, /api/chat/stream).
 * - Includes real health check (Test Ping), multi-turn chat, duplicate-submit protection,
 *   Hindi/Hinglish/English voice STT & TTS, and live Asia/Kolkata (IST) clock.
 */

const CONFIG = {
  defaultModel: "gemini-3.5-flash",
  timeZone: "Asia/Kolkata",
  defaultLocalBackendPorts: [
    "http://127.0.0.1:3000",
    "http://localhost:3000",
    "http://10.0.2.2:3000"
  ]
};

function loadInitialBackendOverride() {
  const raw = (localStorage.getItem("raynox_backend_url") || "").trim();
  if (!raw) return "";
  try {
    const parsed = new URL(raw);
    if (parsed.protocol === "http:" || parsed.protocol === "https:") {
      return raw.replace(/\/+$/, "");
    }
  } catch (_) {}
  localStorage.removeItem("raynox_backend_url");
  return "";
}

let state = {
  theme: localStorage.getItem("raynox_theme") || "dark",
  selectedModel: localStorage.getItem("raynox_model") || CONFIG.defaultModel,
  userName: localStorage.getItem("raynox_username") || "",
  customInstructions: localStorage.getItem("raynox_instructions") || "",
  voiceLang: localStorage.getItem("raynox_voicelang") || "hi-IN",
  autoSpeak: localStorage.getItem("raynox_autospeak") === "true",
  backendUrl: loadInitialBackendOverride(),
  bearerToken: (localStorage.getItem("raynox_bearer_token") || "").trim(),
  autoDetectedLocalBackend: "",
  connectionStatus: "checking", // "checking" | "connected" | "not_connected"
  connectionError: "",
  activeChatId: null,
  conversations: loadSavedConversations(),
  isGenerating: false,
  lastSubmitTimestamp: 0,
  activeAbortController: null,
  pendingAttachment: null,
  isTorchOn: false,
  torchTrack: null,
  speechRecognition: null,
  isListening: false,
  isSpeaking: false
};

function loadSavedConversations() {
  try {
    const raw = localStorage.getItem("raynox_conversations");
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    return [];
  }
}

// --- Toast Notification Helper ---
let toastTimer = null;
function showToast(message, durationMs = 3500) {
  const el = document.getElementById("statusToast");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.remove("show");
  }, durationMs);
}

// --- Theme Management ---
function applyTheme() {
  document.documentElement.setAttribute("data-theme", state.theme);
  localStorage.setItem("raynox_theme", state.theme);
}

function toggleTheme() {
  state.theme = state.theme === "light" ? "dark" : "light";
  applyTheme();
  showToast(`Switched to ${state.theme === "light" ? "Light" : "Dark"} theme`);
}
applyTheme();

// --- Automatic Built-in Backend Resolution ---
function getEffectiveBackendBaseUrl() {
  // 1. Optional developer override if explicitly set
  if (state.backendUrl) {
    return state.backendUrl.replace(/\/+$/, "");
  }
  // 2. If auto-discovery already locked onto a working endpoint (same-origin or local server)
  if (state.autoDetectedLocalBackend !== "") {
    return state.autoDetectedLocalBackend;
  }
  // 3. When served over http:// or https://, use the app's own server origin automatically
  if (window.location.protocol === "http:" || window.location.protocol === "https:") {
    return window.location.origin.replace(/\/+$/, "");
  }
  // 4. Default to built-in local backend server port
  return CONFIG.defaultLocalBackendPorts[0];
}

function getCandidateBackendUrls() {
  const candidates = [];
  if (state.backendUrl) {
    candidates.push(state.backendUrl.replace(/\/+$/, ""));
  }
  if (state.autoDetectedLocalBackend) {
    candidates.push(state.autoDetectedLocalBackend);
  }
  if (window.location.protocol === "http:" || window.location.protocol === "https:") {
    const originUrl = window.location.origin.replace(/\/+$/, "");
    if (originUrl && originUrl !== "null") {
      candidates.push(originUrl);
    }
  }
  for (const portUrl of CONFIG.defaultLocalBackendPorts) {
    candidates.push(portUrl);
  }
  return [...new Set(candidates)];
}

function validateBackendUrl(urlStr) {
  try {
    const parsed = new URL(urlStr);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return { valid: false, error: "Endpoint URL must start with http:// or https://" };
    }
    return { valid: true, url: urlStr.replace(/\/+$/, "") };
  } catch (_) {
    return { valid: false, error: `Invalid endpoint URL format: "${urlStr}"` };
  }
}

function buildAuthHeaders(extraHeaders = {}) {
  const headers = { ...extraHeaders };
  if (state.bearerToken) {
    headers["Authorization"] = `Bearer ${state.bearerToken}`;
  }
  return headers;
}

function updateBackendDisplayLabel() {
  const displayEl = document.getElementById("activeBackendDisplay");
  if (!displayEl) return;
  const baseUrl = getEffectiveBackendBaseUrl();
  if (state.backendUrl) {
    displayEl.textContent = `Custom Endpoint: ${baseUrl}/api/chat`;
  } else {
    displayEl.textContent = `Automatic Built-in Backend (${baseUrl}/api/chat)`;
  }
}

// --- Real Backend Health Check (Test Ping) ---
function setConnectionUiState(status, message, detailError = "") {
  state.connectionStatus = status;
  state.connectionError = detailError;

  const topDot = document.getElementById("topConnDot");
  const topText = document.getElementById("topConnText");
  const modalDot = document.getElementById("modalConnDot");
  const modalText = document.getElementById("pingStatusText");
  const pingBtn = document.getElementById("pingBackendBtn");

  const dotClass =
    status === "connected" ? "conn-dot connected" :
    status === "checking" ? "conn-dot checking" : "conn-dot error";

  if (topDot) topDot.className = dotClass;
  if (modalDot) modalDot.className = dotClass;

  if (status === "checking") {
    if (topText) topText.textContent = "Checking...";
    if (modalText) modalText.textContent = message || "Checking backend health...";
    if (pingBtn) {
      pingBtn.disabled = true;
      pingBtn.textContent = "Checking...";
    }
  } else if (status === "connected") {
    if (topText) topText.textContent = "Connected";
    if (modalText) modalText.textContent = message || "Connected to AI Backend";
    if (pingBtn) {
      pingBtn.disabled = false;
      pingBtn.textContent = "Test Ping";
    }
  } else {
    if (topText) topText.textContent = "Not Connected";
    if (modalText) modalText.textContent = `Not Connected — ${detailError || message || "Backend unreachable"}`;
    if (pingBtn) {
      pingBtn.disabled = false;
      pingBtn.textContent = "Test Ping";
    }
  }
}

async function pingSingleEndpoint(baseUrl, timeoutMs = 8000) {
  const validation = validateBackendUrl(baseUrl);
  if (!validation.valid) {
    return { ok: false, isRaynoxServer: false, error: validation.error };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const endpoint = `${validation.url}/api/health?verify=true&model=${encodeURIComponent(state.selectedModel)}`;

  try {
    const response = await fetch(endpoint, {
      method: "GET",
      headers: buildAuthHeaders({ "Accept": "application/json" }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    let data = null;
    try {
      data = await response.json();
    } catch (_) {
      return {
        ok: false,
        isRaynoxServer: false,
        error: `Endpoint ${validation.url}/api/health did not return JSON (HTTP ${response.status}).`
      };
    }

    if (response.ok && data && data.ok === true && data.status === "connected") {
      return {
        ok: true,
        isRaynoxServer: true,
        model: data.model || state.selectedModel,
        latencyMs: data.latencyMs,
        url: validation.url
      };
    }

    const isRaynox = Boolean(data && (data.status === "not_connected" || data.error));
    const serverErr = (data && data.error) ? data.error : `Server returned HTTP ${response.status}`;
    return { ok: false, isRaynoxServer: isRaynox, error: serverErr, url: validation.url };
  } catch (err) {
    clearTimeout(timeoutId);
    if (err.name === "AbortError") {
      return { ok: false, isRaynoxServer: false, error: `Connection timed out (${validation.url}).` };
    }
    return {
      ok: false,
      isRaynoxServer: false,
      error: `Cannot reach backend server at ${validation.url} (${err.message}).`
    };
  }
}

async function testBackendPing(showUserToast = false) {
  updateBackendDisplayLabel();
  setConnectionUiState("checking", "Checking live AI backend connection...");

  // If user explicitly entered an invalid custom URL in Developer Override, report it directly
  if (state.backendUrl) {
    const customCheck = validateBackendUrl(state.backendUrl);
    if (!customCheck.valid) {
      setConnectionUiState("not_connected", "Not Connected", customCheck.error);
      if (showUserToast) showToast(`Not Connected: ${customCheck.error}`, 5000);
      return false;
    }
    const customResult = await pingSingleEndpoint(customCheck.url, 8000);
    if (customResult.ok) {
      updateBackendDisplayLabel();
      const msg = `Connected • ${customResult.model}${customResult.latencyMs ? ` (${customResult.latencyMs}ms)` : ""}`;
      setConnectionUiState("connected", msg);
      if (showUserToast) showToast(`Connected: ${msg}`);
      return true;
    }
    // If custom URL was explicitly set by user and failed, show the exact failure for that URL
    setConnectionUiState("not_connected", "Not Connected", customResult.error);
    if (showUserToast) showToast(`Not Connected: ${customResult.error}`, 5000);
    return false;
  }

  // Automatic Built-in Backend Discovery: probe same-origin (/api/health) and local backend ports
  const candidates = getCandidateBackendUrls();
  let specificServerError = "";

  for (const candidateUrl of candidates) {
    const probe = await pingSingleEndpoint(candidateUrl, 5000);
    if (probe.ok) {
      state.autoDetectedLocalBackend = probe.url;
      updateBackendDisplayLabel();
      const msg = `Connected • ${probe.model}${probe.latencyMs ? ` (${probe.latencyMs}ms)` : ""}`;
      setConnectionUiState("connected", msg);
      if (showUserToast) showToast(`Connected to AI Backend (${probe.model})`);
      return true;
    }
    if (probe.isRaynoxServer && probe.error) {
      // The Raynox server responded with a specific configuration message (e.g. missing GEMINI_API_KEY)
      specificServerError = probe.error;
      state.autoDetectedLocalBackend = probe.url;
      updateBackendDisplayLabel();
      break;
    }
  }

  const finalError = specificServerError ||
    "Built-in backend server (server.js) is not reachable. Start the backend server with 'npm start' (and set GEMINI_API_KEY in .env) or deploy the full project together.";

  setConnectionUiState("not_connected", "Not Connected", finalError);
  if (showUserToast) showToast(`Not Connected: ${finalError}`, 5000);
  return false;
}

// --- Live Indian Standard Time (IST) Clock ---
function updateLiveClock() {
  const now = new Date();
  const optionsTime = { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false };
  const optionsDate = { timeZone: "Asia/Kolkata", weekday: "short", day: "2-digit", month: "short", year: "numeric" };

  const timeStr = new Intl.DateTimeFormat("en-IN", optionsTime).format(now);
  const dateStr = new Intl.DateTimeFormat("en-IN", optionsDate).format(now);

  const clockEl = document.getElementById("liveClockText");
  if (clockEl) clockEl.textContent = `${timeStr} IST`;

  const modalClock = document.getElementById("modalClockTime");
  const modalDate = document.getElementById("modalClockDate");
  if (modalClock) modalClock.textContent = `${timeStr} IST`;
  if (modalDate) modalDate.textContent = dateStr;

  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const overmorrow = new Date(now.getTime() + 48 * 60 * 60 * 1000);
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysLeft = daysInMonth - now.getDate();

  const modalToday = document.getElementById("modalToday");
  const modalTomorrow = document.getElementById("modalTomorrow");
  const modalOvermorrow = document.getElementById("modalOvermorrow");
  const modalDaysInMonth = document.getElementById("modalDaysInMonth");

  if (modalToday) modalToday.textContent = dateStr;
  if (modalTomorrow) modalTomorrow.textContent = new Intl.DateTimeFormat("en-IN", optionsDate).format(tomorrow);
  if (modalOvermorrow) modalOvermorrow.textContent = new Intl.DateTimeFormat("en-IN", optionsDate).format(overmorrow);
  if (modalDaysInMonth) modalDaysInMonth.textContent = `${daysLeft} days remaining (${daysInMonth} total)`;
}
setInterval(updateLiveClock, 1000);
updateLiveClock();

// --- Modals & Sidebar ---
function toggleSidebar(open) {
  const sb = document.getElementById("sidebar");
  const overlay = document.getElementById("sidebar-overlay");
  if (!sb || !overlay) return;
  if (open) {
    sb.classList.add("open");
    overlay.classList.add("active");
  } else {
    sb.classList.remove("open");
    overlay.classList.remove("active");
  }
}

function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) {
    modal.classList.add("open");
    if (id === "settingsModal") {
      syncSettingsFormInputs();
      updateBackendDisplayLabel();
    }
  }
  toggleSidebar(false);
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove("open");
}

function handleBackdropClick(event, id) {
  if (event.target && event.target.id === id) {
    closeModal(id);
  }
}

// --- Chat History & Rendering ---
function startNewChat() {
  if (state.isGenerating && state.activeAbortController) {
    state.activeAbortController.abort();
    state.isGenerating = false;
  }
  stopSpeaking();
  state.activeChatId = "chat_" + Date.now();
  renderChatMessages();
  renderChatHistory();
  toggleSidebar(false);
  const inp = document.getElementById("messageInput");
  if (inp) inp.focus();
}

function getActiveConversation() {
  if (!state.activeChatId) return null;
  return state.conversations.find((c) => c.id === state.activeChatId) || null;
}

function saveConversations() {
  try {
    localStorage.setItem("raynox_conversations", JSON.stringify(state.conversations));
  } catch (e) {
    console.warn("Could not save conversations to localStorage:", e);
  }
  renderChatHistory();
}

function renderChatHistory() {
  const list = document.getElementById("chatHistoryList");
  if (!list) return;
  list.innerHTML = "";

  if (state.conversations.length === 0) {
    const empty = document.createElement("div");
    empty.style.padding = "14px 12px";
    empty.style.fontSize = "12px";
    empty.style.color = "var(--text-muted)";
    empty.textContent = "No saved conversations yet.";
    list.appendChild(empty);
    return;
  }

  state.conversations.forEach((conv) => {
    const item = document.createElement("div");
    item.className = "history-item" + (conv.id === state.activeChatId ? " active" : "");

    const titleSpan = document.createElement("span");
    titleSpan.style.overflow = "hidden";
    titleSpan.style.textOverflow = "ellipsis";
    titleSpan.style.flex = "1";
    titleSpan.textContent = conv.title || "Conversation";

    item.appendChild(titleSpan);
    item.onclick = () => {
      state.activeChatId = conv.id;
      renderChatMessages();
      renderChatHistory();
      toggleSidebar(false);
    };
    list.appendChild(item);
  });
}

function renderChatMessages() {
  const container = document.getElementById("chat-container");
  if (!container) return;
  const conv = getActiveConversation();

  if (!conv || !Array.isArray(conv.messages) || conv.messages.length === 0) {
    container.innerHTML = `
      <div class="welcome-screen" id="welcomeScreen">
        <div class="welcome-logo">R</div>
        <h2 class="welcome-title">RAYNOX AI</h2>
        <p class="welcome-subtitle">
          Minimalist Executive Intelligence.<br>
          Connected AI with Live IST Calendar, Dual-Language Hindi/English Voice, and Device Tools.
        </p>
        <div class="prompt-suggestions">
          <div class="prompt-card" onclick="sendQuickPrompt('Aaj kya date hai aur kaunsa din hai?')">
            <span class="prompt-card-title">📅 Aaj kya date hai?</span>
            <span class="prompt-card-desc">Current date, time &amp; day in IST</span>
          </div>
          <div class="prompt-card" onclick="sendQuickPrompt('Kal aur parson ki date kya hogi?')">
            <span class="prompt-card-title">⏳ Relative Date Check</span>
            <span class="prompt-card-desc">Kal aur parson ki date aur calendar stats</span>
          </div>
          <div class="prompt-card" onclick="sendQuickPrompt('Explain how neural networks work in simple Hinglish')">
            <span class="prompt-card-title">💡 Fast Reasoning</span>
            <span class="prompt-card-desc">Clear Hindi, Hinglish, &amp; English explanations</span>
          </div>
          <div class="prompt-card" onclick="sendQuickPrompt('Write a clean Python function for binary search with example')">
            <span class="prompt-card-title">💻 Code Assistant</span>
            <span class="prompt-card-desc">Production code with step-by-step explanation</span>
          </div>
        </div>
      </div>
    `;
    const titleEl = document.getElementById("activeChatTitle");
    if (titleEl) titleEl.textContent = "RAYNOX AI";
    return;
  }

  container.innerHTML = "";
  const titleEl = document.getElementById("activeChatTitle");
  if (titleEl) titleEl.textContent = conv.title || "RAYNOX AI";

  conv.messages.forEach((msg, index) => {
    const row = document.createElement("div");
    row.className = `message-row ${msg.role}`;

    const bubble = document.createElement("div");
    bubble.className = "bubble" + (msg.isError ? " error-bubble" : "");

    if (msg.role === "assistant") {
      const header = document.createElement("div");
      header.className = "bubble-header";
      header.innerHTML = `<span>${msg.isError ? "RAYNOX AI • CONNECTION ERROR" : "RAYNOX AI"}</span>`;
      bubble.appendChild(header);
    }

    const content = document.createElement("div");
    content.className = "bubble-content";
    content.innerHTML = formatMarkdown(msg.content);
    bubble.appendChild(content);

    if (msg.role === "assistant" && msg.content) {
      const actions = document.createElement("div");
      actions.className = "bubble-actions";

      const copyBtn = document.createElement("button");
      copyBtn.className = "bubble-action-btn";
      copyBtn.textContent = "📋 Copy";
      copyBtn.onclick = () => copyText(msg.content);
      actions.appendChild(copyBtn);

      if (!msg.isError) {
        const speakBtn = document.createElement("button");
        speakBtn.className = "bubble-action-btn";
        speakBtn.textContent = "🔊 Speak";
        speakBtn.onclick = () => speakText(msg.content);
        actions.appendChild(speakBtn);
      } else {
        const retryBtn = document.createElement("button");
        retryBtn.className = "bubble-action-btn";
        retryBtn.style.color = "var(--accent-primary)";
        retryBtn.style.fontWeight = "700";
        retryBtn.textContent = "↻ Retry";
        retryBtn.onclick = () => retryFromError(index);
        actions.appendChild(retryBtn);

        const settingsBtn = document.createElement("button");
        settingsBtn.className = "bubble-action-btn";
        settingsBtn.textContent = "⚙️ Check Settings";
        settingsBtn.onclick = () => openModal("settingsModal");
        actions.appendChild(settingsBtn);
      }

      bubble.appendChild(actions);
    }

    row.appendChild(bubble);
    container.appendChild(row);
  });

  container.scrollTop = container.scrollHeight;
}

// --- Markdown Formatter ---
function formatMarkdown(text) {
  if (!text) return "";
  let html = escapeHtml(text)
    .replace(/```([\s\S]*?)```/g, "<pre><code>$1</code></pre>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/\n\n/g, "</p><p>")
    .replace(/\n/g, "<br>");
  return `<p>${html}</p>`;
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// --- Duplicate-Safe Message Submission & Real Backend AI Chat ---
function updateGeneratingButtonState(generating) {
  state.isGenerating = generating;
  const sendBtn = document.getElementById("sendBtn");
  if (!sendBtn) return;
  sendBtn.disabled = generating;
}

function submitMessage() {
  // Prevent duplicate requests when send button is tapped repeatedly
  const now = Date.now();
  if (state.isGenerating || now - state.lastSubmitTimestamp < 450) {
    return;
  }

  const textarea = document.getElementById("messageInput");
  if (!textarea) return;
  const text = textarea.value.trim();
  const attachment = state.pendingAttachment;

  if (!text && !attachment) return;

  state.lastSubmitTimestamp = now;
  textarea.value = "";
  textarea.style.height = "auto";
  clearPendingAttachment();

  if (!state.activeChatId) {
    state.activeChatId = "chat_" + now;
  }

  let conv = getActiveConversation();
  if (!conv) {
    conv = {
      id: state.activeChatId,
      title: (text || attachment.name || "New Chat").slice(0, 36),
      messages: []
    };
    state.conversations.unshift(conv);
  }

  const displayUserText = attachment
    ? `[Attached: ${attachment.name}]\n${text}`.trim()
    : text;

  conv.messages.push({
    role: "user",
    content: displayUserText,
    isError: false
  });
  saveConversations();
  renderChatMessages();

  executeAiChat(conv, text || `Please analyze the attached file (${attachment.name}).`, attachment);
}

function retryFromError(errorMsgIndex) {
  if (state.isGenerating) return;
  const conv = getActiveConversation();
  if (!conv) return;

  // Remove the error bubble
  if (conv.messages[errorMsgIndex] && conv.messages[errorMsgIndex].isError) {
    conv.messages.splice(errorMsgIndex, 1);
  }

  // Find last user message
  for (let i = conv.messages.length - 1; i >= 0; i--) {
    if (conv.messages[i].role === "user") {
      saveConversations();
      renderChatMessages();
      executeAiChat(conv, conv.messages[i].content, null);
      return;
    }
  }
}

function sendQuickPrompt(promptText) {
  if (state.isGenerating) return;
  const inp = document.getElementById("messageInput");
  if (inp) {
    inp.value = promptText;
    submitMessage();
  }
}

async function executeAiChat(conv, userPrompt, attachment) {
  updateGeneratingButtonState(true);

  // Add placeholder assistant message with loading indicator
  const assistantMsg = { role: "assistant", content: "", isError: false };
  conv.messages.push(assistantMsg);
  renderChatMessages();

  const container = document.getElementById("chat-container");
  const rows = container ? container.querySelectorAll(".message-row.assistant") : [];
  const currentRow = rows[rows.length - 1];
  const currentBubble = currentRow ? currentRow.querySelector(".bubble-content") : null;

  if (currentRow) currentRow.classList.add("streaming");
  if (currentBubble) {
    currentBubble.innerHTML = `
      <div class="thinking-indicator">
        <span>Raynox AI is thinking</span>
        <span class="thinking-dots"><span></span><span></span><span></span></span>
      </div>
    `;
  }

  // Handle explicit hardware flashlight voice/text command locally if requested
  const lower = userPrompt.toLowerCase().trim();
  if (lower === "turn on the flashlight" || lower === "flashlight on" || lower === "torch on" || lower === "flashlight on karo") {
    await toggleHardwareTorch(true);
    assistantMsg.content = "Flashlight turned ON 🔦";
    finishAiResponse(conv, assistantMsg.content, false);
    return;
  } else if (lower === "turn off the flashlight" || lower === "flashlight off" || lower === "torch off" || lower === "flashlight off karo") {
    await toggleHardwareTorch(false);
    assistantMsg.content = "Flashlight turned OFF 🔦";
    finishAiResponse(conv, assistantMsg.content, false);
    return;
  }

  // Ensure we have resolved the working built-in backend before sending chat
  if (!state.backendUrl && !state.autoDetectedLocalBackend) {
    await testBackendPing(false);
  }

  const baseUrl = getEffectiveBackendBaseUrl();
  const validation = validateBackendUrl(baseUrl);
  if (!validation.valid) {
    assistantMsg.isError = true;
    assistantMsg.content = `Configuration Error: ${validation.error}`;
    finishAiResponse(conv, assistantMsg.content, true);
    return;
  }

  // Prepare relevant conversation history (last 20 valid messages excluding the empty placeholder)
  const historyPayload = conv.messages
    .slice(0, -1)
    .filter((m) => !m.isError && m.content && m.content.trim())
    .slice(-20)
    .map((m) => ({
      role: m.role === "user" ? "user" : "model",
      content: m.content
    }));

  const requestPayload = {
    message: userPrompt,
    history: historyPayload,
    model: state.selectedModel || CONFIG.defaultModel,
    userName: state.userName,
    customInstructions: state.customInstructions,
    attachment: attachment
  };

  state.activeAbortController = new AbortController();
  const timeoutId = setTimeout(() => {
    if (state.activeAbortController) state.activeAbortController.abort();
  }, 60000);

  try {
    // Call POST /api/chat on the resolved built-in backend
    const chatEndpoint = `${validation.url}/api/chat`;
    const response = await fetch(chatEndpoint, {
      method: "POST",
      headers: buildAuthHeaders({
        "Content-Type": "application/json",
        "Accept": "application/json"
      }),
      body: JSON.stringify(requestPayload),
      signal: state.activeAbortController.signal
    });
    clearTimeout(timeoutId);

    let data = null;
    try {
      data = await response.json();
    } catch (_) {
      throw new Error(`Invalid JSON response from backend server (HTTP ${response.status}).`);
    }

    if (!response.ok || !data || data.ok !== true) {
      const serverErr = (data && data.error) ? data.error : `Backend returned HTTP ${response.status}`;
      throw new Error(serverErr);
    }

    const replyText = (data.reply || "").trim();
    if (!replyText) {
      throw new Error("The AI backend returned an empty reply.");
    }

    assistantMsg.content = replyText;
    assistantMsg.isError = false;
    setConnectionUiState("connected", `Connected • ${data.model || state.selectedModel}`);
    finishAiResponse(conv, replyText, false);
  } catch (err) {
    clearTimeout(timeoutId);
    console.error("AI Chat Error:", err);

    let errorMessage = err.message || "Unable to reach the AI backend.";
    if (err.name === "AbortError") {
      errorMessage = "Request timed out after 60 seconds. Please check your connection and tap Retry.";
    } else if (
      errorMessage.includes("Failed to fetch") ||
      errorMessage.includes("NetworkError") ||
      errorMessage.includes("Load failed")
    ) {
      errorMessage = `Built-in backend server (${validation.url}/api/chat) is not reachable. Ensure the backend server is running ('npm start' with GEMINI_API_KEY in .env) or deploy the full project together, then tap "Retry" or "Test Ping".`;
    }

    assistantMsg.isError = true;
    assistantMsg.content = `**AI Request Failed:** ${errorMessage}`;
    setConnectionUiState("not_connected", "Not Connected", errorMessage);
    finishAiResponse(conv, assistantMsg.content, true);
  } finally {
    state.activeAbortController = null;
  }
}

function finishAiResponse(conv, text, isError) {
  updateGeneratingButtonState(false);
  saveConversations();
  renderChatMessages();

  if (!isError && state.autoSpeak && text) {
    speakText(text);
  }
}

// --- Speech-to-Text (Voice Input with Hindi/Hinglish/English & Honest Permission Handling) ---
function toggleVoiceInput() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    showToast("Voice input (Speech-to-Text) is not supported by this browser/WebView. Please type your message or use Chrome.", 5000);
    return;
  }

  const micBtn = document.getElementById("micBtn");
  if (state.isListening) {
    if (state.speechRecognition) {
      try { state.speechRecognition.stop(); } catch (_) {}
    }
    state.isListening = false;
    if (micBtn) micBtn.classList.remove("active");
    return;
  }

  try {
    const recognition = new SpeechRecognition();
    state.speechRecognition = recognition;
    recognition.lang = state.voiceLang || "hi-IN";
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
      state.isListening = true;
      if (micBtn) micBtn.classList.add("active");
      showToast(`Listening (${recognition.lang})... Speak now`);
    };

    recognition.onresult = (event) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        transcript += event.results[i][0].transcript;
      }
      const inp = document.getElementById("messageInput");
      if (inp) {
        inp.value = transcript;
        autoResizeTextarea(inp);
      }
    };

    recognition.onend = () => {
      state.isListening = false;
      if (micBtn) micBtn.classList.remove("active");
    };

    recognition.onerror = (event) => {
      state.isListening = false;
      if (micBtn) micBtn.classList.remove("active");
      const code = event ? event.error : "unknown";
      if (code === "not-allowed" || code === "service-not-allowed") {
        showToast("Microphone permission denied. Please allow microphone access in browser/app settings.", 5000);
      } else if (code === "no-speech") {
        showToast("No speech detected. Tap the microphone and speak clearly.", 3500);
      } else if (code === "audio-capture") {
        showToast("No microphone found or microphone is busy.", 4000);
      } else {
        showToast(`Voice input error: ${code}`, 4000);
      }
    };

    recognition.start();
  } catch (err) {
    state.isListening = false;
    if (micBtn) micBtn.classList.remove("active");
    showToast(`Could not start voice input: ${err.message}`, 4000);
  }
}

// --- Text-to-Speech (Spoken Replies with Honest Support Check) ---
function speakText(text) {
  if (!("speechSynthesis" in window) || typeof window.SpeechSynthesisUtterance === "undefined") {
    showToast("Text-to-Speech is not supported in this browser or WebView.", 4000);
    return;
  }

  try {
    window.speechSynthesis.cancel();
    const plain = String(text)
      .replace(/```[\s\S]*?```/g, "Code block.")
      .replace(/[#*`_\[\]()]/g, "")
      .trim();

    if (!plain) return;

    const utterance = new SpeechSynthesisUtterance(plain);
    utterance.lang = state.voiceLang || "hi-IN";
    utterance.rate = 1.0;

    // Pick a matching voice for Hindi/Indian English if available
    const voices = window.speechSynthesis.getVoices ? window.speechSynthesis.getVoices() : [];
    if (voices.length > 0) {
      const targetLang = (state.voiceLang || "hi-IN").toLowerCase();
      const matched = voices.find((v) => v.lang && v.lang.toLowerCase().startsWith(targetLang.slice(0, 2)));
      if (matched) utterance.voice = matched;
    }

    const stopBtn = document.getElementById("stopSpeakBtn");
    utterance.onstart = () => {
      state.isSpeaking = true;
      if (stopBtn) stopBtn.style.display = "inline-flex";
    };
    utterance.onend = () => {
      state.isSpeaking = false;
      if (stopBtn) stopBtn.style.display = "none";
    };
    utterance.onerror = () => {
      state.isSpeaking = false;
      if (stopBtn) stopBtn.style.display = "none";
    };

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    showToast(`Speech playback failed: ${err.message}`);
  }
}

function stopSpeaking() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
  state.isSpeaking = false;
  const stopBtn = document.getElementById("stopSpeakBtn");
  if (stopBtn) stopBtn.style.display = "none";
}

// --- Hardware Flashlight Control (Torch API + Screen Torch Fallback) ---
async function toggleHardwareTorch(forceState) {
  const card = document.getElementById("torchToolCard");
  const label = document.getElementById("torchStatusLabel");
  const target = typeof forceState === "boolean" ? forceState : !state.isTorchOn;

  try {
    if (target) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toggleScreenTorch(true);
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }
      });
      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities ? track.getCapabilities() : {};

      if (capabilities.torch) {
        await track.applyConstraints({ advanced: [{ torch: true }] });
        state.torchTrack = track;
        state.isTorchOn = true;
        if (card) card.classList.add("active");
        if (label) label.textContent = "Torch is ON 🔦";
      } else {
        track.stop();
        toggleScreenTorch(true);
      }
    } else {
      if (state.torchTrack) {
        state.torchTrack.stop();
        state.torchTrack = null;
      }
      state.isTorchOn = false;
      toggleScreenTorch(false);
      if (card) card.classList.remove("active");
      if (label) label.textContent = "Torch is OFF";
    }
  } catch (_) {
    toggleScreenTorch(target);
  }
}

function toggleScreenTorch(force) {
  const overlay = document.getElementById("screenTorchOverlay");
  if (!overlay) return;
  if (force === true || (force === undefined && !overlay.classList.contains("active"))) {
    overlay.classList.add("active");
  } else {
    overlay.classList.remove("active");
  }
}

// --- Quick App Opener Links & Reminders ---
function openQuickApp(appName) {
  const urls = {
    youtube: "https://www.youtube.com",
    whatsapp: "https://web.whatsapp.com",
    maps: "https://maps.google.com"
  };
  if (urls[appName]) {
    window.open(urls[appName], "_blank", "noopener");
  }
}

function addQuickReminder() {
  const titleEl = document.getElementById("reminderTitle");
  const minsEl = document.getElementById("reminderMinutes");
  const title = (titleEl && titleEl.value.trim()) || "Raynox Reminder";
  const mins = Math.max(1, Math.min(1440, parseInt(minsEl && minsEl.value, 10) || 15));

  setTimeout(() => {
    showToast(`🔔 REMINDER: ${title}`, 6000);
    speakText(`Reminder: ${title}`);
  }, mins * 60 * 1000);

  if (titleEl) titleEl.value = "";
  showToast(`Reminder "${title}" set for ${mins} min(s) from now.`);
  closeModal("toolsModal");
}

// --- Settings Management (Automatic + Optional Advanced Backend) ---
function syncSettingsFormInputs() {
  const modelSelect = document.getElementById("settingModelSelect");
  if (modelSelect) modelSelect.value = state.selectedModel;

  const langSelect = document.getElementById("settingVoiceLang");
  if (langSelect) langSelect.value = state.voiceLang;

  const nameInput = document.getElementById("settingUserName");
  if (nameInput) nameInput.value = state.userName;

  const instInput = document.getElementById("settingCustomInstructions");
  if (instInput) instInput.value = state.customInstructions;

  const autoSpeakBox = document.getElementById("settingAutoSpeak");
  if (autoSpeakBox) autoSpeakBox.checked = state.autoSpeak;

  const backendUrlInput = document.getElementById("settingBackendUrl");
  if (backendUrlInput) backendUrlInput.value = state.backendUrl;

  const bearerInput = document.getElementById("settingBearerToken");
  if (bearerInput) bearerInput.value = state.bearerToken;
}

function updateSelectedModel(m) {
  state.selectedModel = m;
  localStorage.setItem("raynox_model", m);
  showToast(`Model updated to ${m}`);
}

function updateVoiceLanguage(l) {
  state.voiceLang = l;
  localStorage.setItem("raynox_voicelang", l);
  showToast(`Voice language set to ${l}`);
}

function saveUserName(n) {
  state.userName = String(n || "").trim().slice(0, 80);
  localStorage.setItem("raynox_username", state.userName);
}

function saveCustomInstructions(inst) {
  state.customInstructions = String(inst || "").trim().slice(0, 1000);
  localStorage.setItem("raynox_instructions", state.customInstructions);
}

function toggleAutoSpeak(v) {
  state.autoSpeak = Boolean(v);
  localStorage.setItem("raynox_autospeak", String(state.autoSpeak));
}

async function saveAdvancedBackendSettings() {
  const urlInput = document.getElementById("settingBackendUrl");
  const tokenInput = document.getElementById("settingBearerToken");
  const rawUrl = urlInput ? urlInput.value.trim() : "";
  const rawToken = tokenInput ? tokenInput.value.trim() : "";

  if (rawUrl) {
    const check = validateBackendUrl(rawUrl);
    if (!check.valid) {
      showToast(check.error, 4500);
      setConnectionUiState("not_connected", "Not Connected", check.error);
      return;
    }
    state.backendUrl = check.url;
  } else {
    state.backendUrl = "";
  }

  state.bearerToken = rawToken;
  localStorage.setItem("raynox_backend_url", state.backendUrl);
  localStorage.setItem("raynox_bearer_token", state.bearerToken);

  updateBackendDisplayLabel();
  await testBackendPing(true);
}

async function resetBackendToAuto() {
  state.backendUrl = "";
  state.bearerToken = "";
  localStorage.removeItem("raynox_backend_url");
  localStorage.removeItem("raynox_bearer_token");
  syncSettingsFormInputs();
  updateBackendDisplayLabel();
  showToast("Reset to Automatic Backend configuration");
  await testBackendPing(false);
}

function saveAllSettingsAndClose() {
  const nameInput = document.getElementById("settingUserName");
  const instInput = document.getElementById("settingCustomInstructions");
  if (nameInput) saveUserName(nameInput.value);
  if (instInput) saveCustomInstructions(instInput.value);

  const urlInput = document.getElementById("settingBackendUrl");
  const tokenInput = document.getElementById("settingBearerToken");
  if (urlInput && urlInput.value.trim() !== state.backendUrl) {
    const rawUrl = urlInput.value.trim();
    if (rawUrl) {
      const check = validateBackendUrl(rawUrl);
      if (!check.valid) {
        showToast(check.error, 4500);
        return;
      }
      state.backendUrl = check.url;
    } else {
      state.backendUrl = "";
    }
    localStorage.setItem("raynox_backend_url", state.backendUrl);
  }
  if (tokenInput) {
    state.bearerToken = tokenInput.value.trim();
    localStorage.setItem("raynox_bearer_token", state.bearerToken);
  }

  closeModal("settingsModal");
  showToast("Settings saved");
  testBackendPing(false);
}

function clearAllChatHistory() {
  if (confirm("Are you sure you want to clear all chat conversations?")) {
    state.conversations = [];
    state.activeChatId = null;
    saveConversations();
    renderChatMessages();
    closeModal("settingsModal");
    showToast("All conversation history cleared");
  }
}

// --- Attachments & Utilities ---
function handleFileSelect(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  if (file.size > 1.5 * 1024 * 1024) {
    showToast("File is too large (max 1.5MB supported).", 4000);
    e.target.value = "";
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    const result = String(reader.result || "");
    const base64Idx = result.indexOf("base64,");
    if (base64Idx !== -1) {
      state.pendingAttachment = {
        name: file.name,
        mimeType: file.type || "application/octet-stream",
        data: result.slice(base64Idx + 7)
      };
      const bar = document.getElementById("attachmentPreviewBar");
      const nameEl = document.getElementById("attachmentPreviewName");
      if (nameEl) nameEl.textContent = `📎 ${file.name}`;
      if (bar) bar.style.display = "flex";
    }
  };
  reader.readAsDataURL(file);
}

function clearPendingAttachment() {
  state.pendingAttachment = null;
  const bar = document.getElementById("attachmentPreviewBar");
  if (bar) bar.style.display = "none";
  const fileInput = document.getElementById("fileUploadInput");
  if (fileInput) fileInput.value = "";
}

function copyText(str) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(str).then(() => {
      showToast("Copied to clipboard");
    });
  }
}

function handleTextareaKeydown(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    submitMessage();
  }
}

function autoResizeTextarea(el) {
  if (!el) return;
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 120) + "px";
}

function filterChatHistory() {
  const qEl = document.getElementById("chatSearchInput");
  const q = qEl ? qEl.value.toLowerCase() : "";
  const items = document.querySelectorAll(".history-item");
  items.forEach((it) => {
    it.style.display = it.textContent.toLowerCase().includes(q) ? "flex" : "none";
  });
}

function downloadProjectZip() {
  const a = document.createElement("a");
  a.href = "./Raynox_AI_Export.zip";
  a.download = "Raynox_AI_Export.zip";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// --- Initialize UI & Automatic Health Check on Startup ---
window.addEventListener("DOMContentLoaded", () => {
  syncSettingsFormInputs();
  updateBackendDisplayLabel();
  renderChatHistory();

  if (state.conversations.length > 0) {
    state.activeChatId = state.conversations[0].id;
  }
  renderChatMessages();

  // Automatically check backend connection on startup
  testBackendPing(false);
});
