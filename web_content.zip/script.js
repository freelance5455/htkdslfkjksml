const loops=document.getElementById("loops");
let current=null;
const players=new Map();

for(let i=1;i<=200;i++){
 const card=document.createElement("div");
 card.className="loop";
 card.innerHTML=`
  <div class="row">
   <button class="play">▶ Loop ${i}</button>
   <button class="stop">■</button>
  </div>
  <div class="controls">
   <label>BPM <input class="bpm" type="number" min="40" max="240" value="120"></label>
   <label>Volume <input class="vol" type="range" min="0" max="1" step="0.01" value="1"></label>
  </div>`;
 const play=card.querySelector(".play"), stop=card.querySelector(".stop");
 const bpm=card.querySelector(".bpm"), vol=card.querySelector(".vol");
 let audio=null;

 function stopThis(){
   if(audio){audio.pause();audio.currentTime=0;}
   play.classList.remove("active");
   play.textContent=`▶ Loop ${i}`;
   if(current===audio) current=null;
 }
 play.onclick=()=>{
   if(current && current!==audio) {
     current.pause(); current.currentTime=0;
     document.querySelectorAll(".play.active").forEach(b=>{b.classList.remove("active");});
   }
   if(!audio) {
     audio=new Audio(`audio/loop${i}.mp3`);
     audio.loop=true;
   }
   audio.volume=parseFloat(vol.value);
   audio.play().then(()=>{
     current=audio; play.classList.add("active"); play.textContent=`⏸ Loop ${i}`;
   }).catch(()=>{
     alert(`Loop ${i} की audio file अभी ZIP में नहीं है। अपनी MP3 को audio/loop${i}.mp3 नाम से रखें।`);
   });
 };
 play.addEventListener("dblclick",()=>stopThis());
 stop.onclick=stopThis;
 vol.oninput=()=>{if(audio) audio.volume=parseFloat(vol.value);}
 loops.appendChild(card);
}