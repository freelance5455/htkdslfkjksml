
(() => {
  "use strict";

  const $ = id => document.getElementById(id);

  const GLYPHS = {
    w: { k: "♔", q: "♕", r: "♖", b: "♗", n: "♘", p: "♙" },
    b: { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" }
  };

  const VALUES = { p: 100, n: 320, b: 335, r: 500, q: 900, k: 20000 };

  const TIPS = [
    "Kuasai bagian tengah papan dan kembangkan kuda serta gajah lebih awal.",
    "Sebelum bergerak, tanyakan: apakah bidak ini bisa ditangkap lawan?",
    "Rokade membantu mengamankan raja dan mengaktifkan benteng.",
    "Jangan buru-buru mengeluarkan ratu jika bidak lain belum berkembang.",
    "Cari ancaman lawan terlebih dahulu sebelum memilih langkahmu."
  ];

  let game = new Chess();
  let mode = "ai";
  let selected = null;
  let legalTargets = [];
  let flipped = false;
  let gameOverRecorded = false;
  let pendingPromotion = null;
  let lastMove = null;
  let hintMove = null;
  let soundOn = false;
  let timerId = null;
  let initialSeconds = 600;
  let clocks = { w: 600, b: 600 };
  let clockRunning = false;
  let lastTick = Date.now();

  let stats = loadJSON("cmx_stats", {
    games: 0, wins: 0, losses: 0, draws: 0
  });

  let history = loadJSON("cmx_history", []);
  let playerElo = Number(loadJSON("cmx_elo", 1200)) || 1200; // ELO Putih / pemain utama
  let blackPlayerElo = Number(loadJSON("cmx_black_elo", 1200)) || 1200; // ELO pemain Hitam pada mode lokal
  let lastEloChange = 0;

  function loadJSON(key, fallback) {
    try {
      const value = JSON.parse(localStorage.getItem(key));
      return value ?? fallback;
    } catch {
      return fallback;
    }
  }

  function saveData() {
    localStorage.setItem("cmx_stats", JSON.stringify(stats));
    localStorage.setItem("cmx_history", JSON.stringify(history));
    localStorage.setItem("cmx_elo", JSON.stringify(playerElo));
    localStorage.setItem("cmx_black_elo", JSON.stringify(blackPlayerElo));
  }

  function toast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => el.classList.remove("show"), 2200);
  }

  function beep(freq = 440, duration = 0.07) {
    if (!soundOn) return;

    try {
      const Audio = window.AudioContext || window.webkitAudioContext;
      const ctx = new Audio();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.frequency.value = freq;
      gain.gain.value = 0.04;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
      osc.onended = () => ctx.close();
    } catch (error) {}
  }

  function prettyTime(seconds) {
    if (!Number.isFinite(seconds)) return "∞";

    seconds = Math.max(0, seconds);

    return `${Math.floor(seconds / 60).toString().padStart(2, "0")}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;
  }

  function legalFor(square) {
    return game.moves({ square, verbose: true }).map(move => move.to);
  }

  function renderBoard() {
    const board = $("board");
    board.innerHTML = "";

    const files = flipped
      ? ["h", "g", "f", "e", "d", "c", "b", "a"]
      : ["a", "b", "c", "d", "e", "f", "g", "h"];

    const ranks = flipped
      ? [1, 2, 3, 4, 5, 6, 7, 8]
      : [8, 7, 6, 5, 4, 3, 2, 1];

    const moves = game.history({ verbose: true });
    lastMove = moves.length ? moves[moves.length - 1] : null;

    for (const rank of ranks) {
      for (let fi = 0; fi < 8; fi++) {
        const file = files[fi];
        const square = file + rank;
        const piece = game.get(square);

        const btn = document.createElement("button");
        btn.type = "button";

        btn.className = "square " +
          (((file.charCodeAt(0) - 97 + rank) % 2 === 0)
            ? "light" : "dark");

        btn.dataset.square = square;
        btn.setAttribute("role", "gridcell");

        btn.setAttribute(
          "aria-label",
          `${square}${piece ? `, ${piece.color === "w" ? "putih" : "hitam"} ${piece.type}` : " kosong"}`
        );

        if (selected === square) btn.classList.add("selected");

        if (lastMove &&
            (lastMove.from === square || lastMove.to === square)) {
          btn.classList.add("last-move");
        }

        if (piece) {
          const span = document.createElement("span");
          span.className = "piece " +
            (piece.color === "w" ? "white" : "black");
          span.textContent = GLYPHS[piece.color][piece.type];
          btn.appendChild(span);
        }

        if (legalTargets.includes(square)) {
          const marker = document.createElement("span");
          marker.className = piece ? "capture-ring" : "legal-dot";
          btn.appendChild(marker);
        }

        if (fi === 0) {
          const coord = document.createElement("span");
          coord.className = "coord rank";
          coord.textContent = rank;
          btn.appendChild(coord);
        }

        if (rank === 1) {
          const coord = document.createElement("span");
          coord.className = "coord file";
          coord.textContent = file;
          btn.appendChild(coord);
        }

        btn.addEventListener("click", () => onSquareClick(square));
        board.appendChild(btn);
      }
    }

    renderMoves();
    updateStatus();
  }

  function onSquareClick(square) {
    if (
      game.game_over() ||
      pendingPromotion ||
      (mode === "ai" && game.turn() === "b")
    ) return;

    const piece = game.get(square);

    if (selected && legalTargets.includes(square)) {
      const moves = game.moves({
        square: selected,
        verbose: true
      }).filter(move => move.to === square);

      const promotion = moves.find(move => move.promotion);

      if (promotion) {
        pendingPromotion = { from: selected, to: square };
        $("promotionModal").classList.remove("hidden");
        return;
      }

      makeMove({ from: selected, to: square });
      return;
    }

    if (piece && piece.color === game.turn()) {
      selected = square;
      legalTargets = legalFor(square);
      hintMove = null;
      renderBoard();
    } else {
      selected = null;
      legalTargets = [];
      renderBoard();
    }
  }

  function makeMove(move) {
    let result;

    try {
      result = game.move(move);
    } catch (error) {
      result = null;
    }

    if (!result) {
      toast("Langkah tidak legal.");
      return;
    }

    selected = null;
    legalTargets = [];
    hintMove = null;

    beep(result.captured ? 260 : 480);
    renderBoard();

    if (game.game_over()) {
      finishGame();
      return;
    }

    if (mode === "ai" && game.turn() === "b") {
      $("gameMessage").textContent = "Komputer sedang berpikir…";
      setTimeout(makeAIMove, 220);
    } else {
      $("gameMessage").textContent =
        game.turn() === "w"
          ? "Giliran Putih. Pilih langkahmu."
          : "Giliran Hitam. Pilih langkahmu.";
    }

    lastTick = Date.now();
  }

  function updateStatus() {
    const turn = game.turn() === "w" ? "Putih" : "Hitam";

    $("playerState").textContent = game.in_check()
      ? "Skak! Raja sedang terancam."
      : `Giliran ${turn}`;

    if (game.in_checkmate()) {
      $("gameMessage").textContent =
        `Skakmat! ${turn === "Putih" ? "Hitam" : "Putih"} menang.`;
    } else if (game.in_draw()) {
      $("gameMessage").textContent = "Permainan seri.";
    } else if (game.in_check()) {
      $("gameMessage").textContent =
        `Skak! ${turn} harus menyelamatkan rajanya.`;
    } else if (hintMove) {
      $("gameMessage").textContent =
        `Petunjuk: ${hintMove.from} → ${hintMove.to}`;
    }
  }

  function renderMoves() {
    const list = $("moveList");
    const moves = game.history();

    $("moveCount").textContent = `${moves.length} langkah`;

    if (!moves.length) {
      list.innerHTML =
        '<div class="empty-moves">Belum ada langkah.<br>Langkahmu akan muncul di sini.</div>';
      return;
    }

    list.innerHTML = "";

    for (let i = 0; i < moves.length; i += 2) {
      const row = document.createElement("div");
      row.className = "move-row";

      const number = document.createElement("span");
      number.className = "move-number";
      number.textContent = `${Math.floor(i / 2) + 1}.`;

      const white = document.createElement("span");
      white.className = "move-notation" +
        (i === moves.length - 1 ? " latest" : "");
      white.textContent = moves[i];

      const black = document.createElement("span");
      black.className = "move-notation" +
        (i + 1 === moves.length - 1 ? " latest" : "");
      black.textContent = moves[i + 1] || "";

      row.append(number, white, black);
      list.appendChild(row);
    }

    list.scrollTop = list.scrollHeight;
  }

  function evaluatePosition() {
    if (game.in_checkmate()) {
      return game.turn() === "w" ? -999999 : 999999;
    }

    if (game.in_draw()) return 0;

    const board = game.board();
    let score = 0;

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (!piece) continue;

        let value = VALUES[piece.type];

        const center =
          (3.5 - Math.abs(3.5 - c)) +
          (3.5 - Math.abs(3.5 - r));

        if (piece.type === "p") {
          value += center * 3 +
            (piece.color === "w" ? (6 - r) : (r - 1)) * 2;
        }

        if (["n", "b"].includes(piece.type)) value += center * 5;

        if (piece.type === "k" && game.history().length < 16) {
          value -= center * 3;
        }

        score += piece.color === "w" ? value : -value;
      }
    }

    return score;
  }

  function minimax(depth, alpha, beta, maximizing) {
    if (depth === 0 || game.game_over()) return evaluatePosition();

    const moves = game.moves({ verbose: true });

    moves.sort((a, b) =>
      ((b.captured ? VALUES[b.captured] : 0) -
       (a.captured ? VALUES[a.captured] : 0)) +
      (b.promotion ? 800 : 0) -
      (a.promotion ? 800 : 0)
    );

    if (maximizing) {
      let best = -Infinity;

      for (const move of moves) {
        game.move(move);
        const value = minimax(depth - 1, alpha, beta, false);
        game.undo();

        best = Math.max(best, value);
        alpha = Math.max(alpha, best);

        if (beta <= alpha) break;
      }

      return best;
    } else {
      let best = Infinity;

      for (const move of moves) {
        game.move(move);
        const value = minimax(depth - 1, alpha, beta, true);
        game.undo();

        best = Math.min(best, value);
        beta = Math.min(beta, best);

        if (beta <= alpha) break;
      }

      return best;
    }
  }

  function chooseAIMove() {
    const moves = game.moves({ verbose: true });
    if (!moves.length) return null;

    const level = Number($("difficulty").value);
    const depth = level === 1 ? 1 : level === 2 ? 2 : 3;

    if (level === 1 && Math.random() < 0.25) {
      return moves[Math.floor(Math.random() * moves.length)];
    }

    let best = -Infinity;
    let choices = [];

    for (const move of moves) {
      game.move(move);

      const score = minimax(
        depth - 1, -Infinity, Infinity, true
      );

      game.undo();

      const aiScore = -score;

      if (aiScore > best) {
        best = aiScore;
        choices = [move];
      } else if (aiScore === best) {
        choices.push(move);
      }
    }

    return choices[Math.floor(Math.random() * choices.length)];
  }

  function makeAIMove() {
    if (
      mode !== "ai" ||
      game.turn() !== "b" ||
      game.game_over()
    ) return;

    const move = chooseAIMove();

    if (move) {
      makeMove({
        from: move.from,
        to: move.to,
        promotion: move.promotion || "q"
      });
    }
  }

  function finishGame(reason) {
    stopClock();

    if (gameOverRecorded) return;
    gameOverRecorded = true;

    const result = game.in_checkmate()
      ? (game.turn() === "w" ? "Hitam" : "Putih") + " menang"
      : "Seri";

    let outcome = "draw";

    if (game.in_checkmate()) {
      const winner = game.turn() === "w" ? "b" : "w";
      outcome = winner === "w" ? "win" : "loss";

      if (mode === "ai" && winner === "b") outcome = "loss";
    } else if (clocks.w <= 0 || clocks.b <= 0) {
      outcome = mode === "ai"
        ? (clocks.w <= 0 ? "loss" : "win")
        : (clocks.w <= 0 ? "loss" : "win");
    }

    // Mode AI: ELO pemain utama dibandingkan dengan rating AI.
    // Mode 2 pemain: kedua pemain mendapat perubahan ELO masing-masing.
    const score = outcome === "win" ? 1 : outcome === "loss" ? 0 : 0.5;
    if (mode === "ai") {
      const opponentElo = ({ "1": 900, "2": 1200, "3": 1500 }[$("difficulty").value] || 1200);
      const expected = 1 / (1 + Math.pow(10, (opponentElo - playerElo) / 400));
      lastEloChange = Math.round(32 * (score - expected));
      playerElo = Math.max(100, playerElo + lastEloChange);
    } else {
      // outcome adalah hasil pemain Putih. Jam habis juga dihitung dari sisi Putih.
      const whiteScore = clocks.w <= 0 ? 0 : clocks.b <= 0 ? 1 :
        (game.in_checkmate() ? (game.turn() === "b" ? 1 : 0) : 0.5);
      const expectedWhite = 1 / (1 + Math.pow(10, (blackPlayerElo - playerElo) / 400));
      const whiteChange = Math.round(32 * (whiteScore - expectedWhite));
      const blackChange = -whiteChange;
      playerElo = Math.max(100, playerElo + whiteChange);
      blackPlayerElo = Math.max(100, blackPlayerElo + blackChange);
      lastEloChange = whiteChange;
    }

    if (outcome === "win") stats.wins++;
    else if (outcome === "loss") stats.losses++;
    else stats.draws++;

    stats.games++;

    history.unshift({
      date: new Date().toLocaleString("id-ID", {
        dateStyle: "short",
        timeStyle: "short"
      }),
      mode: mode === "ai" ? "Lawan AI" : "2 Pemain",
      result: reason || result,
      outcome,
      eloChange: lastEloChange,
      eloAfter: playerElo,
      moves: game.history().length
    });

    history = history.slice(0, 30);

    saveData();
    updateStats();
    toast(`${reason || result} · ELO ${lastEloChange >= 0 ? "+" : ""}${lastEloChange}`);
    $("gameMessage").textContent = reason || result;
    beep(660, 0.15);
  }

  function startClock() {
    stopClock();

    clockRunning = initialSeconds > 0;
    lastTick = Date.now();

    if (!clockRunning) {
      updateTimers();
      return;
    }

    timerId = setInterval(() => {
      if (!clockRunning || game.game_over()) return;

      const now = Date.now();
      const elapsed = (now - lastTick) / 1000;
      lastTick = now;

      const side = game.turn();
      clocks[side] -= elapsed;

      if (clocks[side] <= 0) {
        clocks[side] = 0;
        updateTimers();
        clockRunning = false;

        finishGame(
          `${side === "w" ? "Putih" : "Hitam"} kehabisan waktu.`
        );
        return;
      }

      updateTimers();
    }, 250);
  }

  function stopClock() {
    if (timerId) clearInterval(timerId);
    timerId = null;
    clockRunning = false;
  }

  function updateTimers() {
    $("playerTimer").textContent =
      initialSeconds === 0 ? "∞" : prettyTime(clocks.w);

    $("playerTimer").classList.toggle(
      "low", clocks.w < 30 && initialSeconds > 0
    );

    // Badge lawan menampilkan rating ELO, bukan waktu. Waktu hitam tetap berjalan di internal game clock.
  }

  function newGame() {
    stopClock();

    game = new Chess();
    selected = null;
    legalTargets = [];
    pendingPromotion = null;
    hintMove = null;
    gameOverRecorded = false;

    initialSeconds = Number($("timeControl").value);
    clocks = { w: initialSeconds, b: initialSeconds };

    $("opponentName").textContent =
      mode === "ai" ? "Komputer" : "Pemain Hitam";

    $("opponentSub").textContent =
      mode === "ai"
        ? `AI · ${$("difficulty").selectedOptions[0].text}`
        : "2 pemain · lokal";

    $("opponentAvatar").textContent = mode === "ai" ? "♟" : "♚";

    // Rating masing-masing pemain ditampilkan pada badge di atas dan bawah papan.
    $("opponentRating").textContent = mode === "ai"
      ? ({ "1": 900, "2": 1200, "3": 1500 }[$("difficulty").value] || 1200)
      : blackPlayerElo;
    $("playerElo").textContent = playerElo;

    $("gameMessage").textContent =
      "Pilih bidak untuk melihat langkah legal.";

    $("promotionModal").classList.add("hidden");

    renderBoard();
    startClock();

    if (mode === "ai" && game.turn() === "b") {
      setTimeout(makeAIMove, 200);
    }
  }

  function showHint() {
    if (
      game.game_over() ||
      (mode === "ai" && game.turn() === "b")
    ) return;

    const moves = game.moves({ verbose: true });
    if (!moves.length) return;

    const ranked = moves.map(move => ({
      m: move,
      score:
        (move.captured ? VALUES[move.captured] : 0) +
        (move.san.includes("+") ? 70 : 0) +
        (move.san.includes("#") ? 10000 : 0) +
        (["d4", "e4", "d5", "e5"].includes(move.to) ? 20 : 0) +
        (move.promotion ? 800 : 0)
    })).sort((a, b) => b.score - a.score);

    const best = ranked[0].m;

    selected = best.from;
    legalTargets = [best.to];
    hintMove = best;

    renderBoard();
    toast(`Coba ${best.from} ke ${best.to}`);
    beep(600);
  }

  function updateStats() {
    if ($("statElo")) $("statElo").textContent = playerElo;
    if ($("playerElo")) $("playerElo").textContent = playerElo;
    if ($("opponentRating")) $("opponentRating").textContent = mode === "ai"
      ? ({ "1": 900, "2": 1200, "3": 1500 }[$("difficulty").value] || 1200)
      : blackPlayerElo;
    if ($("eloProgress")) {
      $("eloProgress").textContent = lastEloChange === 0
        ? "Rating awal / belum berubah"
        : `Perubahan terakhir ${lastEloChange > 0 ? "+" : ""}${lastEloChange}`;
    }
    $("statGames").textContent = stats.games;
    $("statWins").textContent = stats.wins;
    $("statLosses").textContent = stats.losses;
    $("statDraws").textContent = stats.draws;

    const list = $("historyList");

    if (!history.length) {
      list.textContent = "Belum ada pertandingan selesai.";
      return;
    }

    list.innerHTML = "";

    history.slice(0, 12).forEach(item => {
      const row = document.createElement("div");
      row.className = "history-row";

      const info = document.createElement("div");

      info.innerHTML =
        `<strong>${escapeHTML(item.mode)}</strong>` +
        `<div style="font-size:10px;color:#71839b;margin-top:4px">` +
        `${escapeHTML(item.date)} · ${item.moves} langkah` +
        (Number.isFinite(item.eloChange) ? ` · ELO ${item.eloChange > 0 ? "+" : ""}${item.eloChange} → ${item.eloAfter}` : "") + `</div>`;

      const result = document.createElement("span");

      result.className = "history-result " +
        (item.outcome === "loss" ? "loss" :
         item.outcome === "draw" ? "draw" : "");

      result.textContent = item.result;

      row.append(info, result);
      list.appendChild(row);
    });
  }

  function escapeHTML(str) {
    return String(str).replace(/[&<>"']/g, char => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[char]));
  }

  function showPanel(panel) {
    ["play", "stats", "learn"].forEach(name => {
      $(name + "Panel").classList.toggle("hidden", name !== panel);
    });

    document.querySelectorAll(".nav-item").forEach(button => {
      button.classList.toggle("active", button.dataset.panel === panel);
    });

    $("pageTitle").textContent =
      panel === "play" ? "Siap bertanding?" :
      panel === "stats" ? "Performa permainanmu" :
      "Belajar jadi lebih kuat";

    if (panel === "stats") updateStats();
  }

  document.querySelectorAll(".nav-item").forEach(button => {
    button.addEventListener("click", () => showPanel(button.dataset.panel));
  });

  document.querySelectorAll(".segment").forEach(button => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".segment").forEach(item => {
        item.classList.toggle("active", item === button);
      });

      mode = button.dataset.mode;
      newGame();
    });
  });

  $("difficulty").addEventListener("change", () => {
    if (mode === "ai") {
      $("opponentSub").textContent =
        `AI · ${$("difficulty").selectedOptions[0].text}`;
    }
  });

  $("timeControl").addEventListener("change", newGame);

  $("startBtn").addEventListener("click", () => {
    newGame();
    toast("Pertandingan baru dimulai.");
  });

  $("newGameBtn").addEventListener("click", () => {
    newGame();
    toast("Papan diatur ulang.");
  });

  $("undoBtn").addEventListener("click", () => {
    if (!game.history().length) {
      toast("Belum ada langkah untuk dibatalkan.");
      return;
    }

    game.undo();

    if (mode === "ai" && game.turn() === "b" && game.history().length) {
      game.undo();
    }

    selected = null;
    legalTargets = [];
    hintMove = null;
    gameOverRecorded = false;

    renderBoard();
    startClock();
    toast("Langkah terakhir dibatalkan.");
  });

  $("hintBtn").addEventListener("click", showHint);

  $("flipBtn").addEventListener("click", () => {
    flipped = !flipped;
    renderBoard();
  });

  $("soundBtn").addEventListener("click", () => {
    soundOn = !soundOn;
    $("soundBtn").style.color = soundOn ? "#59c7a1" : "#e7c36f";
    toast(soundOn ? "Suara aktif" : "Suara nonaktif");
    beep();
  });

  $("copyMovesBtn").addEventListener("click", async () => {
    const pgn = game.pgn();

    if (!pgn) {
      toast("Belum ada langkah untuk disalin.");
      return;
    }

    try {
      await navigator.clipboard.writeText(pgn);
      toast("PGN berhasil disalin.");
    } catch (error) {
      toast(pgn);
    }
  });

  $("clearHistoryBtn").addEventListener("click", () => {
    if (confirm("Hapus seluruh riwayat pertandingan?")) {
      history = [];
      stats = { games: 0, wins: 0, losses: 0, draws: 0 };

      saveData();
      updateStats();
      toast("Riwayat dihapus.");
    }
  });

  document.querySelectorAll("[data-promotion]").forEach(button => {
    button.addEventListener("click", () => {
      if (!pendingPromotion) return;

      const { from, to } = pendingPromotion;
      const promotion = button.dataset.promotion;

      $("promotionModal").classList.add("hidden");
      pendingPromotion = null;

      makeMove({ from, to, promotion });
    });
  });

  $("promotionModal").addEventListener("click", event => {
    if (event.target === $("promotionModal")) {
      $("promotionModal").classList.add("hidden");
      pendingPromotion = null;
    }
  });

  $("tipText").textContent =
    TIPS[Math.floor(Math.random() * TIPS.length)];

  updateStats();
  newGame();
})();