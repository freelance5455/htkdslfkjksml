
// ========================================
// كشف المتسابقين
// ========================================

// قراءة البيانات المحفوظة
function loadData(key, fallback) {
    try {
        const value = localStorage.getItem(key);
        return value === null ? fallback : JSON.parse(value);
    } catch {
        return fallback;
    }
}

// ========================================
// بيانات المتسابقين
// ========================================

let competitors = loadData("competitors", []);

if (!Array.isArray(competitors)) {
    competitors = [];
}

// إصلاح البيانات القديمة عند الحاجة
competitors = competitors
    .filter(person =>
        person &&
        typeof person.name === "string" &&
        Number.isFinite(Number(person.score)) &&
        Number(person.score) >= 0
    )
    .map(person => ({
        id: person.id ?? createId(),
        name: person.name,
        score: Number(person.score)
    }));

// ========================================
// إعدادات المظهر
// ========================================

let currentMode = localStorage.getItem("appMode") || "light";
let currentTheme = localStorage.getItem("appTheme") || "green";

// ========================================
// إعدادات نظام الدرجات
// ========================================

let scoreMode = localStorage.getItem("scoreMode") || "open";

let maxScore = Number(
    localStorage.getItem("maxScore") || 100
);

if (!["open", "limited"].includes(scoreMode)) {
    scoreMode = "open";
}

if (!Number.isFinite(maxScore) || maxScore <= 0) {
    maxScore = 100;
}

// ========================================
// عناصر HTML
// ========================================

const homePage = document.getElementById("homePage");
const settingsPage = document.getElementById("settingsPage");

const nameInput = document.getElementById("name");
const scoreInput = document.getElementById("score");
const addButton = document.getElementById("addButton");

const list = document.getElementById("list");
const emptyMessage = document.getElementById("emptyMessage");

const countLabel = document.getElementById("count");
const highestLabel = document.getElementById("highest");
const listCount = document.getElementById("listCount");

const themeToggle = document.getElementById("themeToggle");
const themeChoices = document.querySelectorAll(".theme-choice");

const scoreModeInput = document.getElementById("scoreMode");
const maxScoreInput = document.getElementById("maxScore");
const maxScoreContainer = document.getElementById("maxScoreContainer");
const scoreModeDescription = document.getElementById("scoreModeDescription");

const navButtons = document.querySelectorAll(".nav-button");

// ========================================
// إنشاء معرف
// ========================================

function createId() {
    if (window.crypto && crypto.randomUUID) {
        return crypto.randomUUID();
    }

    return Date.now().toString() +
        Math.random().toString(16).slice(2);
}

// ========================================
// حفظ البيانات
// ========================================

function save() {
    localStorage.setItem(
        "competitors",
        JSON.stringify(competitors)
    );
}

// ========================================
// تنسيق الأرقام
// ========================================

function formatScore(score) {
    return Number.isInteger(score)
        ? score.toLocaleString("en-US")
        : score.toLocaleString("en-US", {
            maximumFractionDigits: 2
        });
}

// ========================================
// التحقق من الدرجة
// ========================================

function validScore(score) {
    return Number.isFinite(score) && score >= 0;
}

// ========================================
// تطبيق الحد الأقصى
// ========================================

function applyScoreLimit(score) {
    let result = Math.max(0, score);

    if (scoreMode === "limited") {
        result = Math.min(result, maxScore);
    }

    return result;
}

// ========================================
// إضافة متسابق
// ========================================

function addCompetitor() {

    const name = nameInput.value.trim();
    const scoreText = scoreInput.value.trim();
    const score = Number(scoreText);

    if (!name) {
        alert("اكتب اسم المتسابق");
        nameInput.focus();
        return;
    }

    if (scoreText === "" || !validScore(score)) {
        alert("اكتب درجة صحيحة");
        scoreInput.focus();
        return;
    }

    if (scoreMode === "limited" && score > maxScore) {
        alert(`أعلى درجة مسموحة هي ${formatScore(maxScore)}`);
        scoreInput.focus();
        return;
    }

    competitors.push({
        id: createId(),
        name: name,
        score: score
    });

    nameInput.value = "";
    scoreInput.value = "";

    save();
    render();

    nameInput.focus();
}

// ========================================
// تغيير الدرجة
// ========================================

function changeScore(id, amount) {

    const person = competitors.find(item => item.id === id);

    if (!person) return;

    const newScore = applyScoreLimit(person.score + amount);

    if (!validScore(newScore)) return;

    person.score = newScore;

    save();
    render();
}

// ========================================
// تغيير مقدار مخصص
// ========================================

function customChange(id, amount, direction) {

    if (!Number.isFinite(amount) || amount <= 0) {
        alert("اكتب مقداراً صحيحاً أكبر من صفر");
        return;
    }

    changeScore(id, amount * direction);
}

// ========================================
// تعديل المتسابق
// ========================================

function editCompetitor(id) {

    const person = competitors.find(item => item.id === id);

    if (!person) return;

    const newName = prompt(
        "اكتب الاسم الجديد:",
        person.name
    );

    if (newName === null) return;

    if (!newName.trim()) {
        alert("الاسم لا يمكن أن يكون فارغاً");
        return;
    }

    const newScoreText = prompt(
        "اكتب الدرجة الجديدة:",
        person.score
    );

    if (newScoreText === null) return;

    const newScore = Number(newScoreText);

    if (newScoreText.trim() === "" || !validScore(newScore)) {
        alert("الدرجة غير صحيحة");
        return;
    }

    if (scoreMode === "limited" && newScore > maxScore) {
        alert(`أعلى درجة مسموحة هي ${formatScore(maxScore)}`);
        return;
    }

    person.name = newName.trim();
    person.score = newScore;

    save();
    render();
}

// ========================================
// حذف المتسابق
// ========================================

function deleteCompetitor(id) {

    const confirmed = confirm("هل تريد حذف هذا المتسابق؟");

    if (!confirmed) return;

    competitors = competitors.filter(
        item => item.id !== id
    );

    save();
    render();
}

// ========================================
// إنشاء زر
// ========================================

function createButton(text, className, callback) {

    const button = document.createElement("button");

    button.type = "button";
    button.textContent = text;
    button.className = className;

    button.addEventListener("click", callback);

    return button;
}

// ========================================
// عرض المتسابقين
// ========================================

function render() {

    list.innerHTML = "";

    // ترتيب تنازلي
    const sorted = [...competitors].sort(
        (a, b) => b.score - a.score
    );

    // الإحصائيات
    countLabel.textContent = competitors.length;

    highestLabel.textContent = competitors.length
        ? formatScore(sorted[0].score)
        : "0";

    listCount.textContent =
        `${competitors.length} متسابق`;

    emptyMessage.style.display =
        competitors.length ? "none" : "block";

    // إنشاء البطاقات
    sorted.forEach((person, index) => {

        const card = document.createElement("div");
        card.className = "competitor";

        const rank = document.createElement("div");
        rank.className = "rank";
        rank.textContent = `المركز ${index + 1}`;

        const info = document.createElement("div");
        info.className = "competitor-info";

        const name = document.createElement("span");
        name.className = "competitor-name";
        name.textContent = person.name;

        const score = document.createElement("span");
        score.className = "competitor-score";
        score.textContent = formatScore(person.score);

        info.append(name, score);

        // أزرار التحكم
        const actions = document.createElement("div");
        actions.className = "actions";

        actions.append(

            createButton("+1", "plus", () => {
                changeScore(person.id, 1);
            }),

            createButton("-1", "minus", () => {
                changeScore(person.id, -1);
            }),

            createButton("تعديل", "edit", () => {
                editCompetitor(person.id);
            }),

            createButton("حذف", "delete", () => {
                deleteCompetitor(person.id);
            })

        );

        // المقدار المخصص
        const amountInput = document.createElement("input");

        amountInput.type = "number";
        amountInput.min = "0.01";
        amountInput.step = "any";
        amountInput.placeholder = "مقدار الزيادة أو الخصم";
        amountInput.className = "amount-input";

        const customActions = document.createElement("div");
        customActions.className = "custom-actions";

        customActions.append(

            createButton("زيادة المقدار", "custom-add", () => {
                customChange(
                    person.id,
                    Number(amountInput.value),
                    1
                );
            }),

            createButton("خصم المقدار", "custom-minus", () => {
                customChange(
                    person.id,
                    Number(amountInput.value),
                    -1
                );
            })

        );

        card.append(
            rank,
            info,
            actions,
            amountInput,
            customActions
        );

        list.appendChild(card);

    });
}

// ========================================
// التنقل بين الصفحات
// ========================================

function showPage(pageId) {

    document.querySelectorAll(".page").forEach(page => {
        page.classList.remove("active");
    });

    navButtons.forEach(button => {
        button.classList.remove("active");
    });

    const selectedPage = document.getElementById(pageId);

    if (!selectedPage) return;

    selectedPage.classList.add("active");

    const selectedButton = document.querySelector(
        `.nav-button[data-page="${pageId}"]`
    );

    if (selectedButton) {
        selectedButton.classList.add("active");
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

navButtons.forEach(button => {

    button.addEventListener("click", () => {
        showPage(button.dataset.page);
    });

});

// ========================================
// الوضع الداكن والفاتح
// ========================================

function applyMode() {

    document.body.dataset.mode = currentMode;

    themeToggle.textContent =
        currentMode === "dark"
            ? "تفعيل الوضع الفاتح"
            : "تفعيل الوضع الداكن";

    localStorage.setItem("appMode", currentMode);
}

themeToggle.addEventListener("click", () => {

    currentMode = currentMode === "dark"
        ? "light"
        : "dark";

    applyMode();

});

// ========================================
// السمات اللونية
// ========================================

function applyTheme() {

    document.body.dataset.theme = currentTheme;

    themeChoices.forEach(button => {

        button.classList.toggle(
            "selected",
            button.dataset.color === currentTheme
        );

    });

    localStorage.setItem("appTheme", currentTheme);
}

themeChoices.forEach(button => {

    button.addEventListener("click", () => {

        currentTheme = button.dataset.color;

        applyTheme();

    });

});

// ========================================
// نظام الدرجات
// ========================================

function applyScoreMode() {

    scoreModeInput.value = scoreMode;

    maxScoreInput.value = maxScore;

    maxScoreContainer.style.display =
        scoreMode === "limited" ? "block" : "none";

    scoreModeDescription.textContent =
        scoreMode === "open"
            ? "الدرجات مفتوحة بدون حد أقصى."
            : `الحد الأقصى للدرجة هو ${formatScore(maxScore)}.`;
}

// تغيير نوع الدرجات
scoreModeInput.addEventListener("change", () => {

    scoreMode = scoreModeInput.value;

    if (scoreMode === "limited") {

        const value = Number(maxScoreInput.value);

        if (!Number.isFinite(value) || value <= 0) {
            maxScore = 100;
        } else {
            maxScore = value;
        }

        // ضبط الدرجات التي تتجاوز الحد الجديد
        competitors.forEach(person => {
            person.score = Math.min(person.score, maxScore);
        });
    }

    localStorage.setItem("scoreMode", scoreMode);
    localStorage.setItem("maxScore", maxScore);

    applyScoreMode();
    save();
    render();

});

// تغيير الحد الأقصى
maxScoreInput.addEventListener("change", () => {

    const value = Number(maxScoreInput.value);

    if (
        maxScoreInput.value.trim() === "" ||
        !Number.isFinite(value) ||
        value <= 0
    ) {
        alert("أدخل حداً أقصى صحيحاً أكبر من صفر");
        maxScoreInput.value = maxScore;
        return;
    }

    maxScore = value;

    // لا يسمح بتجاوز الحد الأقصى الجديد
    competitors.forEach(person => {
        person.score = Math.min(person.score, maxScore);
    });

    localStorage.setItem("maxScore", maxScore);

    applyScoreMode();
    save();
    render();

});

// ========================================
// زر Enter
// ========================================

nameInput.addEventListener("keydown", event => {

    if (event.key === "Enter") {
        scoreInput.focus();
    }

});

scoreInput.addEventListener("keydown", event => {

    if (event.key === "Enter") {
        addCompetitor();
    }

});

// ========================================
// تشغيل التطبيق
// ========================================

addButton.addEventListener("click", addCompetitor);

applyMode();
applyTheme();
applyScoreMode();

render();

showPage("homePage");
