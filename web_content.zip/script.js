const splash=document.getElementById("splash");
const home=document.getElementById("home");
const panel=document.getElementById("panel");
const video=document.getElementById("video");
const player=document.getElementById("player");
const hint=document.getElementById("videoHint");
const fov=document.getElementById("fov");
const fovValue=document.getElementById("fovValue");

setTimeout(()=>{splash.classList.add("hidden");home.classList.remove("hidden")},2500);

document.getElementById("openPanel").onclick=()=>{
  home.classList.add("hidden");
  panel.classList.remove("hidden");
};

fov.oninput=()=>fovValue.textContent=fov.value;

document.getElementById("apply").onclick=()=>{
  panel.classList.add("hidden");
  video.classList.remove("hidden");
  player.src="video.mp4";
  player.play().catch(()=>{});
  player.onerror=()=>hint.style.display="block";
};
