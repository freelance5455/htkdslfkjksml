const DB={"Xiaomi / Redmi / Mi":["Xiaomi 16 Ultra","Xiaomi 16 Pro","Xiaomi 16","Xiaomi 15 Ultra","Xiaomi 15 Pro","Xiaomi 15","Xiaomi 14 Ultra","Xiaomi 14 Pro","Xiaomi 14","Xiaomi 13 Ultra","Xiaomi 13 Pro","Xiaomi 13","Xiaomi 12 Pro","Xiaomi 12","Xiaomi 11 Ultra","Xiaomi 11T Pro","Xiaomi 11T","Redmi Note 15 Pro+ (2026)","Redmi Note 15 5G","Redmi Note 14 Pro+","Redmi Note 14","Redmi Note 13 Pro+ 5G","Redmi Note 13 Pro 4G","Redmi Note 13 4G","Redmi Note 12 Pro+","Redmi Note 12S","Redmi Note 12 4G","Redmi Note 11 Pro+ 5G","Redmi Note 11 Pro","Redmi Note 11S","Redmi Note 11","Redmi Note 10 Pro","Redmi Note 10S","Redmi Note 10","Redmi Note 9 Pro","Redmi Note 9S","Redmi Note 9","Redmi Note 8 Pro","Redmi Note 8T","Redmi Note 8","Redmi 13C 5G","Redmi 13C","Redmi 12C","Redmi 10C","Redmi 10A","Redmi 9C","Redmi 9A","Redmi A3 (2026)","Redmi A2","Redmi A1","Xiaomi 13 Lite","Xiaomi 13T","Xiaomi 13T Pro","Xiaomi 14T","Xiaomi 14T Pro","Xiaomi 15T","Xiaomi 15T Pro","Xiaomi MIX Flip","Redmi 12","Redmi 12 5G","Redmi 13","Redmi 13x","Redmi 14C","Redmi 15","Redmi 15 5G","Redmi 15C","Redmi 15C 5G","Redmi Note 12","Redmi Note 12 5G","Redmi Note 12 Pro 5G","Redmi Note 13","Redmi Note 13 5G","Redmi Note 13 Pro","Redmi Note 14 5G","Redmi Note 14 Pro 5G","Redmi Note 14S","Xiaomi 17 Ultra","Xiaomi 17 Pro Max","Xiaomi 17 Pro","Xiaomi 17","Redmi Note 15 Pro+ 5G","Redmi Note 14 Pro 4G","Redmi Note 14 4G","Redmi Note 12 Pro 4G","Redmi K80 Pro","Redmi K80","Redmi K70 Pro","Redmi K70","Redmi K60 Pro","Redmi K60","Redmi Turbo 4 Pro","Redmi Turbo 4","Redmi Turbo 3","Redmi 10","Redmi A5","Xiaomi 12S Ultra","Xiaomi 12S Pro","Xiaomi 12S","Xiaomi 11 Pro","Xiaomi 10 Pro","Xiaomi 10","Xiaomi Civi 5 Pro","Xiaomi Civi 4 Pro","Xiaomi Civi 3","Xiaomi Civi 2","Xiaomi Civi 1S","Xiaomi Civi","Redmi Note 15 Pro+","Redmi Note 15 Pro","Redmi Note 15","Redmi Note 14 Pro+ 5G","Redmi Note 14 Pro","Redmi Note 13 Pro 5G","Redmi Note 11 Pro 5G","Redmi A7 Pro","Redmi A7 Pro 5G","Redmi A4 5G","Redmi A3 Pro","Redmi A3","Redmi A2+","Redmi A1+","Redmi 10 5G","Redmi 9","Redmi K90 Pro Max","Redmi K90 Pro","Redmi K90","Redmi K80 Ultra","Redmi K70 Ultra","Redmi K60 Ultra","Redmi K50 Ultra","Redmi K50 Pro","Redmi K50","Redmi K40 Pro+","Redmi K40 Pro","Redmi K40","Redmi Turbo 5 Pro","Redmi Turbo 5","POCO F8 Ultra","POCO F8 Pro","POCO F7 Ultra","POCO F7 Pro","POCO F7","POCO X7","POCO X5 Pro 5G","POCO M7 Pro 5G","POCO M7","POCO M6","POCO M4 Pro 5G","POCO M4 5G","POCO M3 Pro 5G","POCO M3","POCO C75","POCO C65","POCO C55","POCO C51"],"Samsung Galaxy":["Galaxy S26 Ultra (2026)","Galaxy S26+","Galaxy S25 Ultra","Galaxy S25+","Galaxy S24 Ultra","Galaxy S24+","Galaxy S23 Ultra","Galaxy S23+","Galaxy S22 Ultra","Galaxy S22+","Galaxy S21 Ultra","Galaxy S21+","Galaxy S21 FE","Galaxy S20 Ultra","Galaxy S20+","Galaxy S20 FE","Galaxy S10+","Galaxy Note 20 Ultra","Galaxy Note 20","Galaxy Note 10+","Galaxy Z Fold7 (2026)","Galaxy Z Fold6","Galaxy Z Flip7 (2026)","Galaxy Z Flip6","Galaxy A75 5G (2026)","Galaxy A73 5G","Galaxy A72","Galaxy A55 5G","Galaxy A54 5G","Galaxy A53 5G","Galaxy A52s 5G","Galaxy A52","Galaxy A35 5G","Galaxy A34 5G","Galaxy A33 5G","Galaxy A25 5G","Galaxy A24","Galaxy A23","Galaxy A15 5G","Galaxy A15 4G","Galaxy A14","Galaxy A13","Galaxy A12","Galaxy A05s","Galaxy A05","Galaxy A04s","Galaxy M54 5G","Galaxy M53 5G","Galaxy M34 5G","Galaxy M33 5G","Galaxy M24 5G","Galaxy M23 5G","Galaxy M14","Galaxy S25 Edge","Galaxy Z Fold5","Galaxy Z Flip5","Galaxy Z Fold4","Galaxy Z Flip4","Galaxy Z Fold3","Galaxy Z Flip3","Galaxy A56 5G","Galaxy A36 5G","Galaxy A26 5G","Galaxy A16","Galaxy A06","Galaxy M56","Galaxy M55","Galaxy M53","Galaxy M35","Galaxy M33","Galaxy M15","Galaxy F55","Galaxy F54","Galaxy F34","Galaxy F15","Galaxy F14","Galaxy S26","Galaxy S25","Galaxy S25 FE","Galaxy S24","Galaxy S24 FE","Galaxy S23","Galaxy S23 FE","Galaxy S22","Galaxy Z Fold2","Galaxy Z Flip","Galaxy A16 5G","Galaxy A14 5G","Galaxy A23 5G","Galaxy M56 5G","Galaxy M55s 5G","Galaxy M55 5G","Galaxy M35 5G","Galaxy M32","Galaxy M15 5G","Galaxy M13","Galaxy M05","Galaxy F56 5G","Galaxy F55 5G","Galaxy F23 5G","Galaxy F15 5G","Galaxy F13","Galaxy F06","Galaxy XCover7","Galaxy XCover6 Pro","Galaxy XCover5"],"Apple iPhone":["iPhone 18 Pro Max (2026)","iPhone 18 Pro","iPhone 18 Plus","iPhone 18","iPhone 17 Pro Max","iPhone 17 Pro","iPhone 17","iPhone 16 Pro Max","iPhone 16 Pro","iPhone 16 Plus","iPhone 16","iPhone 15 Pro Max","iPhone 15 Pro","iPhone 15","iPhone 14 Pro Max","iPhone 14 Pro","iPhone 14","iPhone 13 Pro Max","iPhone 13 Pro","iPhone 13","iPhone 12 Pro Max","iPhone 12 Pro","iPhone 12","iPhone 11 Pro Max","iPhone 11 Pro","iPhone 11","iPhone 17 Air","iPhone 16e","iPhone 15 Plus","iPhone 14 Plus","iPhone 13 mini","iPhone 12 mini","iPhone SE (2022)","iPhone XS Max","iPhone XS","iPhone XR","iPhone X","iPhone 8 Plus","iPhone 8","iPhone 7 Plus","iPhone 7","iPhone SE 3rd Generation"],"POCO":["POCO F8 Pro (2026)","POCO F8","POCO F6 Pro","POCO F6","POCO F5 Pro","POCO F5","POCO F4 GT","POCO F4","POCO F3","POCO X7 GT (2026)","POCO X7 Pro","POCO X6 Pro 5G","POCO X6 5G","POCO X5 5G","POCO X4 Pro 5G","POCO X4 GT","POCO X3 Pro","POCO X3 NFC","POCO M6 Pro","POCO M6 5G","POCO M5s","POCO M5","POCO M4 Pro","POCO C40","POCO X6 Neo","POCO X6","POCO X6 Pro","POCO M6 Pro 4G","POCO M6 Plus 5G","POCO C61","POCO X7 Pro Iron Man Edition","POCO M7 Plus","POCO C71","POCO C85","POCO C85 5G","POCO F9 Pro (verify model)","POCO F9 Ultra (verify model)","POCO X8 (verify model)","POCO X8 Pro (verify model)","POCO X8 Pro Max (verify model)","POCO X8 Pro Iron Man Edition (verify model)","POCO M8 5G (verify model)","POCO M8 Pro 5G (verify model)","POCO M8 Power (verify model)","POCO M8x 5G (verify model)","POCO C81 (verify model)","POCO C81x (verify model)","POCO C85x 5G (verify model)","POCO X8 Power (verify model)","POCO X5 Pro","POCO X5"],"Infinix":["Infinix Zero 40 Ultra (2026)","Infinix Zero 40 Pro","Infinix Zero 30 5G","Infinix Zero Ultra","Infinix Note 40 Pro+ 5G","Infinix Note 40 Pro","Infinix Note 40","Infinix Note 30 Pro","Infinix Note 30 5G","Infinix Note 12 Pro","Infinix Note 12 G96","Infinix GT 30 Pro (2026)","Infinix GT 20 Pro","Infinix GT 10 Pro","Infinix Hot 40 Pro","Infinix Hot 40i","Infinix Hot 30 5G","Infinix Hot 30i","Infinix Hot 20 5G","Infinix Hot 12 Pro","Infinix Hot 11S","Infinix Smart 8 Pro","Infinix Smart 8","Infinix Smart 7 HD","Infinix Smart 7","Infinix NOTE 50 Pro+","Infinix NOTE 50","Infinix ZERO 40 5G","Infinix ZERO 40","Infinix ZERO 30","Infinix HOT 60 Pro+","Infinix HOT 60i","Infinix HOT 50 Pro+","Infinix HOT 50","Infinix HOT 40","Infinix SMART 9","Infinix ZERO 20","Infinix NOTE 50 Pro","Infinix NOTE 30 VIP","Infinix NOTE 12 VIP","Infinix NOTE 12","Infinix HOT 60 Pro","Infinix HOT 60","Infinix HOT 50 Pro","Infinix HOT 30","Infinix HOT 20","Infinix HOT 12","Infinix GT 30","Infinix SMART 6"],"Realme":["Realme GT6 Pro (2026)","Realme GT5 Pro","Realme GT5","Realme GT3 240W","Realme GT Neo 6","Realme GT Neo 5","Realme 13 Pro+ (2026)","Realme 12 Pro+ 5G","Realme 12 Pro","Realme 12 5G","Realme 11 Pro+ 5G","Realme 11 Pro","Realme 11 4G","Realme 10 Pro+","Realme 10 4G","Realme 9 Pro+","Realme 9i","Realme 8 Pro","Realme C67 4G","Realme C55","Realme C53","Realme C51","Realme C35","Realme C33","Realme C30","realme GT 7 Pro","realme GT 6T","realme 14 Pro+","realme 12","realme Narzo 70 Pro","realme Narzo 70","realme C75","realme C65","realme GT 7","realme GT 6","realme GT 5","realme GT 2 Pro","realme GT 2","realme 14 Pro","realme 14","realme 13 Pro","realme 13","realme 12 Pro+","realme 12+","realme 11 Pro+","realme 11","realme 10 Pro","realme 10","realme 9 Pro","realme 9","realme 8","realme C63","realme C61","realme Narzo 60 Pro","realme Narzo 60","realme Narzo 50 Pro","realme Narzo 50","realme Narzo N65","realme Narzo N55"],"Oppo":["Oppo Find X8 Ultra (2026)","Oppo Find X8 Pro","Oppo Find X7 Ultra","Oppo Find X6 Pro","Oppo Reno 13 Pro (2026)","Oppo Reno 13","Oppo Reno 12 Pro","Oppo Reno 12","Oppo Reno 11 Pro","Oppo Reno 11","Oppo Reno 10 Pro+ 5G","Oppo Reno 10 Pro","Oppo Reno 8 Pro 5G","Oppo Reno 7","Oppo A98 5G","Oppo A78 5G","Oppo A78 4G","Oppo A58 4G","Oppo A38","Oppo A18","Oppo A96","Oppo A57","Oppo A54","OPPO Find X8","OPPO A5 Pro","OPPO A3 Pro","OPPO A3","OPPO A79 5G","OPPO A60","OPPO Find X7","OPPO Find X6","OPPO Find X5 Pro","OPPO Find X5","OPPO Find X3 Pro","OPPO Reno 14 Pro","OPPO Reno 14","OPPO Reno 10","OPPO Reno 8","OPPO A5","OPPO A79","OPPO A77","OPPO F29 Pro","OPPO F27 Pro+","OPPO F27","OPPO F25 Pro","OPPO F23","OPPO F21 Pro"],"Huawei":["Huawei Mate 80 Pro (2026)","Huawei Mate 80","Huawei Mate 70 Pro","Huawei Mate 60 Pro+","Huawei Mate 50 Pro","Huawei Pura 80 Ultra (2026)","Huawei Pura 70 Ultra","Huawei Pura 70 Pro","Huawei Nova 12 Pro","Huawei Nova 12i","Huawei Nova 11 Pro","Huawei Nova 10 Pro","Huawei Nova 9 SE","Huawei Y9a","Huawei Y7a","Huawei Y9 Prime","Huawei Pura 70","Huawei nova 13 Pro","Huawei nova 12","Huawei Pura 80 Pro","Huawei Pura 80","Huawei Pura 70 Pro+","Huawei Mate 70 Pro+","Huawei Mate 70","Huawei Mate 60 Pro","Huawei Mate 60","Huawei Mate 50","Huawei Mate 40 Pro","Huawei Mate 40","Huawei P60 Pro","Huawei P60","Huawei P50 Pro","Huawei P50","Huawei P40 Pro+","Huawei P40 Pro","Huawei P40","Huawei nova 14 Pro","Huawei nova 14","Huawei nova 13","Huawei nova 12 Ultra","Huawei nova 11","Huawei nova 10","Huawei nova 9","Huawei nova 8","MatePad Pro 13.2","MatePad Pro 12.2","MatePad 11.5","MatePad Air","MatePad SE","Older MatePad models"],"Google Pixel":["Pixel 7a","Pixel 8","Pixel 8 Pro","Pixel 8a","Pixel 9","Pixel 9 Pro","Pixel 9 Pro XL","Pixel 9 Pro Fold","Pixel 9a","Pixel 10","Pixel 10 Pro","Pixel 10 Pro XL","Pixel 10 Pro Fold","Pixel 5","Pixel 4 XL","Pixel 4","Google Pixel 10","Google Pixel 10 Pro","Google Pixel 10 Pro XL","Google Pixel 9 Pro Fold","Google Pixel 8a","Google Pixel 7 Pro","Google Pixel 7","Google Pixel 6 Pro","Google Pixel 6","Google Pixel 6a","Google Pixel 5a","Google Pixel 4"],"OnePlus":["OnePlus 11","OnePlus 12","OnePlus 12R","OnePlus 13","OnePlus 13R","OnePlus 13s","OnePlus 15 (verify model)","OnePlus 15R (verify model)","OnePlus Nord 5","OnePlus Nord 4","OnePlus Nord 3","OnePlus Nord CE4","OnePlus Nord CE3","OnePlus 10 Pro","OnePlus 10T","OnePlus 9 Pro","OnePlus 9","OnePlus 8 Pro","OnePlus 8T","OnePlus Nord 2T","OnePlus Nord CE5","OnePlus Nord CE 3 Lite","OnePlus Nord N30","OnePlus Nord N20","OnePlus Pad 3","OnePlus Pad 2","OnePlus Pad","OnePlus Pad Go"],"Vivo / iQOO":["Vivo X90","Vivo X90 Pro","Vivo X100","Vivo X100 Pro","Vivo X100 Ultra","Vivo X200","Vivo X200 Pro","Vivo X200 Ultra","Vivo V29","Vivo V30","Vivo V40","Vivo V50","iQOO 11","iQOO 12","iQOO 13","iQOO Neo 9","iQOO Neo 10","iQOO Z9","iQOO Z10","vivo V40 Pro","vivo V30 Pro","vivo Y200","vivo Y100","iQOO Neo10 Pro","iQOO Neo9 Pro","iQOO Z9 Turbo","vivo X90 Pro+","vivo X80 Pro","vivo X80","vivo X70 Pro+","vivo V27","vivo V25","vivo V23","vivo Y300 Pro","vivo Y200 Pro","vivo Y78","vivo Y77","vivo Y36","vivo Y27","vivo Y20","iQOO 10","iQOO 9 Pro","iQOO 9","iQOO Neo 10 Pro","iQOO Neo 8 Pro","iQOO Neo 8","iQOO Neo 7","iQOO Neo 6","iQOO Z8","iQOO Z7","iQOO Z6"],"Honor":["Honor Magic 5","Honor Magic 5 Pro","Honor Magic 6","Honor Magic 6 Pro","Honor Magic 7 Pro","Honor Magic V2","Honor Magic V3","Honor 90","Honor 200","Honor 200 Pro","Honor X9b","Honor X9c","HONOR Magic7","HONOR Magic6","HONOR Magic5","HONOR Magic4 Pro","HONOR 400 Pro","HONOR 400","HONOR 300 Pro","HONOR 300","HONOR 100 Pro","HONOR 100","HONOR 80","HONOR X9a","HONOR X8b","HONOR X8a","HONOR X7c","HONOR X7b","HONOR X6b","HONOR MagicPad 2","HONOR Pad 9","HONOR Pad X9","HONOR Pad X8"],"Motorola":["Motorola Edge 40","Motorola Edge 40 Pro","Motorola Edge 50","Motorola Edge 50 Pro","Motorola Edge 50 Ultra","Motorola Edge 60","Motorola Edge 60 Pro","Motorola Razr 40","Motorola Razr 40 Ultra","Motorola Razr 50","Motorola Razr 50 Ultra","Motorola Moto G54","Motorola Moto G55","Motorola Moto G84","Motorola Moto G85","Motorola Razr 60 Ultra","Motorola Moto G Power 2025","Motorola Moto G Stylus 2025","Motorola Moto G75","Motorola Edge 30 Ultra","Motorola Edge 30 Pro","Motorola Razr 60","Motorola Razr 2022","Moto G86","Moto G75","Moto G45","Moto G35","Moto G34","Moto G24","Moto G23","Moto G Power","Moto G Stylus"],"Tecno":["Tecno Pova 5","Tecno Pova 6","Tecno Pova 6 Pro","Tecno Pova 7","Tecno Camon 20","Tecno Camon 30","Tecno Camon 40","Tecno Spark 20","Tecno Spark 30","Tecno Spark 40","TECNO POVA 7 Ultra","TECNO POVA 7 Pro","TECNO POVA 5 Pro","TECNO CAMON 40 Pro 5G","TECNO CAMON 40 Pro","TECNO CAMON 30 Pro 5G","TECNO SPARK 30 Pro","TECNO SPARK 20 Pro+","TECNO POVA 4 Pro","TECNO POVA 4","TECNO POVA 3","TECNO CAMON 40 Premier","TECNO CAMON 30 Premier","TECNO CAMON 30 Pro","TECNO CAMON 20 Premier","TECNO CAMON 20 Pro","TECNO SPARK 20 Pro","TECNO SPARK 10 Pro","TECNO SPARK 10","TECNO SPARK 9 Pro","TECNO SPARK 9","TECNO PHANTOM V Fold2","TECNO PHANTOM V Flip2","TECNO PHANTOM V Fold","TECNO PHANTOM V Flip"],"Nothing":["Nothing Phone (2)","Nothing Phone (2a)","Nothing Phone (2a) Plus","Nothing Phone (3)","Nothing Phone (3a)","Nothing Phone (3a) Pro","Nothing Phone (1)","CMF Phone 2 Pro","CMF Phone 1"],"Gaming Phones":["ASUS ROG Phone 7","ASUS ROG Phone 8","ASUS ROG Phone 8 Pro","ASUS ROG Phone 9","ASUS ROG Phone 9 Pro","RedMagic 8 Pro","RedMagic 9 Pro","RedMagic 9S Pro","RedMagic 10 Pro","RedMagic 11 Pro (verify model)","Lenovo Legion Y70","Lenovo Legion Y90","ASUS ROG Phone 6 Pro","ASUS ROG Phone 6","ASUS ROG Phone 5s Pro","ASUS ROG Phone 5s","ASUS ROG Phone 5","ASUS Zenfone 12 Ultra","ASUS Zenfone 11 Ultra","ASUS Zenfone 10","ASUS Zenfone 9","ASUS Zenfone 8","Sony Xperia 1 VII","Sony Xperia 1 VI","Sony Xperia 1 IV","Sony Xperia 5 IV","Sony Xperia 10 IV","nubia Z50 Ultra","nubia Z40 Pro","REDMAGIC 10 Pro+","REDMAGIC 8S Pro","REDMAGIC 7S Pro","REDMAGIC 7 Pro","ZTE Axon 40 Ultra","Lenovo Legion Phone Duel 2","Lenovo Legion Phone Duel","Meizu 21 Pro","Meizu 21","Meizu 20 Pro","Meizu 20","Sharp AQUOS R9 Pro","Sharp AQUOS R9","Fairphone 6","Fairphone 5","Fairphone 4","HMD Skyline","HMD Fusion","HMD Pulse Pro","HMD Pulse+","TCL 50 Pro NXTPAPER","TCL 50 XL","TCL 50 SE","TCL 40 NXTPAPER","TCL 40 XL","itel RS4","itel P65","itel P55","itel S25 Ultra","itel S24","Lava Agni 3","Lava Agni 2","Lava Blaze Curve","Lava Blaze 5G"],"PC / Android Emulators":["ASUS ROG Ally","ASUS ROG Ally X","Lenovo Legion Go","Lenovo Legion Go S","MSI Claw","MSI Claw 8 AI+","Steam Deck","Steam Deck OLED","AYANEO 2","AYANEO Kun","GPD Win 4","GPD Win Mini","GPD Win Max 2","ASUS ROG Strix","ASUS ROG Zephyrus","ASUS TUF Gaming","Acer Predator Helios","Acer Nitro","Lenovo Legion","Lenovo LOQ","HP OMEN","HP Victus","Dell Alienware","MSI Titan","MSI Raider","MSI Stealth","MSI Katana","Razer Blade","Gigabyte AORUS","Dell XPS","Dell Inspiron","Dell Latitude","Dell Precision","HP Spectre","HP Envy","HP Pavilion","HP EliteBook","Lenovo ThinkPad","Lenovo IdeaPad","Lenovo Yoga","Lenovo ThinkBook","ASUS Zenbook","ASUS Vivobook","Acer Swift","Acer Aspire","Microsoft Surface Laptop","Microsoft Surface Pro","Samsung Galaxy Book","Huawei MateBook","Custom Gaming PC","Alienware Aurora","Dell XPS Desktop","HP OMEN Desktop","Lenovo Legion Tower","ASUS ROG Desktop","MSI Gaming Desktop","Acer Predator Orion","Intel NUC","Minisforum Mini PC","Beelink Mini PC","Apple Mac mini","Apple Mac Studio","Apple Mac Pro","Lenovo Legion Go 2","MSI Claw A1M","MSI Claw 7 AI+","MSI Claw 8 AI+ Polar Tempest Edition","Steam Deck LCD","AYANEO 2S","AYANEO AIR","AYANEO AIR Plus","AYANEO FLIP","AYANEO SLIDE","AYANEO NEXT","AYANEO NEXT Lite","GPD WIN Max","GPD Pocket 4","GPD Pocket 3","OneXPlayer X1","OneXPlayer X1 Mini","OneXPlayer 2 Pro","OneXPlayer Mini","OneXFly","OneXFly F1 Pro","ZOTAC ZONE Gaming Handheld","Acer Nitro Blaze 7","Acer Nitro Blaze 8","Acer Nitro Blaze 11","Anbernic Win600","Anbernic RG556","Anbernic RG Cube","Anbernic RG406H","AOKZOE A1","AOKZOE A1 Pro","Orange Pi Neo","ASUS ROG Strix SCAR 18","ASUS ROG Strix G18","ASUS ROG Zephyrus G16","ASUS ROG Zephyrus G14","ASUS TUF Gaming A16","ASUS TUF Gaming F16","ASUS TUF Gaming A15","ASUS Vivobook Pro","ASUS Zenbook Pro","Acer Predator Helios 18","Acer Predator Helios Neo 16","Acer Predator Triton","Acer Nitro 16","Acer Nitro V 15","Acer Aspire 5","Acer Swift X","Lenovo Legion Pro 7i","Lenovo Legion Pro 5i","Lenovo Legion 7i","Lenovo Legion 5i","Lenovo LOQ 15","Lenovo LOQ 16","Lenovo ThinkPad P Series","Lenovo IdeaPad Gaming","HP OMEN 16","HP OMEN Transcend 14","HP Victus 16","HP Victus 15","HP ZBook","Alienware m18","Alienware m16","Alienware x16","Dell G16","Dell G15","Dell XPS 16","Dell XPS 15","MSI Titan 18 HX","MSI Raider 18 HX","MSI Vector 16 HX","MSI Stealth 16 AI","MSI Katana 15","MSI Cyborg 15","MSI Thin 15","MSI Creator Series","AORUS MASTER","AORUS ELITE","AORUS 17","AORUS 16","GIGABYTE AERO","GIGABYTE G6","Razer Blade 18","Razer Blade 16","Razer Blade 14","MacBook Pro 16-inch","MacBook Pro 14-inch","MacBook Air 15-inch","MacBook Air 13-inch","ASUS ROG Gaming Desktop","ASUS TUF Gaming Desktop","MSI MEG Trident","Corsair Vengeance Gaming PC","NZXT Player Series","CyberPowerPC Gaming PC","iBUYPOWER Gaming PC","GIGABYTE AORUS Gaming PC","Custom-built gaming desktop","ASUS ROG NUC","Minisforum UM Series","Minisforum HX Series","Minisforum AI Series","Beelink SER Series","Beelink GTR Series","Geekom Mini PC","GMKtec Mini PC","Zotac ZBOX","Lenovo ThinkCentre Tiny","HP Elite Mini","Dell OptiPlex Micro"],"Sony Xperia":["Xperia 1 VII","Xperia 1 VI","Xperia 1 V","Xperia 5 V","Xperia 5 IV","Xperia 10 VI","Xperia 10 V"],"ASUS ROG and Zenfone":["ASUS ROG Phone 7 Ultimate"],"ZTE / nubia / RedMagic":["nubia RedMagic 10 Pro","nubia RedMagic 9 Pro","nubia RedMagic 8 Pro","nubia Z70 Ultra","nubia Z60 Ultra","ZTE Axon 60 Ultra","ZTE Axon 50 Ultra"],"Apple iPad":["iPad Pro 13-inch M4","iPad Pro 11-inch M4","iPad Air 13-inch M3","iPad Air 11-inch M3","iPad mini A17 Pro","iPad 11th generation","iPad Pro M2","iPad Air M2","iPad 10th generation","iPad mini 6","iPad Pro 13-inch","iPad Pro 11-inch","iPad Air 13-inch","iPad Air 11-inch","iPad mini","iPad (A-series models)","Older iPad Pro models","Older iPad Air models","Older iPad mini models"],"Samsung Tablets":["Galaxy Tab S10 Ultra","Galaxy Tab S10+","Galaxy Tab S10 FE+","Galaxy Tab S9 Ultra","Galaxy Tab S9+","Galaxy Tab S8 Ultra","Galaxy Tab S8+","Galaxy Tab A9+","Galaxy Tab S11 Ultra","Galaxy Tab S11","Galaxy Tab S10 FE","Galaxy Tab S9","Galaxy Tab S9 FE+","Galaxy Tab S9 FE","Galaxy Tab S8","Galaxy Tab A9","Galaxy Tab A8"],"Xiaomi and Lenovo Tablets":["Xiaomi Pad 7 Pro","Xiaomi Pad 7","Xiaomi Pad 6S Pro","Xiaomi Pad 6","Redmi Pad Pro","Redmi Pad SE","Lenovo Legion Tab","Lenovo Tab P12","Lenovo Tab P11 Pro","Lenovo Tab M11","Xiaomi Pad 6 Pro","Xiaomi Pad 6S Pro 12.4","Redmi Pad","POCO Pad","Lenovo Tab P11","Huawei MatePad Pro","Huawei MatePad Air","Huawei MatePad 11","Huawei MatePad SE","Amazon Fire Max 11","Amazon Fire HD 10","Amazon Fire HD 8","OPPO Pad","vivo Pad","Realme Pad"]};
let mode='smart',smart=false,selectedModel='',fingers=4,speed='متوسط',deviceFactor=0,deviceType='phone';
async function go(n){const previous=Number(document.querySelector('.screen.active')?.id?.replace('s','')||0);if(previous===2&&n===3)await showInterstitial('device_to_player');document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));document.getElementById('s'+n).classList.add('active');if(n===1)showBanner('banner-home','home');if(n===2)showBanner('banner-device','device')}
function openSmartScan(){deviceType='phone';smart=true;mode='smart';go(2);document.getElementById('deviceType').value='phone';document.getElementById('setupTitle').textContent='فحص ذكي';document.getElementById('smartArea').style.display='block';document.getElementById('manualArea').style.display='none';document.getElementById('continue2').disabled=true;smartDetect()}
function manual(){smart=false;mode='manual';go(2);document.getElementById('setupTitle').textContent='اختيار الجهاز';document.getElementById('smartArea').style.display='none';document.getElementById('manualArea').style.display='block';document.getElementById('continue2').disabled=true;initBrands()}
let smartDetected={company:'غير محددة',model:'طراز غير متاح من المتصفح',exact:false};
function smartDetect(){setTimeout(()=>{const ua=navigator.userAgent||'';let company='غير محددة',model='طراز غير متاح من المتصفح',exact=false,code='';
// Browsers/WebViews often hide the exact model. Only claim an exact match for recognized model identifiers.
const known=[[/2201117SG/i,'Xiaomi / Redmi','Redmi Note 11S'],[/M2012K11AG/i,'Xiaomi / Redmi','POCO F3'],[/M2102J20SG/i,'Xiaomi / Redmi','Redmi Note 10 Pro'],[/SM-S928[A-Z0-9]*/i,'Samsung','Galaxy S24 Ultra'],[/SM-S918[A-Z0-9]*/i,'Samsung','Galaxy S23 Ultra'],[/SM-A536[A-Z0-9]*/i,'Samsung','Galaxy A53 5G'],[/CPH2449/i,'OPPO','OPPO Find N2 Flip'],[/RMX3301/i,'Realme','Realme GT 2 Pro']];
for(const item of known){const m=ua.match(item[0]);if(m){company=item[1];model=item[2];code=m[0];exact=true;break}}
if(!exact){let m=ua.match(/(SM-[A-Z0-9]{4,}|220[0-9]{4}[A-Z]{0,2}|M20[0-9A-Z]{5,}|CPH[0-9]{4,}|RMX[0-9]{4,})/i);if(m){code=m[0];if(/^SM-/i.test(code))company='Samsung';else if(/^(220|M20)/i.test(code))company='Xiaomi / Redmi / POCO';else if(/^CPH/i.test(code))company='OPPO';else if(/^RMX/i.test(code))company='Realme';model='رمز الجهاز '+code+' (الطراز غير مؤكد'}}
smartDetected={company,model,exact};document.getElementById('ring').style.display='none';document.getElementById('scanStatus').textContent=exact?'تم العثور على تطابق معروف؛ أكد أن هذا هو جهازك.':'المتصفح لا يكشف الطراز دائمًا؛ لا نريد تخمين اسم غير صحيح. أكد المعلومات إن كانت مطابقة.';document.getElementById('detected').style.display='block';document.getElementById('detectedName').textContent=model;document.getElementById('detectedCompany').textContent='الشركة: '+company+(exact?'':' — لم يتم التحقق من الطراز بدقة');document.getElementById('osVal').textContent=ua.includes('Android')?'Android':'نظام غير مؤكد';document.getElementById('platformVal').textContent=navigator.platform||'غير متاح';document.getElementById('found').style.display='grid';document.getElementById('manualDpi').value=document.getElementById('manualDpi').value||'480'},120)}
function confirmSmart(ok){if(ok){selectedModel=smartDetected.exact?smartDetected.model:('Generic '+smartDetected.company+' device');deviceFactor=stableHash(selectedModel)%9;document.getElementById('headerCompany').textContent=smartDetected.company;document.getElementById('headerModel').textContent=smartDetected.model;document.getElementById('deviceStrip').style.display='grid';document.getElementById('continue2').disabled=false;document.getElementById('scanStatus').textContent=smartDetected.exact?'تم تأكيد الجهاز؛ ستُستخدم بيانات الطراز المكتشف.':'تم حفظ الكشف العام؛ لأن الطراز غير مؤكد، اختر «ليس هاتفي» ثم حدد الطراز يدويًا للحصول على مدخل أدق.'}else{document.getElementById('deviceStrip').style.display='none';manual()}}
function changeDeviceType(){deviceType=document.getElementById('deviceType').value;const isPC=deviceType==='pc';document.getElementById('dpiLabel').textContent=isPC?'DPI الماوس/المحاكي (حسب الإعداد الفعلي)':'DPI / Density للهاتف';document.getElementById('mouseOptions').style.display=isPC?'block':'none';document.getElementById('fingerOptions').style.display=isPC?'none':'block';document.getElementById('pointerControls').style.display=isPC?'block':'none';document.getElementById('resultPointerWrap').style.display=isPC?'block':'none';initBrands();document.getElementById('continue2').disabled=true}
function initBrands(){const b=document.getElementById('brand');b.innerHTML=Object.keys(DB).filter(k=>deviceType!=='pc'||k==='PC / Android Emulators'||k==='Gaming Phones').filter(k=>deviceType==='pc'||k!=='PC / Android Emulators').map(x=>`<option>${x}</option>`).join('');loadModels()}
function loadModels(){document.getElementById('search').value='';filterModels()}
function filterModels(){const brand=document.getElementById('brand').value;const q=(document.getElementById('search').value||'').toLowerCase();const list=(DB[brand]||[]).filter(x=>x.toLowerCase().includes(q));document.getElementById('count').textContent=list.length+' جهاز في هذه القائمة';const box=document.getElementById('deviceList');box.innerHTML='';list.forEach(x=>{const el=document.createElement('div');el.className='device-item'+(selectedModel===x?' sel':'');el.textContent=x;const sub=document.createElement('span');sub.textContent=brand;el.appendChild(sub);el.onclick=()=>selectModel(x);box.appendChild(el)})}
function selectModel(x){selectedModel=x;document.getElementById('model').value=x;deviceFactor=stableHash(x)%9;document.getElementById('continue2').disabled=false;filterModels()}
function getPointerRange(){const minRaw=document.getElementById('pointerMin')?.value;const maxRaw=document.getElementById('pointerMax')?.value;if(minRaw===''||maxRaw===''||minRaw==null||maxRaw==null)return null;const min=Number(minRaw),max=Number(maxRaw);if(!Number.isFinite(min)||!Number.isFinite(max)||min<0||max<=min||max>10000)return null;return {min,max}}
function recommendPointerInRange(){const r=getPointerRange();if(!r)return null;const t=speed==='سريع'?.72:speed==='بطيء'?.35:.52;return Math.round(r.min+(r.max-r.min)*t)}
function markManualCalibration(){const e=document.getElementById('optimalSummary');if(e&&e.dataset.applied==='yes'){e.dataset.applied='no';e.textContent='تم تعديل القيم يدويًا؛ ستستخدم المعايرة DPI ومؤشر السرعة الحاليين.'}}
function eSafePointerMessage(msg){const e=document.getElementById('optimalSummary');if(e)e.textContent=msg}
function applyOptimalPhoneSettings(){
 const pc=deviceType==='pc';
 if(!selectedModel){document.getElementById('optimalSummary').textContent='اختر طراز الجهاز من القائمة أولًا.';return}
 const specs=getDeviceHardwareSpecs(document.getElementById('brand')?.value||'',selectedModel);
 // The registry values are starting estimates, not verified optimal settings for every player.
 const dpi=pc?Math.round(Math.max(400,Math.min(1600,800+(specs.scale-1)*500))):Math.round(Math.max(240,Math.min(600,specs.density)));
 document.getElementById(pc?'mouseDpi':'manualDpi').value=dpi;
 if(pc){const pointer=recommendPointerInRange();if(pointer===null){eSafePointerMessage('أدخل أقل وأعلى قيمة لمؤشر السرعة أولًا، مثل 0 / 15؛ لن نفترض حدًا أقصى قدره 100.')}else{const pe=document.getElementById('pointerRecommendationInline');if(pe)pe.textContent='القيمة المقترحة ضمن نطاق جهازك: '+pointer;}}
 const e=document.getElementById('optimalSummary');e.dataset.applied='yes';
 e.textContent=pc?('اقتراح مبدئي للكمبيوتر: Mouse DPI '+dpi+' ومؤشر الماوس '+document.getElementById('manualPointerNumber').value+'/100. عدّل وفق إعداد الماوس والمحاكي الفعليين.'):
 ('اقتراح DPI مبدئي لهذا الهاتف: '+dpi+'. لا يوجد مؤشر سرعة ماوس للهاتف؛ حساسية اللمس تُضبط داخل اللعبة. القيمة ليست قياسًا مباشرًا ولا ضمانًا للأفضل.');
}

function stableHash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function pick(el,id){document.querySelectorAll('#'+id+' .pill').forEach(x=>x.classList.remove('sel'));el.classList.add('sel');if(id==='fingers')fingers=parseInt(el.textContent);else speed=el.textContent}
async function startCalibration(){if(!selectedModel){alert('اختر طراز الجهاز أولًا');return}const dpi=Number.parseInt(document.getElementById('manualDpi').value,10);if(!Number.isFinite(dpi)||dpi<1||dpi>10000){alert('أدخل DPI صحيحًا بين 1 و10000');go(2);return}const btn=document.querySelector('#s3 button.btn');if(btn){btn.disabled=true;btn.textContent='جارٍ عرض الإعلان التجريبي…'}try{await showInterstitial('start_calibration');if(btn)btn.textContent='جارٍ حساب الحساسية…';generate()}catch(err){console.error('KAKASHI calculation error:',err);alert('تعذر حساب الحساسية. ارجع وتأكد من بيانات الجهاز.')}finally{if(btn){btn.disabled=false;btn.textContent='بدء المعايرة'}}}
function generateThenAd(){generate()}
function show(id){if(id==='result'){go(5);return}document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));const el=document.getElementById(id);if(el)el.classList.add('active')}
// KAKASHI TVS1 V15 — bounded feedback calibration, integrated into the existing V8 UI.
// The formula is deterministic; sensitivity values are starting estimates, not measured headshot guarantees.
const KAKASHI_HARDWARE_REGISTRY = {
  "apple": {"iPhone 18 Pro Max (2026)":{density:460,scale:1.20},"iPhone 18 Pro":{density:460,scale:1.18},"iPhone 17 Pro Max":{density:460,scale:1.15},"iPhone 16 Pro Max":{density:460,scale:1.10},"iPhone 15 Pro Max":{density:460,scale:1.05},"iPhone 14 Pro Max":{density:460,scale:1.02},"iPhone 13":{density:326,scale:.95},"iPhone 12":{density:326,scale:.95},"iPhone 11":{density:326,scale:.95}},
  "samsung": {"Galaxy S26 Ultra (2026)":{density:500,scale:1.22},"Galaxy S25 Ultra":{density:500,scale:1.16},"Galaxy S24 Ultra":{density:505,scale:1.12},"Galaxy S23 Ultra":{density:500,scale:1.08},"Galaxy A55 5G":{density:400,scale:.96},"Galaxy A54 5G":{density:400,scale:.96},"Galaxy A35 5G":{density:390,scale:.90},"Galaxy A25 5G":{density:390,scale:.90},"Galaxy A15 5G":{density:270,scale:.80},"Galaxy A05":{density:270,scale:.80}},
  "xiaomi_poco": {"POCO F8 Pro (2026)":{density:440,scale:1.25},"POCO F7 Pro":{density:440,scale:1.18},"POCO F6 Pro":{density:446,scale:1.14},"POCO X6 Pro 5G":{density:446,scale:1.10},"Xiaomi 16 Ultra":{density:522,scale:1.26},"Xiaomi 15 Pro":{density:522,scale:1.16},"Redmi Note 15 Pro+ (2026)":{density:400,scale:.98},"Redmi Note 13 Pro 5G":{density:395,scale:.92},"Redmi Note 11S":{density:395,scale:.92}},
  "gaming_brands": {"RedMagic 11 Pro (verify model)":{density:400,scale:1.30},"RedMagic 10 Pro":{density:400,scale:1.26},"RedMagic 9 Pro":{density:400,scale:1.20},"ASUS ROG Phone 10 (verify model)":{density:390,scale:1.28},"ASUS ROG Phone 9":{density:388,scale:1.22},"Infinix GT 30 Pro (2026)":{density:390,scale:1.12},"Infinix GT 20 Pro":{density:392,scale:1.08}},
  "realme_oppo_vivo": {"Realme GT 6":{density:450,scale:1.14},"Oppo Find X8 Ultra (2026)":{density:450,scale:1.16},"Vivo X100 Pro":{density:452,scale:1.15},"Realme 12 Pro":{density:394,scale:.94},"Oppo Reno 12":{density:394,scale:.93},"Vivo V40":{density:452,scale:1.02}},
  "infinix_tecno_itel": {"Infinix Note 40 Pro":{density:393,scale:.96},"Tecno Camon 30 Premier":{density:392,scale:.98},"Infinix Hot 40":{density:270,scale:.84},"Tecno Pova 6 Pro":{density:396,scale:.96},"Itel S24":{density:265,scale:.76}},
  "huawei_honor": {"Huawei Pura 70 Ultra":{density:460,scale:1.12},"Honor Magic 6 Pro":{density:460,scale:1.14},"Honor 200":{density:435,scale:.98},"Honor X9b":{density:395,scale:.88}},
  "pc_emulator": {"BlueStacks":{density:240,scale:.75},"LDPlayer":{density:320,scale:.78},"SmartGaga Emulator":{density:160,scale:.82},"GameLoop":{density:240,scale:.72},"MEmu Play":{density:240,scale:.76},"Google Play Games":{density:240,scale:.74}}
};
function getDeviceHardwareSpecs(brand, model) {
  for (const group of Object.values(KAKASHI_HARDWARE_REGISTRY)) if (group[model]) return group[model];
  const m=String(model||'').toLowerCase();
  // Fallback is an explicitly generic estimate, not a verified physical specification.
  let density=360,scale=1.0;
  if(/iphone|ipad/.test(m)){density=/iphone (11|12|13)( |$)/.test(m)?326:460;scale=/pro|max|ultra/.test(m)?1.08:.98;}
  else if(/redmi a|redmi [1-9]c|galaxy a0|galaxy a1|infinix hot|tecno spark|itel/.test(m)){density=270;scale=.84;}
  else if(/ultra|rog|redmagic|legion|gt |gt[0-9]|f[0-9] pro|pixel 9|pixel 10|galaxy s2[4-6]/.test(m)){density=440;scale=1.16;}
  else if(/poco|redmi note|galaxy a[2-7]|infinix note|camon|pova/.test(m)){density=395;scale=.98;}
  if(String(brand).includes('PC /')){density=240;scale=.78;}
  return {density,scale};
}
function executeKakashiMechanicalCalibration(inputs) {
  const brand=String(inputs.brand||'');
  const model=String(inputs.model||'');
  const speedPattern=['fast','slow'].includes(inputs.speedPattern)?inputs.speedPattern:'medium';
  const fingers=Math.max(2,Math.min(5,parseInt(inputs.fingers,10)||2));
  const isPc=!!inputs.isPc;
  const userDpi=Math.max(1,Math.min(30000,Number(inputs.dpi)||(isPc?800:360)));
  const pointerRaw=Number(inputs.pointerSpeed);
  const pointerSpeed=isPc?(Number.isFinite(pointerRaw)?Math.max(0,Math.min(100,pointerRaw)):50):50;
  const specs=getDeviceHardwareSpecs(brand,model);
  const scale=Number.isFinite(Number(specs.scale))?Math.max(.65,Math.min(1.35,Number(specs.scale))):1;
  const density=Number.isFinite(Number(specs.density))?Math.max(160,Math.min(600,Number(specs.density))):(isPc?240:360);
  // Keep the project's explicit three sensitivity bands; speed is never silently remapped.
  const ranges={fast:[171,195],medium:[150,170],slow:[125,149]};
  const [minGen,maxGen]=ranges[speedPattern];
  let general,redDot,scope2x,scope4x,sniper,freeLook,fireButtonSize;
  if(isPc){
    // Mouse/emulator path is isolated from touch-screen density and phone DPI.
    const dpiFactor=clamp(Math.log(3200/Math.max(400,userDpi))/Math.log(8),0,1);
    const pointerFactor=(pointerSpeed-50)/100;
    const scaleOffset=(scale-1)*5;
    general=Math.round(clamp(minGen+(maxGen-minGen)*(.44+.30*dpiFactor+.12*pointerFactor)+scaleOffset,minGen,maxGen));
    redDot=Math.round(clamp(general*.80,0,200));
    scope2x=Math.round(clamp(general*.68,0,200));
    scope4x=Math.round(clamp(general*.56,0,200));
    sniper=Math.round(clamp(general*.38,0,200));
    freeLook=Math.round(clamp(general*.55,0,200));
    fireButtonSize=userDpi>1200?12:14;
  } else {
    const dpiRatio=userDpi/Math.max(240,density);
    // Bounded DPI correction prevents extreme input values from dominating the output.
    const dpiOffset=clamp(Math.log2(dpiRatio)*2.4,-5,5);
    const tierOffset=clamp((scale-1)*9,-3.2,3.2);
    const fingerOffset=(fingers-3)*.8;
    const speedCenter=speedPattern==='fast'?.62:speedPattern==='slow'?.38:.50;
    general=Math.round(clamp(minGen+(maxGen-minGen)*speedCenter+dpiOffset+tierOffset+fingerOffset,minGen,maxGen));
    // Anti-overshoot profile: lower scoped multipliers for faster drag; all values remain within 0–200.
    const ratios=speedPattern==='fast'?[.82,.755,.675,.49,.73]:speedPattern==='slow'?[.86,.795,.715,.53,.72]:[.84,.775,.695,.51,.725];
    const fingerControl=clamp(1-(fingers-3)*.006,.97,1.02);
    const dpiControl=clamp(1-Math.log2(dpiRatio)*.006,.97,1.03);
    const tierControl=clamp(1+(scale-1)*.025,.985,1.01);
    redDot=Math.round(clamp(general*ratios[0]*fingerControl*dpiControl*tierControl,0,200));
    scope2x=Math.round(clamp(general*ratios[1]*fingerControl*dpiControl*tierControl,0,200));
    scope4x=Math.round(clamp(general*ratios[2]*fingerControl*dpiControl*tierControl,0,200));
    sniper=Math.round(clamp(general*ratios[3]*dpiControl,0,200));
    freeLook=Math.round(clamp(general*ratios[4],0,200));
    const button=49+(fingers>=4?1:0)+(speedPattern==='slow'?2:0)-(speedPattern==='fast'?2:0)-(scale>1.12?1:0)-(userDpi>450?1:0);
    fireButtonSize=Math.round(clamp(button,40,57));
  }
  return {identity:'HEADSHOT DOMINATOR V14',engineStatus:'V15 bounded feedback estimate; validate in-game',inputSummary:{device:model,brand,dpi:userDpi,pointerSpeed:pointerSpeed+'%',fingers,pattern:speedPattern,deviceScale:scale,deviceDensity:density},calibration:{general,redDot,scope2x,scope4x,sniper,freeLook,fireButtonSize}};
}
function clamp(value,min,max){return Math.max(min,Math.min(max,value));}
function getRecommendedControls(brand,model,speedPattern,fingerCount,isPc){
 const specs=getDeviceHardwareSpecs(brand,model);
 const scale=Number.isFinite(Number(specs.scale))?Number(specs.scale):1;
 const fingersN=Math.max(2,Math.min(5,Number.parseInt(fingerCount,10)||2));
 const speedOffset=speedPattern==="fast"?1:speedPattern==="slow"?-1:0;
 if(isPc){
  // PC path is mouse/emulator DPI, deliberately separate from Android display density.
  const baseMouseDpi=Math.max(400,Math.min(1600,Math.round((800+(scale-1)*500)/50)*50));
  const dpi=Math.max(400,Math.min(1600,Math.round((baseMouseDpi+speedOffset*100)/50)*50));
  const pointer=Math.max(1,Math.min(100,Math.round(45+(scale-1)*22+speedOffset*7)));
  return {dpi,pointer,confidence:"تقدير لفئة المحاكي/الجهاز؛ ليس قراءة فعلية لإعدادات الماوس"};
 }
 const known=Object.values(KAKASHI_HARDWARE_REGISTRY).some(g=>Object.prototype.hasOwnProperty.call(g,model));
 // Use the selected model's available profile as a starting point, then apply small, bounded
 // adjustments for play style and finger count. These are calibration starting values, not facts.
 const modelBase=Number.isFinite(Number(specs.density))?Number(specs.density):360;
 const scaleTier=Number.isFinite(Number(specs.scale))?Number(specs.scale):1;
 const tierAdjust=Math.round((scaleTier-1)*35);
 const fingerAdjust=(fingersN-3)*5;
 const dpi=Math.max(240,Math.min(600,Math.round((modelBase+speedOffset*10+fingerAdjust+tierAdjust)/10)*10));
 const pointer=null;
 return {dpi,pointer,confidence:known?"اقتراح DPI مبدئي من ملف الطراز، وليس قيمة مثالية مثبتة":"اقتراح DPI عام لأن بيانات الطراز التفصيلية غير متاحة؛ اختبره داخل اللعبة"};
}
function recalculateOptimal(){const e=document.getElementById("useOptimalSettings");if(e)e.checked=true;generate()}
function generate(){
 const pc=deviceType==="pc";
 const speedKey=speed==="سريع"?"fast":speed==="بطيء"?"slow":"medium";
 const brand=document.getElementById("brand")?.value||"";
 const useOptimal=document.getElementById("useOptimalSettings")?.checked!==false;
 const recommended=getRecommendedControls(brand,selectedModel,speedKey,fingers,pc);
 const dpiField=pc?document.getElementById("mouseDpi"):document.getElementById("manualDpi");
 const enteredDpi=Number(dpiField?.value);
 const pointerRange=getPointerRange();
 const pointerRecommendation=pc?recommendPointerInRange():null;
 if(!useOptimal&&(!Number.isFinite(enteredDpi)||enteredDpi<1||enteredDpi>(pc?10000:10000))){alert("أدخل قيمة DPI صحيحة قبل الحساب.");return}
 if(pc&&!pointerRange){alert("أدخل نطاق مؤشر السرعة الذي يدعمه جهازك، مثل 0 / 15. الرقم الثاني هو الحد الأقصى الفعلي في جهازك.");return}
 const dpi=useOptimal?recommended.dpi:enteredDpi;
 const manualPointerRaw=Number(document.getElementById("manualPointerNumber")?.value);
 const pointer=pc?(useOptimal?pointerRecommendation:(Number.isFinite(manualPointerRaw)&&manualPointerRaw>=pointerRange.min&&manualPointerRaw<=pointerRange.max?manualPointerRaw:null)):50;
 if(pc&&pointer===null){alert("أدخل قيمة مؤشر السرعة اليدوية داخل النطاق الذي حددته.");return}
 const normalizedPointer=pc&&pointerRange&&pointerRange.max>pointerRange.min?Math.round(100*(pointer-pointerRange.min)/(pointerRange.max-pointerRange.min)):50;
 const result=executeKakashiMechanicalCalibration({brand,model:selectedModel,dpi,pointerSpeed:normalizedPointer,fingers,speedPattern:speedKey,isPc:pc});
 const c=result.calibration, vals=[c.general,c.redDot,c.scope2x,c.scope4x,c.sniper,c.freeLook];
 ["resGeneral","resRedDot","res2x","res4x","resSniper","resFreeLook"].forEach((id,i)=>{const e=document.getElementById(id);if(e)e.textContent=vals[i]});
 try{const saved=JSON.parse(localStorage.getItem('dominator_v17_feedback_values')||'null');if(saved){["resGeneral","resRedDot","res2x","res4x","resSniper","resFreeLook"].forEach(id=>{const e=document.getElementById(id);if(e&&Number.isFinite(Number(saved[id])))e.textContent=String(Math.max(0,Math.min(200,Math.round(Number(saved[id])))))});const state=readRewardState();const noteEl=document.getElementById('feedbackNote');if(noteEl&&state&&state.unlocked)noteEl.textContent='تم استرجاع تعديلات المعايرة المحفوظة محليًا. كل تعديل جديد يتطلب إكمال إعلان مكافأة.'}}catch(e){}
 const fire=document.getElementById("fb");if(fire)fire.textContent=c.fireButtonSize+"%";
 const rd=document.getElementById("resultDpi");if(rd)rd.textContent=String(dpi);
 const rp=document.getElementById("resultPointer");if(rp)rp.textContent=pc?(String(pointer)+" (من "+pointerRange.min+" إلى "+pointerRange.max+")"):"غير مستخدم للهاتف";const ph=document.getElementById("pointerHowTo");if(ph)ph.textContent=pc?"افتح إعدادات النظام/المحاكي واضبط المؤشر على "+pointer+"؛ القيمة المعروضة هي القيمة الفعلية ضمن نطاق جهازك.":"الهاتف لا يستخدم مؤشر سرعة الماوس.";const pi=document.getElementById("pointerRecommendationInline");if(pi&&pc)pi.textContent="ضمن نطاق جهازك: "+pointer+" (الحدود "+pointerRange.min+" / "+pointerRange.max+")";const rpw=document.getElementById("resultPointerWrap");if(rpw)rpw.style.display=pc?"block":"none";
 const note=document.getElementById("optimalResultNote");if(note)note.textContent=(useOptimal?"تم اختيار القيم المقترحة تلقائيًا. ":"وضع يدوي. ")+recommended.confidence+"؛ القيم نقطة بداية وليست ضمانًا تجريبيًا لأفضل أداء.";
 const platform=String(document.getElementById("emulator")?.value||"PC");
 document.getElementById("profileName").textContent="HEADSHOT SENSI MAX • KAKASHI TVS1 • DOMINATOR V14 ENGINE • "+(pc?platform:selectedModel)+" • "+(pc?"Mouse DPI ":"DPI ")+dpi+" • Pointer "+(pc?pointer:"غير مستخدم")+" • "+speed+" • نتيجة تقديرية";
 show("result");
}

function closeAdAndReveal(){document.getElementById('adOverlay').style.display='none'}
function copyProjectSpecification(){
 const deviceLines=Object.entries(DB).map(([brand,models])=>brand+":\n- "+models.join("\n- ")).join("\n\n");
 const pcProfiles={
  "BlueStacks":"ملف مستقل؛ DPI الماوس؛ polling rate؛ حساسية المحاكي",
  "LDPlayer":"ملف مستقل؛ DPI الماوس؛ polling rate؛ حساسية المحاكي",
  "GameLoop":"ملف مستقل؛ DPI الماوس؛ polling rate؛ حساسية المحاكي",
  "MEmu Play":"ملف مستقل؛ DPI الماوس؛ polling rate؛ حساسية المحاكي",
  "Google Play Games":"ملف مستقل؛ DPI الماوس؛ polling rate؛ حساسية المحاكي",
  "Steam Deck / handheld":"ملف handheld مستقل؛ تخطيط التحكم والحساسية المتاحة",
  "لعبة تعمل مباشرة على PC":"ملف PC مستقل؛ لا تطبق إعدادات اللمس تلقائياً",
  "محاكي آخر":"ملف عام قابل للتعديل مع تحديد اسم المحاكي"
 };
 const text=`HEADSHOT SENSI MAX / KAKASHI TVS1 — MASTER PROJECT SPECIFICATION — V10.1\nالنسخة المطلوبة: حذف التصويت بالكامل؛ زر نسخ المواصفات متاح من الشاشة الرئيسية.\nالاسم الصحيح: KAKASHI TVS1\nالهدف: أداة مساعدة لمعايرة حساسية Free Fire وإخراج مجموعة واحدة سريعة وواضحة لكل جهاز، وليست أداة تضمن الهيدشوت أو تعدل ملفات اللعبة.\nالحالة الحالية: نسخة HTML/JavaScript تجريبية؛ لا تُعتبر APK أصلية أو اختباراً داخل اللعبة إلا بعد بناء APK واختباره فعلياً.\n\n1) الهوية والواجهة\n- Android APK قابلة للتثبيت؛ لا تكتفِ بصفحة متصفح عند الإصدار النهائي.\n- مظهر Gamer Dark Neon Red: خلفية داكنة وإضاءة حمراء وكتابة واضحة، مع دعم الإنجليزية لتفادي ظهور العربية على شكل ???? في WebView.\n- الاسم الظاهر دائماً KAKASHI TVS1؛ package name المقصود com.app.kakashitvs1macro؛ versionName MA1.0؛ versionCode 1.\n- صفحات Next/Back واضحة؛ لا حذف للمحتوى أو قاعدة الأجهزة عند تحسين الأداء.\n- إزالة نظام التصويت بالكامل من التطبيق.\n- زر نسخ مواصفات المشروع الكاملة متاح من الشاشة الرئيسية، بالإضافة إلى زر نسخ إعدادات الحساسية الناتجة. لا يوجد أي نظام تصويت في التطبيق.\n\n2) مسار الاستخدام والبيانات المطلوبة\n- تصنيف الأجهزة إلى اقتصادي/ضعيف، متوسط، قوي/رائد، مع اعتبار حجم الشاشة صغيراً أو كبيراً، ومواصفات الأداء الفعلية عند توافرها بدلاً من الاعتماد على الاسم وحده.\n- اختيار نوع الجهاز: هاتف Android أو منصة PC/محاكي/جهاز ألعاب محمول.\n- فحص ذكي عند توفر معلومات موثوقة، وعرض اسم الجهاز المكتشف مع تأكيد المستخدم؛ إذا لم يسمح المتصفح بمعرفة الطراز بدقة يجب طلب اختياره يدوياً وعدم ادعاء كشف غير صحيح.\n- اختيار الشركة والطراز الدقيق من قاعدة الأجهزة، مع إمكانية إضافة جهاز غير موجود.\n- هاتف: اسم الطراز؛ DPI الفعلي إن كان معروفاً؛ مؤشر سرعة المؤشر إن كان متاحاً؛ عدد الأصابع 2 أو 3 أو 4 أو 5؛ نمط الحساسية سريع/متوسط/بطيء؛ معدل الإطارات/الأداء إن أمكن؛ حجم زر الإطلاق وHUD اختياريان. لا تدّع أن DPI أو مؤشر السرعة مقروءان تلقائياً إن لم تسمح المنصة بذلك.\n- PC: نوع المحاكي أو منصة التشغيل؛ طراز الكمبيوتر/الجهاز؛ DPI الماوس؛ polling rate؛ حساسية التصويب داخل المحاكي/اللعبة؛ طريقة الإدخال/التحكم ومعدل الإطارات إن توفرت.\n- إظهار مجموعة واحدة من القيم النهائية فوراً: General، Red Dot، 2x Scope، 4x Scope، Sniper، Free Look، Fire Button Size، مع زر نسخ وإعادة المعايرة.\n\n3) قواعد السرعة المطلوبة\n- سريع: General من 171 إلى 195؛ أعلى بوضوح من المتوسط ومناسب لسحب أسرع مع تقليل تجاوز الرأس قدر الإمكان.\n- متوسط: General من 150 إلى 170؛ متوازن.\n- بطيء: General من 125 إلى 149؛ أهدأ للتحكم، وليس من المفترض أن يكون سيئاً تلقائياً.\n- لا يكفي تغيير General فقط؛ اضبط Red Dot و2x و4x وSniper وFree Look وفق نمط الجهاز والسرعة. حافظ على حدود اللعبة 0–200 حيث تنطبق، وعلى حدود منطقية لحجم زر الإطلاق.\n- لا تضمن 90% أو 95% هيدشوت. تُعتبر هذه أهدافاً تجريبية لا تتحقق إلا بقياس حقيقي؛ تجنب اختلاق دقة أو نتائج.\n- نتائج المستخدم الحالية بالترتيب الثابت: 1 نسر الصحراء، 2 النقّار، 3 UMP.\n- تجارب المستخدم السابقة: في السريع نسر الصحراء 88–90% هيدشوت، النقّار 75–80%، UMP قرابة 60%. في المتوسط نسر الصحراء 85–92%، النقّار 80–85%، UMP 45–50%. هذه تقديرات المستخدم وليست اختبارات آلية. الأصفر يعني إصابة غير رأس بحسب وصف المستخدم؛ والطيران يعني تجاوز التصويب فوق الرأس.\n- الاختبار لا يتطلب نسباً دقيقة: المستخدم يستطيع وصف النتيجة (ممتاز/جيد/متوسط/سيئ) وإضافة اتجاه السحب (تحت الرأس/على الرأس/تجاوز الرأس) في المحادثة؛ لا تعِد نظام التصويت داخل التطبيق.\n\n4) دعم الكمبيوتر والمحاكيات\n${Object.entries(pcProfiles).map(([k,v])=>'- '+k+': '+v).join('\n')}\n- دعم مسارات منفصلة للأنظمة: Windows PC المكتبي، Gaming Laptop، Laptop اقتصادي، Mini PC، أجهزة All-in-One، أجهزة Mac عند دعم اللعبة/المحاكي، وSteamOS/Linux حيثما يتوفر توافق فعلي.\n- دعم معالجات Intel وAMD، وبطاقات الرسوم NVIDIA وAMD وIntel، والذاكرة RAM، ودقة الشاشة، ومعدل الإطارات؛ هذه مواصفات لتقدير الأداء وليست بديلاً عن DPI الماوس وحساسية المحاكي.\n- دعم مستويات الأجهزة من منخفضة المواصفات إلى متوسطة وعالية وFlagship، وأحجام الشاشات الصغيرة والكبيرة، مع عدم خلط دقة الشاشة مع DPI الماوس.\n- لا تخلط إعدادات الماوس/المحاكي مع إعدادات اللمس في الهاتف.\n- DPI الماوس وpolling rate وحساسية المحاكي عوامل إدخال؛ لا يمكن قراءتها تلقائياً من صفحة HTML عادية.\n- تضمين ملفات منفصلة أو مسارات حساب مستقلة لكل محاكي مع نتائج فورية.\n\n5) قاعدة الطرازات الموجودة في هذه النسخة (القائمة أدناه هي كل الأسماء المضمّنة فعلياً في قاعدة HTML الحالية؛ ليست كل جهاز صُنع في العالم. الأسماء الموسومة verify model غير مؤكدة وتحتاج إلى تحقق قبل نشرها).\n${deviceLines}\n\n6) معلومات الحساب والخصوصية\n- اسم اللاعب، معرف الحساب، رمز اختياري، عدد الأصابع، السرعة، الطراز وبيانات الحساسية.\n- لا تطلب كلمة مرور اللعبة أو بيانات دخول حساسة. وضّح ما يُحفظ محلياً وما لا يُرسل إلى خادم.\n- بيانات الحساب غير ضرورية لحساب الحساسية؛ اجعلها اختيارية ولا تجعلها تؤثر في المعادلة دون سبب موثق.\n\n7) الأخطاء والمشكلات السابقة التي يجب عدم تكرارها\n- ظهور نتائج الحساسية ببطء أو الانتظار عند عبارة تحليل 12 ملفاً؛ الحساب يجب أن يكون فورياً ومحلياً بلا انتظار وهمي.\n- وضع سريع لا يشعر المستخدم بأنه سريع، ومتوسط وبطيء متقاربان؛ يجب أن تكون الفروق الرقمية والسلوكية واضحة.\n- قيم مرتفعة قد تؤدي إلى تجاوز الرأس؛ رفع الحساسية وحده لا يضمن هيدشوت أعلى.\n- بعض الأسلحة تحسنت وأخرى تراجعت؛ لا تضبط القيم على أساس سلاح واحد فقط، واحتفظ بتجارب نسر الصحراء والنقّار وUMP بالترتيب الثابت.\n- المتصفح لا يكشف دائماً طراز الهاتف الدقيق أو DPI أو مؤشر السرعة؛ اعرض حدود الكشف واسمح بالتأكيد/الاختيار اليدوي.\n- حدث سابقاً خطأ فتح داخل WebView بعنوان appassets.androidplatform.net/web/index.htm وERR_HTTP_RESPONSE_CODE_FAILURE؛ يجب اختبار مسارات الملفات والأصول داخل APK فعلياً.\n- أزيل إعلان وهمي سابقاً؛ أي مكان إعلاني يجب أن يكون تكاملاً حقيقياً مرخصاً بعد تجهيز SDK، لا مؤقتاً مزيفاً. النسخة HTML وحدها ليست تكاملاً فعلياً مع AdMob.\n- تجنب الرموز التعبيرية في النصوص التي سببت ظهور ???? في واجهة Android؛ اختبر العربية والخطوط والترميز، واستخدم الإنجليزية عند الحاجة.\n- قاعدة الطرازات السابقة تضم أسماء محتملة/مستقبلية موسومة verify model؛ لا تعرضها كأجهزة مؤكدة قبل التحقق، واحذف التكرارات وصحح أسماء الطرازات.\n- لا يُدّعى أن فحص JavaScript يعني اختبار التطبيق داخل Free Fire أو أن APK بُنيت بنجاح.\n\n8) شروط الجودة قبل تسمية الإصدار نهائياً\n- فحص syntax لملفات JavaScript وHTML؛ اختبار جميع أزرار Next/Back والاختيار اليدوي والفحص الذكي والنسخ وإعادة الضبط.\n- اختبار أحجام الشاشات والاتجاه RTL/LTR وعدم ظهور النصوص مقطوعة.\n- اختبار كل سرعة مع DPI منخفض/متوسط/مرتفع وعدد أصابع مختلف، والتأكد من أن النتائج تختلف منطقياً لا عشوائياً.\n- اختبار الأجهزة الضعيفة والقوية؛ لا تعتمد فقط على كلمات اسم الجهاز لتقدير الأداء، بل استخدم مواصفات موثوقة عندما تتوفر، وإلا استخدم إعداداً افتراضياً قابلاً للضبط.\n- اختبار فعلي داخل Free Fire مع تسجيل السلاح والسرعة والمسافة ومعدل الإطارات واتجاه السحب والنتيجة؛ لا تعدّل المعادلة اعتماداً على الانطباع غير المنظم فقط.\n- بناء APK مستقل وتثبيته من Chrome/مدير الملفات، ثم التحقق من عدم ظهور ERR_HTTP_RESPONSE_CODE_FAILURE وعدم فقد البيانات.\n- الإبقاء على قاعدة الأجهزة والملفات والخصائص الموجودة عند تحسين أي جزء.\n\n9) ملاحظات تقنية صريحة\n- قاعدة الطرازات الحالية موزعة على الشركات/الفئات المدرجة في القسم 5، وتشمل هواتف Android وiPhone وأجهزة handheld. iPhone لا يعني أن نسخة APK تعمل على iOS؛ يتطلب إصدار iOS مستقلاً.\n- دعم PC في HTML يعني إعدادات/حسابات للماوس والمحاكيات؛ لا يعني أن نسخة Android نفسها تعمل كتطبيق PC أصلي.\n- الحساسية تقديرية وتختلف حسب تحديث اللعبة، FPS، إعدادات HUD، السلاح، المسافة وطريقة السحب. لا يمكن ضمان نسبة هيدشوت محددة.\n- المطلوب النهائي: KAKASHI TVS1 سريع، واضح، صادق في حدود الكشف، واسع قاعدة الأجهزة، يدعم الهاتف والكمبيوتر بصورة منفصلة، ويظهر مجموعة حساسية واحدة قابلة للنسخ فوراً.\n`;
 if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(()=>alert('تم نسخ مواصفات المشروع الكاملة')).catch(()=>fallbackCopy(text))}else fallbackCopy(text)
}
function copySettings(){
 const text=`KAKASHI TVS1
General: ${document.getElementById('resGeneral').textContent}
Red Dot: ${document.getElementById('resRedDot').textContent}
2X Scope: ${document.getElementById('res2x').textContent}
4X Scope: ${document.getElementById('res4x').textContent}
Sniper: ${document.getElementById('resSniper').textContent}
Free Look: ${document.getElementById('resFreeLook').textContent}
Fire Button: ${document.getElementById('fb').textContent}`;
 if(navigator.clipboard && navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(()=>alert('تم نسخ الإعدادات')).catch(()=>fallbackCopy(text))}else{fallbackCopy(text)}
}
// Ad mediation adapter: real ads require an Android/iOS native bridge backed by AppLovin MAX SDK.
// Expected bridge: window.DominatorAdBridge.showBanner({containerId, placement}),
// .showInterstitial({placement}), .showRewardedAd({placement}) -> Promise<boolean | {rewarded:boolean}>.
const DOMINATOR_AD_STATE_KEY='dominator_v17_rewarded_feedback_state';
function getAdBridge(){return window.DominatorAdBridge||null}
function showBanner(containerId, placement){
 const slot=document.getElementById(containerId); if(!slot)return false;
 const bridge=getAdBridge();
 if(!bridge||typeof bridge.showBanner!=='function'){slot.dataset.adState='unconfigured';return false;}
 try{const result=bridge.showBanner({containerId,placement});if(result&&typeof result.then==='function')result.then(ok=>{slot.dataset.adState=ok?'loaded':'unavailable'}).catch(()=>{slot.dataset.adState='unavailable'});else slot.dataset.adState=result?'loaded':'unavailable';return true;}catch(e){slot.dataset.adState='unavailable';return false;}
}
async function showInterstitial(placement){
 const bridge=getAdBridge();if(!bridge||typeof bridge.showInterstitial!=='function')return false;
 try{return await bridge.showInterstitial({placement})===true;}catch(e){console.warn('Interstitial unavailable',e);return false;}
}
async function showRewardedAd(placement){
 const bridge=getAdBridge();if(!bridge||typeof bridge.showRewardedAd!=='function')return false;
 try{const result=await bridge.showRewardedAd({placement});return result===true||!!(result&&result.rewarded===true);}catch(e){console.warn('Rewarded ad failed or was closed',e);return false;}
}
function readRewardState(){try{return JSON.parse(localStorage.getItem(DOMINATOR_AD_STATE_KEY)||'{"unlocked":{},"adjustments":0}')}catch(e){return {unlocked:{},adjustments:0}}}
function saveRewardState(state){try{localStorage.setItem(DOMINATOR_AD_STATE_KEY,JSON.stringify(state));return true}catch(e){return false}}
async function requestRewardedFeedback(kind){
 if(!['overshoot','under','body'].includes(kind))return;
 const note=document.getElementById('feedbackNote');
 const state=readRewardState();state.unlocked=state.unlocked||{};
 if(state.unlocked[kind]===true){applyFeedback(kind);if(note)note.textContent='هذا الخيار مفتوح بالفعل. تم تطبيق التعديل وحفظه محليًا دون إعلان جديد.';refreshFeedbackButtons();return;}
 if(note)note.textContent='افتح هذا الخيار مرة واحدة بإكمال الفيديو التجريبي لمدة 10 ثوانٍ.';
 const ok=await showRewardedAd('feedback_'+kind);
 if(!ok){if(note)note.textContent='لم يكتمل الفيديو التجريبي؛ بقي الخيار مقفلًا ولم تتغير الحساسية.';return;}
 state.unlocked[kind]=true;state.adjustments=(Number(state.adjustments)||0)+1;state.lastKind=kind;state.lastUpdated=new Date().toISOString();
 if(!saveRewardState(state)){if(note)note.textContent='تعذر حفظ حالة الفتح في التخزين المحلي؛ لم يتم اعتماد فتح دائم.';return;}
 applyFeedback(kind);refreshFeedbackButtons();if(note)note.textContent='تم فتح هذا الخيار وحفظه. لن يطلب هذا الخيار إعلانًا مرة أخرى إلا بعد الضغط على إعادة المعايرة.';
}
function refreshFeedbackButtons(){
 const state=readRewardState();state.unlocked=state.unlocked||{};
 const map=[['overshoot','السحب يتجاوز الرأس — خفّض الحساسية'],['under','السحب يتوقف تحت الرأس — ارفع الحساسية قليلًا'],['body','يصيب الجسم غالبًا — ارفع General وRed Dot قليلًا']];
 document.querySelectorAll('button[onclick^="requestRewardedFeedback("]').forEach((button)=>{
   const match=button.getAttribute('onclick').match(/requestRewardedFeedback\('([^']+)'\)/);if(!match)return;const kind=match[1];
   const item=map.find(x=>x[0]===kind);if(!item)return;
   button.textContent=(state.unlocked[kind]?'[مفتوح ومحفوظ] ':'[مقفل - فيديو 10 ثوانٍ] ')+item[1];
 });
}
function resetCalibrationState(){try{localStorage.removeItem(DOMINATOR_AD_STATE_KEY);localStorage.removeItem('dominator_v17_feedback_values');}catch(e){}location.reload()}
let DOMINATOR_FEEDBACK_STATE={lastKind:null,repeatCount:0,adjustments:0};
function applyFeedback(kind){
 const ids=['resGeneral','resRedDot','res2x','res4x','resSniper','resFreeLook'];
 if(!['overshoot','under','body','perfect'].includes(kind)) return;
 if(kind==='perfect'){
   const note=document.getElementById('feedbackNote');
   if(note) note.textContent='سجّل هذه المجموعة كأفضل نتيجة حالية؛ لا يمكن استنتاج نسبة إصابة عامة من ضغطة واحدة.';
   DOMINATOR_FEEDBACK_STATE.lastKind='perfect';DOMINATOR_FEEDBACK_STATE.repeatCount=0;
   return;
 }
 DOMINATOR_FEEDBACK_STATE.repeatCount=DOMINATOR_FEEDBACK_STATE.lastKind===kind?DOMINATOR_FEEDBACK_STATE.repeatCount+1:1;
 DOMINATOR_FEEDBACK_STATE.lastKind=kind;
 DOMINATOR_FEEDBACK_STATE.adjustments++;
 // Small diminishing steps reduce oscillation. Clamp General to the selected speed band.
 const step=DOMINATOR_FEEDBACK_STATE.repeatCount===1?2:1;
 const sign=kind==='overshoot'?-1:1;
 const changes=kind==='overshoot'?[-step,-step,-Math.max(1,step-1),-Math.max(1,step-1),-1,0]:kind==='under'?[step,step,Math.max(1,step-1),Math.max(1,step-1),1,0]:[step,step,1,0,0,0];
 const speed=document.getElementById('speedPattern');
 const pattern=speed&&speed.value?speed.value:(typeof speedKey!=='undefined'?speedKey:'medium');
 const bands={fast:[171,195],medium:[150,170],slow:[125,149]};
 const band=bands[pattern]||bands.medium;
 ids.forEach((id,i)=>{
   const e=document.getElementById(id);if(!e)return;
   const n=Number(e.textContent);if(!Number.isFinite(n))return;
   let next=n+changes[i];
   if(i===0) next=clamp(next,band[0],band[1]); else next=clamp(next,0,200);
   e.textContent=String(Math.round(next));
 });
 const note=document.getElementById('feedbackNote');
 if(note) note.textContent=(kind==='overshoot'?'تم خفض الحساسية بخطوة صغيرة لتقليل التجاوز.':kind==='under'?'تم رفع الحساسية بخطوة صغيرة لمعالجة التوقف أسفل الرأس.':'تم رفع General وRed Dot كتجربة محدودة.')+' التعديل '+DOMINATOR_FEEDBACK_STATE.adjustments+'؛ ثبّت بقية الظروف وأعد مجموعة الاختبار قبل تعديل آخر.';
 try{localStorage.setItem('dominator_v17_feedback_values',JSON.stringify(ids.reduce((o,id)=>{const e=document.getElementById(id);if(e)o[id]=e.textContent;return o;},{})));}catch(e){}
}
function fallbackCopy(text){const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');alert('تم نسخ الإعدادات')}catch(e){alert('تعذر النسخ تلقائيًا؛ حدد النص وانسخه يدويًا')}ta.remove();
}
/* V17 MOCK ONLY: browser-side simulation; NOT a real ad or Android SDK. */
(function installDominatorMockBridge(){
 let panel,activeTimer=null;
 function ensurePanel(){
  if(panel)return panel;
  panel=document.createElement('div');panel.id='dominatorMockAdPanel';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-live','polite');
  panel.innerHTML='<div class="mock-ad-card"><div class="mock-ad-kicker">MOCK ADS · TEST ONLY</div><div id="dominatorMockAdTitle" class="mock-ad-title">محاكاة إعلان تجريبي</div><div id="dominatorMockAdMessage" class="mock-ad-message">هذه محاكاة محلية وليست إعلانًا حقيقيًا.</div><div class="mock-ad-progress"><i id="dominatorMockAdProgress"></i></div><div id="dominatorMockAdCountdown" class="mock-ad-countdown"></div><button type="button" id="dominatorMockAdAction" class="mock-ad-action" hidden>مشاهدة الفيديو التجريبي (10 ثوانٍ)</button><button type="button" id="dominatorMockAdClose" class="btn secondary mock-ad-close" hidden>إغلاق</button></div>';
  document.body.appendChild(panel);panel.querySelector('#dominatorMockAdClose').addEventListener('click',()=>panel.classList.remove('show'));return panel;
 }
 function banner(containerId){
  let strip=document.getElementById('dominatorMockBanner');
  if(!strip){strip=document.createElement('div');strip.id='dominatorMockBanner';strip.textContent='[إعلان بنر تجريبي نشط]';document.body.appendChild(strip)}
  strip.classList.add('active');
  const slot=document.getElementById(containerId);if(slot){slot.dataset.adState='loaded';slot.innerHTML='<div class="ad-label">[إعلان بنر تجريبي نشط]</div>'}
  return true;
 }
 function interstitial(placement){
  const p=ensurePanel(),title=p.querySelector('#dominatorMockAdTitle'),msg=p.querySelector('#dominatorMockAdMessage'),bar=p.querySelector('#dominatorMockAdProgress'),count=p.querySelector('#dominatorMockAdCountdown'),action=p.querySelector('#dominatorMockAdAction'),close=p.querySelector('#dominatorMockAdClose');
  if(activeTimer)clearInterval(activeTimer);p.classList.add('show');action.hidden=true;close.hidden=true;bar.style.width='0%';title.textContent='إعلان بيني تجريبي';msg.textContent='محاكاة لمدة 3 ثوانٍ — الموضع: '+placement+'. لا يتم تحميل إعلان حقيقي.';
  return new Promise(resolve=>{let remaining=3;count.textContent='الوقت المتبقي: '+remaining+' ث';activeTimer=setInterval(()=>{remaining--;count.textContent=remaining>0?'الوقت المتبقي: '+remaining+' ث':'اكتملت المحاكاة';bar.style.width=((3-remaining)/3*100)+'%';if(remaining<=0){clearInterval(activeTimer);activeTimer=null;title.textContent='اكتملت محاكاة الإعلان';msg.textContent='سيواصل التطبيق إلى الخطوة التالية.';close.hidden=false;setTimeout(()=>{p.classList.remove('show');resolve(true)},350)}},1000)});
 }
 function rewarded(placement){
  const p=ensurePanel(),title=p.querySelector('#dominatorMockAdTitle'),msg=p.querySelector('#dominatorMockAdMessage'),bar=p.querySelector('#dominatorMockAdProgress'),count=p.querySelector('#dominatorMockAdCountdown'),action=p.querySelector('#dominatorMockAdAction'),close=p.querySelector('#dominatorMockAdClose');
  if(activeTimer)clearInterval(activeTimer);p.classList.add('show');bar.style.width='0%';count.textContent='';close.hidden=true;action.hidden=false;action.disabled=false;title.textContent='[شاهد هذا الفيديو لفتح الحساسية VIP]';msg.textContent='الموضع: '+placement+'. اضغط على الزر لبدء فيديو محاكاة مدته 10 ثوانٍ. هذه ليست شبكة إعلانية حقيقية.';
  return new Promise(resolve=>{let settled=false;const finish=(ok)=>{if(settled)return;settled=true;if(activeTimer)clearInterval(activeTimer);activeTimer=null;action.hidden=true;close.hidden=false;resolve(ok?{rewarded:true}:{rewarded:false})};
   action.onclick=()=>{action.disabled=true;let remaining=10;count.textContent='الوقت المتبقي: '+remaining+' ث';msg.textContent='جاري تشغيل الفيديو التجريبي…';activeTimer=setInterval(()=>{remaining--;count.textContent=remaining>0?'الوقت المتبقي: '+remaining+' ث':'اكتمل الفيديو';bar.style.width=((10-remaining)/10*100)+'%';if(remaining<=0){clearInterval(activeTimer);activeTimer=null;title.textContent='اكتمل الفيديو التجريبي بنجاح';msg.textContent='تم إرجاع rewarded: true. سيتم فتح هذا الخيار وحفظه محليًا.';finish(true);}},1000)};
   close.onclick=()=>{p.classList.remove('show');finish(false)};
  });
 }
 window.DominatorAdBridge={mock:true,showBanner({containerId,placement}={}){return banner(containerId,placement)},showInterstitial({placement}={}){return interstitial(placement||'unspecified')},showRewardedAd({placement}={}){return rewarded(placement||'unspecified')}};
 window.addEventListener('DOMContentLoaded',()=>{const badge=document.createElement('div');badge.className='mock-mode-badge';badge.textContent='MOCK ADS: ON — TEST ONLY';badge.title='محاكاة محلية فقط؛ ليست إعلانات حقيقية ولا تحقق أرباحًا';document.body.appendChild(badge);refreshFeedbackButtons();});
})();

document.addEventListener('DOMContentLoaded',()=>{showBanner('banner-home','home');showBanner('banner-device','device');refreshFeedbackButtons()});
