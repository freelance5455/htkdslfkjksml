/* FN STATS — demo app. All stats are DEMO DATA — NOT OFFICIAL. */
"use strict";

/* ========== 1. PLAYER DATA (editable) ==========
   Each entry: [name, FNCS wins, PR points, earnings USD, optional {qual: FNCS qualifier count, div: Div Cup wins}]. Rank = position in this list (1-201).
   An optional 5th item {region,team,qual,divcup,verified} adds pro details. Values are exactly as supplied. Duplicate names are intentionally preserved. */
const PLAYER_DATA = [
["Peterbot",7,125400,850000],["Mero",6,118200,720000],["EpikWhale",7,112800,900000],["Bugha",3,109500,3500000],["Arkhram",6,105300,680000],
["Pollo",4,102700,550000],["Acorn",5,99800,600000],
["3xzzy",0,98549,108750,{region:"NA East",team:"7VEN Esports",qual:6,divcup:11,verified:true}],["Tayson",5,97400,520000],["Queasy",4,95100,490000],["Veno",4,93600,460000],
["Clix",1,91200,650000],["Kami",3,89700,430000],["Setty",3,87500,410000],["Rehx",5,85300,470000],["K1nG",6,83800,440000],
["Phzin",6,82100,420000],["Yuma",5,80400,390000],["Cold",4,78900,370000],["Merstach",3,77300,350000],["SwizzY",5,75600,340000],
["Mongraal",0,74200,300000],["MrSavage",0,72800,290000],["Aqua",2,71400,320000],["JannisZ",3,70100,280000],["Th0masHD",2,68700,270000],
["Cooper",1,67400,260000],["Commandment",2,66100,250000],["Cented",2,64800,240000],["Edgey",2,63500,230000],["Khanada",0,62200,220000],
["Zayt",2,61000,240000],["Saf",2,59800,230000],["Stretch",1,58600,210000],["Reverse2k",2,57400,200000],["Deyy",2,56200,190000],
["Jamper",2,55100,185000],["Rise",2,54000,180000],["TaySon",5,52900,175000],["Andilex",1,51800,170000],["Jynx",3,50700,165000],
["Muz",3,49600,160000],["Volx",3,48500,155000],["Looter",3,47400,150000],["Jace",2,46300,145000],["Dukez",2,45200,140000],
["FKS",4,44100,135000],["Koyota",4,43000,130000],["Alex",5,42000,125000],["Cadu",4,41000,120000],["Anon",3,40000,115000],
["Bugha",3,39000,3500000],["Mero",6,38500,720000],["Peterbot",7,38000,850000],["EpikWhale",7,37500,900000],["Arkhram",6,37000,680000],
["Rehx",5,36500,470000],["TaySon",5,36000,520000],["Acorn",5,35500,600000],["Veno",4,35000,460000],["Queasy",4,34500,490000],
["Kami",3,34000,430000],["Setty",3,33500,410000],["Pollo",4,33000,550000],["K1nG",6,32500,440000],["Phzin",6,32000,420000],
["Yuma",5,31500,390000],["Cold",4,31000,370000],["Clix",1,30500,650000],["Merstach",3,30000,350000],["SwizzY",5,29500,340000],
["Th0masHD",2,29000,270000],["JannisZ",3,28500,280000],["Aqua",2,28000,320000],["MrSavage",0,27500,290000],["Mongraal",0,27000,300000],
["Cooper",1,26500,260000],["Commandment",2,26000,250000],["Cented",2,25500,240000],["Edgey",2,25000,230000],["Khanada",0,24500,220000],
["Zayt",2,24000,240000],["Saf",2,23500,230000],["Stretch",1,23000,210000],["Reverse2k",2,22500,200000],["Deyy",2,22000,190000],
["Jamper",2,21500,185000],["Rise",2,21000,180000],["Andilex",1,20500,170000],["Jynx",3,20000,165000],["Muz",3,19500,160000],
["Volx",3,19000,155000],["Looter",3,18500,150000],["Jace",2,18000,145000],["Dukez",2,17500,140000],["FKS",4,17000,135000],
["Koyota",4,16500,130000],["Alex",5,16000,125000],["Cadu",4,15500,120000],["Anon",3,15000,115000],["Bugha",3,14500,3500000],
["Tschinken",1,14000,100000],["Stompy",1,13800,95000],["ZexRow",1,13600,90000],["MackWood",1,13400,85000],["Calculator",1,13200,80000],
["Jayrosez",1,13000,75000],["Dog",1,12800,70000],["Buubee",1,12600,65000],["Leleo",2,12400,90000],["Kurtz",2,12200,85000],
["Wisheydp",1,12000,80000],["Takamura",1,11800,70000],["RizArt",1,11600,65000],["Maufin",1,11400,60000],["FHD",1,11200,55000],
["NM7",1,11000,50000],["Yonx",1,10800,45000],["Hillo",1,10600,50000],["Gancho",1,10400,45000],["Minkin",1,10200,40000],
["Vato",0,10000,70000],["Skite",0,9800,65000],["Kinstaar",0,9600,60000],["Nayte",0,9400,55000],["Rezon ay",1,9200,50000],
["Pinq",1,9000,45000],["Flikk",1,8800,40000],["Chapix",1,8600,35000],["Vortexers",0,8400,30000],["Eomzo",0,8200,30000],
["Tahi",1,8000,35000],["Worthy",1,7800,30000],["Basil",0,7600,25000],["Sync",0,7400,25000],["Link",0,7200,20000],
["Frosty",1,7000,30000],["Pulga",1,6800,25000],["Seeyun",2,6600,40000],["Fazer",3,6400,35000],["Kalgamer",3,6200,30000],
["7man",3,6000,30000],["Hero",2,5800,25000],["Vanyak3kk",0,5600,20000],["Tinka",1,5400,20000],["Resignz",1,5200,18000],
["Howly",1,5000,18000],["1Lusha",1,4800,15000],["Encrypted",0,4600,15000],["Rapid",0,4400,15000],["Sky",1,4200,15000],
["Scroll",1,4000,15000],["Tjino",0,3900,12000],["PabloWingu",0,3800,12000],["Ritual",0,3700,12000],["Ajerss",0,3600,12000],
["Chap",0,3500,20000],["Flickzy",0,3400,10000],["Avery",0,3300,10000],["Nosh",0,3200,10000],["Slackes",1,3100,20000],
["Furious",0,3000,10000],["Bizzle",0,2900,50000],["Nate Hill",0,2800,30000],["Funk",0,2700,10000],["Psalm",0,2600,40000],
["Kreo",0,2500,15000],["UnknownxArmy",0,2400,15000],["Wolfiez",0,2300,20000],["Benjyfishy",0,2200,50000],["Tayson",5,2100,520000],
["Merijn",0,2000,10000],["Chico",0,1950,10000],["Veno",4,1900,460000],["Setty",3,1850,410000],["Kami",3,1800,430000],
["Queasy",4,1750,490000],["Pollo",4,1700,550000],["Acorn",5,1650,600000],["Cold",4,1600,370000],["Yuma",5,1550,390000],
["K1nG",6,1500,440000],["Phzin",6,1450,420000],["Cadu",4,1400,120000],["Alex",5,1350,125000],["JannisZ",3,1300,280000],
["Th0masHD",2,1250,270000],["Aqua",2,1200,320000],["MrSavage",0,1150,290000],["Mongraal",0,1100,300000],["Clix",1,1050,650000],
["Cooper",1,1000,260000],["Commandment",2,950,250000],["Cented",2,900,240000],["Edgey",2,850,230000],["Khanada",0,800,220000],
["Zayt",2,750,240000],["Saf",2,700,230000],["Stretch",1,650,210000],["Reverse2k",2,600,200000],["Deyy",2,550,190000]
];

const REGIONS = ["NA Central","NA East","NA West","Europe","Brazil","Asia","Middle East","Oceania"];
const PER_PAGE = 25;

/* ========== 2. HELPERS ========== */
// Seeded PRNG so generated demo data is consistent between visits
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function rng(seed){let a=seed>>>0;return function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
const fmtPR = n => n.toLocaleString("en-US");
const fmtUSD = n => "$" + n.toLocaleString("en-US");
const esc = s => String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const $ = (s,r=document)=>r.querySelector(s);
const initials = n => esc(n.replace(/[^A-Za-z0-9 ]/g,"").slice(0,2).toUpperCase()||"?");

/* Build player objects. Region is a DEMO region assigned from the name (same name = same region). */
// Org/team tags by player name (applies to every entry of that name)
const TEAMS = {"Peterbot":"Falcons","Clix":"XSET"};
// Extra history entries by player name
const EXTRA_HISTORY = {"3xzzy":["FNC Summit LAN Practice"]};
const PLAYERS = PLAYER_DATA.map((d,i)=>({
  rank:i+1, name:d[0], wins:d[1], pr:d[2], earnings:d[3],
  region: (d[4]&&d[4].region)||REGIONS[hashStr(d[0])%REGIONS.length],
  team:(d[4]&&d[4].team)||TEAMS[d[0]]||"", qual:(d[4]&&d[4].qual)||0, divcup:(d[4]&&d[4].divcup)||0,
  verified:!!(d[4]&&d[4].verified)
}));
/* Esports orgs (editable). Maps player name -> org. Rosters change often: edit freely. */
const ORGS = {
  "Falcons":{ full:"Team Falcons", players:["Peterbot","Clix"] },
  "XSET":{ full:"XSET", players:["Veno"] },
  "7VEN Esports":{ full:"7VEN Esports", players:["3xzzy"] }
};
PLAYERS.forEach(p=>{ if(!p.team){ for(const [org,o] of Object.entries(ORGS)){ if(o.players.includes(p.name)) p.team=org; } } });
// Cosmetic demo "Verified Pro" mark: custom-flagged players, or any player ranked in the demo top 25
const isVerified = p => p.verified || p.rank<=25;

/* ========== 3. DEMO TOURNAMENTS ========== */
const TOURNEY_NAMES = ["Neon Cup","Storm Surge Open","Victory Royale Invitational","Zero Build Showdown","Midnight Clash","Apex Series","Frostbite Finals","Skyfall Championship","Turbo Rush Cup","Emerald Gauntlet","Last Circle Classic","Global Demo Championship"];
const FORMATS = ["Solo","Duo","Trio","Squad"];
const PRIZES = [25000,50000,75000,100000,150000,250000,500000,1000000];
const TOURNAMENTS = TOURNEY_NAMES.map((name,i)=>{
  const r = rng(hashStr(name));
  const region = i===11 ? "Global" : REGIONS[Math.floor(r()*REGIONS.length)];
  const d = new Date(2026, 9-i, 1+Math.floor(r()*27)); // monthly, newest first (Oct 2026 backwards)
  // pick 10 distinct top-100 player entries for placements
  const used=new Set(), placements=[];
  while(placements.length<10){
    const p = PLAYERS[Math.floor(r()*100)];
    if(!used.has(p.name)){used.add(p.name);placements.push(p);}
  }
  return {id:i,name:name,region,format:FORMATS[Math.floor(r()*4)],prize:PRIZES[Math.floor(r()*PRIZES.length)],date:d,winner:placements[0].name,placements,global:i===11};
});

/* Per-player demo results: pulled from tournaments they placed in + generated filler, deterministic */
function playerResults(p){
  const r = rng(hashStr(p.name)+p.rank);
  const skill = Math.max(0.05, Math.min(1, p.pr/125400)); // higher PR = better placements
  return TOURNAMENTS.slice(0,8).map(t=>{
    const found = t.placements.findIndex(x=>x.name===p.name);
    const place = found>=0 ? found+1 : Math.max(1, Math.round(1 + (1-skill)*80*r() + r()*10));
    return {t, place, points:Math.max(0,Math.round((101-place)*(0.5+skill)))};
  });
}

/* FNCS history: one "FNCS Champion" line per win, seasons picked consistently from the name */
const SEASONS=["Chapter 3 Season 1","Chapter 3 Season 2","Chapter 3 Season 3","Chapter 3 Season 4","Chapter 4 Season 1","Chapter 4 Season 2","Chapter 4 Season 3","Chapter 4 Season 4","Chapter 5 Season 1","Chapter 5 Season 2","Chapter 5 Season 3","Chapter 5 Season 4","Chapter 6 Season 1"];
function fncsHistory(p){
  const r=rng(hashStr(p.name)), pool=SEASONS.slice(), out=[];
  for(let i=0;i<p.wins&&pool.length;i++)out.push({season:pool.splice(Math.floor(r()*pool.length),1)[0],text:"FNCS Champion"});
  out.sort((a,b)=>SEASONS.indexOf(b.season)-SEASONS.indexOf(a.season));
  if(p.divcup)out.unshift({season:"Division Cups",text:p.divcup+"x FNCS Div Cup Champion"});
  if(p.qual)out.unshift({season:"FNCS",text:p.qual+"x FNCS Qualifier"});
  (EXTRA_HISTORY[p.name]||[]).forEach(x=>out.unshift({season:"LAN",text:x}));
  return out;
}

/* Achievements calculated from the demo data */
const BADGE_DEFS = [
  {id:"champ",label:"FNCS Champion",desc:"1+ demo FNCS win",test:p=>p.wins>=1},
  {id:"multi",label:"Multiple FNCS Champion",desc:"3+ demo FNCS wins",test:p=>p.wins>=3},
  {id:"highpr",label:"High PR",desc:"PR of 50,000+",test:p=>p.pr>=50000},
  {id:"top10",label:"Top 10 Ranked",desc:"Rank 1–10",test:p=>p.rank<=10},
  {id:"earn",label:"Earnings Milestone",desc:"$500,000+ demo earnings",test:p=>p.earnings>=500000},
  {id:"verified",label:"Verified Pro (Demo)",desc:"Demo verified-pro mark: demo top 25 or flagged pro",test:p=>isVerified(p),cls:"verified"},
  {id:"qual",label:"FNCS Qualifier",desc:"Has qualified for FNCS (demo)",test:p=>p.qual>0,cls:"pro"},
  {id:"div",label:"Div Cup Champion",desc:"Won a Division Cup (demo)",test:p=>p.divcup>0,cls:"pro"},
  {id:"team",label:"Pro Team Member",desc:"Signed to an org in the demo data",test:p=>!!p.team,cls:"pro"},
  {id:"global",label:"Global Championship Winner",desc:"Won the demo Global Championship",test:p=>TOURNAMENTS.some(t=>t.global&&t.winner===p.name)}
];
const badgesFor = p => BADGE_DEFS.filter(b=>b.test(p));

/* ========== 4. APP STATE ========== */
const app = $("#app");
let lbState = {q:"",region:"",sort:"rank",dir:1,page:1};
let lastListRoute = "#/leaderboard";

/* ========== 5. UI UTILITIES ========== */
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove("show"),2200);}
function loading(then,ms=350){app.innerHTML='<div class="loader" role="status" aria-label="Loading"></div>';setTimeout(then,ms);}
function downloadFile(name,text,type){const b=new Blob([text],{type});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),500);}
function copyText(text){
  const done=()=>toast("Copied to clipboard!");
  if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).then(done,()=>fallback());}else fallback();
  function fallback(){const ta=document.createElement("textarea");ta.value=text;document.body.appendChild(ta);ta.select();try{document.execCommand("copy");done();}catch(e){toast("Copy failed");}ta.remove();}
}

/* Theme */
function setTheme(t){document.documentElement.dataset.theme=t;$("#themeBtn").textContent=t==="dark"?"☾":"☀";try{localStorage.setItem("fn-theme",t);}catch(e){}}
$("#themeBtn").addEventListener("click",()=>setTheme(document.documentElement.dataset.theme==="dark"?"light":"dark"));
try{const s=localStorage.getItem("fn-theme");if(s)setTheme(s);}catch(e){}

/* Mobile menu */
const sidebar=$("#sidebar"), menuBtn=$("#menuBtn");
menuBtn.addEventListener("click",()=>{const o=sidebar.classList.toggle("open");menuBtn.setAttribute("aria-expanded",o);});
sidebar.addEventListener("click",e=>{if(e.target.closest("a")){sidebar.classList.remove("open");menuBtn.setAttribute("aria-expanded","false");}});

/* Reusable player search with dropdown + keyboard navigation */
function searchBox(){
  return `<div class="search-wrap">
    <label for="ps">Search Fortnite Players</label>
    <input id="ps" type="search" placeholder="Type a player name…" autocomplete="off" role="combobox" aria-expanded="false" aria-controls="psList">
    <div id="psList" class="dropdown" role="listbox" hidden></div></div>`;
}
function bindSearch(){
  const inp=$("#ps"), list=$("#psList"); let sel=-1, items=[];
  function render(){
    const q=inp.value.trim().toLowerCase();
    if(!q){list.hidden=true;inp.setAttribute("aria-expanded","false");return;}
    const seen=new Set();
    items=PLAYERS.filter(p=>p.name.toLowerCase().includes(q)&&!seen.has(p.name)&&seen.add(p.name)).slice(0,8);
    sel=-1; list.hidden=false; inp.setAttribute("aria-expanded","true");
    list.innerHTML = items.length
      ? items.map((p,i)=>`<div class="opt" role="option" data-rank="${p.rank}" data-i="${i}"><span>${esc(p.name)}</span><span class="muted">#${p.rank} · ${fmtPR(p.pr)} PR</span></div>`).join("")
      : `<div class="none">No players found for “${esc(inp.value)}”. Try another name!</div>`;
  }
  function mark(){[...list.querySelectorAll(".opt")].forEach((o,i)=>o.classList.toggle("sel",i===sel));}
  inp.addEventListener("input",render);
  inp.addEventListener("keydown",e=>{
    if(e.key==="ArrowDown"){e.preventDefault();sel=Math.min(items.length-1,sel+1);mark();}
    else if(e.key==="ArrowUp"){e.preventDefault();sel=Math.max(0,sel-1);mark();}
    else if(e.key==="Enter"){e.preventDefault();const p=items[sel>=0?sel:0];if(p)location.hash="#/player/"+p.rank;}
    else if(e.key==="Escape"){list.hidden=true;}
  });
  list.addEventListener("click",e=>{const o=e.target.closest(".opt");if(o)location.hash="#/player/"+o.dataset.rank;});
  document.addEventListener("click",e=>{if(!e.target.closest(".search-wrap"))list.hidden=true;},{once:false});
}

/* Table row markup */
function rowHTML(p){
  return `<tr tabindex="0" data-rank="${p.rank}" role="link" aria-label="Open profile for ${esc(p.name)}">
    <td class="rank">#${p.rank}</td><td><span class="avatar">${initials(p.name)}</span>${esc(p.name)}${isVerified(p)?'<span class="vcheck" title="Verified Pro (demo mark)">✓</span>':""}${p.team?`<span class="team-tag">${esc(p.team)}</span>`:""}</td>
    <td class="num-r">${p.wins}</td><td class="num-r">${fmtPR(p.pr)}</td><td class="num-r">${fmtUSD(p.earnings)}</td></tr>`;
}
function bindRows(root){
  root.addEventListener("click",e=>{const r=e.target.closest("tr[data-rank]");if(r)location.hash="#/player/"+r.dataset.rank;});
  root.addEventListener("keydown",e=>{if(e.key==="Enter"){const r=e.target.closest("tr[data-rank]");if(r)location.hash="#/player/"+r.dataset.rank;}});
}
function miniTable(list){
  return `<div class="table-wrap"><table><thead><tr><th>Rank</th><th>Player</th><th class="num-r">FNCS Wins</th><th class="num-r">PR</th><th class="num-r">Earnings</th></tr></thead><tbody>${list.map(rowHTML).join("")}</tbody></table></div>`;
}

/* ========== 6. VIEWS ========== */
function viewHome(){
  const total=PLAYERS.reduce((s,p)=>s+p.earnings,0);
  const champs=new Set(PLAYERS.filter(p=>p.wins>=1).map(p=>p.name)).size;
  const maxPR=Math.max(...PLAYERS.map(p=>p.pr));
  const feat=PLAYERS[0];
  const t3=TOURNAMENTS.slice(0,3);
  app.innerHTML=`
  <div class="hero"><h1>FN <span class="accent">STATS</span></h1><p>Fan-made demo Fortnite competitive stats tracker</p>${searchBox()}</div>
  <section class="grid stats">
    <div class="card stat"><div class="num">${PLAYERS.length}</div><div class="lbl">Demo player entries</div></div>
    <div class="card stat"><div class="num">${champs}</div><div class="lbl">FNCS champions (unique)</div></div>
    <div class="card stat"><div class="num">${fmtUSD(total)}</div><div class="lbl">Total demo earnings</div></div>
    <div class="card stat"><div class="num">${fmtPR(maxPR)}</div><div class="lbl">Highest demo PR</div></div>
  </section>
  <section><h2>Featured Competitive Leaderboard</h2>${miniTable(PLAYERS.slice(0,10))}
    <p style="margin-top:10px"><a class="btn primary" href="#/leaderboard">View full leaderboard →</a></p></section>
  <section><h2>Featured Player</h2><div class="card profile-head" style="cursor:pointer" id="featCard">
    <span class="avatar big">${initials(feat.name)}</span>
    <div><h3>${esc(feat.name)} · #${feat.rank}</h3><p class="muted">${esc(feat.region)} (demo region)</p>
    <p>${fmtPR(feat.pr)} PR · ${feat.wins} FNCS wins · ${fmtUSD(feat.earnings)}</p>
    <div class="badges" style="margin-top:8px">${badgesFor(feat).map(b=>`<span class="badge ${b.cls||""}">${b.label}</span>`).join("")}</div></div></div></section>
  <section><h2>Recent Tournament Results</h2><div class="grid cols3">
    ${t3.map(t=>`<a class="card" href="#/tournaments"><h3>${esc(t.name)}</h3><p class="muted">${t.region} · ${t.format} · ${fmtUSD(t.prize)}</p><p>🏆 Winner: <strong>${esc(t.winner)}</strong></p><p class="muted">${t.date.toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"})}</p></a>`).join("")}
  </div></section>
  ${topSections()}`;
  bindSearch(); bindRows(app);
  $("#featCard").addEventListener("click",()=>location.hash="#/player/"+feat.rank);
}

/* Top 10 / Most wins / Highest earnings (unique by name, first = best entry) */
function uniqueBy(key){
  const best=new Map();
  PLAYERS.forEach(p=>{const c=best.get(p.name);if(!c||p[key]>c[key])best.set(p.name,p);});
  return [...best.values()].sort((a,b)=>b[key]-a[key]||a.rank-b.rank).slice(0,10);
}
function topSections(){
  const wins=uniqueBy("wins"), earn=uniqueBy("earnings");
  const li=(p,v)=>`<li data-rank="${p.rank}"><span>${esc(p.name)}</span><strong>${v}</strong></li>`;
  return `<section><h2>Top 10 Players</h2><div class="card"><ul class="small-list" data-go>${PLAYERS.slice(0,10).map(p=>li(p,"#"+p.rank+" · "+fmtPR(p.pr)+" PR")).join("")}</ul></div></section>
  <section class="grid cols3" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">
    <div><h2>Most FNCS Wins</h2><div class="card"><ul class="small-list" data-go>${wins.map(p=>li(p,p.wins+" wins")).join("")}</ul></div></div>
    <div><h2>Highest Earnings</h2><div class="card"><ul class="small-list" data-go>${earn.map(p=>li(p,fmtUSD(p.earnings))).join("")}</ul></div></div>
  </section>`;
}
document.addEventListener("click",e=>{const li=e.target.closest("[data-go] li");if(li)location.hash="#/player/"+li.dataset.rank;});

/* Leaderboard */
function filteredPlayers(){
  const q=lbState.q.trim().toLowerCase();
  let l=PLAYERS.filter(p=>(!q||p.name.toLowerCase().includes(q))&&(!lbState.region||p.region===lbState.region));
  const k=lbState.sort, d=lbState.dir;
  l.sort((a,b)=>(k==="name"?a.name.localeCompare(b.name):a[k]-b[k])*d||a.rank-b.rank);
  return l;
}
function viewLeaderboard(){
  app.innerHTML=`<h1>Leaderboard</h1>
  <div class="toolbar">
    <div class="f"><label for="lbq">Search players</label><input id="lbq" type="search" placeholder="Search by name…" value="${esc(lbState.q)}"></div>
    <div class="f"><label for="lbr">Region (demo)</label><select id="lbr"><option value="">All regions</option>${REGIONS.map(r=>`<option ${lbState.region===r?"selected":""}>${r}</option>`).join("")}</select></div>
    <div class="f"><label for="lbs">Sort by</label><select id="lbs">
      ${[["rank","Rank"],["name","Player name"],["wins","FNCS wins"],["pr","PR"],["earnings","Earnings"]].map(([v,l])=>`<option value="${v}" ${lbState.sort===v?"selected":""}>${l}</option>`).join("")}</select></div>
    <button class="btn" id="lbPR">Sort by PR</button>
    <button class="btn" id="lbReset">Reset filters</button>
    <button class="btn primary" id="lbCSV">Export CSV</button>
  </div>
  <p id="lbCount" class="muted" aria-live="polite"></p>
  <div id="lbBody"></div>`;
  $("#lbq").addEventListener("input",e=>{lbState.q=e.target.value;lbState.page=1;drawLB();});
  $("#lbr").addEventListener("change",e=>{lbState.region=e.target.value;lbState.page=1;drawLB();});
  $("#lbs").addEventListener("change",e=>{lbState.sort=e.target.value;lbState.dir=(lbState.sort==="rank"||lbState.sort==="name")?1:-1;lbState.page=1;drawLB();});
  $("#lbPR").addEventListener("click",()=>{lbState.sort="pr";lbState.dir=-1;lbState.page=1;$("#lbs").value="pr";drawLB();});
  $("#lbReset").addEventListener("click",()=>{lbState={q:"",region:"",sort:"rank",dir:1,page:1};viewLeaderboard();toast("Filters reset");});
  $("#lbCSV").addEventListener("click",()=>{
    const rows=filteredPlayers();
    const csv=["Rank,Player,FNCS Wins,PR,Earnings USD,Region (demo)"].concat(rows.map(p=>[p.rank,'"'+p.name.replace(/"/g,'""')+'"',p.wins,p.pr,p.earnings,p.region].join(","))).join("\n");
    downloadFile("fn-stats-demo-leaderboard.csv",csv,"text/csv");toast("CSV exported ("+rows.length+" rows)");
  });
  drawLB();
}
function drawLB(){
  const list=filteredPlayers(), pages=Math.max(1,Math.ceil(list.length/PER_PAGE));
  lbState.page=Math.min(lbState.page,pages);
  const slice=list.slice((lbState.page-1)*PER_PAGE,lbState.page*PER_PAGE);
  const arrow=k=>lbState.sort===k?(lbState.dir===1?" ▲":" ▼"):"";
  $("#lbCount").textContent=`${list.length} matching player${list.length===1?"":"s"} · Page ${lbState.page} of ${pages}`;
  const body=$("#lbBody");
  if(!list.length){body.innerHTML='<div class="card notfound"><p>No players match your filters.</p></div>';return;}
  body.innerHTML=`<div class="table-wrap"><table><thead><tr>
    <th data-s="rank">Rank${arrow("rank")}</th><th data-s="name">Player${arrow("name")}</th><th class="num-r" data-s="wins">FNCS Wins${arrow("wins")}</th><th class="num-r" data-s="pr">PR${arrow("pr")}</th><th class="num-r" data-s="earnings">Earnings${arrow("earnings")}</th></tr></thead>
    <tbody>${slice.map(rowHTML).join("")}</tbody></table></div>
    <div class="pager"><button class="btn" id="pgP" ${lbState.page===1?"disabled":""}>← Prev</button>
    ${pageBtns(lbState.page,pages)}
    <button class="btn" id="pgN" ${lbState.page===pages?"disabled":""}>Next →</button></div>`;
  body.querySelectorAll("th[data-s]").forEach(th=>th.addEventListener("click",()=>{
    const k=th.dataset.s; if(lbState.sort===k)lbState.dir*=-1; else{lbState.sort=k;lbState.dir=(k==="rank"||k==="name")?1:-1;}
    $("#lbs").value=lbState.sort; drawLB();}));
  $("#pgP").onclick=()=>{lbState.page--;drawLB();};
  $("#pgN").onclick=()=>{lbState.page++;drawLB();};
  body.querySelectorAll("[data-pg]").forEach(b=>b.onclick=()=>{lbState.page=+b.dataset.pg;drawLB();});
  bindRows(body);
}
function pageBtns(cur,total){
  const out=[];
  for(let i=1;i<=total;i++){
    if(i===1||i===total||Math.abs(i-cur)<=1)out.push(`<button class="btn ${i===cur?"cur":""}" data-pg="${i}" ${i===cur?'aria-current="page"':""}>${i}</button>`);
    else if(out[out.length-1]!=="<span>…</span>")out.push("<span>…</span>");
  }
  return out.join("");
}

/* Player profile */
function viewPlayer(rank){
  const p=PLAYERS[rank-1];
  if(!p) return viewNotFound("Player Not Found","We couldn't find a player with that rank.");
  const res=playerResults(p), badges=badgesFor(p);
  app.innerHTML=`<p><button class="btn" id="backBtn">← Back to leaderboard</button></p>
  <div class="card profile-head ${p.team?"pro-card":""}"><span class="avatar big">${initials(p.name)}</span>
    <div><h1>${esc(p.name)}${isVerified(p)?'<span class="vcheck" style="width:24px;height:24px;font-size:.9rem" title="Verified Pro (demo mark)">✓</span>':""}</h1>${p.team?`<p><span class="team-tag" style="margin-left:0">${esc(p.team)}</span> <span class="muted">Pro team (demo)</span></p>`:""}<p class="muted">Rank <strong class="accent">#${p.rank}</strong> · ${esc(p.region)}${p.team?" · "+esc(p.team):" (demo region)"}</p></div>
    <button class="btn primary" id="copyBtn" style="margin-left:auto">Copy stats</button></div>
  <section class="grid stats" style="margin-top:14px">
    <div class="card stat"><div class="num">${fmtPR(p.pr)}</div><div class="lbl">PR points</div></div>
    <div class="card stat"><div class="num">${p.wins}</div><div class="lbl">FNCS wins</div></div>
    <div class="card stat"><div class="num">${fmtUSD(p.earnings)}</div><div class="lbl">Career earnings</div></div>
    <div class="card stat"><div class="num">${esc(p.region)}</div><div class="lbl">Region (demo)</div></div>
    ${p.qual?`<div class="card stat"><div class="num">${p.qual}x</div><div class="lbl">FNCS Qualifier</div></div>`:""}
    ${p.divcup?`<div class="card stat"><div class="num">${p.divcup}x</div><div class="lbl">FNCS Div Cup Champion</div></div>`:""}
  </section>
  <section><h2>Competitive Achievements</h2><div class="badges">
    ${BADGE_DEFS.map(b=>{const on=badges.includes(b);return `<span class="badge ${on?(b.cls||""):"off"}" title="${b.desc}">${on?"✔ ":"✖ "}${b.label}</span>`;}).join("")}</div></section>
  <section><h2>Performance Chart</h2><div class="card">${perfChart(res)}<p class="muted" style="font-size:.8rem">Placement per demo tournament (higher = better). Oldest → newest.</p></div></section>
  <section><h2>FNCS History</h2><div class="card">${fncsHistory(p).length?'<ul class="small-list">'+fncsHistory(p).map(h=>`<li style="cursor:default"><span>${esc(h.text)}</span><span class="muted">${esc(h.season)}</span></li>`).join("")+'</ul>':'<p class="muted">No FNCS titles on record yet.</p>'}</div></section>
  <section><h2>Recent Tournament Placements</h2>
    <div class="table-wrap"><table><thead><tr><th>Tournament</th><th>Date</th><th>Format</th><th class="num-r">Placement</th><th class="num-r">Points</th></tr></thead><tbody>
    ${res.map(r=>`<tr style="cursor:default"><td>${esc(r.t.name)}</td><td>${r.t.date.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</td><td>${r.t.format}</td><td class="num-r">#${r.place}</td><td class="num-r">${r.points}</td></tr>`).join("")}
    </tbody></table></div></section>`;
  $("#backBtn").addEventListener("click",()=>{location.hash=lastListRoute;});
  $("#copyBtn").addEventListener("click",()=>copyText(`${p.name} (#${p.rank}) — ${fmtPR(p.pr)} PR, ${p.wins} FNCS wins, ${fmtUSD(p.earnings)} earnings, ${p.region}${p.qual?", "+p.qual+"x FNCS Qualifier":""}${p.divcup?", "+p.divcup+"x Div Cup Champion":""}.`));
}
function perfChart(res){
  const data=res.slice().reverse(), W=600,H=220,pad=34, n=data.length;
  const maxPlace=Math.max(...data.map(d=>d.place),10);
  const x=i=>pad+i*((W-2*pad)/(n-1||1));
  const y=pl=>pad+(pl-1)/(maxPlace-1||1)*(H-2*pad); // better placement = higher on chart
  const pts=data.map((d,i)=>`${x(i)},${y(d.place)}`).join(" ");
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Demo performance chart">
    <g class="lines">${[0,1,2,3].map(i=>`<line x1="${pad}" x2="${W-pad}" y1="${pad+i*(H-2*pad)/3}" y2="${pad+i*(H-2*pad)/3}"/>`).join("")}</g>
    <polyline fill="none" stroke="var(--orange)" stroke-width="3" points="${pts}"/>
    ${data.map((d,i)=>`<circle cx="${x(i)}" cy="${y(d.place)}" r="5" fill="var(--yellow)"/><text x="${x(i)}" y="${y(d.place)-10}" fill="var(--text)" font-size="11" text-anchor="middle">#${d.place}</text>`).join("")}
  </svg>`;
}

/* Tournaments */
function viewTournaments(){
  app.innerHTML=`<h1>Tournaments</h1>
  <div class="grid cols3" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">
  ${TOURNAMENTS.map(t=>`<div class="card"><h3>${esc(t.name)}</h3>
    <p class="muted">${t.region} · ${t.format} · ${t.date.toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"})}</p>
    <p>💰 Prize pool: <strong>${fmtUSD(t.prize)}</strong></p><p>🏆 Winner: <strong class="accent">${esc(t.winner)}</strong></p>
    <details><summary>Final placements</summary><ol style="padding-left:20px">${t.placements.map(p=>`<li><a href="#/player/${p.rank}">${esc(p.name)}</a></li>`).join("")}</ol></details>
   </div>`).join("")}</div>`;
}

/* Achievements */
function viewAchievements(){
  app.innerHTML=`<h1>Achievements</h1>
  <div class="grid cols3">${BADGE_DEFS.map(b=>{
    const holders=[...new Map(PLAYERS.filter(b.test).map(p=>[p.name,p])).values()];
    return `<div class="card"><h3>🎖️ ${b.label}</h3><p class="muted">${b.desc}</p><p><strong class="accent">${holders.length}</strong> unique player${holders.length===1?"":"s"}</p>
    <ul class="small-list" data-go>${holders.slice(0,6).map(p=>`<li data-rank="${p.rank}"><span>${esc(p.name)}</span><span class="muted">#${p.rank}</span></li>`).join("")}</ul>
    ${holders.length>6?`<p class="muted" style="font-size:.8rem">+${holders.length-6} more</p>`:""}</div>`;}).join("")}</div>`;
}

function viewTeams(){
  app.innerHTML=`<h1>Esports Orgs</h1><div class="grid cols3">${Object.entries(ORGS).map(([org,o])=>{
    const seen=new Set(), roster=PLAYERS.filter(p=>p.team===org&&!seen.has(p.name)&&seen.add(p.name));
    const wins=roster.reduce((s,p)=>s+p.wins,0), earn=roster.reduce((s,p)=>s+p.earnings,0);
    return `<div class="card pro-card"><h3>${esc(o.full)}</h3><p class="muted">${roster.length} player${roster.length===1?"":"s"} · ${wins} FNCS wins · ${fmtUSD(earn)}</p>
    <ul class="small-list" data-go>${roster.map(p=>`<li data-rank="${p.rank}"><span>${esc(p.name)}<span class="vcheck">✓</span></span><span class="muted">#${p.rank} · ${fmtPR(p.pr)} PR</span></li>`).join("")}</ul></div>`;}).join("")}</div>`;
}
function viewAbout(){
  app.innerHTML=`<h1>About FN STATS</h1><div class="card"><p>FN STATS is a fan-made <strong>demonstration</strong> of a competitive Fortnite statistics website. It runs entirely in your browser — no servers, accounts, or external APIs.</p>
  <p style="margin-top:10px">Player names are used for demonstration only. Every number — FNCS wins, PR, earnings, regions, tournaments and results — is <strong>fictional</strong> and labeled <em>DEMO DATA — NOT OFFICIAL</em>.</p>
  <p style="margin-top:10px">FN STATS is not affiliated with Epic Games, Fortnite, or Fortnite Tracker.</p>
  <p style="margin-top:10px">To edit the data, open <code>script.js</code> and change the <code>PLAYER_DATA</code> array at the top.</p></div>`;
}
function viewFAQ(){
  const q=[["Are these real stats?","No. All stats are fictional demo data and not verified in any way."],
  ["How are regions assigned?","Regions are demo values generated from each player name so filters work (3xzzy is set to NA East manually). They are not real."],
  ["Why do some names appear more than once?","The supplied data contains duplicate names. They are kept exactly as provided and ranked separately."],
  ["How do I edit the players?","Edit the PLAYER_DATA array in script.js: [name, FNCS wins, PR, earnings]. Rank is the position in the list."],
  ["How are achievements calculated?","From the demo numbers: e.g. High PR = 50,000+, 'Verified Pro (Demo)' = a cosmetic demo mark, Earnings Milestone = $500,000+, Top 10 = rank 1–10."],
  ["Can I export the leaderboard?","Yes — use Export CSV on the Leaderboard page. It respects your current search and filters."]];
  app.innerHTML=`<h1>FAQ</h1>${q.map(([a,b])=>`<details><summary>${a}</summary><p>${b}</p></details>`).join("")}`;
}
function viewNotFound(title="Page Not Found",msg="That page doesn't exist."){
  app.innerHTML=`<div class="card notfound"><div class="big">404</div><h2>${esc(title)}</h2><p class="muted">${esc(msg)}</p><p style="margin-top:14px">${searchBox()}</p><p style="margin-top:14px"><a class="btn primary" href="#/leaderboard">Go to leaderboard</a></p></div>`;
  bindSearch();
}

/* ========== 7. ROUTER ========== */
function route(){
  const h=location.hash||"#/", parts=h.replace(/^#\/?/,"").split("/");
  const page=parts[0]||"home";
  document.querySelectorAll("[data-nav]").forEach(a=>a.classList.toggle("active",a.dataset.nav===(page==="player"?"leaderboard":page)));
  if(page!=="player")lastListRoute=h==="#/"?"#/leaderboard":h;
  if(page==="player")lastListRoute=lastListRoute.startsWith("#/player")?"#/leaderboard":lastListRoute;
  const views={
    home:viewHome, leaderboard:viewLeaderboard, tournaments:viewTournaments, achievements:viewAchievements,
    teams:viewTeams, about:viewAbout, faq:viewFAQ, player:()=>viewPlayer(parseInt(parts[1],10))
  };
  const fn=views[page];
  window.scrollTo(0,0);
  if(!fn){viewNotFound();return;}
  loading(fn);
}
window.addEventListener("hashchange",route);
route();
