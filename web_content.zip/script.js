let tamu = JSON.parse(localStorage.getItem('bukuTamu')) || [];

const form = document.getElementById('guestForm');
const list = document.getElementById('guestList');
const search = document.getElementById('search');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const data = {
        id: Date.now(),
        nama: document.getElementById('nama').value,
        instansi: document.getElementById('instansi').value,
        keperluan: document.getElementById('keperluan').value,
        waktu: new Date().toLocaleString('id-ID')
    };
    tamu.unshift(data);
    localStorage.setItem('bukuTamu', JSON.stringify(tamu));
    form.reset();
    tampilkanTamu();
});

function tampilkanTamu(filter = '') {
    list.innerHTML = '';
    const filtered = tamu.filter(t => t.nama.toLowerCase().includes(filter.toLowerCase()));
    filtered.forEach((t, i) => {
        list.innerHTML += `
            <tr>
                <td>${i+1}</td>
                <td>${t.nama}</td>
                <td>${t.instansi}</td>
                <td>${t.keperluan}</td>
                <td>${t.waktu}</td>
                <td><button class="btn-hapus" onclick="hapusTamu(${t.id})">Hapus</button></td>
            </tr>
        `;
    });
}

function hapusTamu(id) {
    if(confirm('Hapus data ini?')) {
        tamu = tamu.filter(t => t.id !== id);
        localStorage.setItem('bukuTamu', JSON.stringify(tamu));
        tampilkanTamu();
    }
}

search.addEventListener('input', (e) => tampilkanTamu(e.target.value));

tampilkanTamu();