const checklist=[
["Attendance File"],
["CCTV Checklist",["Checklist","Book"]],
["Telephone Book"],
["Generator & AC",["Generator Checklist","Book (Generator & AC)","Bill (Generator & AC)"]],
["Staff Details"],
["Inventory Book",["Lane Book","Filter Book","Other Items"]],
["Area Manager Checklist"],
["Fixed Assets Register"],
["Asset Codes"],
["Target Achievement"],
["Street Promotion"],
["Error Report"],
["Water Bill (Current Bill)",["Manual Book","Bill PDF"]],
["Fee Collector Manual Bill",["Cash Handing Over & Coins","Credit Card Details","Advance Voucher & Credit Sale","Manual Credit Card & Receipt Entry","Cancel & Missing Receipt"]],
["Certificate Reconciliation Book",["Certificate Reconciliation Monthly & Damage Certificate Details","Damage Certificate","Certificate Reconciliation Daily"]],
["Vehicle Rejection Book"],
["Stock Note"],
["Master Document (DMT)"],
["Customer Call Service"],
["Software Reset"],
["Cleaning Payment"],
["Other Payments"],
["HR Document Systematized"],
["Petty Cash",["Bill Report","Book"]],
["Log Book"],
["Modara Verification"],
["Customer Complaints & Suggestions"],
["Center Log Book (DMT Only)"],
["Security Attendance Book"],
["First Aid Box List with Date"]
];
const STORAGE_KEY="office-audit-checklist-v2";
let state;
try{state=JSON.parse(localStorage.getItem(STORAGE_KEY));}catch(e){}
if(!Array.isArray(state)||state.length!==checklist.length)state=checklist.map(x=>x[1]?x[1].map(()=>false):false);
function mainDone(i){return checklist[i][1]?state[i].every(Boolean):state[i];}
function save(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(e){}}
function render(){
const list=document.getElementById("list");list.innerHTML="";
checklist.forEach((entry,i)=>{
const card=document.createElement("section");card.className="item";
const head=document.createElement("div");head.className="head";
const name=document.createElement("span");name.className="name";name.textContent=(i+1)+". "+entry[0];
const status=document.createElement("span");status.className="status "+(mainDone(i)?"ok":"pending");status.textContent=mainDone(i)?"OK":"Pending";
head.append(name,status);card.append(head);
if(entry[1]){
entry[1].forEach((sub,j)=>{
const row=document.createElement("label");row.className="subrow"+(state[i][j]?" done":"");
const cb=document.createElement("input");cb.type="checkbox";cb.checked=state[i][j];
const txt=document.createElement("span");txt.className="subname";txt.textContent=(i+1)+"."+(j+1)+" "+sub;
const st=document.createElement("span");st.className="substatus "+(state[i][j]?"ok":"pending");st.textContent=state[i][j]?"OK":"Pending";
cb.addEventListener("change",()=>{state[i][j]=cb.checked;save();render();});
row.append(cb,txt,st);card.append(row);
});
}else{
const row=document.createElement("label");row.className="single";
const cb=document.createElement("input");cb.type="checkbox";cb.checked=state[i];
const txt=document.createElement("span");txt.className="subname";txt.textContent="Mark as completed";
const st=document.createElement("span");st.className="substatus "+(state[i]?"ok":"pending");st.textContent=state[i]?"OK":"Pending";
cb.addEventListener("change",()=>{state[i]=cb.checked;save();render();});
row.append(cb,txt,st);card.append(row);
}
list.append(card);
});
updateProgress();
}
function updateProgress(){
let done=checklist.reduce((sum,x,i)=>sum+(mainDone(i)?1:0),0);
let pct=Math.round(done/checklist.length*100);
document.getElementById("summary").textContent=done+" / 30 Main Items Complete · "+(30-done)+" Pending";
document.getElementById("progress").style.width=pct+"%";
document.getElementById("percent").textContent=pct+"%";
}
document.getElementById("all-pending").addEventListener("click",()=>{state=checklist.map(x=>x[1]?x[1].map(()=>false):false);save();render();});
document.getElementById("all-ok").addEventListener("click",()=>{state=checklist.map(x=>x[1]?x[1].map(()=>true):true);save();render();});
document.getElementById("reset").addEventListener("click",()=>{if(!confirm("Reset all items to Pending?"))return;state=checklist.map(x=>x[1]?x[1].map(()=>false):false);save();render();});
render();
