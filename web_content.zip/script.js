/* =================================
   SONIC — OFFLINE MUSIC PLAYER
   Version 1.0
================================= */

const audio = document.getElementById("audio");
const fileInput = document.getElementById("fileInput");
const importBtn = document.getElementById("importBtn");
const emptyImportBtn = document.getElementById("emptyImportBtn");

const trackList = document.getElementById("trackList");
const emptyState = document.getElementById("emptyState");
const trackCount = document.getElementById("trackCount");

const currentTitle = document.getElementById("currentTitle");
const currentArtist = document.getElementById("currentArtist");
const currentTime = document.getElementById("currentTime");
const duration = document.getElementById("duration");
const progress = document.getElementById("progress");

const playBtn = document.getElementById("playBtn");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const favoriteBtn = document.getElementById("favoriteBtn");
const shuffleBtn = document.getElementById("shuffleBtn");
const repeatBtn = document.getElementById("repeatBtn");

let tracks = [];
let currentIndex = -1;
let favorites = new Set();
let shuffle = false;
let repeat = false;
let objectURL = null;

/* =================================
   LOCAL STORAGE
================================= */

try {
  const savedFavorites = JSON.parse(
    localStorage.getItem("sonic_favorites") || "[]"
  );

  favorites = new Set(savedFavorites);
} catch (error) {
  favorites = new Set();
}

/* =================================
   IMPORT MUSIC
================================= */

function openFilePicker() {
  fileInput.click();
}

importBtn.addEventListener("click", openFilePicker);
emptyImportBtn.addEventListener("click", openFilePicker);

fileInput.addEventListener("change", function () {
  const files = Array.from(fileInput.files || []);

  const audioFiles = files.filter(file =>
    file.type.startsWith("audio/") ||
    /\.(mp3|wav|ogg|m4a|aac|flac|opus|wma)$/i.test(file.name)
  );

  if (audioFiles.length === 0) {
    alert("Aucun fichier audio compatible sélectionné.");
    fileInput.value = "";
    return;
  }

  const existing = new Set(
    tracks.map(track => `${track.name}_${track.size}_${track.lastModified}`)
  );

  let added = 0;

  audioFiles.forEach(file => {
    const key = `${file.name}_${file.size}_${file.lastModified}`;

    if (existing.has(key)) return;

    tracks.push({
      file,
      name: file.name.replace(/\.[^/.]+$/, ""),
      size: file.size,
      lastModified: file.lastModified,
      key
    });

    existing.add(key);
    added++;
  });

  renderTracks();

  if (currentIndex === -1 && tracks.length > 0) {
    selectTrack(0, false);
  }

  if (added === 0) {
    alert("Ces morceaux sont déjà dans la bibliothèque actuelle.");
  }

  fileInput.value = "";
});

/* =================================
   RENDER LIBRARY
================================= */

function renderTracks() {
  trackList.innerHTML = "";

  emptyState.style.display = tracks.length ? "none" : "flex";

  trackCount.textContent =
    `${tracks.length} morceau${tracks.length > 1 ? "x" : ""}`;

  tracks.forEach((track, index) => {
    const row = document.createElement("div");
    row.className = "track-item";

    if (index === currentIndex) {
      row.classList.add("active");
    }

    const cover = document.createElement("div");
    cover.className = "track-cover";
    cover.textContent = "♫";

    const details = document.createElement("div");
    details.className = "track-details";

    const title = document.createElement("strong");
    title.textContent = track.name;

    const subtitle = document.createElement("span");
    subtitle.textContent = index === currentIndex && !audio.paused
      ? "En cours de lecture"
      : formatFileSize(track.size);

    details.append(title, subtitle);

    const favorite = document.createElement("button");
    favorite.type = "button";
    favorite.textContent = favorites.has(track.key) ? "♥" : "♡";
    favorite.setAttribute(
      "aria-label",
      favorites.has(track.key)
        ? "Retirer des favoris"
        : "Ajouter aux favoris"
    );

    favorite.style.color = favorites.has(track.key)
      ? "#c084fc"
      : "#9690a7";

    favorite.addEventListener("click", event => {
      event.stopPropagation();
      toggleFavorite(track.key);
      renderTracks();
      updateFavoriteButton();
    });

    row.append(cover, details, favorite);

    row.addEventListener("click", () => {
      selectTrack(index, true);
    });

    trackList.appendChild(row);
  });
}

/* =================================
   SELECT AND PLAY TRACK
================================= */

function selectTrack(index, autoplay = true) {
  if (index < 0 || index >= tracks.length) return;

  currentIndex = index;

  if (objectURL) {
    URL.revokeObjectURL(objectURL);
  }

  objectURL = URL.createObjectURL(tracks[index].file);

  audio.src = objectURL;
  audio.load();

  currentTitle.textContent = tracks[index].name;
  currentArtist.textContent = "Fichier local • SONIC";

  currentTime.textContent = "0:00";
  duration.textContent = "0:00";
  progress.value = 0;

  updateFavoriteButton();
  renderTracks();

  if (autoplay) {
    playAudio();
  } else {
    playBtn.textContent = "▶";
  }
}

async function playAudio() {
  if (currentIndex === -1 && tracks.length > 0) {
    selectTrack(0, false);
  }

  if (!audio.src) return;

  try {
    await audio.play();
    playBtn.textContent = "Ⅱ";
    renderTracks();
  } catch (error) {
    playBtn.textContent = "▶";
    console.log("Lecture impossible :", error.message);
  }
}

function pauseAudio() {
  audio.pause();
  playBtn.textContent = "▶";
  renderTracks();
}

playBtn.addEventListener("click", () => {
  if (audio.paused) {
    playAudio();
  } else {
    pauseAudio();
  }
});

/* =================================
   NEXT / PREVIOUS
================================= */

function nextTrack() {
  if (tracks.length === 0) return;

  let nextIndex;

  if (shuffle && tracks.length > 1) {
    do {
      nextIndex = Math.floor(Math.random() * tracks.length);
    } while (nextIndex === currentIndex);
  } else {
    nextIndex = currentIndex + 1;

    if (nextIndex >= tracks.length) {
      nextIndex = 0;
    }
  }

  selectTrack(nextIndex, true);
}

function previousTrack() {
  if (tracks.length === 0) return;

  if (audio.currentTime > 3) {
    audio.currentTime = 0;
    return;
  }

  let previousIndex = currentIndex - 1;

  if (previousIndex < 0) {
    previousIndex = tracks.length - 1;
  }

  selectTrack(previousIndex, true);
}

nextBtn.addEventListener("click", nextTrack);
prevBtn.addEventListener("click", previousTrack);

audio.addEventListener("ended", () => {
  if (repeat) {
    audio.currentTime = 0;
    playAudio();
  } else {
    nextTrack();
  }
});

/* =================================
   PROGRESS AND TIME
================================= */

function formatTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) {
    return "0:00";
  }

  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);

  return `${mins}:${String(secs).padStart(2, "0")}`;
}

audio.addEventListener("loadedmetadata", () => {
  duration.textContent = formatTime(audio.duration);
});

audio.addEventListener("timeupdate", () => {
  currentTime.textContent = formatTime(audio.currentTime);

  if (Number.isFinite(audio.duration) && audio.duration > 0) {
    progress.value = (audio.currentTime / audio.duration) * 1000;
  }
});

progress.addEventListener("input", () => {
  if (Number.isFinite(audio.duration) && audio.duration > 0) {
    audio.currentTime = (Number(progress.value) / 1000) * audio.duration;
  }
});

/* =================================
   FAVORITES
================================= */

function toggleFavorite(key) {
  if (favorites.has(key)) {
    favorites.delete(key);
  } else {
    favorites.add(key);
  }

  try {
    localStorage.setItem(
      "sonic_favorites",
      JSON.stringify(Array.from(favorites))
    );
  } catch (error) {
    console.log("Sauvegarde des favoris indisponible.");
  }
}

function updateFavoriteButton() {
  if (currentIndex === -1) {
    favoriteBtn.textContent = "♡";
    favoriteBtn.classList.remove("selected");
    return;
  }

  const key = tracks[currentIndex].key;
  const isFavorite = favorites.has(key);

  favoriteBtn.textContent = isFavorite ? "♥" : "♡";
  favoriteBtn.classList.toggle("selected", isFavorite);
}

favoriteBtn.addEventListener("click", () => {
  if (currentIndex === -1) return;

  toggleFavorite(tracks[currentIndex].key);
  updateFavoriteButton();
  renderTracks();
});

/* =================================
   SHUFFLE / REPEAT
================================= */

shuffleBtn.addEventListener("click", () => {
  shuffle = !shuffle;
  shuffleBtn.classList.toggle("selected", shuffle);
  shuffleBtn.setAttribute(
    "aria-pressed",
    String(shuffle)
  );
});

repeatBtn.addEventListener("click", () => {
  repeat = !repeat;
  repeatBtn.classList.toggle("selected", repeat);
  repeatBtn.setAttribute(
    "aria-pressed",
    String(repeat)
  );
});

/* =================================
   AUDIO ERRORS
================================= */

audio.addEventListener("error", () => {
  playBtn.textContent = "▶";
  currentArtist.textContent = "Format audio non pris en charge";
});

audio.addEventListener("play", () => {
  playBtn.textContent = "Ⅱ";
  renderTracks();
});

audio.addEventListener("pause", () => {
  playBtn.textContent = "▶";
  renderTracks();
});

/* =================================
   HELPERS
================================= */

function formatFileSize(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) {
    return "Fichier audio";
  }

  if (bytes < 1024 * 1024) {
    return `${Math.max(1, Math.round(bytes / 1024))} Ko`;
  }

  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}

/* =================================
   INITIALIZE
================================= */

renderTracks();
updateFavoriteButton();

console.log("SONIC Music Player prêt.");