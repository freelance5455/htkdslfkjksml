
// =====================================
// GEMBOX 2027 MATCH TRACKER
// MAIN JAVASCRIPT
// =====================================

// LOAD DATA
let matches = [];

try {
    matches = JSON.parse(
        localStorage.getItem("gembox_matches") || "[]"
    );

    if (!Array.isArray(matches)) matches = [];
} catch (error) {
    matches = [];
}

// ELEMENT
const $ = id => document.getElementById(id);

// =====================================
// SAVE DATA
// =====================================

function saveData() {
    localStorage.setItem(
        "gembox_matches",
        JSON.stringify(matches)
    );
}

// =====================================
// WINNER SYSTEM
// =====================================

function getWinner(score1, score2) {
    if (score1 > score2) return 1;
    if (score2 > score1) return 2;
    return 0;
}

function updateWinner() {
    const score1 = Number($("score1").value);
    const score2 = Number($("score2").value);

    const name1 = $("name1").value.trim() || "PLAYER 1";
    const name2 = $("name2").value.trim() || "PLAYER 2";

    const result = getWinner(score1, score2);

    if (result === 1) {
        $("winner").textContent = "🏆 WINNER: " + name1;
    } else if (result === 2) {
        $("winner").textContent = "🏆 WINNER: " + name2;
    } else {
        $("winner").textContent = "🤝 HASIL PERTANDINGAN: DRAW";
    }
}

// =====================================
// ESCAPE HTML
// =====================================

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

// =====================================
// SAVE MATCH
// =====================================

function saveMatch() {
    const name1 = $("name1").value.trim();
    const name2 = $("name2").value.trim();

    const club1 = $("club1").value.trim();
    const club2 = $("club2").value.trim();

    const rawScore1 = $("score1").value;
    const rawScore2 = $("score2").value;

    if (!name1 || !name2) {
        alert("Masukkan nama kedua pemain!");
        return;
    }

    if (name1.toLowerCase() === name2.toLowerCase()) {
        alert("Nama pemain harus berbeda!");
        return;
    }

    if (!club1 || !club2) {
        alert("Pilih club kedua pemain!");
        return;
    }

    if (rawScore1 === "" || rawScore2 === "") {
        alert("Masukkan skor pertandingan!");
        return;
    }

    const score1 = Number(rawScore1);
    const score2 = Number(rawScore2);

    if (
        !Number.isSafeInteger(score1) ||
        !Number.isSafeInteger(score2) ||
        score1 < 0 ||
        score2 < 0
    ) {
        alert("Skor tidak valid!");
        return;
    }

    const result = getWinner(score1, score2);

    let winner = "DRAW";

    if (result === 1) winner = name1;
    if (result === 2) winner = name2;

    const match = {
        id: Date.now() + Math.random(),
        name1: name1,
        name2: name2,
        club1: club1,
        club2: club2,
        score1: score1,
        score2: score2,
        winner: winner,
        date: new Date().toLocaleString("id-ID")
    };

    matches.unshift(match);

    try {
        saveData();
    } catch (error) {
        matches.shift();
        alert("Gagal menyimpan data. Penyimpanan browser mungkin penuh.");
        return;
    }

    render();

    alert("🏆 PERTANDINGAN BERHASIL DISIMPAN!");

    $("score1").value = 0;
    $("score2").value = 0;

    updateWinner();
}

// =====================================
// PLAYER STATISTICS
// =====================================

function getStats(name) {
    let win = 0;
    let lose = 0;
    let draw = 0;

    matches.forEach(match => {

        const player1 = match.name1 === name;
        const player2 = match.name2 === name;

        if (!player1 && !player2) return;

        if (match.winner === "DRAW") {
            draw++;
        } else if (match.winner === name) {
            win++;
        } else {
            lose++;
        }
    });

    return {
        win,
        lose,
        draw,
        total: win + lose + draw
    };
}

// =====================================
// PLAYER LIST
// =====================================

function getPlayers() {
    const players = new Set();

    matches.forEach(match => {
        players.add(match.name1);
        players.add(match.name2);
    });

    return [...players];
}

// =====================================
// RENDER MAIN STATISTICS
// =====================================

function renderStats() {
    const name1 = $("name1").value.trim();
    const name2 = $("name2").value.trim();

    $("total").textContent = matches.length;

    $("win1").textContent = name1
        ? getStats(name1).win
        : 0;

    $("win2").textContent = name2
        ? getStats(name2).win
        : 0;

    const players = getPlayers();

    if (players.length === 0) {
        $("statistics").innerHTML =
            '<p class="empty">Belum ada statistik.</p>';
        return;
    }

    $("statistics").innerHTML = players.map(name => {
        const stats = getStats(name);

        return `
            <div class="player-stat">
                <span>${escapeHTML(name)}</span>

                <span>
                    <b>${stats.win} WIN</b> /
                    ${stats.lose} LOSE /
                    ${stats.draw} DRAW
                </span>
            </div>
        `;
    }).join("");
}

// =====================================
// MATCH HISTORY
// =====================================

function renderHistory() {

    if (matches.length === 0) {
        $("history").innerHTML = `
            <p class="empty">
                Belum ada pertandingan. Ayo mulai bermain! ⚽
            </p>
        `;
        return;
    }

    $("history").innerHTML = matches.map(match => {

        const resultText = match.winner === "DRAW"
            ? "🤝 HASIL SERI"
            : "🏆 WINNER: " + escapeHTML(match.winner);

        return `
            <div class="match">

                <div class="match-date">
                    📅 ${escapeHTML(match.date)}
                </div>

                <div class="match-score">

                    <div>
                        ${escapeHTML(match.name1)}
                        <br>
                        <small>${escapeHTML(match.club1)}</small>
                    </div>

                    <strong>
                        ${match.score1} - ${match.score2}
                    </strong>

                    <div style="text-align:right">
                        ${escapeHTML(match.name2)}
                        <br>
                        <small>${escapeHTML(match.club2)}</small>
                    </div>

                </div>

                <div class="match-result">
                    ${resultText}
                </div>

                <button onclick="deleteMatch('${match.id}')">
                    HAPUS MATCH
                </button>

            </div>
        `;
    }).join("");
}

// =====================================
// DELETE ONE MATCH
// =====================================

function deleteMatch(id) {

    if (!confirm("Yakin ingin menghapus pertandingan ini?")) {
        return;
    }

    const previous = matches;

    matches = matches.filter(
        match => String(match.id) !== String(id)
    );

    try {
        saveData();
    } catch (error) {
        matches = previous;
        alert("Gagal menghapus pertandingan.");
        return;
    }

    render();
}

// =====================================
// DELETE ALL HISTORY
// =====================================

function clearHistory() {

    if (matches.length === 0) {
        alert("Belum ada riwayat pertandingan!");
        return;
    }

    const confirmDelete = confirm(
        "PERINGATAN!\n\n" +
        "Semua riwayat dan statistik akan dihapus.\n\n" +
        "Apakah kamu yakin?"
    );

    if (!confirmDelete) return;

    const previous = matches;
    matches = [];

    try {
        saveData();
    } catch (error) {
        matches = previous;
        alert("Gagal menghapus data.");
        return;
    }

    render();

    alert("SEMUA RIWAYAT BERHASIL DIHAPUS!");
}

// =====================================
// LIVE UPDATE
// =====================================

[
    "name1",
    "name2",
    "score1",
    "score2"
].forEach(id => {

    $(id).addEventListener("input", () => {
        updateWinner();
        renderStats();
    });

});

// =====================================
// INITIALIZE WEBSITE
// =====================================

function render() {
    renderStats();
    renderHistory();
    updateWinner();
}

render();

console.log("GEMBOX 2027 MATCH TRACKER READY!");
