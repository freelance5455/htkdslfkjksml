
/* =========================================
   SKIPTRACK — MAIN SCRIPT
   Cocok untuk index.html + style.css
========================================= */

(function () {
  "use strict";

  const $ = id => document.getElementById(id);
  const storage = window.SkipTrackStorage;

  if (!storage) {
    console.error("SkipTrack: storage.js belum dimuat.");
    return;
  }

  const state = {
    running: false,
    paused: false,
    finished: false,
    startedAt: 0,
    elapsedBeforePause: 0,
    elapsedSeconds: 0,
    sessionJumps: 0,
    targetMinutes: 5,
    targetJumps: 500,
    intervalId: null,
    sessionId: null
  };

  let toastTimeout = null;

  /* -----------------------------------------
     UTILITIES
  ----------------------------------------- */

  function formatNumber(value) {
    return Math.max(0, Math.floor(Number(value) || 0))
      .toLocaleString("id-ID");
  }

  function formatDuration(seconds) {
    const total = Math.max(0, Math.floor(Number(seconds) || 0));
    const minutes = Math.floor(total / 60);
    const remainingSeconds = total % 60;

    return (
      String(minutes).padStart(2, "0") +
      ":" +
      String(remainingSeconds).padStart(2, "0")
    );
  }

  function formatMinutes(seconds) {
    const minutes = Math.floor(Math.max(0, seconds) / 60);
    const remainingSeconds = Math.floor(Math.max(0, seconds) % 60);

    if (minutes === 0) return `${remainingSeconds} dtk`;
    if (remainingSeconds === 0) return `${formatNumber(minutes)} menit`;

    return `${formatNumber(minutes)} mnt ${remainingSeconds} dtk`;
  }

  function localDateKey(date = new Date()) {
    return storage.localDateKey
      ? storage.localDateKey(date)
      : [
          date.getFullYear(),
          String(date.getMonth() + 1).padStart(2, "0"),
          String(date.getDate()).padStart(2, "0")
        ].join("-");
  }

  function showToast(message) {
    const toast = $("toast");
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toast.classList.remove("show");
    }, 2600);
  }

  function refreshIcons() {
    if (window.lucide && typeof window.lucide.createIcons === "function") {
      window.lucide.createIcons();
    }
  }

  function getValidNumber(element, min, max, fallback) {
    if (!element) return fallback;

    const number = Number(element.value);

    if (!Number.isFinite(number)) return fallback;

    return Math.max(min, Math.min(max, Math.floor(number)));
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, character => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[character]);
  }

  /* -----------------------------------------
     SETTINGS
  ----------------------------------------- */

  function readTargets() {
    state.targetMinutes = getValidNumber(
      $("targetMinutes"), 1, 240, 5
    );

    state.targetJumps = getValidNumber(
      $("targetJumps"), 0, 1000000, 500
    );
  }

  function saveTargets() {
    readTargets();

    storage.saveSettings({
      targetMinutes: state.targetMinutes,
      targetJumps: state.targetJumps
    });

    updateJumpTarget();
    updateTimerProgress();
  }

  function loadSettings() {
    const settings = storage.getSettings();

    state.targetMinutes = settings.targetMinutes;
    state.targetJumps = settings.targetJumps;

    if ($("targetMinutes")) {
      $("targetMinutes").value = state.targetMinutes;
    }

    if ($("targetJumps")) {
      $("targetJumps").value = state.targetJumps;
    }
  }

  /* -----------------------------------------
     DATE AND DASHBOARD
  ----------------------------------------- */

  function renderDate() {
    const element = $("currentDate");
    if (!element) return;

    element.textContent = new Intl.DateTimeFormat("id-ID", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    }).format(new Date());
  }

  function refreshDashboard() {
    const stats = storage.getStats();

    if ($("todayJumps")) {
      $("todayJumps").textContent = formatNumber(stats.todayJumps);
    }

    if ($("todayDuration")) {
      const minutes = Math.floor(stats.todayDurationSeconds / 60);
      $("todayDuration").innerHTML =
        `${formatNumber(minutes)} <small>menit</small>`;
    }

    if ($("todaySessions")) {
      $("todaySessions").textContent =
        formatNumber(stats.todaySessionsCount);
    }

    if ($("bestJumps")) {
      $("bestJumps").textContent = formatNumber(stats.bestJumps);
    }

    if ($("bestDuration")) {
      $("bestDuration").innerHTML =
        `${formatNumber(Math.floor(stats.bestDurationSeconds / 60))} ` +
        "<small>mnt</small>";
    }

    if ($("historyCount")) {
      $("historyCount").textContent =
        `${formatNumber(stats.totalSessions)} sesi`;
    }

    updateLevel(stats.totalJumps);
    renderChart();
    renderHistory();
  }

  /* -----------------------------------------
     LEVEL AND XP
  ----------------------------------------- */

  function updateLevel(totalJumps) {
    const totalXP = Math.floor(Math.max(0, totalJumps) / 10);
    const level = Math.floor(totalXP / 100) + 1;
    const currentLevelXP = totalXP % 100;

    const ranks = [
      "Rookie",
      "Beginner",
      "Rope Cadet",
      "Jump Athlete",
      "Pro Jumper",
      "Elite Jumper",
      "Master Jumper",
      "Legend"
    ];

    const rankIndex = Math.min(level - 1, ranks.length - 1);

    if ($("levelName")) {
      $("levelName").textContent = ranks[rankIndex];
    }

    if ($("levelNumber")) {
      $("levelNumber").textContent = `LV. ${level}`;
    }

    if ($("xpText")) {
      $("xpText").textContent =
        `${currentLevelXP} / 100 XP menuju level berikutnya`;
    }

    if ($("xpBar")) {
      $("xpBar").style.width = `${currentLevelXP}%`;
    }

    if ($("xpProgress")) {
      $("xpProgress").setAttribute("aria-valuenow", currentLevelXP);
    }
  }

  /* -----------------------------------------
     TIMER
  ----------------------------------------- */

  function targetSeconds() {
    return Math.max(1, state.targetMinutes * 60);
  }

  function getElapsedSeconds() {
    if (state.running) {
      return state.elapsedBeforePause +
        Math.max(0, (Date.now() - state.startedAt) / 1000);
    }

    return state.elapsedBeforePause;
  }

  function updateTimerDisplay() {
    state.elapsedSeconds = Math.min(
      targetSeconds(),
      Math.floor(getElapsedSeconds())
    );

    if ($("timer")) {
      $("timer").textContent = formatDuration(state.elapsedSeconds);
    }

    updateTimerProgress();
    updatePace();
  }

  function updateTimerProgress() {
    const durationTarget = targetSeconds();
    const elapsed = Math.min(
      durationTarget,
      Math.max(0, state.elapsedSeconds)
    );

    const percent = Math.min(
      100,
      Math.max(0, (elapsed / durationTarget) * 100)
    );

    const roundedPercent = Math.floor(percent);

    if ($("timerProgressBar")) {
      $("timerProgressBar").style.width = `${percent}%`;
    }

    if ($("timerProgress")) {
      $("timerProgress").setAttribute(
        "aria-valuenow",
        String(roundedPercent)
      );
    }

    if ($("timerProgressText")) {
      $("timerProgressText").textContent = `${roundedPercent}%`;
    }
  }

  function updatePace() {
    const minutes = state.elapsedSeconds / 60;
    const pace = minutes > 0
      ? Math.round(state.sessionJumps / minutes)
      : 0;

    if ($("sessionPace")) {
      $("sessionPace").innerHTML =
        `${formatNumber(pace)} ` +
        '<small style="font:500 11px var(--font);color:var(--muted)">SPM</small>';
    }
  }

  function updateJumpTarget() {
    if (!$("jumpTargetProgress")) return;

    const target = state.targetJumps;
    const jumps = state.sessionJumps;

    $("jumpTargetProgress").textContent =
      `${formatNumber(jumps)} / ${formatNumber(target)}`;

    $("jumpTargetProgress").style.color =
      target > 0 && jumps >= target ? "var(--lime)" : "var(--text)";
  }

  function updateButtons() {
    if ($("startBtn")) {
      $("startBtn").disabled = state.running || state.finished;
    }

    if ($("pauseBtn")) {
      $("pauseBtn").disabled = !state.running;
      const span = $("pauseBtn").querySelector("span");

      if (span) span.textContent = "Jeda";
    }

    if ($("stopBtn")) {
      $("stopBtn").disabled =
        state.elapsedSeconds <= 0 && state.sessionJumps <= 0;
    }

    if ($("targetMinutes")) {
      $("targetMinutes").disabled = state.running || state.paused;
    }

    if ($("targetJumps")) {
      $("targetJumps").disabled = state.running || state.paused;
    }
  }

  function startTimer() {
    if (state.running || state.finished) return;

    if (!state.paused) {
      readTargets();

      state.elapsedBeforePause = 0;
      state.elapsedSeconds = 0;
      state.sessionJumps = 0;
      state.sessionId = null;

      if ($("sessionJumps")) {
        $("sessionJumps").textContent = "0";
      }

      updateJumpTarget();
      updatePace();
    }

    state.startedAt = Date.now();
    state.running = true;
    state.paused = false;

    if ($("timerStatus")) {
      $("timerStatus").textContent = "Latihan sedang berlangsung. Semangat!";
    }

    clearInterval(state.intervalId);

    state.intervalId = setInterval(tickTimer, 250);

    tickTimer();
    updateButtons();
  }

  function tickTimer() {
    if (!state.running) return;

    const elapsed = getElapsedSeconds();

    if (elapsed >= targetSeconds()) {
      state.elapsedBeforePause = targetSeconds();
      state.elapsedSeconds = targetSeconds();
      state.running = false;
      state.paused = false;
      state.finished = true;

      clearInterval(state.intervalId);
      state.intervalId = null;

      updateTimerDisplay();
      updateButtons();

      if ($("timerStatus")) {
        $("timerStatus").textContent =
          "Target durasi tercapai! Tekan Selesai untuk menyimpan sesi.";
      }

      showToast("Target durasi tercapai!");
      return;
    }

    updateTimerDisplay();
  }

  function pauseTimer() {
    if (!state.running) return;

    state.elapsedBeforePause = getElapsedSeconds();
    state.elapsedSeconds = Math.floor(state.elapsedBeforePause);
    state.running = false;
    state.paused = true;

    clearInterval(state.intervalId);
    state.intervalId = null;

    updateTimerDisplay();
    updateButtons();

    if ($("timerStatus")) {
      $("timerStatus").textContent =
        "Latihan dijeda. Tekan Mulai untuk melanjutkan.";
    }
  }

  function stopTimer() {
    if (state.running) {
      state.elapsedBeforePause = getElapsedSeconds();
    }

    clearInterval(state.intervalId);
    state.intervalId = null;

    state.elapsedSeconds = Math.floor(
      Math.min(targetSeconds(), state.elapsedBeforePause)
    );

    state.running = false;
    state.paused = false;

    const shouldSave =
      state.elapsedSeconds > 0 || state.sessionJumps > 0;

    if (shouldSave) {
      const session = {
        id: state.sessionId || undefined,
        date: localDateKey(new Date()),
        createdAt: Date.now(),
        startedAt: Date.now() - state.elapsedSeconds * 1000,
        durationSeconds: state.elapsedSeconds,
        jumps: state.sessionJumps,
        targetMinutes: state.targetMinutes,
        targetJumps: state.targetJumps
      };

      const saved = storage.saveSession(session);

      if (saved) {
        showToast("Sesi latihan berhasil disimpan!");
      } else {
        showToast("Gagal menyimpan. Periksa penyimpanan browser.");
      }

      refreshDashboard();
    } else {
      showToast("Belum ada latihan yang perlu disimpan.");
    }

    state.elapsedBeforePause = 0;
    state.elapsedSeconds = 0;
    state.sessionJumps = 0;
    state.finished = false;
    state.sessionId = null;

    if ($("timer")) $("timer").textContent = "00:00";
    if ($("sessionJumps")) $("sessionJumps").textContent = "0";

    if ($("timerStatus")) {
      $("timerStatus").textContent = "Siap memulai sesi latihan berikutnya?";
    }

    if ($("jumpInput")) $("jumpInput").value = "";

    updateTimerProgress();
    updatePace();
    updateJumpTarget();
    updateButtons();
  }

  /* -----------------------------------------
     JUMP INPUT
  ----------------------------------------- */

  function saveJumps() {
    const input = $("jumpInput");
    if (!input) return;

    const amount = Number(input.value);

    if (!Number.isFinite(amount) || amount <= 0 || !Number.isInteger(amount)) {
      showToast("Masukkan jumlah lompatan berupa bilangan bulat positif.");
      input.focus();
      return;
    }

    if (amount > 1000000) {
      showToast("Jumlah lompatan maksimal 1.000.000 per input.");
      return;
    }

    if (state.finished) {
      showToast("Sesi selesai. Tekan Selesai untuk menyimpan sesi ini.");
      return;
    }

    state.sessionJumps += amount;

    if ($("sessionJumps")) {
      $("sessionJumps").textContent = formatNumber(state.sessionJumps);
    }

    input.value = "";

    updatePace();
    updateJumpTarget();
    updateButtons();

    showToast(`${formatNumber(amount)} lompatan ditambahkan.`);
  }

  /* -----------------------------------------
     CHART
  ----------------------------------------- */

  function renderChart() {
    const area = $("chartArea");
    if (!area) return;

    const sessions = storage.getSessions();
    const period = Number($("chartPeriod")?.value) === 30 ? 30 : 7;

    const days = [];

    for (let offset = period - 1; offset >= 0; offset--) {
      const date = new Date();
      date.setHours(12, 0, 0, 0);
      date.setDate(date.getDate() - offset);

      days.push({
        key: localDateKey(date),
        label: period === 7
          ? new Intl.DateTimeFormat("id-ID", { weekday: "short" }).format(date)
          : String(date.getDate()),
        jumps: 0
      });
    }

    const dayMap = new Map(days.map(day => [day.key, day]));

    sessions.forEach(session => {
      const day = dayMap.get(session.date);

      if (day) {
        day.jumps += session.jumps;
      }
    });

    const totalJumps = days.reduce((sum, day) => sum + day.jumps, 0);
    const maxJumps = Math.max(1, ...days.map(day => day.jumps));

    if ($("totalJumpStat")) {
      $("totalJumpStat").textContent = formatNumber(totalJumps);
    }

    if (totalJumps === 0) {
      area.innerHTML = `
        <div class="chart-empty">
          <i data-lucide="chart-no-axes-combined"></i>
          <p>Grafikmu akan muncul setelah kamu menyelesaikan latihan.</p>
        </div>
      `;

      refreshIcons();
      return;
    }

    area.innerHTML = `
      <div class="skiptrack-chart">
        ${days.map(day => {
          const height = day.jumps > 0
            ? Math.max(3, (day.jumps / maxJumps) * 100)
            : 0;

          return `
            <div class="chart-column" title="${escapeHTML(day.key)}: ${formatNumber(day.jumps)} lompatan">
              <span class="chart-value">${day.jumps ? formatNumber(day.jumps) : ""}</span>
              <div class="chart-bar-track">
                <div class="chart-bar" style="height:${height}%"></div>
              </div>
              <span class="chart-label">${escapeHTML(day.label)}</span>
            </div>
          `;
        }).join("")}
      </div>
    `;

    refreshIcons();
  }

  /* -----------------------------------------
     HISTORY
  ----------------------------------------- */

  function formatDateTime(timestamp) {
    const date = new Date(timestamp);

    if (Number.isNaN(date.getTime())) return "Tanggal tidak tersedia";

    return new Intl.DateTimeFormat("id-ID", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }).format(date);
  }

  function renderHistory() {
    const list = $("historyList");
    if (!list) return;

    const sessions = storage.getSessions();

    if (!sessions.length) {
      list.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon"><i data-lucide="calendar-clock"></i></div>
          <h3>Belum ada riwayat</h3>
          <p>Setiap sesi yang kamu selesaikan akan tercatat di sini.</p>
        </div>
      `;

      refreshIcons();
      return;
    }

    list.innerHTML = sessions.map((session, index) => `
      <div class="history-item">
        <div class="history-info">
          <div class="history-title">Sesi latihan #${sessions.length - index}</div>
          <div class="history-date">${escapeHTML(formatDateTime(session.createdAt))}</div>
          <div class="history-details">
            ${formatNumber(session.jumps)} lompatan
            · ${escapeHTML(formatMinutes(session.durationSeconds))}
          </div>
        </div>
        <button
          type="button"
          class="history-delete"
          data-delete-session="${escapeHTML(session.id)}"
          aria-label="Hapus sesi ini"
        >Hapus</button>
      </div>
    `).join("");

    refreshIcons();
  }

  function deleteHistorySession(id) {
    if (!id) return;

    const deleted = storage.deleteSession(id);

    if (deleted) {
      refreshDashboard();
      showToast("Riwayat sesi berhasil dihapus.");
    } else {
      showToast("Sesi tidak ditemukan.");
    }
  }

  /* -----------------------------------------
     NAVIGATION
  ----------------------------------------- */

  function setupNavigation() {
    document.querySelectorAll(".nav-link").forEach(link => {
      link.addEventListener("click", () => {
        document.querySelectorAll(".nav-link").forEach(item => {
          item.classList.remove("active");
        });

        link.classList.add("active");
      });
    });

    if ($("profileBtn")) {
      $("profileBtn").addEventListener("click", () => {
        showToast("Semangat latihan! Progresmu tersimpan di perangkat ini.");
      });
    }
  }

  /* -----------------------------------------
     EVENT LISTENERS
  ----------------------------------------- */

  function setupEvents() {
    if ($("startBtn")) {
      $("startBtn").addEventListener("click", startTimer);
    }

    if ($("pauseBtn")) {
      $("pauseBtn").addEventListener("click", pauseTimer);
    }

    if ($("stopBtn")) {
      $("stopBtn").addEventListener("click", stopTimer);
    }

    if ($("saveJumpsBtn")) {
      $("saveJumpsBtn").addEventListener("click", saveJumps);
    }

    if ($("jumpInput")) {
      $("jumpInput").addEventListener("keydown", event => {
        if (event.key === "Enter") saveJumps();
      });
    }

    ["targetMinutes", "targetJumps"].forEach(id => {
      if ($(id)) {
        $(id).addEventListener("change", () => {
          if (state.running || state.paused) return;

          saveTargets();
          showToast("Target latihan diperbarui.");
        });
      }
    });

    if ($("chartPeriod")) {
      $("chartPeriod").addEventListener("change", renderChart);
    }

    if ($("historyList")) {
      $("historyList").addEventListener("click", event => {
        const button = event.target.closest("[data-delete-session]");
        if (!button) return;

        deleteHistorySession(button.dataset.deleteSession);
      });
    }

    document.addEventListener("visibilitychange", () => {
      if (state.running && !document.hidden) {
        tickTimer();
      }
    });

    window.addEventListener("beforeunload", () => {
      clearInterval(state.intervalId);
    });
  }

  /* -----------------------------------------
     INITIALIZATION
  ----------------------------------------- */

  function init() {
    loadSettings();
    renderDate();
    setupEvents();
    setupNavigation();

    state.elapsedSeconds = 0;
    state.elapsedBeforePause = 0;
    state.sessionJumps = 0;

    if ($("timer")) $("timer").textContent = "00:00";
    if ($("sessionJumps")) $("sessionJumps").textContent = "0";

    updateTimerProgress();
    updatePace();
    updateJumpTarget();
    updateButtons();

    refreshDashboard();
    refreshIcons();

    console.log("SkipTrack siap digunakan.");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
