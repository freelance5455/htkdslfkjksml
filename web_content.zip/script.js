// Local browser storage adapter. Records stay in this browser and are not synced online.
const STORAGE_KEY = 'tuition-fee-manager-data-v1';
const db = {};
const readStore = () => {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
  catch { return {}; }
};
const writeStore = store => localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
const makeId = () => globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const collection = (_db, name) => ({ kind: 'collection', name });
const doc = (first, second, third) => {
  if (first?.kind === 'collection') return { kind: 'document', name: first.name, id: makeId() };
  return { kind: 'document', name: second, id: third };
};
const query = (reference, ...filters) => ({ ...reference, filters: filters.filter(Boolean) });
const where = (field, operator, value) => ({ field, operator, value });
const serverTimestamp = () => new Date().toISOString();
const snapshot = (id, data) => ({ id, exists: () => data !== undefined, data: () => data });
const getDoc = async reference => {
  const data = readStore()[reference.name]?.[reference.id];
  return snapshot(reference.id, data);
};
const getDocs = async reference => {
  const records = Object.entries(readStore()[reference.name] || {}).filter(([, data]) =>
    (reference.filters || []).every(filter => filter.operator === '==' && data[filter.field] === filter.value)
  ).map(([id, data]) => snapshot(id, data));
  return { docs: records, empty: records.length === 0 };
};
const setDoc = async (reference, data, options = {}) => {
  const store = readStore(); store[reference.name] ||= {};
  store[reference.name][reference.id] = options.merge ? { ...store[reference.name][reference.id], ...data } : data;
  writeStore(store);
};
const updateDoc = async (reference, data) => {
  const store = readStore();
  if (!store[reference.name]?.[reference.id]) throw new Error('Record not found.');
  store[reference.name][reference.id] = { ...store[reference.name][reference.id], ...data }; writeStore(store);
};
const addDoc = async (reference, data) => {
  const id = makeId(); await setDoc({ name: reference.name, id }, data); return { id };
};
const runTransaction = async (_db, callback) => {
  const changes = [];
  const transaction = {
    get: async reference => {
      const data = readStore()[reference.name]?.[reference.id];
      return snapshot(reference.id, data);
    },
    set: (reference, data) => changes.push({ type: 'set', reference, data }),
    update: (reference, data) => changes.push({ type: 'update', reference, data })
  };
  const result = await callback(transaction);
  const store = readStore();
  for (const change of changes) {
    store[change.reference.name] ||= {};
    if (change.type === 'update' && !store[change.reference.name][change.reference.id]) throw new Error('Record not found.');
    store[change.reference.name][change.reference.id] = change.type === 'update'
      ? { ...store[change.reference.name][change.reference.id], ...change.data } : change.data;
  }
  writeStore(store);
  return result;
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const now = new Date();
const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
const appState = { user: null, profile: {}, students: [], fees: [], payments: [], classes: [], reminders: [], page: 'dashboard', language: localStorage.getItem('tfm-language') || 'en', filters: {} };
let toastTimer;
appState.user = { uid: 'local-teacher', email: '', displayName: 'Teacher' };

function notify(message, error = false) {
  const toast = $('#toast'); toast.textContent = message; toast.classList.toggle('error', error); toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 3600);
}
function setBusy(busy) { $('#loadingBar').classList.toggle('hidden', !busy); }
function money(value) { return `৳${Math.round(Number(value || 0)).toLocaleString('en-BD')}`; }
function safeDate(value) { if (!value) return ''; if (value.toDate) return value.toDate(); const date = new Date(value); return Number.isNaN(date.getTime()) ? '' : date; }
function dateText(value) { const date = safeDate(value); return date ? date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'; }
function monthName(month) { if (!month) return '—'; const [year, number] = month.split('-').map(Number); return new Date(year, number - 1, 1).toLocaleDateString(appState.language === 'bn' ? 'bn-BD' : 'en-BD', { month: 'long', year: 'numeric' }); }
function idInitial(name = '') { return name.trim().split(/\s+/).slice(0, 2).map(part => part[0] || '').join('').toUpperCase() || 'S'; }
function escapeHTML(value = '') { return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function monthOffset(month, amount) { const [year, number] = month.split('-').map(Number); const date = new Date(year, number - 1 + amount, 1); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`; }
function monthFromDate(value) { const date = safeDate(value); return date ? `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}` : ''; }
function getStatus(fee, month = fee.month) {
  const due = Math.max(0, Number(fee.expectedAmount || 0) - Number(fee.paidAmount || 0));
  if (due <= 0) return 'Paid';
  const dateMonth = currentMonth;
  if (month < dateMonth) return 'Overdue';
  return Number(fee.paidAmount || 0) > 0 ? 'Partial' : 'Unpaid';
}
function badge(status) { return `<span class="badge ${String(status).toLowerCase()}">${escapeHTML(status)}</span>`; }
function activeStudents() { return appState.students.filter(student => student.active !== false); }
function docCollection(name) { return collection(db, name); }
function ownedQuery(name) { return query(docCollection(name), where('teacherId', '==', appState.user.uid)); }

async function refreshData() {
  if (!appState.user) return;
  setBusy(true);
  try {
    const [studentSnap, feeSnap, paymentSnap, classSnap, reminderSnap, profileSnap] = await Promise.all([
      getDocs(ownedQuery('students')), getDocs(ownedQuery('feeRecords')), getDocs(ownedQuery('payments')),
      getDocs(ownedQuery('classes')), getDocs(ownedQuery('reminders')), getDoc(doc(db, 'teachers', appState.user.uid))
    ]);
    appState.students = studentSnap.docs.map(item => ({ id: item.id, ...item.data() }));
    appState.fees = feeSnap.docs.map(item => ({ id: item.id, ...item.data() }));
    appState.payments = paymentSnap.docs.map(item => ({ id: item.id, ...item.data() }));
    appState.classes = classSnap.docs.map(item => ({ id: item.id, ...item.data() }));
    appState.reminders = reminderSnap.docs.map(item => ({ id: item.id, ...item.data() }));
    if (profileSnap.exists()) appState.profile = profileSnap.data();
    renderAll();
  } catch (error) { notify(`Could not load data: ${error.message}`, true); }
  finally { setBusy(false); }
}

async function ensureMonthlyFees(month) {
  if (!appState.user || !month) return;
  const eligible = activeStudents();
  for (const student of eligible) {
    const recordId = `${student.id}_${month}`;
    const recordRef = doc(db, 'feeRecords', recordId);
    await runTransaction(db, async transaction => {
      const snapshot = await transaction.get(recordRef);
      if (!snapshot.exists()) transaction.set(recordRef, {
        teacherId: appState.user.uid, studentId: student.id, studentName: student.name || '', className: student.className || '', section: student.section || '', roll: student.roll || '',
        month, expectedAmount: Number(student.monthlyFee || 0), paidAmount: 0, dueAmount: Number(student.monthlyFee || 0), status: 'Unpaid', createdAt: serverTimestamp(), updatedAt: serverTimestamp()
      });
    });
  }
}

function setPage(page) {
  appState.page = page;
  $$('.page').forEach(section => section.classList.toggle('active', section.id === `page-${page}`));
  $$('.nav-item[data-page], .bottom-nav button[data-page]').forEach(button => button.classList.toggle('active', button.dataset.page === page));
  const name = { dashboard: 'Dashboard', students: 'Students', payments: 'Payments', reminders: 'Fee reminders', reports: 'Reports', settings: 'Settings' }[page] || 'Dashboard';
  $('#pageCrumb').textContent = name;
  if (page === 'payments') { $('#paymentsMonth').value ||= currentMonth; ensureMonthlyFees($('#paymentsMonth').value).then(refreshData).catch(error => notify(error.message, true)); }
  if (page === 'reminders') { $('#reminderMonth').value ||= currentMonth; ensureMonthlyFees($('#reminderMonth').value).then(refreshData).catch(error => notify(error.message, true)); }
  if (page === 'reports') prepareReportDates();
  $('.sidebar').classList.remove('mobile-open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function studentFor(id) { return appState.students.find(student => student.id === id); }
function feeForStudent(studentId, month) { return appState.fees.find(fee => fee.studentId === studentId && fee.month === month); }
function studentAvatarHTML(name = '', photoUrl = '') {
  return photoUrl
    ? `<img class="student-avatar" src="${escapeHTML(photoUrl)}" alt="${escapeHTML(name)} photo">`
    : `<span class="student-avatar">${escapeHTML(idInitial(name))}</span>`;
}
function paymentRows(items, limitRows = Infinity) {
  return items.slice(0, limitRows).map(payment => {
    const student = studentFor(payment.studentId); const name = payment.studentName || student?.name || 'Student';
    return `<tr><td><div class="student-cell"><span class="student-avatar">${escapeHTML(idInitial(name))}</span><span><b>${escapeHTML(name)}</b><small>${escapeHTML(payment.method || 'Payment')}</small></span></div></td><td><b>${money(payment.amount)}</b></td><td>${escapeHTML(monthName(payment.month))}</td><td>${dateText(payment.paymentDate || payment.createdAt)}</td><td>${badge('Paid')}</td></tr>`;
  }).join('');
}
function renderDashboard() {
  const month = $('#dashboardMonth').value || currentMonth;
  const classValue = $('#dashboardClassFilter').value; const sectionValue = $('#dashboardSectionFilter').value; const statusValue = $('#dashboardStatusFilter').value;
  const students = activeStudents().filter(student => (!classValue || student.className === classValue) && (!sectionValue || student.section === sectionValue));
  const eligibleIds = new Set(students.map(student => student.id));
  const monthFees = appState.fees.filter(fee => fee.month === month && eligibleIds.has(fee.studentId)).filter(fee => !statusValue || getStatus(fee, month) === statusValue);
  const feeIds = new Set(monthFees.map(fee => fee.id));
  const expected = monthFees.reduce((sum, fee) => sum + Number(fee.expectedAmount || 0), 0);
  const collected = appState.payments.filter(payment => payment.month === month && feeIds.has(payment.feeRecordId)).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const outstanding = monthFees.reduce((sum, fee) => sum + Math.max(0, Number(fee.expectedAmount || 0) - Number(fee.paidAmount || 0)), 0);
  const paidCount = monthFees.filter(fee => getStatus(fee, month) === 'Paid').length;
  const unpaidCount = monthFees.filter(fee => getStatus(fee, month) !== 'Paid').length;
  $('#statStudents').textContent = students.length.toLocaleString(); $('#statExpected').textContent = money(expected); $('#statCollected').textContent = money(collected); $('#statOutstanding').textContent = money(outstanding);
  $('#collectionHint').textContent = `${expected ? Math.round(collected / expected * 100) : 0}% of expected fees`;
  $('#unpaidCountHint').textContent = `${unpaidCount} unpaid / partial students`;
  $('#paidStudents').textContent = paidCount; $('#pendingStudents').textContent = unpaidCount;
  const percent = monthFees.length ? Math.round(paidCount / monthFees.length * 100) : 0; $('#paidPercent').textContent = `${percent}%`;
  $('#statusDonut').style.background = `conic-gradient(#35b482 ${percent * 3.6}deg,#edf0f5 ${percent * 3.6}deg)`;
  renderChart($('#collectionChart'), -5, month);
  const recent = [...appState.payments].filter(payment => eligibleIds.has(payment.studentId) && (!statusValue || getStatus(appState.fees.find(fee => fee.id === payment.feeRecordId) || {}, payment.month) === statusValue)).sort((a, b) => (safeDate(b.paymentDate || b.createdAt)?.getTime() || 0) - (safeDate(a.paymentDate || a.createdAt)?.getTime() || 0));
  $('#recentPayments').innerHTML = paymentRows(recent, 5);
  $('#recentEmpty').classList.toggle('hidden', recent.length > 0);
}
function renderChart(target, offset = -5, selectedMonth = currentMonth) {
  if (!target) return;
  const months = Array.from({ length: 6 }, (_, index) => monthOffset(selectedMonth, offset + index));
  const values = months.map(month => appState.payments.filter(payment => payment.month === month).reduce((sum, payment) => sum + Number(payment.amount || 0), 0));
  const max = Math.max(...values, 1);
  target.innerHTML = months.map((month, index) => `<div class="chart-column"><div class="chart-bar" style="height:${Math.max(values[index] ? 5 : 2, values[index] / max * 100)}%" data-value="${escapeHTML(money(values[index]))}"></div><span>${escapeHTML(new Date(Number(month.slice(0,4)), Number(month.slice(5))-1, 1).toLocaleDateString('en', { month: 'short' }))}</span></div>`).join('');
}
function fillClassFilters() {
  const classNames = [...new Set([...appState.classes.filter(item => !item.archived).map(item => item.name), ...appState.students.map(item => item.className)].filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  ['#classFilter', '#paymentClassFilter', '#dashboardClassFilter'].forEach(selector => {
    const select = $(selector); if (!select) return; const old = select.value;
    select.innerHTML = `<option value="">All classes</option>${classNames.map(name => `<option value="${escapeHTML(name)}">${escapeHTML(name)}</option>`).join('')}`; select.value = old;
  });
  const sections = [...new Set(appState.students.map(student => student.section).filter(Boolean))].sort();
  ['#sectionFilter', '#dashboardSectionFilter'].forEach(selector => { const section = $(selector); if (section) { const old = section.value; section.innerHTML = `<option value="">All sections</option>${sections.map(value => `<option value="${escapeHTML(value)}">${escapeHTML(value)}</option>`).join('')}`; section.value = old; } });
}
function renderStudents() {
  fillClassFilters();
  const search = ($('#studentSearch').value || '').toLowerCase().trim(); const classValue = $('#classFilter').value; const sectionValue = $('#sectionFilter').value;
  const students = appState.students.filter(student => {
    const matches = `${student.name} ${student.roll} ${student.guardianPhone || ''}`.toLowerCase().includes(search);
    return matches && (!classValue || student.className === classValue) && (!sectionValue || student.section === sectionValue);
  }).sort((a, b) => String(a.className).localeCompare(String(b.className), undefined, { numeric: true }) || String(a.roll).localeCompare(String(b.roll), undefined, { numeric: true }));
  $('#studentsTable').innerHTML = students.map(student => `<tr><td><div class="student-cell">${studentAvatarHTML(student.name, student.photoUrl)}<span><b>${escapeHTML(student.name || 'Student')}</b><small>${escapeHTML(student.studentCode || student.id.slice(0, 8))}</small></span></div></td><td>${escapeHTML(student.className || '—')}${student.group ? ` / ${escapeHTML(student.group)}` : ''} / ${escapeHTML(student.section || '—')}</td><td>${escapeHTML(student.roll || '—')}</td><td>${escapeHTML(student.guardianPhone || '—')}</td><td>${money(student.monthlyFee)}</td><td><div class="row-actions"><button class="small-action" data-student-view="${student.id}" title="View profile">View</button><button class="small-action" data-student-edit="${student.id}" title="Edit">Edit</button><button class="small-action" data-student-delete="${student.id}" title="Archive">⋯</button></div></td></tr>`).join('');
  $('#studentsEmpty').classList.toggle('hidden', students.length > 0);
}
function renderPayments() {
  fillClassFilters(); const month = $('#paymentsMonth').value || currentMonth; const classValue = $('#paymentClassFilter').value;
  const fees = appState.fees.filter(fee => fee.month === month).filter(fee => {
    const status = getStatus(fee, month); const student = studentFor(fee.studentId); const search = ($('#paymentSearch').value || '').toLowerCase();
    return (!$('#paymentStatusFilter').value || $('#paymentStatusFilter').value === status) && (!classValue || fee.className === classValue) && (!search || `${student?.name || fee.studentName} ${fee.roll}`.toLowerCase().includes(search));
  }).sort((a, b) => String(a.className).localeCompare(String(b.className), undefined, { numeric: true }) || String(a.roll).localeCompare(String(b.roll), undefined, { numeric: true }));
  $('#feesTable').innerHTML = fees.map(fee => {
    const due = Math.max(0, Number(fee.expectedAmount || 0) - Number(fee.paidAmount || 0)); const status = getStatus(fee, month);
    return `<tr><td><div class="student-cell"><span class="student-avatar">${escapeHTML(idInitial(fee.studentName))}</span><span><b>${escapeHTML(fee.studentName || 'Student')}</b><small>${escapeHTML(fee.section || '')}</small></span></div></td><td>${escapeHTML(fee.className || '—')} / ${escapeHTML(fee.roll || '—')}</td><td>${escapeHTML(monthName(month))}</td><td>${money(fee.expectedAmount)}</td><td>${money(fee.paidAmount)}</td><td><b>${money(due)}</b></td><td>${badge(status)}</td><td><button class="small-action" data-fee-payment="${fee.id}">＋ Pay</button></td></tr>`;
  }).join(''); $('#feesEmpty').classList.toggle('hidden', fees.length > 0);
  const totalExpected = fees.reduce((sum, fee) => sum + Number(fee.expectedAmount || 0), 0); const totalPaid = fees.reduce((sum, fee) => sum + Number(fee.paidAmount || 0), 0);
  $('#payExpected').textContent = money(totalExpected); $('#payCollected').textContent = money(totalPaid); $('#payOutstanding').textContent = money(Math.max(0, totalExpected - totalPaid));
  const payments = appState.payments.filter(payment => payment.month === month).sort((a,b) => (safeDate(b.paymentDate || b.createdAt)?.getTime() || 0) - (safeDate(a.paymentDate || a.createdAt)?.getTime() || 0));
  $('#paymentHistory').innerHTML = payments.map(payment => `<tr><td>${escapeHTML(payment.studentName || studentFor(payment.studentId)?.name || 'Student')}</td><td>${money(payment.amount)}</td><td>${escapeHTML(monthName(payment.month))}</td><td>${dateText(payment.paymentDate || payment.createdAt)}</td><td>${escapeHTML(payment.method || '—')}</td><td><button class="small-action" data-payment-edit="${payment.id}">Edit</button><button class="small-action" data-receipt="${payment.id}">Print</button></td></tr>`).join(''); $('#historyEmpty').classList.toggle('hidden', payments.length > 0);
}
function reminderMessage(student, fee) {
  const teacher = appState.profile.name || 'শিক্ষক';
  return `আসসালামু আলাইকুম। আপনার সন্তান ${student.name}, শ্রেণি ${student.className || ''}, রোল ${student.roll || ''}-এর ${monthName(fee.month)} মাসের টিউশন ফি ${money(Math.max(0, Number(fee.expectedAmount || 0) - Number(fee.paidAmount || 0))).replace('৳', '')} টাকা এখনো বকেয়া রয়েছে। অনুগ্রহ করে সুবিধামতো বকেয়া ফি পরিশোধ করবেন। ধন্যবাদ।\n— ${teacher}`;
}
function renderReminders() {
  const month = $('#reminderMonth').value || currentMonth;
  const list = appState.fees.filter(fee => fee.month === month && getStatus(fee, month) !== 'Paid').map(fee => ({ fee, student: studentFor(fee.studentId) })).filter(item => item.student && item.student.active !== false);
  $('#reminderList').innerHTML = list.map(({ fee, student }) => {
    const previous = appState.reminders.filter(item => item.studentId === student.id && item.month === month).sort((a,b) => (safeDate(b.sentAt)?.getTime() || 0) - (safeDate(a.sentAt)?.getTime() || 0))[0];
    const phone = (student.guardianPhone || '').replace(/\D/g, '').replace(/^0/, '880');
    return `<article class="reminder-card">${studentAvatarHTML(student.name, student.photoUrl)}<div class="reminder-main"><h3>${escapeHTML(student.name)} ${badge(getStatus(fee, month))}</h3><p>${escapeHTML(student.className || '')} · Roll ${escapeHTML(student.roll || '—')} · Section ${escapeHTML(student.section || '—')}<br>Guardian phone: ${escapeHTML(student.guardianPhone || 'Phone not added')}${previous ? `<br>Last reminder: ${dateText(previous.sentAt)} · ${escapeHTML(previous.channel || 'Message')}` : ''}</p></div><div class="reminder-due"><b>${money(Math.max(0, Number(fee.expectedAmount || 0) - Number(fee.paidAmount || 0)))}</b><small>${escapeHTML(monthName(month))} due</small></div><div class="reminder-actions"><button class="btn whatsapp-btn" data-remind="whatsapp" data-student="${student.id}" data-fee="${fee.id}" ${phone.length < 10 ? 'disabled title="Add a valid guardian phone"' : ''}>WhatsApp</button><button class="btn sms-btn" data-remind="sms" data-student="${student.id}" data-fee="${fee.id}" ${!student.guardianPhone ? 'disabled' : ''}>SMS</button></div></article>`;
  }).join(''); $('#remindersEmpty').classList.toggle('hidden', list.length > 0);
}
function prepareReportDates() {
  if (!$('#reportStart').value) $('#reportStart').value = `${currentMonth}-01`;
  if (!$('#reportEnd').value) { const [year, month] = currentMonth.split('-').map(Number); $('#reportEnd').value = new Date(year, month, 0).toISOString().slice(0, 10); }
  renderReports();
}
function reportDateRange() { return [$('#reportStart').value, $('#reportEnd').value]; }
function renderReports() {
  if (!$('#reportTable')) return;
  const [start, end] = reportDateRange(); const fromMonth = start ? start.slice(0, 7) : '0000-00'; const toMonth = end ? end.slice(0, 7) : '9999-99';
  const fees = appState.fees.filter(fee => fee.month >= fromMonth && fee.month <= toMonth).sort((a,b) => a.month.localeCompare(b.month) || String(a.className).localeCompare(String(b.className), undefined, { numeric: true }));
  const feeIds = new Set(fees.map(fee => fee.id)); const payments = appState.payments.filter(payment => payment.month >= fromMonth && payment.month <= toMonth && (!start || !end || (monthFromDate(payment.paymentDate || payment.createdAt) >= fromMonth && monthFromDate(payment.paymentDate || payment.createdAt) <= toMonth)));
  const paidByFee = new Map(); payments.forEach(payment => paidByFee.set(payment.feeRecordId, (paidByFee.get(payment.feeRecordId) || 0) + Number(payment.amount || 0)));
  const expected = fees.reduce((sum, fee) => sum + Number(fee.expectedAmount || 0), 0); const collected = payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0); const outstanding = fees.reduce((sum, fee) => sum + Math.max(0, Number(fee.expectedAmount || 0) - (paidByFee.get(fee.id) ?? Number(fee.paidAmount || 0))), 0);
  $('#reportExpected').textContent = money(expected); $('#reportCollected').textContent = money(collected); $('#reportOutstanding').textContent = money(outstanding); $('#reportRate').textContent = `${expected ? Math.min(100, Math.round(collected / expected * 100)) : 0}%`;
  const rows = fees.filter(fee => Math.max(0, Number(fee.expectedAmount || 0) - (paidByFee.get(fee.id) ?? Number(fee.paidAmount || 0))) > 0).map(fee => {
    const paid = paidByFee.get(fee.id) ?? Number(fee.paidAmount || 0); const due = Math.max(0, Number(fee.expectedAmount || 0) - paid);
    return `<tr><td>${escapeHTML(fee.studentName || studentFor(fee.studentId)?.name || 'Student')}</td><td>${escapeHTML(fee.className || '—')} / ${escapeHTML(fee.section || '—')}</td><td>${escapeHTML(monthName(fee.month))}</td><td>${money(fee.expectedAmount)}</td><td>${money(paid)}</td><td><b>${money(due)}</b></td><td>${badge(getStatus({ expectedAmount: fee.expectedAmount, paidAmount: paid }, fee.month))}</td></tr>`;
  }).join(''); $('#reportTable').innerHTML = rows; $('#reportEmpty').classList.toggle('hidden', rows.length > 0);
  const byClass = new Map(); fees.forEach(fee => byClass.set(fee.className || 'Unassigned', (byClass.get(fee.className || 'Unassigned') || 0) + (paidByFee.get(fee.id) ?? Number(fee.paidAmount || 0))));
  const max = Math.max(...byClass.values(), 1); $('#classReport').innerHTML = [...byClass].sort((a,b)=>b[1]-a[1]).map(([name, value]) => `<div class="report-bar-row"><span>${escapeHTML(name)}</span><span class="report-track"><i style="width:${value / max * 100}%"></i></span><b>${money(value)}</b></div>`).join('') || '<div class="empty-state"><p>No class collection data in this period.</p></div>';
  const months = [...new Set(fees.map(fee => fee.month))].sort().slice(-6); const target = $('#reportChart'); const values = months.map(month => payments.filter(payment => payment.month === month).reduce((sum,payment)=>sum+Number(payment.amount||0),0)); const high = Math.max(...values,1);
  target.innerHTML = months.length ? months.map((month,index)=>`<div class="chart-column"><div class="chart-bar" style="height:${Math.max(values[index]?5:2,values[index]/high*100)}%" data-value="${escapeHTML(money(values[index]))}"></div><span>${escapeHTML(new Date(Number(month.slice(0,4)), Number(month.slice(5))-1,1).toLocaleDateString('en',{month:'short'}))}</span></div>`).join('') : '<div class="empty-state"><p>No collections in this period.</p></div>';
}
function renderSettings() {
  const profile = appState.profile; $('#profileName').value = profile.name || appState.user?.displayName || ''; $('#profileCenter').value = profile.centerName || ''; $('#profilePhone').value = profile.phone || ''; $('#defaultFee').value = profile.defaultFee ?? 0; $('#dueDay').value = profile.dueDay || 10; $('#accountEmail').textContent = 'Stored in this browser on this device';
  $('#headerTeacher').textContent = profile.name || appState.user?.displayName || 'Teacher'; $('#welcomeName').textContent = profile.name || appState.user?.displayName || 'Teacher'; $('#avatarInitial').textContent = idInitial(profile.name || appState.user?.email || 'T').slice(0,1);
  $('#classList').innerHTML = appState.classes.filter(item => !item.archived).map(item => `<span class="class-chip">${escapeHTML(item.name)}${(item.sections || []).map(section => `<small>${escapeHTML(section)}</small>`).join('')}<button data-class-delete="${item.id}" aria-label="Delete ${escapeHTML(item.name)}">×</button></span>`).join('') || '<small class="table-sub">No custom classes yet. Students can use any class name.</small>';
  const sectionClass = $('#sectionClassSelect');
  if (sectionClass) { const old = sectionClass.value; sectionClass.innerHTML = `<option value="">Choose class</option>${appState.classes.filter(item => !item.archived).map(item => `<option value="${item.id}">${escapeHTML(item.name)}</option>`).join('')}`; sectionClass.value = old; }
}
function renderAll() {
  renderSettings(); renderDashboard(); renderStudents(); renderPayments(); renderReminders();
  if (!$('#reportStart').value) prepareReportDates(); else renderReports();
  applyLanguage();
}

function studentForm(student = {}) {
  const classOptions = [...new Set([...['Class 1','Class 2','Class 3','Class 4','Class 5','Class 6','Class 7','Class 8','Class 9','Class 10'], ...appState.classes.filter(item => !item.archived).map(item => item.name), ...(student.className ? [student.className] : [])])];
  const sectionOptions = [...new Set(appState.classes.flatMap(item => item.sections || []))];
  const seniorClass = student.className === 'Class 9' || student.className === 'Class 10';
  return `<form id="studentForm" class="modal-form"><label class="span-two">Student full name<input name="name" required maxlength="100" value="${escapeHTML(student.name || '')}"></label><label>Class<select name="className" required><option value="">Choose class</option>${classOptions.map(value=>`<option ${value===student.className?'selected':''}>${escapeHTML(value)}</option>`).join('')}<option value="__custom">＋ Custom class…</option></select></label><label class="group-field${seniorClass?'':' hidden'}">Group<select name="group"${seniorClass?' required':''}><option value="">Choose group</option>${['Science','Arts','Commerce'].map(value=>`<option value="${value}" ${value===student.group?'selected':''}>${value}</option>`).join('')}</select></label><label>Section<input name="section" list="sectionOptions" maxlength="30" value="${escapeHTML(student.section || '')}" placeholder="A, B…"><datalist id="sectionOptions">${sectionOptions.map(section=>`<option value="${escapeHTML(section)}">`).join('')}</datalist></label><label>Roll number<input name="roll" required maxlength="30" value="${escapeHTML(student.roll || '')}"></label><label>Monthly tuition fee (৳)<input name="monthlyFee" required type="number" min="0" step="1" value="${escapeHTML(student.monthlyFee ?? appState.profile.defaultFee ?? '')}"></label><label>Guardian phone<input name="guardianPhone" type="tel" placeholder="+880 1XXXXXXXXX" value="${escapeHTML(student.guardianPhone || '+880 ')}"></label><label>Admission date<input name="admissionDate" type="date" value="${escapeHTML(student.admissionDate || new Date().toISOString().slice(0,10))}"></label><label class="span-two">Student photo <span class="optional-label">optional</span><input name="photo" type="file" accept="image/*"><small>Choose a photo from your device. A new upload replaces the current photo.</small></label>${student.photoUrl ? `<div class="span-two">Current photo: ${studentAvatarHTML(student.name, student.photoUrl)}</div>` : ''}<div class="modal-actions"><button type="button" class="btn subtle" data-modal-cancel>Cancel</button><button class="btn primary" type="submit">${student.id ? 'Save changes' : 'Add student'}</button></div></form>`;
}
function paymentForm(fee) {
  const options = activeStudents().sort((a,b)=>a.name.localeCompare(b.name)).map(student=>`<option value="${student.id}" ${student.id===fee?.studentId?'selected':''}>${escapeHTML(student.name)} · ${escapeHTML(student.className || '')} #${escapeHTML(student.roll || '')}</option>`).join('');
  const student = fee ? studentFor(fee.studentId) : null;
  return `<form id="paymentForm" class="modal-form"><label class="span-two">Student & month<select name="feeRecordId" required>${options}</select><input type="month" name="month" required value="${escapeHTML(fee?.month || currentMonth)}"></label><label>Amount received (৳)<input name="amount" type="number" min="1" step="0.01" required value="${fee ? Math.max(1, Number(fee.expectedAmount || 0)-Number(fee.paidAmount || 0)) : ''}"></label><label>Payment date<input name="paymentDate" type="date" required value="${new Date().toISOString().slice(0,10)}"></label><label>Payment method<select name="method"><option>Cash</option><option>bKash</option><option>Nagad</option><option>Rocket</option><option>Bank</option><option>Other</option></select></label><label>Transaction ID<input name="transactionId" maxlength="100" placeholder="Optional"></label><label class="span-two">Notes<textarea name="notes" maxlength="500" placeholder="Optional payment notes"></textarea></label><div class="modal-actions"><button type="button" class="btn subtle" data-modal-cancel>Cancel</button><button class="btn primary" type="submit">Save payment</button></div></form>`;
}
function editPaymentForm(payment) {
  return `<form id="editPaymentForm" class="modal-form"><label>Amount received (৳)<input name="amount" type="number" min="0.01" step="0.01" required value="${escapeHTML(payment.amount)}"></label><label>Payment date<input name="paymentDate" type="date" required value="${escapeHTML(payment.paymentDate || '')}"></label><label>Payment method<select name="method">${['Cash','bKash','Nagad','Rocket','Bank','Other'].map(method=>`<option ${method===payment.method?'selected':''}>${method}</option>`).join('')}</select></label><label>Transaction ID<input name="transactionId" maxlength="100" value="${escapeHTML(payment.transactionId || '')}"></label><label class="span-two">Notes<textarea name="notes" maxlength="500">${escapeHTML(payment.notes || '')}</textarea></label><div class="modal-actions"><button type="button" class="btn subtle" data-modal-cancel>Cancel</button><button class="btn primary" type="submit">Save payment changes</button></div></form>`;
}
async function savePaymentEdit(payment, form) {
  const data = Object.fromEntries(new FormData(form).entries()); const amount = Number(data.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error('Payment amount must be greater than zero.');
  const transactionId = data.transactionId.trim();
  if (transactionId) {
    const duplicates = await getDocs(query(ownedQuery('payments'), where('transactionId', '==', transactionId)));
    if (duplicates.docs.some(item => item.id !== payment.id)) throw new Error('This transaction ID has already been recorded.');
  }
  const paymentRef = doc(db, 'payments', payment.id); const feeRef = doc(db, 'feeRecords', payment.feeRecordId);
  await runTransaction(db, async transaction => {
    const [paymentSnap, feeSnap] = await Promise.all([transaction.get(paymentRef), transaction.get(feeRef)]);
    if (!paymentSnap.exists() || paymentSnap.data().teacherId !== appState.user.uid || !feeSnap.exists() || feeSnap.data().teacherId !== appState.user.uid) throw new Error('Payment record not found or access denied.');
    const fee = feeSnap.data(); const nextPaid = Number(fee.paidAmount || 0) - Number(paymentSnap.data().amount || 0) + amount;
    if (nextPaid > Number(fee.expectedAmount || 0)) throw new Error(`Payment exceeds the remaining balance of ${money(Math.max(0, Number(fee.expectedAmount || 0) - Number(fee.paidAmount || 0) + Number(paymentSnap.data().amount || 0)))}.`);
    const due = Math.max(0, Number(fee.expectedAmount || 0) - nextPaid);
    transaction.update(paymentRef, { amount, paymentDate: data.paymentDate, method: data.method, transactionId, notes: data.notes.trim(), updatedAt: serverTimestamp() });
    transaction.update(feeRef, { paidAmount: nextPaid, dueAmount: due, status: due <= 0 ? 'Paid' : nextPaid > 0 ? 'Partial' : 'Unpaid', updatedAt: serverTimestamp() });
  });
  closeModal(); notify('Payment updated successfully.'); await refreshData();
}
function openModal(title, content, eyebrow = 'MANAGE RECORD') {
  $('#modalTitle').textContent = title; $('#modalEyebrow').textContent = eyebrow; $('#modalContent').innerHTML = content; $('#modalBackdrop').classList.remove('hidden');
  $('#modalContent').querySelector('input:not([type="hidden"]),select,textarea')?.focus();
}
function closeModal() { $('#modalBackdrop').classList.add('hidden'); $('#modalContent').innerHTML = ''; }
function studentProfile(student) {
  const payments = appState.payments.filter(payment => payment.studentId === student.id).sort((a,b)=>(safeDate(b.paymentDate||b.createdAt)?.getTime()||0)-(safeDate(a.paymentDate||a.createdAt)?.getTime()||0));
  const history = payments.length ? payments.map(payment=>`<tr><td>${escapeHTML(monthName(payment.month))}</td><td>${money(payment.amount)}</td><td>${dateText(payment.paymentDate)}</td><td>${escapeHTML(payment.method||'—')}</td><td><button class="small-action" data-receipt="${payment.id}">Receipt</button></td></tr>`).join('') : '<tr><td colspan="5">No payments recorded yet.</td></tr>';
  openModal(student.name, `<div class="profile-details">${student.photoUrl ? `<p>${studentAvatarHTML(student.name, student.photoUrl)}</p>` : ''}<p><b>Class / section:</b> ${escapeHTML(student.className||'—')}${student.group?` / ${escapeHTML(student.group)}`:''} / ${escapeHTML(student.section||'—')} &nbsp; <b>Roll:</b> ${escapeHTML(student.roll||'—')}</p><p><b>Guardian phone:</b> ${escapeHTML(student.guardianPhone||'Phone not added')}</p><p><b>Monthly fee:</b> ${money(student.monthlyFee)} &nbsp; <b>Admitted:</b> ${dateText(student.admissionDate)}</p><h3>Payment history</h3><div class="table-wrap"><table><thead><tr><th>MONTH</th><th>AMOUNT</th><th>DATE</th><th>METHOD</th><th></th></tr></thead><tbody>${history}</tbody></table></div><div class="modal-actions"><button class="btn subtle" data-modal-cancel>Close</button><button class="btn primary" data-student-edit="${student.id}">Edit student</button></div></div>`, 'STUDENT PROFILE');
}

async function compressStudentPhoto(file) {
  if (!file.type.startsWith('image/')) throw new Error('Please choose an image file.');
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Could not read the selected photo.'));
    reader.readAsDataURL(file);
  });
  const image = await new Promise((resolve, reject) => {
    const element = new Image();
    element.onload = () => resolve(element);
    element.onerror = () => reject(new Error('Could not open the selected photo.'));
    element.src = dataUrl;
  });
  const scale = Math.min(1, 480 / Math.max(image.naturalWidth, image.naturalHeight));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
  canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.75);
}
async function saveStudent(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  const originalId = form.dataset.studentId;
  const previous = originalId ? studentFor(originalId) : null;
  const photoFile = form.elements.photo.files[0];
  let photoUrl = previous?.photoUrl || '';
  if (photoFile) photoUrl = await compressStudentPhoto(photoFile);
  if (data.className === '__custom') { const name = prompt('Enter the class name'); if (!name?.trim()) return; data.className = name.trim(); await saveClassName(data.className); }
  const phone = data.guardianPhone.replace(/[\s()-]/g, '');
  if (phone && !/^\+?8801[3-9]\d{8}$/.test(phone)) { notify('Enter a Bangladesh mobile number, for example +880 1712345678.', true); return; }
  const studentId = originalId || doc(collection(db, 'students')).id;
  const duplicateQuery = query(ownedQuery('students'), where('className', '==', data.className), where('section', '==', data.section.trim()), where('roll', '==', data.roll.trim()));
  const dupSnap = await getDocs(duplicateQuery);
  if (dupSnap.docs.some(item => item.id !== studentId && item.data().active !== false)) { notify('A student with this class, section, and roll already exists.', true); return; }
  const record = { teacherId: appState.user.uid, name: data.name.trim(), className: data.className.trim(), group: ['Class 9', 'Class 10'].includes(data.className) ? data.group : '', section: data.section.trim(), roll: data.roll.trim(), guardianPhone: phone, monthlyFee: Number(data.monthlyFee), admissionDate: data.admissionDate, photoUrl, active: true, studentCode: previous?.studentCode || `ST-${studentId.slice(0, 7).toUpperCase()}`, updatedAt: serverTimestamp() };
  if (originalId) await updateDoc(doc(db, 'students', studentId), record); else await setDoc(doc(db, 'students', studentId), { ...record, createdAt: serverTimestamp() });
  closeModal(); notify(originalId ? 'Student profile updated.' : 'Student added successfully.');
  await refreshData(); await ensureMonthlyFees($('#dashboardMonth').value || currentMonth); await refreshData();
}
async function saveClassName(name) {
  const normalized = name.trim();
  if (!normalized || appState.classes.some(item => !item.archived && item.name.toLowerCase() === normalized.toLowerCase())) return false;
  await addDoc(docCollection('classes'), { teacherId: appState.user.uid, name: normalized, sections: [], createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
  return true;
}
async function savePayment(form) {
  const data = Object.fromEntries(new FormData(form).entries()); const selectedStudentId = data.feeRecordId; const month = data.month;
  await ensureMonthlyFees(month); await refreshData();
  const fee = feeForStudent(selectedStudentId, month);
  if (!fee) throw new Error('Fee record could not be created for this student and month.');
  const amount = Number(data.amount); if (!Number.isFinite(amount) || amount <= 0) throw new Error('Payment amount must be greater than zero.');
  if (data.transactionId.trim()) {
    const duplicate = await getDocs(query(ownedQuery('payments'), where('transactionId', '==', data.transactionId.trim())));
    if (!duplicate.empty) throw new Error('This transaction ID has already been recorded.');
  }
  const student = studentFor(selectedStudentId); const paymentRef = doc(collection(db, 'payments')); const feeRef = doc(db, 'feeRecords', fee.id);
  await runTransaction(db, async transaction => {
    const freshFeeSnap = await transaction.get(feeRef); if (!freshFeeSnap.exists() || freshFeeSnap.data().teacherId !== appState.user.uid) throw new Error('Fee record not found or access denied.');
    const freshFee = freshFeeSnap.data();
    const currentDue = Math.max(0, Number(freshFee.expectedAmount || 0) - Number(freshFee.paidAmount || 0));
    if (amount > currentDue) throw new Error(`Payment exceeds the remaining balance of ${money(currentDue)}.`);
    const paid = Number(freshFee.paidAmount || 0) + amount; const due = Math.max(0, Number(freshFee.expectedAmount || 0) - paid);
    transaction.set(paymentRef, { teacherId: appState.user.uid, studentId: selectedStudentId, studentName: student?.name || freshFee.studentName, feeRecordId: fee.id, month, amount, paymentDate: data.paymentDate, method: data.method, transactionId: data.transactionId.trim(), notes: data.notes.trim(), createdAt: serverTimestamp() });
    transaction.update(feeRef, { paidAmount: paid, dueAmount: due, status: due <= 0 ? 'Paid' : 'Partial', updatedAt: serverTimestamp() });
  });
  closeModal(); notify('Payment recorded successfully.'); await refreshData();
}
async function archiveStudent(id) {
  const student = studentFor(id); if (!student || !confirm(`Archive ${student.name}? Their payment history will be retained.`)) return;
  await updateDoc(doc(db, 'students', id), { active: false, archivedAt: serverTimestamp(), updatedAt: serverTimestamp() }); notify('Student archived; historical records are retained.'); await refreshData();
}
async function sendReminder(channel, studentId, feeId) {
  const student = studentFor(studentId); const fee = appState.fees.find(item => item.id === feeId); if (!student || !fee) return;
  let phone = (student.guardianPhone || '').replace(/\D/g, ''); phone = phone.replace(/^0/, '880');
  const message = reminderMessage(student, fee); const encoded = encodeURIComponent(message);
  if (channel === 'whatsapp') {
    if (phone.length < 10) { notify('Add a valid guardian mobile number first.', true); return; }
    window.open(`https://wa.me/${phone}?text=${encoded}`, '_blank', 'noopener,noreferrer');
  } else {
    if (!student.guardianPhone) { notify('Add a guardian mobile number first.', true); return; }
    window.location.href = `sms:${encodeURIComponent(student.guardianPhone)}?body=${encoded}`;
  }
  if (confirm(`Did you send the ${channel === 'sms' ? 'SMS' : 'WhatsApp'} reminder to the guardian at ${student.guardianPhone}?`)) {
    try { await addDoc(docCollection('reminders'), { teacherId: appState.user.uid, studentId, studentName: student.name, month: fee.month, feeRecordId: fee.id, channel, status: 'sent-confirmed', sentAt: serverTimestamp(), createdAt: serverTimestamp() }); notify('Reminder activity recorded.'); await refreshData(); }
    catch (error) { notify(`Message opened, but reminder tracking failed: ${error.message}`, true); }
  }
}
function printReceipt(paymentId) {
  const payment = appState.payments.find(item => item.id === paymentId); if (!payment) return;
  const student = studentFor(payment.studentId); const teacher = appState.profile;
  const content = `<html><head><title>Tuition fee receipt</title><style>body{font:15px Arial,sans-serif;max-width:680px;margin:35px auto;color:#23304a;padding:20px}.box{border:1px solid #dce2ec;border-radius:12px;padding:26px}.head{display:flex;justify-content:space-between;border-bottom:1px solid #ddd;padding-bottom:17px}h1{font-size:21px;margin:0 0 5px}.muted{color:#778197;font-size:12px}.amount{font-size:27px;font-weight:bold;margin:24px 0}.row{display:flex;justify-content:space-between;padding:11px 0;border-bottom:1px solid #eee}button{margin-top:22px;padding:11px 20px}@media print{button{display:none}}</style></head><body><div class="box"><div class="head"><div><h1>${escapeHTML(teacher.centerName || 'Tuition Fee Receipt')}</h1><span class="muted">${escapeHTML(teacher.name || 'Teacher')} ${teacher.phone ? '· '+escapeHTML(teacher.phone) : ''}</span></div><b>PAYMENT RECEIPT</b></div><p class="muted">Receipt ID: ${escapeHTML(payment.id.slice(0,12).toUpperCase())} · ${dateText(payment.paymentDate)}</p><div class="amount">${money(payment.amount)}</div><div class="row"><span>Student</span><b>${escapeHTML(payment.studentName || student?.name || '')}</b></div><div class="row"><span>Class / roll</span><b>${escapeHTML(student?.className || '')} / ${escapeHTML(student?.roll || '')}</b></div><div class="row"><span>Fee month</span><b>${escapeHTML(monthName(payment.month))}</b></div><div class="row"><span>Payment method</span><b>${escapeHTML(payment.method || '')}</b></div>${payment.transactionId?`<div class="row"><span>Transaction ID</span><b>${escapeHTML(payment.transactionId)}</b></div>`:''}<p class="muted">Thank you for your payment.</p><button onclick="window.print()">Print receipt</button></div></body></html>`;
  const win = window.open('', '_blank'); if (!win) { notify('Allow pop-ups to print the receipt.', true); return; } win.document.write(content); win.document.close();
}
function csvDownload(filename, rows) {
  const csv = rows.map(row => row.map(value => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' })); const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.click(); URL.revokeObjectURL(url);
}
function exportStudents() {
  csvDownload('tuition-students.csv', [['Student ID','Name','Class','Section','Roll','Guardian phone','Monthly fee','Admission date','Active'], ...appState.students.map(s=>[s.studentCode||s.id,s.name,s.className,s.section,s.roll,s.guardianPhone,s.monthlyFee,s.admissionDate,s.active!==false])]);
}
function exportReport() {
  const [start,end] = reportDateRange(); const rows = [['Student','Class','Section','Roll','Month','Expected BDT','Collected BDT','Outstanding BDT','Status']];
  appState.fees.filter(fee=>fee.month >= (start?.slice(0,7)||'0000-00') && fee.month <= (end?.slice(0,7)||'9999-99')).forEach(fee=>{
    const paid = appState.payments.filter(payment=>payment.feeRecordId===fee.id && (!start||monthFromDate(payment.paymentDate||payment.createdAt)>=start.slice(0,7)) && (!end||monthFromDate(payment.paymentDate||payment.createdAt)<=end.slice(0,7))).reduce((sum,payment)=>sum+Number(payment.amount||0),0);
    rows.push([fee.studentName,fee.className,fee.section,fee.roll,fee.month,fee.expectedAmount,paid,Math.max(0,fee.expectedAmount-paid),getStatus({expectedAmount:fee.expectedAmount,paidAmount:paid},fee.month)]);
  }); csvDownload('tuition-fee-report.csv', rows);
}
function applyLanguage() {
  const bangla = appState.language === 'bn'; document.documentElement.lang = bangla ? 'bn' : 'en';
  $('#languageToggle').textContent = bangla ? 'English' : 'বাংলা'; $('#settingsLanguage').textContent = bangla ? 'Switch to English' : 'Switch to বাংলা';
  const labels = { dashboard:['Dashboard','ড্যাশবোর্ড','▦'], students:['Students','শিক্ষার্থী','♙'], payments:['Payments','পেমেন্ট','৳'], reminders:['Fee reminders','ফি রিমাইন্ডার','◷'], reports:['Reports','রিপোর্ট','▤'], settings:['Settings','সেটিংস','⚙'] };
  $$('.nav-item[data-page], .bottom-nav button[data-page]').forEach(button => { const [english, translated, icon] = labels[button.dataset.page]; button.replaceChildren(Object.assign(document.createElement('span'), { textContent: icon }), document.createTextNode(bangla ? translated : english)); });
  const [englishPage, banglaPage] = labels[appState.page] || labels.dashboard;
  $('#pageCrumb').textContent = bangla ? banglaPage : englishPage;
}

$('#logoutButton').addEventListener('click', () => {
  if (!confirm('Delete all tuition records saved in this browser? This cannot be undone.')) return;
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem('tfm-local-session');
  window.location.reload();
});

$$('[data-page]').forEach(button => button.addEventListener('click', () => setPage(button.dataset.page)));
$$('[data-action="add-student"]').forEach(button => button.addEventListener('click', () => { openModal('Add a student', studentForm(), 'STUDENT PROFILE'); $('#studentForm').addEventListener('submit', async e=>{ e.preventDefault(); try { await saveStudent(e.currentTarget); } catch(error) { notify(`Could not save student: ${error.message}`,true); } }); bindCustomClass(); bindStudentGroup(); }));
$$('[data-action="record-payment"]').forEach(button => button.addEventListener('click', async () => { if (!activeStudents().length) return notify('Add a student before recording a payment.',true); try { await ensureMonthlyFees(currentMonth); await refreshData(); openModal('Record a payment', paymentForm(), 'PAYMENT ENTRY'); $('#paymentForm').addEventListener('submit', async e=>{e.preventDefault();try{await savePayment(e.currentTarget)}catch(error){notify(`Could not save payment: ${error.message}`,true)}}); bindPaymentMonth(); } catch(error) { notify(`Could not prepare fee record: ${error.message}`,true); } }));
function bindCustomClass() { const select = $('#studentForm select[name="className"]'); select?.addEventListener('change',()=>{ if(select.value==='__custom') {const name=prompt('Enter the class name'); if(name?.trim()) { saveClassName(name.trim()).then(refreshData).catch(error=>notify(error.message,true)); const option=new Option(name.trim(),name.trim(),true,true); select.add(option); } else select.value=''; } }); }
function bindStudentGroup() {
  const classSelect = $('#studentForm select[name="className"]');
  const groupLabel = $('#studentForm .group-field');
  const groupSelect = $('#studentForm select[name="group"]');
  const updateGroupField = () => {
    const needsGroup = ['Class 9', 'Class 10'].includes(classSelect.value);
    groupLabel.classList.toggle('hidden', !needsGroup);
    groupSelect.required = needsGroup;
    if (!needsGroup) groupSelect.value = '';
  };
  classSelect?.addEventListener('change', updateGroupField);
  updateGroupField();
}
function bindPaymentMonth() { const monthInput=$('#paymentForm input[name="month"]'); const studentSelect=$('#paymentForm select[name="feeRecordId"]'); monthInput?.addEventListener('change',async()=>{try{await ensureMonthlyFees(monthInput.value);await refreshData(); const old=studentSelect.value; const options=activeStudents().map(student=>{const fee=feeForStudent(student.id,monthInput.value);return fee?`<option value="${student.id}">${escapeHTML(student.name)} · ${escapeHTML(student.className||'')} #${escapeHTML(student.roll||'')}</option>`:''}).join('');studentSelect.innerHTML=options; if([...studentSelect.options].some(option=>option.value===old))studentSelect.value=old;}catch(error){notify(error.message,true)}}); }
$('#modalClose').addEventListener('click',closeModal); $('#modalBackdrop').addEventListener('click',event=>{if(event.target===$('#modalBackdrop'))closeModal()});
document.addEventListener('click', async event => {
  const target=event.target;
  if(target.closest('[data-modal-cancel]')) { closeModal(); return; }
  const view=target.closest('[data-student-view]'); if(view){const student=studentFor(view.dataset.studentView);if(student)studentProfile(student);return;}
  const edit=target.closest('[data-student-edit]'); if(edit){const student=studentFor(edit.dataset.studentEdit);if(!student)return;openModal('Edit student',studentForm(student),'STUDENT PROFILE');$('#studentForm').dataset.studentId=student.id;$('#studentForm').addEventListener('submit',async e=>{e.preventDefault();try{await saveStudent(e.currentTarget)}catch(error){notify(`Could not save student: ${error.message}`,true)}});bindCustomClass(); bindStudentGroup();return;}
  const del=target.closest('[data-student-delete]'); if(del){try{await archiveStudent(del.dataset.studentDelete)}catch(error){notify(`Could not archive student: ${error.message}`,true)}return;}
  const pay=target.closest('[data-fee-payment]'); if(pay){const fee=appState.fees.find(item=>item.id===pay.dataset.feePayment);if(fee){openModal('Record a payment',paymentForm(fee),'PAYMENT ENTRY');$('#paymentForm').addEventListener('submit',async e=>{e.preventDefault();try{await savePayment(e.currentTarget)}catch(error){notify(`Could not save payment: ${error.message}`,true)}});bindPaymentMonth()}return;}
  const paymentEdit=target.closest('[data-payment-edit]');if(paymentEdit){const payment=appState.payments.find(item=>item.id===paymentEdit.dataset.paymentEdit);if(payment){openModal('Edit payment',editPaymentForm(payment),'PAYMENT ENTRY');$('#editPaymentForm').addEventListener('submit',async e=>{e.preventDefault();try{await savePaymentEdit(payment,e.currentTarget)}catch(error){notify(`Could not update payment: ${error.message}`,true)}})}return;}
  const receipt=target.closest('[data-receipt]');if(receipt){printReceipt(receipt.dataset.receipt);return;}
  const reminder=target.closest('[data-remind]');if(reminder){await sendReminder(reminder.dataset.remind,reminder.dataset.student,reminder.dataset.fee);return;}
  const classDelete=target.closest('[data-class-delete]');if(classDelete){const item=appState.classes.find(row=>row.id===classDelete.dataset.classDelete);if(item&&confirm(`Remove class label “${item.name}”? Student records are unchanged.`)){try{await updateDoc(doc(db,'classes',item.id),{archived:true,updatedAt:serverTimestamp()});appState.classes=appState.classes.filter(row=>row.id!==item.id);renderSettings();renderStudents();notify('Class label removed.')}catch(error){notify(error.message,true)}}}
});
$('#studentSearch').addEventListener('input',renderStudents); $('#classFilter').addEventListener('change',renderStudents); $('#sectionFilter').addEventListener('change',renderStudents);
['dashboardClassFilter','dashboardSectionFilter','dashboardStatusFilter'].forEach(id=>$('#'+id).addEventListener('change',renderDashboard));
['paymentsMonth','paymentStatusFilter','paymentClassFilter'].forEach(id=>$('#'+id).addEventListener('change',async()=>{if(id==='paymentsMonth'){try{await ensureMonthlyFees($('#paymentsMonth').value);await refreshData()}catch(error){notify(error.message,true)}}else renderPayments()}));
$('#paymentSearch').addEventListener('input',renderPayments); $('#dashboardMonth').value=currentMonth; $('#dashboardMonth').addEventListener('change',async()=>{try{await ensureMonthlyFees($('#dashboardMonth').value);await refreshData()}catch(error){notify(error.message,true)}});
$('#reminderMonth').value=currentMonth; $('#reminderMonth').addEventListener('change',async()=>{try{await ensureMonthlyFees($('#reminderMonth').value);await refreshData()}catch(error){notify(error.message,true)}});
$('#applyReport').addEventListener('click',async()=>{const [start,end]=reportDateRange();if(start&&end&&start>end)return notify('Start date must be before the end date.',true);try{if(start&&end){const months=[];let month=start.slice(0,7);while(month<=end.slice(0,7)&&months.length<24){months.push(month);month=monthOffset(month,1)}for(const item of months)await ensureMonthlyFees(item);await refreshData()}renderReports()}catch(error){notify(`Could not prepare report: ${error.message}`,true)}});
$('#profileForm').addEventListener('submit',async event=>{event.preventDefault();const data={teacherId:appState.user.uid,name:$('#profileName').value.trim(),centerName:$('#profileCenter').value.trim(),phone:$('#profilePhone').value.trim(),defaultFee:Number($('#defaultFee').value||0),dueDay:Number($('#dueDay').value||10),currency:'BDT',updatedAt:serverTimestamp()};try{await setDoc(doc(db,'teachers',appState.user.uid),data,{merge:true});appState.profile={...appState.profile,...data};renderSettings();notify('Profile settings saved.')}catch(error){notify(`Could not save profile: ${error.message}`,true)}});
$('#classForm').addEventListener('submit',async event=>{event.preventDefault();try{const added=await saveClassName($('#newClassName').value);$('#newClassName').value='';await refreshData();notify(added?'Class added.':'That class already exists.')}catch(error){notify(`Could not add class: ${error.message}`,true)}});
$('#sectionForm').addEventListener('submit',async event=>{event.preventDefault();const classId=$('#sectionClassSelect').value;const sectionName=$('#newSectionName').value.trim();const classItem=appState.classes.find(item=>item.id===classId);if(!classItem||!sectionName)return;try{const sections=[...new Set([...(classItem.sections||[]),sectionName])];await updateDoc(doc(db,'classes',classId),{sections,updatedAt:serverTimestamp()});$('#newSectionName').value='';await refreshData();notify('Section added.')}catch(error){notify(`Could not add section: ${error.message}`,true)}});
$('#languageToggle').addEventListener('click',toggleLanguage);$('#settingsLanguage').addEventListener('click',toggleLanguage); function toggleLanguage(){appState.language=appState.language==='en'?'bn':'en';localStorage.setItem('tfm-language',appState.language);applyLanguage();renderDashboard();renderReports();}
$('#themeToggle').addEventListener('click',toggleTheme);$('#settingsTheme').addEventListener('click',toggleTheme);function toggleTheme(){document.body.classList.toggle('dark');localStorage.setItem('tfm-theme',document.body.classList.contains('dark')?'dark':'light')}
$('#mobileMenu').addEventListener('click',()=>notify('Use the bottom navigation to switch sections.'));
$$('[data-action="export-students"]').forEach(button=>button.addEventListener('click',exportStudents));
$$('[data-action="export-report"]').forEach(button=>button.addEventListener('click',exportReport));
$$('[data-action="backup"]').forEach(button=>button.addEventListener('click',()=>{csvDownload('tuition-students-backup.csv',[['Record type','ID','Data'],...appState.students.map(item=>['student',item.id,JSON.stringify(item)]),...appState.fees.map(item=>['feeRecord',item.id,JSON.stringify(item)]),...appState.payments.map(item=>['payment',item.id,JSON.stringify(item)])]);notify('Backup CSV downloaded.')}));
$$('[data-action="print-report"]').forEach(button=>button.addEventListener('click',()=>window.print()));

function applySavedTheme(){if(localStorage.getItem('tfm-theme')==='dark')document.body.classList.add('dark');}
async function initializeLocalApp() {
  $('#loginView').classList.add('hidden');
  $('#appView').classList.remove('hidden');
  $('#dashboardMonth').value = currentMonth;
  const profileRef = doc(db, 'teachers', appState.user.uid);
  const profileSnapshot = await getDoc(profileRef);
  if (!profileSnapshot.exists()) {
    await setDoc(profileRef, { teacherId: appState.user.uid, name: appState.user.displayName || 'Teacher', centerName: '', phone: '', defaultFee: 0, dueDay: 10, currency: 'BDT' });
  } else {
    appState.profile = profileSnapshot.data();
  }
  await refreshData();
  await ensureMonthlyFees(currentMonth);
  await refreshData();
}
$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault();
  const name = $('#loginName').value.trim();
  const email = $('#loginEmail').value.trim();
  if (!name) return notify('Please enter your name to continue.', true);
  appState.user = { uid: 'local-teacher', email, displayName: name };
  appState.profile = { ...appState.profile, name, email };
  try {
    await setDoc(doc(db, 'teachers', appState.user.uid), { teacherId: appState.user.uid, ...appState.profile, name, email, updatedAt: serverTimestamp() }, { merge: true });
    sessionStorage.setItem('tfm-local-session', 'active');
    await initializeLocalApp();
  } catch (error) { notify(`Could not open your workspace: ${error.message}`, true); }
});
async function bootLocalApp() {
  const profile = await getDoc(doc(db, 'teachers', 'local-teacher'));
  if (profile.exists()) {
    appState.profile = profile.data();
    $('#loginName').value = profile.data().name || '';
    $('#loginEmail').value = profile.data().email || '';
    appState.user = { uid: 'local-teacher', email: profile.data().email || '', displayName: profile.data().name || 'Teacher' };
  }
  if (sessionStorage.getItem('tfm-local-session') === 'active') await initializeLocalApp();
  else $('#loginView').classList.remove('hidden');
}
applySavedTheme();
bootLocalApp().catch(error => notify(`Could not load local records: ${error.message}`, true));
if('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost')) navigator.serviceWorker.register('./sw.js').catch(error=>console.info('Service worker unavailable:',error));
