'use strict';
/* ---------- Config & save ---------- */
const CAP = 4, MAXC = 12, LEVELS = 100, HINT_COST = 10, TUBE_COST = 30, MAX_EXTRA = 3;
const COLORS = ['#ff4d6d','#ff9f1c','#ffd60a','#38b000','#00c2a8','#1e90ff','#7b5cff','#e056fd','#8d5a3b','#9aa5b1','#ff7ab6','#00e5ff'];
const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const DEF = { unlocked: 1, done: {}, best: {}, coins: 50, sound: true };
function load() {
  try { return Object.assign({}, DEF, JSON.parse(localStorage.getItem('wsp_save') || '{}')); }
  catch (e) { return Object.assign({}, DEF); }
}
function save() { try { localStorage.setItem('wsp_save', JSON.stringify(S)); } catch (e) {} }
const S = load();
S.coins = Math.max(0, S.coins | 0);

/* ---------- Puzzle logic ---------- */
const clone = t => t.map(x => x.slice());
// Number of units that would move from i to j (0 = illegal). Whole top group must fit.
function amt(t, i, j) {
  const a = t[i], b = t[j];
  if (i === j || !a.length || b.length >= CAP) return 0;
  const c = a[a.length - 1];
  if (b.length && b[b.length - 1] !== c) return 0;
  let n = 0;
  for (let k = a.length - 1; k >= 0 && a[k] === c; k--) n++;
  return CAP - b.length >= n ? n : 0;
}
function isWon(t) {
  const seen = new Set();
  for (const x of t) {
    if (!x.length) continue;
    if (x.some(c => c !== x[0]) || seen.has(x[0])) return false;
    seen.add(x[0]);
  }
  return true;
}
// Depth-first solver (returns list of [from,to] or null). Used to guarantee solvability and for hints.
function solve(t0, cap) {
  let nodes = 0; const seen = new Set(), path = [];
  const key = t => t.map(x => x.map(c => c.toString(36)).join('')).sort().join('|');
  function dfs(t, d) {
    if (isWon(t)) return true;
    if (d > 300 || nodes > cap) return false;
    const k = key(t); if (seen.has(k)) return false;
    seen.add(k); nodes++;
    const mv = [];
    for (let i = 0; i < t.length; i++) for (let j = 0; j < t.length; j++) {
      const n = amt(t, i, j);
      if (!n || (!t[j].length && t[i].length === n)) continue; // skip pointless moves
      mv.push([i, j, n, t[j].length ? 1 : 0]);
    }
    mv.sort((x, y) => y[3] - x[3] || y[2] - x[2]);
    for (const [i, j, n] of mv) {
      const u = clone(t); u[j].push(...u[i].splice(-n));
      path.push([i, j]);
      if (dfs(u, d + 1)) return true;
      path.pop();
    }
    return false;
  }
  return dfs(t0, 0) ? path.slice() : null;
}
function rng(a) {
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
const cache = {};
function puzzle(L) {
  if (cache[L]) return cache[L];
  const n = Math.min(MAXC, 3 + Math.floor((L - 1) / 9)); // 3 colours at level 1 → 12 colours
  let tubes;
  for (let a = 0; a < 300; a++) {
    const r = rng(L * 7919 + a * 104729), u = [];
    for (let c = 0; c < n; c++) for (let k = 0; k < CAP; k++) u.push(c);
    for (let i = u.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [u[i], u[j]] = [u[j], u[i]]; }
    tubes = [];
    for (let i = 0; i < n; i++) tubes.push(u.slice(i * CAP, i * CAP + CAP));
    tubes.push([], []); // two empty tubes
    if (!isWon(tubes) && solve(tubes, 15000)) break; // verified solvable
  }
  return cache[L] = tubes;
}

/* ---------- Audio ---------- */
let AC;
function tone(f, d, type = 'sine', v = .15, when = 0, slide = 0) {
  if (!S.sound) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime + when;
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.linearRampToValueAtTime(f + slide, t + d);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.001, t + d);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d);
  } catch (e) {}
}
const sfx = {
  select: () => tone(560, .1, 'triangle'),
  pour: () => { for (let i = 0; i < 5; i++) tone(300 + i * 40, .12, 'sine', .1, i * .08, 120); },
  err: () => tone(150, .2, 'sawtooth', .08),
  win: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, .3, 'triangle', .18, i * .13)),
  coin: () => tone(880, .12, 'square', .06)
};

/* ---------- Game state ---------- */
const G = { level: 1, tubes: [], hist: [], moves: 0, extra: 0, sel: -1, busy: false, paused: false, won: false };
const board = $('board');

function startLevel(L) {
  G.level = L; G.tubes = clone(puzzle(L)); G.hist = []; G.moves = 0; G.extra = 0;
  G.sel = -1; G.busy = false; G.won = false;
  board.classList.remove('won'); [...board.children].forEach(e => { e.style.transform = ''; e.className = 'tube'; });
  hide('winModal'); layout(); render();
}
function layout() {
  const n = G.tubes.length, W = Math.min(innerWidth - 24, 920), per = n <= 6 ? n : Math.ceil(n / 2), rows = n <= 6 ? 1 : 2;
  const tw = Math.max(30, Math.min(62, Math.floor((W - (per - 1) * 12) / per)));
  const th = Math.max(120, Math.min(tw * 3.5, (innerHeight - 330) / rows - 26));
  board.style.setProperty('--tw', tw + 'px'); board.style.setProperty('--th', th + 'px');
  board.style.maxWidth = (per * (tw + 12) + 6) + 'px';
}
function render(ni = -1, nn = 0) {
  while (board.children.length < G.tubes.length) {
    const d = document.createElement('div'), idx = board.children.length;
    d.className = 'tube'; d.onclick = () => tap(idx); board.appendChild(d);
  }
  while (board.children.length > G.tubes.length) board.lastChild.remove();
  G.tubes.forEach((t, i) => {
    const el = board.children[i];
    el.innerHTML = t.map((c, k) => `<i class="l${i === ni && k >= t.length - nn ? ' in' : ''}" style="background-color:${COLORS[c]}"></i>`).join('');
    el.classList.toggle('sel', i === G.sel);
  });
  $('level').textContent = G.level; $('moves').textContent = G.moves;
  $('best').textContent = S.best[G.level] || '–'; $('coins').textContent = S.coins;
  $('undo').disabled = !G.hist.length; $('next').disabled = !S.done[G.level] || G.level >= LEVELS;
  $('hint').disabled = $('addTube').disabled = false;
  $('soundIcon').textContent = S.sound ? '🔊' : '🔇'; $('sound').classList.toggle('off', !S.sound);
}
const clearHint = () => [...board.children].forEach(e => e.classList.remove('hint'));
function toast(m) { const t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.id); toast.id = setTimeout(() => t.classList.remove('show'), 1800); }
const show = id => $(id).classList.remove('hidden'), hide = id => $(id).classList.add('hidden');

/* ---------- Input & pouring ---------- */
function tap(i) {
  if (G.busy || G.paused || G.won) return;
  clearHint();
  if (G.sel < 0) { if (!G.tubes[i].length) return; G.sel = i; sfx.select(); render(); return; }
  if (G.sel === i) { G.sel = -1; render(); return; }
  const from = G.sel; G.sel = -1;
  if (amt(G.tubes, from, i)) doPour(from, i);
  else { sfx.err(); render(); const el = board.children[i]; el.classList.add('shake'); setTimeout(() => el.classList.remove('shake'), 400); }
}
async function doPour(i, j) {
  G.busy = true; render();
  const n = amt(G.tubes, i, j), color = G.tubes[i][G.tubes[i].length - 1];
  const a = board.children[i], b = board.children[j], ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
  const dir = rb.left > ra.left ? 1 : -1, h = ra.height, ang = 68 * Math.PI / 180;
  const tx = (rb.left + rb.width / 2) - (ra.left + ra.width / 2) - dir * Math.sin(ang) * h / 2;
  const ty = rb.top - ra.top - 0.36 * h;
  a.classList.add('moving'); a.style.transform = `translate(${tx}px,${ty}px) rotate(${dir * 68}deg)`;
  await sleep(400); sfx.pour();
  const surf = rb.bottom - 3 - (G.tubes[j].length / CAP) * (rb.height - 3);
  const s = document.createElement('div'); s.className = 'stream'; s.style.background = COLORS[color];
  s.style.left = (rb.left + rb.width / 2) + 'px'; s.style.top = (rb.top - 0.04 * h) + 'px'; s.style.height = Math.max(8, surf - rb.top + 0.04 * h) + 'px';
  document.body.appendChild(s);
  await sleep(150);
  G.hist.push(clone(G.tubes));
  G.tubes[j].push(...G.tubes[i].splice(-n)); G.moves++;
  render(j, n);
  await sleep(350); s.remove(); a.style.transform = '';
  await sleep(400); a.classList.remove('moving');
  G.busy = false; render();
  if (isWon(G.tubes)) win();
}

/* ---------- Win / rewards ---------- */
function win() {
  G.won = true; board.classList.add('won');
  const first = !S.done[G.level], reward = first ? 20 + Math.floor(G.level / 5) * 2 : 5;
  S.coins += reward; S.done[G.level] = 1;
  if (!S.best[G.level] || G.moves < S.best[G.level]) S.best[G.level] = G.moves;
  S.unlocked = Math.max(S.unlocked, Math.min(LEVELS, G.level + 1)); save(); sfx.win();
  $('winText').textContent = `Solved in ${G.moves} moves. Best: ${S.best[G.level]}. +${reward} coins${first ? '' : ' (replay)'}`;
  $('winNext').disabled = G.level >= LEVELS;
  const c = $('confetti'); c.innerHTML = '';
  for (let k = 0; k < 50; k++) {
    const p = document.createElement('b');
    p.style.cssText = `left:${Math.random() * 100}%;background:${COLORS[k % COLORS.length]};animation-duration:${2 + Math.random() * 2}s;animation-delay:${Math.random()}s`;
    c.appendChild(p);
  }
  setTimeout(() => { show('winModal'); render(); }, 900);
}

/* ---------- Buttons ---------- */
$('undo').onclick = () => {
  if (G.busy || G.paused || G.won || !G.hist.length) return;
  G.tubes = G.hist.pop(); G.moves = Math.max(0, G.moves - 1); G.sel = -1; clearHint(); sfx.select(); layout(); render();
};
$('restart').onclick = () => { if (!G.busy) { startLevel(G.level); toast('Level restarted'); } };
$('hint').onclick = () => {
  if (G.busy || G.paused || G.won) return;
  if (S.coins < HINT_COST) { sfx.err(); return toast(`Need ${HINT_COST} coins for a hint`); }
  let mv = (solve(clone(G.tubes), 20000) || [])[0];
  if (!mv) { // fallback: any legal, useful move
    outer: for (let i = 0; i < G.tubes.length; i++) for (let j = 0; j < G.tubes.length; j++)
      if (amt(G.tubes, i, j) && !(G.tubes[j].length === 0 && new Set(G.tubes[i]).size === 1)) { mv = [i, j]; break outer; }
  }
  if (!mv) { sfx.err(); return toast('No moves left. Try Undo, Restart or Add Tube'); }
  S.coins -= HINT_COST; save(); sfx.coin(); G.sel = -1; render(); clearHint();
  board.children[mv[0]].classList.add('hint'); board.children[mv[1]].classList.add('hint');
  toast('Pour the glowing tube into the other one');
};
$('addTube').onclick = () => {
  if (G.busy || G.paused || G.won) return;
  if (G.extra >= MAX_EXTRA) return toast(`Max ${MAX_EXTRA} extra tubes per level`);
  if (S.coins < TUBE_COST) { sfx.err(); return toast(`Need ${TUBE_COST} coins for a tube`); }
  S.coins -= TUBE_COST; G.extra++; G.tubes.push([]); G.hist.forEach(h => h.push([]));
  save(); sfx.coin(); clearHint(); layout(); render();
};
$('sound').onclick = () => { S.sound = !S.sound; save(); render(); sfx.select(); };
$('pause').onclick = () => { if (G.busy) return toast('Wait for the pour to finish'); G.paused = true; show('pauseModal'); };
$('resume').onclick = () => { G.paused = false; hide('pauseModal'); };
$('next').onclick = goNext; $('winNext').onclick = goNext;
function goNext() { if (S.done[G.level] && G.level < LEVELS && !G.busy) startLevel(G.level + 1); }
function openLevels() {
  if (G.busy) return;
  const g = $('levelGrid'); g.innerHTML = '';
  for (let L = 1; L <= LEVELS; L++) {
    const b = document.createElement('button'), ok = L <= S.unlocked;
    b.textContent = ok ? (S.done[L] ? L + ' ✓' : L) : '🔒'; b.disabled = !ok;
    if (S.done[L]) b.className = 'done'; if (L === G.level) b.classList.add('cur');
    b.onclick = () => { hide('levelModal'); startLevel(L); };
    g.appendChild(b);
  }
  hide('winModal'); show('levelModal');
}
$('levels').onclick = openLevels; $('winLevels').onclick = openLevels;
$('closeLevels').onclick = () => hide('levelModal');
addEventListener('resize', layout);

/* ---------- Init ---------- */
startLevel(Math.min(S.unlocked, LEVELS));
