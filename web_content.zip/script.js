// Paste clipboard functionality
async function pasteClipboard() {
  try {
    const text = await navigator.clipboard.readText();
    document.getElementById('mediaUrl').value = text;
  } catch (err) {
    alert('Kripya link ko manually box me paste karein!');
  }
}

// Identify Platform
function detectPlatform(url) {
  if (url.includes('instagram.com')) return 'Instagram';
  if (url.includes('youtube.com') || url.includes('youtu.be')) return 'YouTube';
  if (url.includes('pinterest.com') || url.includes('pin.it')) return 'Pinterest';
  return 'Direct Link';
}

// Process Download
async function processDownload() {
  const urlInput = document.getElementById('mediaUrl');
  const rawUrl = urlInput.value.trim();

  if (!rawUrl) {
    alert('Pehle kisi video ya photo ka link enter karein!');
    return;
  }

  const loader = document.getElementById('loader');
  const resultCard = document.getElementById('resultCard');
  const platform = detectPlatform(rawUrl);

  resultCard.style.display = 'none';
  loader.style.display = 'block';

  // Real-world public API / Resolver fallback
  try {
    let downloadLink = '';
    let previewType = 'video';
    let previewUrl = '';
    let title = `${platform} Media Content`;

    // Fast-resolution API for Social Media
    const apiUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(rawUrl)}`;
    
    // Simulated instant extractor or direct media handler
    setTimeout(() => {
      loader.style.display = 'none';
      resultCard.style.display = 'flex';

      document.getElementById('detectedPlatformBadge').innerText = platform;

      if (platform === 'YouTube') {
        // High quality preview thumbnail for YouTube
        let videoId = '';
        if (rawUrl.includes('youtu.be/')) {
          videoId = rawUrl.split('youtu.be/')[1].split('?')[0];
        } else if (rawUrl.includes('v=')) {
          videoId = rawUrl.split('v=')[1].split('&')[0];
        } else if (rawUrl.includes('shorts/')) {
          videoId = rawUrl.split('shorts/')[1].split('?')[0];
        }

        if (videoId) {
          previewUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
          previewType = 'image';
        } else {
          previewUrl = 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=600&q=80';
          previewType = 'image';
        }
        title = 'YouTube Video / Shorts';
        // Redirection download endpoint
        downloadLink = `https://www.y2mate.com/youtube/${videoId || ''}`;
      } else if (platform === 'Instagram') {
        previewUrl = 'https://images.unsplash.com/photo-1611262588024-d12430b98920?auto=format&fit=crop&w=600&q=80';
        previewType = 'image';
        title = 'Instagram Reel / Photo';
        downloadLink = `https://fastdl.app/en?url=${encodeURIComponent(rawUrl)}`;
      } else if (platform === 'Pinterest') {
        previewUrl = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80';
        previewType = 'image';
        title = 'Pinterest Pin / Video';
        downloadLink = `https://pinterestdownloader.com/?url=${encodeURIComponent(rawUrl)}`;
      } else {
        previewUrl = rawUrl;
        previewType = rawUrl.match(/\.(mp4|webm|ogg)$/i) ? 'video' : 'image';
        title = 'Direct Web Media';
        downloadLink = rawUrl;
      }

      // Render Preview
      const previewArea = document.getElementById('previewContainer');
      if (previewType === 'video') {
        previewArea.innerHTML = `<video src="${previewUrl}" controls playsinline></video>`;
      } else {
        previewArea.innerHTML = `<img src="${previewUrl}" alt="Media Preview" onerror="this.src='https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80';">`;
      }

      document.getElementById('resultTitle').innerText = title;
      document.getElementById('mediaTypeBadge').innerText = previewType.toUpperCase();
      
      const dlBtn = document.getElementById('directDownloadBtn');
      dlBtn.href = downloadLink;

    }, 1200);

  } catch (e) {
    loader.style.display = 'none';
    alert('Media fetch karne me dikkat aayi. Link check karein.');
  }
}

function shareMedia() {
  const url = document.getElementById('mediaUrl').value;
  if (navigator.share) {
    navigator.share({
      title: 'Downloaded Media',
      url: url || window.location.href
    }).catch(() => {});
  } else {
    alert('Link ready to share!');
  }
}
