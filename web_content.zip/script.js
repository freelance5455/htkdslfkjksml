const engines = [
  {id:"google",name:"Google",url:q=>"https://www.google.com/search?q="+encodeURIComponent(q),note:"Pesquisa web pelo Google"},
  {id:"brave",name:"Brave Search",url:q=>"https://search.brave.com/search?q="+encodeURIComponent(q),note:"Pesquisa web pelo Brave"},
  {id:"yandex",name:"Yandex",url:q=>"https://yandex.com/search/?text="+encodeURIComponent(q),note:"Pesquisa web pelo Yandex"},
  {id:"duckduckgo",name:"DuckDuckGo",url:q=>"https://duckduckgo.com/?q="+encodeURIComponent(q),note:"Pesquisa web pelo DuckDuckGo"},
  {id:"mojeek",name:"Mojeek",url:q=>"https://www.mojeek.com/search?q="+encodeURIComponent(q),note:"Pesquisa web pelo Mojeek"},
  {id:"startpage",name:"Startpage",url:q=>"https://www.startpage.com/sp/search?query="+encodeURIComponent(q),note:"Pesquisa web pelo Startpage"}
];
const defaults={enabled:engines.map(e=>e.id),limit:20,profile:"equilibrado"};
let settings={...defaults};
try{const saved=JSON.parse(localStorage.getItem("multisearch-settings")||"null");if(saved)settings={...defaults,...saved};}catch(e){}
const $=id=>document.getElementById(id);
function renderChoices(){
  $("engineChoices").innerHTML=engines.map(e=>`<label class="engine-choice"><input type="checkbox" value="${e.id}" ${settings.enabled.includes(e.id)?"checked":""}><span>${e.name}</span></label>`).join("");
  $("selectedCount").textContent=settings.enabled.length+" buscadores selecionados";
  $("engineChoices").querySelectorAll("input").forEach(input=>input.addEventListener("change",()=>{
    settings.enabled=[...$("engineChoices").querySelectorAll("input:checked")].map(x=>x.value);
    $("selectedCount").textContent=settings.enabled.length+" buscadores selecionados";
    renderCards();
  }));
}
function renderCards(){
  $("results").innerHTML=engines.filter(e=>settings.enabled.includes(e.id)).map(e=>`<article class="engine-card"><div><strong>${e.name}</strong><small>${e.note} • abre no navegador</small></div><button data-engine="${e.id}">Abrir pesquisa ↗</button></article>`).join("");
  $("results").querySelectorAll("button").forEach(btn=>btn.addEventListener("click",()=>openEngine(btn.dataset.engine)));
}
function openEngine(id){
  const q=$("query").value.trim();
  if(!q){$("query").focus();$("status").textContent="Digite algo para pesquisar";return;}
  const e=engines.find(x=>x.id===id);if(!e)return;
  window.open(e.url(q),"_blank");
  $("status").textContent="Pesquisa aberta em "+e.name;
}
function searchAll(){
  const q=$("query").value.trim();
  if(!q){$("query").focus();$("status").textContent="Digite algo para pesquisar";return;}
  if(!settings.enabled.length){$("status").textContent="Selecione pelo menos um buscador";return;}
  $("status").textContent="Escolha um buscador abaixo para abrir a pesquisa. Alguns WebViews bloqueiam várias janelas simultâneas.";
  renderCards();
}
$("searchBtn").addEventListener("click",searchAll);
$("query").addEventListener("keydown",e=>{if(e.key==="Enter")searchAll();});
$("settingsBtn").addEventListener("click",()=>{$("settings").classList.remove("hidden");$("resultLimit").value=settings.limit;});
$("closeSettings").addEventListener("click",()=>$("settings").classList.add("hidden"));
$("saveSettings").addEventListener("click",()=>{
  settings.limit=Number($("resultLimit").value);
  settings.profile=$("profile").value;
  localStorage.setItem("multisearch-settings",JSON.stringify(settings));
  $("saveMessage").textContent="Configurações salvas neste aparelho.";
});
$("resetSettings").addEventListener("click",()=>{
  settings={...defaults};$("profile").value=defaults.profile;$("resultLimit").value=defaults.limit;
  localStorage.setItem("multisearch-settings",JSON.stringify(settings));renderChoices();renderCards();
  $("saveMessage").textContent="Configurações restauradas.";
});
$("profile").value=settings.profile;
renderChoices();renderCards();
