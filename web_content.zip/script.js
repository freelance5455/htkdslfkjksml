const KEY="grupoHubV1";
const S=JSON.parse(localStorage.getItem(KEY))||{news:[],matches:[],champs:[],people:[],events:[],chat:[],theme:{color:"#2563eb",bg:null}};
const $=x=>document.getElementById(x);
function save(){localStorage.setItem(KEY,JSON.stringify(S))}
function esc(x){let d=document.createElement("div");d.textContent=x||"";return d.innerHTML}
function fmt(x){if(!x)return"Sem data";let a=x.split("-");return a[2]+"/"+a[1]+"/"+a[0]}
function item(html){return `<div class="item">${html}</div>`}
function applyTheme(){document.documentElement.style.setProperty("--primary",S.theme.color);$("colorPicker").value=S.theme.color;$("phone").style.backgroundImage=S.theme.bg?`linear-gradient(#0007,#0007),url(${S.theme.bg})`:"none"}
function open(id){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));$(id).classList.add("active");render()}
document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>{if(b.dataset.open==="copa-facil"){window.location.href="https://copafacil.com.br/"}else open(b.dataset.open)});
document.querySelectorAll(".back").forEach(b=>b.onclick=()=>open("home"));
function tick(){$("clock").textContent=new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}tick();setInterval(tick,1000);

function renderNews(){$("newsList").innerHTML=S.news.length?S.news.map(n=>item(`${n.img?`<img src="${n.img}">`:""}<h3>${esc(n.title)}</h3><p>${esc(n.text)}</p><small>${n.date}</small><br><button class="delete" onclick="delNews(${n.id})">Excluir</button>`)).join(""):item("Nenhuma notícia ainda.")}
window.delNews=id=>{S.news=S.news.filter(n=>n.id!==id);save();renderNews()}
$("newsForm").onsubmit=e=>{e.preventDefault();let n={id:Date.now(),title:$("newsTitle").value,text:$("newsText").value,date:new Date().toLocaleDateString("pt-BR"),img:null},f=$("newsImage").files[0];let done=()=>{S.news.unshift(n);save();e.target.reset();renderNews()};if(f){let r=new FileReader();r.onload=x=>{n.img=x.target.result;done()};r.readAsDataURL(f)}else done()}

$("matchForm").onsubmit=e=>{e.preventDefault();S.matches.unshift({id:Date.now(),a:$("team1").value,b:$("team2").value,sa:+$("score1").value,sb:+$("score2").value,date:$("matchDate").value});save();e.target.reset();render()}
window.delMatch=id=>{S.matches=S.matches.filter(m=>m.id!==id);save();render()}
function renderMatches(){$("matchList").innerHTML=S.matches.length?S.matches.map(m=>item(`<b>${esc(m.a)} ${m.sa} × ${m.sb} ${esc(m.b)}</b><br><small>${fmt(m.date)}</small><br><button class="delete" onclick="delMatch(${m.id})">Excluir</button>`)).join(""):item("Nenhuma partida.")}
function renderTable(){let r={};S.matches.forEach(m=>{[[m.a,m.sa,m.sb],[m.b,m.sb,m.sa]].forEach(([n,gf,ga])=>r[n]??={n,p:0,j:0,gf:0,ga:0});let A=r[m.a],B=r[m.b];A.j++;B.j++;A.gf+=m.sa;A.ga+=m.sb;B.gf+=m.sb;B.ga+=m.sa;if(m.sa>m.sb)A.p+=3;else if(m.sb>m.sa)B.p+=3;else{A.p++;B.p++}});let a=Object.values(r).sort((x,y)=>y.p-x.p||(y.gf-y.ga)-(x.gf-x.ga));$("tableList").innerHTML=a.length?a.map((x,i)=>item(`<b>${i+1}º ${esc(x.n)}</b> — ${x.p} pontos <small>(${x.j} jogos)</small>`)).join(""):item("Registre partidas para criar a tabela.")}

$("champForm").onsubmit=e=>{e.preventDefault();S.champs.unshift({id:Date.now(),name:$("champName").value,format:$("champFormat").value,date:$("champDate").value});save();e.target.reset();render()}
window.delChamp=id=>{S.champs=S.champs.filter(c=>c.id!==id);save();render()}
function renderChamps(){$("champList").innerHTML=S.champs.length?S.champs.map(c=>item(`<b>🏆 ${esc(c.name)}</b><p>${esc(c.format||"Formato não informado")}</p><small>${fmt(c.date)}</small><br><button class="delete" onclick="delChamp(${c.id})">Excluir</button>`)).join(""):item("Nenhum campeonato.")}

$("participantForm").onsubmit=e=>{e.preventDefault();S.people.push({id:Date.now(),name:$("participantName").value,game:$("participantGameName").value});save();e.target.reset();render()}
window.delPerson=id=>{S.people=S.people.filter(p=>p.id!==id);save();render()}
function renderPeople(){$("participantList").innerHTML=S.people.length?S.people.map(p=>item(`<b>👤 ${esc(p.name)}</b><p>${esc(p.game||"Sem nome no jogo")}</p><button class="delete" onclick="delPerson(${p.id})">Excluir</button>`)).join(""):item("Nenhum participante.");document.querySelectorAll(".playerSelect").forEach(s=>s.innerHTML="<option value=''>Selecione</option>"+S.people.map(p=>`<option value="${p.id}">${esc(p.game||p.name)}</option>`).join(""))}

let cal=new Date();function renderCalendar(){let y=cal.getFullYear(),m=cal.getMonth();$("monthTitle").textContent=cal.toLocaleDateString("pt-BR",{month:"long",year:"numeric"});let first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate(),h="";for(let i=0;i<first;i++)h+="<div></div>";for(let d=1;d<=days;d++){let t=new Date();let cls=(d===t.getDate()&&m===t.getMonth()&&y===t.getFullYear())?"day today":"day";h+=`<div class="${cls}">${d}</div>`}$("calendarGrid").innerHTML=h}
$("prevMonth").onclick=()=>{cal.setMonth(cal.getMonth()-1);renderCalendar()};$("nextMonth").onclick=()=>{cal.setMonth(cal.getMonth()+1);renderCalendar()};
$("eventForm").onsubmit=e=>{e.preventDefault();S.events.push({id:Date.now(),title:$("eventTitle").value,date:$("eventDate").value,time:$("eventTime").value});save();e.target.reset();render()}
window.delEvent=id=>{S.events=S.events.filter(x=>x.id!==id);save();render()}
function renderEvents(){$("eventList").innerHTML=S.events.sort((a,b)=>a.date.localeCompare(b.date)).map(x=>item(`<b>📅 ${esc(x.title)}</b><p>${fmt(x.date)} ${x.time||""}</p><button class="delete" onclick="delEvent(${x.id})">Excluir</button>`)).join("")}

$("chatForm").onsubmit=e=>{e.preventDefault();let t=$("chatInput").value.trim();if(!t)return;S.chat.push({id:Date.now(),text:t,time:new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})});save();$("chatInput").value="";renderChat()}
function renderChat(){$("chatList").innerHTML=S.chat.map(m=>`<div class="message">${esc(m.text)}<br><small>${m.time}</small></div>`).join("")}

$("unlockAI").onclick=()=>{if($("aiPassword").value==="GUILHERME.8787"){$("passwordMessage").textContent="";open("ai")}else $("passwordMessage").textContent="Senha incorreta!"}
$("videoFile").onchange=e=>{let f=e.target.files[0];if(f){$("videoPreview").src=URL.createObjectURL(f);$("videoPreview").hidden=false}}
$("analyzeBtn").onclick=()=>{let f=$("videoFile").files[0],p=[...document.querySelectorAll(".playerSelect")].map(x=>x.value);if(!f)return alert("Escolha um vídeo.");if(p.some(x=>!x))return alert("Selecione os 4 usuários.");$("analysisResult").innerHTML=`<div class="warning">Vídeo selecionado. A análise automática real precisa de uma IA conectada ao aplicativo.</div>`}

$("colorPicker").oninput=e=>{S.theme.color=e.target.value;save();applyTheme()}
$("bgFile").onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=x=>{S.theme.bg=x.target.result;save();applyTheme()};r.readAsDataURL(f)}
$("removeBg").onclick=()=>{S.theme.bg=null;save();applyTheme()}
$("resetTheme").onclick=()=>{S.theme={color:"#2563eb",bg:null};save();applyTheme()}

function render(){renderNews();renderMatches();renderTable();renderChamps();renderPeople();renderCalendar();renderEvents();renderChat();applyTheme()}
render();