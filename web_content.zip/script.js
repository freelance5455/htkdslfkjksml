/* =====================================================
   تطبيق مواقيت الصلاة + القبلة
   HTML + CSS + JavaScript
===================================================== */


/* -------------------------------
   المتغيرات
-------------------------------- */

let latitude = null;
let longitude = null;

let prayerTimes = {};

let qiblaDirection = 0;

let deviceHeading = 0;

let countdownTimer = null;


/* -------------------------------
   عناصر HTML
-------------------------------- */

const locationText =
    document.getElementById("locationText");

const nextPrayerName =
    document.getElementById("nextPrayerName");

const nextPrayerTime =
    document.getElementById("nextPrayerTime");

const countdown =
    document.getElementById("countdown");

const qiblaArrow =
    document.getElementById("qiblaArrow");

const qiblaDegree =
    document.getElementById("qiblaDegree");

const qiblaStatus =
    document.getElementById("qiblaStatus");


/* -------------------------------
   عند تشغيل التطبيق
-------------------------------- */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        requestLocation();

        setupButtons();

    }
);


/* -------------------------------
   طلب الموقع
-------------------------------- */

function requestLocation() {

    if (!navigator.geolocation) {

        locationText.textContent =
            "المتصفح لا يدعم تحديد الموقع";

        return;
    }


    navigator.geolocation.getCurrentPosition(

        position => {

            latitude =
                position.coords.latitude;

            longitude =
                position.coords.longitude;


            locationText.textContent =
                `📍 ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;


            calculatePrayerTimes();

            calculateQibla();

        },

        error => {

            console.log(error);

            locationText.textContent =
                "⚠️ يجب السماح بالموقع";

        },

        {
            enableHighAccuracy: true,

            timeout: 15000,

            maximumAge: 300000

        }

    );
}


/* =====================================================
   مواقيت الصلاة
===================================================== */


/*
   حساب تقريبي للمواقيت.

   في نسخة APK النهائية يمكن ربط هذا الجزء
   بمكتبة حساب مواقيت الصلاة أو API موثوق.
*/

function calculatePrayerTimes() {

    const now = new Date();


    /*
       هنا نستخدم خوارزمية مبسطة.

       سيتم حساب الأوقات بناءً على خط العرض
       وخط الطول والتاريخ.
    */

    const times =
        calculateSunTimes(
            now,
            latitude,
            longitude
        );


    prayerTimes = {

        Fajr: times.fajr,

        Sunrise: times.sunrise,

        Dhuhr: times.dhuhr,

        Asr: times.asr,

        Maghrib: times.maghrib,

        Isha: times.isha

    };


    document.getElementById("fajr").textContent =
        prayerTimes.Fajr;

    document.getElementById("sunrise").textContent =
        prayerTimes.Sunrise;

    document.getElementById("dhuhr").textContent =
        prayerTimes.Dhuhr;

    document.getElementById("asr").textContent =
        prayerTimes.Asr;

    document.getElementById("maghrib").textContent =
        prayerTimes.Maghrib;

    document.getElementById("isha").textContent =
        prayerTimes.Isha;


    updateNextPrayer();

}


/* =====================================================
   حساب شروق وغروب الشمس
===================================================== */

function calculateSunTimes(
    date,
    lat,
    lon
) {

    /*
       خوارزمية مبسطة لحساب موقع الشمس.
    */


    const day =
        getDayOfYear(date);


    const rad =
        Math.PI / 180;


    const declination =
        23.44 *
        Math.sin(
            rad *
            (360 / 365 *
            (day - 81))
        );


    const latRad =
        lat * rad;

    const declRad =
        declination * rad;


    const hourAngle =
        Math.acos(

            (
                Math.cos(90.833 * rad) -
                Math.sin(latRad) *
                Math.sin(declRad)
            )
            /
            (
                Math.cos(latRad) *
                Math.cos(declRad)
            )

        ) / rad;


    const noon =
        12 -
        lon / 15;


    const sunrise =
        noon -
        hourAngle / 15;


    const sunset =
        noon +
        hourAngle / 15;


    const fajr =
        sunrise - 1.5;


    const isha =
        sunset + 1.5;


    const dhuhr =
        noon;


    /*
       العصر بطريقة تقريبية.
    */

    const asr =
        dhuhr + 3.5;


    return {

        fajr: decimalToTime(fajr),

        sunrise: decimalToTime(sunrise),

        dhuhr: decimalToTime(dhuhr),

        asr: decimalToTime(asr),

        maghrib: decimalToTime(sunset),

        isha: decimalToTime(isha)

    };
}


/* -------------------------------
   اليوم من السنة
-------------------------------- */

function getDayOfYear(date) {

    const start =
        new Date(
            date.getFullYear(),
            0,
            0
        );

    const diff =
        date - start;

    return Math.floor(
        diff /
        (1000 * 60 * 60 * 24)
    );
}


/* -------------------------------
   تحويل رقم الساعة
   إلى HH:MM
-------------------------------- */

function decimalToTime(decimal) {

    decimal =
        ((decimal % 24) + 24) % 24;


    let hours =
        Math.floor(decimal);

    let minutes =
        Math.round(
            (decimal - hours) * 60
        );


    if (minutes >= 60) {

        minutes = 0;

        hours++;

    }


    hours =
        hours
        .toString()
        .padStart(2, "0");

    minutes =
        minutes
        .toString()
        .padStart(2, "0");


    return `${hours}:${minutes}`;
}


/* =====================================================
   الصلاة القادمة
===================================================== */

function updateNextPrayer() {

    const now =
        new Date();


    const prayers = [

        ["الفجر", prayerTimes.Fajr],

        ["الظهر", prayerTimes.Dhuhr],

        ["العصر", prayerTimes.Asr],

        ["المغرب", prayerTimes.Maghrib],

        ["العشاء", prayerTimes.Isha]

    ];


    let next = null;


    for (const prayer of prayers) {

        const time =
            timeToDate(prayer[1], now);


        if (time > now) {

            next = {

                name: prayer[0],

                time: time

            };

            break;
        }
    }


    /*
       إذا انتهت صلوات اليوم
       ننتقل إلى فجر الغد.
    */

    if (!next) {

        const tomorrow =
            new Date(now);

        tomorrow.setDate(
            tomorrow.getDate() + 1
        );


        next = {

            name: "الفجر",

            time:
                timeToDate(
                    prayerTimes.Fajr,
                    tomorrow
                )

        };

    }


    nextPrayerName.textContent =
        next.name;

    nextPrayerTime.textContent =
        formatTime(next.time);


    startCountdown(next.time);

}


/* -------------------------------
   تحويل HH:MM إلى Date
-------------------------------- */

function timeToDate(
    time,
    date
) {

    const [
        hours,
        minutes
    ] =
        time.split(":")
        .map(Number);


    const result =
        new Date(date);


    result.setHours(
        hours,
        minutes,
        0,
        0
    );


    return result;
}


/* -------------------------------
   تنسيق الوقت
-------------------------------- */

function formatTime(date) {

    return date.toLocaleTimeString(
        "ar-IQ",
        {
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


/* -------------------------------
   العد التنازلي
-------------------------------- */

function startCountdown(target) {

    clearInterval(
        countdownTimer
    );


    function update() {

        const now =
            new Date();


        let difference =
            target - now;


        if (difference < 0) {

            updateNextPrayer();

            return;
        }


        const hours =
            Math.floor(
                difference /
                (1000 * 60 * 60)
            );


        const minutes =
            Math.floor(
                (difference %
                (1000 * 60 * 60))
                /
                (1000 * 60)
            );


        const seconds =
            Math.floor(
                (difference %
                (1000 * 60))
                /
                1000
            );


        countdown.textContent =

            `${String(hours).padStart(2,"0")}:` +

            `${String(minutes).padStart(2,"0")}:` +

            `${String(seconds).padStart(2,"0")}`;

    }


    update();

    countdownTimer =
        setInterval(
            update,
            1000
        );
}


/* =====================================================
   حساب اتجاه القبلة
===================================================== */

function calculateQibla() {

    /*
       إحداثيات الكعبة
    */

    const kaabaLat =
        21.422487;

    const kaabaLon =
        39.826206;


    const lat1 =
        toRadians(latitude);

    const lat2 =
        toRadians(kaabaLat);


    const deltaLon =
        toRadians(
            kaabaLon - longitude
        );


    const y =
        Math.sin(deltaLon) *
        Math.cos(lat2);


    const x =

        Math.cos(lat1) *
        Math.sin(lat2)

        -

        Math.sin(lat1) *
        Math.cos(lat2) *
        Math.cos(deltaLon);


    let bearing =
        Math.atan2(y, x);


    bearing =
        toDegrees(bearing);


    bearing =
        (bearing + 360) % 360;


    qiblaDirection =
        bearing;


    qiblaDegree.textContent =
        `${bearing.toFixed(1)}°`;

    qiblaStatus.textContent =
        `اتجاه القبلة ${bearing.toFixed(1)}° من الشمال`;

}


/* -------------------------------
   درجات وراديان
-------------------------------- */

function toRadians(degrees) {

    return degrees *
        Math.PI / 180;

}

function toDegrees(radians) {

    return radians *
        180 / Math.PI;

}


/* =====================================================
   البوصلة
===================================================== */

function startCompass() {

    if (
        typeof DeviceOrientationEvent !==
        "undefined" &&
        typeof DeviceOrientationEvent
            .requestPermission ===
            "function"
    ) {

        DeviceOrientationEvent
            .requestPermission()

            .then(permission => {

                if (
                    permission ===
                    "granted"
                ) {

                    window.addEventListener(
                        "deviceorientation",
                        handleOrientation,
                        true
                    );

                }

            })

            .catch(console.error);

    }

    else {

        window.addEventListener(
            "deviceorientationabsolute",
            handleOrientation,
            true
        );

        window.addEventListener(
            "deviceorientation",
            handleOrientation,
            true
        );

    }


    qiblaStatus.textContent =
        "🧭 البوصلة تعمل";

}


/* -------------------------------
   قراءة اتجاه الجهاز
-------------------------------- */

function handleOrientation(event) {

    let heading;


    if (
        event.webkitCompassHeading
        !== undefined
    ) {

        heading =
            event.webkitCompassHeading;

    }

    else if (
        event.alpha !== null
    ) {

        heading =
            360 - event.alpha;

    }

    else {

        return;

    }


    deviceHeading =
        heading;


    const rotation =
        qiblaDirection -
        deviceHeading;


    qiblaArrow.style.transform =

        `translate(-50%, -50%) ` +
        `rotate(${rotation}deg)`;

}


/* =====================================================
   الأزرار
===================================================== */

function setupButtons() {


    /* الموقع */

    document
        .getElementById("locationBtn")
        .onclick = () => {

            requestLocation();

        };


    document
        .getElementById("allowLocation")
        .onclick = () => {

            requestLocation();

            document
                .getElementById("permissionBox")
                .classList.add("hidden");

        };


    /* البوصلة */

    document
        .getElementById("compassBtn")
        .onclick = () => {

            startCompass();

        };


    /* الإشعارات */

    document
        .getElementById("notificationBtn")
        .onclick = () => {

            requestNotifications();

        };


    document
        .getElementById("allowNotification")
        .onclick = () => {

            requestNotifications();

        };


    /* الودجت */

    document
        .getElementById("widgetBtn")
        .onclick = () => {

            if (
                window.Android &&
                Android.addWidget
            ) {

                Android.addWidget();

            }
            else {

                alert(
                    "هذه الميزة تعمل داخل نسخة Android APK."
                );

            }

        };


    /* إخفاء الودجت */

    document
        .getElementById("hideWidgetBtn")
        .onclick = () => {

            if (
                window.Android &&
                Android.hideWidget
            ) {

                Android.hideWidget();

            }
            else {

                alert(
                    "هذه الميزة تعمل داخل نسخة Android APK."
                );

            }

        };


    /* زر الإعدادات */

    document
        .getElementById("settingsBtn")
        .onclick = () => {

            document
                .getElementById("permissionBox")
                .classList.remove("hidden");

        };


    document
        .getElementById("closePermission")
        .onclick = () => {

            document
                .getElementById("permissionBox")
                .classList.add("hidden");

        };

}


/* =====================================================
   الإشعارات
===================================================== */

async function requestNotifications() {

    /*
       إذا كان التطبيق داخل Android WebView
       نستخدم الجسر الأصلي.
    */

    if (
        window.Android &&
        Android.requestNotifications
    ) {

        Android.requestNotifications();

        return;

    }


    /*
       نسخة المتصفح
    */

    if (
        "Notification"
        in window
    ) {

        const permission =
            await Notification.requestPermission();


        if (
            permission ===
            "granted"
        ) {

            alert(
                "تم تفعيل الإشعارات."
            );

        }
        else {

            alert(
                "لم يتم السماح بالإشعارات."
            );

        }

    }
}


/* =====================================================
   تحديث المواقيت تلقائياً
===================================================== */

setInterval(

    () => {

        if (
            latitude !== null &&
            longitude !== null
        ) {

            calculatePrayerTimes();

        }

    },

    60 * 60 * 1000

);