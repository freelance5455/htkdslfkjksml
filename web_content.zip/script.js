// ==========================================
// DATA & PENYIMPANAN LOKAL (LOCAL STORAGE)
// ==========================================
let setorList = JSON.parse(localStorage.getItem('audit_setor')) || [];
let tarikList = JSON.parse(localStorage.getItem('audit_tarik')) || [];

const defaultRules = [
    { min: 5000, max: 100000, fee: 3000 },
    { min: 100001, max: 500000, fee: 5000 },
    { min: 500001, max: 1000000, fee: 10000 },
    { min: 1000001, max: 5000000, fee: 15000 }
];

// Aturan Biaya Admin Terpisah untuk Setor Tunai & Tarik Tunai
let adminConfig = JSON.parse(localStorage.getItem('audit_admin_config')) || {
    setor: JSON.parse(JSON.stringify(defaultRules)),
    tarik: JSON.parse(JSON.stringify(defaultRules))
};

let currentAdminTab = 'setor'; // 'setor' atau 'tarik'
let isEditingAdmin = false;
let pendingNavigationTarget = null;

// ==========================================
// INISIALISASI SAAT APK DIBUKA
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    displayCurrentDate();
    renderTables();
    renderAdminRules();
    setupUniversalSearch();
});

function displayCurrentDate() {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('today-date').innerText = new Date().toLocaleDateString('id-ID', options);
}

// ==========================================
// FORMAT ANGKA DENGAN TITIK (.) OTOMATIS
// ==========================================
function formatDots(num) {
    if (!num && num !== 0) return '';
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function parseDots(str) {
    if (!str) return 0;
    return parseInt(str.toString().replace(/\./g, ''), 10) || 0;
}

// Handler saat mengetik Nominal -> Tambah titik otomatis & Hitung Admin Otomatis
function handleNominalInput(inputEl, type) {
    let rawValue = inputEl.value.replace(/\D/g, '');
    if (rawValue === '') {
        inputEl.value = '';
        document.getElementById(`${type}-admin`).value = '0';
        return;
    }

    let numericVal = parseInt(rawValue, 10);
    inputEl.value = formatDots(numericVal);

    // Cari biaya admin yang sesuai jenis (setor / tarik) dari pengaturan
    let calculatedFee = calculateAdminFee(numericVal, type);
    document.getElementById(`${type}-admin`).value = formatDots(calculatedFee);
}

function calculateAdminFee(nominal, type) {
    const rules = adminConfig[type] || [];
    for (let rule of rules) {
        if (nominal >= rule.min && nominal <= rule.max) {
            return rule.fee;
        }
    }
    return 0;
}

// ==========================================
// NAVIGASI ANTAR MENU & CEK PERUBAHAN ADMIN
// ==========================================
function navigateTo(targetView) {
    // Jika sedang dalam mode Edit Admin di menu Akun dan hendak pindah menu
    if (isEditingAdmin && targetView !== 'akun') {
        pendingNavigationTarget = targetView;
        document.getElementById('confirm-modal').classList.remove('hidden');
        return;
    }

    executeNavigation(targetView);
}

function executeNavigation(targetView) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    document.getElementById(`view-${targetView}`).classList.add('active');

    if (['home', 'setor', 'tarik', 'akun'].includes(targetView)) {
        document.getElementById(`nav-${targetView}`).classList.add('active');
    } else {
        document.getElementById('nav-home').classList.add('active');
    }

    if (targetView === 'grafik-harian') {
        drawDailyChart();
    } else if (targetView === 'grafik-bulanan') {
        drawMonthlyChart();
    }
}

// ==========================================
// TRANSAKSI SETOR TUNAI & TARIK TUNAI
// ==========================================
function addTransaction(event, type) {
    event.preventDefault();

    const bank = document.getElementById(`${type}-bank`).value.trim();
    const nama = document.getElementById(`${type}-nama`).value.trim();
    const nominal = parseDots(document.getElementById(`${type}-nominal`).value);
    const admin = parseDots(document.getElementById(`${type}-admin`).value);

    const now = new Date();
    const newTx = {
        id: Date.now(),
        day: now.getDate(),
        month: now.getMonth(),
        year: now.getFullYear(),
        bank: bank,
        nama: nama,
        nominal: nominal,
        admin: admin
    };

    if (type === 'setor') {
        setorList.push(newTx);
        localStorage.setItem('audit_setor', JSON.stringify(setorList));
    } else {
        tarikList.push(newTx);
        localStorage.setItem('audit_tarik', JSON.stringify(tarikList));
    }

    document.getElementById(`form-${type}`).reset();
    document.getElementById(`${type}-admin`).value = '0';

    renderTables();
}

function renderTables() {
    // Render Setor Tunai
    const tbodySetor = document.getElementById('tbody-setor');
    tbodySetor.innerHTML = '';
    let totalSetorNom = 0;
    let totalSetorAdm = 0;

    setorList.forEach((item, index) => {
        totalSetorNom += item.nominal;
        totalSetorAdm += item.admin;
        tbodySetor.innerHTML += `
            <tr>
                <td style="text-align:center;">${index + 1}</td>
                <td>${item.bank}</td>
                <td>${item.nama}</td>
                <td>Rp ${formatDots(item.nominal)}</td>
                <td>Rp ${formatDots(item.admin)}</td>
            </tr>
        `;
    });

    document.getElementById('foot-setor-nominal').innerHTML = `<strong>Rp ${formatDots(totalSetorNom)}</strong>`;
    document.getElementById('foot-setor-admin').innerHTML = `<strong>Rp ${formatDots(totalSetorAdm)}</strong>`;

    // Render Tarik Tunai
    const tbodyTarik = document.getElementById('tbody-tarik');
    tbodyTarik.innerHTML = '';
    let totalTarikNom = 0;
    let totalTarikAdm = 0;

    tarikList.forEach((item, index) => {
        totalTarikNom += item.nominal;
        totalTarikAdm += item.admin;
        tbodyTarik.innerHTML += `
            <tr>
                <td style="text-align:center;">${index + 1}</td>
                <td>${item.bank}</td>
                <td>${item.nama}</td>
                <td>Rp ${formatDots(item.nominal)}</td>
                <td>Rp ${formatDots(item.admin)}</td>
            </tr>
        `;
    });

    document.getElementById('foot-tarik-nominal').innerHTML = `<strong>Rp ${formatDots(totalTarikNom)}</strong>`;
    document.getElementById('foot-tarik-admin').innerHTML = `<strong>Rp ${formatDots(totalTarikAdm)}</strong>`;

    // Update Ringkasan di Menu Utama
    document.getElementById('home-total-setor').innerText = `Rp ${formatDots(totalSetorNom)}`;
    document.getElementById('home-total-tarik').innerText = `Rp ${formatDots(totalTarikNom)}`;
    document.getElementById('home-total-admin').innerText = `Rp ${formatDots(totalSetorAdm + totalTarikAdm)}`;
}

function resetTable(type) {
    if (confirm(`Kosongkan seluruh tabel ${type === 'setor' ? 'Setor Tunai' : 'Tarik Tunai'}?`)) {
        if (type === 'setor') {
            setorList = [];
            localStorage.setItem('audit_setor', JSON.stringify(setorList));
        } else {
            tarikList = [];
            localStorage.setItem('audit_tarik', JSON.stringify(tarikList));
        }
        renderTables();
    }
}

// ==========================================
// KOLOM PENCARIAN UNIVERSAL
// ==========================================
function setupUniversalSearch() {
    const searchInput = document.getElementById('universal-search');
    const resultsBox = document.getElementById('search-results');

    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase().trim();
        if (!query) {
            resultsBox.classList.add('hidden');
            resultsBox.innerHTML = '';
            return;
        }

        const allData = [
            ...setorList.map(i => ({ ...i, jenis: 'Setor Tunai' })),
            ...tarikList.map(i => ({ ...i, jenis: 'Tarik Tunai' }))
        ];

        const filtered = allData.filter(item =>
            item.nama.toLowerCase().includes(query) ||
            item.bank.toLowerCase().includes(query) ||
            item.nominal.toString().includes(query.replace(/\./g, ''))
        );

        resultsBox.classList.remove('hidden');
        if (filtered.length === 0) {
            resultsBox.innerHTML = `<div class="search-item">Data tidak ditemukan.</div>`;
        } else {
            resultsBox.innerHTML = filtered.map(item => `
                <div class="search-item">
                    <strong>[${item.jenis}]</strong> ${item.bank} - ${item.nama} : 
                    <span>Rp ${formatDots(item.nominal)}</span> (Admin: Rp ${formatDots(item.admin)})
                </div>
            `).join('');
        }
    });
}

// ==========================================
// PENGATURAN ADMIN & POP-UP KONFIRMASI
// ==========================================
function switchAdminTab(tabType) {
    if (isEditingAdmin) {
        // Simpan sementara perubahan input pada tab saat ini sebelum ganti tab
        collectCurrentTabInputs();
    }
    currentAdminTab = tabType;
    document.getElementById('tab-rule-setor').classList.toggle('active', tabType === 'setor');
    document.getElementById('tab-rule-tarik').classList.toggle('active', tabType === 'tarik');
    renderAdminRules();
}

function collectCurrentTabInputs() {
    const rows = document.querySelectorAll('.rule-row');
    const updated = [];
    rows.forEach(row => {
        const min = parseDots(row.querySelector('.rule-min').value);
        const max = parseDots(row.querySelector('.rule-max').value);
        const fee = parseDots(row.querySelector('.rule-fee').value);
        updated.push({ min, max, fee });
    });
    adminConfig[currentAdminTab] = updated;
}

function renderAdminRules() {
    const container = document.getElementById('admin-rules-container');
    const rules = adminConfig[currentAdminTab] || [];

    container.innerHTML = rules.map((rule, idx) => `
        <div class="rule-row">
            <input type="text" class="rule-min" value="${formatDots(rule.min)}" placeholder="Min" inputmode="numeric" oninput="this.value=formatDots(this.value.replace(/\\D/g,''))" ${isEditingAdmin ? '' : 'disabled'}>
            <input type="text" class="rule-max" value="${formatDots(rule.max)}" placeholder="Max" inputmode="numeric" oninput="this.value=formatDots(this.value.replace(/\\D/g,''))" ${isEditingAdmin ? '' : 'disabled'}>
            <input type="text" class="rule-fee" value="${formatDots(rule.fee)}" placeholder="Admin" inputmode="numeric" oninput="this.value=formatDots(this.value.replace(/\\D/g,''))" ${isEditingAdmin ? '' : 'disabled'}>
            ${isEditingAdmin ? `<button type="button" class="btn-del-rule" onclick="removeRuleRow(${idx})">X</button>` : ''}
        </div>
    `).join('');
}

function enableAdminEdit() {
    isEditingAdmin = true;
    document.getElementById('btn-toggle-edit').classList.add('hidden');
    document.getElementById('edit-controls').classList.remove('hidden');
    renderAdminRules();
}

function addAdminRuleRow() {
    collectCurrentTabInputs();
    adminConfig[currentAdminTab].push({ min: 0, max: 0, fee: 0 });
    renderAdminRules();
}

function removeRuleRow(index) {
    collectCurrentTabInputs();
    adminConfig[currentAdminTab].splice(index, 1);
    renderAdminRules();
}

function triggerSaveAdminConfirm() {
    pendingNavigationTarget = 'akun';
    document.getElementById('confirm-modal').classList.remove('hidden');
}

function closeModal(isConfirmed) {
    document.getElementById('confirm-modal').classList.add('hidden');

    if (isConfirmed) {
        collectCurrentTabInputs();
        // Bersihkan baris kosong (max === 0)
        adminConfig.setor = adminConfig.setor.filter(r => r.max > 0);
        adminConfig.tarik = adminConfig.tarik.filter(r => r.max > 0);
        localStorage.setItem('audit_admin_config', JSON.stringify(adminConfig));
    } else {
        // Batalkan perubahan dan kembalikan dari penyimpanan lokal
        adminConfig = JSON.parse(localStorage.getItem('audit_admin_config')) || {
            setor: JSON.parse(JSON.stringify(defaultRules)),
            tarik: JSON.parse(JSON.stringify(defaultRules))
        };
    }

    isEditingAdmin = false;
    document.getElementById('btn-toggle-edit').classList.remove('hidden');
    document.getElementById('edit-controls').classList.add('hidden');
    renderAdminRules();

    if (pendingNavigationTarget) {
        const target = pendingNavigationTarget;
        pendingNavigationTarget = null;
        executeNavigation(target);
    }
}

// ==========================================
// GRAFIK GARIS & GARIS VERTIKAL (HARIAN & BULANAN)
// ==========================================
function drawDailyChart() {
    const canvas = document.getElementById('canvas-harian');
    const ctx = canvas.getContext('2d');
    const daysInMonth = 31;
    const width = 950;
    const height = 260;
    canvas.width = width;
    canvas.height = height;

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const dailyTotals = new Array(daysInMonth).fill(0);

    [...setorList, ...tarikList].forEach(tx => {
        if (tx.month === currentMonth && tx.year === currentYear) {
            dailyTotals[tx.day - 1] += tx.nominal;
        }
    });

    renderVerticalLineChart(ctx, width, height, dailyTotals, Array.from({ length: 31 }, (_, i) => `${i + 1}`), '#eab308');
}

function drawMonthlyChart() {
    const canvas = document.getElementById('canvas-bulanan');
    const ctx = canvas.getContext('2d');
    const monthLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];
    const width = 650;
    const height = 260;
    canvas.width = width;
    canvas.height = height;

    const currentYear = new Date().getFullYear();
    const monthlyTotals = new Array(12).fill(0);

    [...setorList, ...tarikList].forEach(tx => {
        if (tx.year === currentYear) {
            monthlyTotals[tx.month] += tx.nominal;
        }
    });

    renderVerticalLineChart(ctx, width, height, monthlyTotals, monthLabels, '#2563eb');
}

function renderVerticalLineChart(ctx, width, height, dataValues, labels, themeColor) {
    ctx.clearRect(0, 0, width, height);

    const padLeft = 45;
    const padRight = 25;
    const padTop = 30;
    const padBottom = 35;
    const chartW = width - padLeft - padRight;
    const chartH = height - padTop - padBottom;

    const maxVal = Math.max(...dataValues, 100000);
    const stepX = chartW / (labels.length - 1 || 1);

    // Sumbu X & Y dasar
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padLeft, padTop);
    ctx.lineTo(padLeft, height - padBottom);
    ctx.lineTo(width - padRight, height - padBottom);
    ctx.stroke();

    const points = [];

    // 1. Garis vertikal setiap transaksi harian/bulanan
    labels.forEach((label, idx) => {
        const x = padLeft + idx * stepX;
        const val = dataValues[idx];
        const barH = (val / maxVal) * chartH;
        const y = (height - padBottom) - barH;
        points.push({ x, y, val });

        ctx.strokeStyle = themeColor;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x, height - padBottom);
        ctx.lineTo(x, y);
        ctx.stroke();

        ctx.fillStyle = '#374151';
        ctx.font = '11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label, x, height - 15);
    });

    // 2. Garis penghubung pucuk antar hari/bulan
    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 2;
    ctx.beginPath();
    points.forEach((pt, idx) => {
        if (idx === 0) ctx.moveTo(pt.x, pt.y);
        else ctx.lineTo(pt.x, pt.y);
    });
    ctx.stroke();

    // 3. Titik pucuk
    points.forEach(pt => {
        ctx.fillStyle = themeColor;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#111827';
        ctx.lineWidth = 1.5;
        ctx.stroke();
    });
}
