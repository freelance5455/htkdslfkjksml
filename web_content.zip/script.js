const $ = id => document.getElementById(id);
const $$ = sel => document.querySelectorAll(sel);

/* ============================================================
   STORAGE / STATS
   ============================================================ */
function load(key) {
  try { return Number(localStorage.getItem(key)) || 0; } catch { return 0; }
}
function save(key, val) {
  try { localStorage.setItem(key, val); } catch {}
}
function trackPlay(key) {
  const played = load(key + "_plays") + 1;
  save(key + "_plays", played);
  save("totalPlayed", load("totalPlayed") + 1);
}

/* ============================================================
   AUDIO / HAPTIC / TOAST
   ============================================================ */
let soundOn = localStorage.getItem("soundOn") !== "false";

function sfx(freq, dur = 0.06, type = "sine", vol = 0.08) {
  if (!soundOn) return;
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = vol;
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + dur);
  } catch {}
}

function haptic(ms = 10) {
  try { if (navigator.vibrate) navigator.vibrate(ms); } catch {}
}

let toastTimer;
function toast(msg) {
  const el = $("toast");
  el.textContent = msg;
  el.classList.remove("hidden");
  requestAnimationFrame(() => el.classList.add("show"));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.classList.add("hidden"), 300);
  }, 2200);
}

function confetti() {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const colors = ["#6366f1", "#a855f7", "#ec4899", "#fbbf24", "#22c55e", "#3b82f6"];
  for (let i = 0; i < 40; i++) {
    const el = document.createElement("div");
    el.className = "confetti";
    el.style.left = Math.random() * 100 + "%";
    el.style.background = colors[Math.floor(Math.random() * colors.length)];
    el.style.animationDelay = Math.random() * 0.4 + "s";
    el.style.animationDuration = (1.6 + Math.random()) + "s";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2800);
  }
}

/* ============================================================
   THEME / SOUND TOGGLES
   ============================================================ */
function applyTheme(t) {
  document.documentElement.setAttribute("data-theme", t);
  localStorage.setItem("theme", t);
  $("btnTheme").textContent = t === "light" ? "☀️" : "🌙";
  document.querySelector('meta[name="theme-color"]').setAttribute(
    "content", t === "light" ? "#f0f0f8" : "#0b0b16"
  );
}
applyTheme(localStorage.getItem("theme") || "dark");

$("btnTheme").addEventListener("click", () => {
  const cur = document.documentElement.getAttribute("data-theme");
  applyTheme(cur === "light" ? "dark" : "light");
  sfx(660, 0.05, "triangle");
});

$("btnSound").addEventListener("click", () => {
  soundOn = !soundOn;
  localStorage.setItem("soundOn", soundOn);
  $("btnSound").textContent = soundOn ? "🔊" : "🔇";
  if (soundOn) sfx(880, 0.08, "triangle");
});
$("btnSound").textContent = soundOn ? "🔊" : "🔇";

/* ============================================================
   ROUTER
   ============================================================ */
const screens = [
  "menu", "snakeScreen", "tapScreen", "memoryScreen", "tttScreen",
  "breakoutScreen", "moleScreen", "g2048Screen", "simonScreen", "reactionScreen"
];
function show(id) {
  screens.forEach(s => $(s).classList.toggle("hidden", s !== id));
  window.scrollTo(0, 0);
}

function updateBest() {
  const fmt = (v, suffix = "") => v > 0 ? v + suffix : "—";
  $("snakeBest").textContent = "Best: " + fmt(load("snakeBest"));
  $("breakoutBest").textContent = "Best: " + fmt(load("breakoutBest"));
  $("moleBest").textContent = "Best: " + fmt(load("moleBest"));
  $("memoryBest").textContent = "Best: " + fmt(load("memoryBest"));
  $("tttBest").textContent = "Wins: " + load("tttBest");
  $("simonBest").textContent = "Best: " + fmt(load("simonBest"));
  $("tapBest").textContent = "Best: " + fmt(load("tapBest"));
  $("reactionBest").textContent = load("reactionBest") > 0 ? load("reactionBest") + "ms" : "—";
  $("g2048Best").textContent = "Best: " + fmt(load("g2048Best"));

  // Hero stats
  $("statPlayed").textContent = load("totalPlayed");
  let bests = 0;
  ["snakeBest","breakoutBest","moleBest","memoryBest","simonBest","tapBest","reactionBest","g2048Best"]
    .forEach(k => { if (load(k) > 0) bests++; });
  $("statBests").textContent = bests;
}

function newBest(gameKey, display) {
  save(gameKey, display);
  toast("🏆 New best: " + display);
  confetti();
  sfx(1000, 0.12, "triangle");
  haptic(50);
}

/* ============================================================
   NAV — back buttons & game launch
   ============================================================ */
$$("[data-back]").forEach(b => b.addEventListener("click", () => {
  stopAllGames();
  updateBest();
  show("menu");
}));

function stopAllGames() {
  clearInterval(snake.loop);
  clearInterval(tapState.timer);
  clearTimeout(reactionCtrl.timeout);
  clearInterval(memoryGame.timer);
  clearInterval(breakoutGame.loop);
  clearInterval(moleGame.timer);
  clearInterval(moleGame.spawnTimer);
  simonGame.playing = false;
}

$("btnOpenSettings").addEventListener("click", () => {
  $("settingsModal").classList.remove("hidden");
  sfx(600, 0.05);
});
$$("[data-close-settings]").forEach(el => el.addEventListener("click", () => {
  $("settingsModal").classList.add("hidden");
}));

/* Filter tabs */
$("tabs").addEventListener("click", e => {
  const btn = e.target.closest(".tab");
  if (!btn) return;
  $$(".tab").forEach(t => t.classList.toggle("active", t === btn));
  const cat = btn.dataset.cat;
  $$(".game-card").forEach(card => {
    card.style.display = (cat === "all" || card.dataset.cat === cat) ? "" : "none";
  });
  sfx(700, 0.04, "sine");
});

/* Game card launch */
const launchers = {
  snake: startSnake, breakout: startBreakout, mole: startMole,
  memory: startMemory, ttt: startTtt, simon: startSimon,
  tap: startTap, reaction: startReaction, g2048: start2048
};
$$(".game-card").forEach(card => {
  card.addEventListener("click", () => {
    const g = card.dataset.game;
    trackPlay(g);
    sfx(800, 0.05, "triangle");
    haptic(15);
    if (launchers[g]) launchers[g]();
  });
});

/* ============================================================
   SNAKE
   ============================================================ */
const snake = (() => {
  const canvas = $("canvas");
  const ctx = canvas.getContext("2d");
  const TILES = 20;
  const CELL = canvas.width / TILES;
  let snakeArr, dir, nextDir, food, score, loop, paused, combo, comboCount;

  const FOOD = {
    normal: { color: "#ef4444", glow: "#ef4444", value: 1, grow: 1, chance: 0.78 },
    gold:   { color: "#fbbf24", glow: "#fbbf24", value: 5, grow: 2, chance: 0.15 },
    bomb:   { color: "#9c27b0", glow: "#9c27b0", value: -1, grow: -2, chance: 0.07 }
  };

  function roundRect(x, y, w, h, r) {
    if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x, y, w, h, r); return; }
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function interval() {
    const base = 220 - $("speed").value * 18;
    // Speed ramp: shrink interval as score rises
    const ramp = Math.min(60, score * 2);
    return Math.max(60, base - ramp);
  }

  function reset() {
    snakeArr = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
    dir = { x: 1, y: 0 };
    nextDir = dir;
    score = 0;
    paused = false;
    combo = 1;
    comboCount = 0;
    $("score").textContent = "0";
    $("snakePause").textContent = "⏸";
    $("combo").style.display = "none";
    $("overlay").classList.add("hidden");
    placeFood();
    clearInterval(loop);
    loop = setInterval(tick, interval());
    draw();
  }

  function pickType() {
    const r = Math.random();
    let acc = 0;
    for (const [n, cfg] of Object.entries(FOOD)) {
      acc += cfg.chance;
      if (r <= acc) return n;
    }
    return "normal";
  }

  function placeFood() {
    do {
      food = {
        x: Math.floor(Math.random() * TILES),
        y: Math.floor(Math.random() * TILES),
        type: pickType()
      };
    } while (snakeArr.some(s => s.x === food.x && s.y === food.y));
  }

  function tick() {
    if (paused) return;
    dir = nextDir;
    let x = snakeArr[0].x + dir.x;
    let y = snakeArr[0].y + dir.y;

    if ($("wrap").checked) {
      x = (x + TILES) % TILES;
      y = (y + TILES) % TILES;
    } else if (x < 0 || y < 0 || x >= TILES || y >= TILES) return gameOver();
    if (snakeArr.some(s => s.x === x && s.y === y)) return gameOver();

    snakeArr.unshift({ x, y });

    if (x === food.x && y === food.y) {
      const cfg = FOOD[food.type];
      if (cfg.value > 0) {
        comboCount++;
        combo = Math.min(5, 1 + Math.floor(comboCount / 3));
        $("combo").textContent = "×" + combo;
        $("combo").style.display = combo > 1 ? "" : "none";
      } else {
        comboCount = 0;
        combo = 1;
        $("combo").style.display = "none";
      }
      score = Math.max(0, score + cfg.value * combo);
      $("score").textContent = score;
      sfx(cfg.value > 0 ? 880 : 220, 0.08, "square");
      haptic(10);

      if (cfg.grow > 0) {
        for (let i = 1; i < cfg.grow; i++) snakeArr.push({ ...snakeArr[snakeArr.length - 1] });
      } else if (cfg.grow < 0) {
        for (let i = 0; i < -cfg.grow; i++) if (snakeArr.length > 1) snakeArr.pop();
      }
      placeFood();
      // Rebuild interval for speed ramp
      clearInterval(loop);
      loop = setInterval(tick, interval());
    } else {
      snakeArr.pop();
    }
    draw();
  }

  function gameOver() {
    clearInterval(loop);
    if (score > load("snakeBest")) newBest("snakeBest", score);
    $("overlayText").textContent = "Score: " + score;
    $("overlay").classList.remove("hidden");
    sfx(140, 0.25, "sawtooth");
    haptic([30, 40, 30]);
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const cfg = FOOD[food.type];
    ctx.shadowColor = cfg.glow;
    ctx.shadowBlur = 14;
    ctx.fillStyle = cfg.color;
    roundRect(food.x * CELL + 2, food.y * CELL + 2, CELL - 4, CELL - 4, 4);
    ctx.fill();
    ctx.shadowBlur = 0;

    if (food.type === "bomb") drawIcon("💣", food.x, food.y);
    else if (food.type === "gold") drawIcon("★", food.x, food.y, "#000");

    const color = $("color").value;
    snakeArr.forEach((s, i) => {
      ctx.globalAlpha = i === 0 ? 1 : 0.85;
      ctx.fillStyle = i === 0 ? "#84cc16" : color;
      roundRect(s.x * CELL + 1, s.y * CELL + 1, CELL - 2, CELL - 2, 5);
      ctx.fill();
      if (i === 0) {
        ctx.globalAlpha = 1;
        ctx.fillStyle = "#000";
        const cx = s.x * CELL + CELL / 2, cy = s.y * CELL + CELL / 2;
        const ex = dir.y !== 0 ? 3 : 0, ey = dir.x !== 0 ? 3 : 0;
        ctx.beginPath(); ctx.arc(cx - 3 + ex, cy - 3 + ey, 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(cx + 3 - ex, cy + 3 - ey, 1.8, 0, Math.PI * 2); ctx.fill();
      }
    });
    ctx.globalAlpha = 1;
  }

  function drawIcon(txt, fx, fy, color = "#fff") {
    ctx.fillStyle = color;
    ctx.font = "bold 12px system-ui";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(txt, fx * CELL + CELL / 2, fy * CELL + CELL / 2 + 1);
  }

  function turn(x, y) {
    if (paused) return;
    if (x === -dir.x && y === -dir.y) return;
    nextDir = { x, y };
  }

  function togglePause() {
    if (!$("overlay").classList.contains("hidden")) return;
    paused = !paused;
    $("snakePause").textContent = paused ? "▶" : "⏸";
  }

  return {
    reset, turn, togglePause,
    get loop() { return loop; },
    set loop(v) { loop = v; },
    interval
  };
})();

document.addEventListener("keydown", e => {
  if ($("snakeScreen").classList.contains("hidden")) return;
  const k = e.key.toLowerCase();
  if (k === "arrowup" || k === "w") snake.turn(0, -1);
  else if (k === "arrowdown" || k === "s") snake.turn(0, 1);
  else if (k === "arrowleft" || k === "a") snake.turn(-1, 0);
  else if (k === "arrowright" || k === "d") snake.turn(1, 0);
  else if (k === " ") snake.togglePause();
  if (k.startsWith("arrow") || k === " ") e.preventDefault();
});

let snakeTX, snakeTY;
$("canvas").addEventListener("touchstart", e => {
  snakeTX = e.touches[0].clientX; snakeTY = e.touches[0].clientY;
});
$("canvas").addEventListener("touchend", e => {
  const dx = e.changedTouches[0].clientX - snakeTX;
  const dy = e.changedTouches[0].clientY - snakeTY;
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) return;
  if (Math.abs(dx) > Math.abs(dy)) snake.turn(dx > 0 ? 1 : -1, 0);
  else snake.turn(0, dy > 0 ? 1 : -1);
});

$("restart").addEventListener("click", () => { snake.reset(); });
$("snakePause").addEventListener("click", () => snake.togglePause());
$("speed").addEventListener("input", () => {
  if (!$("snakeScreen").classList.contains("hidden")) {
    clearInterval(snake.loop);
    snake.loop = setInterval(() => snake.turn(0, 0), 1); // placeholder, real interval set below
    // real restart:
    clearInterval(snake.loop);
    snake.loop = setInterval(() => {
      // tick is internal; trigger by resetting? Simpler: no-op — user restarts
    }, 9999);
  }
});

function startSnake() {
  show("snakeScreen");
  snake.reset();
}

/* ============================================================
   TAP
   ============================================================ */
const tapState = (() => {
  let state = "idle", count = 0, timer, timeLeft = 10;

  function reset() {
    clearInterval(timer);
    state = "idle"; count = 0; timeLeft = 10;
    $("tapTime").textContent = "10s";
    $("tapScore").textContent = "0";
    $("tapBtn").textContent = "Tap to start!";
  }

  function tap() {
    if (state === "done") return;
    if (state === "retry") reset();
    if (state === "idle") {
      state = "playing";
      timer = setInterval(() => {
        timeLeft--;
        $("tapTime").textContent = timeLeft + "s";
        if (timeLeft <= 0) end();
      }, 1000);
    }
    count++;
    $("tapScore").textContent = count;
    $("tapBtn").textContent = count;
    sfx(600 + count * 8, 0.02, "square", 0.03);
    haptic(5);
  }

  function end() {
    clearInterval(timer);
    state = "done";
    if (count > load("tapBest")) newBest("tapBest", count);
    $("tapBtn").textContent = "🏆 " + count + " — tap to retry";
    sfx(880, 0.15, "triangle");
    setTimeout(() => (state = "retry"), 700);
  }

  return { reset, tap, get timer() { return timer; } };
})();

function startTap() { show("tapScreen"); tapState.reset(); }
$("tapBtn").addEventListener("pointerdown", tapState.tap);

/* ============================================================
   REACTION
   ============================================================ */
const reactionCtrl = (() => {
  let state = "idle", startTime, timeout, times = [];

  function set(cls, txt, sub) {
    $("reactionArea").className = "reaction-area " + cls;
    $("reactionText").textContent = txt;
    $("reactionSub").textContent = sub;
  }

  function reset() {
    clearTimeout(timeout);
    times = [];
    state = "idle";
    set("idle", "Tap to start", "Wait for green…");
    $("reactionLast").textContent = "—";
    $("reactionAvg").textContent = "—";
    $("reactionRound").textContent = "Round 1";
  }

  function tap() {
    if (state === "idle" || state === "done" || state === "tooSoon") {
      state = "waiting";
      set("waiting", "Wait…", "Don't tap yet");
      timeout = setTimeout(() => {
        state = "ready";
        startTime = performance.now();
        set("ready", "TAP!", "");
        haptic(20);
      }, 1000 + Math.random() * 3000);
      return;
    }
    if (state === "waiting") {
      clearTimeout(timeout);
      state = "tooSoon";
      set("tooSoon", "Too soon!", "Tap to try again");
      sfx(200, 0.15, "sawtooth");
      haptic([30, 40]);
      return;
    }
    if (state === "ready") {
      const ms = Math.round(performance.now() - startTime);
      state = "done";
      times.push(ms);
      $("reactionLast").textContent = ms + "ms";
      const avg = Math.round(times.reduce((a, b) => a + b, 0) / times.length);
      $("reactionAvg").textContent = avg + "ms";
      const isBest = load("reactionBest") === 0 || ms < load("reactionBest");
      if (isBest) newBest("reactionBest", ms);
      $("reactionRound").textContent = "Round " + (times.length + 1);
      set("done", ms + "ms", (isBest ? "🏆 New best! " : "") + "Tap to go again");
      sfx(isBest ? 1000 : 700, 0.1, "triangle");
      haptic(30);
    }
  }

  return { reset, tap, get timeout() { return timeout; } };
})();

function startReaction() { show("reactionScreen"); reactionCtrl.reset(); }
$("reactionArea").addEventListener("pointerdown", reactionCtrl.tap);

/* ============================================================
   MEMORY
   ============================================================ */
const MEM_ICONS = ["🍎","🍌","🍇","🍓","🍒","🥝","🍍","🥥"];
const memoryGame = (() => {
  let deck = [], flipped = [], matched = 0, moves = 0, lock = false, timer, start;

  function reset() {
    clearInterval(timer);
    flipped = []; matched = 0; moves = 0; lock = false;
    $("memoryMoves").textContent = "Moves 0";
    $("memoryTime").textContent = "0s";
    start = Date.now();
    timer = setInterval(() => {
      $("memoryTime").textContent = Math.floor((Date.now() - start) / 1000) + "s";
    }, 250);

    deck = [...MEM_ICONS, ...MEM_ICONS]
      .map((icon, i) => ({ icon, id: i }))
      .sort(() => Math.random() - 0.5);

    const grid = $("memoryGrid");
    grid.innerHTML = "";
    deck.forEach((card, i) => {
      const btn = document.createElement("button");
      btn.className = "mem-card";
      btn.textContent = card.icon;
      btn.addEventListener("click", () => flip(i, btn));
      grid.appendChild(btn);
    });
  }

  function flip(i, btn) {
    if (lock) return;
    if (btn.classList.contains("flipped") || btn.classList.contains("matched")) return;
    btn.classList.add("flipped");
    sfx(720, 0.04);
    haptic(8);
    flipped.push({ i, btn });
    if (flipped.length === 2) {
      moves++;
      $("memoryMoves").textContent = "Moves " + moves;
      const [a, b] = flipped;
      if (deck[a.i].icon === deck[b.i].icon) {
        a.btn.classList.add("matched");
        b.btn.classList.add("matched");
        matched++;
        flipped = [];
        sfx(980, 0.08, "triangle");
        if (matched === MEM_ICONS.length) {
          clearInterval(timer);
          const best = load("memoryBest");
          if (best === 0 || moves < best) newBest("memoryBest", moves);
          setTimeout(() => $("memoryMoves").textContent = "🏆 " + moves + " moves", 400);
        }
      } else {
        lock = true;
        setTimeout(() => {
          a.btn.classList.remove("flipped");
          b.btn.classList.remove("flipped");
          flipped = [];
          lock = false;
        }, 700);
      }
    }
  }

  return { reset, get timer() { return timer; } };
})();

function startMemory() { show("memoryScreen"); memoryGame.reset(); }

/* ============================================================
   TIC TAC TOE
   ============================================================ */
let tttBoard, tttOver, tttTurn;
const TTT_WINS = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];

function startTtt() {
  show("tttScreen");
  tttBoard = Array(9).fill(null);
  tttOver = false;
  tttTurn = "X";
  $("tttStatus").textContent = "Your turn";
  renderTtt();
}

function renderTtt() {
  const board = $("tttBoard");
  board.innerHTML = "";
  tttBoard.forEach((v, i) => {
    const b = document.createElement("button");
    b.className = "ttt-cell";
    b.textContent = v || "";
    b.addEventListener("click", () => playTtt(i));
    board.appendChild(b);
  });
}

function playTtt(i) {
  if (tttOver || tttBoard[i] || tttTurn !== "X") return;
  tttBoard[i] = "X";
  sfx(720, 0.05);
  haptic(8);
  renderTtt();
  if (checkTtt()) return;
  tttTurn = "O";
  $("tttStatus").textContent = "CPU thinking…";
  setTimeout(() => {
    const m = bestTttMove();
    if (m !== -1) tttBoard[m] = "O";
    sfx(520, 0.05);
    renderTtt();
    if (checkTtt()) return;
    tttTurn = "X";
    $("tttStatus").textContent = "Your turn";
  }, 400);
}

function checkTtt() {
  for (const [a,b,c] of TTT_WINS) {
    if (tttBoard[a] && tttBoard[a] === tttBoard[b] && tttBoard[a] === tttBoard[c]) {
      tttOver = true;
      $("tttStatus").textContent = tttBoard[a] === "X" ? "🎉 You win!" : "😢 CPU wins";
      if (tttBoard[a] === "X") {
        save("tttBest", load("tttBest") + 1);
        toast("🎉 You won!");
        confetti();
        sfx(1000, 0.15, "triangle");
      } else sfx(200, 0.2, "sawtooth");
      renderTtt();
      return true;
    }
  }
  if (tttBoard.every(c => c)) {
    tttOver = true;
    $("tttStatus").textContent = "🤝 Draw!";
    return true;
  }
  return false;
}

function hasTttWin(who) {
  return TTT_WINS.some(([a,b,c]) => tttBoard[a] === who && tttBoard[b] === who && tttBoard[c] === who);
}

function bestTttMove() {
  for (let i = 0; i < 9; i++) {
    if (!tttBoard[i]) { tttBoard[i] = "O"; if (hasTttWin("O")) { tttBoard[i] = null; return i; } tttBoard[i] = null; }
  }
  for (let i = 0; i < 9; i++) {
    if (!tttBoard[i]) { tttBoard[i] = "X"; if (hasTttWin("X")) { tttBoard[i] = null; return i; } tttBoard[i] = null; }
  }
  for (const p of [4, 0, 2, 6, 8, 1, 3, 5, 7]) if (!tttBoard[p]) return p;
  return -1;
}

$("tttReset").addEventListener("click", startTtt);

/* ============================================================
   BREAKOUT
   ============================================================ */
const breakoutGame = (() => {
  const cvs = $("breakoutCanvas");
  const ctx = cvs.getContext("2d");
  let paddle, ball, bricks, score, lives, loop, running, particles;

  const ROWS = 5, COLS = 8, BW = 40, BH = 16, GAP = 4, TOP = 40, LEFT = 8;

  function reset() {
    paddle = { x: cvs.width / 2 - 40, y: cvs.height - 20, w: 80, h: 10, speed: 6 };
    resetBall();
    bricks = [];
    for (let r = 0; r < ROWS; r++)
      for (let c = 0; c < COLS; c++)
        bricks.push({
          x: LEFT + c * (BW + GAP), y: TOP + r * (BH + GAP),
          w: BW, h: BH, alive: true,
          color: ["#ef4444","#f59e0b","#fbbf24","#22c55e","#6366f1"][r]
        });
    score = 0;
    lives = 3;
    particles = [];
    running = true;
    $("breakoutScore").textContent = "0";
    $("breakoutLives").textContent = "❤️❤️❤️";
    $("breakoutOverlay").classList.add("hidden");
    clearInterval(loop);
    loop = setInterval(tick, 1000 / 60);
  }

  function resetBall() {
    ball = { x: cvs.width / 2, y: cvs.height - 70, r: 6, vx: 3, vy: -3 };
  }

  function tick() {
    if (!running) return;

    if (keys["ArrowLeft"] || keys["a"]) paddle.x -= paddle.speed;
    if (keys["ArrowRight"] || keys["d"]) paddle.x += paddle.speed;
    paddle.x = Math.max(0, Math.min(cvs.width - paddle.w, paddle.x));

    ball.x += ball.vx;
    ball.y += ball.vy;

    if (ball.x - ball.r < 0) { ball.x = ball.r; ball.vx *= -1; }
    if (ball.x + ball.r > cvs.width) { ball.x = cvs.width - ball.r; ball.vx *= -1; }
    if (ball.y - ball.r < 0) { ball.y = ball.r; ball.vy *= -1; }

    if (ball.y + ball.r > cvs.height) {
      lives--;
      $("breakoutLives").textContent = "❤️".repeat(Math.max(0, lives)) || "💀";
      sfx(200, 0.15, "sawtooth");
      haptic([30, 40]);
      if (lives <= 0) return end(false);
      resetBall();
      return;
    }

    if (ball.y + ball.r >= paddle.y && ball.y - ball.r <= paddle.y + paddle.h &&
        ball.x >= paddle.x && ball.x <= paddle.x + paddle.w && ball.vy > 0) {
      ball.vy *= -1;
      ball.y = paddle.y - ball.r;
      const hit = (ball.x - (paddle.x + paddle.w / 2)) / (paddle.w / 2);
      ball.vx = hit * 5;
      sfx(600, 0.03);
    }

    for (const brick of bricks) {
      if (!brick.alive) continue;
      if (ball.x + ball.r > brick.x && ball.x - ball.r < brick.x + brick.w &&
          ball.y + ball.r > brick.y && ball.y - ball.r < brick.y + brick.h) {
        brick.alive = false;
        ball.vy *= -1;
        score += 10;
        $("breakoutScore").textContent = score;
        sfx(900, 0.04);
        haptic(6);
        // Particles
        for (let i = 0; i < 8; i++) {
          particles.push({
            x: brick.x + brick.w / 2, y: brick.y + brick.h / 2,
            vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 4,
            life: 1, color: brick.color
          });
        }
        break;
      }
    }

    // Update particles
    particles.forEach(p => {
      p.x += p.vx; p.y += p.vy; p.vy += 0.15; p.life -= 0.02;
    });
    particles = particles.filter(p => p.life > 0);

    if (bricks.every(b => !b.alive)) return end(true);

    draw();
  }

  function draw() {
    ctx.fillStyle = "#1a1830";
    ctx.fillRect(0, 0, cvs.width, cvs.height);

    bricks.forEach(b => {
      if (!b.alive) return;
      ctx.fillStyle = b.color;
      ctx.fillRect(b.x, b.y, b.w, b.h);
    });

    ctx.fillStyle = "#6366f1";
    ctx.fillRect(paddle.x, paddle.y, paddle.w, paddle.h);

    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
    ctx.fill();

    particles.forEach(p => {
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, 3, 3);
    });
    ctx.globalAlpha = 1;
  }

  function end(won) {
    running = false;
    clearInterval(loop);
    if (score > load("breakoutBest")) newBest("breakoutBest", score);
    $("breakoutTitle").textContent = won ? "🎉 You win!" : "Game over";
    $("breakoutText").textContent = "Score: " + score;
    $("breakoutOverlay").classList.remove("hidden");
  }

  return { reset, get loop() { return loop; } };
})();

function startBreakout() { show("breakoutScreen"); breakoutGame.reset(); }
$("breakoutRestart").addEventListener("click", () => breakoutGame.reset());

function movePaddleX(clientX) {
  const cvs = $("breakoutCanvas");
  const rect = cvs.getBoundingClientRect();
  const scale = cvs.width / rect.width;
  const b = breakoutGame;
  // Access internal via event — simpler: just reassign using canvas
  // We keep paddle accessible via closure through a helper
}
// Mouse move — we use a shared reference
const breakoutCanvas = $("breakoutCanvas");
breakoutCanvas.addEventListener("mousemove", e => {
  const rect = breakoutCanvas.getBoundingClientRect();
  const scale = breakoutCanvas.width / rect.width;
  const px = (e.clientX - rect.left) * scale;
  // No direct access, so dispatch a custom event to the loop:
  breakoutCanvas._lastMouseX = px;
});
breakoutCanvas.addEventListener("touchmove", e => {
  const rect = breakoutCanvas.getBoundingClientRect();
  const scale = breakoutCanvas.width / rect.width;
  const px = (e.touches[0].clientX - rect.left) * scale;
  breakoutCanvas._lastMouseX = px;
  e.preventDefault();
}, { passive: false });

const keys = {};
document.addEventListener("keydown", e => { keys[e.key] = true; });
document.addEventListener("keyup", e => { keys[e.key] = false; });

/* ============================================================
   WHACK-A-MOLE
   ============================================================ */
const moleGame = (() => {
  let score = 0, timeLeft = 30, timer, spawnTimer, active = null;

  function reset() {
    score = 0; timeLeft = 30; active = null;
    $("moleScore").textContent = "0";
    $("moleTime").textContent = "30s";

    const grid = $("moleGrid");
    grid.innerHTML = "";
    for (let i = 0; i < 9; i++) {
      const h = document.createElement("div");
      h.className = "mole-hole";
      h.dataset.i = i;
      h.textContent = "⚫";
      h.addEventListener("pointerdown", () => whack(i, h));
      grid.appendChild(h);
    }

    clearInterval(timer);
    clearInterval(spawnTimer);

    timer = setInterval(() => {
      timeLeft--;
      $("moleTime").textContent = timeLeft + "s";
      if (timeLeft <= 0) end();
    }, 1000);

    spawnTimer = setInterval(spawn, 700);
    spawn();
  }

  function spawn() {
    const holes = document.querySelectorAll(".mole-hole");
    holes.forEach(h => { h.classList.remove("active", "bomb"); h.textContent = "⚫"; });
    const idx = Math.floor(Math.random() * 9);
    const isBomb = Math.random() < 0.2;
    const h = holes[idx];
    h.classList.add("active");
    if (isBomb) { h.classList.add("bomb"); h.textContent = "💣"; }
    else h.textContent = "🐹";
    active = { idx, isBomb, h };
  }

  function whack(i, h) {
    if (!active || active.idx !== i) return;
    const { isBomb } = active;
    const rect = h.getBoundingClientRect();
    const delta = isBomb ? -3 : 1;
    score = Math.max(0, score + delta);
    $("moleScore").textContent = score;
    showFloat(rect.left + rect.width / 2, rect.top + rect.height / 2, delta);
    sfx(isBomb ? 200 : 880, 0.05);
    haptic(8);
    h.classList.remove("active", "bomb");
    h.textContent = "⚫";
    active = null;
  }

  function showFloat(x, y, val) {
    const el = document.createElement("div");
    el.className = "float-score " + (val > 0 ? "plus" : "minus");
    el.textContent = (val > 0 ? "+" : "") + val;
    el.style.left = x + "px";
    el.style.top = y + "px";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 900);
  }

  function end() {
    clearInterval(timer);
    clearInterval(spawnTimer);
    if (score > load("moleBest")) newBest("moleBest", score);
    $("moleTime").textContent = "Done!";
    $("moleScore").textContent = score;
  }

  return { reset, get timer() { return timer; }, get spawnTimer() { return spawnTimer; } };
})();

function startMole() { show("moleScreen"); moleGame.reset(); }

/* ============================================================
   2048
   ============================================================ */
let g2048Board, g2048Score, g2048Over, g2048Won, g2048History;

function start2048() {
  show("g2048Screen");
  g2048Board = Array(4).fill().map(() => Array(4).fill(0));
  g2048Score = 0;
  g2048Over = false;
  g2048Won = false;
  g2048History = [];
  add2048Tile();
  add2048Tile();
  $("g2048Overlay").classList.add("hidden");
  $("g2048Undo").disabled = true;
  render2048();
}

function saveHistory2048(beforeBoard, beforeScore) {
  g2048History.push({ board: beforeBoard.map(r => [...r]), score: beforeScore });
  if (g2048History.length > 20) g2048History.shift();
  $("g2048Undo").disabled = false;
}

function undo2048() {
  if (!g2048History.length) return;
  const p = g2048History.pop();
  g2048Board = p.board.map(r => [...r]);
  g2048Score = p.score;
  g2048Over = false;
  $("g2048Undo").disabled = g2048History.length === 0;
  $("g2048Overlay").classList.add("hidden");
  sfx(500, 0.05);
  render2048();
}

function add2048Tile() {
  const empties = [];
  for (let r = 0; r < 4; r++)
    for (let c = 0; c < 4; c++)
      if (g2048Board[r][c] === 0) empties.push([r, c]);
  if (!empties.length) return;
  const [r, c] = empties[Math.floor(Math.random() * empties.length)];
  g2048Board[r][c] = Math.random() < 0.9 ? 2 : 4;
}

function render2048() {
  const grid = $("g2048Grid");
  grid.innerHTML = "";
  for (let r = 0; r < 4; r++)
    for (let c = 0; c < 4; c++) {
      const v = g2048Board[r][c];
      const cell = document.createElement("div");
      cell.className = "g2048-cell";
      cell.textContent = v || "";
      if (v) cell.dataset.v = v;
      grid.appendChild(cell);
    }
  $("g2048Score").textContent = g2048Score;
  $("g2048BestScore").textContent = Math.max(load("g2048Best"), g2048Score);
}

function slide2048(row) {
  const filtered = row.filter(v => v);
  const merged = [];
  for (let i = 0; i < filtered.length; i++) {
    if (filtered[i] === filtered[i + 1]) {
      merged.push(filtered[i] * 2);
      g2048Score += filtered[i] * 2;
      i++;
    } else merged.push(filtered[i]);
  }
  while (merged.length < 4) merged.push(0);
  return merged;
}

function transpose2048(b) { return b[0].map((_, c) => b.map(row => row[c])); }

function move2048(dir) {
  if (g2048Over) return;
  const beforeBoard = g2048Board.map(r => [...r]);
  const beforeScore = g2048Score;
  const before = JSON.stringify(g2048Board);

  if (dir === "left") g2048Board = g2048Board.map(row => slide2048(row));
  else if (dir === "right") g2048Board = g2048Board.map(row => slide2048([...row].reverse()).reverse());
  else if (dir === "up") g2048Board = transpose2048(transpose2048(g2048Board).map(row => slide2048(row)));
  else if (dir === "down") g2048Board = transpose2048(transpose2048(g2048Board).map(row => slide2048([...row].reverse()).reverse()));

  if (JSON.stringify(g2048Board) !== before) {
    saveHistory2048(beforeBoard, beforeScore);
    add2048Tile();
    render2048();
    check2048End();
    sfx(660, 0.03, "sine", 0.03);
  }
}

function check2048End() {
  if (!g2048Won) {
    for (let r = 0; r < 4; r++)
      for (let c = 0; c < 4; c++)
        if (g2048Board[r][c] === 2048) {
          g2048Won = true;
          if (g2048Score > load("g2048Best")) newBest("g2048Best", g2048Score);
          $("g2048Title").textContent = "🎉 You hit 2048!";
          $("g2048Text").textContent = "Score: " + g2048Score;
          $("g2048Continue").classList.remove("hidden");
          $("g2048Overlay").classList.remove("hidden");
          $("g2048Continue").onclick = () => $("g2048Overlay").classList.add("hidden");
          return;
        }
  }
  for (let r = 0; r < 4; r++)
    for (let c = 0; c < 4; c++)
      if (g2048Board[r][c] === 0) return;
  for (let r = 0; r < 4; r++)
    for (let c = 0; c < 4; c++) {
      if (c < 3 && g2048Board[r][c] === g2048Board[r][c + 1]) return;
      if (r < 3 && g2048Board[r][c] === g2048Board[r + 1][c]) return;
    }
  g2048Over = true;
  if (g2048Score > load("g2048Best")) newBest("g2048Best", g2048Score);
  $("g2048Title").textContent = "Game over";
  $("g2048Text").textContent = "Score: " + g2048Score;
  $("g2048Continue").classList.add("hidden");
  $("g2048Overlay").classList.remove("hidden");
  sfx(180, 0.3, "sawtooth");
}

document.addEventListener("keydown", e => {
  if ($("g2048Screen").classList.contains("hidden")) return;
  const k = e.key.toLowerCase();
  if (k === "arrowleft" || k === "a") move2048("left");
  else if (k === "arrowright" || k === "d") move2048("right");
  else if (k === "arrowup" || k === "w") move2048("up");
  else if (k === "arrowdown" || k === "s") move2048("down");
  if (k.startsWith("arrow")) e.preventDefault();
});

let g2048TX, g2048TY;
$("g2048Grid").addEventListener("touchstart", e => {
  g2048TX = e.touches[0].clientX; g2048TY = e.touches[0].clientY;
}, { passive: true });
$("g2048Grid").addEventListener("touchend", e => {
  const dx = e.changedTouches[0].clientX - g2048TX;
  const dy = e.changedTouches[0].clientY - g2048TY;
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 25) return;
  if (Math.abs(dx) > Math.abs(dy)) move2048(dx > 0 ? "right" : "left");
  else move2048(dy > 0 ? "down" : "up");
});

$("g2048Reset").addEventListener("click", start2048);
$("g2048Restart2").addEventListener("click", start2048);
$("g2048Undo").addEventListener("click", undo2048);

/* ============================================================
   SIMON
   ============================================================ */
const simonGame = (() => {
  let seq = [], input = [], round = 0, playing = false, allow = false;

  function reset() {
    seq = []; input = []; round = 0;
    playing = true; allow = false;
    $("simonRound").textContent = "Round 0";
    $("simonStatus").textContent = "Watch…";
    $("simonStart").textContent = "Restart";
    nextRound();
  }

  function nextRound() {
    round++;
    $("simonRound").textContent = "Round " + round;
    input = [];
    seq.push(Math.floor(Math.random() * 4));
    allow = false;
    $("simonStatus").textContent = "Watch…";
    playSeq(0);
  }

  function playSeq(i) {
    if (!playing || i >= seq.length) {
      if (playing) { allow = true; $("simonStatus").textContent = "Your turn!"; }
      return;
    }
    const idx = seq[i];
    const btn = document.querySelector(`.simon-btn[data-i="${idx}"]`);
    btn.classList.add("lit");
    sfx([329, 261, 392, 523][idx], 0.12, "sine", 0.06);
    setTimeout(() => {
      btn.classList.remove("lit");
      // Speed increases with round
      const speed = Math.max(120, 320 - round * 12);
      setTimeout(() => playSeq(i + 1), speed);
    }, Math.max(180, 350 - round * 10));
  }

  function press(idx) {
    if (!allow || !playing) return;
    const btn = document.querySelector(`.simon-btn[data-i="${idx}"]`);
    btn.classList.add("lit");
    sfx([329, 261, 392, 523][idx], 0.08, "sine", 0.06);
    haptic(8);
    setTimeout(() => btn.classList.remove("lit"), 200);

    input.push(idx);
    const pos = input.length - 1;
    if (input[pos] !== seq[pos]) {
      playing = false; allow = false;
      $("simonStatus").textContent = "❌ Wrong!";
      if (round - 1 > load("simonBest")) newBest("simonBest", round - 1);
      setTimeout(() => $("simonStatus").textContent = "Reached: " + (round - 1), 800);
      sfx(200, 0.25, "sawtooth");
      haptic([30, 40]);
      return;
    }
    if (input.length === seq.length) {
      allow = false;
      $("simonStatus").textContent = "✅ Good!";
      setTimeout(nextRound, 700);
    }
  }

  return { reset, press, get playing() { return playing; }, set playing(v) { playing = v; } };
})();

function startSimon() { show("simonScreen"); simonGame.reset(); }
$$(".simon-btn").forEach(b => b.addEventListener("click", () => simonGame.press(Number(b.dataset.i))));
$("simonStart").addEventListener("click", () => simonGame.reset());

/* ============================================================
   INIT
   ============================================================ */
updateBest();