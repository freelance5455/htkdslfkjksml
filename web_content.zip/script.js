
const DOWNLOAD_URL = "";

const menuButton = document.getElementById("menuButton");
const navMenu = document.getElementById("navMenu");
const downloadButton = document.getElementById("downloadButton");
const downloadNote = document.getElementById("downloadNote");

menuButton.addEventListener("click", () => {
  navMenu.classList.toggle("open");
});

document.querySelectorAll(".nav-menu a").forEach(link => {
  link.addEventListener("click", () => {
    navMenu.classList.remove("open");
  });
});

if (DOWNLOAD_URL.trim() !== "") {
  downloadButton.disabled = false;
  downloadButton.textContent = "↓  BAIXAR TERMINAL PUBLIC";
  downloadButton.style.background = "#48f59a";
  downloadButton.style.color = "#07120b";
  downloadButton.style.cursor = "pointer";

  downloadNote.textContent = "Arquivo oficial disponível para download.";

  downloadButton.addEventListener("click", () => {
    window.open(DOWNLOAD_URL, "_blank");
  });
} else {
  downloadButton.disabled = true;
}
