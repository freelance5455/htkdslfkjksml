const ROWS=4,COLS=7;
const KEY="dot_grid_history_suggestion_v3";
let currentPoints=[];
let sequence=[];
let saved=JSON.parse(localStorage.getItem(KEY)||"[]");

const grid=document.getElementById("grid");
const status=document.getElementById("status");
const sequenceEl=document.getElementById("sequence");
const suggestionsEl=document.getElementById("suggestions");
const matchInfo=document.getElementById("matchInfo");
const color=document.getElementById("dotColor");
const dataName=document.getElementById("dataName");

function pos(r,c){return String.fromCharCode(65+r)+(c+1)}
function parse(name){
  const m=String(name).match(/^([A-D])([1-7])$/);
  return m?{r:m[1].charCodeAt(0)-65,c:+m[2]-1}:null;
}
function findPoint(r,c){return currentPoints.find(p=>p.r===r&&p.c===c)}
function drawGrid(){
  grid.innerHTML="";
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){
    const b=document.createElement("button");
    b.className="cell";
    if(sequence.length && sequence[sequence.length-1]===pos(r,c)) b.classList.add("current");
    const p=findPoint(r,c);
    if(p){const d=document.createElement("span");d.className="dot";d.style.background=p.color;b.appendChild(d)}
    b.title=pos(r,c);
    b.onclick=()=>clickCell(r,c);
    grid.appendChild(b);
  }
}
function clickCell(r,c){
  const name=pos(r,c);
  if(!findPoint(r,c)) currentPoints.push({r,c,color:color.value});
  sequence.push(name);
  status.textContent=`Current: ${name} — আগের Data খোঁজা হচ্ছে...`;
  renderSequence();
  drawGrid();
  showSuggestions(name);
}
function renderSequence(){
  sequenceEl.innerHTML="";
  if(!sequence.length){sequenceEl.className="sequence empty";sequenceEl.textContent="এখনও কোনো ঘর নির্বাচন করা হয়নি";return}
  sequenceEl.className="sequence";
  sequence.forEach((x,i)=>{
    const s=document.createElement("span");s.className="seqTag";s.textContent=x;sequenceEl.appendChild(s);
    if(i<sequence.length-1){const a=document.createElement("span");a.className="arrow";a.textContent="→";sequenceEl.appendChild(a)}
  });
}
function showSuggestions(current){
  // Find every historical occurrence of the clicked cell and collect the immediately-next cell.
  const counts={};
  let occurrences=0;
  saved.forEach(item=>{
    const seq=item.sequence||[];
    seq.forEach((cell,i)=>{
      if(cell===current){
        occurrences++;
        const next=seq[i+1];
        if(next) counts[next]=(counts[next]||0)+1;
      }
    });
  });
  suggestionsEl.innerHTML="";
  const entries=Object.entries(counts).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
  matchInfo.textContent=occurrences?`${occurrences} historical match`:"No historical match";
  if(!entries.length){
    suggestionsEl.innerHTML='<span class="muted">এই ঘরের পরে কোনো পুরোনো Data পাওয়া যায়নি। আরও Pattern Save করলে suggestion তৈরি হবে।</span>';
    return;
  }
  entries.forEach(([next,count],i)=>{
    const b=document.createElement("button");b.className="suggestBtn";
    b.innerHTML=`${next} <small>${count} বার</small>`;
    b.title="Suggestion-এ ক্লিক করলে সেই ঘর Current sequence-এ যোগ হবে";
    b.onclick=()=>clickSuggested(next);
    suggestionsEl.appendChild(b);
  });
}
function clickSuggested(name){
  const p=parse(name);
  if(!findPoint(p.r,p.c)) currentPoints.push({r:p.r,c:p.c,color:color.value});
  sequence.push(name);
  status.textContent=`Suggestion থেকে ${name} নেওয়া হয়েছে`;
  renderSequence();drawGrid();showSuggestions(name);
}
function undo(){
  const last=sequence.pop();
  if(last){
    const p=parse(last);
    // Remove its dot only if this cell is no longer present in sequence.
    if(!sequence.includes(last)){
      currentPoints=currentPoints.filter(x=>!(x.r===p.r&&x.c===p.c));
    }
  }
  const cur=sequence[sequence.length-1];
  status.textContent=cur?`Current: ${cur}`:"Start করুন একটি ঘরে ক্লিক করে";
  renderSequence();drawGrid();if(cur)showSuggestions(cur);else resetSuggestions();
}
function resetSuggestions(){
  matchInfo.textContent="";
  suggestionsEl.innerHTML='<span class="muted">আগের ডাটা থেকে suggestion এখানে আসবে</span>';
}
function clearCurrent(){currentPoints=[];sequence=[];status.textContent="Start করুন একটি ঘরে ক্লিক করে";renderSequence();drawGrid();resetSuggestions()}
function savePattern(){
  if(!sequence.length){alert("আগে কয়েকটি ঘরে ক্লিক করুন।");return}
  const title=dataName.value.trim()||`Data ${saved.length+1}`;
  saved.unshift({
    id:Date.now(),title,
    sequence:[...sequence],
    points:JSON.parse(JSON.stringify(currentPoints)),
    created:new Date().toLocaleString("bn-BD")
  });
  localStorage.setItem(KEY,JSON.stringify(saved));
  dataName.value="";
  clearCurrent();
  renderSaved();
  alert("Pattern Save হয়েছে। এখন নতুন Pattern তৈরি করুন।");
}
function renderSaved(){
  const list=document.getElementById("savedList"),empty=document.getElementById("empty");
  list.innerHTML="";empty.style.display=saved.length?"none":"block";
  saved.forEach(item=>{
    const box=document.createElement("div");box.className="savedItem";
    const title=document.createElement("div");title.className="savedTitle";
    const strong=document.createElement("strong");strong.textContent=item.title;
    const small=document.createElement("small");small.textContent=item.created;
    title.append(strong,small);

    const seq=document.createElement("div");seq.className="savedSeq";
    (item.sequence||[]).forEach((x,i)=>{
      const s=document.createElement("span");s.textContent=i?`→ ${x}`:x;seq.appendChild(s);
    });

    const mg=document.createElement("div");mg.className="miniGrid";
    for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){
      const mc=document.createElement("div");mc.className="miniCell";
      const p=(item.points||[]).find(x=>x.r===r&&x.c===c);
      if(p){const d=document.createElement("span");d.className="miniDot";d.style.background=p.color;mc.appendChild(d)}
      mg.appendChild(mc);
    }
    const acts=document.createElement("div");acts.className="savedActions";
    const load=document.createElement("button");load.className="load";load.textContent="Load / Edit";
    load.onclick=()=>{currentPoints=JSON.parse(JSON.stringify(item.points||[]));sequence=[...(item.sequence||[])];status.textContent=sequence.length?`Current: ${sequence[sequence.length-1]}`:"Start করুন একটি ঘরে ক্লিক করে";renderSequence();drawGrid();if(sequence.length)showSuggestions(sequence[sequence.length-1]);window.scrollTo({top:0,behavior:"smooth"})};
    const del=document.createElement("button");del.className="delete";del.textContent="Delete";
    del.onclick=()=>{if(confirm("এই Pattern Delete করবেন?")){saved=saved.filter(x=>x.id!==item.id);localStorage.setItem(KEY,JSON.stringify(saved));renderSaved();if(sequence.length)showSuggestions(sequence[sequence.length-1])}};
    acts.append(load,del);
    box.append(title,seq,mg,acts);list.appendChild(box);
  });
}
document.getElementById("undoBtn").onclick=undo;
document.getElementById("clearBtn").onclick=clearCurrent;
document.getElementById("saveBtn").onclick=savePattern;
document.getElementById("deleteAll").onclick=()=>{if(saved.length&&confirm("সব Saved Pattern Delete করবেন?")){saved=[];localStorage.removeItem(KEY);renderSaved();resetSuggestions()}};
drawGrid();renderSaved();
