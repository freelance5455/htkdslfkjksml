const form = document.getElementById("download-form");
const urlInput = document.getElementById("media-url");
const pasteBtn = document.getElementById("paste-btn");
const statusEl = document.getElementById("status");
const result = document.getElementById("result");
const resultTitle = document.getElementById("result-title");
const resultDetail = document.getElementById("result-detail");
const directDownload = document.getElementById("direct-download");

function identifyPlatform(url) {
  const host = new URL(url).hostname.toLowerCase().replace(/^www\./, "");
  if (host === "youtube.com" || host === "youtu.be" || host.endsWith(".youtube.com")) return "YouTube";
  if (host === "tiktok.com" || host.endsWith(".tiktok.com")) return "TikTok";
  if (host === "instagram.com" || host.endsWith(".instagram.com")) return "Instagram";
  return "Other media";
}

pasteBtn.addEventListener("click", async () => {
  try {
    const text = await navigator.clipboard.readText();
    if (text) {
      urlInput.value = text.trim();
      statusEl.textContent = "Link pasted. Press Find media.";
    } else {
      statusEl.textContent = "Clipboard is empty.";
    }
  } catch {
    statusEl.textContent = "Clipboard access isn't available. Paste the link into the box manually.";
    urlInput.focus();
  }
});

form.addEventListener("submit", (event) => {
  event.preventDefault();
  statusEl.textContent = "";
  result.classList.add("hidden");

  let parsed;
  try {
    parsed = new URL(urlInput.value.trim());
    if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Invalid protocol");
  } catch {
    statusEl.textContent = "Please enter a valid link beginning with https://";
    return;
  }

  const platform = identifyPlatform(parsed.href);
  result.classList.remove("hidden");

  if (/\.(mp4|webm|mov|mp3|m4a|ogg|wav)(\?.*)?$/i.test(parsed.pathname + parsed.search)) {
    resultTitle.textContent = "Direct media link detected";
    resultDetail.textContent = "Your browser may download this file directly. Some hosts restrict cross-site downloads.";
    directDownload.href = parsed.href;
    directDownload.download = "";
    directDownload.classList.remove("hidden");
    statusEl.textContent = "";
  } else {
    resultTitle.textContent = `${platform} link detected`;
    resultDetail.textContent = "This page is a frontend demo. Platform video extraction needs a permitted backend/API and may not be available for every link.";
    directDownload.removeAttribute("href");
    directDownload.removeAttribute("download");
    directDownload.classList.add("hidden");
    statusEl.textContent = "No download was started.";
  }
});
