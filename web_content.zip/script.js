/* =========================================================
   QUIZKIDS
   ETAPA 16 + 19 + EXPLICAÇÕES PASSO A PASSO
========================================================= */

const SAVE_KEY = "QUIZKIDS_SAVE_V16_V19";

const MATERIAS = {
    adicao:{nome:"Adição",emoji:"➕"},
    subtracao:{nome:"Subtração",emoji:"➖"},
    multiplicacao:{nome:"Multiplicação",emoji:"✖️"},
    divisao:{nome:"Divisão",emoji:"➗"}
};

const NIVEIS = {
    facil:"Fácil",
    medio:"Médio",
    dificil:"Difícil"
};

let jogador;
let materiaAtual = "adicao";
let nivelAtual = "facil";
let quizAtual = 1;

let perguntas = [];
let perguntaAtual = 0;
let acertos = 0;
let vidas = 3;
let combo = 0;
let melhorComboRodada = 0;
let tempo = 20;
let intervaloTempo = null;

let quizEmAndamento = false;

let provaAtual = null;
let respostasProva = [];

let avatarSelecionado = "🧑‍🎓";
let fotoSelecionada = "";

let somLigado = true;

let respostaSendoMostrada = false;


/* =========================================================
   SOM
========================================================= */

const AudioContextClass =
    window.AudioContext || window.webkitAudioContext;

let audioContext = null;

function tocarNotas(notas, volume = 0.12){

    if(!somLigado) return;

    try{

        if(!audioContext){
            audioContext = new AudioContextClass();
        }

        if(audioContext.state === "suspended"){
            audioContext.resume();
        }

        let inicio = audioContext.currentTime;

        notas.forEach(nota => {

            const oscilador =
                audioContext.createOscillator();

            const ganho =
                audioContext.createGain();

            oscilador.connect(ganho);
            ganho.connect(audioContext.destination);

            oscilador.type =
                nota.tipo || "sine";

            oscilador.frequency.setValueAtTime(
                nota.frequencia,
                inicio
            );

            ganho.gain.setValueAtTime(
                0.001,
                inicio
            );

            ganho.gain.exponentialRampToValueAtTime(
                volume,
                inicio + 0.015
            );

            ganho.gain.exponentialRampToValueAtTime(
                0.001,
                inicio + nota.duracao
            );

            oscilador.start(inicio);

            oscilador.stop(
                inicio + nota.duracao
            );

            inicio +=
                nota.duracao +
                (nota.pausa || 0);
        });

    }catch(e){}
}

function tocarSom(tipo){

    if(tipo === "certo"){

        tocarNotas([
            {frequencia:660,duracao:.10},
            {frequencia:880,duracao:.16}
        ]);

    }else if(tipo === "errado"){

        tocarNotas([
            {frequencia:300,duracao:.10},
            {frequencia:220,duracao:.18}
        ]);

    }else if(tipo === "clique"){

        tocarNotas([
            {frequencia:520,duracao:.06}
        ],.08);

    }else if(tipo === "combo"){

        tocarNotas([
            {frequencia:660,duracao:.08},
            {frequencia:780,duracao:.08},
            {frequencia:920,duracao:.14}
        ]);

    }else if(tipo === "vitoria"){

        tocarNotas([
            {frequencia:660,duracao:.10},
            {frequencia:784,duracao:.10},
            {frequencia:988,duracao:.10},
            {frequencia:1175,duracao:.20}
        ]);

    }else if(tipo === "estrelas"){

        tocarNotas([
            {frequencia:880,duracao:.08},
            {frequencia:1046,duracao:.08},
            {frequencia:1318,duracao:.18}
        ]);

    }else if(tipo === "nivel"){

        tocarNotas([
            {frequencia:523,duracao:.08},
            {frequencia:659,duracao:.08},
            {frequencia:784,duracao:.08},
            {frequencia:1046,duracao:.18}
        ]);

    }else if(tipo === "missao"){

        tocarNotas([
            {frequencia:784,duracao:.08},
            {frequencia:988,duracao:.08},
            {frequencia:1175,duracao:.18}
        ]);

    }else if(tipo === "provaPassou"){

        tocarNotas([
            {frequencia:523,duracao:.08},
            {frequencia:659,duracao:.08},
            {frequencia:784,duracao:.08},
            {frequencia:1046,duracao:.08},
            {frequencia:1318,duracao:.20}
        ]);

    }else if(tipo === "provaFalhou"){

        tocarNotas([
            {frequencia:330,duracao:.10},
            {frequencia:277,duracao:.10},
            {frequencia:220,duracao:.18}
        ]);
    }
}

function alternarSom(){

    somLigado = !somLigado;

    localStorage.setItem(
        "QUIZKIDS_SOM",
        somLigado ? "1" : "0"
    );

    atualizarSom();

    if(somLigado){
        tocarSom("clique");
    }
}

function atualizarSom(){

    const texto =
        document.getElementById("textoSom");

    if(texto){
        texto.textContent =
            somLigado ? "Ligado" : "Desligado";
    }
}


/* =========================================================
   DADOS DO JOGADOR
========================================================= */

function criarJogador(){

    const progresso = {};

    Object.keys(MATERIAS).forEach(materia => {

        progresso[materia] = {
            facil:criarQuizzes(),
            medio:criarQuizzes(),
            dificil:criarQuizzes(),
            provaFacil:false,
            provaMedio:false
        };

    });

    return {

        nome:"Herói",
        avatar:"🧑‍🎓",
        foto:"",

        estrelas:0,
        moedas:0,
        xp:0,
        nivel:1,

        combo:0,
        melhorCombo:0,

        totalAcertos:0,
        quizzesConcluidos:0,

        progresso,

        conquistas:[],
        medalhas:[],
        missoes:[],
        desafios:[],

        evolucao:0,
        som:true
    };
}

function criarQuizzes(){

    return Array.from(
        {length:10},
        () => ({
            concluido:false,
            estrelas:0
        })
    );
}

function carregarDados(){

    const salvo =
        localStorage.getItem(SAVE_KEY);

    if(!salvo){

        jogador = criarJogador();

    }else{

        try{
            jogador =
                normalizarJogador(
                    JSON.parse(salvo)
                );
        }catch(e){
            jogador = criarJogador();
        }
    }

    const somSalvo =
        localStorage.getItem("QUIZKIDS_SOM");

    somLigado =
        somSalvo === null
            ? true
            : somSalvo === "1";

    atualizarTudo();
}

function normalizarJogador(j){

    const novo = criarJogador();

    novo.nome = j.nome || "Herói";
    novo.avatar = j.avatar || "🧑‍🎓";
    novo.foto = j.foto || "";

    novo.estrelas = Number(j.estrelas) || 0;
    novo.moedas = Number(j.moedas) || 0;
    novo.xp = Number(j.xp) || 0;
    novo.nivel = Number(j.nivel) || 1;

    novo.combo = Number(j.combo) || 0;
    novo.melhorCombo = Number(j.melhorCombo) || 0;

    novo.totalAcertos =
        Number(j.totalAcertos) || 0;

    novo.quizzesConcluidos =
        Number(j.quizzesConcluidos) || 0;

    novo.conquistas =
        Array.isArray(j.conquistas)
            ? j.conquistas : [];

    novo.medalhas =
        Array.isArray(j.medalhas)
            ? j.medalhas : [];

    novo.missoes =
        Array.isArray(j.missoes)
            ? j.missoes : [];

    novo.desafios =
        Array.isArray(j.desafios)
            ? j.desafios : [];

    novo.evolucao =
        Number(j.evolucao) || 0;

    if(j.progresso){

        Object.keys(MATERIAS).forEach(materia => {

            if(!j.progresso[materia]) return;

            ["facil","medio","dificil"]
            .forEach(nivel => {

                if(
                    Array.isArray(
                        j.progresso[materia][nivel]
                    )
                ){

                    novo.progresso[materia][nivel] =
                        j.progresso[materia][nivel]
                        .map(q => ({
                            concluido:!!q.concluido,
                            estrelas:Number(q.estrelas) || 0
                        }));
                }
            });

            novo.progresso[materia].provaFacil =
                !!j.progresso[materia].provaFacil;

            novo.progresso[materia].provaMedio =
                !!j.progresso[materia].provaMedio;
        });
    }

    return novo;
}

function salvar(){

    localStorage.setItem(
        SAVE_KEY,
        JSON.stringify(jogador)
    );

    atualizarTudo();
}

function salvarSemAtualizar(){

    localStorage.setItem(
        SAVE_KEY,
        JSON.stringify(jogador)
    );
}


/* =========================================================
   TELAS
========================================================= */

function mostrarTela(id){

    document.querySelectorAll(".tela")
        .forEach(tela =>
            tela.classList.remove("ativa")
        );

    const tela =
        document.getElementById(id);

    if(tela){

        tela.classList.add("ativa");

        window.scrollTo(0,0);
    }

    atualizarTudo();
}

function voltarInicio(){
    mostrarTela("telaInicio");
}

function abrirMapa(){
    mostrarTela("telaMapa");
}

function abrirPersonagem(){
    mostrarTela("telaPersonagem");
}

function abrirProgresso(){
    mostrarTela("telaProgresso");
}

function abrirConquistas(){
    mostrarTela("telaConquistas");
}

function abrirRecompensas(){
    mostrarTela("telaRecompensas");
}

function abrirMissoes(){

    criarMissoesSeNecessario();
    atualizarMissoesTela();

    mostrarTela("telaMissoes");
}

function abrirDesafios(){

    criarDesafiosSeNecessario();
    atualizarDesafiosTela();

    mostrarTela("telaDesafios");
}

function abrirEvolucao(){
    mostrarTela("telaEvolucao");
}

function abrirResponsaveis(){

    atualizarAreaResponsaveis();

    mostrarTela("telaResponsaveis");
}


/* =========================================================
   PERSONAGEM
========================================================= */

function selecionarAvatar(botao,avatar){

    document.querySelectorAll(".avatar-option")
        .forEach(b =>
            b.classList.remove("selecionado")
        );

    botao.classList.add("selecionado");

    avatarSelecionado = avatar;
    fotoSelecionada = "";

    const preview =
        document.getElementById("previewFoto");

    if(preview){
        preview.innerHTML = "";
    }

    tocarSom("clique");
}

function carregarFoto(event){

    const arquivo =
        event.target.files[0];

    if(!arquivo) return;

    const leitor =
        new FileReader();

    leitor.onload = function(e){

        fotoSelecionada =
            e.target.result;

        document.getElementById(
            "previewFoto"
        ).innerHTML =
            `<img src="${fotoSelecionada}" alt="Foto">`;

        tocarSom("clique");
    };

    leitor.readAsDataURL(arquivo);
}

function salvarPersonagem(){

    const input =
        document.getElementById("inputNome");

    let nome =
        input.value.trim();

    if(!nome){
        nome = "Herói";
    }

    jogador.nome = nome;
    jogador.avatar = avatarSelecionado;

    if(fotoSelecionada){
        jogador.foto = fotoSelecionada;
    }

    salvar();

    mostrarMensagem(
        "Personagem salvo! 🎉"
    );

    tocarSom("vitoria");

    abrirMapa();
}

function editarPersonagem(){

    document.getElementById(
        "inputNome"
    ).value = jogador.nome;

    avatarSelecionado =
        jogador.avatar || "🧑‍🎓";

    fotoSelecionada =
        jogador.foto || "";

    const preview =
        document.getElementById("previewFoto");

    if(jogador.foto){

        preview.innerHTML =
            `<img src="${jogador.foto}" alt="Foto">`;

    }else{

        preview.innerHTML = "";
    }

    mostrarTela("telaCriarPersonagem");
}


/* =========================================================
   QUIZZES
========================================================= */

function abrirQuizzes(materia){

    materiaAtual = materia;
    nivelAtual = "facil";

    atualizarQuizzes();

    mostrarTela("telaQuizzes");
}

function trocarNivel(nivel){

    if(nivel !== "facil"){

        const desbloqueado =
            nivel === "medio"
                ? nivelMedioDesbloqueado()
                : nivelDificilDesbloqueado();

        if(!desbloqueado){

            mostrarMensagem(
                nivel === "medio"
                    ? "Complete o Fácil e passe na prova! 🔒"
                    : "Complete o Médio e passe na prova! 🔒"
            );

            tocarSom("errado");

            return;
        }
    }

    nivelAtual = nivel;

    atualizarQuizzes();

    tocarSom("clique");
}

function nivelMedioDesbloqueado(){

    const dados =
        jogador.progresso[materiaAtual];

    return (
        dados.facil.every(q => q.concluido) &&
        dados.provaFacil
    );
}

function nivelDificilDesbloqueado(){

    const dados =
        jogador.progresso[materiaAtual];

    return (
        dados.medio.every(q => q.concluido) &&
        dados.provaMedio
    );
}

function atualizarQuizzes(){

    const dados =
        jogador.progresso[materiaAtual];

    const lista =
        dados[nivelAtual];

    document.getElementById(
        "tituloMateria"
    ).textContent =
        `${MATERIAS[materiaAtual].emoji} ${MATERIAS[materiaAtual].nome}`;

    document.querySelectorAll(".nivel-btn")
        .forEach(btn =>
            btn.classList.remove("ativo")
        );

    const tab =
        document.getElementById(
            "tab" +
            nivelAtual.charAt(0).toUpperCase() +
            nivelAtual.slice(1)
        );

    if(tab){
        tab.classList.add("ativo");
    }

    atualizarAbas();

    const concluidos =
        lista.filter(q => q.concluido).length;

    document.getElementById(
        "barraMateria"
    ).style.width =
        concluidos / 10 * 100 + "%";

    document.getElementById(
        "textoProgressoMateria"
    ).textContent =
        `${concluidos}/10`;

    const container =
        document.getElementById(
            "listaQuizzes"
        );

    container.innerHTML = "";

    lista.forEach((quiz,index) => {

        const numero = index + 1;

        const desbloqueado =
            numero === 1 ||
            lista[index - 1].concluido;

        const estrelas =
            quiz.estrelas > 0
                ? "⭐".repeat(quiz.estrelas) +
                  "☆".repeat(3 - quiz.estrelas)
                : "☆☆☆";

        const div =
            document.createElement("div");

        div.className =
            "quiz-card" +
            (quiz.concluido ? " completo" : "") +
            (!desbloqueado ? " bloqueado" : "");

        div.innerHTML = `
            <div class="quiz-topo">
                <h3>Quiz ${numero}</h3>
                <div class="quiz-stars">${estrelas}</div>
            </div>

            <p>
                ${
                    quiz.concluido
                    ? "Você já completou este quiz! 🎉"
                    : "5 perguntas para aprender brincando."
                }
            </p>

            <button
                ${!desbloqueado ? "disabled" : ""}
                onclick="prepararQuiz(${numero})">

                ${
                    !desbloqueado
                    ? "🔒 Bloqueado"
                    : quiz.concluido
                    ? "🔄 Jogar novamente"
                    : "▶️ Jogar"
                }

            </button>
        `;

        container.appendChild(div);
    });

    atualizarAreaProva();
}

function atualizarAbas(){

    const meio =
        nivelMedioDesbloqueado();

    const dificil =
        nivelDificilDesbloqueado();

    document.getElementById(
        "tabMedio"
    ).textContent =
        meio ? "🟡 Médio" : "🟡 Médio 🔒";

    document.getElementById(
        "tabDificil"
    ).textContent =
        dificil ? "🔴 Difícil" : "🔴 Difícil 🔒";
}

function atualizarAreaProva(){

    const area =
        document.getElementById("areaProva");

    if(!area) return;

    area.innerHTML = "";

    const dados =
        jogador.progresso[materiaAtual];

    if(
        nivelAtual === "facil" &&
        dados.facil.every(q => q.concluido) &&
        !dados.provaFacil
    ){

        area.innerHTML = `
            <div class="recompensa">
                <h3>🎓 Prova do Fácil</h3>
                <p>
                    Você terminou os 10 quizzes!
                    Agora faça a prova para liberar o Médio.
                </p>

                <button
                    class="btn principal"
                    onclick="abrirProva('facil')">
                    📝 Fazer prova
                </button>
            </div>
        `;
    }

    if(
        nivelAtual === "medio" &&
        dados.medio.every(q => q.concluido) &&
        !dados.provaMedio
    ){

        area.innerHTML = `
            <div class="recompensa">
                <h3>🎓 Prova do Médio</h3>
                <p>
                    Você terminou os 10 quizzes!
                    Agora faça a prova para liberar o Difícil.
                </p>

                <button
                    class="btn principal"
                    onclick="abrirProva('medio')">
                    📝 Fazer prova
                </button>
            </div>
        `;
    }
}

function prepararQuiz(numero){

    const lista =
        jogador.progresso[materiaAtual][nivelAtual];

    if(
        numero > 1 &&
        !lista[numero - 2].concluido
    ){

        mostrarMensagem(
            "Complete o quiz anterior primeiro! 🔒"
        );

        return;
    }

    quizAtual = numero;

    document.getElementById(
        "configTitulo"
    ).textContent =
        `Quiz ${numero} — ${NIVEIS[nivelAtual]}`;

    document.getElementById(
        "configDescricao"
    ).textContent =
        `${MATERIAS[materiaAtual].nome}: prepare-se para 5 perguntas!`;

    mostrarTela("telaConfiguracao");
}


/* =========================================================
   PERGUNTAS
========================================================= */

function gerarPergunta(){

    let a,b,resultado,texto,emoji;

    if(nivelAtual === "facil"){

        a = numeroAleatorio(1,20);
        b = numeroAleatorio(1,20);

    }else if(nivelAtual === "medio"){

        a = numeroAleatorio(10,60);
        b = numeroAleatorio(2,30);

    }else{

        a = numeroAleatorio(20,150);
        b = numeroAleatorio(5,80);
    }

    let operacao = materiaAtual;

    switch(materiaAtual){

        case "adicao":

            resultado = a + b;
            texto = `${a} + ${b} = ?`;
            emoji = "➕";

            break;

        case "subtracao":

            if(b > a){
                [a,b] = [b,a];
            }

            resultado = a - b;
            texto = `${a} − ${b} = ?`;
            emoji = "➖";

            break;

        case "multiplicacao":

            if(nivelAtual === "facil"){

                a = numeroAleatorio(1,10);
                b = numeroAleatorio(1,10);

            }else if(nivelAtual === "medio"){

                a = numeroAleatorio(2,15);
                b = numeroAleatorio(2,12);

            }else{

                a = numeroAleatorio(5,25);
                b = numeroAleatorio(5,20);
            }

            resultado = a * b;
            texto = `${a} × ${b} = ?`;
            emoji = "✖️";

            break;

        case "divisao":

            if(nivelAtual === "facil"){

                b = numeroAleatorio(1,10);
                resultado = numeroAleatorio(1,10);

            }else if(nivelAtual === "medio"){

                b = numeroAleatorio(2,12);
                resultado = numeroAleatorio(2,15);

            }else{

                b = numeroAleatorio(3,20);
                resultado = numeroAleatorio(3,20);
            }

            a = b * resultado;

            texto = `${a} ÷ ${b} = ?`;
            emoji = "➗";

            break;
    }

    return {
        a,
        b,
        resultado,
        texto,
        emoji,
        operacao
    };
}

function gerarAlternativas(resposta){

    const conjunto =
        new Set([resposta]);

    while(conjunto.size < 4){

        const variacao =
            numeroAleatorio(
                Math.max(0,resposta - 12),
                resposta + 12
            );

        if(variacao !== resposta){
            conjunto.add(variacao);
        }
    }

    return [...conjunto]
        .sort(() => Math.random() - .5);
}


/* =========================================================
   INICIAR QUIZ
========================================================= */

function iniciarQuiz(){

    clearInterval(intervaloTempo);

    perguntas = [];

    for(let i=0;i<5;i++){
        perguntas.push(
            gerarPergunta()
        );
    }

    perguntaAtual = 0;
    acertos = 0;
    vidas = 3;
    combo = 0;
    melhorComboRodada = 0;

    quizEmAndamento = true;
    respostaSendoMostrada = false;

    mostrarTela("telaPergunta");

    mostrarPergunta();
}

function mostrarPergunta(){

    if(!quizEmAndamento) return;

    if(perguntaAtual >= 5){

        finalizarQuiz();

        return;
    }

    respostaSendoMostrada = false;

    const pergunta =
        perguntas[perguntaAtual];

    document.getElementById(
        "numeroPergunta"
    ).textContent =
        perguntaAtual + 1;

    document.getElementById(
        "vidas"
    ).textContent =
        vidas;

    document.getElementById(
        "combo"
    ).textContent =
        combo;

    document.getElementById(
        "emojiPergunta"
    ).textContent =
        pergunta.emoji;

    document.getElementById(
        "textoPergunta"
    ).textContent =
        pergunta.texto;

    document.getElementById(
        "barraPergunta"
    ).style.width =
        `${(perguntaAtual / 5) * 100}%`;

    const alternativas =
        gerarAlternativas(
            pergunta.resultado
        );

    const container =
        document.getElementById(
            "alternativas"
        );

    container.innerHTML = "";

    alternativas.forEach(valor => {

        const botao =
            document.createElement("button");

        botao.className =
            "alternativa";

        botao.textContent =
            valor;

        botao.onclick = () =>
            responder(valor,botao);

        container.appendChild(botao);
    });

    iniciarTimer();
}


/* =========================================================
   TIMER
========================================================= */

function iniciarTimer(){

    clearInterval(intervaloTempo);

    tempo = 20;

    document.getElementById(
        "tempo"
    ).textContent =
        tempo;

    intervaloTempo =
        setInterval(() => {

            if(respostaSendoMostrada) return;

            tempo--;

            document.getElementById(
                "tempo"
            ).textContent =
                tempo;

            if(tempo <= 0){

                clearInterval(intervaloTempo);

                responder(
                    null,
                    null,
                    true
                );
            }

        },1000);
}


/* =========================================================
   EXPLICAÇÃO PASSO A PASSO
========================================================= */

function criarEstiloExplicacao(){

    if(document.getElementById(
        "estiloExplicacaoQuiz"
    )) return;

    const style =
        document.createElement("style");

    style.id =
        "estiloExplicacaoQuiz";

    style.textContent = `

        #explicacaoQuiz{
            position:fixed;
            inset:0;
            z-index:9999;
            background:rgba(20,30,70,.75);
            display:flex;
            align-items:center;
            justify-content:center;
            padding:18px;
        }

        .caixa-explicacao{
            width:min(520px,100%);
            max-height:90vh;
            overflow-y:auto;
            background:white;
            border-radius:25px;
            padding:25px;
            text-align:center;
            box-shadow:0 15px 50px rgba(0,0,0,.3);
            animation:aparecerExplicacao .25s ease;
        }

        .caixa-explicacao .emoji-explicacao{
            font-size:55px;
            margin-bottom:8px;
        }

        .caixa-explicacao h2{
            margin:5px 0 15px;
            font-size:25px;
        }

        .conta-grande{
            background:#f1f5ff;
            border-radius:18px;
            padding:15px;
            margin:15px 0;
            font-size:25px;
            font-weight:bold;
        }

        .passo-explicacao{
            text-align:left;
            background:#fff8dc;
            border-radius:14px;
            padding:12px;
            margin:8px 0;
            line-height:1.5;
        }

        .resposta-errada{
            background:#ffe8e8;
            border-radius:14px;
            padding:12px;
            margin:12px 0;
        }

        .resposta-certa{
            background:#e7ffe9;
            border-radius:14px;
            padding:12px;
            margin:12px 0;
        }

        .btn-continuar-explicacao{
            width:100%;
            border:0;
            border-radius:15px;
            padding:15px;
            margin-top:15px;
            font-size:18px;
            font-weight:bold;
            cursor:pointer;
            background:#4f7cff;
            color:white;
        }

        @keyframes aparecerExplicacao{
            from{
                transform:scale(.8);
                opacity:0;
            }
            to{
                transform:scale(1);
                opacity:1;
            }
        }
    `;

    document.head.appendChild(style);
}

function gerarExplicacao(
    pergunta,
    respostaUsuario,
    acertou,
    tempoEsgotado
){

    const a = pergunta.a;
    const b = pergunta.b;
    const resultado = pergunta.resultado;

    let passos = "";

    if(pergunta.operacao === "adicao"){

        passos = `
            <div class="passo-explicacao">
                👉 Começamos com <strong>${a}</strong>.
            </div>

            <div class="passo-explicacao">
                👉 Vamos adicionar <strong>${b}</strong>.
            </div>

            <div class="passo-explicacao">
                👉 Então fazemos:
                <strong>${a} + ${b} = ${resultado}</strong>
            </div>

            <div class="passo-explicacao">
                🧠 Isso significa juntar ${a} com mais ${b}.
            </div>
        `;

    }else if(pergunta.operacao === "subtracao"){

        passos = `
            <div class="passo-explicacao">
                👉 Começamos com <strong>${a}</strong>.
            </div>

            <div class="passo-explicacao">
                👉 Precisamos tirar <strong>${b}</strong>.
            </div>

            <div class="passo-explicacao">
                👉 Fazemos:
                <strong>${a} − ${b} = ${resultado}</strong>
            </div>

            <div class="passo-explicacao">
                🧠 Depois de tirar ${b} de ${a},
                sobram <strong>${resultado}</strong>.
            </div>
        `;

    }else if(pergunta.operacao === "multiplicacao"){

        let repeticao = "";

        if(b <= 10){

            repeticao =
                Array(b)
                .fill(a)
                .join(" + ");

            repeticao +=
                ` = ${resultado}`;
        }

        passos = `
            <div class="passo-explicacao">
                👉 Multiplicar é somar o mesmo número
                várias vezes.
            </div>

            <div class="passo-explicacao">
                👉 Temos <strong>${b}</strong> grupos de
                <strong>${a}</strong>.
            </div>

            ${
                repeticao
                ? `
                <div class="passo-explicacao">
                    🧮 ${repeticao}
                </div>
                `
                : ""
            }

            <div class="passo-explicacao">
                👉 Portanto:
                <strong>${a} × ${b} = ${resultado}</strong>
            </div>
        `;

    }else if(pergunta.operacao === "divisao"){

        passos = `
            <div class="passo-explicacao">
                👉 Dividir significa repartir
                em partes iguais.
            </div>

            <div class="passo-explicacao">
                👉 Temos <strong>${a}</strong>
                para dividir em <strong>${b}</strong> partes.
            </div>

            <div class="passo-explicacao">
                👉 Fazemos:
                <strong>${a} ÷ ${b} = ${resultado}</strong>
            </div>

            <div class="passo-explicacao">
                🧠 Podemos conferir:
                <strong>${resultado} × ${b} = ${a}</strong>
            </div>
        `;
    }

    const titulo =
        acertou
        ? "🎉 Muito bem!"
        : "💡 Vamos aprender!";

    const subtitulo =
        acertou
        ? "Você acertou! Veja por que a resposta está certa:"
        : tempoEsgotado
        ? "⏰ O tempo acabou, mas vamos aprender:"
        : "Não tem problema! Vamos descobrir juntos:";

    let respostas = "";

    if(!acertou){

        respostas = `
            ${
                tempoEsgotado
                ? `
                <div class="resposta-errada">
                    ⏰ Você não respondeu a tempo.
                </div>
                `
                : `
                <div class="resposta-errada">
                    ❌ Você respondeu:
                    <strong>${respostaUsuario}</strong>
                </div>
                `
            }

            <div class="resposta-certa">
                ✅ A resposta correta é:
                <strong>${resultado}</strong>
            </div>
        `;
    }

    return `
        <div class="emoji-explicacao">
            ${acertou ? "🎉" : "🧠"}
        </div>

        <h2>${titulo}</h2>

        <p>${subtitulo}</p>

        <div class="conta-grande">
            ${pergunta.texto.replace("?",resultado)}
        </div>

        ${respostas}

        ${passos}

        <button
            class="btn-continuar-explicacao"
            onclick="continuarDepoisDaExplicacao()">
            ${
                perguntaAtual >= 4
                    ? "🏁 Ver resultado"
                    : "👉 Continuar"
            }
        </button>
    `;
}

function mostrarExplicacao(
    pergunta,
    respostaUsuario,
    acertou,
    tempoEsgotado
){

    criarEstiloExplicacao();

    const antiga =
        document.getElementById(
            "explicacaoQuiz"
        );

    if(antiga){
        antiga.remove();
    }

    const div =
        document.createElement("div");

    div.id =
        "explicacaoQuiz";

    div.innerHTML =
        `<div class="caixa-explicacao">
            ${gerarExplicacao(
                pergunta,
                respostaUsuario,
                acertou,
                tempoEsgotado
            )}
        </div>`;

    document.body.appendChild(div);
}

function continuarDepoisDaExplicacao(){

    const tela =
        document.getElementById(
            "explicacaoQuiz"
        );

    if(tela){
        tela.remove();
    }

    respostaSendoMostrada = false;

    if(vidas <= 0){

        finalizarQuiz();

        return;
    }

    perguntaAtual++;

    mostrarPergunta();
}


/* =========================================================
   RESPONDER
========================================================= */

function responder(
    valor,
    botao,
    tempoEsgotado=false
){

    if(
        !quizEmAndamento ||
        respostaSendoMostrada
    ){
        return;
    }

    respostaSendoMostrada = true;

    clearInterval(intervaloTempo);

    const pergunta =
        perguntas[perguntaAtual];

    const correta =
        valor === pergunta.resultado;

    document.querySelectorAll(
        ".alternativa"
    ).forEach(b =>
        b.disabled = true
    );

    if(correta){

        acertos++;

        combo++;

        if(combo > melhorComboRodada){
            melhorComboRodada = combo;
        }

        if(combo > jogador.melhorCombo){
            jogador.melhorCombo = combo;
        }

        if(botao){
            botao.classList.add("certa");
        }

        tocarSom("certo");

        if(combo >= 3){

            mostrarMensagem(
                `🔥 Combo ${combo}!`
            );

            tocarSom("combo");
        }

    }else{

        vidas--;

        combo = 0;

        if(botao){
            botao.classList.add("errada");
        }

        tocarSom("errado");

        document.getElementById(
            "vidas"
        ).textContent = vidas;

        if(tempoEsgotado){

            mostrarMensagem(
                "⏰ O tempo acabou!"
            );

        }else{

            mostrarMensagem(
                "💡 Vamos descobrir juntos!"
            );
        }
    }

    document.getElementById(
        "combo"
    ).textContent = combo;

    mostrarExplicacao(
        pergunta,
        valor,
        correta,
        tempoEsgotado
    );
}


/* =========================================================
   FINALIZAR QUIZ
========================================================= */

function finalizarQuiz(){

    clearInterval(intervaloTempo);

    const explicacao =
        document.getElementById(
            "explicacaoQuiz"
        );

    if(explicacao){
        explicacao.remove();
    }

    quizEmAndamento = false;
    respostaSendoMostrada = false;

    const estrelas =
        calcularEstrelas(acertos);

    const xp =
        calcularXP(acertos);

    const moedas =
        calcularMoedas(acertos);

    const dados =
        jogador.progresso[materiaAtual][nivelAtual];

    const existente =
        dados[quizAtual - 1];

    const eraConcluido =
        existente.concluido;

    const estrelasAntigas =
        existente.estrelas || 0;

    existente.concluido = true;

    if(estrelas > estrelasAntigas){

        const diferenca =
            estrelas - estrelasAntigas;

        existente.estrelas = estrelas;

        jogador.estrelas +=
            diferenca;
    }

    if(!eraConcluido){
        jogador.quizzesConcluidos++;
    }

    jogador.totalAcertos +=
        acertos;

    jogador.moedas +=
        moedas;

    ganharXP(xp);

    verificarConquistas();
    atualizarMissoes();
    atualizarDesafios();

    salvar();

    document.getElementById(
        "resultadoAcertos"
    ).textContent =
        acertos;

    document.getElementById(
        "resultadoEstrelas"
    ).textContent =
        estrelas > 0
            ? "⭐".repeat(estrelas)
            : "0";

    document.getElementById(
        "resultadoMoedas"
    ).textContent =
        moedas;

    document.getElementById(
        "resultadoXP"
    ).textContent =
        xp;

    if(acertos === 5){

        document.getElementById(
            "resultadoEmoji"
        ).textContent = "🏆";

        document.getElementById(
            "resultadoTitulo"
        ).textContent =
            "PERFEITO! 🎉";

        soltarConfetes();

        tocarSom("vitoria");
        tocarSom("estrelas");

    }else if(acertos >= 3){

        document.getElementById(
            "resultadoEmoji"
        ).textContent = "😄";

        document.getElementById(
            "resultadoTitulo"
        ).textContent =
            "Muito bem!";

    }else{

        document.getElementById(
            "resultadoEmoji"
        ).textContent = "💪";

        document.getElementById(
            "resultadoTitulo"
        ).textContent =
            "Continue tentando!";
    }

    mostrarTela("telaResultado");
}

function calcularEstrelas(acertos){

    if(acertos === 5) return 3;
    if(acertos >= 3) return 2;
    if(acertos >= 1) return 1;

    return 0;
}

function calcularXP(acertos){

    const base = {
        facil:10,
        medio:20,
        dificil:30
    };

    return base[nivelAtual] +
        acertos * 5;
}

function calcularMoedas(acertos){

    return acertos * 2;
}


/* =========================================================
   XP / NÍVEL
========================================================= */

function ganharXP(valor){

    jogador.xp += valor;

    let subiu = false;

    while(
        jogador.xp >=
        jogador.nivel * 100
    ){

        jogador.xp -=
            jogador.nivel * 100;

        jogador.nivel++;

        jogador.evolucao++;

        subiu = true;
    }

    if(subiu){

        mostrarMensagem(
            `🎉 Você chegou ao nível ${jogador.nivel}!`
        );

        soltarConfetes();

        tocarSom("nivel");
    }
}


/* =========================================================
   VOLTAR DA TELA DE RESULTADO
========================================================= */

function voltarListaQuizzes(){

    atualizarQuizzes();

    mostrarTela("telaQuizzes");
}


/* =========================================================
   PROVAS
========================================================= */

function abrirProva(nivel){

    provaAtual = nivel;

    respostasProva =
        Array(10).fill(null);

    document.getElementById(
        "tituloProva"
    ).textContent =
        `📝 Prova do ${NIVEIS[nivel]}`;

    document.getElementById(
        "btnFinalizarProva"
    ).style.display = "none";

    gerarProva();

    mostrarTela("telaProva");
}

function gerarProva(){

    const container =
        document.getElementById(
            "provaPergunta"
        );

    container.innerHTML = "";

    for(let i=0;i<10;i++){

        const pergunta =
            gerarPergunta();

        const div =
            document.createElement("div");

        div.className =
            "prova-item";

        div.innerHTML = `
            <h3>
                ${i+1}. ${pergunta.emoji}
                ${pergunta.texto}
            </h3>

            <div
                class="prova-opcoes"
                id="provaOpcoes${i}">
            </div>
        `;

        container.appendChild(div);

        const opcoes =
            gerarAlternativas(
                pergunta.resultado
            );

        opcoes.forEach(valor => {

            const botao =
                document.createElement("button");

            botao.textContent =
                valor;

            botao.onclick = () => {

                respostasProva[i] = {
                    resposta:valor,
                    correta:pergunta.resultado
                };

                document.querySelectorAll(
                    `#provaOpcoes${i} button`
                ).forEach(b =>
                    b.classList.remove(
                        "selecionado"
                    )
                );

                botao.classList.add(
                    "selecionado"
                );

                atualizarBotaoProva();

                tocarSom("clique");
            };

            document.getElementById(
                `provaOpcoes${i}`
            ).appendChild(botao);
        });
    }
}

function atualizarBotaoProva(){

    const completas =
        respostasProva.filter(Boolean)
        .length;

    document.getElementById(
        "btnFinalizarProva"
    ).style.display =
        completas === 10
            ? "block"
            : "none";
}

function finalizarProva(){

    if(respostasProva.some(r => !r)){
        return;
    }

    let nota = 0;

    respostasProva.forEach(r => {

        if(r.resposta === r.correta){
            nota++;
        }
    });

    const dados =
        jogador.progresso[materiaAtual];

    if(provaAtual === "facil"){

        if(nota >= 8){

            dados.provaFacil = true;

            jogador.moedas += 20;

            ganharXP(50);

            mostrarResultadoProva(
                nota,
                true,
                "🎉 Parabéns! O nível Médio foi desbloqueado!"
            );

        }else{

            mostrarResultadoProva(
                nota,
                false,
                "💪 Você precisa de 8 acertos. Tente novamente!"
            );
        }

    }else{

        if(nota >= 8){

            dados.provaMedio = true;

            jogador.moedas += 30;

            ganharXP(70);

            mostrarResultadoProva(
                nota,
                true,
                "🎉 Parabéns! O nível Difícil foi desbloqueado!"
            );

        }else{

            mostrarResultadoProva(
                nota,
                false,
                "💪 Você precisa de 8 acertos. Tente novamente!"
            );
        }
    }

    verificarConquistas();

    salvar();
}

function mostrarResultadoProva(
    nota,
    passou,
    mensagem
){

    document.getElementById(
        "notaProva"
    ).textContent =
        nota;

    document.getElementById(
        "mensagemProva"
    ).textContent =
        mensagem;

    if(passou){

        document.getElementById(
            "emojiResultadoProva"
        ).textContent =
            "🏆";

        document.getElementById(
            "tituloResultadoProva"
        ).textContent =
            "Aprovado! 🎉";

        soltarConfetes();

        tocarSom("provaPassou");

    }else{

        document.getElementById(
            "emojiResultadoProva"
        ).textContent =
            "💪";

        document.getElementById(
            "tituloResultadoProva"
        ).textContent =
            "Quase lá!";

        tocarSom("provaFalhou");
    }

    mostrarTela(
        "telaResultadoProva"
    );
}


/* =========================================================
   CONQUISTAS
========================================================= */

const CONQUISTAS = [

["primeiro","🌟","Primeiro passo","Complete seu primeiro quiz."],
["quiz5","📚","Começando bem","Complete 5 quizzes."],
["quiz10","🎓","Estudante","Complete 10 quizzes."],
["quiz20","🏅","Matemático","Complete 20 quizzes."],
["quiz30","🏆","Grande estudante","Complete 30 quizzes."],
["quiz40","⭐","Mestre","Complete 40 quizzes."],
["quiz50","👑","Lenda","Complete 50 quizzes."],

["acertos10","🎯","Boa mira","Tenha 10 acertos."],
["acertos25","🎯","Precisão","Tenha 25 acertos."],
["acertos50","🎯","Craque","Tenha 50 acertos."],
["acertos100","💯","Centena","Tenha 100 acertos."],

["combo3","🔥","Combo inicial","Faça combo 3."],
["combo5","🔥","Combo forte","Faça combo 5."],
["combo10","🔥","Combo incrível","Faça combo 10."],

["estrelas10","⭐","Colecionador","Ganhe 10 estrelas."],
["estrelas25","🌟","Estrela brilhante","Ganhe 25 estrelas."],
["estrelas50","💫","Super estrela","Ganhe 50 estrelas."],

["nivel2","⬆️","Subindo","Chegue ao nível 2."],
["nivel5","🚀","Evoluindo","Chegue ao nível 5."],
["nivel10","👑","Grande mestre","Chegue ao nível 10."],

["adicao","➕","Especialista em adição","Complete todos os quizzes de Adição."],
["subtracao","➖","Especialista em subtração","Complete todos os quizzes de Subtração."],
["multiplicacao","✖️","Especialista em multiplicação","Complete todos os quizzes de Multiplicação."],
["divisao","➗","Especialista em divisão","Complete todos os quizzes de Divisão."],

["prova1","📝","Primeira prova","Passe em uma prova."],
["prova2","🎓","Duas provas","Passe em duas provas."],
["prova3","🏅","Três provas","Passe em três provas."],
["prova4","🏆","Mestre das provas","Passe em quatro provas."],

["facil","🟢","Fácil completo","Complete o nível Fácil de uma matéria."],
["medio","🟡","Médio completo","Complete o nível Médio de uma matéria."],
["dificil","🔴","Difícil completo","Complete o nível Difícil de uma matéria."],

["perfeito","💯","Perfeito","Faça 5/5 em um quiz."],
["perfeitos3","💯","Três perfeitos","Faça 3 quizzes com 5/5."],

["moedas50","🪙","Primeiras moedas","Ganhe 50 moedas."],
["moedas100","💰","Cofrinho","Ganhe 100 moedas."],
["moedas250","💎","Tesouro","Ganhe 250 moedas."],

["xp100","✨","Experiência","Ganhe 100 XP."],
["xp500","🌟","Muito conhecimento","Ganhe 500 XP."],
["xp1000","🚀","Super conhecimento","Ganhe 1000 XP."],

["jogar3","🎮","Brincando e aprendendo","Jogue 3 quizzes."],
["jogar7","🎮","Sempre estudando","Jogue 7 quizzes."],
["jogar15","🎮","Apaixonado por matemática","Jogue 15 quizzes."],

["todasFacil","🟢","Fácil dominado","Complete o Fácil em todas as matérias."],
["todasMedio","🟡","Médio dominado","Complete o Médio em todas as matérias."],
["todasDificil","🔴","Difícil dominado","Complete o Difícil em todas as matérias."],

["provas2","📖","Aluno dedicado","Passe em 2 provas."],
["provas4","🎓","Aluno exemplar","Passe em todas as provas."],

["evolucao1","🧙","Primeira evolução","Evolua seu personagem."],
["evolucao3","🧙‍♂️","Personagem forte","Evolua 3 vezes."],

["desafio","🌟","Desafiador","Complete um desafio."],
["missao","🎯","Missão cumprida","Complete uma missão."]
];


/* =========================================================
   VERIFICAR CONQUISTAS
========================================================= */

function verificarConquistas(){

    const desbloqueadas =
        jogador.conquistas;

    const testes =
        Object.values(
            jogador.progresso
        );

    const provas =
        testes.filter(p => p.provaFacil).length +
        testes.filter(p => p.provaMedio).length;

    const quizzesPerfeitos =
        contarQuizzesPerfeitos();

    const condicoes = {

        primeiro:jogador.quizzesConcluidos >= 1,
        quiz5:jogador.quizzesConcluidos >= 5,
        quiz10:jogador.quizzesConcluidos >= 10,
        quiz20:jogador.quizzesConcluidos >= 20,
        quiz30:jogador.quizzesConcluidos >= 30,
        quiz40:jogador.quizzesConcluidos >= 40,
        quiz50:jogador.quizzesConcluidos >= 50,

        acertos10:jogador.totalAcertos >= 10,
        acertos25:jogador.totalAcertos >= 25,
        acertos50:jogador.totalAcertos >= 50,
        acertos100:jogador.totalAcertos >= 100,

        combo3:jogador.melhorCombo >= 3,
        combo5:jogador.melhorCombo >= 5,
        combo10:jogador.melhorCombo >= 10,

        estrelas10:jogador.estrelas >= 10,
        estrelas25:jogador.estrelas >= 25,
        estrelas50:jogador.estrelas >= 50,

        nivel2:jogador.nivel >= 2,
        nivel5:jogador.nivel >= 5,
        nivel10:jogador.nivel >= 10,

        adicao:todosQuizzes("adicao"),
        subtracao:todosQuizzes("subtracao"),
        multiplicacao:todosQuizzes("multiplicacao"),
        divisao:todosQuizzes("divisao"),

        prova1:provas >= 1,
        prova2:provas >= 2,
        prova3:provas >= 3,
        prova4:provas >= 4,

        facil:Object.keys(MATERIAS)
            .some(m => nivelCompleto(m,"facil")),

        medio:Object.keys(MATERIAS)
            .some(m => nivelCompleto(m,"medio")),

        dificil:Object.keys(MATERIAS)
            .some(m => nivelCompleto(m,"dificil")),

        perfeito:quizzesPerfeitos >= 1,
        perfeitos3:quizzesPerfeitos >= 3,

        moedas50:jogador.moedas >= 50,
        moedas100:jogador.moedas >= 100,
        moedas250:jogador.moedas >= 250,

        xp100:
            jogador.xp >= 100 ||
            jogador.nivel >= 2,

        xp500:jogador.nivel >= 5,
        xp1000:jogador.nivel >= 10,

        jogar3:jogador.quizzesConcluidos >= 3,
        jogar7:jogador.quizzesConcluidos >= 7,
        jogar15:jogador.quizzesConcluidos >= 15,

        todasFacil:Object.keys(MATERIAS)
            .every(m => nivelCompleto(m,"facil")),

        todasMedio:Object.keys(MATERIAS)
            .every(m => nivelCompleto(m,"medio")),

        todasDificil:Object.keys(MATERIAS)
            .every(m => nivelCompleto(m,"dificil")),

        provas2:provas >= 2,
        provas4:provas >= 4,

        evolucao1:jogador.evolucao >= 1,
        evolucao3:jogador.evolucao >= 3,

        desafio:jogador.desafios.some(
            d => d.concluido
        ),

        missao:jogador.missoes.some(
            m => m.concluida
        )
    };

    CONQUISTAS.forEach(c => {

        const id = c[0];

        if(
            condicoes[id] &&
            !desbloqueadas.includes(id)
        ){

            desbloqueadas.push(id);

            mostrarMensagem(
                `🏆 Conquista: ${c[2]}!`
            );

            tocarSom("vitoria");
        }
    });

    salvarSemAtualizar();
}

function todosQuizzes(materia){

    return Object.values(
        jogador.progresso[materia]
    )
    .filter(Array.isArray)
    .every(lista =>
        lista.every(q => q.concluido)
    );
}

function nivelCompleto(materia,nivel){

    return jogador.progresso[materia][nivel]
        .every(q => q.concluido);
}

function contarQuizzesPerfeitos(){

    let total = 0;

    Object.keys(MATERIAS)
        .forEach(materia => {

        ["facil","medio","dificil"]
        .forEach(nivel => {

            jogador.progresso[materia][nivel]
                .forEach(q => {

                    if(q.estrelas === 3){
                        total++;
                    }
                });
        });
    });

    return total;
}

function atualizarConquistas(){

    const lista =
        document.getElementById(
            "listaConquistas"
        );

    if(!lista) return;

    const quantidade =
        jogador.conquistas.length;

    document.getElementById(
        "contadorConquistas"
    ).textContent =
        quantidade;

    document.getElementById(
        "barraConquistas"
    ).style.width =
        `${quantidade / 50 * 100}%`;

    lista.innerHTML = "";

    CONQUISTAS.forEach(c => {

        const desbloqueada =
            jogador.conquistas.includes(c[0]);

        const div =
            document.createElement("div");

        div.className =
            "conquista" +
            (desbloqueada
                ? ""
                : " bloqueada");

        div.innerHTML = `
            <div class="icone">
                ${desbloqueada ? c[1] : "🔒"}
            </div>

            <div>
                <strong>${c[2]}</strong>
                <p>${c[3]}</p>
            </div>
        `;

        lista.appendChild(div);
    });
}


/* =========================================================
   MISSÕES
========================================================= */

function criarMissoesSeNecessario(){

    if(jogador.missoes.length > 0) return;

    jogador.missoes = [

        {
            id:"m1",
            texto:"Complete 2 quizzes.",
            alvo:2,
            atual:0,
            concluida:false,
            premio:"🪙 10 moedas"
        },

        {
            id:"m2",
            texto:"Tenha 10 acertos.",
            alvo:10,
            atual:0,
            concluida:false,
            premio:"⭐ 3 estrelas"
        },

        {
            id:"m3",
            texto:"Faça um combo de 3.",
            alvo:3,
            atual:0,
            concluida:false,
            premio:"✨ 30 XP"
        }
    ];
}

function atualizarMissoes(){

    criarMissoesSeNecessario();

    jogador.missoes.forEach(m => {

        if(m.id === "m1"){
            m.atual =
                Math.min(
                    jogador.quizzesConcluidos,
                    m.alvo
                );
        }

        if(m.id === "m2"){
            m.atual =
                Math.min(
                    jogador.totalAcertos,
                    m.alvo
                );
        }

        if(m.id === "m3"){
            m.atual =
                Math.min(
                    jogador.melhorCombo,
                    m.alvo
                );
        }

        if(
            m.atual >= m.alvo &&
            !m.concluida
        ){

            m.concluida = true;

            if(m.id === "m1"){
                jogador.moedas += 10;
            }

            if(m.id === "m2"){
                jogador.estrelas += 3;
            }

            if(m.id === "m3"){
                jogador.xp += 30;
            }

            mostrarMensagem(
                "🎯 Missão concluída!"
            );

            tocarSom("missao");
        }
    });

    salvarSemAtualizar();
}

function atualizarMissoesTela(){

    const lista =
        document.getElementById(
            "listaMissoes"
        );

    if(!lista) return;

    lista.innerHTML = "";

    jogador.missoes.forEach(m => {

        const div =
            document.createElement("div");

        div.className = "missao";

        div.innerHTML = `
            <h3>
                ${m.concluida ? "✅" : "🎯"}
                ${m.texto}
            </h3>

            <p>
                Progresso:
                ${m.atual}/${m.alvo}
            </p>

            <p class="premio">
                ${m.premio}
            </p>
        `;

        lista.appendChild(div);
    });
}


/* =========================================================
   DESAFIOS
========================================================= */

function criarDesafiosSeNecessario(){

    if(jogador.desafios.length > 0) return;

    jogador.desafios = [

        {
            id:"d1",
            titulo:"🌟 Desafio das estrelas",
            texto:"Ganhe 10 estrelas.",
            alvo:10,
            atual:0,
            concluido:false,
            premio:"🪙 20 moedas"
        },

        {
            id:"d2",
            titulo:"🔥 Desafio do combo",
            texto:"Faça combo 5.",
            alvo:5,
            atual:0,
            concluido:false,
            premio:"✨ 50 XP"
        }
    ];
}

function atualizarDesafios(){

    criarDesafiosSeNecessario();

    jogador.desafios.forEach(d => {

        if(d.id === "d1"){
            d.atual =
                Math.min(
                    jogador.estrelas,
                    d.alvo
                );
        }

        if(d.id === "d2"){
            d.atual =
                Math.min(
                    jogador.melhorCombo,
                    d.alvo
                );
        }

        if(
            d.atual >= d.alvo &&
            !d.concluido
        ){

            d.concluido = true;

            if(d.id === "d1"){
                jogador.moedas += 20;
            }

            if(d.id === "d2"){
                ganharXP(50);
            }

            mostrarMensagem(
                "🌟 Desafio concluído!"
            );

            tocarSom("missao");
        }
    });

    salvarSemAtualizar();
}

function atualizarDesafiosTela(){

    const lista =
        document.getElementById(
            "listaDesafios"
        );

    if(!lista) return;

    lista.innerHTML = "";

    jogador.desafios.forEach(d => {

        const div =
            document.createElement("div");

        div.className = "desafio";

        div.innerHTML = `
            <h3>
                ${d.concluido ? "✅" : "🌟"}
                ${d.titulo}
            </h3>

            <p>${d.texto}</p>

            <p>
                Progresso:
                ${d.atual}/${d.alvo}
            </p>

            <p class="premio">
                ${d.premio}
            </p>
        `;

        lista.appendChild(div);
    });
}


/* =========================================================
   EVOLUÇÃO
========================================================= */

const EVOLUCOES = [

    ["🧑‍🎓","Pequeno Aprendiz",0],
    ["🧒","Aprendiz Curioso",1],
    ["🧙","Mago da Matemática",3],
    ["🧙‍♂️","Grande Mago",5],
    ["👑","Mestre da Matemática",10]
];

function atualizarEvolucao(){

    const indice =
        Math.min(
            jogador.evolucao,
            EVOLUCOES.length - 1
        );

    const atual =
        EVOLUCOES[indice];

    document.getElementById(
        "evolucaoAvatar"
    ).textContent =
        jogador.foto
            ? "📷"
            : atual[0];

    document.getElementById(
        "evolucaoTitulo"
    ).textContent =
        atual[1];

    document.getElementById(
        "evolucaoNivel"
    ).textContent =
        jogador.nivel;

    const necessario =
        jogador.nivel * 100;

    const percentual =
        Math.min(
            jogador.xp / necessario * 100,
            100
        );

    document.getElementById(
        "barraXP"
    ).style.width =
        percentual + "%";

    document.getElementById(
        "textoXP"
    ).textContent =
        `${jogador.xp}/${necessario} XP`;

    const lista =
        document.getElementById(
            "listaEvolucoes"
        );

    if(!lista) return;

    lista.innerHTML = "";

    EVOLUCOES.forEach(e => {

        const desbloqueado =
            jogador.evolucao >= e[2];

        const div =
            document.createElement("div");

        div.className =
            "evolucao-item" +
            (desbloqueado
                ? " desbloqueado"
                : "");

        div.innerHTML = `
            <strong>
                ${desbloqueado ? e[0] : "🔒"}
                ${e[1]}
            </strong>

            <p>
                ${
                    desbloqueado
                    ? "Desbloqueado! 🎉"
                    : `Evolução ${e[2]}`
                }
            </p>
        `;

        lista.appendChild(div);
    });
}


/* =========================================================
   RECOMPENSAS
========================================================= */

function atualizarRecompensas(){

    const lista =
        document.getElementById(
            "listaRecompensas"
        );

    if(!lista) return;

    const recompensas = [

        ["⭐ 5 estrelas","Pequena recompensa"],
        ["⭐ 15 estrelas","Boa evolução"],
        ["⭐ 30 estrelas","Grande estudante"],
        ["🏆 10 conquistas","Mestre das conquistas"],
        ["🎓 4 provas","Mestre das provas"]
    ];

    lista.innerHTML = "";

    recompensas.forEach(r => {

        const div =
            document.createElement("div");

        div.className =
            "recompensa";

        div.innerHTML = `
            <strong>${r[0]}</strong>
            <p>${r[1]}</p>
        `;

        lista.appendChild(div);
    });
}


/* =========================================================
   ÁREA DOS RESPONSÁVEIS
========================================================= */

function atualizarAreaResponsaveis(){

    const nome =
        document.getElementById("respNome");

    if(!nome) return;

    nome.textContent =
        jogador.nome;

    document.getElementById(
        "respNivel"
    ).textContent =
        jogador.nivel;

    document.getElementById(
        "respQuizzes"
    ).textContent =
        jogador.quizzesConcluidos;

    document.getElementById(
        "respAcertos"
    ).textContent =
        jogador.totalAcertos;

    document.getElementById(
        "respConquistas"
    ).textContent =
        jogador.conquistas.length;

    document.getElementById(
        "respCombo"
    ).textContent =
        jogador.melhorCombo;

    const container =
        document.getElementById(
            "respMaterias"
        );

    if(!container) return;

    container.innerHTML = "";

    Object.keys(MATERIAS)
        .forEach(materia => {

        const dados =
            jogador.progresso[materia];

        const total =
            dados.facil.filter(
                q => q.concluido
            ).length +

            dados.medio.filter(
                q => q.concluido
            ).length +

            dados.dificil.filter(
                q => q.concluido
            ).length;

        const percentual =
            total / 30 * 100;

        const div =
            document.createElement("div");

        div.className =
            "materia-resp";

        div.innerHTML = `
            <div class="materia-resp-topo">

                <strong>
                    ${MATERIAS[materia].emoji}
                    ${MATERIAS[materia].nome}
                </strong>

                <span>
                    ${total}/30
                </span>

            </div>

            <div class="barra">
                <div style="width:${percentual}%"></div>
            </div>
        `;

        container.appendChild(div);
    });

    let mensagem =
        "Continue estudando! 🌟";

    if(jogador.totalAcertos >= 100){

        mensagem =
            "Excelente desempenho em matemática! 🏆";

    }else if(jogador.totalAcertos >= 50){

        mensagem =
            "Ótimo trabalho! Continue praticando. ⭐";

    }else if(jogador.totalAcertos >= 20){

        mensagem =
            "Bom progresso! Está aprendendo bastante. 😊";
    }

    document.getElementById(
        "respMensagem"
    ).textContent =
        mensagem;
}


/* =========================================================
   ATUALIZAÇÃO GERAL
========================================================= */

function atualizarTudo(){

    if(!jogador) return;

    atualizarInicio();
    atualizarPersonagem();
    atualizarProgresso();
    atualizarConquistas();

    criarMissoesSeNecessario();
    criarDesafiosSeNecessario();

    atualizarMissoes();
    atualizarDesafios();

    atualizarMissoesTela();
    atualizarDesafiosTela();

    atualizarEvolucao();
    atualizarRecompensas();
    atualizarAreaResponsaveis();
    atualizarSom();
}

function atualizarInicio(){

    const nome =
        document.getElementById(
            "nomeInicio"
        );

    if(!nome) return;

    nome.textContent =
        jogador.nome;

    document.getElementById(
        "nivelInicio"
    ).textContent =
        jogador.nivel;

    document.getElementById(
        "estrelasInicio"
    ).textContent =
        jogador.estrelas;

    document.getElementById(
        "moedasInicio"
    ).textContent =
        jogador.moedas;
}

function atualizarPersonagem(){

    const nome =
        document.getElementById(
            "personagemNome"
        );

    if(!nome) return;

    nome.textContent =
        jogador.nome;

    document.getElementById(
        "personagemNivel"
    ).textContent =
        jogador.nivel;

    document.getElementById(
        "personagemEstrelas"
    ).textContent =
        jogador.estrelas;

    document.getElementById(
        "personagemMoedas"
    ).textContent =
        jogador.moedas;

    document.getElementById(
        "personagemCombo"
    ).textContent =
        jogador.melhorCombo;

    const visual =
        document.getElementById(
            "personagemVisual"
        );

    if(jogador.foto){

        visual.innerHTML =
            `<img src="${jogador.foto}" alt="Foto">`;

    }else{

        visual.textContent =
            jogador.avatar;
    }
}

function atualizarProgresso(){

    const total =
        document.getElementById(
            "totalQuizzes"
        );

    if(!total) return;

    total.textContent =
        jogador.quizzesConcluidos;

    document.getElementById(
        "totalAcertos"
    ).textContent =
        jogador.totalAcertos;

    document.getElementById(
        "melhorCombo"
    ).textContent =
        jogador.melhorCombo;

    document.getElementById(
        "totalConquistas"
    ).textContent =
        jogador.conquistas.length;

    const container =
        document.getElementById(
            "progressoMaterias"
        );

    if(!container) return;

    container.innerHTML = "";

    Object.keys(MATERIAS)
        .forEach(materia => {

        const dados =
            jogador.progresso[materia];

        const facil =
            dados.facil.filter(
                q => q.concluido
            ).length;

        const medio =
            dados.medio.filter(
                q => q.concluido
            ).length;

        const dificil =
            dados.dificil.filter(
                q => q.concluido
            ).length;

        const total =
            facil + medio + dificil;

        const div =
            document.createElement("div");

        div.className =
            "materia-progresso-card";

        div.innerHTML = `
            <h3>
                ${MATERIAS[materia].emoji}
                ${MATERIAS[materia].nome}
            </h3>

            <p>🟢 Fácil: ${facil}/10</p>
            <p>🟡 Médio: ${medio}/10</p>
            <p>🔴 Difícil: ${dificil}/10</p>

            <div class="barra">
                <div
                    style="width:${total / 30 * 100}%">
                </div>
            </div>
        `;

        container.appendChild(div);
    });
}


/* =========================================================
   UTILIDADES
========================================================= */

function numeroAleatorio(min,max){

    return Math.floor(
        Math.random() *
        (max - min + 1)
    ) + min;
}

function mostrarMensagem(texto){

    const elemento =
        document.getElementById(
            "mensagemFlutuante"
        );

    if(!elemento) return;

    elemento.textContent =
        texto;

    elemento.classList.add(
        "mostrar"
    );

    clearTimeout(
        mostrarMensagem.timer
    );

    mostrarMensagem.timer =
        setTimeout(() => {

            elemento.classList.remove(
                "mostrar"
            );

        },1800);
}

function soltarConfetes(){

    const container =
        document.getElementById(
            "confetes"
        );

    if(!container) return;

    const emojis = [
        "🎉",
        "⭐",
        "🌟",
        "🎊",
        "✨",
        "🏆"
    ];

    for(let i=0;i<35;i++){

        const confete =
            document.createElement("div");

        confete.className =
            "confete";

        confete.textContent =
            emojis[
                numeroAleatorio(
                    0,
                    emojis.length - 1
                )
            ];

        confete.style.left =
            Math.random() * 100 + "%";

        confete.style.animationDelay =
            Math.random() * .8 + "s";

        container.appendChild(
            confete
        );

        setTimeout(() => {
            confete.remove();
        },3500);
    }
}


/* =========================================================
   INÍCIO
========================================================= */

carregarDados();

if(!localStorage.getItem(SAVE_KEY)){

    setTimeout(() => {

        mostrarTela(
            "telaCriarPersonagem"
        );

    },100);

}else{

    mostrarTela("telaInicio");
}