const SAVE_KEY = 'mc-save-v1';
const LEGACY_KEY = 'mc-diamonds';
const SHOP_TITLE = 'Магазин';

const UPGRADES = [
  { id: 'wood-pick',    name: 'Деревянная кирка',    type: 'click',   power: 1,  baseCost: 10,   costMul: 1.55 },
  { id: 'iron-pick',    name: 'Железная кирка',      type: 'click',   power: 5,  baseCost: 120,  costMul: 1.5  },
  { id: 'diamond-pick', name: 'Алмазная кирка',      type: 'click',   power: 25, baseCost: 1500, costMul: 1.45 },
  { id: 'diamond-farm', name: 'Алмазная ферма',      type: 'passive', power: 1,  baseCost: 50,   costMul: 1.7  },
  { id: 'auto-mine',    name: 'Автоматическая шахта', type: 'passive', power: 8, baseCost: 800,  costMul: 1.6  }
];

const state = { diamonds: 0, levels: {} };
const compactFmt = new Intl.NumberFormat('ru', { notation: 'compact', maximumFractionDigits: 2 });

let ysdk = null;
let player = null;
let cloudTimer = null;

const balanceEl = document.getElementById('balance');
const blockEl = document.getElementById('block');
const shopEl = document.getElementById('shop');
const cubeEl = document.querySelector('.cube');

const fmt = n => n >= 100000 ? compactFmt.format(n) : String(Math.floor(n));

const levelOf = id => state.levels[id] || 0;

const clickPower = () => 1 + UPGRADES.reduce((sum, u) =>
  u.type === 'click' ? sum + u.power * levelOf(u.id) : sum, 0);

const incomePerSec = () => UPGRADES.reduce((sum, u) =>
  u.type === 'passive' ? sum + u.power * levelOf(u.id) : sum, 0);

const costOf = u => Math.floor(u.baseCost * Math.pow(u.costMul, levelOf(u.id)));

function refresh() {
  balanceEl.textContent = fmt(state.diamonds);
  updateShop();
}

function updateShop() {
  shopEl.querySelectorAll('.item-buy').forEach(btn => {
    const u = UPGRADES.find(x => x.id === btn.dataset.id);
    btn.textContent = '◆ ' + fmt(costOf(u));
    btn.disabled = state.diamonds < costOf(u);
  });
  shopEl.querySelectorAll('.shop-item').forEach(item => {
    const u = UPGRADES.find(x => x.id === item.querySelector('.item-buy').dataset.id);
    item.querySelector('.item-lvl').textContent = 'ур. ' + levelOf(u.id);
  });
}

function renderShop() {
  shopEl.innerHTML =
    '<h2 class="shop-title">' + SHOP_TITLE + '</h2>' +
    '<ul class="shop-list" id="shop-list">' +
    UPGRADES.map(u =>
      '<li class="shop-item">' +
      '<span class="item-name">' + u.name + '</span>' +
      '<span class="item-lvl">ур. 0</span>' +
      '<button class="item-buy" type="button" data-id="' + u.id + '">◆ 0</button>' +
      '</li>'
    ).join('') +
    '</ul>';
  document.getElementById('shop-list').addEventListener('click', onBuy);
}

function onBuy(e) {
  const btn = e.target.closest('.item-buy');
  if (!btn || btn.disabled) return;
  const u = UPGRADES.find(x => x.id === btn.dataset.id);
  const cost = costOf(u);
  if (state.diamonds < cost) return;
  state.diamonds -= cost;
  state.levels[u.id] = levelOf(u.id) + 1;
  persist();
  refresh();
}

function spawnFloater(x, y, text) {
  const plus = document.createElement('span');
  plus.className = 'plus-one';
  plus.textContent = text;
  plus.style.left = (x - 10) + 'px';
  plus.style.top = (y - 24) + 'px';
  document.body.appendChild(plus);
  plus.addEventListener('animationend', () => plus.remove());
}

blockEl.addEventListener('pointerdown', e => {
  const gain = clickPower();
  state.diamonds += gain;
  spawnFloater(e.clientX + (Math.random() * 16 - 8), e.clientY, '+' + fmt(gain));
  persist();
  refresh();
  if (navigator.vibrate) navigator.vibrate(15);
});

setInterval(() => {
  const inc = incomePerSec();
  if (!inc) return;
  state.diamonds += inc;
  spawnFloater(
    cubeEl.getBoundingClientRect().left + cubeEl.offsetWidth / 2,
    cubeEl.getBoundingClientRect().bottom - 20,
    '+' + fmt(inc)
  );
  persist();
  refresh();
}, 1000);

function persist() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  } catch (e) {}
  scheduleCloudSave();
}

function scheduleCloudSave() {
  if (!player) return;
  clearTimeout(cloudTimer);
  cloudTimer = setTimeout(flushCloud, 4000);
}

function flushCloud() {
  clearTimeout(cloudTimer);
  if (!player) return;
  player.setData({ diamonds: state.diamonds, levels: state.levels }, true).catch(() => {});
}

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') flushCloud();
});

function normalize(data) {
  const s = { diamonds: Math.floor(Number(data.diamonds)) || 0, levels: {} };
  UPGRADES.forEach(u => {
    const lvl = data.levels ? Math.floor(Number(data.levels[u.id])) || 0 : 0;
    if (lvl > 0) s.levels[u.id] = lvl;
  });
  return s;
}

function loadLocal() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) return normalize(JSON.parse(raw));
    return { diamonds: Number(localStorage.getItem(LEGACY_KEY)) || 0, levels: {} };
  } catch (e) {
    return { diamonds: 0, levels: {} };
  }
}

function applyState(s) {
  state.diamonds = Math.max(state.diamonds, s.diamonds);
  Object.keys(s.levels).forEach(id => {
    state.levels[id] = Math.max(levelOf(id), s.levels[id]);
  });
  try {
    localStorage.removeItem(LEGACY_KEY);
  } catch (e) {}
}

async function initYG() {
  if (typeof YaGames === 'undefined') return;
  try {
    ysdk = await YaGames.init();
    if (ysdk.features && ysdk.features.LoadingAPI) {
      ysdk.features.LoadingAPI.ready();
    }
    try {
      player = await ysdk.getPlayer({ scopes: false });
      const cloud = await player.getData();
      if (cloud && typeof cloud.diamonds === 'number') {
        applyState(normalize(cloud));
      }
    } catch (e) {}
    refresh();
    ysdk.adv.showFullscreenAdv({
      callbacks: {
        onOpen: () => {},
        onClose: wasShown => {},
        onError: () => {}
      }
    });
  } catch (e) {}
}

applyState(loadLocal());
renderShop();
refresh();
initYG();
