"use strict";
/* ===== Water Sort Puzzle — offline, no dependencies ===== */
/*GEN*/
const CAP = 4;
const COLORS = ["#ff5a5f","#ffd23f","#3ddc97","#4dabf7","#b57bff","#ff8c42","#f06cc0","#1fd1d1","#8bc34a","#a0522d","#e8e8e8","#2f4fd8"];
// Deterministic RNG so each level is always the same puzzle
function rng(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
// Difficulty ramp: more colors as the level grows, then fewer spare bottles
function levelParams(l){return{colors:Math.min(3+Math.floor((l-1)/4),COLORS.length),empty:l>60?1+(l%3?1:0):2};}
function isDone(b){return b.every(t=>t.length===0||(t.length===CAP&&t.every(c=>c===t[0])));}
function canPour(a,b){if(!a.length||a===b||b.length>=CAP)return false;if(b.length&&b[b.length-1]!==a[a.length-1])return false;
  // pointless move: whole bottle of one color into an empty bottle
  if(!b.length&&a.every(c=>c===a[0]))return false;return true;}
// Pour whole top group as far as space allows; returns count moved
function pour(a,b){const c=a[a.length-1];let n=0;while(a.length&&a[a.length-1]===c&&b.length<CAP){b.push(a.pop());n++;}return n;}
const clone=s=>s.map(b=>b.slice());
// DFS solver (also gives hints). Returns list of [from,to] or null
function solve(state,cap){const seen=new Set(),path=[];let nodes=0;
  const key=s=>s.map(b=>b.join("")).sort().join("|");
  function dfs(s){if(isDone(s))return true;if(++nodes>cap)return false;const k=key(s);if(seen.has(k))return false;seen.add(k);
    const mv=[];for(let i=0;i<s.length;i++)for(let j=0;j<s.length;j++)if(canPour(s[i],s[j])){
      const top=s[i][s[i].length-1];let g=0;for(let x=s[i].length-1;x>=0&&s[i][x]===top;x--)g++;
      mv.push([i,j,(s[j].length?10:0)+Math.min(g,CAP-s[j].length)]);}
    mv.sort((a,b)=>b[2]-a[2]);
    for(const[i,j]of mv){const n=clone(s);pour(n[i],n[j]);path.push([i,j]);if(dfs(n))return true;path.pop();if(nodes>cap)return false;}
    return false;}
  return dfs(state)?path.slice():null;}
// Generate: shuffle units randomly, then PROVE solvable with the solver; retry otherwise
function genLevel(l){let p=levelParams(l);
  for(let att=0;att<200;att++){const r=rng(l*7919+att*104729);
    const nc=att>60?Math.max(3,p.colors-1):p.colors,units=[];
    for(let c=0;c<nc;c++)for(let k=0;k<CAP;k++)units.push(c);
    for(let i=units.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[units[i],units[j]]=[units[j],units[i]];}
    const s=[];for(let c=0;c<nc;c++)s.push(units.slice(c*CAP,c*CAP+CAP));
    for(let e=0;e<p.empty;e++)s.push([]);
    if(s.some(b=>b.length&&b.every(x=>x===b[0])))continue; // avoid pre-solved bottles
    if(solve(clone(s),40000))return s;}
  // guaranteed fallback: nearly solved puzzle
  return [[0,1,0,1],[1,0,1,0],[],[]];}
/*ENDGEN*/

/* ===== Save system ===== */
const SAVE_KEY="wsp_save_v1";
let save=Object.assign({level:1,max:1,sound:true,music:true,started:false},JSON.parse(localStorage.getItem(SAVE_KEY)||"{}"));
const store=()=>{try{localStorage.setItem(SAVE_KEY,JSON.stringify(save));}catch(e){}};
const $=id=>document.getElementById(id);

/* ===== Audio (generated with WebAudio, no files) ===== */
let ac=null;
function ctx(){if(!ac){const A=window.AudioContext||window.webkitAudioContext;if(A)ac=new A();}if(ac&&ac.state==="suspended")ac.resume();return ac;}
function tone(f,d,type,vol,when){const a=ctx();if(!a)return;const t=a.currentTime+(when||0),o=a.createOscillator(),g=a.createGain();
  o.type=type||"sine";o.frequency.setValueAtTime(f,t);g.gain.setValueAtTime(vol||.15,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+d);}
const sfx={
  tap(){if(save.sound)tone(520,.08,"triangle",.12);},
  pour(){if(save.sound)for(let i=0;i<6;i++)tone(300+i*70,.12,"sine",.08,i*.07);},
  bad(){if(save.sound)tone(150,.2,"sawtooth",.08);},
  win(){if(save.sound)[523,659,784,1047].forEach((f,i)=>tone(f,.4,"triangle",.15,i*.14));}};
let musicTimer=null,mi=0;const SCALE=[262,330,392,523,392,330,294,349,440,349,330,392];
function musicOn(){stopMusic();if(!save.music)return;musicTimer=setInterval(()=>{if(ac&&ac.state==="running")tone(SCALE[mi++%SCALE.length]/2,.9,"sine",.04);},700);}
function stopMusic(){clearInterval(musicTimer);musicTimer=null;}

/* ===== Game state ===== */
let state=[],history=[],undos=3,sel=-1,busy=false,level=1;
function show(id){document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.id===id));}
function modal(id,on){$(id).classList.toggle("active",on);}

function startLevel(l){level=l;save.level=l;save.started=true;store();state=genLevel(l);history=[];undos=3;sel=-1;busy=false;
  $("lvl").textContent="LEVEL "+l;show("game");modal("win",false);render();updateUndo();}

// Pick bottle size so every bottle fits on screen in 1-4 rows
function layout(){const b=$("board"),W=b.clientWidth-8,H=b.clientHeight-8,n=state.length;let best=0,gap=12;
  for(let r=1;r<=4;r++){const c=Math.ceil(n/r),w=Math.min((W-(c-1)*gap)/c,(H-(r-1)*gap)/r/4.1);if(w>best)best=w;}
  b.style.setProperty("--bw",Math.max(30,Math.min(best,90))+"px");b.style.setProperty("--gap",gap+"px");}

function render(popIdx){layout();const b=$("board");b.innerHTML="";
  state.forEach((t,i)=>{const e=document.createElement("div");e.className="bottle"+(i===sel?" sel":"")+(t.length===CAP&&t.every(c=>c===t[0])?" done":"");
    e.dataset.i=i;t.forEach((c,k)=>{const l=document.createElement("div");l.className="layer"+(popIdx===i&&k>=popFrom?" pop":"");l.style.setProperty("--c",COLORS[c]);e.appendChild(l);});
    e.addEventListener("click",()=>tapBottle(i));b.appendChild(e);});}
let popFrom=0;
const bottleEl=i=>$("board").children[i];

function updateUndo(){const u=$("bUndo");u.textContent="UNDO "+undos+"/3";u.disabled=undos<=0||history.length===0;}

function tapBottle(i){if(busy)return;ctx();
  if(sel<0){if(!state[i].length){sfx.bad();return;}sel=i;sfx.tap();bottleEl(i).classList.add("sel");return;}
  if(sel===i){sel=-1;bottleEl(i).classList.remove("sel");return;}
  if(!canPour(state[sel],state[i])){sfx.bad();const o=sel;sel=-1;bottleEl(o).classList.remove("sel");
    if(state[i].length){sel=i;bottleEl(i).classList.add("sel");}return;}
  doPour(sel,i);}

function doPour(from,to){busy=true;const snap=clone(state),src=bottleEl(from),dst=bottleEl(to);
  // Animate: source moves over destination and tilts, a stream of liquid falls
  const rs=src.getBoundingClientRect(),rd=dst.getBoundingClientRect();
  const right=rd.left>rs.left,dx=(rd.left-rs.left)+(right?-rs.width*1.15:rs.width*1.15);
  src.style.zIndex=6;src.style.transform=`translate(${dx}px,${rd.top-rs.top-rs.height*0.3}px) rotate(${right?60:-60}deg)`;
  const top=state[from][state[from].length-1],st=document.createElement("div");st.className="stream";st.style.setProperty("--c",COLORS[top]);
  st.style.left=(rd.left+rd.width/2-3)+"px";st.style.top=(rd.top-rs.height*0.1)+"px";st.style.height="0px";st.style.transition="height .2s";document.body.appendChild(st);
  sfx.pour();setTimeout(()=>{st.style.height=(rd.height*0.5)+"px";},120);
  setTimeout(()=>{const before=state[to].length;pour(state[from],state[to]);history.push(snap);popFrom=before;st.remove();sel=-1;
    render(to);updateUndo();busy=false;
    if(isDone(state))setTimeout(win,500);},560);}

function undo(){if(busy||undos<=0||!history.length)return;state=history.pop();undos--;sel=-1;render();updateUndo();sfx.tap();}

function hint(){if(busy)return;const s=solve(clone(state),40000);let m=s&&s[0];
  if(!m){for(let i=0;i<state.length&&!m;i++)for(let j=0;j<state.length;j++)if(canPour(state[i],state[j])){m=[i,j];break;}}
  if(!m)return;sfx.tap();[m[0],m[1]].forEach(i=>{const e=bottleEl(i);e.classList.add("hint");setTimeout(()=>e.classList.remove("hint"),2500);});}

function win(){sfx.win();save.max=Math.max(save.max,level+1);save.level=level+1;store();modal("win",true);confetti();}

/* ===== Confetti celebration ===== */
function confetti(){const c=$("fx"),g=c.getContext("2d");c.width=innerWidth;c.height=innerHeight;
  const P=Array.from({length:90},()=>({x:Math.random()*c.width,y:-20-Math.random()*c.height*.5,v:2+Math.random()*4,s:5+Math.random()*7,c:COLORS[Math.floor(Math.random()*COLORS.length)],r:Math.random()*6}));
  let f=0;(function tick(){g.clearRect(0,0,c.width,c.height);P.forEach(p=>{p.y+=p.v;p.r+=.1;p.x+=Math.sin(p.r);g.fillStyle=p.c;g.fillRect(p.x,p.y,p.s,p.s*.6);});
    if(++f<240&&$("win").classList.contains("active"))requestAnimationFrame(tick);else g.clearRect(0,0,c.width,c.height);})();}

/* ===== Level select ===== */
let page=0;const PER=50;
function levelsScreen(){page=Math.floor((Math.max(save.max,1)-1)/PER);drawGrid();show("levels");}
function drawGrid(){const g=$("grid");g.innerHTML="";$("pInfo").textContent=(page*PER+1)+" – "+(page*PER+PER);
  for(let i=1;i<=PER;i++){const l=page*PER+i,b=document.createElement("button");b.className="cell"+(l>save.max?" lock":"")+(l===save.max?" cur":"");
    b.textContent=l>save.max?"🔒":l;b.onclick=()=>startLevel(l);g.appendChild(b);}
  $("pPrev").style.visibility=page>0?"visible":"hidden";}

/* ===== Settings & menu ===== */
function refreshSettings(){$("tSound").textContent="Sound: "+(save.sound?"ON":"OFF");$("tMusic").textContent="Music: "+(save.music?"ON":"OFF");
  $("sRestart").style.display=$("game").classList.contains("active")?"":"none";$("bCont").style.display=save.started?"":"none";}
function openSettings(){refreshSettings();modal("settings",true);}
function ask(txt,fn){$("cTxt").textContent=txt;modal("confirm",true);$("cYes").onclick=()=>{modal("confirm",false);fn();};}
function home(){modal("settings",false);modal("win",false);refreshSettings();show("menu");refreshSettings();}

$("bPlay").onclick=()=>{ctx();musicOn();startLevel(save.started?1:1);};
$("bCont").onclick=()=>{ctx();musicOn();startLevel(Math.min(save.level,save.max));};
$("bLevels").onclick=levelsScreen;$("bSet").onclick=openSettings;
$("lBack").onclick=home;$("pPrev").onclick=()=>{page--;drawGrid();};$("pNext").onclick=()=>{page++;drawGrid();};
$("gSet").onclick=openSettings;$("gRestart").onclick=$("bRestart").onclick=()=>startLevel(level);
$("bUndo").onclick=undo;$("bHint").onclick=hint;
$("tSound").onclick=()=>{save.sound=!save.sound;store();refreshSettings();sfx.tap();};
$("tMusic").onclick=()=>{save.music=!save.music;store();refreshSettings();save.music?(ctx(),musicOn()):stopMusic();};
$("sRestart").onclick=()=>{modal("settings",false);startLevel(level);};
$("sHome").onclick=home;$("sClose").onclick=()=>modal("settings",false);
$("sReset").onclick=()=>ask("Reset ALL progress?",()=>{save.level=1;save.max=1;save.started=false;store();modal("settings",false);home();});
$("cNo").onclick=()=>modal("confirm",false);
$("bNext").onclick=()=>startLevel(level+1);$("wHome").onclick=home;
addEventListener("resize",()=>{if($("game").classList.contains("active")&&!busy)render();});
document.addEventListener("visibilitychange",()=>{if(document.hidden)stopMusic();else if($("game").classList.contains("active"))musicOn();});
refreshSettings();
