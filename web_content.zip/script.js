(() => {
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const expressionEl = $('#expression'), resultEl = $('#result'), toastEl = $('#toast');
  let expression = '', lastAnswer = 0, soundOn = false, editingNoteId = null;
  let history = load('pc_history', []), notes = load('pc_notes', []);
  function load(key, fallback){try{const v=JSON.parse(localStorage.getItem(key));return Array.isArray(v)?v:fallback}catch{return fallback}}
  function save(key, value){try{localStorage.setItem(key,JSON.stringify(value))}catch{toast('ذخیره‌سازی در این مرورگر در دسترس نیست.')}}
  function toast(message){toastEl.textContent=message;toastEl.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>toastEl.classList.remove('show'),2300)}
  function beep(){if(!soundOn)return;try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const c=new C(),o=c.createOscillator(),g=c.createGain();o.frequency.value=650;g.gain.value=.025;o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.035);o.onended=()=>c.close()}catch{}}
  function render(){expressionEl.textContent=expression||'0';}
  function append(v){if(expression.length>120){toast('عبارت بیش از حد طولانی است.');return}expression+=v;render();preview();beep()}
  function preview(){if(!expression){resultEl.textContent='آماده محاسبه';return}try{const v=calculate(expression);resultEl.textContent=Number.isFinite(v)?'= '+format(v):'نتیجه نامعتبر'}catch{resultEl.textContent=''}}
  function format(n){if(!Number.isFinite(n))throw Error('نتیجه نامعتبر');if(Math.abs(n)<1e-12)n=0;return Number(n.toPrecision(12)).toString()}
  function factorial(n){if(!Number.isInteger(n)||n<0||n>170)throw Error('فاکتوریل فقط برای عدد صحیح ۰ تا ۱۷۰ است');let r=1;for(let i=2;i<=n;i++)r*=i;return r}
  function calculate(raw){
    let s=String(raw).replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/π/g,'PI').replace(/\be\b/g,'E');
    s=s.replace(/\bPI\b/g,'Math.PI').replace(/\bE\b/g,'Math.E');
    if(!/^[0-9+\-*/().,\sA-Za-z]*$/.test(s))throw Error('عبارت نامعتبر');
    if(/[A-Za-z]/.test(s.replace(/Math\.(PI|E)/g,'')))throw Error('عبارت نامعتبر');
    if(/\/\s*0(?:\.0*)?(?![\d.])/.test(s))throw Error('تقسیم بر صفر');
    if(s.length>220)throw Error('عبارت بیش از حد طولانی است');
    const v=Function('"use strict";return ('+s+')')();
    if(typeof v!=='number'||!Number.isFinite(v))throw Error('نتیجه نامعتبر');
    return v;
  }
  function record(expr, value){history.unshift({id:Date.now()+Math.random(),expr,result:format(value),time:new Date().toLocaleString()});history=history.slice(0,100);save('pc_history',history);renderHistory()}
  function equals(){if(!expression.trim())return;try{const old=expression,v=calculate(expression);lastAnswer=v;expression=format(v);resultEl.textContent='= '+format(v);record(old,v);render();beep()}catch(e){resultEl.textContent=e.message||'عبارت نامعتبر';toast(e.message||'عبارت نامعتبر')}}
  function unary(fn){
    try{if(!expression)throw Error('ابتدا یک عدد وارد کنید');let x=calculate(expression),v;
      switch(fn){
        case'sin':v=Math.sin(x*Math.PI/180);break;case'cos':v=Math.cos(x*Math.PI/180);break;case'tan':v=Math.tan(x*Math.PI/180);break;
        case'asin':v=Math.asin(x)*180/Math.PI;break;case'acos':v=Math.acos(x)*180/Math.PI;break;case'atan':v=Math.atan(x)*180/Math.PI;break;
        case'sqrt':if(x<0)throw Error('جذر عدد منفی در اعداد حقیقی تعریف نشده است');v=Math.sqrt(x);break;
        case'square':v=x*x;break;case'cube':v=x*x*x;break;case'log':if(x<=0)throw Error('عدد باید مثبت باشد');v=Math.log10(x);break;case'ln':if(x<=0)throw Error('عدد باید مثبت باشد');v=Math.log(x);break;
        case'factorial':v=factorial(x);break;case'abs':v=Math.abs(x);break;case'reciprocal':if(x===0)throw Error('تقسیم بر صفر مجاز نیست');v=1/x;break;
        case'pow':expression+='**';render();return;
        default:return;
      }
      const old=expression;expression=format(v);resultEl.textContent='= '+expression;record(fn+'('+old+')',v);render();beep();
    }catch(e){toast(e.message||'محاسبه انجام نشد');resultEl.textContent=e.message||'خطا'}
  }
  $$('.tab').forEach(b=>b.addEventListener('click',()=>{ $$('.tab').forEach(x=>x.classList.toggle('active',x===b));$$('.view').forEach(v=>v.classList.toggle('active',v.id===b.dataset.view+'View'));if(b.dataset.view==='history')renderHistory();if(b.dataset.view==='notes')renderNotes()}));
  $$('.keypad [data-value]').forEach(b=>b.addEventListener('click',()=>append(b.dataset.value)));
  $$('.quick-tools [data-action]').forEach(b=>b.addEventListener('click',()=>quick(b.dataset.action)));
  $$('.keypad [data-action]').forEach(b=>b.addEventListener('click',()=>quick(b.dataset.action)));
  function quick(a){beep();switch(a){case'clear':expression='';resultEl.textContent='آماده محاسبه';render();break;case'backspace':expression=expression.slice(0,-1);render();preview();break;case'equals':equals();break;case'percent':if(expression)expression='('+expression+')/100';render();preview();break;case'sign':if(expression)expression='-('+expression+')';else expression='-';render();preview();break;case'pi':append('π');break;case'e':append('e');break;case'openParen':append('(');break;case'closeParen':append(')');break;case'ans':append(format(lastAnswer));break}}
  $$('[data-func]').forEach(b=>b.addEventListener('click',()=>unary(b.dataset.func)));
  document.addEventListener('keydown',e=>{if(!$('#calculatorView').classList.contains('active'))return;if(e.ctrlKey||e.altKey||e.metaKey)return;if(/^[0-9.]$/.test(e.key)){append(e.key);e.preventDefault()}else if(['+','-','*','/','(',')'].includes(e.key)){append(({ '*':'×','/':'÷','-':'−'}[e.key]||e.key));e.preventDefault()}else if(e.key==='Enter'||e.key==='='){equals();e.preventDefault()}else if(e.key==='Backspace'){quick('backspace');e.preventDefault()}else if(e.key==='Escape'){quick('clear');e.preventDefault()}});
  $('#themeBtn').addEventListener('click',()=>{document.body.classList.toggle('light');save('pc_theme',document.body.classList.contains('light')?'light':'dark')});
  if(loadTheme()==='light')document.body.classList.add('light');
  function loadTheme(){try{return localStorage.getItem('pc_theme')}catch{return'dark'}}
  $('#soundBtn').addEventListener('click',()=>{soundOn=!soundOn;$('#soundBtn').textContent=soundOn?'🔔':'🔊';toast(soundOn?'صدای دکمه‌ها روشن شد':'صدای دکمه‌ها خاموش شد');beep()});
  $('#percentCalc').addEventListener('click',()=>{const b=Number($('#percentBase').value),r=Number($('#percentRate').value);if($('#percentBase').value===''||$('#percentRate').value===''||!Number.isFinite(b)||!Number.isFinite(r)){toast('هر دو مقدار را وارد کنید.');return}$('#percentOutput').textContent=format(b*r/100);});
  $('#averageCalc').addEventListener('click',()=>{const raw=$('#averageInput').value.trim(),parts=raw.split(/[,،\s]+/).filter(Boolean),nums=parts.map(Number);if(!parts.length||nums.some(n=>!Number.isFinite(n))){toast('چند عدد معتبر وارد کنید و آن‌ها را با کامه جدا سازید.');return}$('#averageOutput').textContent=format(nums.reduce((a,b)=>a+b,0)/nums.length)});
  $('#noteForm').addEventListener('submit',e=>{e.preventDefault();const title=$('#noteTitle').value.trim(),body=$('#noteBody').value.trim();if(!title||!body)return; if(editingNoteId!==null){notes=notes.map(n=>n.id===editingNoteId?{...n,title,body,updated:new Date().toLocaleString()}:n)}else{notes.unshift({id:Date.now()+Math.random(),title,body,updated:new Date().toLocaleString()})}save('pc_notes',notes);$('#noteForm').reset();editingNoteId=null;$('#cancelEdit').hidden=true;renderNotes();toast('یادداشت ذخیره شد.')});
  $('#cancelEdit').addEventListener('click',()=>{editingNoteId=null;$('#noteForm').reset();$('#cancelEdit').hidden=true});
  function renderNotes(){const box=$('#notesList');box.replaceChildren();if(!notes.length){box.innerHTML='<div class="empty-state">هنوز یادداشتی ندارید. اولین یادداشت خود را بنویسید.</div>';return}notes.forEach(n=>{const el=document.createElement('article');el.className='item-card';const h=document.createElement('h3');h.textContent=n.title;const p=document.createElement('p');p.textContent=n.body;const meta=document.createElement('div');meta.className='item-meta';meta.textContent=n.updated||'';const actions=document.createElement('div');actions.className='item-actions';const edit=document.createElement('button');edit.textContent='ویرایش';edit.addEventListener('click',()=>{$('#noteTitle').value=n.title;$('#noteBody').value=n.body;editingNoteId=n.id;$('#cancelEdit').hidden=false;$('#noteTitle').focus();window.scrollTo({top:0,behavior:'smooth'})});const del=document.createElement('button');del.textContent='حذف';del.addEventListener('click',()=>{if(confirm('این یادداشت حذف شود؟')){notes=notes.filter(x=>x.id!==n.id);save('pc_notes',notes);renderNotes()}});actions.append(edit,del);el.append(h,p,meta,actions);box.append(el)})}
  function renderHistory(){const box=$('#historyList');box.replaceChildren();if(!history.length){box.innerHTML='<div class="empty-state">هنوز محاسبه‌ای ثبت نشده است.</div>';return}history.forEach(item=>{const el=document.createElement('article');el.className='item-card';const h=document.createElement('h3');h.textContent=item.expr+' = '+item.result;const meta=document.createElement('div');meta.className='item-meta';meta.textContent=item.time||'';const actions=document.createElement('div');actions.className='item-actions';const use=document.createElement('button');use.textContent='استفاده از جواب';use.addEventListener('click',()=>{expression=item.result;render();resultEl.textContent='جواب قبلی انتخاب شد';$$('.tab').find(t=>t.dataset.view==='calculator').click()});const del=document.createElement('button');del.textContent='حذف';del.addEventListener('click',()=>{history=history.filter(x=>x.id!==item.id);save('pc_history',history);renderHistory()});actions.append(use,del);el.append(h,meta,actions);box.append(el)})}
  $('#clearHistory').addEventListener('click',()=>{if(confirm('تمام تاریخچه حذف شود؟')){history=[];save('pc_history',history);renderHistory();toast('تاریخچه پاک شد.')}});
  render();renderNotes();renderHistory();
})();