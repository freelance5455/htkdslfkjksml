const input=document.getElementById("photoInput"), upload=document.getElementById("uploadBtn"), zone=document.getElementById("dropZone"), preview=document.getElementById("preview"), status=document.getElementById("status"), generate=document.getElementById("generate");
upload.onclick=()=>input.click();
zone.onclick=e=>{if(e.target!==upload) input.click()};
input.onchange=()=>{const f=input.files&&input.files[0]; if(!f)return; preview.src=URL.createObjectURL(f); preview.style.display="block"; zone.style.display="none"; status.textContent="Photo selected. Choose a 90s style."};
document.querySelectorAll(".style").forEach(b=>b.onclick=()=>{document.querySelectorAll(".style").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");});
generate.onclick=()=>{if(!input.files.length){status.textContent="Please upload a photo first.";return} status.textContent="Demo UI ready — connect your AI image API here to generate the final photo.";};