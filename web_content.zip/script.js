/*
  ================================
  MY QUIZ APP - QUESTION DATABASE
  ================================
  बाद में questions इसी format में जोड़ें:

  {
    question:"आपका प्रश्न?",
    options:["Option A","Option B","Option C","Option D"],
    answer:0
  }

  answer:
  0 = पहला option
  1 = दूसरा option
  2 = तीसरा option
  3 = चौथा option
*/

const chapters = {
  Physics:["Physical World","Units and Measurement","Motion","Laws of Motion"],
  Chemistry:["Some Basic Concepts","Structure of Atom","Periodic Table","Chemical Bonding"],
  Mathematics:["Sets","Relations and Functions","Trigonometric Functions","Complex Numbers"],
  English:["Grammar","Tenses","Narration","Conjunction"],
  Biology:["The Living World","Biological Classification","Plant Kingdom","Animal Kingdom"],
  GK:["History","Geography","Polity","General Science"],
  Reasoning:["Blood Relation","Coding Decoding","Number Series","Analogy"]
};

/* =====================================================
   यहाँ से QUESTIONS जोड़ें
   ===================================================== */

const questions = {
  "Physics-Physical World":[
    {question:"भौतिकी मुख्य रूप से किसका अध्ययन करती है?",options:["पदार्थ और ऊर्जा","केवल पौधों का","केवल इतिहास का","केवल भाषा का"],answer:0},
    {question:"भौतिकी का प्रमुख उद्देश्य क्या है?",options:["प्रकृति के नियमों को समझना","केवल कहानी पढ़ना","केवल पौधों को पढ़ना","केवल इतिहास पढ़ना"],answer:0},
    {question:"निम्न में से भौतिकी की शाखा कौन-सी है?",options:["यांत्रिकी","इतिहास","भूगोल","व्याकरण"],answer:0},
    {question:"प्रकाश के अध्ययन को क्या कहते हैं?",options:["प्रकाशिकी","यांत्रिकी","ऊष्मागतिकी","नाभिकीय भौतिकी"],answer:0},
    {question:"ऊष्मागतिकी मुख्य रूप से किससे संबंधित है?",options:["ऊष्मा और तापमान","केवल प्रकाश","केवल ध्वनि","केवल ग्रह"],answer:0},
    {question:"प्रकृति में कितनी मूलभूत अंतःक्रियाएँ मानी जाती हैं?",options:["चार","दो","छह","आठ"],answer:0},
    {question:"निम्न में से मूलभूत बल कौन-सा है?",options:["गुरुत्वाकर्षण","घर्षण","तनाव","अभिकेंद्रीय"],answer:0},
    {question:"चार मूलभूत बलों में सबसे कमजोर कौन-सा है?",options:["गुरुत्वाकर्षण","विद्युतचुंबकीय","प्रबल नाभिकीय","कमजोर नाभिकीय"],answer:0},
    {question:"चार मूलभूत बलों में सबसे प्रबल कौन-सा है?",options:["प्रबल नाभिकीय","गुरुत्वाकर्षण","विद्युतचुंबकीय","कमजोर नाभिकीय"],answer:0},
    {question:"गुरुत्वाकर्षण का सार्वत्रिक नियम किसने दिया?",options:["न्यूटन","मैक्सवेल","फैराडे","बोहर"],answer:0},
    {question:"सापेक्षता के सिद्धांत से कौन संबंधित है?",options:["आइंस्टीन","न्यूटन","फैराडे","मैक्सवेल"],answer:0},
    {question:"विद्युतचुंबकीय प्रेरण की खोज किसने की?",options:["फैराडे","न्यूटन","आइंस्टीन","बोहर"],answer:0},
    {question:"ऊर्जा संरक्षण का नियम क्या बताता है?",options:["ऊर्जा नष्ट या उत्पन्न नहीं होती, रूप बदलती है","ऊर्जा हमेशा नष्ट होती है","ऊर्जा केवल उत्पन्न होती है","ऊर्जा होती ही नहीं"],answer:0},
    {question:"भौतिकी और प्रौद्योगिकी का संबंध कैसा है?",options:["घनिष्ठ संबंध है","कोई संबंध नहीं","दोनों विरोधी हैं","केवल इतिहास से संबंध है"],answer:0},
    {question:"एक्स-रे का प्रमुख उपयोग किस क्षेत्र में है?",options:["चिकित्सा","इतिहास","व्याकरण","साहित्य"],answer:0}
  ],

  /* नए chapter के questions यहाँ डाल सकते हैं */
  "Physics-Units and Measurement":[],
  "Physics-Motion":[],
  "Physics-Laws of Motion":[],
  "Chemistry-Some Basic Concepts":[],
  "Chemistry-Structure of Atom":[],
  "Chemistry-Periodic Table":[],
  "Chemistry-Chemical Bonding":[],
  "Mathematics-Sets":[],
  "Mathematics-Relations and Functions":[],
  "Mathematics-Trigonometric Functions":[],
  "Mathematics-Complex Numbers":[],
  "English-Grammar":[],
  "English-Tenses":[],
  "English-Narration":[],
  "English-Conjunction":[],
  "Biology-The Living World":[],
  "Biology-Biological Classification":[],
  "Biology-Plant Kingdom":[],
  "Biology-Animal Kingdom":[],
  "GK-History":[],
  "GK-Geography":[],
  "GK-Polity":[],
  "GK-General Science":[],
  "Reasoning-Blood Relation":[],
  "Reasoning-Coding Decoding":[],
  "Reasoning-Number Series":[],
  "Reasoning-Analogy":[]
};

let currentSubject="";
let currentChapter="";
let currentQuestion=0;
let score=0;
let answered=false;

const subjectNames={
  Physics:"⚡ Physics",
  Chemistry:"🧪 Chemistry",
  Mathematics:"📐 Mathematics",
  English:"📖 English",
  Biology:"🧬 Biology",
  GK:"🌍 General Knowledge",
  Reasoning:"🧠 Reasoning"
};

function init(){
  const list=document.getElementById("subjectList");
  list.innerHTML="";
  Object.keys(chapters).forEach(subject=>{
    const b=document.createElement("button");
    b.innerText=subjectNames[subject]||subject;
    b.onclick=()=>showChapters(subject);
    list.appendChild(b);
  });
}

function showChapters(subject){
  currentSubject=subject;
  hideAll();
  document.getElementById("chapterScreen").classList.remove("hidden");
  document.getElementById("subjectTitle").innerText=subjectNames[subject]||subject;
  const list=document.getElementById("chapterList");
  list.innerHTML="";
  chapters[subject].forEach(chapter=>{
    const b=document.createElement("button");
    b.innerText=chapter;
    b.className="chapter-button";
    b.onclick=()=>startQuiz(subject,chapter);
    list.appendChild(b);
  });
}

function startQuiz(subject,chapter){
  currentSubject=subject;
  currentChapter=chapter;
  currentQuestion=0;
  score=0;
  answered=false;
  hideAll();
  document.getElementById("quizScreen").classList.remove("hidden");
  loadQuestion();
}

function loadQuestion(){
  answered=false;
  const quiz=questions[currentSubject+"-"+currentChapter];
  if(!quiz||quiz.length===0){
    document.getElementById("questionNumber").innerText="";
    document.getElementById("question").innerText="इस Chapter के Questions अभी नहीं जोड़े गए हैं।";
    document.getElementById("options").innerHTML="";
    document.getElementById("nextBtn").style.display="none";
    document.getElementById("score").innerText="स्कोर: 0";
    return;
  }

  document.getElementById("nextBtn").style.display="block";
  const q=quiz[currentQuestion];
  document.getElementById("questionNumber").innerText=`प्रश्न ${currentQuestion+1} / ${quiz.length}`;
  document.getElementById("question").innerText=q.question;

  const options=document.getElementById("options");
  options.innerHTML="";

  q.options.forEach((option,index)=>{
    const b=document.createElement("button");
    b.className="option";
    b.innerText=String.fromCharCode(65+index)+". "+option;
    b.onclick=()=>checkAnswer(index);
    options.appendChild(b);
  });

  document.getElementById("score").innerText="स्कोर: "+score;
}

function checkAnswer(selected){
  if(answered)return;
  answered=true;

  const quiz=questions[currentSubject+"-"+currentChapter];
  const correct=quiz[currentQuestion].answer;
  const buttons=document.querySelectorAll(".option");

  if(selected===correct){
    score++;
    buttons[selected].innerText+="  ✅ सही";
  }else{
    buttons[selected].innerText+="  ❌ गलत";
    buttons[correct].innerText+="  ✅ सही उत्तर";
  }

  document.getElementById("score").innerText="स्कोर: "+score;
}

function nextQuestion(){
  const quiz=questions[currentSubject+"-"+currentChapter];
  if(!quiz||quiz.length===0)return;

  if(!answered){
    alert("पहले एक option चुनें।");
    return;
  }

  if(currentQuestion<quiz.length-1){
    currentQuestion++;
    loadQuestion();
  }else{
    document.getElementById("resultText").innerText=
      `आपका स्कोर: ${score} / ${quiz.length}`;
    hideAll();
    document.getElementById("resultScreen").classList.remove("hidden");
  }
}

function goHome(){
  hideAll();
  document.getElementById("homeScreen").classList.remove("hidden");
}

function goChapters(){
  showChapters(currentSubject);
}

function hideAll(){
  ["homeScreen","chapterScreen","quizScreen","resultScreen"].forEach(id=>{
    document.getElementById(id).classList.add("hidden");
  });
}

init();
