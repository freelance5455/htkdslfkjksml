const $ = (id) => document.getElementById(id);

let timer = null;

/* =========================
   RÉCUPÉRATION DES MANCHES
========================= */

function getRounds() {
  const text = $("rounds").value
    .replace(/x/gi, "")
    .trim();

  if (!text) return [];

  return text
    .split(/[\s,;]+/)
    .map(value => parseFloat(value.replace(",", ".")))
    .filter(value => Number.isFinite(value) && value >= 1);
}

/* =========================
   MÉDIANE
========================= */

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const n = sorted.length;

  if (n === 0) return 0;

  if (n % 2 === 1) {
    return sorted[Math.floor(n / 2)];
  }

  return (sorted[n / 2 - 1] + sorted[n / 2]) / 2;
}

/* =========================
   ÉCART-TYPE
========================= */

function standardDeviation(values) {
  if (values.length === 0) return 0;

  const average =
    values.reduce((sum, value) => sum + value, 0) /
    values.length;

  const variance =
    values.reduce(
      (sum, value) => sum + Math.pow(value - average, 2),
      0
    ) / values.length;

  return Math.sqrt(variance);
}

/* =========================
   NOTE DE FIABILITÉ
========================= */

function reliability(values) {
  if (values.length < 5) {
    return 1;
  }

  let score = 1;

  if (values.length >= 8) score++;
  if (values.length >= 15) score++;
  if (values.length >= 25) score++;

  const recent = values.slice(-10);
  const deviation = standardDeviation(recent);

  if (deviation < 1.25) {
    score++;
  }

  return Math.min(5, score);
}

/* =========================
   ANALYSE
========================= */

function analyze() {
  const values = getRounds();

  if (values.length === 0) {
    $("message").textContent =
      "Entre des multiplicateurs valides.";

    return;
  }

  const recent = values.slice(-20);

  const average =
    recent.reduce((sum, value) => sum + value, 0) /
    recent.length;

  const med = median(recent);

  const stars = reliability(values);

  /*
    Cette estimation est uniquement statistique
    et expérimentale. Elle ne garantit pas le
    résultat de la prochaine manche.
  */

  const estimate = Math.max(
    1.10,
    Math.min(
      4.99,
      med * (0.85 + stars * 0.03)
    )
  );

  $("estimate").textContent =
    estimate.toFixed(2) + "x";

  $("stars").textContent =
    "★".repeat(stars) +
    "☆".repeat(5 - stars);

  $("confidence").textContent =
    `Fiabilité ${stars} / 5`;

  $("roundCount").textContent =
    values.length;

  $("avg").textContent =
    average.toFixed(2) + "x";

  $("median").textContent =
    med.toFixed(2) + "x";

  const above2 =
    values.filter(value => value >= 2).length;

  const below2 =
    values.filter(value => value < 2).length;

  $("over2").textContent =
    Math.round((above2 / values.length) * 100) + "%";
}
