const API = "https://mp3quran.net/api/v3";

const reciterSelect = document.getElementById("reciter");
const surahSelect = document.getElementById("surah");
const audio = document.getElementById("audio");
const title = document.getElementById("title");
const playButton = document.getElementById("play");
const downloadButton = document.getElementById("download");
const status = document.getElementById("status");
const downloadList = document.getElementById("downloadList");

let reciters = [];
let surahs = [];
let selectedReciter = null;
let selectedSurah = null;
let currentURL = "";

/* القراء الذين طلبتهم */
const wantedReciters = [
    "عبد الباسط عبد الصمد",
    "عبد الرحمن السديس",
    "ماهر المعيقلي",
    "سعد الغامدي",
    "مشاري العفاسي",
    "ياسر الدوسري",
    "محمد صديق المنشاوي",
    "محمود خليل الحصري",
    "مصطفى إسماعيل",
    "محمود علي البنا",
    "سعود الشريم",
    "فارس عباد",
    "أحمد العجمي",
    "أبو بكر الشاطري",
    "علي جابر"
];

/* =========================
   تحميل السور
========================= */

async function loadSurahs() {

    try {

        status.textContent = "جاري تحميل السور...";

        const response = await fetch(
            `${API}/suwar?language=ar`
        );

        if (!response.ok) {
            throw new Error("Surahs API error");
        }

        const data = await response.json();

        surahs = data.suwar || [];

        surahSelect.innerHTML =
            `<option value="">اختر السورة</option>`;

        surahs.forEach((surah, index) => {

            const option =
                document.createElement("option");

            option.value = index + 1;

            option.textContent =
                `${index + 1} - ${surah.name}`;

            surahSelect.appendChild(option);
        });

    } catch (error) {

        console.error(error);

        surahSelect.innerHTML =
            `<option value="">فشل تحميل السور</option>`;

        status.textContent =
            "تأكد من اتصال الإنترنت.";
    }
}


/* =========================
   تحميل القراء
========================= */

async function loadReciters() {

    try {

        status.textContent = "جاري تحميل القراء...";

        const response = await fetch(
            `${API}/reciters?language=ar`
        );

        if (!response.ok) {
            throw new Error("Reciters API error");
        }

        const data = await response.json();

        reciters = data.reciters || [];

        console.log("عدد القراء:", reciters.length);

        reciterSelect.innerHTML =
            `<option value="">اختر القارئ</option>`;

        /*
         * البحث بطريقة أكثر مرونة
         */

        wantedReciters.forEach(wantedName => {

            const found = findReciter(wantedName);

            if (found) {

                const option =
                    document.createElement("option");

                option.value = found.id;

                option.textContent = wantedName;

                reciterSelect.appendChild(option);

            } else {

                console.log(
                    "لم يتم العثور على:",
                    wantedName
                );
            }

        });

        /*
         * إذا لم يظهر أي قارئ،
         * نعرض جميع القراء الموجودين في API
         */

        if (reciterSelect.options.length === 1) {

            reciters.forEach(reciter => {

                if (
                    !reciter.moshaf ||
                    !reciter.moshaf.length
                ) {
                    return;
                }

                const option =
                    document.createElement("option");

                option.value = reciter.id;

                option.textContent =
                    reciter.name;

                reciterSelect.appendChild(option);
            });
        }

        if (reciterSelect.options.length > 1) {

            status.textContent =
                "اختر القارئ والسورة.";

        } else {

            status.textContent =
                "لم يتم تحميل القراء.";
        }

    } catch (error) {

        console.error(error);

        reciterSelect.innerHTML = `
            <option value="">
                فشل تحميل القراء
            </option>
        `;

        status.textContent =
            "تعذر الاتصال بخادم القراء.";
    }
}


/* =========================
   البحث عن القارئ
========================= */

function findReciter(name) {

    const wanted = normalize(name);

    /*
     * مطابقة كاملة
     */

    let result =
        reciters.find(
            r =>
                normalize(r.name) === wanted
        );

    if (result) {
        return result;
    }

    /*
     * مطابقة جزئية
     */

    result =
        reciters.find(
            r =>
                normalize(r.name).includes(wanted) ||
                wanted.includes(normalize(r.name))
        );

    if (result) {
        return result;
    }

    /*
     * كلمات مميزة لكل قارئ
     */

    const keywords = {

        "عبد الباسط عبد الصمد":
            ["عبدالباسط", "عبد الباسط", "basit"],

        "عبد الرحمن السديس":
            ["السديس", "sudais"],

        "ماهر المعيقلي":
            ["المعيقلي", "maher"],

        "سعد الغامدي":
            ["الغامدي", "ghamdi"],

        "مشاري العفاسي":
            ["العفاسي", "afasy"],

        "ياسر الدوسري":
            ["الدوسري", "yasir"],

        "محمد صديق المنشاوي":
            ["المنشاوي", "minshawi"],

        "محمود خليل الحصري":
            ["الحصري", "husary"],

        "مصطفى إسماعيل":
            ["مصطفى إسماعيل", "mustafa"],

        "محمود علي البنا":
            ["البنا", "banna"],

        "سعود الشريم":
            ["الشريم", "shuraim"],

        "فارس عباد":
            ["فارس عباد", "faris"],

        "أحمد العجمي":
            ["العجمي", "ajmi"],

        "أبو بكر الشاطري":
            ["الشاطري", "shatri"],

        "علي جابر":
            ["علي جابر", "ali jaber"]
    };

    const list =
        keywords[name] || [];

    return reciters.find(r => {

        const apiName =
            normalize(r.name);

        return list.some(keyword =>
            apiName.includes(
                normalize(keyword)
            )
        );
    });
}


/* =========================
   تنظيف النص
========================= */

function normalize(text) {

    return String(text || "")
        .toLowerCase()
        .replace(/[ًٌٍَُِّْـ]/g, "")
        .replace(/[أإآ]/g, "ا")
        .replace(/ى/g, "ي")
        .replace(/ة/g, "ه")
        .replace(/\s+/g, "")
        .trim();
}


/* =========================
   اختيار القارئ
========================= */

reciterSelect.addEventListener(
    "change",
    () => {

        const id =
            Number(reciterSelect.value);

        selectedReciter =
            reciters.find(
                r => r.id === id
            );

        updatePlayer();
    }
);


/* =========================
   اختيار السورة
========================= */

surahSelect.addEventListener(
    "change",
    () => {

        const number =
            Number(surahSelect.value);

        selectedSurah =
            surahs[number - 1];

        updatePlayer();
    }
);


/* =========================
   تجهيز رابط الصوت
========================= */

function updatePlayer() {

    if (
        !selectedReciter ||
        !selectedSurah
    ) {
        return;
    }

    const moshaf =
        selectedReciter.moshaf?.find(
            m => m.server
        );

    if (!moshaf) {

        status.textContent =
            "لا يوجد تسجيل متاح لهذا القارئ.";

        return;
    }

    const number =
        String(
            Number(surahSelect.value)
        ).padStart(3, "0");

    currentURL =
        moshaf.server +
        number +
        ".mp3";

    title.textContent =
        `${selectedSurah.name} — ${selectedReciter.name}`;

    audio.src =
        currentURL;

    status.textContent =
        "جاهز للتشغيل.";
}


/* =========================
   تشغيل
========================= */

playButton.addEventListener(
    "click",
    async () => {

        if (!currentURL) {

            status.textContent =
                "اختر القارئ والسورة أولاً.";

            return;
        }

        try {

            if (audio.paused) {

                await audio.play();

            } else {

                audio.pause();
            }

        } catch (error) {

            console.error(error);

            status.textContent =
                "تعذر تشغيل الصوت.";
        }
    }
);


audio.addEventListener(
    "play",
    () => {

        playButton.textContent =
            "⏸ إيقاف";
    }
);


audio.addEventListener(
    "pause",
    () => {

        playButton.textContent =
            "▶️ تشغيل";
    }
);


/* =========================
   تنزيل
========================= */

downloadButton.addEventListener(
    "click",
    async () => {

        if (!currentURL) {

            status.textContent =
                "اختر القارئ والسورة أولاً.";

            return;
        }

        try {

            status.textContent =
                "⬇️ جاري تنزيل السورة...";

            downloadButton.disabled =
                true;

            const response =
                await fetch(currentURL);

            if (!response.ok) {
                throw new Error(
                    "Download error"
                );
            }

            const blob =
                await response.blob();

            const localURL =
                URL.createObjectURL(blob);

            const downloads =
                JSON.parse(
                    localStorage.getItem(
                        "quranDownloads"
                    ) || "[]"
                );

            const item = {

                id: Date.now(),

                surah:
                    selectedSurah.name,

                reciter:
                    selectedReciter.name,

                url:
                    currentURL,

                localURL:
                    localURL
            };

            downloads.push(item);

            localStorage.setItem(
                "quranDownloads",
                JSON.stringify(
                    downloads
                )
            );

            const link =
                document.createElement("a");

            link.href = localURL;

            link.download =
                `${selectedSurah.name} - ${selectedReciter.name}.mp3`;

            document.body.appendChild(link);

            link.click();

            link.remove();

            status.textContent =
                "✅ تم تنزيل السورة.";

            showDownloads();

        } catch (error) {

            console.error(error);

            status.textContent =
                "❌ فشل التنزيل.";
        }

        downloadButton.disabled =
            false;
    }
);


/* =========================
   التنزيلات
========================= */

function showDownloads() {

    const downloads =
        JSON.parse(
            localStorage.getItem(
                "quranDownloads"
            ) || "[]"
        );

    if (!downloads.length) {

        downloadList.innerHTML =
            "لا توجد سور تم تنزيلها.";

        return;
    }

    downloadList.innerHTML = "";

    downloads.forEach(item => {

        const div =
            document.createElement("div");

        div.className =
            "download-item";

        div.innerHTML = `

            <div class="download-info">

                <strong>
                    ${item.surah}
                </strong>

                <small>
                    ${item.reciter}
                </small>

            </div>

            <button class="playSaved">
                ▶️
            </button>

            <button class="delete">
                🗑️
            </button>
        `;

        div.querySelector(
            ".playSaved"
        ).onclick = () => {

            audio.src =
                item.localURL;

            title.textContent =
                `${item.surah} — ${item.reciter}`;

            audio.play();
        };

        div.querySelector(
            ".delete"
        ).onclick = () => {

            const list =
                JSON.parse(
                    localStorage.getItem(
                        "quranDownloads"
                    ) || "[]"
                );

            const newList =
                list.filter(
                    x =>
                    x.id !== item.id
                );

            localStorage.setItem(
                "quranDownloads",
                JSON.stringify(
                    newList
                )
            );

            showDownloads();
        };

        downloadList.appendChild(div);
    });
}


/* =========================
   تشغيل التطبيق
========================= */

async function start() {

    await loadSurahs();

    await loadReciters();

    showDownloads();
}

start();