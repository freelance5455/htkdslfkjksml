const $=id=>document.getElementById(id);
let stream=null, recorder=null, chunks=[], lastPhotoBlob=null, lastVideoBlob=null;
let currentFilter="none";

async function startCamera(){
  try{
    stream=await navigator.mediaDevices.getUserMedia({
      video:{facingMode:{ideal:"environment"},width:{ideal:3840},height:{ideal:2160}},
      audio:true
    });
    $("preview").srcObject=stream;
    $("videoHint").style.display="none";
  }catch(e){
    $("videoHint").textContent="تعذر تشغيل الكاميرا: "+e.message;
  }
}
$("startCamera").onclick=startCamera;

document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>{
  currentFilter=b.dataset.filter;
  $("preview").style.filter=currentFilter==="none"?"none":currentFilter;
});

$("capture").onclick=()=>{
  if(!stream){alert("شغل الكاميرا أولاً");return}
  const v=$("preview"), c=$("canvas");
  c.width=v.videoWidth||1280; c.height=v.videoHeight||720;
  const ctx=c.getContext("2d");
  ctx.filter=currentFilter==="none"?"none":currentFilter;
  ctx.drawImage(v,0,0,c.width,c.height);
  c.toBlob(blob=>{
    lastPhotoBlob=blob;
    showPhoto(blob,c.width,c.height);
  },"image/jpeg",.95);
};

function showPhoto(blob,w,h){
  $("photoResult").src=URL.createObjectURL(blob);
  $("photoResult").hidden=false;
  $("videoResult").hidden=true;
  $("downloadPhoto").disabled=false;
  $("downloadVideo").disabled=true;
  $("details").innerHTML=`النوع: صورة<br>الدقة: ${w} × ${h}<br>الحجم: ${formatBytes(blob.size)}<br>الصيغة: JPEG<br>التاريخ: ${new Date().toLocaleString("ar-IQ")}`;
}

$("record").onclick=()=>{
  if(!stream){alert("شغل الكاميرا أولاً");return}
  chunks=[];
  const mime=MediaRecorder.isTypeSupported("video/webm;codecs=vp9")?"video/webm;codecs=vp9":"video/webm";
  recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:12000000});
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  recorder.onstop=()=>{
    lastVideoBlob=new Blob(chunks,{type:recorder.mimeType});
    const url=URL.createObjectURL(lastVideoBlob);
    $("videoResult").src=url;$("videoResult").hidden=false;
    $("photoResult").hidden=true;
    $("downloadVideo").disabled=false;$("downloadPhoto").disabled=true;
    const v=$("preview");
    $("details").innerHTML=`النوع: فيديو<br>دقة المصدر: ${(v.videoWidth||0)} × ${(v.videoHeight||0)}<br>الحجم: ${formatBytes(lastVideoBlob.size)}<br>الصيغة: ${recorder.mimeType}<br>المدة: بعد الإيقاف يمكنك تشغيل الفيديو ومعرفة المدة.`;
  };
  recorder.start(1000);
  $("record").disabled=true;$("stopRecord").disabled=false;
};
$("stopRecord").onclick=()=>{if(recorder&&recorder.state!=="inactive")recorder.stop();$("record").disabled=false;$("stopRecord").disabled=true};

document.querySelectorAll("[data-photo-size]").forEach(b=>b.onclick=async()=>{
  if(!lastPhotoBlob){alert("التقط صورة أولاً");return}
  const sizes={hd:[1280,720],"4k":[3840,2160],"8k":[7680,4320]};
  const [w,h]=sizes[b.dataset.photoSize];
  const img=new Image();img.onload=()=>{
    const c=document.createElement("canvas");c.width=w;c.height=h;
    const ctx=c.getContext("2d");ctx.filter=currentFilter==="none"?"none":currentFilter;
    ctx.drawImage(img,0,0,w,h);
    c.toBlob(blob=>{lastPhotoBlob=blob;showPhoto(blob,w,h)},"image/jpeg",.95);
  };img.src=URL.createObjectURL(lastPhotoBlob);
});

document.querySelectorAll("[data-video-size]").forEach(b=>b.onclick=()=>{
  if(!lastVideoBlob){alert("سجل فيديو أولاً");return}
  alert("تم اختيار "+b.textContent+". تحويل الفيديو الحقيقي إلى 4K/16K يحتاج ترميز فيديو أصلي مثل FFmpeg أو محرك معالجة مدمج؛ نسخة HTML وحدها لا تستطيع إنتاج ترميز 16K حقيقي بكفاءة.");
});

$("aiEnhance").onclick=()=>{
  if(!lastPhotoBlob){alert("التقط صورة أولاً");return}
  const img=new Image();img.onload=()=>{
    const c=document.createElement("canvas");c.width=img.naturalWidth;c.height=img.naturalHeight;
    const ctx=c.getContext("2d");
    ctx.filter="contrast(1.12) brightness(1.05) saturate(1.08)";
    ctx.drawImage(img,0,0);
    c.toBlob(blob=>{lastPhotoBlob=blob;showPhoto(blob,c.width,c.height)},"image/jpeg",.97);
  };img.src=URL.createObjectURL(lastPhotoBlob);
};

function download(blob,name){const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click()}
$("downloadPhoto").onclick=()=>download(lastPhotoBlob,"AI_Camera_photo.jpg");
$("downloadVideo").onclick=()=>download(lastVideoBlob,"AI_Camera_video.webm");
function formatBytes(n){if(!n)return"0 B";const u=["B","KB","MB","GB"];let i=0;while(n>=1024&&i<3){n/=1024;i++}return n.toFixed(2)+" "+u[i]}

$("infoBtn").onclick=()=>$("modal").hidden=false;
$("closeModal").onclick=()=>$("modal").hidden=true;
$("modal").onclick=e=>{if(e.target===$("modal"))$("modal").hidden=true};
