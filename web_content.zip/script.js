// ============================================================
// Quran App - script.js
// نسخة كاملة متوافقة مع توقيتات جميع السور
// ============================================================


// ============================================================
// المتغيرات
// ============================================================

const homeScreen = document.getElementById("homeScreen");
const quranScreen = document.getElementById("quranScreen");

const startReading = document.getElementById("startReading");
const backButton = document.getElementById("backButton");

const playButton = document.getElementById("playButton");
const quranAudio = document.getElementById("quranAudio");

const previousPage = document.getElementById("previousPage");
const nextPage = document.getElementById("nextPage");
const pageNumber = document.getElementById("pageNumber");

const pageInput = document.getElementById("pageInput");
const goToPage = document.getElementById("goToPage");

const surahButton = document.getElementById("surahButton");
const surahList = document.getElementById("surahList");

const surahSelect = document.getElementById("surahSelect");

const quranText = document.querySelector(".quran-text");
const surahTitle = document.querySelector(".surah-title");
const headerTitle = document.querySelector(".quran-header h2");


let currentPage = 1;
let currentSurah = 1;

/*
 * آخر آية (سورة + رقم آية) موجودة في الصفحة المعروضة حاليًا
 * تُستخدم لمعرفة متى يتجاوز القارئ نهاية الصفحة
 * حتى ننتقل تلقائيًا للصفحة التالية دون إيقاف الصوت
 */
let pageLastAyah = null;

/*
 * حماية من تكرار الانتقال التلقائي أكثر من مرة
 * أثناء تحميل الصفحة التالية
 */
let isAutoAdvancingPage = false;

let wordTimings = [];

let audioSurah = 0;

let renderToken = 0;


// ============================================================
// أسماء السور
// ============================================================

const surahNames = [

    "الفاتحة",
    "البقرة",
    "آل عمران",
    "النساء",
    "المائدة",
    "الأنعام",
    "الأعراف",
    "الأنفال",
    "التوبة",
    "يونس",

    "هود",
    "يوسف",
    "الرعد",
    "إبراهيم",
    "الحجر",
    "النحل",
    "الإسراء",
    "الكهف",
    "مريم",
    "طه",

    "الأنبياء",
    "الحج",
    "المؤمنون",
    "النور",
    "الفرقان",
    "الشعراء",
    "النمل",
    "القصص",
    "العنكبوت",
    "الروم",

    "لقمان",
    "السجدة",
    "الأحزاب",
    "سبأ",
    "فاطر",
    "يس",
    "الصافات",
    "ص",
    "الزمر",
    "غافر",

    "فصلت",
    "الشورى",
    "الزخرف",
    "الدخان",
    "الجاثية",
    "الأحقاف",
    "محمد",
    "الفتح",
    "الحجرات",
    "ق",

    "الذاريات",
    "الطور",
    "النجم",
    "القمر",
    "الرحمن",
    "الواقعة",
    "الحديد",
    "المجادلة",
    "الحشر",
    "الممتحنة",

    "الصف",
    "الجمعة",
    "المنافقون",
    "التغابن",
    "الطلاق",
    "التحريم",
    "الملك",
    "القلم",
    "الحاقة",
    "المعارج",

    "نوح",
    "الجن",
    "المزمل",
    "المدثر",
    "القيامة",
    "الإنسان",
    "المرسلات",
    "النبأ",
    "النازعات",
    "عبس",

    "التكوير",
    "الانفطار",
    "المطففين",
    "الانشقاق",
    "البروج",
    "الطارق",
    "الأعلى",
    "الغاشية",
    "الفجر",
    "البلد",

    "الشمس",
    "الليل",
    "الضحى",
    "الشرح",
    "التين",
    "العلق",
    "القدر",
    "البينة",
    "الزلزلة",
    "العاديات",

    "القارعة",
    "التكاثر",
    "العصر",
    "الهمزة",
    "الفيل",
    "قريش",
    "الماعون",
    "الكوثر",
    "الكافرون",
    "النصر",

    "المسد",
    "الإخلاص",
    "الفلق",
    "الناس"

];


// ============================================================
// تحويل الأرقام إلى عربية
// ============================================================

function arabicNumber(number) {

    return String(number).replace(
        /\d/g,
        d => "٠١٢٣٤٥٦٧٨٩"[d]
    );

}


// ============================================================
// إزالة التظليل
// ============================================================

function clearHighlight() {

    document
        .querySelectorAll(
            ".quran-text .quran-word.active"
        )
        .forEach(word => {

            word.classList.remove("active");

        });

}


// ============================================================
// الحصول على كائن التوقيتات
// ============================================================

function getTimingsObject() {

    /*
     * الخيار الأول:
     * segmentsData
     */

    if (
        typeof window !== "undefined" &&
        window.segmentsData
    ) {

        return window.segmentsData;

    }


    if (
        typeof segmentsData !== "undefined"
    ) {

        return segmentsData;

    }


    /*
     * الخيار الثاني:
     * QuranTimings
     */

    if (
        typeof window !== "undefined" &&
        window.QuranTimings
    ) {

        return window.QuranTimings;

    }


    if (
        typeof quranTimings !== "undefined"
    ) {

        return quranTimings;

    }


    /*
     * الخيار الثالث:
     * timings
     *
     * هذا مهم جدًا لأن ملف timings(4).js
     * عندك يستخدم:
     *
     * const timings = {...}
     */

    if (
        typeof window !== "undefined" &&
        window.timings
    ) {

        return window.timings;

    }


    if (
        typeof timings !== "undefined"
    ) {

        return timings;

    }


    return null;

}


// ============================================================
// الحصول على بيانات السور
// ============================================================

function getSurahDataObject() {

    if (
        typeof window !== "undefined" &&
        window.surahData
    ) {

        return window.surahData;

    }


    if (
        typeof surahData !== "undefined"
    ) {

        return surahData;

    }


    return null;

}


// ============================================================
// تحميل جميع توقيتات السورة
// ============================================================

function loadAllSurahTimings(surahNumber) {

    wordTimings = [];


    const timings =
        getTimingsObject();


    if (!timings) {

        console.error(
            "❌ لم يتم العثور على ملف التوقيتات."
        );

        return;

    }


    const wantedSurah =
        Number(surahNumber);


    Object.keys(timings).forEach(key => {

        const parts =
            String(key).split(":");


        if (
            parts.length !== 2
        ) {

            return;

        }


        const surah =
            Number(parts[0]);


        const ayah =
            Number(parts[1]);


        if (
            surah !== wantedSurah
        ) {

            return;

        }


        const data =
            timings[key];


        if (!data) {

            return;

        }


        /*
         * التوقيتات يمكن أن تكون:
         *
         * "1:1": {
         *     segments: [...]
         * }
         *
         * أو:
         *
         * "1:1": [...]
         */

        const segments =
            Array.isArray(data.segments)
                ? data.segments
                : Array.isArray(data)
                    ? data
                    : null;


        if (!segments) {

            return;

        }


        segments.forEach(segment => {

            if (
                !Array.isArray(segment) ||
                segment.length < 3
            ) {

                return;

            }


            const start =
                Number(segment[1]);


            const end =
                Number(segment[2]);


            if (
                !Number.isFinite(start) ||
                !Number.isFinite(end)
            ) {

                return;

            }


            wordTimings.push({

                surah: surah,

                ayah: ayah,

                wordIndex:
                    Number(segment[0]),

                start:
                    start / 1000,

                end:
                    end / 1000

            });

        });

    });


    /*
     * ترتيب التوقيتات حسب وقت البداية
     */

    wordTimings.sort(
        (a, b) =>
            a.start - b.start
    );


    console.log(
        "✅ تم تحميل توقيتات السورة:",
        wantedSurah,
        "عدد الكلمات:",
        wordTimings.length
    );

}


// ============================================================
// تغيير الصوت
// ============================================================

function changeAudio(surahNumber) {

    if (!quranAudio) {

        return;

    }


    const number =
        Number(surahNumber);


    /*
     * إيقاف الصوت السابق
     */

    quranAudio.pause();

    quranAudio.currentTime = 0;


    clearHighlight();


    let audioUrl = null;


    /*
     * إذا كان surahData موجودًا
     */

    const data =
        getSurahDataObject();


    if (
        data &&
        data[number] &&
        data[number].audio_url
    ) {

        audioUrl =
            data[number].audio_url;

    }


    /*
     * رابط احتياطي للصوت
     */

    if (!audioUrl) {

        const n =
            String(number).padStart(3, "0");


        audioUrl =
            `https://audio-cdn.tarteel.ai/quran/surah/abuBakrAlShatri/murattal/mp3/${n}.mp3`;

    }


    audioSurah =
        number;


    quranAudio.src =
        audioUrl;


    quranAudio.load();


    if (playButton) {

        playButton.textContent =
            "▶️";

    }


    /*
     * تحميل توقيتات السورة نفسها
     */

    loadAllSurahTimings(number);

}

// ============================================================
// الحصول على رقم الآية داخل السورة
// ============================================================

function getAyahInSurah(ayah) {

    /*
     * API الحديثة
     */

    if (
        ayah.numberInSurah != null
    ) {

        return Number(
            ayah.numberInSurah
        );

    }


    /*
     * احتمال آخر
     */

    if (
        ayah.ayahNumber != null
    ) {

        return Number(
            ayah.ayahNumber
        );

    }


    /*
     * حل أخير
     */

    if (
        ayah.number != null
    ) {

        return Number(
            ayah.number
        );

    }


    return 0;

}


// ============================================================
// عرض الصفحة
// ============================================================

async function showPage(page) {

    page =
        Number(page);


    if (
        !Number.isInteger(page) ||
        page < 1 ||
        page > 604
    ) {

        return;

    }


    if (!quranText) {

        return;

    }


    /*
     * رقم خاص بالتحميل الحالي
     */

    const token =
        ++renderToken;


    currentPage =
        page;


    if (pageNumber) {

        pageNumber.textContent =
            `صفحة ${arabicNumber(page)}`;

    }


    clearHighlight();


    quranText.innerHTML = `

        <div class="ayah">

            <span>
                جاري تحميل الصفحة...
            </span>

        </div>

    `;


    try {

        const data =
            await loadQuranPage(page);


        /*
         * إذا انتقل المستخدم إلى صفحة أخرى
         * أثناء التحميل نتجاهل النتيجة القديمة
         */

        if (
            token !== renderToken
        ) {

            return;

        }


        if (
            !data ||
            !Array.isArray(data.ayahs) ||
            !data.ayahs.length
        ) {

            quranText.innerHTML = `

                <div class="ayah">

                    <span>
                        تعذر تحميل الصفحة
                    </span>

                </div>

            `;

            return;

        }


        renderPage(data);

    } catch (error) {

        console.error(
            "خطأ في تحميل الصفحة:",
            error
        );


        quranText.innerHTML = `

            <div class="ayah">

                <span>
                    تعذر تحميل الصفحة
                </span>

            </div>

        `;

    }

}


// ============================================================
// عرض الآيات والكلمات
// ============================================================

function renderPage(data) {

    let html = "";


    const firstAyah =
        data.ayahs[0];


    /*
     * معرفة رقم السورة
     */

    currentSurah =
        Number(
            firstAyah.surahNumber ||
            (
                firstAyah.surah &&
                firstAyah.surah.number
            ) ||
            1
        );


    /*
     * اسم السورة
     */

    const firstSurahName =

        typeof firstAyah.surah === "string"

            ? firstAyah.surah

            : surahNames[
                currentSurah - 1
            ] || "";


    if (surahTitle) {

        surahTitle.textContent =
            `سورة ${firstSurahName}`;

    }


    if (headerTitle) {

        headerTitle.textContent =
            firstSurahName;

    }


    if (surahSelect) {

        surahSelect.value =
            String(currentSurah);

    }


    /*
     * إنشاء الآيات
     */

    data.ayahs.forEach(ayah => {


        const words =

            String(
                ayah.text || ""
            )

            .trim()

            .split(/\s+/)

            .filter(Boolean);


        /*
         * رقم الآية داخل السورة
         */

        const ayahInSurah =
            getAyahInSurah(ayah);


        html += `

            <div

                class="ayah"

                data-surah-number="${currentSurah}"

                data-ayah-number="${ayahInSurah}"

            >

        `;


        /*
         * إنشاء الكلمات
         */

        words.forEach(
            (word, index) => {


                /*
                 * حماية النص
                 */

                const safeWord =
                    String(word)

                        .replace(
                            /&/g,
                            "&amp;"
                        )

                        .replace(
                            /</g,
                            "&lt;"
                        )

                        .replace(
                            />/g,
                            "&gt;"
                        )

                        .replace(
                            /"/g,
                            "&quot;"
                        );


                html += `

                    <span

                        class="quran-word"

                        data-word-index="${index + 1}"

                    >${safeWord}</span>

                `;

            }
        );


        /*
         * رقم الآية
         */

        html += `

            <span class="ayah-number">

                ${arabicNumber(
                    ayahInSurah
                )}

            </span>

        `;


        html += `

            </div>

        `;

    });


    /*
     * وضع القرآن في الصفحة
     */

    quranText.innerHTML =
        html;


    /*
     * حفظ آخر آية في هذه الصفحة
     * (تُستخدم لاكتشاف نهاية الصفحة أثناء التشغيل)
     */

    const lastAyahOfPage =
        data.ayahs[data.ayahs.length - 1];

    pageLastAyah = {

        surah: Number(
            lastAyahOfPage.surahNumber ||
            currentSurah
        ),

        ayah: getAyahInSurah(
            lastAyahOfPage
        )

    };


    /*
     * تحميل صوت السورة
     *
     * مهم جدًا: لا نعيد تحميل/إيقاف الصوت إلا إذا
     * تغيّرت السورة فعليًا. إذا كانت نفس السورة
     * (مجرد تقليب صفحات داخلها) يجب أن يستمر
     * الصوت في التشغيل من دون انقطاع أو رجوع للبداية.
     */

    if (
        currentSurah !== audioSurah
    ) {

        changeAudio(
            currentSurah
        );

    }

}


// ============================================================
// تحديث تظليل الكلمة
// ============================================================

function updateWordHighlight() {

    if (
        !quranAudio ||
        !wordTimings ||
        wordTimings.length === 0
    ) {

        return;

    }


    /*
     * إزالة التظليل السابق
     */

    clearHighlight();


    const currentTime =
        quranAudio.currentTime;


    /*
     * بحث سريع عن التوقيت
     */

    let low = 0;

    let high =
        wordTimings.length - 1;

    let found = null;


    while (
        low <= high
    ) {

        const mid =
            (low + high) >> 1;


        const item =
            wordTimings[mid];


        if (
            currentTime < item.start
        ) {

            high =
                mid - 1;

        } else if (
            currentTime >= item.end
        ) {

            low =
                mid + 1;

        } else {

            found =
                item;

            break;

        }

    }


    if (!found) {

        return;

    }


    /*
     * ============================================================
     * الانتقال التلقائي للصفحة التالية
     * ============================================================
     *
     * مهم: هذا الفحص يجب أن يتم هنا، قبل البحث عن عنصر الآية
     * في DOM الصفحة الحالية. لأنه عندما يتجاوز القارئ نهاية
     * الصفحة المعروضة، فإن الآية/الكلمة الجديدة غير موجودة
     * إطلاقًا في هذه الصفحة (لم تُعرض بعد)، فلو وضعنا هذا
     * الفحص بعد البحث في DOM لكانت الدالة تتوقف مبكرًا عند
     * "لم يتم إيجاد الآية" قبل أن تصل لكود الانتقال.
     */

    if (
        pageLastAyah &&
        !isAutoAdvancingPage &&
        currentPage < 604
    ) {

        const wentPastPage =
            found.surah > pageLastAyah.surah ||
            (
                found.surah === pageLastAyah.surah &&
                found.ayah > pageLastAyah.ayah
            );


        if (wentPastPage) {

            isAutoAdvancingPage = true;

            showPage(currentPage + 1)
                .catch(() => {})
                .finally(() => {

                    isAutoAdvancingPage = false;

                });


            /*
             * الآية/الكلمة الحالية تخص الصفحة القادمة
             * وليست موجودة بعد في هذه الصفحة، فلا داعي
             * لمتابعة البحث عن عنصرها في DOM الآن
             */

            return;

        }

    }


    /*
     * البحث عن الآية
     *
     * مهم:
     * نستعمل رقم السورة + رقم الآية
     * وليس الرقم العالمي للآية.
     */

    const ayah =
        document.querySelector(

            `.quran-text .ayah[data-surah-number="${found.surah}"][data-ayah-number="${found.ayah}"]`

        );


    if (!ayah) {

        return;

    }


    /*
     * البحث عن الكلمة
     */

    const word =
        ayah.querySelector(

            `.quran-word[data-word-index="${found.wordIndex}"]`

        );


    if (!word) {

        return;

    }


    /*
     * إظهار الخط الأزرق
     */

    word.classList.add(
        "active"
    );

}


// ============================================================
// أحداث الصوت
// ============================================================

if (quranAudio) {

    quranAudio.addEventListener(
        "timeupdate",
        updateWordHighlight
    );


    quranAudio.addEventListener(
        "ended",
        () => {

            if (playButton) {

                playButton.textContent =
                    "▶️";

            }


            clearHighlight();

        }
    );

}


// ============================================================
// الصفحة السابقة
// ============================================================

if (previousPage) {

    previousPage.addEventListener(
        "click",
        () => {

            if (
                currentPage > 1
            ) {

                showPage(
                    currentPage - 1
                );

            }

        }
    );

}


// ============================================================
// الصفحة التالية
// ============================================================

if (nextPage) {

    nextPage.addEventListener(
        "click",
        () => {

            if (
                currentPage < 604
            ) {

                showPage(
                    currentPage + 1
                );

            }

        }
    );

}


// ============================================================
// الانتقال إلى صفحة
// ============================================================

if (
    goToPage &&
    pageInput
) {

    goToPage.addEventListener(
        "click",
        () => {

            const page =
                Number(
                    pageInput.value
                );


            if (
                page >= 1 &&
                page <= 604
            ) {

                showPage(page);

                pageInput.value =
                    "";

            } else {

                alert(
                    "اكتب رقم صفحة من 1 إلى 604"
                );

            }

        }
    );


    pageInput.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Enter"
            ) {

                goToPage.click();

            }

        }
    );

}


// ============================================================
// بدء القراءة
// ============================================================

if (startReading) {

    startReading.addEventListener(
        "click",
        () => {

            if (homeScreen) {

                homeScreen.style.display =
                    "none";

            }


            if (quranScreen) {

                quranScreen.style.display =
                    "block";

            }


            showPage(
                currentPage
            );

        }
    );

}


// ============================================================
// الرجوع
// ============================================================

if (backButton) {

    backButton.addEventListener(
        "click",
        () => {

            if (quranAudio) {

                quranAudio.pause();

                quranAudio.currentTime =
                    0;

            }


            if (playButton) {

                playButton.textContent =
                    "▶️";

            }


            clearHighlight();


            if (quranScreen) {

                quranScreen.style.display =
                    "none";

            }


            if (homeScreen) {

                homeScreen.style.display =
                    "flex";

            }

        }
    );

}


// ============================================================
// تشغيل وإيقاف الصوت
// =========================

if (
    playButton &&
    quranAudio
) {

    playButton.addEventListener(
        "click",
        async () => {

            try {

                if (
                    quranAudio.paused
                ) {

                    await quranAudio.play();


                    playButton.textContent =
                        "⏸️";

                } else {

                    quranAudio.pause();


                    playButton.textContent =
                        "▶️";

                }

            } catch (error) {

                console.error(
                    "خطأ تشغيل الصوت:",
                    error
                );


                alert(
                    "تعذر تشغيل الصوت. تأكد من اتصال الإنترنت."
                );

            }

        }
    );

}


// ============================================================
// فتح سورة
// ============================================================

function openSurah(surahNumber) {

    const number =
        Number(surahNumber);


    const name =
        surahNames[number - 1];


    if (!name) {

        return;

    }


    if (surahList) {

        surahList.innerHTML =
            "";

    }


    if (quranText) {

        quranText.innerHTML = `

            <div class="ayah">

                <span>
                    جاري فتح سورة ${name}...
                </span>

            </div>

        `;

    }


    /*
     * الحصول على صفحة بداية السورة
     */

    Promise
        .resolve(
            getSurahStartPage(number)
        )

        .then(
            startPage => {


                if (!startPage) {

                    if (quranText) {

                        quranText.innerHTML = `

                            <div class="ayah">

                                <span>
                                    تعذر فتح السورة
                                </span>

                            </div>

                        `;

                    }

                    return;

                }


                currentSurah =
                    number;


                showPage(
                    startPage
                );

            }
        )

        .catch(
            error => {

                console.error(
                    error
                );


                if (quranText) {

                    quranText.innerHTML = `

                        <div class="ayah">

                            <span>
                                تعذر فتح السورة
                            </span>

                        </div>

                    `;

                }

            }
        );

}


// ============================================================
// قائمة السور
// ============================================================

if (
    surahButton &&
    surahList
) {

    surahButton.addEventListener(
        "click",
        () => {


            if (
                surahList.innerHTML.trim()
                !== ""
            ) {

                surahList.innerHTML =
                    "";

                return;

            }


            surahNames.forEach(
                (name, index) => {


                    const button =
                        document.createElement(
                            "button"
                        );


                    const number =
                        index + 1;


                    button.textContent =
                        `${number} - سورة ${name}`;


                    button.addEventListener(
                        "click",
                        () => {

                            openSurah(
                                number
                            );

                        }
                    );


                    surahList.appendChild(
                        button
                    );

                }
            );

        }
    );

}


// ============================================================
// القائمة العلوية للسور
// ============================================================

if (surahSelect) {


    /*
     * لا نكرر الخيارات
     * إذا كانت موجودة أصلًا
     */

    if (
        surahSelect.options.length === 1
    ) {

        surahNames.forEach(
            (name, index) => {


                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    String(
                        index + 1
                    );


                option.textContent =
                    `${index + 1} - ${name}`;


                surahSelect.appendChild(
                    option
                );

            }
        );

    }


    surahSelect.addEventListener(
        "change",
        () => {


            const number =
                Number(
                    surahSelect.value
                );


            if (number) {

                openSurah(
                    number
                );

            }

        }
    );

}


// ============================================================
// بداية التطبيق
// ============================================================

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        () => {

            showPage(1);

        },
        {
            once: true
        }
    );

} else {

    showPage(1);

}