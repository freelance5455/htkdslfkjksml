// ==================================
// MB LUDO - COMPLETE GAME SCRIPT
// ==================================

let player = {
    name: "",
    country: "",
    uid: "1000001"
};

let soundOn = true;
let totalCoins = 1000;

let game = {
    players: [],
    currentPlayer: 0,
    dice: 0,
    hasRolled: false,
    winner: null
};

const colors = [
    { name: "RED", color: "#e83d45" },
    { name: "GREEN", color: "#20a85b" },
    { name: "YELLOW", color: "#e5bd22" },
    { name: "BLUE", color: "#287ce0" }
];

let audioContext = null;

// ==================================
// SCREEN SYSTEM
// ==================================

function showScreen(screenId) {
    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.remove("active");
    });

    const target = document.getElementById(screenId);

    if (target) {
        target.classList.add("active");
    }
}

// ==================================
// INTRO
// ==================================

window.addEventListener("load", function () {
    setTimeout(() => {
        const savedName = localStorage.getItem("mbLudoName");
        const savedCountry = localStorage.getItem("mbLudoCountry");

        if (savedName && savedCountry) {
            player.name = savedName;
            player.country = savedCountry;

            updateProfile();
            showScreen("lobbyScreen");
        } else {
            showScreen("nameScreen");
        }
    }, 4000);
});

// ==================================
// PROFILE
// ==================================

function saveProfile() {
    const nameInput = document.getElementById("playerName");
    const countryInput = document.getElementById("playerCountry");

    const name = nameInput.value.trim();
    const country = countryInput.value;

    if (name.length < 3) {
        alert("Name kam az kam 3 letters ka hona chahiye!");
        return;
    }

    if (!country) {
        alert("Apna country select karo!");
        return;
    }

    player.name = name;
    player.country = country;

    if (!localStorage.getItem("mbLudoUID")) {
        localStorage.setItem("mbLudoUID", "1000001");
    }

    player.uid = localStorage.getItem("mbLudoUID");

    localStorage.setItem("mbLudoName", name);
    localStorage.setItem("mbLudoCountry", country);

    localStorage.setItem("mbLudoNameChangeUsed", "false");

    updateProfile();
    showScreen("lobbyScreen");
    playSound(700);
}
function updateProfile() {
    const lobbyName = document.getElementById("lobbyName");
    const profileName = document.getElementById("profileName");
    const profileCountry = document.getElementById("profileCountry");
    const playerUID = document.getElementById("playerUID");
    const coinCount = document.getElementById("coinCount");

    if (lobbyName) lobbyName.textContent = player.name;
    if (profileName) profileName.textContent = player.name;
    if (profileCountry) profileCountry.textContent = player.country;
    if (playerUID) playerUID.textContent = player.uid;
    if (coinCount) coinCount.textContent = totalCoins;
}

function openProfile() {
    updateProfile();
    showScreen("profileScreen");
}

function changeName() {
    const used = localStorage.getItem("mbLudoNameChangeUsed");

    if (used === "true") {
        alert("Free name change already use ho chuka hai!");
        return;
    }

    const newName = prompt("Apna naya name likho:");

    if (!newName || newName.trim().length < 3) {
        alert("Valid name likho!");
        return;
    }
  player.name = newName.trim();

    localStorage.setItem("mbLudoName", player.name);
    localStorage.setItem("mbLudoNameChangeUsed", "true");

    updateProfile();

    alert("Name successfully change ho gaya!");
}

// ==================================
// LOBBY AND SETTINGS
// ==================================

function openModeScreen() {
    showScreen("modeScreen");
}

function openSettings() {
    showScreen("settingsScreen");
}

function toggleSound() {
    soundOn = !soundOn;

    alert(soundOn ? "Sound ON" : "Sound OFF");

    if (soundOn) {
        playSound(600);
    }
}

// ==================================
// SOUND
// ==================================

function playSound(frequency = 500) {
    if (!soundOn) return;

    try {
        const AudioContextClass =
            window.AudioContext || window.webkitAudioContext;

        if (!AudioContextClass) return;

        if (!audioContext) {
            audioContext = new AudioContextClass();
        }

        if (audioContext.state === "suspended") {
            audioContext.resume();
        }
      const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();

        oscillator.type = "sine";
        oscillator.frequency.value = frequency;

        gain.gain.setValueAtTime(0.12, audioContext.currentTime);
        gain.gain.exponentialRampToValueAtTime(
            0.001,
            audioContext.currentTime + 0.2
        );

        oscillator.connect(gain);
        gain.connect(audioContext.destination);

        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.2);

    } catch (error) {
        console.log("Sound error:", error);
    }
}

// ==================================
// START GAME
// ==================================

function selectMode(numberOfPlayers) {
    game.players = colors.slice(0, numberOfPlayers).map((color, index) => ({
        name: index === 0 ? player.name : color.name + " PLAYER",
        color: color.name,
        hex: color.color,
        position: -1,
        finished: false
    }));

    game.currentPlayer = 0;
    game.dice = 0;
    game.hasRolled = false;
    game.winner = null;

    createBoardTokens();

    document.getElementById("dice").textContent = "🎲";
  document.getElementById("gameMessage").textContent =
        "Roll the dice to start playing!";

    updateTurn();

    showScreen("gameScreen");
}

// ==================================
// TOKEN SETUP
// ==================================

function createBoardTokens() {
    const layer = document.getElementById("tokenLayer");

    layer.innerHTML = "";

    game.players.forEach((p, index) => {
        const token = document.createElement("div");

        token.id = "token-" + index;
        token.textContent = "●";

        token.style.position = "absolute";
        token.style.width = "25px";
        token.style.height = "25px";
        token.style.borderRadius = "50%";
        token.style.background = p.hex;
        token.style.color = "white";
        token.style.border = "3px solid white";
        token.style.boxShadow = "0 3px 8px #0008";
        token.style.display = "grid";
        token.style.placeItems = "center";
        token.style.fontSize = "18px";
        token.style.transition = "all 0.4s ease";

        layer.appendChild(token);

        placeToken(index);
    });
}
// ==================================
// TOKEN MOVEMENT
// ==================================

function placeToken(index) {
    const token = document.getElementById("token-" + index);

    if (!token) return;

    const positions = [
        { x: 17, y: 17 },
        { x: 76, y: 17 },
        { x: 17, y: 76 },
        { x: 76, y: 76 }
    ];

    const position = positions[index];

    if (game.players[index].position === -1) {
        token.style.left = position.x + "%";
        token.style.top = position.y + "%";
        return;
    }

    const step = game.players[index].position;

    const angle = (step / 52) * Math.PI * 2 - Math.PI / 2;

    const x = 50 + Math.cos(angle) * 29;
    const y = 50 + Math.sin(angle) * 29;

    token.style.left = x + "%";
    token.style.top = y + "%";
}

// ==================================
// DICE
// ==================================

function rollDice() {
    if (game.winner !== null) return;

    if (game.hasRolled) {
        document.getElementById("gameMessage").textContent =
            "Pehle apna token move karo!";
        return;
    }

    game.dice = Math.floor(Math.random() * 6) + 1;
    game.hasRolled = true;

    const dice = document.getElementById("dice");

    const diceFaces = [
        "",
        "⚀",
        "⚁",
        "⚂",
        "⚃",
        "⚄",
        "⚅"
    ];
  dice.textContent = diceFaces[game.dice];

    playSound(300 + game.dice * 100);

    const current = game.players[game.currentPlayer];

    document.getElementById("gameMessage").textContent =
        current.name + " got " + game.dice +
        ". Tap your token to move!";

    const token = document.getElementById(
        "token-" + game.currentPlayer
    );

    if (token) {
        token.style.cursor = "pointer";
        token.style.pointerEvents = "auto";
        token.onclick = moveCurrentToken;
    }
}

// ==================================
// MOVE TOKEN
// ==================================

function moveCurrentToken() {
    if (!game.hasRolled || game.winner !== null) return;

    const currentIndex = game.currentPlayer;
    const current = game.players[currentIndex];

    if (current.position === -1) {
        if (game.dice !== 6) {
            document.getElementById("gameMessage").textContent =
                "Token ghar se nikalne ke liye 6 chahiye!";
            return;
        }

        current.position = 0;
    } else {
        current.position += game.dice;
    }
  if (current.position >= 52) {
        current.position = 51;
        current.finished = true;
    }

    const token = document.getElementById("token-" + currentIndex);

    if (token) {
        token.onclick = null;
        token.style.pointerEvents = "none";
    }

    placeToken(currentIndex);

    playSound(800);

    game.hasRolled = false;

    if (current.finished) {
        game.winner = currentIndex;
        showWinner(current);
        return;
    }

    if (game.dice !== 6) {
        game.currentPlayer =
            (game.currentPlayer + 1) % game.players.length;
    }

    document.getElementById("gameMessage").textContent =
        current.name + " moved!";

    updateTurn();
}// ==================================
// TURN
// ==================================

function updateTurn() {
    const current = game.players[game.currentPlayer];

    if (!current) return;

    document.getElementById("turnText").textContent =
        current.color + " PLAYER TURN";

    document.getElementById("gameMessage").textContent =
        current.name + ", roll the dice!";
}

// ==================================
// WINNER
// ==================================

function showWinner(winner) {
    document.getElementById("winnerName").textContent =
        winner.name + " WINS!";

    totalCoins += 100;

    updateProfile();

    playSound(1000);

    showScreen("winnerScreen");
}

// ==================================
// RESTART
// ==================================

function restartGame() {
    if (game.players.length === 0) {
        showScreen("lobbyScreen");
        return;
    }

    const playerCount = game.players.length;

    selectMode(playerCount);
}