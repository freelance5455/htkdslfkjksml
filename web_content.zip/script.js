/* ============================================================
   ADS | Cyber Security — Shared JavaScript (v2, robust)
   ============================================================ */

/* ---------- SAFE STORAGE (in-memory fallback) ---------- */
const _mem = {};
const storage = {
  get(key){
    try{ return localStorage.getItem(key); }
    catch(e){ return _mem[key] ?? null; }
  },
  set(key, val){
    try{ localStorage.setItem(key, val); }
    catch(e){ _mem[key] = val; }
  },
  remove(key){
    try{ localStorage.removeItem(key); }
    catch(e){ delete _mem[key]; }
  }
};

/* ---------- ICON REGISTRY ---------- */
const ICONS = {
  /* Nav */
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  presentation: '<path d="M2 3h20"/><path d="M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"/><path d="m7 21 5-5 5 5"/>',
  layers: '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
  "book-open": '<path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/>',
  "clipboard-check": '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
  "alarm-clock": '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2"/><path d="M5 3 2 6"/><path d="m22 6-3-3"/><path d="M6.38 18.7 4 21"/><path d="M17.64 18.67 20 21"/>',
  "bell-ring": '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/><path d="M4 2C2.8 3.7 2 5.7 2 8"/><path d="M22 8c0-2.3-.8-4.3-2-6"/>',

  /* Stats */
  "book-marked": '<path d="M10 2v8l3-3 3 3V2"/><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
  "calendar-days": '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/>',
  "file-pen": '<path d="M12.5 22H18a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v9.5"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M13.378 15.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"/>',
  library: '<path d="m16 6 4 14"/><path d="M12 6v14"/><path d="M8 8v12"/><path d="M4 4v16"/>',

  /* Home */
  network: '<rect x="16" y="16" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="9" y="2" width="6" height="6" rx="1"/><path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"/><path d="M12 12V8"/>',
  "key-round": '<path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"/><circle cx="16.5" cy="7.5" r=".5" fill="currentColor"/>',
  bug: '<path d="m8 2 1.88 1.88"/><path d="M14.12 3.88 16 2"/><path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"/><path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/><path d="M12 20v-9"/><path d="M6.53 9C4.6 8.8 3 7.1 3 5"/><path d="M6 13H2"/><path d="M3 21c0-2.1 1.7-3.9 3.8-4"/><path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/><path d="M22 13h-4"/><path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/>',
  "calendar-clock": '<path d="M8 2v4"/><path d="M16 2v4"/><path d="M21 14V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"/><path d="M3 10h18"/><circle cx="16" cy="16" r="6"/><path d="M16 14v2l1 1"/>',
  mic: '<path d="M12 19v3"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><rect x="9" y="2" width="6" height="13" rx="3"/>',

  /* Socials */
  facebook: '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
  twitter: '<path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>',
  github: '<path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/>',
  linkedin: '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/>',

  /* Footer contact */
  "at-sign": '<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"/>',
  smartphone: '<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  "map-pin": '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',

  /* Subjects */
  "shield-check": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  key: '<path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4"/><path d="m21 2-9.6 9.6"/><circle cx="7.5" cy="15.5" r="5.5"/>',
  skull: '<path d="M15 22a1 1 0 0 0 1-1v-1a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20v1a1 1 0 0 0 1 1z"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="12" r="1"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  gavel: '<path d="m14.5 12.5-8 8a2.119 2.119 0 1 1-3-3l8-8"/><path d="m16 16 6-6"/><path d="m8 8 6-6"/><path d="m9 7 8 8"/><path d="m21 11-8-8"/>',
  braces: '<path d="M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1"/><path d="M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1"/>',

  /* Books */
  "hard-drive": '<line x1="22" x2="2" y1="12" y2="12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" x2="6.01" y1="16" y2="16"/><line x1="10" x2="10.01" y1="16" y2="16"/>',
  binary: '<rect x="14" y="14" width="4" height="6" rx="2"/><rect x="6" y="4" width="4" height="6" rx="2"/><path d="M6 20h4"/><path d="M14 10h4"/><path d="M6 14h2v6"/><path d="M14 4h2v6"/>',
  "file-key": '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><circle cx="10" cy="16" r="2"/><path d="m16 10-4.5 4.5"/><path d="m15 15 1 1"/>',
  "brick-wall": '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v6"/><path d="M15 3v6"/><path d="M6 9v6"/><path d="M12 9v6"/><path d="M9 15v6"/><path d="M15 15v6"/>',
  "monitor-play": '<path d="M10 7.75a.75.75 0 0 1 1.142-.638l3.664 2.249a.75.75 0 0 1 0 1.278l-3.664 2.25a.75.75 0 0 1-1.142-.64z"/><path d="M12 17v4"/><path d="M8 21h8"/><rect x="2" y="3" width="20" height="14" rx="2"/>',
  "file-calendar": '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/>',

  /* Assignments */
  calculator: '<rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 10h.01"/><path d="M12 14h.01"/><path d="M8 14h.01"/><path d="M12 18h.01"/><path d="M8 18h.01"/>',
  blocks: '<rect width="7" height="7" x="14" y="3" rx="1"/><path d="M10 21V8a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1H3"/>',
  "database-backup": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 12a9 3 0 0 0 5 2.69"/><path d="M21 9.3V5"/><path d="M3 5v14a9 3 0 0 0 6.47 2.88"/><path d="M12 12v4h4"/><path d="M13 20a5 5 0 0 0 9-3 4.5 4.5 0 0 0-4.5-4.5c-1.33 0-2.54.54-3.41 1.41L12 16"/>',
  "scroll-text": '<path d="M15 12h-5"/><path d="M15 8h-5"/><path d="M19 17V5a2 2 0 0 0-2-2H4"/><path d="M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3"/>',

  /* Notifications */
  "calendar-range": '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4"/><path d="M3 10h18"/><path d="M8 2v4"/><path d="M17 14h-6"/><path d="M13 18H7"/><path d="M7 14h.01"/><path d="M17 18h.01"/>',
  timer: '<line x1="10" x2="14" y1="2" y2="2"/><line x1="12" x2="15" y1="14" y2="11"/><circle cx="12" cy="14" r="8"/>',
  podcast: '<path d="M16 17.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z"/><path d="M8 17.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z"/><path d="M12 14a4 4 0 0 0-4 4v2h8v-2a4 4 0 0 0-4-4Z"/><path d="M12 2a6 6 0 0 0-6 6c0 1.887.87 3.565 2.23 4.663"/><path d="M12 2a6 6 0 0 1 6 6c0 1.887-.87 3.565-2.23 4.663"/>',
  "upload-cloud": '<path d="M12 13v8"/><path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="m8 17 4-4 4 4"/>',
  "building-library": '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>',

  /* Reminder */
  hourglass: '<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>',
  "plus-circle": '<circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/>',
  "arrow-right": '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  cog: '<path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z"/><path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/><path d="M12 2v2"/><path d="M12 22v-2"/><path d="m17 20.66-1-1.73"/><path d="M11 10.27 7 3.34"/><path d="m20.66 17-1.73-1"/><path d="m3.34 7 1.73 1"/><path d="M14 12h8"/><path d="M2 12h2"/><path d="m20.66 7-1.73 1"/><path d="m3.34 17 1.73-1"/><path d="m17 3.34-1 1.73"/><path d="m11 13.73-4 6.93"/>',

  /* Lecture icons */
  wifi: '<path d="M12 20h.01"/><path d="M2 8.82a15 15 0 0 1 20 0"/><path d="M5 12.859a10 10 0 0 1 14 0"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  terminal: '<polyline points="4 17 10 11 4 5"/><line x1="12" x2="20" y1="19" y2="19"/>',
  fingerprint: '<path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/><path d="M14 13.12c0 2.38 0 6.38-1 8.88"/><path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"/><path d="M2 12a10 10 0 0 1 18-6"/><path d="M2 16h.01"/><path d="M21.8 16c.2-2 .131-5.354 0-6"/><path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"/><path d="M8.65 22c.21-.66.45-1.32.57-2"/><path d="M9 6.8a6 6 0 0 1 9 5.2v2"/>',
  scale: '<path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/>',
  code: '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
  radar: '<path d="M19.07 4.93A10 10 0 0 0 6.99 3.34"/><path d="M4 6h.01"/><path d="M2.29 9.62A10 10 0 1 0 21.31 8.35"/><path d="M16.24 7.76A6 6 0 1 0 8.23 16.67"/><path d="M12 18h.01"/><path d="M17.99 11.66A6 6 0 0 1 15.77 16.67"/><circle cx="12" cy="12" r="2"/><path d="m13.41 10.59 5.66-5.66"/>',
  "scan-search": '<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/><path d="m16 16-1.9-1.9"/>',
  server: '<rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/>',
  cpu: '<rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2"/><path d="M15 20v2"/><path d="M2 15h2"/><path d="M2 9h2"/><path d="M20 15h2"/><path d="M20 9h2"/><path d="M9 2v2"/><path d="M9 20v2"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  "shield-alert": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
  eye: '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
  zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
  satellite: '<path d="M13 7 9 3 5 7l4 4"/><path d="m17 11 4 4-4 4-4-4"/><path d="m8 12 4 4 6-6-4-4Z"/><path d="m16 8 3-3"/><path d="M9 21a6 6 0 0 0-6-6"/>',
  radio: '<path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"/><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"/><circle cx="12" cy="12" r="2"/><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"/><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19"/>',
  cloud: '<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>'
};

/* ---------- Render SVG icons ---------- */
function renderIcons(){
  document.querySelectorAll('[data-icon]').forEach(el => {
    if(el.dataset.rendered === '1') return;
    const name = el.getAttribute('data-icon');
    const path = ICONS[name];
    if(!path) return;
    el.innerHTML = `<svg viewBox="0 0 24 24">${path}</svg>`;
    el.dataset.rendered = '1';
  });
}

/* ---------- Helpers ---------- */
function escapeHtml(str){
  return String(str).replace(/[&<>"']/g, m => (
    { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[m]
  ));
}
function offsetDate(days){
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
function formatDate(iso){
  const d = new Date(iso + 'T00:00:00');
  if(isNaN(d)) return iso;
  const today = new Date(); today.setHours(0,0,0,0);
  const diff = Math.round((d - today) / 86400000);
  if(diff === 0) return 'Today';
  if(diff === 1) return 'Tomorrow';
  if(diff === -1) return 'Yesterday';
  return d.toLocaleDateString(undefined, { day:'numeric', month:'short', year:'numeric' });
}
function formatTime(t){
  if(!t) return '';
  const [h, m] = t.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hr = h % 12 || 12;
  return `${hr}:${String(m).padStart(2,'0')} ${ampm}`;
}

/* ============================================================
   LECTURES
   ============================================================ */
const LEC_KEY = 'ads_cyber_lectures_v2';
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

const DEFAULT_LECTURES = [
  { id:'l1',  day:'Monday',    subject:'Network Security',      time:'09:00', room:'CS-204', teacher:'Dr. A. Rehman', type:'Core',      icon:'wifi' },
  { id:'l2',  day:'Monday',    subject:'Cryptography',          time:'11:30', room:'CS-108', teacher:'Ms. S. Khan',   type:'Core',      icon:'lock' },
  { id:'l3',  day:'Monday',    subject:'Digital Forensics',     time:'14:00', room:'CS-210', teacher:'Dr. M. Zafar',  type:'Core',      icon:'fingerprint' },
  { id:'l4',  day:'Tuesday',   subject:'Ethical Hacking (Lab)', time:'14:00', room:'Lab 3',  teacher:'Mr. H. Iqbal',  type:'Practical', icon:'terminal' },
  { id:'l5',  day:'Tuesday',   subject:'Secure Software Dev.',  time:'16:00', room:'CS-305', teacher:'Dr. A. Rehman', type:'Core',      icon:'code' },
  { id:'l6',  day:'Wednesday', subject:'Network Security',      time:'09:00', room:'CS-204', teacher:'Dr. A. Rehman', type:'Core',      icon:'network' },
  { id:'l7',  day:'Wednesday', subject:'Cryptography',          time:'11:00', room:'CS-108', teacher:'Ms. S. Khan',   type:'Core',      icon:'key' },
  { id:'l8',  day:'Wednesday', subject:'Cyber Law & Ethics',    time:'13:00', room:'CS-101', teacher:'Ms. N. Fatima', type:'Elective',  icon:'gavel' },
  { id:'l9',  day:'Thursday',  subject:'Digital Forensics',     time:'10:00', room:'CS-210', teacher:'Dr. M. Zafar',  type:'Core',      icon:'search' },
  { id:'l10', day:'Thursday',  subject:'Ethical Hacking (Lab)', time:'14:30', room:'Lab 3',  teacher:'Mr. H. Iqbal',  type:'Practical', icon:'skull' },
  { id:'l11', day:'Friday',    subject:'Network Security',      time:'09:00', room:'CS-204', teacher:'Dr. A. Rehman', type:'Core',      icon:'radar' },
  { id:'l12', day:'Friday',    subject:'Cryptography',          time:'11:30', room:'CS-108', teacher:'Ms. S. Khan',   type:'Core',      icon:'key-round' },
  { id:'l13', day:'Friday',    subject:'Digital Forensics',     time:'13:30', room:'CS-210', teacher:'Dr. M. Zafar',  type:'Core',      icon:'scan-search' }
];

const LECTURE_ICON_POOL = [
  'shield-check','bug','binary','monitor-play','database-backup',
  'server','cpu','globe','shield-alert','eye','zap','cog',
  'satellite','radio','cloud','hard-drive','braces','library'
];

function loadLectures(){
  const raw = storage.get(LEC_KEY);
  if(!raw){
    console.log('[ADS] No saved lectures — using defaults');
    return DEFAULT_LECTURES.slice();
  }
  try{
    const parsed = JSON.parse(raw);
    if(Array.isArray(parsed)){
      console.log('[ADS] Loaded', parsed.length, 'lectures from storage');
      return parsed;
    }
  }catch(e){
    console.warn('[ADS] Failed to parse saved lectures:', e);
  }
  return DEFAULT_LECTURES.slice();
}

function saveLectures(list){
  storage.set(LEC_KEY, JSON.stringify(list));
  console.log('[ADS] Saved', list.length, 'lectures');
}

function resetLectures(){
  storage.remove(LEC_KEY);
  console.log('[ADS] Lectures reset to defaults');
}

function nextLectureIcon(){
  const used = new Set(loadLectures().map(l => l.icon));
  for(const icon of LECTURE_ICON_POOL){
    if(!used.has(icon)) return icon;
  }
  return 'book-open';
}

function lectureBadge(type){
  return { Core:'blue', Practical:'green', Elective:'amber' }[type] || 'blue';
}
function lectureIcoClass(type){
  return { Core:'', Practical:'green', Elective:'amber' }[type] || '';
}

function lectureRow(l){
  return `
    <div class="row-item">
      <div class="row-left">
        <div class="file-ico ${lectureIcoClass(l.type)}"><i data-icon="${l.icon}"></i></div>
        <div>
          <div class="row-title">${escapeHtml(l.subject)}</div>
          <div class="row-sub">Room ${escapeHtml(l.room)} · ${escapeHtml(l.teacher)}</div>
        </div>
      </div>
      <div class="lecture-meta">
        <span class="time-chip">${formatTime(l.time)}</span>
        <span class="badge ${lectureBadge(l.type)}">${escapeHtml(l.type)}</span>
        <button class="del-btn" data-del-lec="${l.id}" title="Delete">&#10005;</button>
      </div>
    </div>`;
}

function renderLectures(){
  const el = document.getElementById('lecturesContainer');
  if(!el){
    console.log('[ADS] lecturesContainer not found on this page');
    return;
  }

  const all = loadLectures();
  const grouped = {};
  DAYS.forEach(d => grouped[d] = []);
  all.forEach(l => {
    if(!grouped[l.day]) grouped[l.day] = [];
    grouped[l.day].push(l);
  });
  DAYS.forEach(d => grouped[d].sort((a,b) => a.time.localeCompare(b.time)));

  const html = DAYS.filter(d => grouped[d].length > 0).map(day => `
    <div class="day-group">
      <div class="day-header">
        <span class="day-name">${day}</span>
        <span class="day-count">${grouped[day].length} ${grouped[day].length === 1 ? 'Lecture' : 'Lectures'}</span>
      </div>
      <div class="day-body">
        ${grouped[day].map(lectureRow).join('')}
      </div>
    </div>
  `).join('');

  el.innerHTML = html || '<div class="empty-state">No lectures yet — click "Add Lecture" to create one.</div>';
  renderIcons();

  el.querySelectorAll('[data-del-lec]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.delLec;
      saveLectures(loadLectures().filter(l => String(l.id) !== String(id)));
      renderLectures();
    });
  });
}

function bindLectureForm(){
  const toggle = document.getElementById('toggleLectureForm');
  const wrap   = document.getElementById('lectureFormWrap');
  const form   = document.getElementById('lectureForm');
  const cancel = document.getElementById('cancelLecture');
  const reset  = document.getElementById('resetLectures');

  if(!toggle || !wrap || !form){
    console.log('[ADS] Lecture form elements not found on this page');
    return;
  }

  toggle.addEventListener('click', () => {
    wrap.hidden = !wrap.hidden;
    if(!wrap.hidden){
      const first = form.querySelector('input,select');
      if(first) first.focus();
    }
  });

  cancel.addEventListener('click', () => {
    form.reset();
    wrap.hidden = true;
  });

  if(reset){
    reset.addEventListener('click', () => {
      if(confirm('Reset all lectures to the default schedule?')){
        resetLectures();
        renderLectures();
      }
    });
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    const subject = document.getElementById('lecSubject').value.trim();
    const day     = document.getElementById('lecDay').value;
    const time    = document.getElementById('lecTime').value;
    const room    = document.getElementById('lecRoom').value.trim();
    const teacher = document.getElementById('lecTeacher').value.trim();
    const type    = document.getElementById('lecType').value;
    if(!subject || !day || !time || !room || !teacher) return;

    const list = loadLectures();
    list.push({
      id: 'u' + Date.now(),
      day, subject, time, room, teacher, type,
      icon: nextLectureIcon()
    });
    saveLectures(list);
    renderLectures();

    form.reset();
    wrap.hidden = true;
  });
}

/* ============================================================
   REMINDERS
   ============================================================ */
const REM_KEY = 'ads_cyber_reminders_v2';

const DEFAULT_REMINDERS = [
  { id: 1, title:'Submit Network Security Lab Report', date: offsetDate(0), time:'23:59', tag:'Assignment' },
  { id: 2, title:'Cryptography Quiz — Unit 3',        date: offsetDate(1), time:'09:00', tag:'Exam' },
  { id: 3, title:'Group Project Meeting',             date: offsetDate(2), time:'16:00', tag:'Meeting' },
  { id: 4, title:'Read Chapter 5 — Ethical Hacking',  date: offsetDate(3), time:'18:30', tag:'Study' }
];

function loadReminders(){
  const raw = storage.get(REM_KEY);
  if(!raw) return DEFAULT_REMINDERS.slice();
  try{
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_REMINDERS.slice();
  }catch(e){ return DEFAULT_REMINDERS.slice(); }
}
function saveReminders(list){ storage.set(REM_KEY, JSON.stringify(list)); }
function tagClass(tag){
  return { Assignment:'blue', Exam:'red', Lecture:'green', Meeting:'amber', Study:'green' }[tag] || 'blue';
}
function reminderCard(r, showDelete){
  return `
    <div class="card">
      <div class="reminder-head">
        <div class="reminder-title">
          <span data-icon="alarm-clock"></span>
          <span>${escapeHtml(r.title)}</span>
        </div>
        ${showDelete ? `<button class="del-btn" data-del="${r.id}" title="Delete">&#10005;</button>` : ''}
      </div>
      <div class="meta"><span class="badge ${tagClass(r.tag)}">${escapeHtml(r.tag)}</span></div>
      <div class="reminder-when">
        <span><span data-icon="calendar-days"></span>${formatDate(r.date)}</span>
        <span class="clock"><span data-icon="hourglass"></span>${formatTime(r.time)}</span>
      </div>
    </div>`;
}
function renderHomeReminders(){
  const el = document.getElementById('homeReminders');
  if(!el) return;
  const list = loadReminders().sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time));
  el.innerHTML = list.length
    ? list.slice(0,3).map(r => reminderCard(r, false)).join('')
    : '<div class="empty-state">No reminders yet.</div>';
  renderIcons();
}
function renderReminderPage(){
  const el = document.getElementById('reminderList');
  if(!el) return;
  const list = loadReminders().sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time));
  el.innerHTML = list.length
    ? list.map(r => reminderCard(r, true)).join('')
    : '<div class="empty-state">No reminders yet — add your first one above.</div>';
  renderIcons();
  el.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.del);
      saveReminders(loadReminders().filter(r => r.id !== id));
      renderReminderPage();
      renderHomeReminders();
    });
  });
}
function bindReminderForm(){
  const form = document.getElementById('reminderForm');
  if(!form) return;
  const dateInput = document.getElementById('remDate');
  if(dateInput && !dateInput.value) dateInput.value = offsetDate(1);
  form.addEventListener('submit', e => {
    e.preventDefault();
    const title = document.getElementById('remTitle').value.trim();
    const date  = document.getElementById('remDate').value;
    const time  = document.getElementById('remTime').value;
    const tag   = document.getElementById('remTag').value;
    if(!title || !date || !time) return;
    const list = loadReminders();
    list.push({ id: Date.now(), title, date, time, tag });
    saveReminders(list);
    renderReminderPage();
    renderHomeReminders();
    form.reset();
    dateInput.value = offsetDate(1);
  });
}

/* ---------- Init ---------- */
document.addEventListener('DOMContentLoaded', () => {
  console.log('[ADS] DOM ready');
  const y = document.getElementById('year');
  if(y) y.textContent = new Date().getFullYear();

  renderIcons();
  renderLectures();
  bindLectureForm();
  renderHomeReminders();
  renderReminderPage();
  bindReminderForm();
});