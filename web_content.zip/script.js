const video = document.getElementById('video-player');
const wrap = document.getElementById('video-wrap');
const scaler = document.getElementById('video-scaler');
const fileInput = document.getElementById('file-input');
const btnReset = document.getElementById('btn-reset');
const contenedor = document.querySelector('.player-container');
const pantallaInicio = document.getElementById('pantalla-inicio');

const MODO_HORIZONTAL = window.matchMedia('(orientation: landscape)');
const puenteApp = window.AndroidApp || null;

const FILTROS = [
    { id: 'brillo',     variable: '--brillo',     cssUnidad: '%',   textoUnidad: '%', defecto: 100 },
    { id: 'contraste',  variable: '--contraste',  cssUnidad: '%',   textoUnidad: '%', defecto: 100 },
    { id: 'saturacion', variable: '--saturacion', cssUnidad: '%',   textoUnidad: '%', defecto: 100 },
    { id: 'gray',       variable: '--gray',       cssUnidad: '%',   textoUnidad: '%', defecto: 0 },
    { id: 'sepia',      variable: '--sepia',      cssUnidad: '%',   textoUnidad: '%', defecto: 0 },
    { id: 'hue',        variable: '--hue',        cssUnidad: 'deg', textoUnidad: '°', defecto: 0 },
    { id: 'opacity',    variable: '--opacity',    cssUnidad: '%',   textoUnidad: '%', defecto: 100 }
].map(f => ({
    ...f,
    slider: document.getElementById('slider-' + f.id),
    etiqueta: document.getElementById(f.id + '-val')
}));

// Presets orientados a calidad (Filmmaker / corrección profesional), no looks artísticos extremos.
// Referencias: modos Cinema/Filmmaker de TV, contraste claro, saturación moderada, pseudo-HDR suave.
const PRESETS = [
    { nombre: 'Original',        valores: {} },
    // Salto de calidad: contraste claro + saturación natural + ligero HDR (estilo “clear contrast” / mejora general)
    { nombre: 'Mejor calidad',   valores: { brillo: 102, contraste: 118, saturacion: 112, hdr: 45 } },
    { nombre: 'Natural',         valores: { contraste: 108, saturacion: 106 } },
    { nombre: 'Cine',            valores: { brillo: 96, contraste: 115, saturacion: 96, sepia: 8 } },
    { nombre: 'Claridad',        valores: { brillo: 103, contraste: 122, saturacion: 108, hdr: 30 } },
    { nombre: 'Vívido',          valores: { brillo: 103, contraste: 118, saturacion: 128 } },
    { nombre: 'Pseudo-HDR',      valores: { contraste: 112, saturacion: 110, hdr: 75 } },
    { nombre: 'Deportes',        valores: { brillo: 105, contraste: 114, saturacion: 120 } },
    { nombre: 'Cálido',          valores: { brillo: 101, saturacion: 108, sepia: 14 } },
    { nombre: 'Nocturno',        valores: { brillo: 88, contraste: 112, saturacion: 95 } }
];

const ASPECTOS = [
    { id: 'ajuste',   etiqueta: 'Ajuste',   clase: 'aspecto-contain' },
    { id: '16:9',     etiqueta: '16:9',     clase: 'aspecto-16-9' },
    { id: '4:3',      etiqueta: '4:3',      clase: 'aspecto-4-3' },
    { id: 'expandir', etiqueta: 'Expandir', clase: 'aspecto-cover' },
    { id: 'rellenar', etiqueta: 'Rellenar', clase: 'aspecto-fill' },
    { id: 'original', etiqueta: 'Original', clase: 'aspecto-original' }
];
let indiceAspecto = 0;

let urlVideoActual = null;
let chipActivo = null;
let hdrNivel = 0;
let nombreArchivo = '';
let tamanoArchivo = 0;
let menuAbierto = false; // algún panel de color/pro abierto

// ---------- Inmersivo / pantalla completa ----------
function activarInmersivo(activo) {
    if (puenteApp) {
        try {
            if (typeof puenteApp.setInmersivo === 'function') puenteApp.setInmersivo(!!activo);
            else if (typeof puenteApp.hideSystemUI === 'function') puenteApp.hideSystemUI(!!activo);
            if (typeof puenteApp.setPantallaCompleta === 'function') puenteApp.setPantallaCompleta(!!activo);
        } catch (e) {}
    }
    if (activo) {
        const el = document.documentElement;
        const pedir = el.requestFullscreen || el.webkitRequestFullscreen;
        if (pedir && !document.fullscreenElement && !document.webkitFullscreenElement) {
            try {
                const r = pedir.call(contenedor) || pedir.call(el);
                if (r && r.catch) r.catch(() => {
                    try { pedir.call(el); } catch (e2) {}
                });
            } catch (e) {
                try { pedir.call(el); } catch (e2) {}
            }
        }
        pantallaCompletaApp = true;
        marcarPantallaCompleta();
    } else {
        const salir = document.exitFullscreen || document.webkitExitFullscreen;
        if (salir && (document.fullscreenElement || document.webkitFullscreenElement)) {
            try { salir.call(document); } catch (e) {}
        }
        pantallaCompletaApp = false;
        marcarPantallaCompleta();
    }
}

function irAInicio() {
    video.pause();
    if (urlVideoActual) {
        URL.revokeObjectURL(urlVideoActual);
        urlVideoActual = null;
    }
    video.removeAttribute('src');
    video.load();
    contenedor.classList.add('sin-video');
    pantallaInicio.classList.remove('oculta');
    fileInput.value = '';
    resetZoom();
    document.getElementById('panel-info').classList.add('oculto');
    cerrarTodosLosMenus();
    activarInmersivo(false);
    if (history.state && history.state.reproductor) {
        history.replaceState(null, '');
    }
}

function entrarAlReproductor() {
    pantallaInicio.classList.add('oculta');
    contenedor.classList.remove('sin-video');
    cerrarTodosLosMenus();
    activarInmersivo(true);
    if (!history.state || !history.state.reproductor) {
        history.pushState({ reproductor: true }, '');
    }
    mostrarInterfaz();
}

fileInput.addEventListener('change', (e) => {
    const archivo = e.target.files[0];
    if (!archivo) return;

    if (urlVideoActual) URL.revokeObjectURL(urlVideoActual);
    urlVideoActual = URL.createObjectURL(archivo);
    nombreArchivo = archivo.name || 'Vídeo';
    tamanoArchivo = archivo.size || 0;

    video.src = urlVideoActual;
    document.getElementById('titulo-video').textContent = nombreArchivo;

    resetZoom();
    aplicarAspecto(0);
    entrarAlReproductor();

    const intento = video.play();
    if (intento && intento.catch) intento.catch(() => {});
});

document.getElementById('btn-atras-inicio').addEventListener('click', irAInicio);

window.addEventListener('popstate', () => {
    if (tieneVideo()) irAInicio();
});

// ---------- Filtros (solo cambia lo que movés) ----------
function actualizarFiltros() {
    FILTROS.forEach((f) => {
        const valor = f.slider.value;
        f.etiqueta.textContent = valor + f.textoUnidad;
        video.style.setProperty(f.variable, valor + f.cssUnidad);
    });
    const hdr = hdrNivel / 100;
    video.style.setProperty('--hdr-contraste', (1 + 0.22 * hdr).toFixed(3));
    video.style.setProperty('--hdr-saturacion', (1 + 0.30 * hdr).toFixed(3));
    video.style.setProperty('--hdr-brillo', (1 + 0.06 * hdr).toFixed(3));
}

function marcarChip(chip) {
    if (chipActivo) chipActivo.classList.remove('activo');
    chipActivo = chip;
    if (chip) chip.classList.add('activo');
}

function aplicarPreset(preset, chip) {
    hdrNivel = preset.valores.hdr || 0;
    FILTROS.forEach((f) => {
        const valor = preset.valores[f.id];
        f.slider.value = (valor !== undefined) ? valor : f.defecto;
    });
    actualizarFiltros();
    marcarChip(chip);
}

const listaPresets = document.getElementById('lista-presets');
PRESETS.forEach((preset) => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'chip-preset';
    chip.textContent = preset.nombre;
    chip.addEventListener('click', () => {
        aplicarPreset(preset, chip);
        // El menú permanece abierto hasta tocar fuera
    });
    listaPresets.appendChild(chip);
});
const chipOriginal = listaPresets.firstElementChild;

function restablecerValores() {
    aplicarPreset(PRESETS[0], chipOriginal);
}

FILTROS.forEach((f) => {
    f.slider.addEventListener('input', () => {
        // Solo modifica ese control; el resto de valores del preset se mantienen
        marcarChip(null);
        actualizarFiltros();
    });
});
btnReset.addEventListener('click', restablecerValores);

// ---------- Mejoras: velocidad, nitidez, modo ligero ----------
const VELOCIDADES = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4];
const listaVel = document.getElementById('lista-velocidad');
const velVal = document.getElementById('velocidad-val');
const sliderNitidez = document.getElementById('slider-nitidez');
const nitidezVal = document.getElementById('nitidez-val');
const checkLigero = document.getElementById('check-ligero');
let nitidezActual = 0;
let filtrosGuardadosLigero = null;

VELOCIDADES.forEach((v) => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'chip-vel' + (v === 1 ? ' activo' : '');
    chip.textContent = v + '×';
    chip.addEventListener('click', () => {
        try {
            video.playbackRate = v;
            velVal.textContent = v + '×';
            listaVel.querySelectorAll('.chip-vel').forEach((c) => c.classList.remove('activo'));
            chip.classList.add('activo');
        } catch (e) {}
    });
    listaVel.appendChild(chip);
});

function aplicarNitidez(n) {
    nitidezActual = n;
    nitidezVal.textContent = String(n);
    video.style.setProperty('--nitidez', String(n));
}

sliderNitidez.addEventListener('input', () => {
    aplicarNitidez(Number(sliderNitidez.value));
});

checkLigero.addEventListener('change', () => {
    if (checkLigero.checked) {
        filtrosGuardadosLigero = FILTROS.map((f) => f.slider.value);
        filtrosGuardadosLigero._hdr = hdrNivel;
        filtrosGuardadosLigero._nit = nitidezActual;
        FILTROS.forEach((f) => { f.slider.value = f.defecto; });
        hdrNivel = 0;
        aplicarNitidez(0);
        sliderNitidez.value = 0;
        actualizarFiltros();
    } else if (filtrosGuardadosLigero) {
        FILTROS.forEach((f, i) => { f.slider.value = filtrosGuardadosLigero[i]; });
        hdrNivel = filtrosGuardadosLigero._hdr || 0;
        aplicarNitidez(filtrosGuardadosLigero._nit || 0);
        sliderNitidez.value = filtrosGuardadosLigero._nit || 0;
        actualizarFiltros();
        filtrosGuardadosLigero = null;
    }
});

// ---------- Controles de reproducción ----------
const btnPlay = document.getElementById('btn-play');
const btnAtras = document.getElementById('btn-atras');
const btnAdelante = document.getElementById('btn-adelante');
const barraProgreso = document.getElementById('barra-progreso');
const tiempoActual = document.getElementById('tiempo-actual');
const tiempoTotal = document.getElementById('tiempo-total');
let buscando = false;

function formatoTiempo(segundos) {
    if (!isFinite(segundos) || segundos < 0) return '0:00';
    const h = Math.floor(segundos / 3600);
    const m = Math.floor((segundos % 3600) / 60);
    const s = Math.floor(segundos % 60);
    const ss = String(s).padStart(2, '0');
    return h > 0 ? h + ':' + String(m).padStart(2, '0') + ':' + ss : m + ':' + ss;
}

function actualizarTiempos() {
    const duracion = video.duration;
    tiempoActual.textContent = formatoTiempo(video.currentTime);
    tiempoTotal.textContent = formatoTiempo(duracion);
    if (!buscando && isFinite(duracion) && duracion > 0) {
        barraProgreso.value = Math.round(video.currentTime / duracion * 1000);
    }
}

function saltar(segundos) {
    const duracion = video.duration;
    if (!isFinite(duracion)) return;
    video.currentTime = Math.max(0, Math.min(duracion, video.currentTime + segundos));
}

btnPlay.addEventListener('click', () => {
    if (video.paused) {
        const intento = video.play();
        if (intento && intento.catch) intento.catch(() => {});
    } else {
        video.pause();
    }
});
btnAtras.addEventListener('click', () => saltar(-10));
btnAdelante.addEventListener('click', () => saltar(10));

barraProgreso.addEventListener('pointerdown', () => { buscando = true; });
window.addEventListener('pointerup', () => { buscando = false; });
barraProgreso.addEventListener('input', () => {
    const duracion = video.duration;
    if (isFinite(duracion) && duracion > 0) {
        video.currentTime = barraProgreso.value / 1000 * duracion;
    }
    actualizarTiempos();
});

video.addEventListener('timeupdate', actualizarTiempos);
video.addEventListener('loadedmetadata', () => {
    actualizarTiempos();
    actualizarMetaVideo();
});
video.addEventListener('durationchange', actualizarTiempos);
video.addEventListener('play', () => wrap.classList.add('reproduciendo'));
video.addEventListener('pause', () => wrap.classList.remove('reproduciendo'));

function formatoTamano(bytes) {
    if (!bytes || bytes <= 0) return '—';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
}

function actualizarMetaVideo() {
    const w = video.videoWidth;
    const h = video.videoHeight;
    const meta = document.getElementById('meta-video');
    meta.textContent = (w && h) ? (w + '×' + h) : '';
}

// ---------- Aspecto ----------
const btnAspecto = document.getElementById('btn-aspecto');
const aspectoLabel = document.getElementById('aspecto-label');

function aplicarAspecto(indice) {
    indiceAspecto = ((indice % ASPECTOS.length) + ASPECTOS.length) % ASPECTOS.length;
    const a = ASPECTOS[indiceAspecto];
    ASPECTOS.forEach((x) => video.classList.remove(x.clase));
    video.classList.add(a.clase);
    aspectoLabel.textContent = a.etiqueta;
}

btnAspecto.addEventListener('click', () => {
    aplicarAspecto(indiceAspecto + 1);
    mostrarInterfaz();
});

// ---------- Pantalla completa (botón manual) ----------
const btnPantalla = document.getElementById('btn-pantalla');
let pantallaCompletaApp = false;

function enPantallaCompleta() {
    return pantallaCompletaApp || !!(document.fullscreenElement || document.webkitFullscreenElement);
}

function marcarPantallaCompleta() {
    if (enPantallaCompleta()) wrap.classList.add('pantalla-completa');
    else wrap.classList.remove('pantalla-completa');
}

function alCambiarPantallaCompleta() {
    marcarPantallaCompleta();
    if (!enPantallaCompleta() && window.screen && screen.orientation && screen.orientation.unlock) {
        try { screen.orientation.unlock(); } catch (e) {}
    }
}

function alternarPantallaCompleta() {
    if (enPantallaCompleta()) {
        activarInmersivo(false);
    } else {
        activarInmersivo(true);
    }
}

btnPantalla.addEventListener('click', alternarPantallaCompleta);
document.addEventListener('fullscreenchange', alCambiarPantallaCompleta);
document.addEventListener('webkitfullscreenchange', alCambiarPantallaCompleta);

// ---------- Información ----------
const panelInfo = document.getElementById('panel-info');
const panelInfoCuerpo = document.getElementById('panel-info-cuerpo');

function construirInfo() {
    const filas = [];
    const add = (etiqueta, valor) => {
        if (valor === undefined || valor === null || valor === '') return;
        filas.push({ etiqueta, valor });
    };
    add('Nombre', nombreArchivo);
    add('Tamaño', formatoTamano(tamanoArchivo));
    if (video.videoWidth && video.videoHeight) {
        add('Resolución', video.videoWidth + ' × ' + video.videoHeight + ' px');
        add('Relación de aspecto', (video.videoWidth / video.videoHeight).toFixed(3) + ' (' + ASPECTOS[indiceAspecto].etiqueta + ')');
    }
    if (isFinite(video.duration) && video.duration > 0) add('Duración', formatoTiempo(video.duration));
    if (fileInput.files[0] && fileInput.files[0].type) add('Tipo MIME', fileInput.files[0].type);
    try {
        if (typeof video.getVideoPlaybackQuality === 'function') {
            const q = video.getVideoPlaybackQuality();
            if (q) {
                add('Frames totales', q.totalVideoFrames);
                add('Frames perdidos', q.droppedVideoFrames);
            }
        }
    } catch (e) {}
    if (filas.length === 0) {
        panelInfoCuerpo.innerHTML = '<p style="color:#999">No hay información disponible todavía.</p>';
        return;
    }
    panelInfoCuerpo.innerHTML = filas.map((f) =>
        '<div class="fila-info"><span class="etiqueta">' + f.etiqueta + '</span><span class="valor">' + f.valor + '</span></div>'
    ).join('');
}

document.getElementById('btn-info').addEventListener('click', (e) => {
    e.stopPropagation();
    construirInfo();
    panelInfo.classList.toggle('oculto');
    mostrarInterfaz();
});
document.getElementById('btn-cerrar-info').addEventListener('click', () => {
    panelInfo.classList.add('oculto');
});

// ---------- UI y menús ----------
const TIEMPO_AUTOOCULTAR = 4000;
const INTERACTIVO = '.ctl, .flotante, .barra-superior, .panel-info, .btn-icono, .panel-arrastrable';
let temporizadorUI = null;

function tieneVideo() {
    return !!video.getAttribute('src');
}

function hayMenuAbierto() {
    return !contenedor.classList.contains('panel-oculto')
        || !contenedor.classList.contains('extras-oculto')
        || !contenedor.classList.contains('presets-oculto')
        || !contenedor.classList.contains('pro-oculto')
        || !panelInfo.classList.contains('oculto');
}

function cerrarTodosLosMenus() {
    contenedor.classList.add('presets-oculto', 'panel-oculto', 'extras-oculto', 'pro-oculto');
    panelInfo.classList.add('oculto');
    menuAbierto = false;
}

function mostrarInterfaz(fija) {
    contenedor.classList.remove('ui-oculta');
    clearTimeout(temporizadorUI);
    // Con menú abierto no se auto-oculta nada
    if (hayMenuAbierto()) return;
    if (!fija && tieneVideo()) {
        temporizadorUI = setTimeout(() => {
            if (!hayMenuAbierto()) {
                contenedor.classList.add('ui-oculta');
            }
        }, TIEMPO_AUTOOCULTAR);
    }
}

function ocultarInterfaz() {
    clearTimeout(temporizadorUI);
    if (tieneVideo() && !hayMenuAbierto()) {
        contenedor.classList.add('ui-oculta');
    }
}

function alternarInterfaz() {
    if (hayMenuAbierto()) {
        cerrarTodosLosMenus();
        mostrarInterfaz();
        return;
    }
    if (contenedor.classList.contains('ui-oculta')) {
        mostrarInterfaz();
    } else {
        ocultarInterfaz();
    }
}

// Abrir/cerrar un menú concreto (botones fijos; paneles se pueden arrastrar)
function toggleMenu(claseOculto) {
    const estabaAbierto = !contenedor.classList.contains(claseOculto);
    // Cierra los demás paneles de ajustes para no apilar
    ['panel-oculto', 'extras-oculto', 'presets-oculto', 'pro-oculto'].forEach((c) => {
        if (c !== claseOculto) contenedor.classList.add(c);
    });
    if (estabaAbierto) {
        contenedor.classList.add(claseOculto);
    } else {
        contenedor.classList.remove(claseOculto);
    }
    menuAbierto = hayMenuAbierto();
    contenedor.classList.remove('ui-oculta');
    clearTimeout(temporizadorUI);
}

document.getElementById('btn-panel').addEventListener('click', () => toggleMenu('panel-oculto'));
document.getElementById('btn-extras').addEventListener('click', () => toggleMenu('extras-oculto'));
document.getElementById('btn-presets').addEventListener('click', () => toggleMenu('presets-oculto'));
document.getElementById('btn-pro').addEventListener('click', () => toggleMenu('pro-oculto'));

// Tocar fuera de un menú lo cierra
contenedor.addEventListener('pointerdown', (e) => {
    if (!hayMenuAbierto()) {
        if (e.target.closest(INTERACTIVO)) mostrarInterfaz();
        return;
    }
    // Si toca dentro de un panel o botón flotante, no cerrar
    if (e.target.closest('.panel-arrastrable, .color-controls, .presets, .panel-pro, .btn-flotante, .panel-info, .barra-superior')) {
        return;
    }
    // Tocar en cualquier otro lugar → cerrar menús, dejar solo controles de reproducción
    cerrarTodosLosMenus();
    mostrarInterfaz();
});

contenedor.addEventListener('input', () => {
    if (hayMenuAbierto()) {
        clearTimeout(temporizadorUI);
        contenedor.classList.remove('ui-oculta');
    } else {
        mostrarInterfaz();
    }
});

video.addEventListener('play', () => { if (!hayMenuAbierto()) mostrarInterfaz(); });
video.addEventListener('pause', () => { if (!hayMenuAbierto()) mostrarInterfaz(); });
video.addEventListener('ended', () => mostrarInterfaz(true));

// ---------- Arrastrar SOLO las ventanas de menú (botones fijos) ----------
function hacerPanelArrastrable(panelEl) {
    if (!panelEl) return;
    panelEl.classList.add('panel-arrastrable');
    let posX = 0;
    let posY = 0;
    let inicio = null;
    const clave = 'panel-pos-' + (panelEl.id || panelEl.className);

    try {
        const g = JSON.parse(localStorage.getItem(clave));
        if (g) {
            posX = Number(g.x) || 0;
            posY = Number(g.y) || 0;
        }
    } catch (e) {}

    function aplicar() {
        panelEl.style.setProperty('--pdx', posX + 'px');
        panelEl.style.setProperty('--pdy', posY + 'px');
    }

    function alPresionar(e) {
        // Solo arrastrar desde la cabecera / área vacía del panel, no desde sliders
        if (e.target.closest('input, button, .chip-preset, .chip-vel, label')) return;
        e.preventDefault();
        panelEl.setPointerCapture(e.pointerId);
        inicio = {
            x: e.clientX,
            y: e.clientY,
            posX,
            posY,
            rect: panelEl.getBoundingClientRect(),
            area: contenedor.getBoundingClientRect()
        };
        panelEl.classList.add('arrastrando-panel');
    }

    function alMover(e) {
        if (!inicio) return;
        let dx = e.clientX - inicio.x;
        let dy = e.clientY - inicio.y;
        const r = inicio.rect;
        const a = inicio.area;
        const minDx = a.left - r.left;
        const maxDx = a.right - r.right;
        const minDy = a.top - r.top;
        const maxDy = a.bottom - r.bottom;
        dx = Math.min(Math.max(dx, minDx), maxDx);
        dy = Math.min(Math.max(dy, minDy), maxDy);
        posX = inicio.posX + dx;
        posY = inicio.posY + dy;
        aplicar();
    }

    function terminar() {
        if (!inicio) return;
        inicio = null;
        panelEl.classList.remove('arrastrando-panel');
        try {
            localStorage.setItem(clave, JSON.stringify({ x: posX, y: posY }));
        } catch (e) {}
    }

    panelEl.addEventListener('pointerdown', alPresionar);
    panelEl.addEventListener('pointermove', alMover);
    panelEl.addEventListener('pointerup', terminar);
    panelEl.addEventListener('pointercancel', terminar);
    aplicar();
}

// Envolver paneles para arrastre
document.querySelectorAll('.panel-ajustes, .panel-extras, .presets, .panel-pro').forEach(hacerPanelArrastrable);

// ---------- Zoom (hasta 1000% = 10×, mostrado en %) ----------
const ZOOM_MIN = 1;
const ZOOM_MAX = 12; // 1200%
let zoomActual = 1;
let panX = 0;
let panY = 0;
let pinchActivo = null;
const indicadorZoom = document.getElementById('indicador-zoom');
const zoomValorEl = document.getElementById('zoom-valor');
let tempZoomHide = null;
const pointers = new Map();

function aplicarTransformZoom() {
    scaler.style.transform = 'translate(' + panX + 'px,' + panY + 'px) scale(' + zoomActual + ')';
}

function mostrarZoomUI() {
    zoomValorEl.textContent = Math.round(zoomActual * 100) + '%';
    indicadorZoom.classList.add('visible');
    clearTimeout(tempZoomHide);
    tempZoomHide = setTimeout(() => indicadorZoom.classList.remove('visible'), 900);
}

function resetZoom() {
    zoomActual = 1;
    panX = 0;
    panY = 0;
    aplicarTransformZoom();
}

function limitarPan() {
    const maxPan = (zoomActual - 1) * Math.min(wrap.clientWidth, wrap.clientHeight) * 0.5;
    panX = Math.max(-maxPan, Math.min(maxPan, panX));
    panY = Math.max(-maxPan, Math.min(maxPan, panY));
}

wrap.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.ctl, .flotante, .barra-superior, .panel-info, .panel-arrastrable, .color-controls, .presets, .panel-pro')) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.size === 2) {
        const pts = Array.from(pointers.values());
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        pinchActivo = {
            dist0: dist,
            zoom0: zoomActual,
            panX0: panX,
            panY0: panY,
            cx: (pts[0].x + pts[1].x) / 2,
            cy: (pts[0].y + pts[1].y) / 2
        };
        gesto = null;
    }
});

wrap.addEventListener('pointermove', (e) => {
    if (!pointers.has(e.pointerId)) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinchActivo && pointers.size >= 2) {
        const pts = Array.from(pointers.values());
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        if (pinchActivo.dist0 > 0) {
            let nuevo = pinchActivo.zoom0 * (dist / pinchActivo.dist0);
            nuevo = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, nuevo));
            zoomActual = Math.round(nuevo * 50) / 50;
            const cx = (pts[0].x + pts[1].x) / 2;
            const cy = (pts[0].y + pts[1].y) / 2;
            panX = pinchActivo.panX0 + (cx - pinchActivo.cx) * 0.55;
            panY = pinchActivo.panY0 + (cy - pinchActivo.cy) * 0.55;
            limitarPan();
            aplicarTransformZoom();
            mostrarZoomUI();
        }
    }
});

function finPointer(e) {
    pointers.delete(e.pointerId);
    if (pointers.size < 2) pinchActivo = null;
}
wrap.addEventListener('pointerup', finPointer);
wrap.addEventListener('pointercancel', finPointer);

// Doble toque: laterales ±10 s; centro resetea zoom
let ultimoTap = 0;
let ultimoTapX = 0;
wrap.addEventListener('pointerup', (e) => {
    if (e.target.closest('.ctl, .flotante, .barra-superior, .panel-info, .panel-arrastrable, .color-controls, .presets, .panel-pro')) return;
    if (pointers.size > 0) return;
    const ahora = Date.now();
    const rect = wrap.getBoundingClientRect();
    const xRel = (e.clientX - rect.left) / rect.width;
    if (ahora - ultimoTap < 300 && Math.abs(e.clientX - ultimoTapX) < 80) {
        if (xRel < 0.35) {
            saltar(-10);
            mostrarInterfaz();
        } else if (xRel > 0.65) {
            saltar(10);
            mostrarInterfaz();
        } else if (zoomActual > 1.05) {
            resetZoom();
            mostrarZoomUI();
        }
        ultimoTap = 0;
    } else {
        ultimoTap = ahora;
        ultimoTapX = e.clientX;
    }
});

// ---------- Gestos: brillo y volumen del SISTEMA Android ----------
const indicador = document.getElementById('indicador-gesto');
const indicadorValor = document.getElementById('indicador-valor');
const indicadorRelleno = document.getElementById('indicador-relleno');
const atenuador = document.getElementById('atenuador');

const MOVIMIENTO_MINIMO = 12;
const DURACION_TOQUE = 500;
const SENSIBILIDAD = { brillo: 130, volumen: 140 };
let gesto = null;
let temporizadorIndicador = null;
let brilloSimulado = 100;
let volumenSimulado = 80;

function leerBrilloSistema() {
    if (puenteApp && typeof puenteApp.getBrillo === 'function') {
        try { return Math.round(puenteApp.getBrillo() * 100); } catch (e) {}
    }
    return brilloSimulado;
}

function fijarBrilloSistema(valor) {
    valor = Math.min(100, Math.max(1, Math.round(valor)));
    if (puenteApp && typeof puenteApp.setBrillo === 'function') {
        try {
            puenteApp.setBrillo(valor / 100);
            return valor;
        } catch (e) {}
    }
    // Fallback navegador: capa atenuadora (no es brillo real del sistema)
    brilloSimulado = valor;
    atenuador.style.opacity = ((100 - valor) / 100 * 0.85).toFixed(2);
    return valor;
}

function leerVolumenSistema() {
    if (puenteApp && typeof puenteApp.getVolumen === 'function') {
        try { return Math.round(puenteApp.getVolumen() * 100); } catch (e) {}
    }
    if (puenteApp && typeof puenteApp.getVolume === 'function') {
        try { return Math.round(puenteApp.getVolume() * 100); } catch (e) {}
    }
    return volumenSimulado;
}

function fijarVolumenSistema(valor) {
    valor = Math.min(100, Math.max(0, Math.round(valor)));
    if (puenteApp && typeof puenteApp.setVolumen === 'function') {
        try {
            puenteApp.setVolumen(valor / 100);
            return valor;
        } catch (e) {}
    }
    if (puenteApp && typeof puenteApp.setVolume === 'function') {
        try {
            puenteApp.setVolume(valor / 100);
            return valor;
        } catch (e) {}
    }
    // Fallback: volumen del elemento video (navegador)
    volumenSimulado = valor;
    video.volume = valor / 100;
    if (valor > 0) video.muted = false;
    return Math.round(video.volume * 100);
}

function mostrarIndicador(tipo, valor, maximo, texto) {
    if (tipo === 'brillo') {
        indicador.classList.add('izquierda');
        indicador.classList.remove('derecha');
    } else {
        indicador.classList.add('derecha');
        indicador.classList.remove('izquierda');
    }
    if (tipo === 'volumen' && valor === 0) indicador.classList.add('silencio');
    else indicador.classList.remove('silencio');
    indicadorRelleno.style.height = (valor / maximo * 100) + '%';
    indicadorValor.textContent = texto;
    indicador.classList.add('visible');
    clearTimeout(temporizadorIndicador);
}

function ocultarIndicador() {
    clearTimeout(temporizadorIndicador);
    temporizadorIndicador = setTimeout(() => indicador.classList.remove('visible'), 700);
}

function aplicarGesto(valor) {
    if (gesto.tipo === 'brillo') {
        const v = fijarBrilloSistema(valor);
        mostrarIndicador('brillo', v, 100, v + '%');
    } else {
        const v = fijarVolumenSistema(valor);
        mostrarIndicador('volumen', v, 100, v + '%');
    }
}

wrap.addEventListener('pointerdown', (e) => {
    if (gesto || e.target.closest('.ctl, .flotante, .barra-superior, .panel-info, .panel-arrastrable, .color-controls, .presets, .panel-pro')) return;
    if (pointers.size > 1 || hayMenuAbierto()) return;
    const rect = wrap.getBoundingClientRect();
    const lado = (e.clientX < rect.left + rect.width / 2) ? 'brillo' : 'volumen';
    gesto = {
        id: e.pointerId,
        tipo: lado,
        x: e.clientX,
        y: e.clientY,
        t: Date.now(),
        alto: rect.height,
        activo: false,
        movio: false,
        bloqueado: false,
        inicial: 0
    };
});

wrap.addEventListener('pointermove', (e) => {
    if (!gesto || e.pointerId !== gesto.id || gesto.bloqueado) return;
    if (pinchActivo || pointers.size > 1) {
        gesto.bloqueado = true;
        return;
    }
    const dx = e.clientX - gesto.x;
    const dy = e.clientY - gesto.y;

    if (!gesto.activo) {
        if (Math.hypot(dx, dy) < MOVIMIENTO_MINIMO) return;
        gesto.movio = true;
        if (Math.abs(dy) < Math.abs(dx)) {
            gesto.bloqueado = true;
            return;
        }
        gesto.activo = true;
        gesto.x = e.clientX;
        gesto.y = e.clientY;
        gesto.inicial = (gesto.tipo === 'brillo') ? leerBrilloSistema() : leerVolumenSistema();
        wrap.setPointerCapture(e.pointerId);
        aplicarGesto(gesto.inicial);
        return;
    }

    aplicarGesto(gesto.inicial + (-dy / gesto.alto) * SENSIBILIDAD[gesto.tipo]);
});

function terminarGesto(e) {
    if (!gesto || e.pointerId !== gesto.id) return;
    const g = gesto;
    gesto = null;
    if (g.activo) {
        ocultarIndicador();
    } else if (!g.movio && e.type === 'pointerup' && Date.now() - g.t < DURACION_TOQUE && !pinchActivo) {
        alternarInterfaz();
    }
}
wrap.addEventListener('pointerup', terminarGesto);
wrap.addEventListener('pointercancel', terminarGesto);

// Estado inicial
marcarChip(chipOriginal);
actualizarFiltros();
actualizarTiempos();
aplicarAspecto(0);
cerrarTodosLosMenus();
