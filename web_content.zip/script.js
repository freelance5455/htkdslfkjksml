import {
  auth,
  database,
  ref,
  set,
  get,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged
} from "./firebase/firebase.js";

const userInput = document.getElementById("user");
const passwordInput = document.getElementById("password");
const emailInput = document.getElementById("email");
const submitButton = document.getElementById("submit");
const visibilityButton = document.getElementById("visibility");

function showError(message) {
  console.error(message);
  alert(message);
}

async function saveUserProfile(user, username) {
  await set(ref(database, `users/${user.uid}`), {
    uid: user.uid,
    username,
    email: user.email || ""
  });
  localStorage.setItem("username", username);
  localStorage.setItem("uid", user.uid);
}

onAuthStateChanged(auth, async (user) => {
  if (!user) return;

  try {
    const snapshot = await get(ref(database, `users/${user.uid}`));
    if (snapshot.exists()) {
      localStorage.setItem("username", snapshot.val().username || "");
      localStorage.setItem("uid", user.uid);
    }
    window.location.replace("./main.html");
  } catch (error) {
    console.error("Could not load user profile:", error);
  }
});

submitButton.addEventListener("click", async (event) => {
  event.preventDefault();

  const username = userInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!username || !email || !password) {
    showError("Please enter a username, email, and password.");
    return;
  }

  submitButton.disabled = true;
  submitButton.textContent = "Loading...";

  try {
    let credential;

    try {
      credential = await createUserWithEmailAndPassword(auth, email, password);
    } catch (createError) {
      if (createError.code !== "auth/email-already-in-use") throw createError;
      credential = await signInWithEmailAndPassword(auth, email, password);
    }

    await saveUserProfile(credential.user, username);
    window.location.replace("./main.html");
  } catch (error) {
    console.error("Authentication error:", error);

    const messages = {
      "auth/invalid-email": "That email address is invalid.",
      "auth/weak-password": "Password must be at least 6 characters.",
      "auth/invalid-credential": "Incorrect email or password.",
      "auth/user-not-found": "No account was found with that email.",
      "auth/wrong-password": "Incorrect password."
    };

    showError(messages[error.code] || error.message || "Authentication failed.");
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Submit";
  }
});

let passwordVisible = false;
visibilityButton.addEventListener("click", () => {
  passwordVisible = !passwordVisible;
  passwordInput.type = passwordVisible ? "text" : "password";
  const icon = document.getElementById("vis");
  if (icon) icon.textContent = passwordVisible ? "visibility_off" : "visibility";
});
