const characters = {
    tanjiro: { name: "Tanjiro Kamado", chat: [], enabled: true },
    nezuko: { name: "Nezuko Kamado", chat: [], enabled: true },
    zenitsu: { name: "Zenitsu Agatsuma", chat: [], enabled: true },
    inosuke: { name: "Inosuke Hashibira", chat: [], enabled: true },
    giyu: { name: "Giyu Tomioka", chat: [], enabled: true },
    shinobu: { name: "Shinobu Kocho", chat: [], enabled: true },
    kyojuro: { name: "Kyojuro Rengoku", chat: [], enabled: true },
    tengen: { name: "Tengen Uzui", chat: [], enabled: true },
    muichiro: { name: "Muichiro Tokito", chat: [], enabled: true },
    obanai: { name: "Obanai Iguro", chat: [], enabled: true },
    sanemi: { name: "Sanemi Shinazugawa", chat: [], enabled: true },
    gyomei: { name: "Gyomei Himejima", chat: [], enabled: true },
    kanao: { name: "Kanao Tsuyuri", chat: [], enabled: true },
    genya: { name: "Genya Shinazugawa", chat: [], enabled: true },
    demon_king_tanjiro: { name: "Demon King Tanjiro", chat: [], enabled: true },
    muzan: { name: "Muzan Kibutsuji", chat: [], enabled: true },
    akaza: { name: "Akaza", chat: [], enabled: true }
};

let currentChatId = null;

function loadChat(charId) {
    if (!characters[charId]?.enabled) return;
    currentChatId = charId;
    const title = document.getElementById('current-chat-title');
    const container = document.getElementById('chat-messages');
    const chatArea = document.getElementById('chat-area');
    const sidebar = document.getElementById('sidebar');

    if (!title || !container || !chatArea || !sidebar) return;

    title.innerText = characters[charId].name;
    container.innerHTML = '';

    if (characters[charId].chat) {
        characters[charId].chat.forEach(msg => {
            const msgDiv = document.createElement('div');
            msgDiv.className = msg.sender === 'user' ? 'message user' : 'message';
            msgDiv.innerText = msg.text;
            container.appendChild(msgDiv);
        });
    }

    sidebar.classList.add('hidden');
    chatArea.classList.add('active');
}

function closeChat() {
    const chatArea = document.getElementById('chat-area');
    const sidebar = document.getElementById('sidebar');
    if (chatArea && sidebar) {
        chatArea.classList.remove('active');
        sidebar.classList.remove('hidden');
    }
    currentChatId = null;
}

function sendMessage() {
    const input = document.getElementById('message-input');
    const container = document.getElementById('chat-messages');
    if (!input || !container || !currentChatId) return;

    const text = input.value;
    if (text.trim() !== "") {
        const userMsg = { sender: 'user', text: text };
        characters[currentChatId].chat.push(userMsg);

        const msgDiv = document.createElement('div');
        msgDiv.className = 'message user';
        msgDiv.innerText = text;
        container.appendChild(msgDiv);
        input.value = '';
        container.scrollTop = container.scrollHeight;

        setTimeout(() => {
            const responses = [
                "سأقضي عليك!",
                "تنفس التركيز الكامل...",
                "لن أسمح لك بإيذاء أحد.",
                "همم... مثير للاهتمام."
            ];
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            characters[currentChatId].chat.push({ sender: 'character', text: randomResponse });

            const responseDiv = document.createElement('div');
            responseDiv.className = 'message';
            responseDiv.innerText = randomResponse;
            container.appendChild(responseDiv);
            container.scrollTop = container.scrollHeight;
        }, 1000);
    }
}

function switchTab(tabId) {
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    const activeBtn = Array.from(document.querySelectorAll('.nav-item')).find(btn => btn.getAttribute('onclick')?.includes(tabId));
    if (activeBtn) activeBtn.classList.add('active');

    const sidebar = document.getElementById('sidebar');
    const chatArea = document.getElementById('chat-area');
    const settingsSection = document.getElementById('settings-section');

    if (chatArea) chatArea.classList.remove('active');
    if (sidebar) sidebar.classList.add('hidden');
    if (settingsSection) settingsSection.style.display = 'none';

    if (tabId === 'chats' || tabId === 'groups') {
        if (sidebar) sidebar.classList.remove('hidden');
        document.getElementById('sidebar').querySelector('h2').innerText = tabId === 'chats' ? 'الشخصيات المتاحة' : 'المجموعات';
    } else if (tabId === 'settings') {
        if (settingsSection) settingsSection.style.display = 'flex';
        renderCharacterToggles();
    }
}

function openAddCharacterModal() {
    const name = prompt("أدخل اسم الشخصية الجديدة:");
    if (name) {
        const id = 'char_' + Date.now();
        characters[id] = { name: name, chat: [], enabled: true };
        renderCharacterGrid();
        alert("تمت إضافة الشخصية!");
    }
}

function createGroup() {
    const name = prompt("أدخل اسم المجموعة الجديدة:");
    if (name) {
        alert("تم إنشاء المجموعة: " + name);
    }
}

function setCustomBackground(hexColor) {
    document.body.style.backgroundColor = hexColor;
    
    if (hexColor === '#ffffff') {
        document.documentElement.style.setProperty('--text-color', '#121212');
        document.documentElement.style.setProperty('--sidebar-bg', '#eeeeee');
        document.documentElement.style.setProperty('--chat-bg', '#f9f9f9');
        document.documentElement.style.setProperty('--card-bg', '#e0e0e0');
        document.documentElement.style.setProperty('--char-msg', '#cccccc');
        document.documentElement.style.setProperty('--nav-bg', '#eeeeee');
        document.documentElement.style.setProperty('--header-bg', '#dddddd');
    } else {
        document.documentElement.style.setProperty('--text-color', '#e0e0e0');
        document.documentElement.style.setProperty('--sidebar-bg', '#161616');
        document.documentElement.style.setProperty('--chat-bg', '#1f1f1f');
        document.documentElement.style.setProperty('--card-bg', '#262626');
        document.documentElement.style.setProperty('--char-msg', '#303030');
        document.documentElement.style.setProperty('--nav-bg', '#161616');
        document.documentElement.style.setProperty('--header-bg', '#121212');
    }
}

function changeLanguage(lang) {
    console.log("Language changed to:", lang);
}

function renderCharacterGrid() {
    const charGrid = document.getElementById('character-grid');
    if (!charGrid) return;

    charGrid.innerHTML = '';
    Object.keys(characters).forEach(id => {
        if (characters[id].enabled) {
            const card = document.createElement('div');
            card.className = 'selectable-card';
            card.innerText = characters[id].name;
            card.onclick = () => loadChat(id);
            charGrid.appendChild(card);
        }
    });
}

function renderCharacterToggles() {
    const container = document.getElementById('character-toggles');
    if (!container) return;

    container.innerHTML = '';
    Object.keys(characters).forEach(id => {
        const item = document.createElement('div');
        item.className = 'toggle-item';
        
        item.innerHTML = `
            <span>${characters[id].name}</span>
            <label class="switch">
                <input type="checkbox" ${characters[id].enabled ? 'checked' : ''} onchange="toggleCharacter('${id}')">
                <span class="slider"></span>
            </label>
        `;
        container.appendChild(item);
    });
}

function toggleCharacter(id) {
    characters[id].enabled = !characters[id].enabled;
    renderCharacterGrid();
}

window.onload = () => {
    renderCharacterGrid();
};
