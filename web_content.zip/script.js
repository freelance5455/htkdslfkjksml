/* =================================================================
   SHILLONG TEER PYRAMID CALCULATOR — script.js
   Pure vanilla JavaScript. No frameworks, no external calls, no API keys.
   Everything runs and stores data entirely on this device.
   ================================================================= */

(function () {
  'use strict';

  var HISTORY_KEY = 'shillongTeerPyramidHistory_v1';
  var MAX_HISTORY = 10;

  // Filled in by init() once the DOM is ready.
  var frInput, srInput, frError, srError, form;
  var pyramidSection, pyramidDisplay, resultsSection, commonRow, actionsSection;
  var historyList, toastEl, howItWorksToggle, howItWorksBody;

  var lastSummaryText = '';

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    frInput = document.getElementById('fr-input');
    srInput = document.getElementById('sr-input');
    frError = document.getElementById('fr-error');
    srError = document.getElementById('sr-error');
    form = document.getElementById('calc-form');

    pyramidSection = document.getElementById('pyramid-section');
    pyramidDisplay = document.getElementById('pyramid-display');
    resultsSection = document.getElementById('results-section');
    commonRow = document.getElementById('common-row');
    actionsSection = document.getElementById('actions-section');

    historyList = document.getElementById('history-list');
    toastEl = document.getElementById('toast');
    howItWorksToggle = document.getElementById('howitworks-toggle');
    howItWorksBody = document.getElementById('howitworks-body');

    attachDigitFilter(frInput);
    attachDigitFilter(srInput);

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      handleCalculate();
    });

    document.getElementById('reset-btn').addEventListener('click', handleReset);
    document.getElementById('copy-btn').addEventListener('click', handleCopySummary);
    document.getElementById('clear-history-btn').addEventListener('click', handleClearHistory);
    howItWorksToggle.addEventListener('click', toggleHowItWorks);

    renderHistory(loadHistory());
  }

  /* ---------------------------------------------------------------
     Input handling — keeps only digits, max 2 characters, and
     pads a single typed digit back to two characters (e.g. "5" -> "05")
     so leading zeros are never lost.
     --------------------------------------------------------------- */
  function attachDigitFilter(input) {
    input.addEventListener('input', function () {
      input.value = input.value.replace(/[^0-9]/g, '').slice(0, 2);
    });
    input.addEventListener('blur', function () {
      if (input.value.length === 1) {
        input.value = '0' + input.value;
      }
    });
  }

  function validateRound(value, label) {
    if (!value) {
      return { valid: false, message: label + ' is required.' };
    }
    if (!/^[0-9]{2}$/.test(value)) {
      return { valid: false, message: 'Enter exactly 2 digits, like 05.' };
    }
    return { valid: true, message: '' };
  }

  /* ---------------------------------------------------------------
     Calculate
     --------------------------------------------------------------- */
  function handleCalculate() {
    // Safety net in case blur didn't fire before submit (e.g. fast Enter key)
    if (frInput.value.length === 1) frInput.value = '0' + frInput.value;
    if (srInput.value.length === 1) srInput.value = '0' + srInput.value;

    var frCheck = validateRound(frInput.value, 'First Round');
    var srCheck = validateRound(srInput.value, 'Second Round');

    frError.textContent = frCheck.valid ? '' : frCheck.message;
    srError.textContent = srCheck.valid ? '' : srCheck.message;
    frInput.classList.toggle('invalid', !frCheck.valid);
    srInput.classList.toggle('invalid', !srCheck.valid);

    if (!frCheck.valid || !srCheck.valid) {
      return;
    }

    var data = computePyramidData(frInput.value, srInput.value);

    renderPyramid(data);
    renderResults(data);

    pyramidSection.classList.remove('hidden');
    resultsSection.classList.remove('hidden');
    actionsSection.classList.remove('hidden');
    triggerReveal(pyramidSection);
    triggerReveal(resultsSection);

    lastSummaryText = buildSummaryText(data);

    saveToHistory(data);
  }

  /* ---------------------------------------------------------------
     Core deterministic math.
     Row 1 (base): the four entered digits, F1 F2 S1 S2.
     Row 2: adjacent-pair sums of Row 1, mod 10 (3 digits).
     Row 3: adjacent-pair sums of Row 2, mod 10 (2 digits).
     Apex : sum of Row 3, mod 10 (1 digit).
     Quick Digit Sum: sum of all four base digits, mod 10.
     Common House/Ending: only set when the two rounds genuinely match.
     --------------------------------------------------------------- */
  function computePyramidData(fr, sr) {
    var f1 = Number(fr[0]);
    var f2 = Number(fr[1]);
    var s1 = Number(sr[0]);
    var s2 = Number(sr[1]);

    var row1 = [f1, f2, s1, s2];
    var row2 = [(f1 + f2) % 10, (f2 + s1) % 10, (s1 + s2) % 10];
    var row3 = [(row2[0] + row2[1]) % 10, (row2[1] + row2[2]) % 10];
    var apex = (row3[0] + row3[1]) % 10;
    var quickSum = (f1 + f2 + s1 + s2) % 10;

    return {
      fr: fr,
      sr: sr,
      f1: f1, f2: f2, s1: s1, s2: s2,
      rows: [row1, row2, row3, [apex]],
      apex: apex,
      quickSum: quickSum,
      commonHouse: (f1 === s1) ? f1 : null,
      commonEnding: (f2 === s2) ? f2 : null,
      timestamp: Date.now()
    };
  }

  /* ---------------------------------------------------------------
     Rendering
     --------------------------------------------------------------- */
  function renderPyramid(data) {
    pyramidDisplay.innerHTML = '';

    var labels = ['Apex', 'Row 3', 'Row 2', 'Base (FR + SR digits)'];
    var rowsTopToBottom = [data.rows[3], data.rows[2], data.rows[1], data.rows[0]];

    rowsTopToBottom.forEach(function (rowDigits, idx) {
      var rowEl = document.createElement('div');
      rowEl.className = 'pyramid-row';

      if (idx === 3) {
        rowEl.classList.add('pyramid-row-base');
      } else {
        rowEl.classList.add('pyramid-row-derived');
      }
      if (idx === 0) {
        rowEl.classList.add('pyramid-row-apex');
      }

      rowDigits.forEach(function (digit) {
        var tile = document.createElement('span');
        tile.className = 'pyramid-tile';
        tile.textContent = String(digit);
        rowEl.appendChild(tile);
      });

      var labelEl = document.createElement('span');
      labelEl.className = 'row-label';
      labelEl.textContent = labels[idx];

      var wrap = document.createElement('div');
      wrap.className = 'pyramid-row-wrap';
      wrap.appendChild(rowEl);
      wrap.appendChild(labelEl);

      pyramidDisplay.appendChild(wrap);
    });
  }

  function renderResults(data) {
    document.getElementById('fr-house-value').textContent = data.f1;
    document.getElementById('fr-ending-value').textContent = data.f2;
    document.getElementById('sr-house-value').textContent = data.s1;
    document.getElementById('sr-ending-value').textContent = data.s2;
    document.getElementById('apex-value').textContent = data.apex;
    document.getElementById('quicksum-value').textContent = data.quickSum;

    commonRow.innerHTML = '';
    var hasCommon = false;

    if (data.commonHouse !== null) {
      hasCommon = true;
      commonRow.appendChild(buildCommonChip('Common house digit', data.commonHouse));
    }
    if (data.commonEnding !== null) {
      hasCommon = true;
      commonRow.appendChild(buildCommonChip('Common ending digit', data.commonEnding));
    }
    if (!hasCommon) {
      var note = document.createElement('p');
      note.className = 'common-none';
      note.textContent = 'No matching house or ending digit between the two rounds this time.';
      commonRow.appendChild(note);
    }
  }

  function buildCommonChip(label, value) {
    var chip = document.createElement('div');
    chip.className = 'result-chip common-chip';

    var val = document.createElement('span');
    val.className = 'chip-value';
    val.textContent = String(value);

    var lab = document.createElement('span');
    lab.className = 'chip-label';
    lab.textContent = label;

    chip.appendChild(val);
    chip.appendChild(lab);
    return chip;
  }

  function triggerReveal(el) {
    el.classList.remove('reveal');
    // Force a reflow so the animation can restart on repeated calculations.
    void el.offsetWidth;
    el.classList.add('reveal');
  }

  /* ---------------------------------------------------------------
     Summary text (used by Copy Summary)
     --------------------------------------------------------------- */
  function buildSummaryText(data) {
    var lines = [];
    lines.push('Shillong Teer Pyramid Calculator');
    lines.push('First Round: ' + data.fr + '   Second Round: ' + data.sr);
    lines.push('FR House/Ending: ' + data.f1 + ' / ' + data.f2);
    lines.push('SR House/Ending: ' + data.s1 + ' / ' + data.s2);
    if (data.commonHouse !== null) {
      lines.push('Common House Digit: ' + data.commonHouse);
    }
    if (data.commonEnding !== null) {
      lines.push('Common Ending Digit: ' + data.commonEnding);
    }
    lines.push('Pyramid Apex Digit: ' + data.apex);
    lines.push('Quick Digit Sum: ' + data.quickSum);
    lines.push('(Mathematical pattern analysis only - not a prediction or guarantee.)');
    return lines.join('\n');
  }

  /* ---------------------------------------------------------------
     Reset — clears the form and hides results, but keeps history.
     --------------------------------------------------------------- */
  function handleReset() {
    frInput.value = '';
    srInput.value = '';
    frError.textContent = '';
    srError.textContent = '';
    frInput.classList.remove('invalid');
    srInput.classList.remove('invalid');

    pyramidSection.classList.add('hidden');
    resultsSection.classList.add('hidden');
    actionsSection.classList.add('hidden');
    pyramidDisplay.innerHTML = '';

    frInput.focus();
  }

  /* ---------------------------------------------------------------
     Copy Summary — Clipboard API with an execCommand fallback for
     older WebViews (important for an app wrapped into an APK).
     --------------------------------------------------------------- */
  function handleCopySummary() {
    if (!lastSummaryText) return;

    copyText(lastSummaryText).then(function () {
      showToast('Summary copied');
    }).catch(function () {
      showToast('Could not copy - select and copy manually');
    });
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        var ok = document.execCommand('copy');
        document.body.removeChild(ta);
        if (ok) {
          resolve();
        } else {
          reject(new Error('execCommand copy failed'));
        }
      } catch (err) {
        reject(err);
      }
    });
  }

  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    window.clearTimeout(showToast._timer);
    showToast._timer = window.setTimeout(function () {
      toastEl.classList.remove('show');
    }, 2200);
  }

  /* ---------------------------------------------------------------
     History (localStorage) — keeps at most the last 10 calculations.
     --------------------------------------------------------------- */
  function loadHistory() {
    try {
      var raw = window.localStorage.getItem(HISTORY_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (err) {
      return [];
    }
  }

  function saveToHistory(data) {
    var history = loadHistory();
    history.unshift({
      fr: data.fr,
      sr: data.sr,
      commonHouse: data.commonHouse,
      commonEnding: data.commonEnding,
      apex: data.apex,
      quickSum: data.quickSum,
      timestamp: data.timestamp
    });
    history = history.slice(0, MAX_HISTORY);

    try {
      window.localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    } catch (err) {
      // Storage unavailable (e.g. private mode) - continue without saving.
    }

    renderHistory(history);
  }

  function renderHistory(history) {
    historyList.innerHTML = '';

    if (!history || history.length === 0) {
      var empty = document.createElement('li');
      empty.className = 'history-empty';
      empty.id = 'history-empty';
      empty.textContent = 'No calculations yet. Run your first one above.';
      historyList.appendChild(empty);
      return;
    }

    history.forEach(function (item) {
      var li = document.createElement('li');
      li.className = 'history-item';

      var main = document.createElement('div');
      main.className = 'history-main';

      var pair = document.createElement('span');
      pair.className = 'history-pair';
      pair.textContent = item.fr + ' \u2192 ' + item.sr;

      var time = document.createElement('span');
      time.className = 'history-time';
      time.textContent = formatTimestamp(item.timestamp);

      main.appendChild(pair);
      main.appendChild(time);

      var tags = document.createElement('div');
      tags.className = 'history-tags';
      tags.appendChild(makeTag('Apex ' + item.apex, false));

      if (item.commonHouse !== null && item.commonHouse !== undefined) {
        tags.appendChild(makeTag('House ' + item.commonHouse, true));
      }
      if (item.commonEnding !== null && item.commonEnding !== undefined) {
        tags.appendChild(makeTag('Ending ' + item.commonEnding, true));
      }

      li.appendChild(main);
      li.appendChild(tags);
      historyList.appendChild(li);
    });
  }

  function makeTag(text, highlight) {
    var span = document.createElement('span');
    span.className = 'history-tag' + (highlight ? ' history-tag-highlight' : '');
    span.textContent = text;
    return span;
  }

  function formatTimestamp(ts) {
    var d = new Date(ts);
    var day = String(d.getDate()).padStart(2, '0');
    var month = String(d.getMonth() + 1).padStart(2, '0');
    var hours = d.getHours();
    var minutes = String(d.getMinutes()).padStart(2, '0');
    var ampm = hours >= 12 ? 'PM' : 'AM';
    var h12 = hours % 12 || 12;
    return day + '/' + month + ' ' + h12 + ':' + minutes + ' ' + ampm;
  }

  function handleClearHistory() {
    var confirmed = window.confirm('Clear all saved calculations? This cannot be undone.');
    if (!confirmed) return;

    try {
      window.localStorage.removeItem(HISTORY_KEY);
    } catch (err) {
      // ignore
    }
    renderHistory([]);
    showToast('History cleared');
  }

  /* ---------------------------------------------------------------
     "How this works" disclosure panel
     --------------------------------------------------------------- */
  function toggleHowItWorks() {
    var expanded = howItWorksToggle.getAttribute('aria-expanded') === 'true';
    howItWorksToggle.setAttribute('aria-expanded', String(!expanded));
    howItWorksBody.hidden = expanded;
  }

})();
