/* =========================
   بخش اصلاح‌شده لیست خرید
   قیمت واردشده = مبلغ واقعی خرید
   ========================= */

function renderShopping(){

    const order = {
        high: 0,
        med: 1,
        low: 2
    };

    const a = db.shopping
        .slice()
        .sort(
            (x, y) =>
                (order[x.priority] ?? 9) -
                (order[y.priority] ?? 9)
        );

    $('shoppingList').innerHTML =
        a.length
        ?
        a.map(x => {

            /* 
               مهم:
               قیمت دقیقاً همان مبلغی است
               که کاربر هنگام ثبت خرید وارد کرده.
               دیگر در تعداد ضرب نمی‌شود.
            */
            const price = Number(x.price) || 0;

            return `

            <div class="item">

                <div class="between">

                    <b>
                        ${esc(x.title)}
                    </b>

                    <span class="badge ${x.priority}">

                        ${
                            x.priority === 'high'
                            ?
                            'ضروری'
                            :
                            x.priority === 'med'
                            ?
                            'مهم'
                            :
                            'معمولی'
                        }

                    </span>

                </div>


                <div style="margin-top:8px">

                    <b class="green">
                        مبلغ خرید:
                        ${money(price)}
                    </b>

                </div>


                <div class="muted" style="margin-top:5px">

                    تعداد:
                    ${fa(x.qty || 1)}
                    عدد

                    ${
                        x.date
                        ?
                        ' · تاریخ موردنیاز: ' +
                        fmtDate(x.date)
                        :
                        ''
                    }

                    ·

                    ${
                        x.status === 'bought'
                        ?
                        'خرید شده'
                        :
                        'خرید نشده'
                    }

                </div>


                ${
                    x.note
                    ?
                    `
                    <div style="margin-top:6px">
                        ${esc(x.note)}
                    </div>
                    `
                    :
                    ''
                }


                ${buttons('shopping', x.id)}

            </div>

            `;

        }).join('')

        :

        '<div class="empty">لیست خرید خالی است.</div>';
}


/* =========================
   ثبت خرید
   ========================= */

$('shoppingForm').onsubmit = e => {

    e.preventDefault();

    const id =
        $('shoppingId').value || uid();

    const price =
        Number(
            normalizeDigits(
                $('shoppingPrice').value
            )
        ) || 0;

    const qty =
        Number(
            normalizeDigits(
                $('shoppingQty').value
            )
        ) || 1;

    saveForm(
        'shopping',
        {
            id,

            title:
                $('shoppingTitle').value,

            /* تعداد فقط تعداد کالا است */
            qty: qty,

            /* قیمت واقعی خرید */
            price: price,

            priority:
                $('shoppingPriority').value,

            date:
                normalizeDigits(
                    $('shoppingDate').value
                ),

            status:
                $('shoppingStatus').value,

            note:
                $('shoppingNote').value
        }
    );

    resetForm('shoppingForm');
};


/* =========================
   نمایش خریدهای مهم در داشبورد
   ========================= */

function renderDashboard(){

    const income =
        db.incomes.reduce(
            (s, x) =>
                s +
                (
                    x.status === 'paid'
                    ?
                    Number(x.amount) || 0
                    :
                    0
                ),
            0
        );

    const due =
        db.incomes.reduce(
            (s, x) =>
                s +
                (
                    x.status !== 'paid'
                    ?
                    Number(x.amount) || 0
                    :
                    0
                ),
            0
        );

    const exp =
        db.expenses.reduce(
            (s, x) =>
                s +
                (Number(x.amount) || 0),
            0
        );

    const owe =
        db.debts
        .filter(
            x =>
                x.status !== 'paid' &&
                x.type === 'owe'
        )
        .reduce(
            (s, x) =>
                s +
                (Number(x.amount) || 0),
            0
        );

    const rec =
        db.debts
        .filter(
            x =>
                x.status !== 'paid' &&
                x.type === 'receivable'
        )
        .reduce(
            (s, x) =>
                s +
                (Number(x.amount) || 0),
            0
        );


    $('sIncome').textContent =
        money(income);

    $('sExpense').textContent =
        money(exp);

    $('sBalance').textContent =
        money(income - exp);

    $('sDebt').textContent =
        money(owe - rec);


    /* یادآوری‌های نزدیک */

    let rr =
        db.reminders
        .map(
            x => ({
                x,
                d: daysUntil(
                    x.date,
                    x.time
                )
            })
        )
        .filter(
            z =>
                z.d !== null &&
                z.d >= 0 &&
                z.d <= z.x.alert
        )
        .sort(
            (a, b) =>
                a.d - b.d
        )
        .slice(0, 5);


    $('dashReminders').innerHTML =
        rr.length
        ?
        rr.map(
            z => `

            <div class="item">

                <b>
                    ${esc(z.x.title)}
                </b>

                <div class="muted">

                    ${
                        z.d === 0
                        ?
                        'امروز'
                        :
                        fa(z.d) +
                        ' روز دیگر'
                    }

                    ·

                    ${fmtDate(z.x.date)}

                </div>

            </div>

            `
        ).join('')

        :

        '<div class="empty">مورد نزدیک ندارید.</div>';


    /* =========================
       خریدهای ضروری
       ========================= */

    let sh =
        db.shopping
        .filter(
            x =>
                x.status === 'todo' &&
                x.priority === 'high'
        )
        .slice(0, 5);


    $('dashShopping').innerHTML =
        sh.length
        ?
        sh.map(
            x => `

            <div class="item">

                <div class="between">

                    <b>
                        ${esc(x.title)}
                    </b>

                </div>

            </div>
            `
        ).join('')
        :
        '<div class="empty">موردی نیست</div>';
}
