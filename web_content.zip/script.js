// ===============================
// ChatSBD — Galaxy LCD
// ===============================

// 1. CẤU HÌNH NHIỀU NHÀ CUNG CẤP API
const API_KEY_STORAGE = "chatsbd_api_key_v1";
const PROVIDER_STORAGE = "chatsbd_provider_v1";
const API_KEYS_STORAGE = "chatsbd_provider_keys_v1";
const PROVIDERS = {
  gemini: { name: "Google Gemini", model: "gemini-2.5-flash" },
  openai: { name: "OpenAI", model: "gpt-4o-mini" },
  anthropic: { name: "Anthropic Claude", model: "claude-3-5-haiku-latest" },
  groq: { name: "Groq", model: "llama-3.3-70b-versatile" },
  openrouter: { name: "OpenRouter", model: "nvidia/nemotron-3.5-lightning:free" }
};
let PROVIDER = (() => {
  try { return localStorage.getItem(PROVIDER_STORAGE) || "gemini"; } catch { return "gemini"; }
})();
if (!PROVIDERS[PROVIDER]) PROVIDER = "gemini";
function getProviderKeys() {
  try {
    const keys = JSON.parse(localStorage.getItem(API_KEYS_STORAGE) || "{}");
    if (!keys.gemini && localStorage.getItem(API_KEY_STORAGE)) keys.gemini = localStorage.getItem(API_KEY_STORAGE);
    return keys;
  } catch { return { gemini: localStorage.getItem(API_KEY_STORAGE) || "" }; }
}
function getApiKey() { return getProviderKeys()[PROVIDER] || ""; }
function saveProviderKey(provider, key) {
  const keys = getProviderKeys(); keys[provider] = key;
  localStorage.setItem(API_KEYS_STORAGE, JSON.stringify(keys));
  localStorage.setItem(PROVIDER_STORAGE, provider);
  if (provider === "gemini") localStorage.setItem(API_KEY_STORAGE, key);
  PROVIDER = provider;
}
function getApiUrl(provider = PROVIDER) {
  if (provider === "gemini") return `https://generativelanguage.googleapis.com/v1beta/models/${PROVIDERS[provider].model}:generateContent`;
  if (provider === "openai") return "https://api.openai.com/v1/chat/completions";
  if (provider === "groq") return "https://api.groq.com/openai/v1/chat/completions";
  if (provider === "openrouter") return "https://openrouter.ai/api/v1/chat/completions";
  return "https://api.anthropic.com/v1/messages";
}

// 2. LẤY CÁC THÀNH PHẦN GIAO DIỆN
const $ = (selector) => document.querySelector(selector);

// Đồng bộ chiều cao khung ứng dụng với vùng nhìn thực tế trên điện thoại,
// kể cả khi thanh trình duyệt thay đổi hoặc bàn phím ảo mở.
(function syncAppViewport() {
  const updateAppHeight = () => {
    const height = window.visualViewport
      ? window.visualViewport.height
      : window.innerHeight;
    document.documentElement.style.setProperty("--app-height", `${height}px`);
  };
  updateAppHeight();
  window.addEventListener("resize", updateAppHeight, { passive: true });
  window.addEventListener("orientationchange", updateAppHeight, { passive: true });
  if (window.visualViewport) {
    window.visualViewport.addEventListener("resize", updateAppHeight, { passive: true });
    window.visualViewport.addEventListener("scroll", updateAppHeight, { passive: true });
  }
})();

const chat = $("#chat");
const messages = $("#messages");
const welcome = $("#welcome");
const form = $("#bar");
const input = $("#message");
const sendButton = $("#sendButton");
const thinking = $("#thinking");

const menuToggle = $("#menuToggle");
const sidePanel = $("#sidePanel");
const panelScrim = $("#panelScrim");
const closeMenu = $("#closeMenu");
const historyList = $("#historyList");
const newChatButton = $("#newChat");
const newChatTop = $("#newChatTop");
const clearChatButton = $("#clearChat");
const animationToggle = $("#spaceAnimationToggle");
const animationStatus = $("#animationStatus");
const apiModal = $("#apiModal");
const apiForm = $("#apiForm");
const apiKeyInput = $("#apiKeyInput");
const apiProviderSelect = $("#apiProvider");
const apiError = $("#apiError");
const apiSubmit = $("#apiSubmit");
const toggleApiKey = $("#toggleApiKey");
const openApiStatusButton = $("#openApiStatus");
const apiStatusModal = $("#apiStatusModal");
const closeApiStatusButton = $("#closeApiStatus");
const apiStatusDot = $("#apiStatusDot");
const apiStatusLabel = $("#apiStatusLabel");
const apiStatusMessage = $("#apiStatusMessage");
const refreshApiStatusButton = $("#refreshApiStatus");
const replaceApiButton = $("#replaceApiButton");

function openApiStatusPanel() {
  apiStatusModal.hidden = false;
  $("#apiStatusTitle").textContent = "API Status · " + (PROVIDERS[PROVIDER]?.name || "API");
  checkSavedApiStatus();
}
function closeApiStatusPanel() { apiStatusModal.hidden = true; }
function renderSavedApiStatus(state, message) {
  apiStatusDot.dataset.state = state;
  apiStatusLabel.textContent = state === "ok" ? "API đang hoạt động" : state === "error" ? "API không hoạt động" : "Đang kiểm tra…";
  apiStatusMessage.textContent = message;
}
async function checkSavedApiStatus() {
  const key = getApiKey();
  if (!key) {
    renderSavedApiStatus("error", "Vui lòng lấy một API mới rồi nhập vào ChatSBD.");
    return;
  }
  refreshApiStatusButton.disabled = true;
  refreshApiStatusButton.textContent = "Đang kiểm tra…";
  renderSavedApiStatus("checking", "Đang kiểm tra trạng thái API mới nhất…");
  try {
    await validateApiKey(key);
    renderSavedApiStatus("ok", "API vẫn hoạt động và có thể sử dụng.");
  } catch (error) {
    renderSavedApiStatus("error", "Vui lòng lấy một API mới.");
  } finally {
    refreshApiStatusButton.disabled = false;
    refreshApiStatusButton.textContent = "Refresh";
  }
}
openApiStatusButton.addEventListener("click", openApiStatusPanel);
closeApiStatusButton.addEventListener("click", closeApiStatusPanel);
apiStatusModal.addEventListener("click", event => { if (event.target === apiStatusModal) closeApiStatusPanel(); });
refreshApiStatusButton.addEventListener("click", checkSavedApiStatus);
replaceApiButton.addEventListener("click", () => {
  closeApiStatusPanel();
  showApiModal();
});

function showApiModal(message = "") {
  apiProviderSelect.value = PROVIDER;
  apiKeyInput.value = getApiKey();
  apiModal.hidden = false;
  apiError.textContent = message;
  apiError.hidden = !message;
  apiSubmit.disabled = false;
  apiSubmit.textContent = "Nhập API";
  setTimeout(() => apiKeyInput.focus(), 50);
}

function hideApiModal() {
  apiModal.hidden = true;
  apiError.hidden = true;
  apiError.textContent = "";
}

function explainApiError(status, message = "") {
  const detail = String(message || "").trim();
  if (status === 400) return "API key không hợp lệ hoặc yêu cầu bị từ chối. Hãy kiểm tra key rồi thử lại.";
  if (status === 401 || status === 403) return "API key không hợp lệ hoặc chưa được cấp quyền. Hãy kiểm tra key và quyền truy cập.";
  if (status === 404) return "Không tìm thấy model đang cấu hình. Lỗi này không nhất thiết do API key.";
  if (status === 429) return "API đã hết hạn mức hoặc vượt giới hạn tần suất (429). Hãy đợi quota được làm mới hoặc kiểm tra hạn mức; nhập key mới không phải lúc nào cũng giải quyết được.";
  return "API gặp lỗi (" + status + "). " + detail;
}

async function validateApiKey(key, provider = PROVIDER) {
  const url = getApiUrl(provider);
  const headers = { "Content-Type": "application/json" };
  let body;
  if (provider === "gemini") {
    body = { contents: [{ role: "user", parts: [{ text: "Reply only OK" }] }], generationConfig: { maxOutputTokens: 8, temperature: 0 } };
  } else if (provider === "anthropic") {
    Object.assign(headers, { "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" });
    body = { model: PROVIDERS[provider].model, max_tokens: 8, messages: [{ role: "user", content: "Reply only OK" }] };
  } else {
    headers.Authorization = `Bearer ${key}`;
    body = { model: PROVIDERS[provider].model, messages: [{ role: "user", content: "Reply only OK" }], max_tokens: 8 };
  }
  const response = await fetch(provider === "gemini" ? `${url}?key=${encodeURIComponent(key)}` : url, {
    method: "POST", headers, body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`Không xác minh được ${PROVIDERS[provider].name} (${response.status}). ${data?.error?.message || "Kiểm tra API key, quyền truy cập hoặc quota."}`);
  if (provider === "gemini" && !data?.candidates?.length) throw new Error("API chưa trả về phản hồi hợp lệ.");
  if (provider === "anthropic" && !data?.content?.length) throw new Error("API chưa trả về phản hồi hợp lệ.");
  if (["openai", "groq", "openrouter"].includes(provider) && !data?.choices?.length) throw new Error("API chưa trả về phản hồi hợp lệ.");
}

apiForm.addEventListener("submit", async event => {
  event.preventDefault();
  const candidate = apiKeyInput.value.trim();
  const candidateProvider = apiProviderSelect.value;
  if (!candidate) {
    apiError.textContent = "Vui lòng nhập API key.";
    apiError.hidden = false;
    return;
  }

  apiSubmit.disabled = true;
  apiSubmit.textContent = "Đang kiểm tra…";
  apiError.hidden = true;

  try {
    await validateApiKey(candidate, candidateProvider);
    saveProviderKey(candidateProvider, candidate);
    API_KEY = candidate;
    apiKeyInput.value = "";
    hideApiModal();
  } catch (error) {
    apiError.textContent = error.message || "Không thể xác minh API key.";
    apiError.hidden = false;
  } finally {
    apiSubmit.disabled = false;
    apiSubmit.textContent = "Nhập API";
  }
});



apiProviderSelect.addEventListener("change", () => {
  PROVIDER = apiProviderSelect.value;
  apiKeyInput.value = getApiKey();
  apiKeyInput.placeholder = `Dán API key của ${PROVIDERS[PROVIDER].name}`;
});

toggleApiKey.addEventListener("click", () => {
  const showing = apiKeyInput.type === "text";
  apiKeyInput.type = showing ? "password" : "text";
  toggleApiKey.textContent = showing ? "Hiện" : "Ẩn";
  toggleApiKey.setAttribute("aria-label", showing ? "Hiện API key" : "Ẩn API key");
});


// 3. DỮ LIỆU VÀ LƯU LỊCH SỬ
// Lưu trên trình duyệt của thiết bị đang sử dụng.
const STORAGE_KEY = "chatsbd_galaxy_history_v1";
const SETTINGS_KEY = "chatsbd_galaxy_settings_v1";
const MAX_CHATS = 30;
const MAX_HISTORY_MESSAGES = 80;

let conversations = loadConversations();
let currentChatId = null;
let busy = false;

function makeId() {
  return Date.now().toString(36) +
    Math.random().toString(36).slice(2, 8);
}

function loadConversations() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!Array.isArray(saved)) return [];

    return saved
      .filter(item =>
        item &&
        typeof item.id === "string" &&
        Array.isArray(item.messages)
      )
      .map(item => ({
        id: item.id,
        title: String(item.title || "Cuộc trò chuyện mới"),
        updatedAt: Number(item.updatedAt) || Date.now(),
        messages: item.messages
          .filter(m =>
            m &&
            (m.role === "user" || m.role === "model") &&
            typeof m.text === "string"
          )
          .slice(-MAX_HISTORY_MESSAGES)
      }))
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, MAX_CHATS);
  } catch (error) {
    console.warn("Không thể đọc lịch sử:", error);
    return [];
  }
}

function saveConversations() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(conversations.slice(0, MAX_CHATS))
    );
    return true;
  } catch (error) {
    console.warn("Không thể lưu lịch sử:", error);
    return false;
  }
}

function getCurrentChat() {
  return conversations.find(c => c.id === currentChatId) || null;
}

function createConversation() {
  const conversation = {
    id: makeId(),
    title: "Cuộc trò chuyện mới",
    updatedAt: Date.now(),
    messages: []
  };

  conversations.unshift(conversation);
  currentChatId = conversation.id;

  conversations = conversations.slice(0, MAX_CHATS);
  saveConversations();
  renderHistory();
  renderConversation();
  hideMenu();

  input.value = "";
  resizeInput();
  input.focus();

  return conversation;
}

function ensureConversation() {
  return getCurrentChat() || createConversation();
}

function updateConversation(conversation) {
  conversation.updatedAt = Date.now();

  conversations.sort((a, b) => b.updatedAt - a.updatedAt);
  conversations = conversations.slice(0, MAX_CHATS);

  saveConversations();
  renderHistory();
}

function formatDate(timestamp) {
  try {
    return new Date(timestamp).toLocaleString("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch {
    return "";
  }
}

function makeTitle(text) {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length > 34 ? clean.slice(0, 34) + "…" : clean;
}

// 4. HIỂN THỊ LỊCH SỬ
function renderHistory() {
  historyList.replaceChildren();

  if (conversations.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-history";
    empty.textContent = "Chưa có cuộc trò chuyện nào.";
    historyList.appendChild(empty);
    return;
  }

  conversations.forEach(conversation => {
    const row = document.createElement("div");
    row.className = "history-item";

    const openButton = document.createElement("button");
    openButton.className =
      "history-open" +
      (conversation.id === currentChatId ? " active" : "");
    openButton.type = "button";

    const title = document.createElement("span");
    title.className = "history-title";
    title.textContent = conversation.title;

    const date = document.createElement("span");
    date.className = "history-date";
    date.textContent = formatDate(conversation.updatedAt);

    openButton.append(title, date);
    openButton.addEventListener("click", () => {
      if (busy) return;
      currentChatId = conversation.id;
      renderHistory();
      renderConversation();
      hideMenu();
    });

    const deleteButton = document.createElement("button");
    deleteButton.className = "history-delete";
    deleteButton.type = "button";
    deleteButton.textContent = "✕";
    deleteButton.setAttribute("aria-label", "Xóa " + conversation.title);

    deleteButton.addEventListener("click", () => {
      if (busy) return;

      const confirmed = confirm(
        `Xóa cuộc trò chuyện "${conversation.title}"?`
      );
      if (!confirmed) return;

      conversations = conversations.filter(
        c => c.id !== conversation.id
      );

      if (currentChatId === conversation.id) {
        currentChatId = null;
      }

      saveConversations();
      renderHistory();

      if (!getCurrentChat()) {
        if (conversations.length) {
          currentChatId = conversations[0].id;
        } else {
          createConversation();
          return;
        }
      }

      renderConversation();
    });

    row.append(openButton, deleteButton);
    historyList.appendChild(row);
  });
}

// 5. HIỂN THỊ TIN NHẮN
function addMessage(role, text, options = {}) {
  const wrapper = document.createElement("article");
  wrapper.className = "msg " + (role === "user" ? "user" : "assistant");

  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "●" : "✦";
  avatar.setAttribute("aria-hidden", "true");

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  if (options.error) bubble.classList.add("error");

  wrapper.append(avatar, bubble);
  messages.appendChild(wrapper);

  scrollToBottom();
  return wrapper;
}

function renderConversation() {
  messages.replaceChildren();

  const conversation = getCurrentChat();
  const hasMessages = !!conversation && conversation.messages.length > 0;

  welcome.hidden = hasMessages;

  if (conversation) {
    conversation.messages.forEach(message => {
      addMessage(message.role, message.text);
    });
  }

  scrollToBottom();
}

function scrollToBottom() {
  requestAnimationFrame(() => {
    chat.scrollTop = chat.scrollHeight;
  });
}

function setBusy(value) {
  busy = value;
  sendButton.disabled = value;
  input.disabled = value;
  thinking.hidden = !value;
  sendButton.textContent = value ? "…" : "➤";
  sendButton.setAttribute(
    "aria-label",
    value ? "Đang gửi tin nhắn" : "Gửi tin nhắn"
  );
}

function addToConversation(role, text) {
  const conversation = ensureConversation();

  conversation.messages.push({ role, text });
  conversation.messages =
    conversation.messages.slice(-MAX_HISTORY_MESSAGES);

  if (role === "user" && conversation.title === "Cuộc trò chuyện mới") {
    conversation.title = makeTitle(text);
  }

  updateConversation(conversation);
  return conversation;
}

// 6. GỌI GEMINI API
async function askGemini(conversation) {
  API_KEY = getApiKey();
  if (!API_KEY) {
    apiProviderSelect.value = PROVIDER;
    showApiModal();
    throw new Error("Bạn cần nhập API key cho nhà cung cấp đang chọn.");
  }
  const provider = PROVIDER;
  const url = getApiUrl(provider);
  const systemText = "Bạn là ChatSBD, trợ lý AI thân thiện, hữu ích. Trả lời bằng tiếng Việt khi phù hợp. Trình bày rõ ràng, dễ hiểu.";
  const history = conversation.messages;
  const headers = { "Content-Type": "application/json" };
  let body;
  if (provider === "gemini") {
    body = {
      systemInstruction: { parts: [{ text: systemText }] },
      contents: history.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
      generationConfig: { temperature: 0.8, topP: 0.95, maxOutputTokens: 4096 }
    };
    headers["x-goog-api-key"] = API_KEY;
  } else if (provider === "anthropic") {
    Object.assign(headers, { "x-api-key": API_KEY, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" });
    body = { model: PROVIDERS[provider].model, max_tokens: 4096, system: systemText,
      messages: history.map(m => ({ role: m.role === "model" ? "assistant" : "user", content: m.text })) };
  } else {
    headers.Authorization = `Bearer ${API_KEY}`;
    body = { model: PROVIDERS[provider].model,
      messages: [{ role: "system", content: systemText }, ...history.map(m => ({ role: m.role === "model" ? "assistant" : "user", content: m.text }))],
      temperature: 0.8, max_tokens: 4096 };
  }
  const response = await fetch(provider === "gemini" ? `${url}?key=${encodeURIComponent(API_KEY)}` : url,
    { method: "POST", headers, body: JSON.stringify(body) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const msg = data?.error?.message || data?.message || "Không nhận được phản hồi hợp lệ.";
    if ([400, 401, 403].includes(response.status)) showApiModal(`API ${PROVIDERS[provider].name} bị từ chối (${response.status}). Kiểm tra key/quyền truy cập.`);
    throw new Error(`Lỗi ${PROVIDERS[provider].name} (${response.status}): ${msg}`);
  }
  let answer = "";
  if (provider === "gemini") answer = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim() || "";
  else if (provider === "anthropic") answer = data?.content?.map(p => p.text || "").join("").trim() || "";
  else answer = data?.choices?.[0]?.message?.content?.trim() || "";
  if (!answer) throw new Error(`${PROVIDERS[provider].name} không trả về nội dung. Hãy thử lại.`);
  return answer;
}

// 7. GỬI TIN NHẮN
async function sendMessage(text) {
  const prompt = text.trim();
  if (!prompt || busy) return;

  const conversation = ensureConversation();

  welcome.hidden = true;
  addToConversation("user", prompt);
  addMessage("user", prompt);

  input.value = "";
  resizeInput();
  setBusy(true);

  try {
    const answer = await askGemini(conversation);
    addToConversation("model", answer);
    addMessage("model", answer);
  } catch (error) {
    console.error(error);

    addMessage(
      "model",
      "Không thể kết nối Gemini.\n\n" +
      (error.message || "Đã xảy ra lỗi không xác định.") +
      "\n\nHãy kiểm tra kết nối mạng, API key và model rồi thử lại.",
      { error: true }
    );
  } finally {
    setBusy(false);
    input.focus();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});

input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

function resizeInput() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 130) + "px";
}

input.addEventListener("input", resizeInput);

// 8. MENU TRƯỢT
function showMenu() {
  sidePanel.classList.add("open");
  panelScrim.classList.add("visible");
  menuToggle.setAttribute("aria-expanded", "true");
}

function hideMenu() {
  sidePanel.classList.remove("open");
  panelScrim.classList.remove("visible");
  menuToggle.setAttribute("aria-expanded", "false");
}

menuToggle.addEventListener("click", () => {
  sidePanel.classList.contains("open") ? hideMenu() : showMenu();
});

closeMenu.addEventListener("click", hideMenu);
panelScrim.addEventListener("click", hideMenu);

document.addEventListener("keydown", event => {
  if (event.key === "Escape") hideMenu();
});

// 9. CUỘC TRÒ CHUYỆN MỚI VÀ XÓA
newChatButton.addEventListener("click", () => {
  if (busy) return;
  createConversation();
});

newChatTop.addEventListener("click", () => {
  if (busy) return;
  createConversation();
});

clearChatButton.addEventListener("click", () => {
  if (busy) return;

  const conversation = getCurrentChat();
  if (!conversation || conversation.messages.length === 0) {
    alert("Cuộc trò chuyện này chưa có tin nhắn.");
    return;
  }

  if (!confirm("Xóa toàn bộ tin nhắn trong cuộc trò chuyện này?")) {
    return;
  }

  conversation.messages = [];
  conversation.title = "Cuộc trò chuyện mới";
  conversation.updatedAt = Date.now();

  saveConversations();
  renderHistory();
  renderConversation();
  hideMenu();
});

// 10. NÚT GỢI Ý
document.querySelectorAll(".suggestion").forEach(button => {
  button.addEventListener("click", () => {
    if (busy) return;
    sendMessage(button.dataset.prompt || button.textContent);
  });
});

// 11. CÀI ĐẶT HIỆU ỨNG
function setAnimation(enabled) {
  document.body.classList.toggle("space-animation-off", !enabled);
  animationToggle.checked = enabled;
  animationStatus.textContent = enabled
    ? "Hiệu ứng đang bật"
    : "Hiệu ứng đã tắt";

  try {
    const settings = JSON.parse(
      localStorage.getItem(SETTINGS_KEY) || "{}"
    );
    settings.animation = enabled;
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.warn("Không thể lưu cài đặt:", error);
  }
}

animationToggle.addEventListener("change", () => {
  setAnimation(animationToggle.checked);
});

// 12. KHỞI ĐỘNG
function init() {
  let animationEnabled = true;

  try {
    const settings = JSON.parse(
      localStorage.getItem(SETTINGS_KEY) || "{}"
    );
    if (typeof settings.animation === "boolean") {
      animationEnabled = settings.animation;
    }
  } catch (error) {
    console.warn("Không thể đọc cài đặt:", error);
  }

  setAnimation(animationEnabled);

  if (conversations.length > 0) {
    currentChatId = conversations[0].id;
  } else {
    const conversation = {
      id: makeId(),
      title: "Cuộc trò chuyện mới",
      updatedAt: Date.now(),
      messages: []
    };
    conversations.unshift(conversation);
    currentChatId = conversation.id;
    saveConversations();
  }

  renderHistory();
  renderConversation();

  if (!API_KEY) showApiModal();
}

init();