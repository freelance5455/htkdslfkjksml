document.addEventListener("DOMContentLoaded", function () {

    let money = 18000;
    let worms = 10;
    let inventory = [];
    let collection = [];

    const screens = document.querySelectorAll(".screen");

    function showScreen(id) {
        screens.forEach(function (screen) {
            screen.classList.remove("active");
        });

        const target = document.getElementById(id);

        if (target) {
            target.classList.add("active");
        }
    }

    // PLAY
    document.getElementById("playBtn").addEventListener("click", function () {
        showScreen("menu");
    });

    // MENU
    document.getElementById("fishMenu").addEventListener("click", function () {
        showScreen("maps");
    });

    document.getElementById("shopMenu").addEventListener("click", function () {
        showScreen("shop");
    });

    document.getElementById("inventoryMenu").addEventListener("click", function () {
        renderInventory();
        showScreen("inventory");
    });

    document.getElementById("collectionMenu").addEventListener("click", function () {
        renderCollection();
        showScreen("collection");
    });

    // MAP
    document.getElementById("lakeBtn").addEventListener("click", function () {
        document.getElementById("mapTitle").textContent = "🏞️ Danau";
        showScreen("fishing");
    });

    document.getElementById("riverBtn").addEventListener("click", function () {
        document.getElementById("mapTitle").textContent = "🌊 Sungai";
        showScreen("fishing");
    });

    document.getElementById("seaBtn").addEventListener("click", function () {
        document.getElementById("mapTitle").textContent = "🚤 Laut";
        showScreen("fishing");
    });

    document.getElementById("backMap").addEventListener("click", function () {
        showScreen("menu");
    });

    document.getElementById("backFishing").addEventListener("click", function () {
        showScreen("maps");
    });

    document.getElementById("backShop").addEventListener("click", function () {
        showScreen("menu");
    });

    document.getElementById("backInventory").addEventListener("click", function () {
        showScreen("menu");
    });

    document.getElementById("backCollection").addEventListener("click", function () {
        showScreen("menu");
    });

    // MANCING
    document.getElementById("fishBtn").addEventListener("click", function () {

        const button = document.getElementById("fishBtn");
        const status = document.getElementById("fishStatus");

        if (worms <= 0) {
            status.textContent = "🪱 Cacing habis!";
            return;
        }

        worms--;

        button.disabled = true;
        button.textContent = "⏳ MENUNGGU...";
        status.textContent = "Ikan sedang mendekat...";

        setTimeout(function () {

            const fish = {
                name: "Ikan Nila",
                rarity: "Common",
                price: 600
            };

            inventory.push(fish);

            if (!collection.includes(fish.name)) {
                collection.push(fish.name);
            }

            status.textContent =
                "🎉 Dapat " + fish.name + "!";

            button.disabled = false;
            button.textContent = "🎣 MANCING";

            updateMoney();

        }, 3000);
    });

    // BELI CACING
    document.getElementById("buyWormBtn").addEventListener("click", function () {

        if (money < 1000) {
            alert("Uang tidak cukup!");
            return;
        }

        money -= 1000;
        worms += 10;

        updateMoney();
        updateWorms();
    });

    // JUAL SEMUA
    document.getElementById("sellAllBtn").addEventListener("click", function () {

        let total = 0;

        inventory.forEach(function (fish) {
            total += fish.price;
        });

        inventory = [];

        money += total;

        updateMoney();
        renderInventory();

        alert("Terjual! +Rp" + total.toLocaleString("id-ID"));
    });

    function updateMoney() {

        document.querySelectorAll(".money").forEach(function (element) {
            element.textContent =
                "Rp" + money.toLocaleString("id-ID");
        });
    }

    function updateWorms() {
        document.getElementById("wormCount").textContent = worms;
    }

    function renderInventory() {

        const box = document.getElementById("inventoryList");

        box.innerHTML = "";

        if (inventory.length === 0) {
            box.innerHTML = "<p>🎒 Inventory masih kosong.</p>";
            return;
        }

        inventory.forEach(function (fish) {

            const item = document.createElement("div");

            item.className = "fishItem";

            item.textContent =
                "🐟 " +
                fish.name +
                " | " +
                fish.rarity +
                " | Rp" +
                fish.price.toLocaleString("id-ID");

            box.appendChild(item);
        });
    }

    function renderCollection() {

        const box = document.getElementById("collectionList");

        box.innerHTML = "";

        const fishes = [
            "Ikan Nila",
            "Ikan Lele",
            "Ikan Mas",
            "Ikan Mujair",
            "Ikan Gabus",
            "Ikan Patin",
            "Ikan Gurame",
            "Ikan Arwana",
            "Ikan Hiu",
            "Ikan Naga"
        ];

        fishes.forEach(function (name) {

            const item = document.createElement("div");

            item.className = "collectionItem";

            if (collection.includes(name)) {
                item.textContent = "🐟 " + name;
            } else {
                item.textContent = "❓ ???";
            }

            box.appendChild(item);
        });
    }

    // Pastikan awalnya HOME
    showScreen("home");
    updateMoney();
    updateWorms();

});