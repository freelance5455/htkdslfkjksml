const questions=[
{name:'Buzz Cut',img:'https://i.pinimg.com/736x/46/c4/87/46c487c97431a4836194ba9ed075adb6.jpg'},
{name:'Crew Cut',img:'https://media.hairtical.com/2026/03/crew-cut-military-69b3922a498e6.webp'},
{name:'French Crop',img:'https://i.pinimg.com/originals/23/f6/82/23f68209874ec23d1d763b9a29619dd2.jpg'},
{name:'Low Fade',img:'https://i.pinimg.com/1200x/94/d2/61/94d261dec7f865287ab8cb4734cd1f69.jpg'},
{name:'Mid Fade',img:'https://pandami.com.br/api/asset/homem-com-degrade-medio-mid-fade-819x1024'},
{name:'Skin Fade',img:'https://www.beardbeasts.com/cdn/shop/articles/skin-fade-hairstyle.jpg'},
{name:'Curly High Fade',img:'https://cdn.shopify.com/s/files/1/0255/2417/4922/files/Curly_High_Fade_Short_Curly_Haircuts_for_Men_1_90953c94-392f-4dc9-8270-36ff1c4af96e.png?v=1716904070'},
{name:'Curly Low Fade',img:'https://img.modices.com.br/cabelo-cacheado-curto-homem-1.jpg'},
{name:'Quiff',img:'https://i.pinimg.com/originals/45/ae/53/45ae537aec93bd50324431d4fe8c76de.jpg'},
{name:'Pompadour',img:'https://www.reuzel.com/cdn/shop/articles/Joram_0aa3572d-51aa-48c9-b45f-11b9f0f0c638.jpg?v=1777321228'},
{name:'Side Part',img:'https://i.pinimg.com/474x/b6/1b/8e/b61b8ea9f1adc2bd528b1dbff4a98a6c.jpg'},
{name:'Comb Over',img:'https://i.pinimg.com/564x/e8/ab/6c/e8ab6c74adef6f756bfd821bd22c9d2f.jpg'},
{name:'Undercut',img:'https://i.pinimg.com/736x/45/f7/35/45f735fad311fc6dbc5a05f0370093ef.jpg'},
{name:'Slick Back',img:'https://i.pinimg.com/736x/45/f7/35/45f735fad311fc6dbc5a05f0370093ef.jpg'},
{name:'Mullet',img:'https://media.hairtical.com/2026/03/mullet-haircut-texture-fade-69b38b53a0933.webp'},
{name:'Wolf Cut',img:'https://cdn.shopify.com/s/files/1/2384/0833/files/Wolf_Cut_Long_Shag_Edge.png?v=1772439028'},
{name:'Shag',img:'https://i.pinimg.com/originals/48/fa/51/48fa515999a00db112fcba981a141b80.png'},
{name:'Caesar',img:'https://hairstylehub.com/wp-content/uploads/2017/01/Low-Taper-Caesar.jpg'},
{name:'Faux Hawk',img:'https://i.pinimg.com/564x/5b/d4/e8/5bd4e8a121c83757fc9b0711ef3b3a82.jpg'},
{name:'Buzz Fade',img:'https://i.pinimg.com/736x/46/c4/87/46c487c97431a4836194ba9ed075adb6.jpg'},
{name:'Crew Fade',img:'https://media.hairtical.com/2026/03/crew-cut-military-69b3922a498e6.webp'},
{name:'French Crop Fade',img:'https://i.pinimg.com/originals/23/f6/82/23f68209874ec23d1d763b9a29619dd2.jpg'},
{name:'Low Fade Quiff',img:'https://i.pinimg.com/originals/45/ae/53/45ae537aec93bd50324431d4fe8c76de.jpg'},
{name:'Skin Fade Side Part',img:'https://www.beardbeasts.com/cdn/shop/articles/skin-fade-hairstyle.jpg'},
{name:'Comb Over Fade',img:'https://i.pinimg.com/564x/e8/ab/6c/e8ab6c74adef6f756bfd821bd22c9d2f.jpg'},
{name:'Disconnected Undercut',img:'https://i.pinimg.com/736x/45/f7/35/45f735fad311fc6dbc5a05f0370093ef.jpg'},
{name:'Modern Mullet',img:'https://media.hairtical.com/2026/03/mullet-haircut-texture-fade-69b38b53a0933.webp'},
{name:'Long Wolf Cut',img:'https://cdn.shopify.com/s/files/1/2384/0833/files/Wolf_Cut_Long_Shag_Edge.png?v=1772439028'},
{name:'Curly Fade',img:'https://img.modices.com.br/cabelo-cacheado-curto-homem-1.jpg'},
{name:'Faux Hawk Fade',img:'https://i.pinimg.com/564x/5b/d4/e8/5bd4e8a121c83757fc9b0711ef3b3a82.jpg'}
];
const arabicNames={'Buzz Cut':'باز كت','Crew Cut':'كرو كت','French Crop':'فرنش كروب','Low Fade':'فيد واطي','Mid Fade':'فيد متوسط','Skin Fade':'فيد سكن','Curly High Fade':'كيرلي فيد عالي','Curly Low Fade':'كيرلي فيد واطي','Quiff':'كويف','Pompadour':'بومبادور','Side Part':'سايد بارت','Comb Over':'كومب أوفر','Undercut':'أندر كت','Slick Back':'سليك باك','Mullet':'مولت','Wolf Cut':'وولف كت','Shag':'شاغ','Caesar':'قيصر','Faux Hawk':'فوهـوك','Buzz Fade':'باز كت مع فيد','Crew Fade':'كرو كت مع فيد','French Crop Fade':'فرنش كروب مع فيد','Low Fade Quiff':'فيد واطي مع كويف','Skin Fade Side Part':'فيد سكن مع سايد بارت','Comb Over Fade':'كومب أوفر مع فيد','Disconnected Undercut':'أندر كت مفصول','Modern Mullet':'مولت مودرن','Long Wolf Cut':'وولف كت طويل','Curly Fade':'كيرلي فيد','Faux Hawk Fade':'فوهـوك فيد'};
questions.forEach(q=>q.opts=[q.name,...questions.filter(x=>x.name!==q.name).map(x=>x.name).sort(()=>Math.random()-.5).slice(0,2)]);

const $=id=>document.getElementById(id), screens=[...document.querySelectorAll('.screen')];
let language='en',volume=.8,audioCtx=null,masterGain=null,currentTrack=0,musicStarted=false;
let current=0,score=0,quizTimer=null,quizTime=30,quizLocked=false;
let coins=Number(localStorage.getItem('barberCoins')||0),day=Number(localStorage.getItem('barberDay')||1),client=Number(localStorage.getItem('barberClient')||1);
let barberTimer=null,barberSeconds=120,barberLocked=false,activeTool='clipper',clientState=null,targetState=null;
const musicPlayers=[0,1].map(i=>$('music'+i));
const translations={
 en:{title:'Barber Challenge',play:'Play',settings:'Settings',info:'About',back:'Back',chooseMode:'Choose your challenge',modes:'Challenge Modes',barberMode:'Barber Shop',barberModeDesc:'Cut, shape and finish the client\'s requested style.',quizMode:'Haircut Challenge',quizModeDesc:'Test your haircut knowledge.',moreSoon:'More challenges soon',moreDesc:'New challenges will be added here.',customize:'Customize',settingsTitle:'Settings',volume:'Volume',music:'Menu music',language:'Language',song1:'Calm Night',song2:'Quiet Cafe',song3:'Soft Breeze',madeBy:'Developed by',aboutCopy:'Barber Challenge is a growing collection of barber challenges.',menu:'Menu',titleShort:'Barber Challenge',quizSub:'Focus & react',score:'Coins',challenge:'HAIRCUT CHALLENGE',question:'Which cut is this?',chooseAnswer:'Choose the right answer',finished:'CHALLENGE COMPLETE',again:'Play again',correct:'Correct ✦',wrong:'Not this one',timeup:'Time is up',result1:'Outstanding eye',result2:'Sharp eye',result3:'Nice run',result4:'Keep practicing',resultText:s=>`You got ${s} out of ${questions.length} rounds right.`,round:r=>`Round ${r} of ${questions.length}`,correctAnswer:n=>`Correct: ${n}`,day:'Day',client:'Client',barberShopTitle:'BARBER SHOP',barberTask:'Give the client the requested cut.',timeLeft:'TIME',target:'REQUEST',clipper:'Clipper',clipperDesc:'Cut',comb:'Comb',combDesc:'Shape',razor:'Razor',razorDesc:'Shave',powder:'Growth',powderDesc:'Grow',finishWhenReady:'Finish when you\'re ready',finish:'Finish',nextClient:'Next Client',menuResult:'Menu',goodJob:'Great job!',lose:'YOU LOSE',accuracy:'Accuracy',reward:'Reward',clientRequest:'Client wants',hints:{buzz:'Short and clean all over.',fade:'Short sides with a longer top.',long:'Keep the top long and shaped.',shave:'Clean skin on the sides.'},toolTip:{clipper:'Move over the hair to cut it.',comb:'Comb the hair to shape it.',razor:'Remove hair completely.',powder:'Grow the hair longer.'}},
 ar:{title:'تحدّي الحلاقين',play:'لعب',settings:'الإعدادات',info:'معلومات',back:'رجوع',chooseMode:'اختار التحدّي',modes:'أوضاع التحدّي',barberMode:'صالون الحلاق',barberModeDesc:'قص ورتّب شعر الزبون مثل القصة اللي طلبها.',quizMode:'تحدّي الحلاقات',quizModeDesc:'اختبر معرفتك بالحلاقات.',moreSoon:'تحديات أكثر قريباً',moreDesc:'راح نضيف التحديات الجديدة هنا.',customize:'تخصيص',settingsTitle:'الإعدادات',volume:'مستوى الصوت',music:'موسيقى الواجهة',language:'اللغة',song1:'ليل هادئ',song2:'مقهى هادئ',song3:'نسمة خفيفة',madeBy:'تطوير',aboutCopy:'تحدّي الحلاقين مجموعة تكبر مع الوقت وراح نضيف إلها تحديات أكثر.',menu:'القائمة',titleShort:'تحدّي الحلاقين',quizSub:'ركّز وأسرع',score:'عملات',challenge:'تحدّي الحلاقات',question:'شنو اسم هاي الحلاقة؟',chooseAnswer:'اختار الجواب الصح',finished:'اكتمل التحدّي',again:'عيد اللعب',correct:'إي صح ✦',wrong:'لا مو هي',timeup:'خلص الوقت',result1:'عينك حديد',result2:'عين قوية',result3:'بداية حلوة',result4:'استمر بالتدريب',resultText:s=>`جاوبت صح ${s} من ${questions.length} جولة.`,round:r=>`الجولة ${r} من ${questions.length}`,correctAnswer:n=>`الصح: ${n}`,day:'اليوم',client:'الزبون',barberShopTitle:'صالون الحلاق',barberTask:'قص ورتّب شعر الزبون مثل طلبه.',timeLeft:'الوقت',target:'الطلب',clipper:'مكينة',clipperDesc:'قص',comb:'مشط',combDesc:'ترتيب',razor:'موس',razorDesc:'حلاقة',powder:'بودرا',powderDesc:'تطويل',finishWhenReady:'لما تخلص اضغط إنهاء',finish:'إنهاء',nextClient:'الزبون الجاي',menuResult:'القائمة',goodJob:'شغل حلو!',lose:'خسرت',accuracy:'نسبة التطابق',reward:'المكافأة',clientRequest:'الزبون يريد',hints:{buzz:'قصير ونظيف بكل الرأس.',fade:'الجوانب قصيرة وفوك أطول.',long:'خلي الفوك طويل ورتبه.',shave:'الجوانب تنشال للجلد.'},toolTip:{clipper:'حرّك المكينة على الشعر حتى تقصه.',comb:'مشّط الشعر حتى ترتبه.',razor:'يشيل الشعر نهائياً.',powder:'يطوّل الشعر.'}}
};
function t(k,...a){const v=translations[language][k];return typeof v==='function'?v(...a):v}
function displayName(n){return language==='ar'?(arabicNames[n]||n):n}
function showScreen(id){screens.forEach(s=>s.classList.toggle('active',s.id===id));window.scrollTo({top:0,behavior:'smooth'})}
function setText(){document.documentElement.lang=language;document.documentElement.dir=language==='ar'?'rtl':'ltr';document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.dataset.i18n;if(translations[language][k]!==undefined)el.textContent=translations[language][k]});$('volumeValue').textContent=Math.round(volume*100)+'%';$('musicState').textContent='On';$('questionNumber').textContent=t('round',current+1);document.title=t('title');$('coinCount').textContent=coins;$('menuCoinCount').textContent=coins;updateBarberTexts();}
function updateBarberTexts(){if(!clientState)return;const name=clientState.target; $('targetName').textContent=displayName(name);$('targetHint').textContent=clientState.hint[language];$('toolTip').textContent=t('toolTip')[activeTool]}
function makeDecor(){const wrap=$('barberDecor'),items=[];const scissors=(x,y,r)=>`<svg class="decor-item s" style="left:${x}%;top:${y}%;width:${r}px;height:${r}px" viewBox="0 0 100 100"><circle cx="28" cy="27" r="12"/><circle cx="28" cy="73" r="12"/><path d="M37 34L83 76M37 66L83 24M46 50L88 50"/></svg>`;const mustache=(x,y,r)=>`<svg class="decor-item m" style="left:${x}%;top:${y}%;width:${r}px;height:${r*.62}px" viewBox="0 0 160 100"><path d="M80 43C57 25 36 25 15 43c8 29 28 39 65 11 37 28 57 18 65-11-21-18-42-18-65 0Z"/><path d="M80 43c-12 11-25 17-40 14M80 43c12 11 25 17 40 14"/></svg>`;[[4,7,70],[78,10,78],[18,30,48],[87,32,55],[2,57,60],[74,57,74],[35,78,48],[89,82,50],[52,8,42],[48,88,65],[12,91,43],[62,42,38],[26,63,44],[92,15,40]].forEach((v,i)=>items.push(i%2?mustache(...v):scissors(...v)));wrap.innerHTML=items.join('')}
function ensureAudio(){try{if(!audioCtx){audioCtx=new(window.AudioContext||window.webkitAudioContext)();masterGain=audioCtx.createGain();masterGain.gain.value=volume;masterGain.connect(audioCtx.destination)}if(audioCtx.state==='suspended')audioCtx.resume();musicPlayers.forEach(p=>p.volume=Math.min(.55,volume*.7))}catch(e){}}
function sound(type='click'){try{ensureAudio();if(!audioCtx)return;const n=audioCtx.currentTime,o=audioCtx.createOscillator(),g=audioCtx.createGain();o.connect(g);g.connect(masterGain);const l=Math.min(.78,.4+volume*.38);if(type==='click'){o.type='sine';o.frequency.setValueAtTime(640,n);o.frequency.exponentialRampToValueAtTime(920,n+.06);g.gain.setValueAtTime(l,n);g.gain.exponentialRampToValueAtTime(.001,n+.13);o.start();o.stop(n+.14)}else if(type==='good'){o.type='triangle';[620,780,980].forEach((f,i)=>o.frequency.setValueAtTime(f,n+i*.09));g.gain.setValueAtTime(l,n);g.gain.exponentialRampToValueAtTime(.001,n+.5);o.start();o.stop(n+.51)}else if(type==='bad'){o.type='sawtooth';o.frequency.setValueAtTime(240,n);o.frequency.exponentialRampToValueAtTime(90,n+.4);g.gain.setValueAtTime(l*.75,n);g.gain.exponentialRampToValueAtTime(.001,n+.42);o.start();o.stop(n+.43)}else if(type==='clip'){o.type='square';o.frequency.setValueAtTime(150,n);o.frequency.setValueAtTime(180,n+.035);g.gain.setValueAtTime(l*.24,n);g.gain.exponentialRampToValueAtTime(.001,n+.07);o.start();o.stop(n+.08)}else if(type==='shave'){o.type='sawtooth';o.frequency.setValueAtTime(80,n);g.gain.setValueAtTime(l*.18,n);g.gain.exponentialRampToValueAtTime(.001,n+.12);o.start();o.stop(n+.13)}else if(type==='grow'){o.type='sine';o.frequency.setValueAtTime(380,n);o.frequency.exponentialRampToValueAtTime(720,n+.22);g.gain.setValueAtTime(l*.25,n);g.gain.exponentialRampToValueAtTime(.001,n+.25);o.start();o.stop(n+.26)}else if(type==='finish'){o.type='triangle';o.frequency.setValueAtTime(520,n);o.frequency.setValueAtTime(700,n+.1);o.frequency.setValueAtTime(920,n+.2);g.gain.setValueAtTime(l,n);g.gain.exponentialRampToValueAtTime(.001,n+.55);o.start();o.stop(n+.56)}}catch(e){}}
function startMenuMusic(){if(musicStarted)return;const p=musicPlayers[currentTrack];if(!p)return;p.volume=Math.min(.55,volume*.7);p.play().then(()=>musicStarted=true).catch(()=>{})}
function setMusic(i){currentTrack=i;musicPlayers.forEach((p,j)=>{if(j!==i)p.pause()});musicPlayers[i].currentTime=0;musicPlayers[i].play().then(()=>musicStarted=true).catch(()=>{});document.querySelectorAll('.music-choice').forEach((b,j)=>b.classList.toggle('active',j===i))}
function updateVolume(v){volume=v/100;$('volumeValue').textContent=v+'%';if(masterGain)masterGain.gain.value=volume;musicPlayers.forEach(p=>p.volume=Math.min(.55,volume*.7))}
function buttonPress(el,action){if(!el||el.dataset.busy==='1')return;el.dataset.busy='1';el.classList.remove('button-press');void el.offsetWidth;el.classList.add('button-press');sound('click');setTimeout(()=>{el.classList.remove('button-press');el.dataset.busy='0';action()},190)}

// ---------- Barber shop mode ----------
const clientTypes=[
 {target:'Low Fade',style:'lowFade',start:58,top:64,side:20,shave:0,hint:{en:'Cut only the sides low. Keep the top medium.',ar:'قص الجوانب فيد واطي وخلي الفوك متوسط.'}},
 {target:'Buzz Cut',style:'buzz',start:28,top:24,side:20,shave:0,hint:{en:'Make the whole head short and even.',ar:'خلّي الشعر كله قصير ومتساوي.'}},
 {target:'Skin Fade',style:'skinFade',start:52,top:62,side:0,shave:1,hint:{en:'Take the sides all the way to skin. Keep the top.',ar:'شيل الجوانب للجلد وخلي شعر الفوك.'}},
 {target:'Long Top',style:'long',start:12,top:88,side:32,shave:0,hint:{en:'Grow the top, then shape it with the comb.',ar:'طوّل شعر الفوك وبعدين رتبه بالمشط.'}},
 {target:'Crew Cut',style:'crew',start:42,top:38,side:18,shave:0,hint:{en:'Short top with tighter sides.',ar:'خلي الفوك قصير والجوانب أضيق.'}},
 {target:'Mid Fade',style:'midFade',start:56,top:60,side:27,shave:0,hint:{en:'Make the sides a medium fade and keep the top.',ar:'سوّي فيد متوسط بالجوانب وخلي الفوك.'}}
];
let hairGrid=null, targetGrid=null, hairParticles=[], pointerPos=null, drawFrame=0, lastStrokePoint=null;
const clientBaseImg=new Image(); clientBaseImg.src='assets/client-real.jpg';
const GRID_W=31,GRID_H=36;
function hairShape(x,y){
  // Realistic full-head hair zone: dense crown + temples, with a curved hairline
  // kept above the forehead so no dark circle is painted over the face.
  const crown=((x-215)/138)**2+((y-82)/92)**2<1 && y<142;
  const left=((x-108)/45)**2+((y-155)/83)**2<1 && y>78 && y<232;
  const right=((x-314)/45)**2+((y-158)/83)**2<1 && y>78 && y<235;
  const templeL=((x-132)/34)**2+((y-188)/65)**2<1;
  const templeR=((x-298)/34)**2+((y-190)/65)**2<1;
  // Curved front hairline: leave the central forehead visible.
  const hairline= y < 101 + 0.00075*(x-215)*(x-215);
  return (crown && hairline) || left || right || templeL || templeR;
}
function hairMask(gx,gy){
 const x=(gx/(GRID_W-1))*430, y=(gy/(GRID_H-1))*520;
 return hairShape(x,y);
}
function desiredLength(style,gx,gy){
 const x=(gx/(GRID_W-1))*430,y=(gy/(GRID_H-1))*520;
 const topRegion=((x-215)/108)**2+((y-105)/104)**2<1 && y<185;
 const sideDist=Math.min(Math.abs(x-132),Math.abs(x-298));
 const inSide=((x-132)/42)**2+((y-220)/92)**2<1 || ((x-298)/42)**2+((y-220)/92)**2<1;
 if(!hairMask(gx,gy))return 0;
 if(style==='buzz')return 24;
 if(style==='crew')return topRegion?38:18;
 if(style==='long')return topRegion?88:32;
 if(style==='skinFade')return topRegion?62:0;
 if(style==='lowFade'){
   if(topRegion)return 64;
   return Math.max(8,24-Math.max(0,(220-y))/7);
 }
 if(style==='midFade'){
   if(topRegion)return 60;
   return Math.max(7,30-Math.max(0,(235-y))/5);
 }
 return topRegion?55:22;
}
function makeGrid(valueOrStyle){
 const g=[];
 for(let y=0;y<GRID_H;y++)for(let x=0;x<GRID_W;x++){
   const i=y*GRID_W+x;
   if(typeof valueOrStyle==='string') g[i]=desiredLength(valueOrStyle,x,y);
   else g[i]=hairMask(x,y)?valueOrStyle:0;
 }
 return g;
}
function newClient(){
 clientState={...clientTypes[Math.floor(Math.random()*clientTypes.length)]};
 targetState={style:clientState.style,top:clientState.top,side:clientState.side,shave:clientState.shave};
 const start=clientState.start??48;
 hairGrid=makeGrid(start); targetGrid=makeGrid(clientState.style);
 clientState.grown=false;clientState.combed=false;barberLocked=false;barberSeconds=120;activeTool='clipper';hairParticles=[];pointerPos=null;
 document.querySelectorAll('.tool-btn').forEach(b=>b.classList.toggle('active',b.dataset.tool==='clipper'));
 $('dayNumber').textContent=day;$('clientNumber').textContent=client;$('coinCount').textContent=coins;$('menuCoinCount').textContent=coins;
 updateBarberTexts();drawTarget();drawClient();clearInterval(barberTimer);
 barberTimer=setInterval(()=>{barberSeconds--;updateBarberTimer();if(barberSeconds<=0){clearInterval(barberTimer);finishBarberGame(true)}},1000);updateBarberTimer();startHairAnimation();
}
function updateBarberTimer(){const m=Math.floor(barberSeconds/60),s=barberSeconds%60;$('barberTimer').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;$('barberTimer').classList.toggle('danger',barberSeconds<=20)}
function gridIndexFromPoint(x,y){let gx=Math.round((x/430)*(GRID_W-1)),gy=Math.round((y/520)*(GRID_H-1));return {gx:Math.max(0,Math.min(GRID_W-1,gx)),gy:Math.max(0,Math.min(GRID_H-1,gy))}}
function addHairParticles(x,y,count=4){for(let i=0;i<count;i++)hairParticles.push({x,y,vx:(Math.random()-.5)*1.8,vy:.7+Math.random()*1.6,life:1,len:3+Math.random()*7,rot:(Math.random()-.5)*1.4})}
function applyTool(x,y,interpolate=true){
 if(barberLocked)return;
 const c=$('clientCanvas'),r=c.getBoundingClientRect();
 const cx=(x-r.left)*430/r.width,cy=(y-r.top)*520/r.height;
 if(cx<55||cx>375||cy<35||cy>455){pointerPos=null;lastStrokePoint=null;drawClient();return}
 pointerPos={x:cx,y:cy};
 const radius=activeTool==='razor'?18:activeTool==='powder'?23:activeTool==='comb'?25:21;
 const from=lastStrokePoint&&interpolate?lastStrokePoint:{x:cx,y:cy};
 const dist=Math.hypot(cx-from.x,cy-from.y);
 const steps=Math.max(1,Math.ceil(dist/7));
 let changed=false;
 for(let st=1;st<=steps;st++){
   const px0=from.x+(cx-from.x)*st/steps, py0=from.y+(cy-from.y)*st/steps;
   const minX=Math.max(0,Math.floor(((px0-radius)/430)*(GRID_W-1))),maxX=Math.min(GRID_W-1,Math.ceil(((px0+radius)/430)*(GRID_W-1)));
   const minY=Math.max(0,Math.floor(((py0-radius)/520)*(GRID_H-1))),maxY=Math.min(GRID_H-1,Math.ceil(((py0+radius)/520)*(GRID_H-1)));
   for(let gy=minY;gy<=maxY;gy++)for(let gx=minX;gx<=maxX;gx++){
     const gxPx=gx/(GRID_W-1)*430,gyPx=gy/(GRID_H-1)*520,dd=Math.hypot(gxPx-px0,gyPx-py0);
     if(dd>radius||!hairMask(gx,gy))continue;
     const i=gy*GRID_W+gx,old=hairGrid[i];
     if(activeTool==='clipper'){
       const pressure=Math.max(.35,1-dd/radius);
       hairGrid[i]=Math.max(0,old-9*pressure);
     }else if(activeTool==='razor') hairGrid[i]=0;
     else if(activeTool==='powder') hairGrid[i]=Math.min(100,old+11*(1-dd/radius));
     else if(activeTool==='comb') clientState.combed=true;
     if(hairGrid[i]!==old)changed=true;
   }
 }
 lastStrokePoint={x:cx,y:cy};
 if(changed){
   if(activeTool==='clipper'){sound('clip');addHairParticles(cx,cy,5)}
   else if(activeTool==='razor'){sound('shave');addHairParticles(cx,cy,7)}
   else if(activeTool==='powder')sound('grow');
 }
 if(activeTool==='comb')sound('click');
 drawClient();updateLiveAccuracy();
}
function drawBasePerson(ctx){
 ctx.clearRect(0,0,430,520);
 if(clientBaseImg.complete && clientBaseImg.naturalWidth){
   ctx.drawImage(clientBaseImg,0,0,430,520);
   // subtle vignette so the hair stays visually separated from the portrait
   const g=ctx.createLinearGradient(0,0,0,520);g.addColorStop(0,'rgba(0,0,0,.02)');g.addColorStop(.72,'rgba(0,0,0,.05)');g.addColorStop(1,'rgba(0,0,0,.18)');
   ctx.fillStyle=g;ctx.fillRect(0,0,430,520);
   return;
 }
 const skin='#c99172';ctx.save();
 ctx.fillStyle='#141821';ctx.beginPath();ctx.ellipse(215,470,135,55,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#202631';ctx.beginPath();ctx.roundRect(120,340,190,170,42);ctx.fill();
 ctx.fillStyle=skin;ctx.beginPath();ctx.ellipse(215,236,103,137,0,0,Math.PI*2);ctx.fill();ctx.restore();
}
function hairSeed(a,b,c=0){
  const n=Math.sin(a*127.1+b*311.7+c*74.7)*43758.5453;
  return n-Math.floor(n);
}
function drawHairGrid(ctx,g,small=false){
  ctx.save();
  if(small)ctx.scale(.56,.56);

  let weighted=0,count=0;
  for(let i=0;i<g.length;i++){if(g[i]>1){weighted+=g[i];count++}}
  const avg=count?weighted/count:0;
  if(avg>1){
    // One continuous, head-shaped base instead of a floating black circle.
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(76,103);
    ctx.quadraticCurveTo(79,38,142,12);
    ctx.quadraticCurveTo(215,-5,289,13);
    ctx.quadraticCurveTo(349,40,354,105);
    ctx.quadraticCurveTo(348,137,333,165);
    ctx.quadraticCurveTo(326,181,319,202);
    ctx.lineTo(286,205);
    ctx.quadraticCurveTo(276,168,266,143);
    ctx.quadraticCurveTo(215,111,164,143);
    ctx.quadraticCurveTo(153,169,145,205);
    ctx.lineTo(111,203);
    ctx.quadraticCurveTo(105,177,94,154);
    ctx.quadraticCurveTo(80,132,76,103);
    ctx.closePath();
    const base=ctx.createLinearGradient(0,10,0,210);
    const darkness=Math.min(.96,.60+avg/250);
    base.addColorStop(0,`rgba(10,9,10,${darkness})`);
    base.addColorStop(.35,`rgba(16,14,15,${Math.min(.94,darkness+.05)})`);
    base.addColorStop(.72,'rgba(22,19,20,.96)');
    base.addColorStop(1,'rgba(26,22,23,.72)');
    ctx.fillStyle=base;ctx.fill();
    ctx.restore();
  }

  // Dense realistic strand field. Every grid point receives several overlapping
  // strands, so the head stays visually full instead of looking like dots.
  for(let gy=0;gy<GRID_H;gy++)for(let gx=0;gx<GRID_W;gx++){
    const len=g[gy*GRID_W+gx];
    if(len<=1)continue;
    const x=gx/(GRID_W-1)*430,y=gy/(GRID_H-1)*520;
    if(!hairShape(x,y))continue;
    const density=small?4:9;
    for(let k=0;k<density;k++){
      const j1=hairSeed(gx,gy,k)-.5,j2=hairSeed(gy,gx,k+8)-.5;
      const px=x+j1*(small?6:9), py=y+j2*(small?5:8);
      const crown=y<145;
      const dx=(px-215)/140;
      let angle;
      if(crown){
        angle=Math.atan2(.25+dx*.65,1)+((hairSeed(gx+3,gy+5,k+17)-.5)*.28);
        if(clientState?.combed)angle=-.16+dx*.34+((hairSeed(gx+3,gy+5,k+17)-.5)*.12);
      }else{
        angle=(px<215?1:-1)*(.95+hairSeed(gx+2,gy+2,k+22)*.34);
      }
      const strandLen=Math.max(4,2.5+len*(.38+.28*hairSeed(gx+11,gy+7,k+31)));
      const bend=(hairSeed(gx+19,gy+13,k+41)-.5)*strandLen*.7;
      const ex=px+Math.cos(angle)*strandLen, ey=py+Math.sin(angle)*strandLen;
      const mx=px+Math.cos(angle)*strandLen*.48-Math.sin(angle)*bend;
      const my=py+Math.sin(angle)*strandLen*.48+Math.cos(angle)*bend;
      const tone=hairSeed(gx,gy,k+57);
      ctx.strokeStyle=tone>.88?'#625958':tone>.58?'#302a2b':'#171416';
      ctx.globalAlpha=Math.min(.94,.48+len/135)*(small?.88:1);
      ctx.lineWidth=small?.72:(.62+hairSeed(gx+7,gy+9,k+63)*1.05);
      ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(px,py);ctx.quadraticCurveTo(mx,my,ex,ey);ctx.stroke();
      if(!small && len>30 && tone>.73){
        ctx.globalAlpha=.13;ctx.strokeStyle='#eee5df';ctx.lineWidth=.42;
        ctx.beginPath();ctx.moveTo(px+.4,py+.3);ctx.quadraticCurveTo(mx,my,ex,ey);ctx.stroke();
      }
    }
  }
  ctx.restore();
}
function drawPersonGrid(ctx,g,small=false){drawBasePerson(ctx);drawHairGrid(ctx,g,small);if(pointerPos&&!small){ctx.save();ctx.strokeStyle=activeTool==='razor'?'rgba(255,107,139,.8)':'rgba(169,157,255,.8)';ctx.setLineDash([5,4]);ctx.lineWidth=2;const rr=activeTool==='powder'?24:activeTool==='razor'?18:22;ctx.beginPath();ctx.arc(pointerPos.x,pointerPos.y,rr,0,Math.PI*2);ctx.stroke();ctx.restore()}}
function drawClient(){const c=$('clientCanvas'),ctx=c.getContext('2d');drawPersonGrid(ctx,hairGrid,false);}
function drawTarget(){const c=$('targetCanvas'),ctx=c.getContext('2d');drawPersonGrid(ctx,targetGrid,false)}
function calcAccuracy(){if(!hairGrid||!targetGrid)return 0;let total=0,count=0;for(let i=0;i<hairGrid.length;i++){if(!hairMask(i%GRID_W,Math.floor(i/GRID_W)))continue;total+=Math.abs(hairGrid[i]-targetGrid[i]);count++}let s=100-(total/count)*1.12;if(targetState.shave){let sideErr=0,n=0;for(let gy=0;gy<GRID_H;gy++)for(let gx=0;gx<GRID_W;gx++){const x=gx/(GRID_W-1)*430;if((x<175||x>255)&&hairMask(gx,gy)){sideErr+=hairGrid[gy*GRID_W+gx];n++}}s-=Math.min(20,sideErr/n*.45)}if(targetState.style==='long'&&!clientState.grown)s-=10;if(targetState.style!=='buzz'&&!clientState.combed)s-=5;return Math.max(0,Math.min(100,Math.round(s)))}
function updateLiveAccuracy(){$('liveAccuracy').textContent=calcAccuracy()+'%'}
function startHairAnimation(){cancelAnimationFrame(drawFrame);const loop=()=>{for(const p of hairParticles){p.x+=p.vx;p.y+=p.vy;p.vy+=.025;p.life-=.025;p.rot+=.04}hairParticles=hairParticles.filter(p=>p.life>0);drawClient();const c=$('clientCanvas'),ctx=c.getContext('2d');ctx.save();for(const p of hairParticles){ctx.globalAlpha=p.life;ctx.strokeStyle='#242731';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+Math.cos(p.rot)*p.len,p.y+Math.sin(p.rot)*p.len);ctx.stroke()}ctx.restore();drawFrame=requestAnimationFrame(loop)};drawFrame=requestAnimationFrame(loop)}
function finishBarberGame(timeup=false){if(barberLocked)return;barberLocked=true;clearInterval(barberTimer);cancelAnimationFrame(drawFrame);const acc=calcAccuracy(),good=acc>=72;let reward=0;if(good){reward=acc>=96?12:acc>=90?9:acc>=82?6:3; if(barberSeconds>=60) reward+=2;}if(good){coins+=reward;localStorage.setItem('barberCoins',coins);sound('finish')}else sound('bad');$('coinCount').textContent=coins;$('menuCoinCount').textContent=coins;$('barberAccuracy').textContent=acc;$('barberResultTitle').textContent=good?t('goodJob'):t('lose');$('resultEyebrow').textContent=t('accuracy');$('barberResultText').textContent=timeup?((language==='ar'?'خلص الوقت، ':'Time ran out, ')+(good?t('goodJob').toLowerCase():t('lose'))):(language==='ar'?`التطابق ويا طلب الزبون ${acc}%.`:`Your match with the request is ${acc}%.`);$('rewardLine').style.display=good?'flex':'none';$('rewardLine').innerHTML=good?`<span class="coin-icon"><img src="assets/coin.svg" alt=""></span><b>+${reward}</b>`:'';$('resultBurst').textContent=good?'✦':'×';$('resultBurst').className='result-burst '+(good?'win':'lose');$('barberResult').classList.add('show');$('barberResult').setAttribute('aria-hidden','false')}
function nextBarberClient(){barberLocked=false;$('barberResult').classList.remove('show');$('barberResult').setAttribute('aria-hidden','true');client++;if(client>5){client=1;day++;localStorage.setItem('barberDay',day)}localStorage.setItem('barberClient',client);newClient()}
function openBarber(){ensureAudio();startMenuMusic();showScreen('barberScreen');newClient()}
function leaveBarber(){clearInterval(barberTimer);cancelAnimationFrame(drawFrame);barberLocked=true;$('barberResult').classList.remove('show');showScreen('modeScreen')}

// ---------- Quiz mode ----------
const imageFrame=$('imageFrame'),answers=$('answers'),timerEl=$('timer'),ring=$('ringProgress'),CIRC=2*Math.PI*20;ring.style.strokeDasharray=CIRC;
function renderQuiz(){quizLocked=false;const q=questions[current];$('questionNumber').textContent=t('round',current+1);$('progressBar').style.width=((current+1)/questions.length*100)+'%';imageFrame.classList.add('swap');setTimeout(()=>{imageFrame.innerHTML=`<img src="${q.img}" alt="${displayName(q.name)}" onerror="this.remove();this.parentElement.classList.add('image-error')">`;imageFrame.classList.remove('swap')},120);const choices=[...q.opts].sort(()=>Math.random()-.5);answers.innerHTML='';choices.forEach(name=>{const b=document.createElement('button');b.type='button';b.className='answer';b.dataset.name=name;b.textContent=displayName(name);b.onclick=()=>buttonPress(b,()=>chooseQuiz(b,name===q.name));answers.appendChild(b)});$('feedback').textContent='';$('feedback').className='feedback';resetQuizTimer()}
function resetQuizTimer(){clearInterval(quizTimer);quizTime=30;updateQuizTimer();quizTimer=setInterval(()=>{quizTime--;updateQuizTimer();if(quizTime<=5&&quizTime>0)sound('click');if(quizTime<=0){clearInterval(quizTimer);timeoutQuiz()}},1000)}
function updateQuizTimer(){timerEl.textContent=String(quizTime).padStart(2,'0');ring.style.strokeDashoffset=CIRC*(1-quizTime/30);ring.style.stroke=quizTime<=7?'#ff6b8b':'#a18dff'}
function chooseQuiz(btn,correct){if(quizLocked)return;quizLocked=true;clearInterval(quizTimer);document.querySelectorAll('.answer').forEach(x=>x.disabled=true);const f=$('feedback');if(correct){score++;coins++;localStorage.setItem('barberCoins',coins);$('score').textContent=coins;btn.classList.add('correct');f.textContent=t('correct');f.classList.add('good');sound('good')}else{btn.classList.add('wrong');const right=document.querySelector(`.answer[data-name="${CSS.escape(questions[current].name)}"]`);if(right)right.classList.add('correct');f.textContent=`${t('wrong')} — ${t('correctAnswer',displayName(questions[current].name))}`;f.classList.add('bad');sound('bad')}$('coinCount').textContent=coins;setTimeout(nextQuiz,850)}
function timeoutQuiz(){if(quizLocked)return;quizLocked=true;sound('bad');document.querySelectorAll('.answer').forEach(x=>{x.disabled=true;if(x.dataset.name===questions[current].name)x.classList.add('correct')});$('feedback').textContent=`${t('timeup')} — ${t('correctAnswer',displayName(questions[current].name))}`;$('feedback').classList.add('bad');setTimeout(nextQuiz,850)}
function nextQuiz(){current++;if(current>=questions.length){finishQuiz();return}renderQuiz()}
function finishQuiz(){clearInterval(quizTimer);showScreen('resultScreen');$('finalScore').textContent=score;$('resultTitle').textContent=score>=27?t('result1'):score>=22?t('result2'):score>=15?t('result3'):t('result4');$('resultText').textContent=t('resultText',score)}
function startQuiz(){ensureAudio();current=0;score=0;$('score').textContent=coins;showScreen('quizScreen');renderQuiz()}
function goMenu(){clearInterval(quizTimer);clearInterval(barberTimer);showScreen('menuScreen')}

function bindControls(){
 const bind=(id,fn)=>{const e=$(id);if(e)e.addEventListener('click',ev=>{ev.preventDefault();buttonPress(e,fn)})};
 bind('playBtn',()=>{ensureAudio();startMenuMusic();showScreen('modeScreen')});bind('settingsBtn',()=>{ensureAudio();startMenuMusic();showScreen('settingsScreen')});bind('infoBtn',()=>showScreen('infoScreen'));bind('barberModeBtn',openBarber);bind('quizModeBtn',startQuiz);bind('barberBack',leaveBarber);bind('quizBack',goMenu);bind('restartBtn',startQuiz);bind('resultMenu',goMenu);bind('finishBarber',()=>finishBarberGame(false));bind('nextClientBtn',nextBarberClient);bind('resultHomeBtn',()=>{clearInterval(barberTimer);$('barberResult').classList.remove('show');showScreen('modeScreen')});
 document.querySelectorAll('[data-back]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();buttonPress(b,()=>showScreen(b.dataset.back))}));
 document.querySelectorAll('.music-choice').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();buttonPress(b,()=>{ensureAudio();setMusic(Number(b.dataset.track))})}));
 document.querySelectorAll('.lang-choice').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();buttonPress(b,()=>{language=b.dataset.lang;document.querySelectorAll('.lang-choice').forEach(x=>{x.classList.toggle('active',x===b);x.querySelector('span').textContent=x===b?'✓':''});setText();if($('quizScreen').classList.contains('active'))renderQuiz();if($('barberScreen').classList.contains('active')){drawTarget();drawClient()}})}));
 $('volumeSlider').addEventListener('input',e=>{ensureAudio();updateVolume(Number(e.target.value))});
 document.querySelectorAll('.tool-btn').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();buttonPress(b,()=>{activeTool=b.dataset.tool;document.querySelectorAll('.tool-btn').forEach(x=>x.classList.toggle('active',x===b));updateBarberTexts()})}));
 const cc=$('clientCanvas');let drawing=false;cc.addEventListener('pointerdown',e=>{if(barberLocked)return;drawing=true;lastStrokePoint=null;cc.setPointerCapture(e.pointerId);applyTool(e.clientX,e.clientY,false)});cc.addEventListener('pointermove',e=>{if(drawing)applyTool(e.clientX,e.clientY,true)});cc.addEventListener('pointerup',()=>{drawing=false;lastStrokePoint=null});cc.addEventListener('pointercancel',()=>{drawing=false;lastStrokePoint=null});
 document.addEventListener('pointerdown',()=>{ensureAudio();startMenuMusic()},{once:true,passive:true});
}
makeDecor();setText();updateVolume(80);bindControls();showScreen('menuScreen');
