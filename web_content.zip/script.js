const API = "https://mp3quran.net/api/v3";

const reciterSelect = document.getElementById("reciter");
const surahListContainer = document.getElementById("surahList");
const searchInput = document.getElementById("searchInput");
const audio = document.getElementById("audio");
const playerTitle = document.getElementById("playerTitle");
const statusText = document.getElementById("status");

let selectedReciter = null;
let selectedSurah = null;

/* القراء داخل التطبيق (أوفلاين) */
const reciters = [
    { id: 1, name: "عبد الباسط عبد الصمد", keywords: ["عبدالباسط", "basit"] },
    { id: 2, name: "عبد الرحمن السديس", keywords: ["السديس", "sudais"] },
    { id: 3, name: "ماهر المعيقلي", keywords: ["المعيقلي", "maher"] },
    { id: 4, name: "سعد الغامدي", keywords: ["الغامدي", "ghamdi"] },
    { id: 5, name: "مشاري العفاسي", keywords: ["العفاسي", "afasy"] },
    { id: 6, name: "ياسر الدوسري", keywords: ["الدوسري", "yasir"] },
    { id: 7, name: "محمد صديق المنشاوي", keywords: ["المنشاوي", "minshawi"] },
    { id: 8, name: "محمود خليل الحصري", keywords: ["الحصري", "husary"] },
    { id: 9, name: "مصطفى إسماعيل", keywords: ["مصطفى إسماعيل", "mustafa"] },
    { id: 10, name: "محمود علي البنا", keywords: ["البنا", "banna"] }
];

/* أسماء السور داخل التطبيق (أوفلاين) */
const surahNames = [
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
    "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
    "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
    "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
    "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
    "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
    "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
    "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
    "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
    "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
    "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
    "المسد", "الإخلاص", "الفلق", "الناس"
];

// 1. تحميل القراء
function loadReciters() {
    reciterSelect.innerHTML = `<option value="">اختر القارئ</option>`;
    reciters.forEach((r, index) => {
        const option = document.createElement("option");
        option.value = index;
        option.textContent = `${index + 1}. ${r.name}`;
        reciterSelect.appendChild(option);
    });
}

// 2. عرض السور في القائمة
function renderSurahs(filterText = "") {
    surahListContainer.innerHTML = "";
    
    surahNames.forEach((name, index) => {
        if (filterText && !name.includes(filterText)) return;

        const surahNumber = index + 1;
        const item = document.createElement("div");
        item.className = "surah-item";
        item.innerHTML = `
            <span class="surah-number">${surahNumber}</span>
            <span class="surah-name">سورة ${name}</span>
        `;

        item.addEventListener("click", () => selectSurah(surahNumber, name, item));
        surahListContainer.appendChild(item);
    });
}

// 3. اختيار القارئ
reciterSelect.addEventListener("change", () => {
    const val = reciterSelect.value;
    selectedReciter = val !== "" ? reciters[val] : null;
    if (selectedSurah) playSelectedAudio();
});

// 4. اختيار السورة وتجهيز التشغيل
function selectSurah(number, name, element) {
    document.querySelectorAll(".surah-item").forEach(el => el.classList.remove("active"));
    element.classList.add("active");

    selectedSurah = { number, name };
    
    if (!selectedReciter) {
        playerTitle.textContent = `سورة ${name}`;
        statusText.textContent = "الرجاء اختيار القارئ أولاً للبدء.";
        return;
    }

    playSelectedAudio();
}

// 5. جلب رابط الصوت وتشغيله
async function playSelectedAudio() {
    if (!selectedReciter || !selectedSurah) return;

    playerTitle.textContent = `سورة ${selectedSurah.name} - ${selectedReciter.name}`;
    statusText.textContent = "🌐 جاري جلب الصوت...";

    try {
        const url = await getAudioURL();
        audio.src = url;
        audio.play();
        statusText.textContent = "جاري التشغيل...";
    } catch (err) {
        console.error(err);
        statusText.textContent = "❌ تعذر جلب الصوت. تحقق من الإنترنت.";
    }
}

// 6. الربط مع API جلب الروابط
async function getAudioURL() {
    const res = await fetch(`${API}/reciters?language=ar`);
    if (!res.ok) throw new Error("API error");
    const data = await res.json();

    const wanted = selectedReciter.keywords;
    const found = data.reciters.find(r => {
        const name = normalize(r.name);
        return wanted.some(k => name.includes(normalize(k)));
    });

    if (!found) throw new Error("Reciter not found");

    const moshaf = found.moshaf?.find(m => m.server);
    if (!moshaf) throw new Error("No server found");

    const numStr = String(selectedSurah.number).padStart(3, "0");
    return moshaf.server + numStr + ".mp3";
}

function normalize(text) {
    return String(text || "")
        .toLowerCase()
        .replace(/[ًٌٍَُِّْـ]/g, "")
        .replace(/[أإآ]/g, "ا")
        .replace(/ى/g, "ي")
        .replace(/ة/g, "ه")
        .replace(/\s+/g, "")
        .trim();
}

// 7. البحث في السور
searchInput.addEventListener("input", (e) => {
    renderSurahs(e.target.value.trim());
});

// بدء التطبيق
loadReciters();
renderSurahs();
