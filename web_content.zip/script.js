// MealFlow APK/WebView compatible Firebase bridge (no ES modules)

const firebaseConfig={apiKey:"AIzaSyB94z3Z61QSz8zie9cL8g6Gayjsbp9LHSY",authDomain:"mealflow-56118.firebaseapp.com",databaseURL:"https://mealflow-56118-default-rtdb.asia-southeast1.firebasedatabase.app",projectId:"mealflow-56118",storageBucket:"mealflow-56118.firebasestorage.app",messagingSenderId:"274352422081",appId:"1:274352422081:web:a1739bf867e110d9f42840",measurementId:"G-XS71C9C8EN"};
const app=firebase.initializeApp(firebaseConfig),auth=firebase.auth(),db=firebase.database();
const GoogleAuthProvider=()=>new firebase.auth.GoogleAuthProvider();
const FacebookAuthProvider=()=>new firebase.auth.FacebookAuthProvider();
const signInWithPopup=(a,p)=>a.signInWithPopup(p);
const signInWithEmailAndPassword=(a,e,p)=>a.signInWithEmailAndPassword(e,p);
const createUserWithEmailAndPassword=(a,e,p)=>a.createUserWithEmailAndPassword(e,p);
const updateProfile=(u,v)=>u.updateProfile(v);
const sendPasswordResetEmail=(a,e)=>a.sendPasswordResetEmail(e);
const onAuthStateChanged=(a,cb)=>a.onAuthStateChanged(cb);
const signOut=a=>a.signOut();
const ref=(d,p)=>d.ref(p);
const set=(r,v)=>r.set(v);
const push=r=>r.push();
const onValue=(r,cb)=>r.on("value",s=>cb(s));
const remove=r=>r.remove();
const $=id=>document.getElementById(id), today=new Date().toISOString().slice(0,10), monthNow=today.slice(0,7);
$("mealDate").value=today;$("offDate").value=today;$("depositDate").value=today;$("reportMonth").value=monthNow;$("historyMonth").value=monthNow;
let uid=null,data={meals:{},deposits:{},offDays:{},settings:{mealPrice:0}},unsubs=[];

function toast(m){$("toast").textContent=m;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2500)}
function money(n){return "৳"+Number(n||0).toLocaleString("en-BD",{maximumFractionDigits:2})}
function path(p){return ref(db,`users/${uid}/${p}`)}
function calc(month=monthNow){
 let meals=Object.values(data.meals||{}).filter(x=>x.date?.startsWith(month)), deposits=Object.values(data.deposits||{}).filter(x=>x.date?.startsWith(month)), offs=Object.values(data.offDays||{}).filter(x=>x.date?.startsWith(month));
 let cost=meals.reduce((s,x)=>s+Number(x.price||0),0), dep=deposits.reduce((s,x)=>s+Number(x.amount||0),0);
 return {meals,deposits,offs,cost,dep,balance:dep-cost};
}
function render(){
 const c=calc(monthNow); $("dashMonth").textContent=new Date(monthNow+"-01").toLocaleDateString("en-US",{month:"long",year:"numeric"});
 $("totalMeals").textContent=c.meals.length;$("mealCost").textContent=money(c.cost);$("totalDeposit").textContent=money(c.dep);$("balance").textContent=money(c.balance);$("offDaysText").textContent=`${c.offs.length} off days`;
 $("mealBreakdown").innerHTML=["breakfast","lunch","dinner"].map(t=>`<div class="break-row"><span>${t[0].toUpperCase()+t.slice(1)}</span><b>${c.meals.filter(x=>x.type===t).length}</b></div>`).join("");
 $("mealPrice").value=data.settings?.mealPrice??0;
 renderDeposits();renderOffs();renderReport();renderHistory();
}
function renderDeposits(){let a=Object.entries(data.deposits||{}).sort((a,b)=>(b[1].date||"").localeCompare(a[1].date||""));$("depositList").innerHTML=a.length?a.map(([id,x])=>`<div class="list-item"><div><b>${money(x.amount)}</b><small> · ${x.date}${x.note?" · "+x.note:""}</small></div><button class="danger" data-del-deposit="${id}">Delete</button></div>`).join(""):"<p class='muted'>No deposits yet.</p>"}
function renderOffs(){let a=Object.entries(data.offDays||{}).sort((a,b)=>b[1].date.localeCompare(a[1].date));$("offList").innerHTML=a.length?a.map(([id,x])=>`<div class="list-item"><b>${x.date}</b><button class="danger" data-del-off="${id}">Remove</button></div>`).join(""):"<p class='muted'>No off days.</p>"}
function renderReport(){let m=$("reportMonth").value||monthNow,c=calc(m);$("reportMeals").textContent=c.meals.length;$("reportCost").textContent=money(c.cost);$("reportDeposit").textContent=money(c.dep);$("reportBalance").textContent=money(c.balance);$("reportBreakdown").innerHTML=["breakfast","lunch","dinner"].map(t=>`<div class="break-row"><span>${t[0].toUpperCase()+t.slice(1)}</span><b>${c.meals.filter(x=>x.type===t).length}</b></div>`).join("")}
function renderHistory(){let m=$("historyMonth").value||monthNow,items=[...Object.values(data.meals||{}).filter(x=>x.date?.startsWith(m)).map(x=>({...x,kind:"Meal",label:x.type,cost:x.price})),...Object.values(data.deposits||{}).filter(x=>x.date?.startsWith(m)).map(x=>({...x,kind:"Deposit",label:"Money added",cost:x.amount}))].sort((a,b)=>b.date.localeCompare(a.date));$("historyList").innerHTML=items.length?items.map(x=>`<div class="list-item"><div><b>${x.kind}: ${x.label}</b><small> · ${x.date}</small></div><strong>${x.kind==="Meal"?money(x.cost):"+"+money(x.cost)}</strong></div>`).join(""):"<p class='muted'>No activity for this month.</p>"}

function showPage(page){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));$("page-"+page).classList.add("active");document.querySelectorAll("[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===page));$("pageTitle").textContent=page[0].toUpperCase()+page.slice(1);window.scrollTo(0,0)}
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));document.querySelectorAll("[data-page-jump]").forEach(b=>b.onclick=()=>showPage(b.dataset.pageJump));

$("showSignup").onclick=()=>{$("loginView").classList.add("hidden");$("signupView").classList.remove("hidden")};$("showLogin").onclick=()=>{$("signupView").classList.add("hidden");$("loginView").classList.remove("hidden")};
$("loginForm").onsubmit=async e=>{e.preventDefault();try{await signInWithEmailAndPassword(auth,$("loginEmail").value,$("loginPassword").value)}catch(err){toast(err.message)}};
$("signupForm").onsubmit=async e=>{e.preventDefault();try{let c=await createUserWithEmailAndPassword(auth,$("signupEmail").value,$("signupPassword").value);await updateProfile(c.user,{displayName:$("signupName").value});await set(ref(db,`users/${c.user.uid}/profile`),{name:$("signupName").value,email:c.user.email,createdAt:Date.now()});toast("Account created")}catch(err){toast(err.message)}};
$("googleBtn").onclick=async()=>{try{await signInWithPopup(auth,new GoogleAuthProvider())}catch(e){toast(e.message)}};
$("facebookBtn").onclick=async()=>{try{await signInWithPopup(auth,new FacebookAuthProvider())}catch(e){toast(e.message)}};
$("forgotBtn").onclick=async()=>{let e=$("loginEmail").value;if(!e)return toast("Enter your email first");try{await sendPasswordResetEmail(auth,e);toast("Password reset email sent")}catch(x){toast(x.message)}};
async function logoutUser(){
 if(!confirm("Are you sure you want to logout from MealFlow?")) return;
 try{await signOut(auth);toast("Logged out successfully")}catch(e){toast(e.message)}
}
$("logoutBtn").onclick=logoutUser;
$("accountLogoutBtn").onclick=logoutUser;

$("mealForm").onsubmit=async e=>{e.preventDefault();let price=Number(data.settings?.mealPrice||0);if(price<=0)return toast("Set meal price first");let x={date:$("mealDate").value,type:$("mealType").value,note:$("mealNote").value,price,createdAt:Date.now()};await set(push(path("meals")),x);$("mealNote").value="";toast("Meal added")};
$("depositForm").onsubmit=async e=>{e.preventDefault();await set(push(path("deposits")),{amount:Number($("depositAmount").value),date:$("depositDate").value,note:$("depositNote").value,createdAt:Date.now()});e.target.reset();$("depositDate").value=today;toast("Deposit added")};
$("offForm").onsubmit=async e=>{e.preventDefault();await set(push(path("offDays")),{date:$("offDate").value,createdAt:Date.now()});toast("Off day added")};
$("priceForm").onsubmit=async e=>{e.preventDefault();await set(path("settings"),{...data.settings,mealPrice:Number($("mealPrice").value)});toast("Meal price saved")};
$("reportMonth").onchange=renderReport;$("historyMonth").onchange=renderHistory;
document.addEventListener("click",async e=>{if(e.target.dataset.delDeposit)await remove(ref(db,`users/${uid}/deposits/${e.target.dataset.delDeposit}`));if(e.target.dataset.delOff)await remove(ref(db,`users/${uid}/offDays/${e.target.dataset.delOff}`))});

onAuthStateChanged(auth,user=>{
 unsubs.forEach(u=>u());unsubs=[];uid=user?.uid||null;
 if(!user){$("authScreen").classList.remove("hidden");$("appShell").classList.add("hidden");return}
 $("authScreen").classList.add("hidden");$("appShell").classList.remove("hidden");
 let name=user.displayName||user.email?.split("@")[0]||"User";$("userName").textContent=name;$("settingsName").textContent=name;$("settingsEmail").textContent=user.email||"";$("avatar").textContent=name[0].toUpperCase();$("settingsAvatar").textContent=name[0].toUpperCase();
 const uref=ref(db,`users/${uid}`);unsubs.push(onValue(uref,s=>{data=s.val()||{};data.meals=data.meals||{};data.deposits=data.deposits||{};data.offDays=data.offDays||{};data.settings=data.settings||{mealPrice:0};render()}));
});
