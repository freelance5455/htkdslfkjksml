let audioCtx = null;
let soundEnabled = localStorage.getItem('soundEnabled') !== 'false';

function getAudioCtx() {
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e) { return null; }
  }
  if (audioCtx.state === 'suspended') audioCtx.resume();
  return audioCtx;
}
function playTone(freq, duration, type, volume) {
  if (!soundEnabled) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(volume || 0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration);
  } catch(e) {}
}
function soundTap() { playTone(800, 0.05, 'sine', 0.05); }
function soundClick() { playTone(1200, 0.04, 'square', 0.03); }
function soundWin() {
  if (!soundEnabled) return;
  setTimeout(function() { playTone(523, 0.15, 'sine', 0.1); }, 0);
  setTimeout(function() { playTone(659, 0.15, 'sine', 0.1); }, 150);
  setTimeout(function() { playTone(784, 0.15, 'sine', 0.1); }, 300);
  setTimeout(function() { playTone(1047, 0.3, 'sine', 0.12); }, 450);
}
function soundUnlock() {
  setTimeout(function() { playTone(600, 0.08, 'sine', 0.08); }, 0);
  setTimeout(function() { playTone(900, 0.12, 'sine', 0.08); }, 80);
}
function soundWrong() {
  setTimeout(function() { playTone(300, 0.15, 'square', 0.08); }, 0);
  setTimeout(function() { playTone(200, 0.25, 'square', 0.08); }, 150);
}
function soundLockClick() { playTone(1500, 0.03, 'square', 0.04); }

const IMAGES = {
  iphone11to15_back: 'https://i.postimg.cc/TPfnNp6C/IMG-20260915-081707-934.png',
  iphone16_back:     'https://i.postimg.cc/jjty3LbM/IMG-20260915-081735-182.png',
  iphone17_back:     'https://i.postimg.cc/pLDDBKwN/IMG-20260915-081752-665.png',
  iphone17e_back:    'https://i.postimg.cc/pLDDBKwN/IMG-20260915-081813-363.png',
  iphone16e_back:    'https://i.postimg.cc/K8nn5tdp/IMG-20260915-081840-608.png',
  iphoneX_back:      'https://i.postimg.cc/52wwm8ZD/IMG-20260915-081908-470.png',
  iphoneXR_back:     'https://i.postimg.cc/L8zzVjrC/IMG-20260915-081930-228.png',
  iphone7_back:      'https://i.postimg.cc/52wwm8Zg/IMG-20260915-082012-727.png',
  android_back:      'https://i.postimg.cc/QdF0p6Db/IMG-20260915-122805-845.png'
};

const wheel = document.getElementById('wheel');
const spinBtn = document.getElementById('spinBtn');
const spinCounter = document.getElementById('spinCounter');
const loading = document.getElementById('loading');
const loadingText = document.getElementById('loadingText');
const result = document.getElementById('result');
const prizeName = document.getElementById('prizeName');
const miniPhone = document.getElementById('miniPhone');
const phoneViewer = document.getElementById('phoneViewer');
const phoneStage = document.getElementById('phoneStage');
const flipCard = document.getElementById('flipCard');
const rotateBtn = document.getElementById('rotateBtn');
const closeBtn = document.getElementById('closeBtn');
const saveBtn = document.getElementById('saveBtn');
const androidBrand = document.getElementById('androidBrand');
const iphoneIcons = document.getElementById('iphoneIcons');
const androidIcons = document.getElementById('androidIcons');
const appScreen = document.getElementById('appScreen');
const appBackBtn = document.getElementById('appBackBtn');
const appScreenContent = document.getElementById('appScreenContent');
const ipBatteryEl = document.getElementById('ipBattery');
const anBatteryEl = document.getElementById('anBattery');
const setupScreen = document.getElementById('setupScreen');
const nameInput = document.getElementById('nameInput');
const saveNameBtn = document.getElementById('saveNameBtn');
const iphoneBackImg = document.getElementById('iphoneBackImg');
const androidBackImg = document.getElementById('androidBackImg');
const myPhonesBtn = document.getElementById('myPhonesBtn');
const myPhonesScreen = document.getElementById('myPhonesScreen');
const myPhonesBackBtn = document.getElementById('myPhonesBackBtn');
const myPhonesList = document.getElementById('myPhonesList');

const iPhones = ['iPhone 7','iPhone X','iPhone XR','iPhone 11','iPhone 12','iPhone 13 Pro Max','iPhone 14','iPhone 15 Pro','iPhone 16','iPhone 16e','iPhone 17e','iPhone 17 Pro Max'];
const androids = ['Samsung Galaxy S26 Ultra','Samsung Galaxy S25','Samsung Galaxy S24','Google Pixel 9 Pro','Google Pixel 8','OnePlus 12','Xiaomi 14 Ultra','Nothing Phone 2','Infinix Zero 30','Infinix Note 40 Pro','Tecno Camon 30','Tecno Spark 20 Pro','itel P55','itel A70'];

const iosApps = [
  { label: 'Phone', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { label: 'Messages', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { label: 'Safari', color: 'linear-gradient(135deg,#3ddc84,#0088cc)' },
  { label: 'Camera', color: 'linear-gradient(135deg,#a0a0a0,#404040)' },
  { label: 'Music', color: 'linear-gradient(135deg,#ff006e,#cc0066)' },
  { label: 'Notes', color: 'linear-gradient(135deg,#ffcc00,#ff8800)' },
  { label: 'Calculator', color: 'linear-gradient(135deg,#a855f7,#6600ff)' },
  { label: 'Photos', color: 'linear-gradient(135deg,#ff6699,#cc0066)' },
  { label: 'App Store', color: 'linear-gradient(135deg,#1a88ff,#0066ff)' },
  { label: 'Settings', color: 'linear-gradient(135deg,#555,#222)' }
];

const androidApps = [
  { label: 'Phone', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { label: 'Messages', color: 'linear-gradient(135deg,#00e5ff,#0088ff)' },
  { label: 'Chrome', color: 'linear-gradient(135deg,#ffcc00,#ff6600)' },
  { label: 'Camera', color: 'linear-gradient(135deg,#a0a0a0,#404040)' },
  { label: 'Music', color: 'linear-gradient(135deg,#ff006e,#cc0066)' },
  { label: 'Notes', color: 'linear-gradient(135deg,#ffcc00,#ff8800)' },
  { label: 'Calculator', color: 'linear-gradient(135deg,#a855f7,#6600ff)' },
  { label: 'Gallery', color: 'linear-gradient(135deg,#ff6699,#cc0066)' },
  { label: 'Play Store', color: 'linear-gradient(135deg,#00e5ff,#0088ff)' },
  { label: 'Settings', color: 'linear-gradient(135deg,#555,#222)' }
];

let currentRotation = 0;
let spinning = false;
let currentBrand = 'iphone';
let currentModel = '';
let currentPhoneNumber = '';
let userName = '';
let battery = 87;
let settingsState = { wifi: true, bluetooth: true, mobileData: true, notifications: true, sounds: true };
let iphonePage = 0;
let androidPage = 0;
let pwInput = '';

function getInstalledApps() {
  try { return JSON.parse(localStorage.getItem('installedApps') || '[]'); }
  catch(e) { return []; }
}
function setInstalledApps(arr) {
  localStorage.setItem('installedApps', JSON.stringify(arr));
  refreshPage2();
}
function isAppInstalled(name) { return getInstalledApps().indexOf(name) !== -1; }
function installApp(name) {
  const installed = getInstalledApps();
  if (installed.indexOf(name) !== -1) return;
  installed.push(name);
  setInstalledApps(installed);
}

const STORE_APPS = {
  'Instagram': 'linear-gradient(135deg,#ff006e,#a855f7)',
  'WhatsApp':  'linear-gradient(135deg,#3ddc84,#00aa66)',
  'TikTok':    'linear-gradient(135deg,#ff006e,#00e5ff)',
  'YouTube':   'linear-gradient(135deg,#ff0000,#cc0000)',
  'Spotify':   'linear-gradient(135deg,#3ddc84,#00aa66)',
  'Netflix':   'linear-gradient(135deg,#cc0000,#880000)',
  'Snapchat':  'linear-gradient(135deg,#ffcc00,#ff8800)',
  'Twitter':   'linear-gradient(135deg,#00e5ff,#0088ff)',
  'Facebook':  'linear-gradient(135deg,#1a88ff,#0066ff)',
  'Telegram':  'linear-gradient(135deg,#00e5ff,#0088ff)'
};

function refreshPage2() {
  const installed = getInstalledApps();
  const build = function(container) {
    container.innerHTML = '';
    installed.forEach(function(name) {
      const color = STORE_APPS[name] || 'linear-gradient(135deg,#555,#222)';
      const el = document.createElement('div');
      el.className = 'app';
      el.textContent = name.charAt(0);
      el.setAttribute('data-label', name);
      el.style.background = color;
      el.style.color = '#fff';
      el.style.fontWeight = '900';
      el.addEventListener('click', function() { soundTap(); openApp(name); });
      container.appendChild(el);
    });
  };
  const ip2 = document.getElementById('iphoneIcons2');
  const an2 = document.getElementById('androidIcons2');
  if (ip2) build(ip2);
  if (an2) build(an2);
}

function switchPage(brand, dir) {
  const installedCount = getInstalledApps().length;
  if (brand === 'iphone') {
    const maxPage = installedCount > 0 ? 1 : 0;
    iphonePage = Math.max(0, Math.min(maxPage, iphonePage + dir));
    document.getElementById('iphoneIcons').classList.toggle('hidden', iphonePage !== 0);
    document.getElementById('iphoneIcons2').classList.toggle('hidden', iphonePage !== 1);
    document.querySelectorAll('#ipDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === iphonePage); });
  } else {
    const maxPage = installedCount > 0 ? 1 : 0;
    androidPage = Math.max(0, Math.min(maxPage, androidPage + dir));
    document.getElementById('androidIcons').classList.toggle('hidden', androidPage !== 0);
    document.getElementById('androidIcons2').classList.toggle('hidden', androidPage !== 1);
    document.querySelectorAll('#anDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === androidPage); });
  }
}

const DAILY_SPINS = 3;
function getTodayKey() {
  const d = new Date();
  return 'spins_' + d.getFullYear() + '-' + (d.getMonth()+1) + '-' + d.getDate();
}
function getSpinsToday() {
  const raw = localStorage.getItem(getTodayKey());
  return raw === null ? 0 : (parseInt(raw, 10) || 0);
}
function recordSpin() {
  localStorage.setItem(getTodayKey(), String(getSpinsToday() + 1));
  updateSpinCounter();
}
function spinsRemaining() { return Math.max(0, DAILY_SPINS - getSpinsToday()); }
function updateSpinCounter() {
  const remaining = spinsRemaining();
  spinCounter.textContent = 'Spins left today: ' + remaining;
  spinCounter.classList.remove('warning', 'empty');
  if (remaining === 0) {
    spinCounter.classList.add('empty');
    spinBtn.disabled = true;
    spinBtn.textContent = 'COME BACK TOMORROW';
  } else {
    if (remaining === 1) spinCounter.classList.add('warning');
    spinBtn.disabled = false;
    spinBtn.textContent = 'SPIN';
  }
}
setInterval(updateSpinCounter, 30000);

function getSavedPhones() {
  try { return JSON.parse(localStorage.getItem('savedPhones') || '[]'); }
  catch(e) { return []; }
}
function savePhoneToCollection(model, brand, number) {
  const saved = getSavedPhones();
  if (!saved.some(function(p) { return p.model === model; })) {
    saved.push({ model: model, brand: brand, number: number, savedAt: Date.now() });
    localStorage.setItem('savedPhones', JSON.stringify(saved));
  }
  refreshSaveButton();
}
function removePhoneFromCollection(model) {
  const saved = getSavedPhones().filter(function(p) { return p.model !== model; });
  localStorage.setItem('savedPhones', JSON.stringify(saved));
  refreshSaveButton();
}
function isPhoneSaved(model) {
  return getSavedPhones().some(function(p) { return p.model === model; });
}
function refreshSaveButton() {
  if (!currentModel) return;
  if (isPhoneSaved(currentModel)) {
    saveBtn.textContent = '*';
    saveBtn.classList.add('saved');
  } else {
    saveBtn.textContent = 'o';
    saveBtn.classList.remove('saved');
  }
}
saveBtn.addEventListener('click', function() {
  if (!currentModel) return;
  soundClick();
  if (isPhoneSaved(currentModel)) removePhoneFromCollection(currentModel);
  else savePhoneToCollection(currentModel, currentBrand, currentPhoneNumber);
});

function generatePhoneNumber() {
  const areaCodes = ['212','310','415','305','404','617','702','713','206','312','646','718'];
  const area = areaCodes[Math.floor(Math.random() * areaCodes.length)];
  const prefix = String(Math.floor(Math.random() * 900) + 100);
  const line = String(Math.floor(Math.random() * 9000) + 1000);
  return '+1 (' + area + ') ' + prefix + '-' + line;
}

function buildIcons(container, apps) {
  container.innerHTML = '';
  apps.forEach(function(app) {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = app.label.charAt(0);
    el.setAttribute('data-label', app.label);
    el.style.background = app.color;
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() { soundTap(); openApp(app.label); });
    container.appendChild(el);
  });
}
buildIcons(iphoneIcons, iosApps);
buildIcons(androidIcons, androidApps);

window.addEventListener('load', function() {
  const saved = localStorage.getItem('userName');
  if (saved) userName = saved;
  else setupScreen.classList.remove('hidden');
  updateSpinCounter();
  refreshPage2();
  soundEnabled = localStorage.getItem('soundEnabled') !== 'false';
  settingsState.sounds = soundEnabled;
});
saveNameBtn.addEventListener('click', function() {
  const val = nameInput.value.trim();
  if (!val) { nameInput.focus(); return; }
  userName = val;
  localStorage.setItem('userName', val);
  setupScreen.classList.add('hidden');
  soundClick();
});
nameInput.addEventListener('keydown', function(e) {
  if (e.key === 'Enter') saveNameBtn.click();
});

function getIphoneBackImage(model) {
  if (model === 'iPhone 7') return IMAGES.iphone7_back;
  if (model === 'iPhone X') return IMAGES.iphoneX_back;
  if (model === 'iPhone XR') return IMAGES.iphoneXR_back;
  if (model === 'iPhone 11' || model === 'iPhone 12' || model === 'iPhone 13 Pro Max' || model === 'iPhone 14' || model === 'iPhone 15 Pro') return IMAGES.iphone11to15_back;
  if (model === 'iPhone 16') return IMAGES.iphone16_back;
  if (model === 'iPhone 16e') return IMAGES.iphone16e_back;
  if (model === 'iPhone 17e') return IMAGES.iphone17e_back;
  if (model === 'iPhone 17 Pro Max') return IMAGES.iphone17_back;
  return IMAGES.iphone11to15_back;
}
spinBtn.addEventListener('click', function() {
  if (spinning) return;
  if (spinsRemaining() <= 0) { updateSpinCounter(); return; }
  spinning = true;
  spinBtn.disabled = true;
  recordSpin();
  soundClick();
  result.classList.add('hidden');
  loading.classList.add('hidden');
  const isIPhone = Math.random() < 0.5;
  currentBrand = isIPhone ? 'iphone' : 'android';
  const targetAngle = isIPhone ? 90 : 270;
  const fullSpins = 5 + Math.floor(Math.random() * 3);
  const delta = ((targetAngle - (currentRotation % 360)) + 360) % 360;
  currentRotation = currentRotation + (fullSpins * 360) + delta;
  wheel.style.transform = 'rotate(' + currentRotation + 'deg)';
  setTimeout(function() {
    loading.classList.remove('hidden');
    loadingText.textContent = 'Scanning devices...';
    setTimeout(function() { loadingText.textContent = isIPhone ? 'Finding an iPhone...' : 'Finding an Android...'; }, 700);
    setTimeout(function() { loadingText.textContent = 'Almost there...'; }, 1400);
    setTimeout(function() {
      loading.classList.add('hidden');
      const list = isIPhone ? iPhones : androids;
      const picked = list[Math.floor(Math.random() * list.length)];
      currentModel = picked;
      currentPhoneNumber = generatePhoneNumber();
      prizeName.textContent = picked;
      if (!isIPhone) {
        const brand = picked.split(' ')[0];
        androidBrand.textContent = brand.toUpperCase();
      }
      result.classList.remove('hidden');
      soundWin();
      spinning = false;
      updateSpinCounter();
    }, 2000);
  }, 4200);
});

miniPhone.addEventListener('click', function() {
  soundClick();
  openPhoneViewer(currentModel, currentBrand, currentPhoneNumber);
});

function openPhoneViewer(model, brand, number) {
  const iphoneFrontEl = document.querySelector('.iphone-front');
  if (iphoneFrontEl) {
    iphoneFrontEl.classList.remove('show-home-button', 'show-home-bar');
    if (brand === 'iphone') {
      if (model === 'iPhone 7') iphoneFrontEl.classList.add('show-home-button');
      else iphoneFrontEl.classList.add('show-home-bar');
    }
  }
  currentModel = model;
  currentBrand = brand;
  currentPhoneNumber = number;
  phoneStage.className = brand;
  flipCard.classList.remove('flipped');
  appScreen.classList.add('hidden');
  iphonePage = 0;
  androidPage = 0;
  if (document.getElementById('iphoneIcons')) document.getElementById('iphoneIcons').classList.remove('hidden');
  if (document.getElementById('iphoneIcons2')) document.getElementById('iphoneIcons2').classList.add('hidden');
  if (document.getElementById('androidIcons')) document.getElementById('androidIcons').classList.remove('hidden');
  if (document.getElementById('androidIcons2')) document.getElementById('androidIcons2').classList.add('hidden');
  document.querySelectorAll('#ipDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === 0); });
  document.querySelectorAll('#anDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === 0); });
  refreshPage2();
  if (brand === 'iphone') { iphoneBackImg.src = getIphoneBackImage(model); }
  else {
    androidBackImg.src = IMAGES.android_back;
    androidBrand.textContent = model.split(' ')[0].toUpperCase();
  }
  refreshSaveButton();
  phoneViewer.classList.remove('hidden');
  const lock = document.getElementById('lockScreen');
  if (lock) { lock.classList.remove('hidden'); lock.style.display = 'flex'; }
  const pwScreen = document.getElementById('passwordScreen');
  if (pwScreen) { pwScreen.classList.add('hidden'); pwScreen.style.display = 'none'; }
  updateLockClock();
}

rotateBtn.addEventListener('click', function() {
  if (!appScreen.classList.contains('hidden')) return;
  soundClick();
  flipCard.classList.toggle('flipped');
});

closeBtn.addEventListener('click', function() {
  soundClick();
  phoneViewer.classList.add('hidden');
  flipCard.classList.remove('flipped');
  appScreen.classList.add('hidden');
  const lock = document.getElementById('lockScreen');
  if (lock) lock.classList.add('hidden');
  const pw = document.getElementById('passwordScreen');
  if (pw) pw.classList.add('hidden');
});

function openApp(name) {
  appScreenContent.innerHTML = '';
  appScreen.classList.remove('hidden');
  flipCard.classList.remove('flipped');
  if (name === 'Settings') renderSettings();
  else if (name === 'App Store' || name === 'Play Store') renderStore(name);
  else if (name === 'Phone') renderPhoneApp();
  else if (name === 'Calculator') renderCalculator();
  else if (name === 'WhatsApp') renderWhatsApp();
  else if (name === 'YouTube') renderYouTube();
  else if (name === 'Instagram') renderInstagram();
  else if (name === 'TikTok') renderTikTok();
  else if (name === 'Spotify') renderSpotify();
  else if (name === 'Netflix') renderNetflix();
  else if (name === 'Facebook') renderFacebook();
  else if (name === 'Twitter') renderTwitter();
  else if (name === 'Snapchat') renderSnapchat();
  else if (name === 'Telegram') renderTelegram();
  else renderPlaceholder(name);
}

let calcState = { display: '0', firstNumber: null, operator: null, waitingForSecond: false };

function renderCalculator() {
  let html = '<div style="display:flex;flex-direction:column;height:100%;">';
  html += '<div class="calc-display" id="calcDisplay">' + calcState.display + '</div>';
  html += '<div class="calc-grid">';
  html += '<button class="calc-btn gray" data-calc="AC">AC</button>';
  html += '<button class="calc-btn gray" data-calc="+/-">+/-</button>';
  html += '<button class="calc-btn gray" data-calc="%">%</button>';
  html += '<button class="calc-btn op" data-calc="/">/</button>';
  html += '<button class="calc-btn" data-calc="7">7</button>';
  html += '<button class="calc-btn" data-calc="8">8</button>';
  html += '<button class="calc-btn" data-calc="9">9</button>';
  html += '<button class="calc-btn op" data-calc="*">x</button>';
  html += '<button class="calc-btn" data-calc="4">4</button>';
  html += '<button class="calc-btn" data-calc="5">5</button>';
  html += '<button class="calc-btn" data-calc="6">6</button>';
  html += '<button class="calc-btn op" data-calc="-">-</button>';
  html += '<button class="calc-btn" data-calc="1">1</button>';
  html += '<button class="calc-btn" data-calc="2">2</button>';
  html += '<button class="calc-btn" data-calc="3">3</button>';
  html += '<button class="calc-btn op" data-calc="+">+</button>';
  html += '<button class="calc-btn zero" data-calc="0">0</button>';
  html += '<button class="calc-btn" data-calc=".">.</button>';
  html += '<button class="calc-btn op" data-calc="=">=</button>';
  html += '</div></div>';
  appScreenContent.innerHTML = html;
  appScreenContent.querySelectorAll('.calc-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      calcHandleKey(btn.getAttribute('data-calc'));
    });
  });
}

function calcUpdateDisplay() {
  const el = document.getElementById('calcDisplay');
  if (el) el.textContent = calcState.display;
}
function calcInput(digit) {
  if (calcState.waitingForSecond) {
    calcState.display = digit;
    calcState.waitingForSecond = false;
  } else {
    calcState.display = calcState.display === '0' ? digit : calcState.display + digit;
  }
  if (calcState.display.length > 12) calcState.display = calcState.display.slice(0, 12);
  calcUpdateDisplay();
}
function calcDecimal() {
  if (calcState.waitingForSecond) {
    calcState.display = '0.';
    calcState.waitingForSecond = false;
  } else if (calcState.display.indexOf('.') === -1) {
    calcState.display += '.';
  }
  calcUpdateDisplay();
}
function calcClear() {
  calcState.display = '0';
  calcState.firstNumber = null;
  calcState.operator = null;
  calcState.waitingForSecond = false;
  calcUpdateDisplay();
}
function calcToggleSign() {
  if (calcState.display.charAt(0) === '-') calcState.display = calcState.display.slice(1);
  else if (calcState.display !== '0') calcState.display = '-' + calcState.display;
  calcUpdateDisplay();
}
function calcPercent() {
  calcState.display = String(parseFloat(calcState.display) / 100);
  calcUpdateDisplay();
}
function calcCalculate(a, b, op) {
  a = parseFloat(a);
  b = parseFloat(b);
  if (op === '+') return a + b;
  if (op === '-') return a - b;
  if (op === '*') return a * b;
  if (op === '/') return b === 0 ? 'Error' : a / b;
  return b;
}
function calcOperator(op) {
  const current = parseFloat(calcState.display);
  if (calcState.firstNumber === null) {
    calcState.firstNumber = current;
  } else if (!calcState.waitingForSecond) {
    const r = calcCalculate(calcState.firstNumber, current, calcState.operator);
    if (r === 'Error') {
      calcState.display = 'Error';
      calcUpdateDisplay();
      calcClear();
      return;
    }
    calcState.display = String(r);
    calcState.firstNumber = r;
    calcUpdateDisplay();
  }
  calcState.operator = op;
  calcState.waitingForSecond = true;
}
function calcEquals() {
  if (calcState.operator === null || calcState.firstNumber === null) return;
  const current = parseFloat(calcState.display);
  const r = calcCalculate(calcState.firstNumber, current, calcState.operator);
  calcState.display = r === 'Error' ? 'Error' : String(Math.round(r * 100000000) / 100000000);
  calcState.firstNumber = null;
  calcState.operator = null;
  calcState.waitingForSecond = false;
  calcUpdateDisplay();
}
function calcHandleKey(key) {
  soundClick();
  if (key >= '0' && key <= '9') { calcInput(key); return; }
  if (key === '.') { calcDecimal(); return; }
  if (key === 'AC') { calcClear(); return; }
  if (key === '+/-') { calcToggleSign(); return; }
  if (key === '%') { calcPercent(); return; }
  if (key === '=') { calcEquals(); return; }
  if (key === '+' || key === '-' || key === '*' || key === '/') { calcOperator(key); return; }
}
function renderWhatsApp() {
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#3ddc84;margin:0 0 16px;">WhatsApp</h2>';
  const chats = [
    { name: 'Mom', msg: 'Did you eat?', time: 'now' },
    { name: 'John', msg: 'See you tomorrow', time: '5m' },
    { name: 'Sarah', msg: 'Sent a photo', time: '1h' },
    { name: 'Work Group', msg: 'Alex: Meeting at 3pm', time: '2h' },
    { name: 'David', msg: 'Okay thanks!', time: '1d' },
    { name: 'Emma', msg: 'Nice', time: '2d' }
  ];
  const colors = ['#00e5ff','#ff006e','#3ddc84','#ffcc00','#a855f7','#ff6699'];
  for (let i = 0; i < chats.length; i++) {
    html += '<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:48px;height:48px;border-radius:50%;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:18px;color:#fff;flex-shrink:0;">' + chats[i].name.charAt(0) + '</div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:14px;font-weight:600;margin-bottom:2px;">' + chats[i].name + '</div>';
    html += '<div style="font-size:12px;color:rgba(255,255,255,0.55);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + chats[i].msg + '</div></div>';
    html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);flex-shrink:0;">' + chats[i].time + '</div></div>';
  }
  appScreenContent.innerHTML = html;
}

function renderYouTube() {
  let html = '<div style="background:#ff0000;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">YouTube</div>';
  const videos = [
    { title: 'How to build an app', ch: 'Tech Tips', dur: '12:34', views: '1.2M views' },
    { title: 'Best songs 2026', ch: 'Music World', dur: '3:45', views: '892K views' },
    { title: 'Funny cats compilation', ch: 'Funny Pets', dur: '8:21', views: '5.4M views' },
    { title: 'Learn coding fast', ch: 'CodeMaster', dur: '22:10', views: '340K views' },
    { title: 'Top 10 phones 2026', ch: 'Tech Review', dur: '15:02', views: '2.1M views' }
  ];
  videos.forEach(function(v) {
    html += '<div style="display:flex;gap:12px;margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:120px;height:70px;background:linear-gradient(135deg,#333,#111);border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:16px;position:relative;color:#fff;font-weight:700;">PLAY<span style="position:absolute;bottom:4px;right:4px;background:rgba(0,0,0,0.8);font-size:10px;padding:2px 4px;border-radius:3px;font-weight:400;">' + v.dur + '</span></div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;margin-bottom:4px;">' + v.title + '</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.5);">' + v.ch + '</div>';
    html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);">' + v.views + '</div></div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderInstagram() {
  let html = '<div style="background:linear-gradient(90deg,#ff006e,#a855f7);padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Instagram</div>';
  const posts = [
    { user: 'sarah_official', likes: '2,341', caption: 'Sunset vibes' },
    { user: 'john.photo', likes: '890', caption: 'New camera' },
    { user: 'travel_world', likes: '12,402', caption: 'Beach day' },
    { user: 'foodie_life', likes: '3,120', caption: 'Best pizza ever' }
  ];
  const colors = ['#ff6699','#00e5ff','#ffcc00','#a855f7'];
  posts.forEach(function(p, i) {
    html += '<div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">';
    html += '<div style="width:32px;height:32px;border-radius:50%;background:' + colors[i] + ';"></div>';
    html += '<div style="font-size:12px;font-weight:600;">' + p.user + '</div></div>';
    html += '<div style="width:100%;height:180px;border-radius:10px;background:linear-gradient(135deg,' + colors[i] + ',#222);margin-bottom:8px;"></div>';
    html += '<div style="font-size:12px;margin-bottom:4px;">' + p.likes + ' likes</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.65);">' + p.caption + '</div>';
    html += '</div>';
  });
  appScreenContent.innerHTML = html;
}

function renderTikTok() {
  let html = '<div style="background:linear-gradient(90deg,#ff006e,#00e5ff);padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">TikTok</div>';
  const videos = ['Dance trend', 'Funny cat', 'Cooking hack', 'Pet reveal', 'Life hack', 'Music remix'];
  const colors = ['#ff006e','#a855f7','#00e5ff','#3ddc84','#ffcc00','#ff6699'];
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">';
  videos.forEach(function(v, i) {
    html += '<div style="aspect-ratio:9/16;border-radius:10px;background:linear-gradient(180deg,' + colors[i] + ',#111);position:relative;overflow:hidden;">';
    html += '<div style="position:absolute;bottom:8px;left:8px;right:8px;font-size:10px;color:#fff;font-weight:600;">' + v + '</div>';
    html += '</div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
}

function renderSpotify() {
  let html = '<div style="background:linear-gradient(90deg,#3ddc84,#00aa66);padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Spotify</div>';
  const songs = [
    { title: 'Blinding Lights', artist: 'The Weeknd', dur: '3:20' },
    { title: 'Levitating', artist: 'Dua Lipa', dur: '3:23' },
    { title: 'Stay', artist: 'Kid Laroi', dur: '2:21' },
    { title: 'Heat Waves', artist: 'Glass Animals', dur: '3:58' },
    { title: 'As It Was', artist: 'Harry Styles', dur: '2:47' },
    { title: 'Bad Habit', artist: 'Steve Lacy', dur: '3:52' }
  ];
  html += '<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);margin-bottom:10px;">PLAYLIST - LIKED SONGS</div>';
  songs.forEach(function(s, i) {
    html += '<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.4);width:14px;">' + (i+1) + '</div>';
    html += '<div style="width:36px;height:36px;border-radius:6px;background:linear-gradient(135deg,#3ddc84,#0088ff);flex-shrink:0;"></div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;">' + s.title + '</div><div style="font-size:11px;color:rgba(255,255,255,0.5);">' + s.artist + '</div></div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.4);">' + s.dur + '</div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderNetflix() {
  let html = '<div style="background:#cc0000;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">NETFLIX</div>';
  const shows = [
    { title: 'Money Heist', genre: 'Action - Thriller' },
    { title: 'Stranger Things', genre: 'Sci-Fi - Horror' },
    { title: 'The Witcher', genre: 'Fantasy - Adventure' },
    { title: 'Squid Game', genre: 'Drama - Thriller' },
    { title: 'Wednesday', genre: 'Comedy - Mystery' }
  ];
  const colors = ['#cc0000','#a855f7','#3ddc84','#ff006e','#333'];
  shows.forEach(function(s, i) {
    html += '<div style="display:flex;gap:12px;margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:80px;height:120px;border-radius:8px;background:linear-gradient(180deg,' + colors[i] + ',#111);flex-shrink:0;"></div>';
    html += '<div style="flex:1;padding-top:8px;"><div style="font-size:14px;font-weight:700;margin-bottom:6px;">' + s.title + '</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.5);margin-bottom:8px;">' + s.genre + '</div>';
    html += '<div style="display:inline-block;background:#fff;color:#000;font-size:10px;font-weight:700;padding:4px 12px;border-radius:4px;">PLAY</div></div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderFacebook() {
  let html = '<div style="background:#1a88ff;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Facebook</div>';
  const posts = [
    { user: 'Sarah Johnson', time: '2h', text: 'Had an amazing day at the beach!' },
    { user: 'John Smith', time: '5h', text: 'Just finished my new project' },
    { user: 'Tech News', time: '1d', text: 'iPhone 17 Pro Max review is out!' }
  ];
  const colors = ['#00e5ff','#3ddc84','#ffcc00'];
  posts.forEach(function(p, i) {
    html += '<div style="background:rgba(255,255,255,0.04);border-radius:12px;padding:14px;margin-bottom:12px;">';
    html += '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">';
    html += '<div style="width:36px;height:36px;border-radius:50%;background:' + colors[i] + ';"></div>';
    html += '<div><div style="font-size:13px;font-weight:600;">' + p.user + '</div><div style="font-size:10px;color:rgba(255,255,255,0.4);">' + p.time + ' ago</div></div></div>';
    html += '<div style="font-size:12px;color:rgba(255,255,255,0.85);margin-bottom:10px;">' + p.text + '</div>';
    html += '<div style="display:flex;gap:16px;font-size:11px;color:rgba(255,255,255,0.5);">Like  Comment  Share</div>';
    html += '</div>';
  });
  appScreenContent.innerHTML = html;
}

function renderTwitter() {
  let html = '<div style="background:#00e5ff;color:#0a0f1e;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Twitter</div>';
  const tweets = [
    { user: '@techguru', text: 'Just got my hands on the new iPhone 17 Pro!', time: '2m' },
    { user: '@newsupdate', text: 'Breaking: New AI model released today', time: '15m' },
    { user: '@foodie', text: 'Best pizza in town, highly recommend!', time: '1h' },
    { user: '@coder_life', text: 'JavaScript tip: use const by default', time: '3h' }
  ];
  const colors = ['#00e5ff','#ff006e','#3ddc84','#ffcc00'];
  tweets.forEach(function(t, i) {
    html += '<div style="padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);display:flex;gap:12px;">';
    html += '<div style="width:36px;height:36px;border-radius:50%;background:' + colors[i] + ';flex-shrink:0;"></div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:12px;font-weight:600;margin-bottom:4px;">' + t.user + ' - ' + t.time + '</div>';
    html += '<div style="font-size:13px;color:rgba(255,255,255,0.85);margin-bottom:6px;">' + t.text + '</div>';
    html += '<div style="display:flex;gap:16px;font-size:11px;color:rgba(255,255,255,0.45);">Reply  Retweet  Like</div></div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderSnapchat() {
  let html = '<div style="background:#ffcc00;color:#000;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Snapchat</div>';
  html += '<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);margin-bottom:12px;">RECENT SNAPS</div>';
  const snaps = ['Sarah','John','Emma','Mike','Lisa','David','Anna','Tom'];
  const colors = ['#ffcc00','#ff006e','#00e5ff','#3ddc84','#a855f7','#ff6699','#ff8800','#00aa66'];
  html += '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">';
  snaps.forEach(function(n, i) {
    html += '<div style="aspect-ratio:3/4;border-radius:10px;background:linear-gradient(180deg,' + colors[i] + ',#222);position:relative;display:flex;align-items:flex-end;padding:8px;">';
    html += '<div style="font-size:12px;font-weight:600;">' + n + '</div></div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
}

function renderTelegram() {
  let html = '<div style="background:#00e5ff;color:#0a0f1e;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Telegram</div>';
  const chats = [
    { name: 'Family Group', msg: 'Mom: See you soon!', time: 'now' },
    { name: 'Crypto News', msg: 'BTC up 5% today', time: '10m' },
    { name: 'Tech Friends', msg: 'Alex: Anyone tried the new iPhone?', time: '1h' },
    { name: 'Study Group', msg: 'Exam notes shared', time: '3h' }
  ];
  const colors = ['#00e5ff','#3ddc84','#ff006e','#ffcc00'];
  chats.forEach(function(c, i) {
    html += '<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:44px;height:44px;border-radius:50%;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;color:#fff;flex-shrink:0;">' + c.name.charAt(0) + '</div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;">' + c.name + '</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.55);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + c.msg + '</div></div>';
    html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);">' + c.time + '</div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderPlaceholder(name) {
  let html = '';
  if (name === 'Messages') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">Messages</h2>';
    const names = ['Mom','John','Sarah','Work Group','David','Emma'];
    const colors = ['#00e5ff','#ff006e','#3ddc84','#ffcc00','#a855f7','#ff6699'];
    const times = ['now','5m','1h','2h','3h','1d'];
    for (let i = 0; i < names.length; i++) {
      html += '<div style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(255,255,255,0.05);border-radius:12px;margin-bottom:8px;">';
      html += '<div style="width:44px;height:44px;border-radius:50%;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;color:#fff;">' + names[i].charAt(0) + '</div>';
      html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;">' + names[i] + '</div><div style="font-size:11px;color:rgba(255,255,255,0.5);">Hey, how are you?</div></div>';
      html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);">' + times[i] + '</div></div>';
    }
  } else if (name === 'Safari' || name === 'Chrome') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">' + name + '</h2>';
    html += '<div style="background:rgba(255,255,255,0.08);border-radius:12px;padding:10px 14px;margin-bottom:16px;"><span style="font-size:12px;color:rgba(255,255,255,0.7);">Search or type URL</span></div>';
    const sites = ['Google','YouTube','Facebook','Twitter','Instagram','Reddit'];
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">';
    for (let i = 0; i < sites.length; i++) {
      html += '<div style="background:rgba(255,255,255,0.06);border-radius:12px;padding:16px;text-align:center;">';
      html += '<div style="font-size:11px;color:rgba(255,255,255,0.7);">' + sites[i] + '</div></div>';
    }
    html += '</div>';
  } else if (name === 'Camera') {
    html += '<div style="display:flex;flex-direction:column;height:100%;">';
    html += '<div style="flex:1;width:100%;background:linear-gradient(135deg,#0a0f1e,#1a2238);border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:16px;color:#fff;font-weight:900;">CAMERA</div>';
    html += '<div style="display:flex;gap:24px;align-items:center;justify-content:center;padding-bottom:10px;">';
    html += '<div style="width:70px;height:70px;border-radius:50%;background:#fff;border:4px solid #ccc;"></div>';
    html += '</div></div>';
  } else if (name === 'Music') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#ff006e;margin:0 0 16px;">Now Playing</h2>';
    html += '<div style="background:linear-gradient(135deg,#ff006e,#a855f7);border-radius:16px;aspect-ratio:1/1;max-width:180px;margin:0 auto 16px;"></div>';
    html += '<div style="text-align:center;margin-bottom:20px;"><div style="font-size:15px;font-weight:700;margin-bottom:4px;">Blinding Lights</div><div style="font-size:11px;color:rgba(255,255,255,0.5);">The Weeknd</div></div>';
  } else if (name === 'Notes') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#ffcc00;margin:0 0 16px;">Notes</h2>';
    const notes = ['Shopping List','Meeting notes','Ideas','To-Do','Birthday plans'];
    const dates = ['Today','Yesterday','3 days ago','Last week','2 weeks ago'];
    for (let i = 0; i < notes.length; i++) {
      html += '<div style="padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);"><div style="font-size:13px;font-weight:600;margin-bottom:2px;">' + notes[i] + '</div><div style="font-size:11px;color:rgba(255,255,255,0.4);">' + dates[i] + '</div></div>';
    }
  } else if (name === 'Photos' || name === 'Gallery') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#ff6699;margin:0 0 16px;">' + name + '</h2>';
    html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px;">';
    const colors = ['#ff6699','#00e5ff','#3ddc84','#ffcc00','#a855f7','#ff006e'];
    for (let i = 0; i < 18; i++) {
      html += '<div style="aspect-ratio:1/1;background:linear-gradient(135deg,' + colors[i % 6] + ',#222);border-radius:4px;"></div>';
    }
    html += '</div>';
  } else {
    html += '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;"><h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;">' + name + '</h2></div>';
  }
  appScreenContent.innerHTML = html;
}

function renderPhoneApp() {
  let html = '<div style="display:flex;flex-direction:column;align-items:center;padding-top:20px;text-align:center;">';
  html += '<div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#3ddc84,#00aa66);display:flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:18px;color:#fff;font-weight:900;">PHONE</div>';
  html += '<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);margin-bottom:6px;">MY NUMBER</div>';
  html += '<div style="font-size:18px;font-weight:700;letter-spacing:1px;color:#3ddc84;margin-bottom:20px;">' + (currentPhoneNumber || 'No SIM') + '</div>';
  html += '<div style="font-size:12px;color:rgba(255,255,255,0.5);letter-spacing:1px;margin-bottom:24px;">Carrier: ' + (currentBrand === 'iphone' ? 'T-Mobile' : 'Verizon') + '</div>';
  html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;width:100%;max-width:240px;">';
  const nums = [1,2,3,4,5,6,7,8,9,'*',0,'#'];
  for (let i = 0; i < nums.length; i++) {
    html += '<div style="width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,0.08);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:600;color:#fff;">' + nums[i] + '</div>';
  }
  html += '</div></div>';
  appScreenContent.innerHTML = html;
}

function renderStore(name) {
  const isApple = name === 'App Store';
  const list = isApple ? ['Instagram','WhatsApp','TikTok','YouTube','Spotify','Netflix','Snapchat','Twitter'] : ['Facebook','WhatsApp','TikTok','YouTube','Spotify','Netflix','Telegram','Instagram'];
  const colors = ['#ff006e','#3ddc84','#00e5ff','#ffcc00','#a855f7','#ff6699','#00aa66','#ff6600'];
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">' + name + '</h2>';
  for (let i = 0; i < list.length; i++) {
    const installed = isAppInstalled(list[i]);
    const btnClass = installed ? 'store-open-btn' : 'store-get-btn';
    const btnText = installed ? 'OPEN' : 'GET';
    const btnColor = installed ? '#3ddc84' : '#00e5ff';
    html += '<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:44px;height:44px;border-radius:12px;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:18px;color:#fff;">' + list[i].charAt(0) + '</div>';
    html += '<div style="flex:1;"><div style="font-size:13px;font-weight:600;">' + list[i] + '</div><div style="font-size:10px;color:rgba(255,255,255,0.4);">Free - Get</div></div>';
    html += '<button class="' + btnClass + '" data-app="' + list[i] + '" style="padding:6px 16px;font-size:11px;border-radius:20px;background:' + btnColor + ';color:#0a0f1e;border:none;font-weight:700;box-shadow:none;">' + btnText + '</button></div>';
  }
  appScreenContent.innerHTML = html;
}

function renderSettings() {
  const usedGB = 64, totalGB = 128;
  const pct = Math.round((usedGB / totalGB) * 100);
  const initial = userName ? userName.charAt(0).toUpperCase() : '?';
  let html = '';
  html += '<div class="settings-profile"><div class="profile-avatar">' + initial + '</div>';
  html += '<div class="profile-info"><div class="profile-name">' + escapeHtml(userName || 'Your Name') + '</div>';
  html += '<div class="profile-sub">' + (currentBrand === 'iphone' ? 'Apple ID, iCloud' : 'Samsung Account') + '</div></div></div>';
  html += '<div class="section-heading">Connectivity</div><div class="settings-section">';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#007aff;">W</div><div class="settings-label">Wi-Fi</div><div class="settings-value">Home_5G</div><div class="toggle ' + (settingsState.wifi ? 'on' : '') + '" data-key="wifi"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#007aff;">B</div><div class="settings-label">Bluetooth</div><div class="toggle ' + (settingsState.bluetooth ? 'on' : '') + '" data-key="bluetooth"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#34c759;">M</div><div class="settings-label">Mobile Data</div><div class="toggle ' + (settingsState.mobileData ? 'on' : '') + '" data-key="mobileData"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#00aa66;">N</div><div class="settings-label">My Number</div><div class="settings-value">' + (currentPhoneNumber || '-') + '</div></div>';
  html += '</div>';
  html += '<div class="section-heading">Device</div><div class="settings-section">';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#ff9500;">B</div><div class="settings-label">Battery</div><div class="settings-value" id="batteryValue">' + battery + '%</div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#5856d6;">S</div><div class="settings-label">Storage</div><div class="settings-value">' + usedGB + ' GB of ' + totalGB + ' GB</div></div>';
  html += '<div style="padding:0 0 12px 44px;"><div class="storage-bar"><div class="storage-fill" style="width:' + pct + '%"></div></div>';
  html += '<div class="storage-labels"><span>Used: ' + usedGB + ' GB</span><span>Free: ' + (totalGB - usedGB) + ' GB</span></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#ff2d55;">N</div><div class="settings-label">Notifications</div><div class="toggle ' + (settingsState.notifications ? 'on' : '') + '" data-key="notifications"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#af52de;">S</div><div class="settings-label">Sounds</div><div class="toggle ' + (settingsState.sounds ? 'on' : '') + '" data-key="sounds"></div></div>';
  html += '</div>';

  const hasPw = getPassword() !== '';
  html += '<div class="section-heading">Security</div><div class="settings-section">';
  html += '<div class="settings-row" id="settingsPasswordRow">';
  html += '<div class="settings-icon" style="background:#ff2d55;">L</div>';
  html += '<div class="settings-label">' + (hasPw ? 'Change Password' : 'Set Password') + '</div>';
  html += '<div class="settings-value">' + (hasPw ? '....' : 'Off') + '</div></div>';
  if (hasPw) {
    html += '<div class="settings-row" id="settingsRemovePwRow">';
    html += '<div class="settings-icon" style="background:#ff6600;">U</div>';
    html += '<div class="settings-label">Remove Password</div>';
    html += '<div class="settings-value">Tap to remove</div></div>';
  }
  html += '</div>';

  html += '<div class="section-heading">About</div><div class="settings-section">';
  html += '<div class="info-block"><span>Name</span><strong>' + escapeHtml(currentModel || 'Unknown') + '</strong></div>';
  html += '<div class="info-block"><span>Model</span><strong>' + escapeHtml(currentModel || 'Unknown') + '</strong></div>';
  html += '<div class="info-block"><span>Capacity</span><strong>' + totalGB + ' GB</strong></div>';
  html += '<div class="info-block"><span>OS Version</span><strong>' + (currentBrand === 'iphone' ? 'iOS 18.2' : 'Android 15') + '</strong></div>';
  html += '<div class="info-block"><span>Serial</span><strong>' + randomSerial() + '</strong></div>';
  html += '<div class="info-block"><span>Owner</span><strong>' + escapeHtml(userName || '-') + '</strong></div>';
  html += '</div>';
  appScreenContent.innerHTML = html;

  appScreenContent.querySelectorAll('.toggle').forEach(function(t) {
    t.addEventListener('click', function() {
      const key = t.dataset.key;
      settingsState[key] = !settingsState[key];
      t.classList.toggle('on', settingsState[key]);
      if (key === 'sounds') {
        soundEnabled = settingsState.sounds;
        localStorage.setItem('soundEnabled', soundEnabled ? 'true' : 'false');
        if (soundEnabled) soundClick();
      } else {
        soundClick();
      }
    });
  });

  const pwRow = document.getElementById('settingsPasswordRow');
  if (pwRow) {
    pwRow.addEventListener('click', function() {
      soundClick();
      const newPw = prompt('Enter a new 4-6 digit password:');
      if (newPw === null) return;
      const clean = String(newPw || '').replace(/[^0-9]/g, '');
      if (clean.length < 4 || clean.length > 6) { alert('Password must be 4-6 digits.'); return; }
      setPassword(clean);
      renderSettings();
    });
  }
  const removeRow = document.getElementById('settingsRemovePwRow');
  if (removeRow) {
    removeRow.addEventListener('click', function() {
      soundClick();
      if (confirm('Remove password?')) { removePassword(); renderSettings(); }
    });
  }
}

function escapeHtml(s) { return String(s).replace(/[&<>"']/g, function(c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function randomSerial() { const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789'; let s = ''; for (let i = 0; i < 12; i++) s += chars[Math.floor(Math.random() * chars.length)]; return s; }

setInterval(function() {
  if (battery > 1) {
    battery -= 1;
    ipBatteryEl.textContent = battery;
    anBatteryEl.textContent = battery;
    const bv = document.getElementById('batteryValue');
    if (bv) bv.textContent = battery + '%';
  }
}, 45000);

appBackBtn.addEventListener('click', function() { soundClick(); appScreen.classList.add('hidden'); });

myPhonesBtn.addEventListener('click', function() { soundClick(); renderMyPhones(); myPhonesScreen.classList.remove('hidden'); });
myPhonesBackBtn.addEventListener('click', function() { soundClick(); myPhonesScreen.classList.add('hidden'); });

function renderMyPhones() {
  const saved = getSavedPhones();
  if (saved.length === 0) {
    myPhonesList.innerHTML = '<div class="empty-state">No saved phones yet.<br>Spin and tap the star to save one.</div>';
    return;
  }
  let html = '';
  for (let i = 0; i < saved.length; i++) {
    const p = saved[i];
    const img = p.brand === 'iphone' ? getIphoneBackImage(p.model) : IMAGES.android_back;
    html += '<div class="saved-phone-card" data-index="' + i + '">';
    html += '<img src="' + img + '" alt="">';
    html += '<div class="saved-phone-name">' + escapeHtml(p.model) + '</div>';
    html += '<div class="saved-phone-number">' + escapeHtml(p.number) + '</div>';
    html += '</div>';
  }
  myPhonesList.innerHTML = html;
  myPhonesList.querySelectorAll('.saved-phone-card').forEach(function(card) {
    card.addEventListener('click', function() {
      soundClick();
      const idx = parseInt(card.getAttribute('data-index'), 10);
      const p = getSavedPhones()[idx];
      if (!p) return;
      myPhonesScreen.classList.add('hidden');
      openPhoneViewer(p.model, p.brand, p.number);
    });
  });
}

function updateLockClock() {
  const now = new Date();
  const hours = now.getHours();
  const mins = String(now.getMinutes()).padStart(2, '0');
  const h12 = hours % 12 || 12;
  const clock = document.getElementById('lockClock');
  if (clock) clock.textContent = h12 + ':' + mins;
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const dateEl = document.getElementById('lockDate');
  if (dateEl) dateEl.textContent = days[now.getDay()] + ', ' + months[now.getMonth()] + ' ' + now.getDate();
}
setInterval(updateLockClock, 30000);

function getPassword() { return localStorage.getItem('phonePassword') || ''; }
function setPassword(pw) { localStorage.setItem('phonePassword', pw); }
function removePassword() { localStorage.removeItem('phonePassword'); }

function showPasswordScreen() {
  const lock = document.getElementById('lockScreen');
  if (lock) { lock.classList.add('hidden'); lock.style.display = 'none'; }
  const pwScreen = document.getElementById('passwordScreen');
  if (pwScreen) { pwScreen.classList.remove('hidden'); pwScreen.style.display = 'flex'; }
  pwInput = '';
  updatePwDots();
  const err = document.getElementById('pwError');
  if (err) err.classList.add('hidden');
}

function updatePwDots() {
  document.querySelectorAll('.pw-dot').forEach(function(d, i) {
    d.classList.toggle('filled', i < pwInput.length);
  });
}

function pwSubmit() {
  const stored = getPassword();
  if (pwInput === stored) { soundUnlock(); unlockPhone(); }
  else {
    soundWrong();
    const err = document.getElementById('pwError');
    if (err) err.classList.remove('hidden');
    pwInput = '';
    updatePwDots();
  }
}

function unlockPhone() {
  const pwScreen = document.getElementById('passwordScreen');
  if (pwScreen) { pwScreen.classList.add('hidden'); pwScreen.style.display = 'none'; }
  const lock = document.getElementById('lockScreen');
  if (lock) { lock.classList.add('hidden'); lock.style.display = 'none'; }
  pwInput = '';
}

document.addEventListener('touchstart', function(e) {
  const lock = document.getElementById('lockScreen');
  if (!lock || lock.classList.contains('hidden')) return;
  if (!e.touches || !e.touches[0]) return;
  lock.dataset.startY = e.touches[0].clientY;
}, { passive: true });
document.addEventListener('touchend', function(e) {
  const lock = document.getElementById('lockScreen');
  if (!lock || lock.classList.contains('hidden')) return;
  const startY = parseFloat(lock.dataset.startY || '0');
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dy = startY - e.changedTouches[0].clientY;
  if (dy > 40) {
    if (getPassword()) showPasswordScreen();
    else unlockPhone();
  }
}, { passive: true });

document.addEventListener('click', function(e) {
  const lock = document.getElementById('lockScreen');
  if (lock && !lock.classList.contains('hidden') && (e.target === lock || lock.contains(e.target))) {
    if (getPassword()) showPasswordScreen();
    else unlockPhone();
  }
});

document.addEventListener('click', function(e) {
  const key = e.target.closest && e.target.closest('.pw-key');
  if (!key) return;
  const val = key.getAttribute('data-key');
  if (!val || val === 'empty') return;
  if (val === 'del') { soundLockClick(); pwInput = pwInput.slice(0, -1); updatePwDots(); return; }
  soundLockClick();
  if (pwInput.length >= 6) return;
  pwInput += val;
  updatePwDots();
  if (pwInput.length === getPassword().length) setTimeout(pwSubmit, 200);
});

document.addEventListener('click', function(e) {
  const getBtn = e.target.closest && e.target.closest('.store-get-btn');
  if (getBtn) {
    const name = getBtn.getAttribute('data-app');
    if (isAppInstalled(name)) return;
    soundClick();
    getBtn.textContent = '...';
    getBtn.style.background = '#888';
    setTimeout(function() {
      installApp(name);
      getBtn.textContent = 'OPEN';
      getBtn.style.background = '#3ddc84';
      getBtn.classList.remove('store-get-btn');
      getBtn.classList.add('store-open-btn');
      soundUnlock();
    }, 1200);
    return;
  }
  const openBtn = e.target.closest && e.target.closest('.store-open-btn');
  if (openBtn) { soundTap(); openApp(openBtn.getAttribute('data-app')); }
});

document.addEventListener('click', function(e) {
  if (e.target.id === 'iphone7HomeBtn') { soundClick(); appScreen.classList.add('hidden'); switchPage(currentBrand, -100); }
  if (e.target.id === 'androidHome') { soundClick(); appScreen.classList.add('hidden'); switchPage(currentBrand, -100); }
  if (e.target.id === 'androidBack') { soundClick(); if (!appScreen.classList.contains('hidden')) appScreen.classList.add('hidden'); }
  if (e.target.id === 'androidRecent') { soundClick(); if (!appScreen.classList.contains('hidden')) appScreen.classList.add('hidden'); }
});

document.addEventListener('touchstart', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (appScreen && !appScreen.classList.contains('hidden')) return;
  const lock = document.getElementById('lockScreen');
  if (lock && !lock.classList.contains('hidden')) return;
  const pw = document.getElementById('passwordScreen');
  if (pw && !pw.classList.contains('hidden')) return;
  if (!e.touches || !e.touches[0]) return;
  phoneViewer.dataset.touchX = e.touches[0].clientX;
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (appScreen && !appScreen.classList.contains('hidden')) return;
  const lock = document.getElementById('lockScreen');
  if (lock && !lock.classList.contains('hidden')) return;
  const pw = document.getElementById('passwordScreen');
  if (pw && !pw.classList.contains('hidden')) return;
  const startX = parseFloat(phoneViewer.dataset.touchX || '0');
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dx = e.changedTouches[0].clientX - startX;
  if (Math.abs(dx) < 50) return;
  switchPage(currentBrand, dx < 0 ? 1 : -1);
}, { passive: true });

let homeSwipeStartY = 0;
document.addEventListener('touchstart', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (currentBrand !== 'iphone') return;
  if (currentModel === 'iPhone 7') return;
  if (!e.touches || !e.touches[0]) return;
  const stage = document.getElementById('phoneStage');
  if (!stage) return;
  const rect = stage.getBoundingClientRect();
  const touchY = e.touches[0].clientY;
  if (touchY > rect.top + rect.height * 0.85) homeSwipeStartY = touchY;
  else homeSwipeStartY = 0;
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (homeSwipeStartY === 0) return;
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dy = homeSwipeStartY - e.changedTouches[0].clientY;
  homeSwipeStartY = 0;
  if (dy > 50) { appScreen.classList.add('hidden'); switchPage(currentBrand, -100); }
}, { passive: true });
/* ============================================================
   CONTROL CENTER + TORCH + TIC TAC TOE
   ============================================================ */
let ccState = { wifi: true, bluetooth: true, mobileData: true, hotspot: false, airplane: false, screenRecord: false, torch: false, brightness: 80, volume: 70 };

function ensureControlCenter() {
  if (document.getElementById('controlCenter')) return;
  const cc = document.createElement('div');
  cc.id = 'controlCenter';
  cc.className = 'control-center hidden';
  cc.innerHTML = '<div class="cc-title">CONTROL CENTER</div>' +
    '<div class="cc-grid">' +
      '<div class="cc-tile blue" data-cc="wifi"><div class="cc-icon">W</div><div class="cc-label">Wi-Fi</div></div>' +
      '<div class="cc-tile blue" data-cc="bluetooth"><div class="cc-icon">B</div><div class="cc-label">Bluetooth</div></div>' +
      '<div class="cc-tile" data-cc="mobileData"><div class="cc-icon">M</div><div class="cc-label">Mobile Data</div></div>' +
      '<div class="cc-tile orange" data-cc="hotspot"><div class="cc-icon">H</div><div class="cc-label">Hotspot</div></div>' +
      '<div class="cc-tile orange" data-cc="airplane"><div class="cc-icon">A</div><div class="cc-label">Airplane</div></div>' +
      '<div class="cc-tile red" data-cc="screenRecord"><div class="cc-icon">R</div><div class="cc-label">Record</div></div>' +
      '<div class="cc-tile yellow" data-cc="torch"><div class="cc-icon">T</div><div class="cc-label">Torch</div></div>' +
      '<div class="cc-tile purple" data-cc="brightness"><div class="cc-icon">+</div><div class="cc-label">Bright</div></div>' +
      '<div class="cc-tile purple" data-cc="volume"><div class="cc-icon">V</div><div class="cc-label">Volume</div></div>' +
    '</div>' +
    '<div class="cc-slider-wrap"><div class="cc-slider-label">BRIGHTNESS</div><input type="range" min="0" max="100" class="cc-slider" id="ccBrightness" value="80"></div>' +
    '<div class="cc-slider-wrap"><div class="cc-slider-label">VOLUME</div><input type="range" min="0" max="100" class="cc-slider" id="ccVolume" value="70"></div>' +
    '<button class="cc-close-btn" id="ccCloseBtn">CLOSE</button>';
  const stage = document.getElementById('phoneStage');
  if (stage) stage.appendChild(cc);

  const torch = document.createElement('div');
  torch.id = 'torchOverlay';
  torch.className = 'cc-torch-overlay hidden';
  torch.innerHTML = '<div class="torch-text">TORCH ON</div>' +
    '<div class="torch-hint">Screen lights up like a torch</div>' +
    '<button class="torch-btn" id="torchOffBtn">TURN OFF</button>';
  if (stage) stage.appendChild(torch);

  cc.querySelectorAll('.cc-tile').forEach(function(t) {
    t.addEventListener('click', function() {
      const key = t.getAttribute('data-cc');
      if (key === 'torch') {
        ccState.torch = !ccState.torch;
        t.classList.toggle('on', ccState.torch);
        const overlay = document.getElementById('torchOverlay');
        if (overlay) overlay.classList.toggle('hidden', !ccState.torch);
        if (typeof soundClick === 'function') soundClick();
        return;
      }
      if (key === 'brightness' || key === 'volume') return;
      ccState[key] = !ccState[key];
      t.classList.toggle('on', ccState[key]);
      if (typeof soundClick === 'function') soundClick();
      if (key === 'airplane' && ccState.airplane) {
        ccState.mobileData = false;
        ccState.wifi = false;
        cc.querySelector('[data-cc="mobileData"]').classList.remove('on');
        cc.querySelector('[data-cc="wifi"]').classList.remove('on');
      }
    });
  });
  const b = document.getElementById('ccBrightness');
  if (b) b.addEventListener('input', function() { ccState.brightness = parseInt(b.value, 10); });
  const v = document.getElementById('ccVolume');
  if (v) v.addEventListener('input', function() { ccState.volume = parseInt(v.value, 10); });
  const c = document.getElementById('ccCloseBtn');
  if (c) c.addEventListener('click', function() { closeControlCenter(); });
  const tOff = document.getElementById('torchOffBtn');
  if (tOff) tOff.addEventListener('click', function() {
    ccState.torch = false;
    const tile = cc.querySelector('[data-cc="torch"]');
    if (tile) tile.classList.remove('on');
    const ov = document.getElementById('torchOverlay');
    if (ov) ov.classList.add('hidden');
  });

  applyControlCenterState();
}

function applyControlCenterState() {
  const cc = document.getElementById('controlCenter');
  if (!cc) return;
  cc.querySelectorAll('.cc-tile').forEach(function(t) {
    const key = t.getAttribute('data-cc');
    if (key === 'brightness' || key === 'volume') return;
    t.classList.toggle('on', !!ccState[key]);
  });
  const b = document.getElementById('ccBrightness');
  if (b) b.value = ccState.brightness;
  const v = document.getElementById('ccVolume');
  if (v) v.value = ccState.volume;
}

function openControlCenter() {
  ensureControlCenter();
  const cc = document.getElementById('controlCenter');
  if (cc) {
    cc.classList.remove('hidden');
    applyControlCenterState();
  }
}

function closeControlCenter() {
  const cc = document.getElementById('controlCenter');
  if (cc) cc.classList.add('hidden');
}

document.addEventListener('touchstart', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (!e.touches || !e.touches[0]) return;
  const stage = document.getElementById('phoneStage');
  if (!stage) return;
  const rect = stage.getBoundingClientRect();
  const touchY = e.touches[0].clientY;
  if (touchY < rect.top + rect.height * 0.12) {
    phoneViewer.dataset.ccStartY = String(touchY);
  } else {
    phoneViewer.dataset.ccStartY = '';
  }
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  const startY = phoneViewer.dataset.ccStartY;
  if (!startY) return;
  phoneViewer.dataset.ccStartY = '';
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dy = e.changedTouches[0].clientY - parseFloat(startY);
  if (dy > 50) openControlCenter();
}, { passive: true });

/* ============================================================
   TIC TAC TOE
   ============================================================ */
let tttBoard = ['','','','','','','','',''];
let tttTurn = 'X';
let tttMode = 'pvp';
let tttGameOver = false;

function renderTicTacToe() {
  let html = '<div class="ttt-header">';
  html += '<h2 class="ttt-title">TIC TAC TOE</h2>';
  html += '<button class="ttt-mode-btn" id="tttModeBtn">' + (tttMode === 'pvp' ? '2 PLAYERS' : 'VS CPU') + '</button>';
  html += '</div>';
  html += '<div class="ttt-status" id="tttStatus">' + (tttGameOver ? '' : tttTurn + "'s TURN") + '</div>';
  html += '<div class="ttt-board" id="tttBoard">';
  for (let i = 0; i < 9; i++) {
    const cls = 'ttt-cell' + (tttBoard[i] ? ' ' + tttBoard[i].toLowerCase() : '');
    html += '<div class="' + cls + '" data-ttt="' + i + '">' + tttBoard[i] + '</div>';
  }
  html += '</div>';
  html += '<button class="ttt-reset" id="tttReset">NEW GAME</button>';
  appScreenContent.innerHTML = html;

  appScreenContent.querySelectorAll('.ttt-cell').forEach(function(cell) {
    cell.addEventListener('click', function() { tttPlay(parseInt(cell.getAttribute('data-ttt'), 10)); });
  });
  const rb = document.getElementById('tttReset');
  if (rb) rb.addEventListener('click', function() {
    tttBoard = ['','','','','','','','',''];
    tttTurn = 'X';
    tttGameOver = false;
    renderTicTacToe();
  });
  const mb = document.getElementById('tttModeBtn');
  if (mb) mb.addEventListener('click', function() {
    tttMode = tttMode === 'pvp' ? 'cpu' : 'pvp';
    tttBoard = ['','','','','','','','',''];
    tttTurn = 'X';
    tttGameOver = false;
    renderTicTacToe();
  });
}

function tttCheckWin(board) {
  const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for (let i = 0; i < lines.length; i++) {
    const a = lines[i][0], b = lines[i][1], c = lines[i][2];
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return { winner: board[a], line: lines[i] };
  }
  if (board.indexOf('') === -1) return { winner: 'draw', line: [] };
  return null;
}

function tttPlay(idx) {
  if (tttGameOver) return;
  if (tttBoard[idx] !== '') return;
  if (tttMode === 'cpu' && tttTurn === 'O') return;
  tttBoard[idx] = tttTurn;
  if (typeof soundClick === 'function') soundClick();
  const result = tttCheckWin(tttBoard);
  if (result) {
    tttGameOver = true;
    renderTicTacToe();
    if (result.winner === 'draw') {
      document.getElementById('tttStatus').textContent = "IT'S A DRAW!";
    } else {
      document.getElementById('tttStatus').textContent = result.winner + ' WINS!';
      result.line.forEach(function(i) {
        const cell = document.querySelector('[data-ttt="' + i + '"]');
        if (cell) cell.classList.add('win');
      });
      if (typeof soundWin === 'function') soundWin();
    }
    return;
  }
  tttTurn = tttTurn === 'X' ? 'O' : 'X';
  renderTicTacToe();
  if (tttMode === 'cpu' && tttTurn === 'O' && !tttGameOver) {
    setTimeout(tttCpuMove, 500);
  }
}

function tttCpuMove() {
  if (tttGameOver) return;
  const empty = [];
  for (let i = 0; i < 9; i++) if (tttBoard[i] === '') empty.push(i);
  if (empty.length === 0) return;
  for (let i = 0; i < empty.length; i++) {
    const t = tttBoard.slice();
    t[empty[i]] = 'O';
    const r = tttCheckWin(t);
    if (r && r.winner === 'O') { tttPlay(empty[i]); return; }
  }
  for (let i = 0; i < empty.length; i++) {
    const t = tttBoard.slice();
    t[empty[i]] = 'X';
    const r = tttCheckWin(t);
    if (r && r.winner === 'X') { tttPlay(empty[i]); return; }
  }
  if (tttBoard[4] === '') { tttPlay(4); return; }
  const corners = [0,2,6,8].filter(function(i) { return tttBoard[i] === ''; });
  if (corners.length) { tttPlay(corners[Math.floor(Math.random() * corners.length)]); return; }
  tttPlay(empty[Math.floor(Math.random() * empty.length)]);
}

/* Add Tic Tac Toe icon to both home screens */
(function addTicTacToeIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'X';
    el.setAttribute('data-label', 'Tic Tac Toe');
    el.style.background = 'linear-gradient(135deg,#00e5ff,#a855f7)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      tttBoard = ['','','','','','','','',''];
      tttTurn = 'X';
      tttGameOver = false;
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderTicTacToe();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();

/* Browser requires Mobile Data */
(function patchBrowser() {
  const origOpenApp = window.openApp;
  if (typeof origOpenApp !== 'function') return;
  window.openApp = function(name) {
    if (name === 'Safari' || name === 'Chrome') {
      if (!ccState.mobileData) {
        appScreenContent.innerHTML = '<div class="no-internet">' +
          '<div class="no-internet-icon">!</div>' +
          '<h2 class="no-internet-title">No Internet Connection</h2>' +
          '<p class="no-internet-msg">Turn on Mobile Data in Control Center.<br>Swipe down from the top of the screen.</p>' +
          '</div>';
        appScreen.classList.remove('hidden');
        flipCard.classList.remove('flipped');
        return;
      }
    }
    return origOpenApp.apply(this, arguments);
  };
})();
/* ============================================================
   STORE REQUIRES MOBILE DATA
   ============================================================ */
(function patchStoreInternet() {
  const originalRenderStore = window.renderStore;
  if (typeof originalRenderStore !== 'function') return;
  window.renderStore = function(name) {
    if (!ccState.mobileData) {
      let html = '<div class="no-internet">';
      html += '<div class="no-internet-icon">!</div>';
      html += '<h2 class="no-internet-title">No Internet Connection</h2>';
      html += '<p class="no-internet-msg">Turn on Mobile Data in Control Center.<br>Swipe down from the top of the screen.</p>';
      html += '</div>';
      appScreenContent.innerHTML = html;
      return;
    }
    return originalRenderStore.apply(this, arguments);
  };
})();

/* ============================================================
   SNAKE GAME
   ============================================================ */
let snakeState = {
  grid: 15,
  snake: [{ x: 7, y: 7 }],
  dir: { x: 1, y: 0 },
  nextDir: { x: 1, y: 0 },
  food: { x: 10, y: 7 },
  score: 0,
  best: parseInt(localStorage.getItem('snakeBest') || '0', 10),
  running: false,
  dead: false,
  timer: null,
  speed: 180
};

function snakeReset() {
  snakeState.snake = [{ x: 7, y: 7 }];
  snakeState.dir = { x: 1, y: 0 };
  snakeState.nextDir = { x: 1, y: 0 };
  snakeState.score = 0;
  snakeState.dead = false;
  snakeState.running = false;
  snakeState.speed = 180;
  snakePlaceFood();
  if (snakeState.timer) { clearInterval(snakeState.timer); snakeState.timer = null; }
}

function snakePlaceFood() {
  let attempts = 0;
  while (attempts < 200) {
    const fx = Math.floor(Math.random() * snakeState.grid);
    const fy = Math.floor(Math.random() * snakeState.grid);
    let onSnake = false;
    for (let i = 0; i < snakeState.snake.length; i++) {
      if (snakeState.snake[i].x === fx && snakeState.snake[i].y === fy) { onSnake = true; break; }
    }
    if (!onSnake) {
      snakeState.food = { x: fx, y: fy };
      return;
    }
    attempts++;
  }
  snakeState.food = { x: 0, y: 0 };
}

function snakeTick() {
  if (!snakeState.running) return;
  snakeState.dir = snakeState.nextDir;
  const head = snakeState.snake[0];
  const newHead = { x: head.x + snakeState.dir.x, y: head.y + snakeState.dir.y };
  if (newHead.x < 0 || newHead.x >= snakeState.grid || newHead.y < 0 || newHead.y >= snakeState.grid) {
    snakeGameOver();
    return;
  }
  for (let i = 0; i < snakeState.snake.length; i++) {
    if (snakeState.snake[i].x === newHead.x && snakeState.snake[i].y === newHead.y) {
      snakeGameOver();
      return;
    }
  }
  snakeState.snake.unshift(newHead);
  if (newHead.x === snakeState.food.x && newHead.y === snakeState.food.y) {
    snakeState.score += 10;
    if (typeof soundTap === 'function') soundTap();
    if (snakeState.snake.length > 0) {
      if (snakeState.speed > 80) snakeState.speed -= 3;
    }
    snakePlaceFood();
    snakeRestartTimer();
  } else {
    snakeState.snake.pop();
  }
  snakeRenderBoard();
}

function snakeRestartTimer() {
  if (snakeState.timer) clearInterval(snakeState.timer);
  snakeState.timer = setInterval(snakeTick, snakeState.speed);
}

function snakeGameOver() {
  snakeState.running = false;
  snakeState.dead = true;
  if (snakeState.timer) { clearInterval(snakeState.timer); snakeState.timer = null; }
  if (snakeState.score > snakeState.best) {
    snakeState.best = snakeState.score;
    localStorage.setItem('snakeBest', String(snakeState.best));
  }
  if (typeof soundWrong === 'function') soundWrong();
  snakeRenderBoard();
}

function snakeRenderBoard() {
  const board = document.getElementById('snakeBoard');
  if (!board) return;
  let html = '';
  for (let y = 0; y < snakeState.grid; y++) {
    for (let x = 0; x < snakeState.grid; x++) {
      let cls = 'snake-cell';
      for (let i = 0; i < snakeState.snake.length; i++) {
        if (snakeState.snake[i].x === x && snakeState.snake[i].y === y) {
          cls += i === 0 ? ' snake-head' : ' snake-body';
          break;
        }
      }
      if (snakeState.food.x === x && snakeState.food.y === y) cls += ' snake-food';
      html += '<div class="' + cls + '"></div>';
    }
  }
  board.innerHTML = html;
  const scoreEl = document.getElementById('snakeScore');
  if (scoreEl) scoreEl.textContent = 'SCORE: ' + snakeState.score;
  const bestEl = document.getElementById('snakeBest');
  if (bestEl) bestEl.textContent = 'BEST: ' + snakeState.best;
  const statusEl = document.getElementById('snakeStatus');
  if (statusEl) {
    if (snakeState.dead) statusEl.textContent = 'GAME OVER - Tap Start';
    else if (!snakeState.running) statusEl.textContent = 'Tap Start to play';
    else statusEl.textContent = 'Playing...';
  }
}

function renderSnake() {
  let html = '<div class="snake-header">';
  html += '<div class="snake-score" id="snakeScore">SCORE: 0</div>';
  html += '<div class="snake-best" id="snakeBest">BEST: ' + snakeState.best + '</div>';
  html += '</div>';
  html += '<div class="snake-status" id="snakeStatus">Tap Start to play</div>';
  html += '<div class="snake-board-wrap"><div class="snake-board" id="snakeBoard" style="grid-template-columns:repeat(' + snakeState.grid + ',1fr);"></div></div>';
  html += '<div class="snake-controls">';
  html += '<button class="snake-btn" id="snakeStart">START</button>';
  html += '<button class="snake-btn" id="snakeReset">RESET</button>';
  html += '</div>';
  html += '<div class="snake-dpad">';
  html += '<div></div><button class="dpad-btn" data-snake-dir="up">UP</button><div></div>';
  html += '<button class="dpad-btn" data-snake-dir="left">LEFT</button>';
  html += '<div></div>';
  html += '<button class="dpad-btn" data-snake-dir="right">RIGHT</button>';
  html += '<div></div><button class="dpad-btn" data-snake-dir="down">DOWN</button><div></div>';
  html += '</div>';

  appScreenContent.innerHTML = html;

  snakeRenderBoard();

  const startBtn = document.getElementById('snakeStart');
  if (startBtn) {
    startBtn.addEventListener('click', function() {
      if (snakeState.dead) { snakeReset(); snakeRenderBoard(); }
      snakeState.running = true;
      snakeRestartTimer();
      snakeRenderBoard();
    });
  }
  const resetBtn = document.getElementById('snakeReset');
  if (resetBtn) {
    resetBtn.addEventListener('click', function() {
      snakeReset();
      snakeRenderBoard();
    });
  }
  appScreenContent.querySelectorAll('.dpad-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const d = btn.getAttribute('data-snake-dir');
      snakeSetDir(d);
    });
  });
}

function snakeSetDir(d) {
  const cur = snakeState.dir;
  let nx = cur.x, ny = cur.y;
  if (d === 'up') { nx = 0; ny = -1; }
  else if (d === 'down') { nx = 0; ny = 1; }
  else if (d === 'left') { nx = -1; ny = 0; }
  else if (d === 'right') { nx = 1; ny = 0; }
  if (nx === -cur.x && ny === -cur.y) return;
  snakeState.nextDir = { x: nx, y: ny };
}

function snakeSwipe(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('snakeBoard')) return;
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dx = e.changedTouches[0].clientX - parseFloat(appScreen.dataset.swipeX || '0');
  const dy = e.changedTouches[0].clientY - parseFloat(appScreen.dataset.swipeY || '0');
  if (Math.abs(dx) < 20 && Math.abs(dy) < 20) return;
  if (Math.abs(dx) > Math.abs(dy)) snakeSetDir(dx > 0 ? 'right' : 'left');
  else snakeSetDir(dy > 0 ? 'down' : 'up');
}

document.addEventListener('touchstart', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('snakeBoard')) return;
  if (!e.touches || !e.touches[0]) return;
  appScreen.dataset.swipeX = String(e.touches[0].clientX);
  appScreen.dataset.swipeY = String(e.touches[0].clientY);
}, { passive: true });
document.addEventListener('touchend', snakeSwipe, { passive: true });

document.addEventListener('keydown', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('snakeBoard')) return;
  if (e.key === 'ArrowUp') { snakeSetDir('up'); e.preventDefault(); }
  if (e.key === 'ArrowDown') { snakeSetDir('down'); e.preventDefault(); }
  if (e.key === 'ArrowLeft') { snakeSetDir('left'); e.preventDefault(); }
  if (e.key === 'ArrowRight') { snakeSetDir('right'); e.preventDefault(); }
});

/* Add Snake icon to both home screens */
(function addSnakeIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'S';
    el.setAttribute('data-label', 'Snake');
    el.style.background = 'linear-gradient(135deg,#3ddc84,#00aa66)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      snakeReset();
      renderSnake();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();
/* ============================================================
   2048 GAME
   ============================================================ */
let g2048State = {
  board: [],
  score: 0,
  best: parseInt(localStorage.getItem('g2048Best') || '0', 10),
  gameOver: false,
  won: false
};

function g2048Reset() {
  g2048State.board = [];
  for (let i = 0; i < 16; i++) g2048State.board.push(0);
  g2048State.score = 0;
  g2048State.gameOver = false;
  g2048State.won = false;
  g2048AddTile();
  g2048AddTile();
}

function g2048AddTile() {
  const empty = [];
  for (let i = 0; i < 16; i++) if (g2048State.board[i] === 0) empty.push(i);
  if (empty.length === 0) return;
  const idx = empty[Math.floor(Math.random() * empty.length)];
  g2048State.board[idx] = Math.random() < 0.9 ? 2 : 4;
}

function g2048Slide(row) {
  let arr = row.filter(function(v) { return v !== 0; });
  const result = [];
  let i = 0;
  while (i < arr.length) {
    if (i + 1 < arr.length && arr[i] === arr[i+1]) {
      result.push(arr[i] * 2);
      g2048State.score += arr[i] * 2;
      if (arr[i] * 2 === 2048) g2048State.won = true;
      i += 2;
    } else {
      result.push(arr[i]);
      i++;
    }
  }
  while (result.length < 4) result.push(0);
  return result;
}

function g2048Move(dir) {
  if (g2048State.gameOver) return;
  const b = g2048State.board;
  let moved = false;
  const before = b.slice();

  if (dir === 'left' || dir === 'right') {
    for (let r = 0; r < 4; r++) {
      let row = [b[r*4], b[r*4+1], b[r*4+2], b[r*4+3]];
      if (dir === 'right') row.reverse();
      row = g2048Slide(row);
      if (dir === 'right') row.reverse();
      for (let c = 0; c < 4; c++) b[r*4+c] = row[c];
    }
  } else {
    for (let c = 0; c < 4; c++) {
      let col = [b[c], b[c+4], b[c+8], b[c+12]];
      if (dir === 'down') col.reverse();
      col = g2048Slide(col);
      if (dir === 'down') col.reverse();
      for (let r = 0; r < 4; r++) b[c+r*4] = col[r];
    }
  }

  for (let i = 0; i < 16; i++) if (before[i] !== b[i]) { moved = true; break; }
  if (moved) {
    g2048AddTile();
    if (g2048State.score > g2048State.best) {
      g2048State.best = g2048State.score;
      localStorage.setItem('g2048Best', String(g2048State.best));
    }
    if (!g2048CanMove()) g2048State.gameOver = true;
    if (typeof soundTap === 'function') soundTap();
    g2048Render();
  }
}

function g2048CanMove() {
  const b = g2048State.board;
  for (let i = 0; i < 16; i++) if (b[i] === 0) return true;
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      const v = b[r*4+c];
      if (c < 3 && b[r*4+c+1] === v) return true;
      if (r < 3 && b[(r+1)*4+c] === v) return true;
    }
  }
  return false;
}

function g2048TileClass(v) {
  if (v === 0) return 'g2048-cell empty';
  if (v <= 4) return 'g2048-cell t2';
  if (v <= 8) return 'g2048-cell t4';
  if (v <= 16) return 'g2048-cell t8';
  if (v <= 32) return 'g2048-cell t16';
  if (v <= 64) return 'g2048-cell t32';
  if (v <= 128) return 'g2048-cell t64';
  if (v <= 256) return 'g2048-cell t128';
  if (v <= 512) return 'g2048-cell t256';
  if (v <= 1024) return 'g2048-cell t512';
  return 'g2048-cell t1024';
}

function g2048Render() {
  const board = document.getElementById('g2048Board');
  if (!board) return;
  let html = '';
  for (let i = 0; i < 16; i++) {
    const v = g2048State.board[i];
    html += '<div class="' + g2048TileClass(v) + '">' + (v === 0 ? '' : v) + '</div>';
  }
  board.innerHTML = html;

  const scoreEl = document.getElementById('g2048Score');
  if (scoreEl) scoreEl.textContent = 'SCORE: ' + g2048State.score;
  const bestEl = document.getElementById('g2048Best');
  if (bestEl) bestEl.textContent = 'BEST: ' + g2048State.best;
  const statusEl = document.getElementById('g2048Status');
  if (statusEl) {
    if (g2048State.gameOver) statusEl.textContent = 'GAME OVER - Tap New Game';
    else if (g2048State.won) statusEl.textContent = 'YOU REACHED 2048! Keep going';
    else statusEl.textContent = 'Swipe to move tiles';
  }
}

function render2048() {
  let html = '<div class="g2048-header">';
  html += '<div class="g2048-score" id="g2048Score">SCORE: 0</div>';
  html += '<div class="g2048-best" id="g2048Best">BEST: ' + g2048State.best + '</div>';
  html += '</div>';
  html += '<div class="g2048-status" id="g2048Status">Swipe to move tiles</div>';
  html += '<div class="g2048-board" id="g2048Board"></div>';
  html += '<div class="g2048-controls">';
  html += '<button class="g2048-btn" id="g2048New">NEW GAME</button>';
  html += '</div>';
  html += '<div class="g2048-dpad">';
  html += '<div></div><button class="dpad-btn" data-g2048-dir="up">UP</button><div></div>';
  html += '<button class="dpad-btn" data-g2048-dir="left">LEFT</button>';
  html += '<div></div>';
  html += '<button class="dpad-btn" data-g2048-dir="right">RIGHT</button>';
  html += '<div></div><button class="dpad-btn" data-g2048-dir="down">DOWN</button><div></div>';
  html += '</div>';

  appScreenContent.innerHTML = html;

  if (g2048State.board.length === 0) g2048Reset();
  g2048Render();

  const nb = document.getElementById('g2048New');
  if (nb) nb.addEventListener('click', function() {
    g2048Reset();
    g2048Render();
  });
  appScreenContent.querySelectorAll('[data-g2048-dir]').forEach(function(b) {
    b.addEventListener('click', function() {
      g2048Move(b.getAttribute('data-g2048-dir'));
    });
  });
}

document.addEventListener('touchstart', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('g2048Board')) return;
  if (!e.touches || !e.touches[0]) return;
  appScreen.dataset.g2048X = String(e.touches[0].clientX);
  appScreen.dataset.g2048Y = String(e.touches[0].clientY);
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('g2048Board')) return;
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dx = e.changedTouches[0].clientX - parseFloat(appScreen.dataset.g2048X || '0');
  const dy = e.changedTouches[0].clientY - parseFloat(appScreen.dataset.g2048Y || '0');
  if (Math.abs(dx) < 25 && Math.abs(dy) < 25) return;
  if (Math.abs(dx) > Math.abs(dy)) g2048Move(dx > 0 ? 'right' : 'left');
  else g2048Move(dy > 0 ? 'down' : 'up');
}, { passive: true });

document.addEventListener('keydown', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('g2048Board')) return;
  if (e.key === 'ArrowUp') { g2048Move('up'); e.preventDefault(); }
  if (e.key === 'ArrowDown') { g2048Move('down'); e.preventDefault(); }
  if (e.key === 'ArrowLeft') { g2048Move('left'); e.preventDefault(); }
  if (e.key === 'ArrowRight') { g2048Move('right'); e.preventDefault(); }
});

(function add2048Icon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = '2';
    el.setAttribute('data-label', '2048');
    el.style.background = 'linear-gradient(135deg,#ffcc00,#ff8800)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      g2048Reset();
      render2048();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();
/* ============================================================
   WHACK-A-MOLE
   ============================================================ */
let wamState = {
  activeMole: -1,
  score: 0,
  timeLeft: 30,
  running: false,
  best: parseInt(localStorage.getItem('wamBest') || '0', 10),
  moleTimer: null,
  countdownTimer: null,
  holeCount: 9
};

function wamReset() {
  if (wamState.moleTimer) clearInterval(wamState.moleTimer);
  if (wamState.countdownTimer) clearInterval(wamState.countdownTimer);
  wamState.moleTimer = null;
  wamState.countdownTimer = null;
  wamState.activeMole = -1;
  wamState.score = 0;
  wamState.timeLeft = 30;
  wamState.running = false;
}

function wamStart() {
  wamReset();
  wamState.running = true;
  wamRenderBoard();
  wamShowMole();
  wamState.moleTimer = setInterval(wamShowMole, 800);
  wamState.countdownTimer = setInterval(function() {
    wamState.timeLeft -= 1;
    const t = document.getElementById('wamTime');
    if (t) t.textContent = 'TIME: ' + wamState.timeLeft;
    if (wamState.timeLeft <= 0) wamEnd();
  }, 1000);
}

function wamShowMole() {
  if (!wamState.running) return;
  wamState.activeMole = Math.floor(Math.random() * wamState.holeCount);
  wamRenderBoard();
}

function wamWhack(idx) {
  if (!wamState.running) return;
  if (idx !== wamState.activeMole) return;
  wamState.score += 1;
  if (typeof soundTap === 'function') soundTap();
  wamState.activeMole = -1;
  wamRenderBoard();
  const s = document.getElementById('wamScore');
  if (s) s.textContent = 'SCORE: ' + wamState.score;
}

function wamEnd() {
  wamState.running = false;
  if (wamState.moleTimer) clearInterval(wamState.moleTimer);
  if (wamState.countdownTimer) clearInterval(wamState.countdownTimer);
  wamState.moleTimer = null;
  wamState.countdownTimer = null;
  if (wamState.score > wamState.best) {
    wamState.best = wamState.score;
    localStorage.setItem('wamBest', String(wamState.best));
  }
  if (typeof soundWin === 'function') soundWin();
  wamRenderBoard();
  const s = document.getElementById('wamStatus');
  if (s) s.textContent = 'GAME OVER - Final: ' + wamState.score;
  const b = document.getElementById('wamBest');
  if (b) b.textContent = 'BEST: ' + wamState.best;
}

function wamRenderBoard() {
  const board = document.getElementById('wamBoard');
  if (!board) return;
  let html = '';
  for (let i = 0; i < wamState.holeCount; i++) {
    const isActive = i === wamState.activeMole;
    html += '<div class="wam-hole' + (isActive ? ' wam-active' : '') + '" data-wam="' + i + '">';
    html += isActive ? 'M' : '';
    html += '</div>';
  }
  board.innerHTML = html;
  board.querySelectorAll('.wam-hole').forEach(function(el) {
    el.addEventListener('click', function() {
      wamWhack(parseInt(el.getAttribute('data-wam'), 10));
    });
  });
  const s = document.getElementById('wamScore');
  if (s) s.textContent = 'SCORE: ' + wamState.score;
  const t = document.getElementById('wamTime');
  if (t) t.textContent = 'TIME: ' + wamState.timeLeft;
  const b = document.getElementById('wamBest');
  if (b) b.textContent = 'BEST: ' + wamState.best;
}

function renderWhackAMole() {
  let html = '<div class="wam-header">';
  html += '<div class="wam-score" id="wamScore">SCORE: 0</div>';
  html += '<div class="wam-best" id="wamBest">BEST: ' + wamState.best + '</div>';
  html += '</div>';
  html += '<div class="wam-status" id="wamStatus">Tap Start to play</div>';
  html += '<div class="wam-time" id="wamTime">TIME: 30</div>';
  html += '<div class="wam-board" id="wamBoard"></div>';
  html += '<div class="wam-controls">';
  html += '<button class="wam-btn" id="wamStart">START</button>';
  html += '<button class="wam-btn" id="wamReset">RESET</button>';
  html += '</div>';
  appScreenContent.innerHTML = html;

  wamRenderBoard();

  const sb = document.getElementById('wamStart');
  if (sb) sb.addEventListener('click', function() { wamStart(); });
  const rb = document.getElementById('wamReset');
  if (rb) rb.addEventListener('click', function() {
    wamReset();
    wamRenderBoard();
    const s = document.getElementById('wamStatus');
    if (s) s.textContent = 'Tap Start to play';
    const t = document.getElementById('wamTime');
    if (t) t.textContent = 'TIME: 30';
  });
}

(function addWamIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'W';
    el.setAttribute('data-label', 'Whack');
    el.style.background = 'linear-gradient(135deg,#ff006e,#a855f7)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      wamReset();
      renderWhackAMole();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();
/* ============================================================
   GAMES FOLDER + MEMORY MATCH + ROCK PAPER SCISSORS
   ============================================================ */

/* Remove the individual game icons from home screens */
(function removeGameIcons() {
  const removeByLabel = function(containerId, labels) {
    const c = document.getElementById(containerId);
    if (!c) return;
    const icons = c.querySelectorAll('.app');
    icons.forEach(function(el) {
      const lbl = el.getAttribute('data-label');
      if (lbl && labels.indexOf(lbl) !== -1) el.remove();
    });
  };
  const toRemove = ['Tic Tac Toe', 'Snake', '2048', 'Whack'];
  removeByLabel('iphoneIcons', toRemove);
  removeByLabel('androidIcons', toRemove);
})();

/* Memory Match state */
let memState = {
  cards: [],
  flipped: [],
  matched: 0,
  moves: 0,
  lock: false,
  totalPairs: 8
};

function memReset() {
  const symbols = ['A','B','C','D','E','F','G','H'];
  const deck = symbols.concat(symbols);
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = deck[i]; deck[i] = deck[j]; deck[j] = t;
  }
  memState.cards = deck;
  memState.flipped = [];
  memState.matched = 0;
  memState.moves = 0;
  memState.lock = false;
}

function memRender() {
  const board = document.getElementById('memBoard');
  if (!board) return;
  let html = '';
  for (let i = 0; i < memState.cards.length; i++) {
    const isFlipped = memState.flipped.indexOf(i) !== -1;
    const isMatched = memState.matchedCards && memState.matchedCards.indexOf(i) !== -1;
    let cls = 'mem-card';
    if (isFlipped || isMatched) cls += ' mem-open';
    html += '<div class="' + cls + '" data-mem="' + i + '">';
    html += (isFlipped || isMatched) ? memState.cards[i] : '?';
    html += '</div>';
  }
  board.innerHTML = html;
  const movesEl = document.getElementById('memMoves');
  if (movesEl) movesEl.textContent = 'MOVES: ' + memState.moves;
  const pairsEl = document.getElementById('memPairs');
  if (pairsEl) pairsEl.textContent = 'PAIRS: ' + memState.matched + '/' + memState.totalPairs;
  board.querySelectorAll('.mem-card').forEach(function(el) {
    el.addEventListener('click', function() {
      memFlip(parseInt(el.getAttribute('data-mem'), 10));
    });
  });
}

function memFlip(idx) {
  if (memState.lock) return;
  if (memState.flipped.indexOf(idx) !== -1) return;
  if (!memState.matchedCards) memState.matchedCards = [];
  if (memState.matchedCards.indexOf(idx) !== -1) return;
  memState.flipped.push(idx);
  if (typeof soundTap === 'function') soundTap();
  memRender();
  if (memState.flipped.length === 2) {
    memState.moves += 1;
    memState.lock = true;
    const a = memState.flipped[0];
    const b = memState.flipped[1];
    if (memState.cards[a] === memState.cards[b]) {
      memState.matchedCards.push(a, b);
      memState.matched += 1;
      memState.flipped = [];
      memState.lock = false;
      memRender();
      if (memState.matched === memState.totalPairs) {
        if (typeof soundWin === 'function') soundWin();
        const s = document.getElementById('memStatus');
        if (s) s.textContent = 'YOU WON in ' + memState.moves + ' moves!';
      }
    } else {
      setTimeout(function() {
        memState.flipped = [];
        memState.lock = false;
        memRender();
      }, 800);
    }
  }
}

function renderMemory() {
  if (!memState.cards.length || memState.matched === memState.totalPairs) {
    memReset();
    memState.matchedCards = [];
  }
  let html = '<div class="mem-header">';
  html += '<div class="mem-moves" id="memMoves">MOVES: 0</div>';
  html += '<div class="mem-pairs" id="memPairs">PAIRS: 0/8</div>';
  html += '</div>';
  html += '<div class="mem-status" id="memStatus">Match all pairs</div>';
  html += '<div class="mem-board" id="memBoard"></div>';
  html += '<button class="mem-btn" id="memNew">NEW GAME</button>';
  appScreenContent.innerHTML = html;
  memRender();
  const nb = document.getElementById('memNew');
  if (nb) nb.addEventListener('click', function() {
    memReset();
    memState.matchedCards = [];
    renderMemory();
  });
}

/* Rock Paper Scissors state */
let rpsState = {
  playerScore: 0,
  cpuScore: 0,
  round: 1,
  maxRounds: 3,
  finished: false
};

function rpsReset() {
  rpsState.playerScore = 0;
  rpsState.cpuScore = 0;
  rpsState.round = 1;
  rpsState.finished = false;
}

function rpsPlay(player) {
  if (rpsState.finished) return;
  const opts = ['Rock', 'Paper', 'Scissors'];
  const cpu = opts[Math.floor(Math.random() * 3)];
  let result = '';
  if (player === cpu) result = 'DRAW';
  else if ((player === 'Rock' && cpu === 'Scissors') ||
           (player === 'Paper' && cpu === 'Rock') ||
           (player === 'Scissors' && cpu === 'Paper')) {
    result = 'YOU WIN';
    rpsState.playerScore += 1;
  } else {
    result = 'CPU WINS';
    rpsState.cpuScore += 1;
  }
  if (typeof soundTap === 'function') soundTap();
  const resultEl = document.getElementById('rpsResult');
  if (resultEl) {
    resultEl.innerHTML = 'You: <b>' + player + '</b> - CPU: <b>' + cpu + '</b><br>' + result;
  }
  const ps = document.getElementById('rpsPlayer');
  if (ps) ps.textContent = 'YOU: ' + rpsState.playerScore;
  const cs = document.getElementById('rpsCpu');
  if (cs) cs.textContent = 'CPU: ' + rpsState.cpuScore;
  if (rpsState.round >= rpsState.maxRounds || rpsState.playerScore >= 2 || rpsState.cpuScore >= 2) {
    rpsState.finished = true;
    let msg = '';
    if (rpsState.playerScore > rpsState.cpuScore) msg = 'YOU WIN THE MATCH!';
    else if (rpsState.cpuScore > rpsState.playerScore) msg = 'CPU WINS THE MATCH';
    else msg = 'MATCH DRAW';
    if (typeof soundWin === 'function') soundWin();
    const res = document.getElementById('rpsResult');
    if (res) res.innerHTML = msg;
  } else {
    rpsState.round += 1;
    const rd = document.getElementById('rpsRound');
    if (rd) rd.textContent = 'ROUND ' + rpsState.round + ' of ' + rpsState.maxRounds;
  }
}

function renderRPS() {
  rpsReset();
  let html = '<div class="rps-header">';
  html += '<div class="rps-score" id="rpsPlayer">YOU: 0</div>';
  html += '<div class="rps-round" id="rpsRound">ROUND 1 of 3</div>';
  html += '<div class="rps-score-cpu" id="rpsCpu">CPU: 0</div>';
  html += '</div>';
  html += '<div class="rps-result" id="rpsResult">Pick your move</div>';
  html += '<div class="rps-buttons">';
  html += '<button class="rps-btn" data-rps="Rock">ROCK</button>';
  html += '<button class="rps-btn" data-rps="Paper">PAPER</button>';
  html += '<button class="rps-btn" data-rps="Scissors">SCISSORS</button>';
  html += '</div>';
  html += '<button class="rps-new" id="rpsNew">NEW MATCH</button>';
  appScreenContent.innerHTML = html;
  appScreenContent.querySelectorAll('[data-rps]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      rpsPlay(btn.getAttribute('data-rps'));
    });
  });
  const nb = document.getElementById('rpsNew');
  if (nb) nb.addEventListener('click', function() { renderRPS(); });
}

/* Games folder */
const GAMES_LIST = [
  { name: 'Tic Tac Toe', emoji: 'X', color: 'linear-gradient(135deg,#00e5ff,#a855f7)' },
  { name: 'Snake', emoji: 'S', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { name: '2048', emoji: '2', color: 'linear-gradient(135deg,#ffcc00,#ff8800)' },
  { name: 'Whack', emoji: 'W', color: 'linear-gradient(135deg,#ff006e,#a855f7)' },
  { name: 'Memory', emoji: 'M', color: 'linear-gradient(135deg,#1a88ff,#0066ff)' },
  { name: 'RPS', emoji: 'R', color: 'linear-gradient(135deg,#ffcc00,#ff6600)' }
];

function openGame(name) {
  if (typeof soundTap === 'function') soundTap();
  appScreen.classList.remove('hidden');
  flipCard.classList.remove('flipped');
  if (name === 'Tic Tac Toe') {
    tttBoard = ['','','','','','','','',''];
    tttTurn = 'X';
    tttGameOver = false;
    renderTicTacToe();
  } else if (name === 'Snake') {
    snakeReset();
    renderSnake();
  } else if (name === '2048') {
    g2048Reset();
    render2048();
  } else if (name === 'Whack') {
    wamReset();
    renderWhackAMole();
  } else if (name === 'Memory') {
    memReset();
    memState.matchedCards = [];
    renderMemory();
  } else if (name === 'RPS') {
    renderRPS();
  }
}

function renderGamesFolder() {
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">GAMES</h2>';
  html += '<div class="games-grid">';
  GAMES_LIST.forEach(function(g) {
    html += '<div class="games-tile" data-game="' + g.name + '">';
    html += '<div class="games-icon" style="background:' + g.color + ';">' + g.emoji + '</div>';
    html += '<div class="games-label">' + g.name + '</div>';
    html += '</div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
  appScreenContent.querySelectorAll('.games-tile').forEach(function(t) {
    t.addEventListener('click', function() {
      openGame(t.getAttribute('data-game'));
    });
  });
}

/* Add Games folder icon to both home screens */
(function addGamesFolderIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'G';
    el.setAttribute('data-label', 'Games');
    el.style.background = 'linear-gradient(135deg,#1a88ff,#a855f7)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderGamesFolder();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();

/* Route folder games from openApp */
(function patchOpenAppForGames() {
  const orig = window.openApp;
  if (typeof orig !== 'function') return;
  window.openApp = function(name) {
    if (name === 'Games') { renderGamesFolder(); return; }
    if (name === 'Memory') { memReset(); memState.matchedCards = []; renderMemory(); return; }
    if (name === 'RPS') { renderRPS(); return; }
    return orig.apply(this, arguments);
  };
})();
/* ============================================================
   NOTES APP
   ============================================================ */
var notesEditingId = null;

function notesGetAll(){
  try { return JSON.parse(localStorage.getItem('notes') || '[]'); }
  catch(e) { return []; }
}
function notesSaveAll(arr){
  localStorage.setItem('notes', JSON.stringify(arr));
}
function notesEscape(s){
  if (s === undefined || s === null) return '';
  return String(s).replace(/[&<>"']/g, function(c){
    if (c === '&') return '&amp;';
    if (c === '<') return '&lt;';
    if (c === '>') return '&gt;';
    if (c === '"') return '&quot;';
    if (c === "'") return '&#39;';
    return c;
  });
}
function notesFormatDate(ts){
  if (!ts) return '';
  var d = new Date(ts);
  var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  var h = d.getHours();
  var m = d.getMinutes();
  if (m < 10) m = '0' + m;
  var ampm = h < 12 ? 'AM' : 'PM';
  var h12 = h % 12 || 12;
  return months[d.getMonth()] + ' ' + d.getDate() + ', ' + h12 + ':' + m + ' ' + ampm;
}

function renderNotes(){
  var notes = notesGetAll();
  notes.sort(function(a, b){ return b.updated - a.updated; });
  var h = '<div class="notes-header">';
  h += '<h2 class="notes-title">Notes</h2>';
  h += '<button class="notes-new-btn" id="notesNewBtn">+</button>';
  h += '</div>';
  if (notes.length === 0) {
    h += '<div class="notes-empty">No notes yet.<br>Tap + to create one.</div>';
  } else {
    h += '<div class="notes-list">';
    for (var i = 0; i < notes.length; i++) {
      var n = notes[i];
      var t = n.title || 'Untitled';
      var p = n.body ? n.body.slice(0, 60) : 'No content';
      h += '<div class="note-card" data-note-id="' + n.id + '">';
      h += '<div class="note-card-title">' + notesEscape(t) + '</div>';
      h += '<div class="note-card-preview">' + notesEscape(p) + '</div>';
      h += '<div class="note-card-date">' + notesFormatDate(n.updated) + '</div>';
      h += '</div>';
    }
    h += '</div>';
  }
  appScreenContent.innerHTML = h;
  var nb = document.getElementById('notesNewBtn');
  if (nb) nb.onclick = function(){ openNoteEditor(null); };
  var cards = appScreenContent.querySelectorAll('.note-card');
  for (var j = 0; j < cards.length; j++) {
    cards[j].onclick = (function(el){
      return function(){
        var id = parseInt(el.getAttribute('data-note-id'), 10);
        openNoteEditor(id);
      };
    })(cards[j]);
  }
}

function openNoteEditor(id){
  notesEditingId = id;
  var note = { id: null, title: '', body: '' };
  if (id !== null) {
    var notes = notesGetAll();
    for (var i = 0; i < notes.length; i++) {
      if (notes[i].id === id) { note = notes[i]; break; }
    }
  }
  var h = '<div class="note-editor">';
  h += '<input type="text" class="note-editor-title" id="noteTitleInput" placeholder="Title" value="' + notesEscape(note.title) + '">';
  h += '<textarea class="note-editor-body" id="noteBodyInput" placeholder="Start writing...">' + notesEscape(note.body) + '</textarea>';
  h += '<div class="note-actions">';
  h += '<button class="note-save-btn" id="noteSaveBtn">SAVE</button>';
  if (id !== null) {
    h += '<button class="note-delete-btn" id="noteDeleteBtn">DELETE</button>';
  }
  h += '</div></div>';
  appScreenContent.innerHTML = h;
  document.getElementById('noteSaveBtn').onclick = notesSaveCurrent;
  var del = document.getElementById('noteDeleteBtn');
  if (del) del.onclick = notesDeleteCurrent;
}

function notesSaveCurrent(){
  var t = document.getElementById('noteTitleInput').value.trim();
  var b = document.getElementById('noteBodyInput').value;
  if (t === '' && b.trim() === '') { renderNotes(); return; }
  var notes = notesGetAll();
  if (notesEditingId === null) {
    notes.push({ id: Date.now(), title: t, body: b, updated: Date.now() });
  } else {
    for (var i = 0; i < notes.length; i++) {
      if (notes[i].id === notesEditingId) {
        notes[i].title = t;
        notes[i].body = b;
        notes[i].updated = Date.now();
        break;
      }
    }
  }
  notesSaveAll(notes);
  notesEditingId = null;
  renderNotes();
}

function notesDeleteCurrent(){
  if (notesEditingId === null) return;
  if (!confirm('Delete this note?')) return;
  var notes = notesGetAll().filter(function(n){ return n.id !== notesEditingId; });
  notesSaveAll(notes);
  notesEditingId = null;
  renderNotes();
}

/* Hook Notes into openApp */
(function patchOpenAppForNotes(){
  var orig = window.openApp;
  if (typeof orig !== 'function') return;
  window.openApp = function(name){
    if (name === 'Notes') { renderNotes(); return; }
    return orig.apply(this, arguments);
  };
})();
/* ============================================================
   CLOCK APP (live time + stopwatch)
   ============================================================ */
let clockState = {
  swRunning: false,
  swElapsed: 0,
  swStartedAt: 0,
  clockTimer: null,
  swTimer: null
};

function clockFormatTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  const cs = Math.floor((ms % 1000) / 10);
  return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0') + '.' + String(cs).padStart(2, '0');
}

function clockUpdateLive() {
  const el = document.getElementById('clockLive');
  if (!el) return;
  const now = new Date();
  const h = now.getHours();
  const m = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');
  const h12 = h % 12 || 12;
  const ampm = h < 12 ? 'AM' : 'PM';
  el.textContent = h12 + ':' + m + ':' + s + ' ' + ampm;
  const dateEl = document.getElementById('clockDate');
  if (dateEl) {
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    dateEl.textContent = days[now.getDay()] + ', ' + months[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear();
  }
}

function clockUpdateStopwatch() {
  const el = document.getElementById('clockStopwatch');
  if (!el) return;
  let ms = clockState.swElapsed;
  if (clockState.swRunning) ms += (Date.now() - clockState.swStartedAt);
  el.textContent = clockFormatTime(ms);
}

function renderClock() {
  if (clockState.clockTimer) clearInterval(clockState.clockTimer);
  if (clockState.swTimer) clearInterval(clockState.swTimer);

  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 20px;">Clock</h2>';
  html += '<div class="clock-live-wrap">';
  html += '<div class="clock-live" id="clockLive">--:--:--</div>';
  html += '<div class="clock-date" id="clockDate">Loading...</div>';
  html += '</div>';
  html += '<div class="clock-sw-title">STOPWATCH</div>';
  html += '<div class="clock-stopwatch" id="clockStopwatch">00:00.00</div>';
  html += '<div class="clock-sw-buttons">';
  html += '<button class="clock-btn start" id="clockStart">START</button>';
  html += '<button class="clock-btn" id="clockReset">RESET</button>';
  html += '</div>';

  appScreenContent.innerHTML = html;

  clockUpdateLive();
  clockUpdateStopwatch();

  clockState.clockTimer = setInterval(clockUpdateLive, 1000);
  clockState.swTimer = setInterval(clockUpdateStopwatch, 50);

  const startBtn = document.getElementById('clockStart');
  if (startBtn) {
    startBtn.addEventListener('click', function() {
      if (typeof soundClick === 'function') soundClick();
      if (clockState.swRunning) {
        clockState.swElapsed += (Date.now() - clockState.swStartedAt);
        clockState.swRunning = false;
        startBtn.textContent = 'START';
        startBtn.classList.remove('pause');
        startBtn.classList.add('start');
      } else {
        clockState.swStartedAt = Date.now();
        clockState.swRunning = true;
        startBtn.textContent = 'PAUSE';
        startBtn.classList.remove('start');
        startBtn.classList.add('pause');
      }
    });
  }
  const resetBtn = document.getElementById('clockReset');
  if (resetBtn) {
    resetBtn.addEventListener('click', function() {
      if (typeof soundClick === 'function') soundClick();
      clockState.swRunning = false;
      clockState.swElapsed = 0;
      clockUpdateStopwatch();
      const s = document.getElementById('clockStart');
      if (s) { s.textContent = 'START'; s.classList.remove('pause'); s.classList.add('start'); }
    });
  }
}

/* ============================================================
   WEATHER APP (fake data)
   ============================================================ */
const WEATHER_CITIES = [
  { name: 'Lagos', temp: 31, condition: 'Sunny', humidity: 78, wind: 12 },
  { name: 'Abuja', temp: 29, condition: 'Cloudy', humidity: 65, wind: 8 },
  { name: 'New York', temp: 15, condition: 'Rainy', humidity: 82, wind: 20 },
  { name: 'London', temp: 11, condition: 'Foggy', humidity: 88, wind: 15 }
];

function renderWeather() {
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">Weather</h2>';
  html += '<div class="weather-list">';
  WEATHER_CITIES.forEach(function(city, i) {
    html += '<div class="weather-card" data-weather="' + i + '">';
    html += '<div class="weather-city">' + city.name + '</div>';
    html += '<div class="weather-temp">' + city.temp + '°C</div>';
    html += '<div class="weather-cond">' + city.condition + '</div>';
    html += '<div class="weather-details">Humidity ' + city.humidity + '% · Wind ' + city.wind + ' km/h</div>';
    html += '</div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
}

/* Add Clock + Weather icons to both home screens */
(function addClockWeatherIcons() {
  const makeClock = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'C';
    el.setAttribute('data-label', 'Clock');
    el.style.background = 'linear-gradient(135deg,#555,#222)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderClock();
    });
    return el;
  };
  const makeWeather = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'W';
    el.setAttribute('data-label', 'Weather');
    el.style.background = 'linear-gradient(135deg,#00e5ff,#0088ff)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderWeather();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) { ip.appendChild(makeClock()); ip.appendChild(makeWeather()); }
  if (an) { an.appendChild(makeClock()); an.appendChild(makeWeather()); }
})();

/* Route Clock/Weather in openApp */
(function patchOpenAppForClockWeather() {
  const orig = window.openApp;
  if (typeof orig !== 'function') return;
  window.openApp = function(name) {
    if (name === 'Clock') { renderClock(); return; }
    if (name === 'Weather') { renderWeather(); return; }if (name === 'Weather') { renderWeather(); return; }
    return orig.apply(this, arguments);
  };
})();
/* ============================================================
   NOTES APP
   ============================================================ */
var notesEditingId = null;
function notesGetAll(){ try { return JSON.parse(localStorage.getItem('notes') || '[]'); } catch(e) { return []; } }
function notesSaveAll(a){ localStorage.setItem('notes', JSON.stringify(a)); }
function notesEscape(s){ if (s === undefined || s === null) return ''; return String(s).replace(/[&<>"']/g, function(c){ if (c === '&') return '&amp;'; if (c === '<') return '&lt;'; if (c === '>') return '&gt;'; if (c === '"') return '&quot;'; if (c === "'") return '&#39;'; return c; }); }
function notesFormatDate(ts){ if (!ts) return ''; var d = new Date(ts); var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; var h = d.getHours(); var m = d.getMinutes(); if (m < 10) m = '0' + m; var ampm = h < 12 ? 'AM' : 'PM'; var h12 = h % 12 || 12; return months[d.getMonth()] + ' ' + d.getDate() + ', ' + h12 + ':' + m + ' ' + ampm; }
function renderNotes(){
  var notes = notesGetAll();
  notes.sort(function(a, b){ return b.updated - a.updated; });
  var h = '<div class="notes-header"><h2 class="notes-title">Notes</h2><button class="notes-new-btn" id="notesNewBtn">+</button></div>';
  if (notes.length === 0) {
    h += '<div class="notes-empty">No notes yet.<br>Tap + to create one.</div>';
  } else {
    h += '<div class="notes-list">';
    for (var i = 0; i < notes.length; i++) {
      var n = notes[i];
      var t = n.title || 'Untitled';
      var p = n.body ? n.body.slice(0, 60) : 'No content';
      h += '<div class="note-card" data-note-id="' + n.id + '"><div class="note-card-title">' + notesEscape(t) + '</div><div class="note-card-preview">' + notesEscape(p) + '</div><div class="note-card-date">' + notesFormatDate(n.updated) + '</div></div>';
    }
    h += '</div>';
  }
  appScreenContent.innerHTML = h;
  var nb = document.getElementById('notesNewBtn');
  if (nb) nb.onclick = function(){ openNoteEditor(null); };
  var cards = appScreenContent.querySelectorAll('.note-card');
  for (var j = 0; j < cards.length; j++) {
    cards[j].onclick = (function(el){ return function(){ openNoteEditor(parseInt(el.getAttribute('data-note-id'), 10)); }; })(cards[j]);
  }
}
function openNoteEditor(id){
  notesEditingId = id;
  var note = { id: null, title: '', body: '' };
  if (id !== null) {
    var notes = notesGetAll();
    for (var i = 0; i < notes.length; i++) { if (notes[i].id === id) { note = notes[i]; break; } }
  }
  var h = '<div class="note-editor">';
  h += '<input type="text" class="note-editor-title" id="noteTitleInput" placeholder="Title" value="' + notesEscape(note.title) + '">';
  h += '<textarea class="note-editor-body" id="noteBodyInput" placeholder="Start writing...">' + notesEscape(note.body) + '</textarea>';
  h += '<div class="note-actions"><button class="note-save-btn" id="noteSaveBtn">SAVE</button>';
  if (id !== null) h += '<button class="note-delete-btn" id="noteDeleteBtn">DELETE</button>';
  h += '</div></div>';
  appScreenContent.innerHTML = h;
  document.getElementById('noteSaveBtn').onclick = notesSaveCurrent;
  var del = document.getElementById('noteDeleteBtn');
  if (del) del.onclick = notesDeleteCurrent;
}
function notesSaveCurrent(){
  var t = document.getElementById('noteTitleInput').value.trim();
  var b = document.getElementById('noteBodyInput').value;
  if (t === '' && b.trim() === '') { renderNotes(); return; }
  var notes = notesGetAll();
  if (notesEditingId === null) {
    notes.push({ id: Date.now(), title: t, body: b, updated: Date.now() });
  } else {
    for (var i = 0; i < notes.length; i++) {
      if (notes[i].id === notesEditingId) { notes[i].title = t; notes[i].body = b; notes[i].updated = Date.now(); break; }
    }
  }
  notesSaveAll(notes);
  notesEditingId = null;
  renderNotes();
}
function notesDeleteCurrent(){
  if (notesEditingId === null) return;
  if (!confirm('Delete this note?')) return;
  var notes = notesGetAll().filter(function(n){ return n.id !== notesEditingId; });
  notesSaveAll(notes);
  notesEditingId = null;
  renderNotes();
}
setTimeout(function(){
  var allApps = document.querySelectorAll('.app');
  for (var i = 0; i < allApps.length; i++) {
    if (allApps[i].getAttribute('data-label') === 'Notes') {
      allApps[i].onclick = function(){
        if (appScreen) appScreen.classList.remove('hidden');
        if (flipCard) flipCard.classList.remove('flipped');
        renderNotes();
      };
    }
  }
}, 300);
var notesEditingId=null;
function notesGetAll(){try{return JSON.parse(localStorage.getItem('notes')||'[]');}catch(e){return [];}}
function notesSaveAll(a){localStorage.setItem('notes',JSON.stringify(a));}
function notesEscape(s){if(s===undefined||s===null)return '';return String(s).replace(/[&<>"']/g,function(c){if(c==='&')return '&amp;';if(c==='<')return '&lt;';if(c==='>')return '&gt;';if(c==='"')return '&quot;';if(c==="'")return '&#39;';return c;});}
function notesFormatDate(ts){if(!ts)return '';var d=new Date(ts);var months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];var h=d.getHours();var m=d.getMinutes();if(m<10)m='0'+m;var ampm=h<12?'AM':'PM';var h12=h%12||12;return months[d.getMonth()]+' '+d.getDate()+', '+h12+':'+m+' '+ampm;}
function renderNotes(){
  var notes=notesGetAll();
  notes.sort(function(a,b){return b.updated-a.updated;});
  var h='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px"><h2 style="font-size:18px;color:#ffcc00;font-weight:900;margin:0">Notes</h2><button id="notesNewBtn" style="background:#ffcc00;color:#0a0f1e;border:none;width:36px;height:36px;border-radius:50%;font-size:20px;font-weight:900;cursor:pointer">+</button></div>';
  if(notes.length===0){h+='<div style="text-align:center;padding:40px 20px;color:rgba(255,255,255,.4);font-size:12px">No notes yet.<br>Tap + to create one.</div>';}
  else{
    for(var i=0;i<notes.length;i++){
      var n=notes[i];
      var t=n.title||'Untitled';
      var p=n.body?n.body.slice(0,60):'No content';
      h+='<div class="note-card-'+n.id+'" data-note-id="'+n.id+'" style="background:rgba(255,255,255,.05);border:1px solid rgba(255,204,0,.2);border-radius:12px;padding:12px;cursor:pointer;margin-bottom:10px"><div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+notesEscape(t)+'</div><div style="font-size:11px;color:rgba(255,255,255,.5);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+notesEscape(p)+'</div><div style="font-size:9px;color:rgba(255,255,255,.35);margin-top:4px">'+notesFormatDate(n.updated)+'</div></div>';
    }
  }
  appScreenContent.innerHTML=h;
  var nb=document.getElementById('notesNewBtn');
  if(nb)nb.onclick=function(){openNoteEditor(null);};
  var cards=appScreenContent.querySelectorAll('[data-note-id]');
  for(var j=0;j<cards.length;j++){
    cards[j].onclick=(function(el){return function(){openNoteEditor(parseInt(el.getAttribute('data-note-id'),10));};})(cards[j]);
  }
}
function openNoteEditor(id){
  notesEditingId=id;
  var note={id:null,title:'',body:''};
  if(id!==null){
    var notes=notesGetAll();
    for(var i=0;i<notes.length;i++){if(notes[i].id===id){note=notes[i];break;}}
  }
  var h='<input type="text" id="noteTitleInput" placeholder="Title" value="'+notesEscape(note.title)+'" style="width:100%;background:transparent;border:none;color:#fff;font-size:18px;font-weight:700;outline:none;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.1);margin-bottom:12px;font-family:inherit">';
  h+='<textarea id="noteBodyInput" placeholder="Start writing..." style="width:100%;min-height:200px;background:transparent;border:none;color:#fff;font-size:13px;line-height:1.6;outline:none;resize:none;font-family:inherit">'+notesEscape(note.body)+'</textarea>';
  h+='<div style="display:flex;gap:10px;margin-top:16px"><button id="noteSaveBtn" style="flex:1;background:linear-gradient(135deg,#ffcc00,#ff8800);color:#0a0f1e;border:none;padding:12px;border-radius:20px;font-size:12px;font-weight:900;cursor:pointer">SAVE</button>';
  if(id!==null)h+='<button id="noteDeleteBtn" style="background:rgba(255,45,85,.15);border:1px solid rgba(255,45,85,.4);color:#ff2d55;padding:12px 20px;border-radius:20px;font-size:12px;font-weight:900;cursor:pointer">DELETE</button>';
  h+='</div>';
  appScreenContent.innerHTML=h;
  document.getElementById('noteSaveBtn').onclick=notesSaveCurrent;
  var del=document.getElementById('noteDeleteBtn');
  if(del)del.onclick=notesDeleteCurrent;
}
function notesSaveCurrent(){
  var t=document.getElementById('noteTitleInput').value.trim();
  var b=document.getElementById('noteBodyInput').value;
  if(t===''&&b.trim()===''){renderNotes();return;}
  var notes=notesGetAll();
  if(notesEditingId===null){notes.push({id:Date.now(),title:t,body:b,updated:Date.now()});}
  else{for(var i=0;i<notes.length;i++){if(notes[i].id===notesEditingId){notes[i].title=t;notes[i].body=b;notes[i].updated=Date.now();break;}}}
  notesSaveAll(notes);
  notesEditingId=null;
  renderNotes();
}
function notesDeleteCurrent(){
  if(notesEditingId===null)return;
  if(!confirm('Delete this note?'))return;
  var notes=notesGetAll().filter(function(n){return n.id!==notesEditingId;});
  notesSaveAll(notes);
  notesEditingId=null;
  renderNotes();
}
setTimeout(function(){
  var allApps=document.querySelectorAll('.app');
  for(var i=0;i<allApps.length;i++){
    if(allApps[i].getAttribute('data-label')==='Notes'){
      (function(el){
        el.onclick=function(){
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          renderNotes();
        };
      })(allApps[i]);
    }
  }
},500);
/* ============================================================
   ANDROID BACK IMAGES (per model)
   ============================================================ */
var ANDROID_BACKS = {
  'Samsung Galaxy S26 Ultra': 'https://i.postimg.cc/RZCgCCBZ/IMG-20260918-144810-157.png',
  'Samsung Galaxy S25':       'https://i.postimg.cc/8zkZkkSj/IMG-20260918-144852-814.png',
  'Samsung Galaxy S24':       'https://i.postimg.cc/9QXLXXhM/IMG-20260918-144924-747.png',
  'Google Pixel 9 Pro':       'https://i.postimg.cc/x1j6jj2q/IMG-20260918-144956-273.png',
  'Google Pixel 8':           'https://i.postimg.cc/QdNfNN3C/IMG-20260918-145022-600.png',
  'OnePlus 12':               'https://i.postimg.cc/Nj5QnH0J/IMG-20260918-151718-442.png',
  'Xiaomi 14 Ultra':          'https://i.postimg.cc/K8RmWMY0/IMG-20260918-151748-315.png',
  'Nothing Phone 2':          'https://i.postimg.cc/t4Y9cxgk/IMG-20260918-151836-069.png',
  'Infinix Zero 30':          'https://i.postimg.cc/Nj5QnH04/IMG-20260918-151912-113.png',
  'Infinix Note 40 Pro':      'https://i.postimg.cc/jSLR17jz/IMG-20260918-151933-378.png',
  'Tecno Camon 30':           'https://i.postimg.cc/526frCtq/IMG-20260918-151957-164.png',
  'Tecno Spark 20 Pro':       'https://i.postimg.cc/6pyBPvQr/IMG-20260918-152021-476.png',
  'itel P55':                 'https://i.postimg.cc/L6yHvTmQ/IMG-20260918-152057-749.png',
  'itel A70':                 'https://i.postimg.cc/J4T1KqRT/IMG-20260918-152131-608.png'
};
var _origOpenPhoneViewer = window.openPhoneViewer;
if (typeof _origOpenPhoneViewer === 'function') {
  window.openPhoneViewer = function(model, brand, number) {
    _origOpenPhoneViewer(model, brand, number);
    if (brand === 'android' && ANDROID_BACKS[model]) {
      setTimeout(function() {
        var img = document.getElementById('androidBackImg');
        if (img) img.src = ANDROID_BACKS[model];
      }, 50);
    }
  };
}
/* Remove ONLY exact "iPhone 12" and "iPhone 15" - keeps all Pro / Pro Max */
(function removeExactPhones(){
  var toRemove = ['iPhone 12', 'iPhone 15'];
  var i;
  for (i = iPhones.length - 1; i >= 0; i--) {
    if (toRemove.indexOf(iPhones[i]) !== -1) {
      iPhones.splice(i, 1);
    }
  }
})();
/* ============================================================
   IPHONE BACK IMAGES
   ============================================================ */
var IPHONE_BACKS = {
  'iPhone 7':           'https://i.postimg.cc/pTXg4NWJ/IMG-20260918-154145-993.png',
  'iPhone X':           'https://i.postimg.cc/85Pq98pB/IMG-20260918-154305-101.png',
  'iPhone XR':          'https://i.postimg.cc/cH4V2qxR/IMG-20260918-154330-469.png',
  'iPhone 11':          'https://i.postimg.cc/SsNw30SC/IMG-20260918-154406-083.png',
  'iPhone 13 Pro Max':  'https://i.postimg.cc/NMfWShsT/IMG-20260918-154422-912.png',
  'iPhone 14':          'https://i.postimg.cc/d1tzpMsy/IMG-20260918-154448-884.png',
  'iPhone 15 Pro Max':  'https://i.postimg.cc/XJ7TmMjr/IMG-20260918-154507-439.png',
  'iPhone 16':          'https://i.postimg.cc/635DgsWG/IMG-20260918-154523-368.png',
  'iPhone 16e':         'https://i.postimg.cc/SKGBgQh6/IMG-20260918-161424-228.png',
  'iPhone 17e':         'https://i.postimg.cc/ZRK12kb9/IMG-20260918-161753-924.png',
  'iPhone 17 Pro Max':  'https://i.postimg.cc/QMq2fN3F/IMG-20260918-162529-961.png'
};

var _origOpenPhoneViewerI = window.openPhoneViewer;
if (typeof _origOpenPhoneViewerI === 'function') {
  window.openPhoneViewer = function(model, brand, number) {
    _origOpenPhoneViewerI(model, brand, number);
    if (brand === 'iphone' && IPHONE_BACKS[model]) {
      setTimeout(function() {
        var img = document.getElementById('iphoneBackImg');
        if (img) img.src = IPHONE_BACKS[model];
      }, 50);
    }
  };
  
}
/* ============================================================
   FLAPPY BIRD
   ============================================================ */
var flappyState = {
  canvas: null, ctx: null, timer: null,
  bird: { x: 60, y: 140, vy: 0, size: 18 },
  pipes: [],
  score: 0,
  best: parseInt(localStorage.getItem('flappyBest') || '0', 10),
  running: false,
  dead: false,
  frame: 0
};
function flappyReset() {
  if (flappyState.timer) { clearInterval(flappyState.timer); flappyState.timer = null; }
  flappyState.bird = { x: 60, y: 140, vy: 0, size: 18 };
  flappyState.pipes = [];
  flappyState.score = 0;
  flappyState.running = false;
  flappyState.dead = false;
  flappyState.frame = 0;
}
function flappyFlap() {
  if (flappyState.dead) return;
  if (!flappyState.running) {
    flappyState.running = true;
    flappyState.timer = setInterval(flappyTick, 33);
  }
  flappyState.bird.vy = -7;
}
function flappyTick() {
  if (!flappyState.running) return;
  flappyState.frame++;
  var b = flappyState.bird;
  b.vy += 0.55;
  b.y += b.vy;
  if (b.y < 0) { b.y = 0; b.vy = 0; }
  if (b.y + b.size > 280) { flappyGameOver(); return; }
  if (flappyState.frame % 45 === 0) {
    var gapY = 60 + Math.random() * 130;
    flappyState.pipes.push({ x: 280, gapY: gapY, gapH: 90, passed: false });
  }
  for (var i = flappyState.pipes.length - 1; i >= 0; i--) {
    var p = flappyState.pipes[i];
    p.x -= 3;
    if (p.x + 40 < 0) { flappyState.pipes.splice(i, 1); continue; }
    if (!p.passed && p.x + 40 < b.x) {
      p.passed = true;
      flappyState.score += 1;
      if (flappyState.score > flappyState.best) {
        flappyState.best = flappyState.score;
        localStorage.setItem('flappyBest', String(flappyState.best));
      }
    }
    if (b.x + b.size > p.x && b.x < p.x + 40) {
      if (b.y < p.gapY || b.y + b.size > p.gapY + p.gapH) {
        flappyGameOver();
        return;
      }
    }
  }
  flappyDraw();
}
function flappyGameOver() {
  flappyState.running = false;
  flappyState.dead = true;
  if (flappyState.timer) { clearInterval(flappyState.timer); flappyState.timer = null; }
  if (flappyState.score > flappyState.best) {
    flappyState.best = flappyState.score;
    localStorage.setItem('flappyBest', String(flappyState.best));
  }
  flappyDraw();
}
function flappyDraw() {
  var c = flappyState.canvas;
  if (!c) return;
  var g = c.getContext('2d');
  g.fillStyle = '#0a0f1e';
  g.fillRect(0, 0, 280, 280);
  g.fillStyle = '#3ddc84';
  for (var i = 0; i < flappyState.pipes.length; i++) {
    var p = flappyState.pipes[i];
    g.fillRect(p.x, 0, 40, p.gapY);
    g.fillRect(p.x, p.gapY + p.gapH, 40, 280 - p.gapY - p.gapH);
  }
  var b = flappyState.bird;
  g.fillStyle = '#ffcc00';
  g.beginPath();
  g.arc(b.x + b.size / 2, b.y + b.size / 2, b.size / 2, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = '#fff';
  g.font = 'bold 20px system-ui';
  g.textAlign = 'center';
  g.fillText(String(flappyState.score), 140, 30);
  var sc = document.getElementById('flappyScore');
  if (sc) sc.textContent = 'SCORE: ' + flappyState.score;
  var bst = document.getElementById('flappyBest');
  if (bst) bst.textContent = 'BEST: ' + flappyState.best;
  var st = document.getElementById('flappyStatus');
  if (st) {
    if (flappyState.dead) st.textContent = 'GAME OVER - Tap Start';
    else if (!flappyState.running) st.textContent = 'Tap Start, then tap canvas to fly';
    else st.textContent = 'Tap canvas to fly';
  }
}
function renderFlappy() {
  flappyReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Flappy Bird</h2>';
  h += '<div class="game-score-row"><div class="game-score" id="flappyScore">SCORE: 0</div><div class="game-best" id="flappyBest">BEST: ' + flappyState.best + '</div></div>';
  h += '<div class="game-status" id="flappyStatus">Tap Start, then tap canvas to fly</div>';
  h += '<canvas id="flappyCanvas" class="game-canvas" width="280" height="280"></canvas>';
  h += '<button class="game-btn" id="flappyStart" style="margin-top:12px">START</button>';
  appScreenContent.innerHTML = h;
  flappyState.canvas = document.getElementById('flappyCanvas');
  flappyDraw();
  document.getElementById('flappyStart').onclick = function() {
    if (flappyState.dead) { flappyReset(); }
    flappyState.running = true;
    flappyState.bird.vy = -7;
    if (flappyState.timer) clearInterval(flappyState.timer);
    flappyState.timer = setInterval(flappyTick, 33);
    flappyDraw();
  };
  flappyState.canvas.addEventListener('click', flappyFlap);
}
/* ============================================================
   BREAKOUT
   ============================================================ */
var brkState = {
  canvas: null, timer: null,
  paddle: { x: 110, w: 60, h: 8, speed: 22 },
  ball: { x: 140, y: 200, vx: 3, vy: -3, r: 6 },
  bricks: [],
  score: 0,
  best: parseInt(localStorage.getItem('brkBest') || '0', 10),
  running: false,
  dead: false,
  frame: 0
};
function brkReset() {
  if (brkState.timer) { clearInterval(brkState.timer); brkState.timer = null; }
  brkState.paddle = { x: 110, w: 60, h: 8, speed: 22 };
  brkState.ball = { x: 140, y: 200, vx: 3, vy: -3, r: 6 };
  brkState.score = 0;
  brkState.running = false;
  brkState.dead = false;
  brkState.frame = 0;
  brkState.bricks = [];
  for (var r = 0; r < 5; r++) {
    for (var c = 0; c < 8; c++) {
      brkState.bricks.push({
        x: 10 + c * 33,
        y: 30 + r * 16,
        w: 30,
        h: 12,
        alive: true,
        color: ['#ff2d55','#ff8800','#ffcc00','#3ddc84','#00e5ff'][r]
      });
    }
  }
}
function brkTick() {
  if (!brkState.running) return;
  brkState.frame++;
  var b = brkState.ball;
  var p = brkState.paddle;
  b.x += b.vx;
  b.y += b.vy;
  if (b.x - b.r < 0) { b.x = b.r; b.vx *= -1; }
  if (b.x + b.r > 280) { b.x = 280 - b.r; b.vx *= -1; }
  if (b.y - b.r < 0) { b.y = b.r; b.vy *= -1; }
  if (b.y + b.r > 280) { brkGameOver(); return; }
  if (b.y + b.r > 260 && b.y + b.r < 275 && b.x > p.x && b.x < p.x + p.w) {
    b.y = 260 - b.r;
    b.vy = -Math.abs(b.vy);
    var hitPos = (b.x - p.x) / p.w - 0.5;
    b.vx = hitPos * 6;
  }
  for (var i = 0; i < brkState.bricks.length; i++) {
    var br = brkState.bricks[i];
    if (!br.alive) continue;
    if (b.x + b.r > br.x && b.x - b.r < br.x + br.w && b.y + b.r > br.y && b.y - b.r < br.y + br.h) {
      br.alive = false;
      b.vy *= -1;
      brkState.score += 10;
      if (brkState.score > brkState.best) {
        brkState.best = brkState.score;
        localStorage.setItem('brkBest', String(brkState.best));
      }
      break;
    }
  }
  var anyAlive = false;
  for (var k = 0; k < brkState.bricks.length; k++) {
    if (brkState.bricks[k].alive) { anyAlive = true; break; }
  }
  if (!anyAlive) { brkGameOver(); return; }
  brkDraw();
}
function brkGameOver() {
  brkState.running = false;
  brkState.dead = true;
  if (brkState.timer) { clearInterval(brkState.timer); brkState.timer = null; }
  brkDraw();
}
function brkDraw() {
  var c = brkState.canvas;
  if (!c) return;
  var g = c.getContext('2d');
  g.fillStyle = '#0a0f1e';
  g.fillRect(0, 0, 280, 280);
  for (var i = 0; i < brkState.bricks.length; i++) {
    var br = brkState.bricks[i];
    if (br.alive) {
      g.fillStyle = br.color;
      g.fillRect(br.x, br.y, br.w, br.h);
    }
  }
  var p = brkState.paddle;
  g.fillStyle = '#00e5ff';
  g.fillRect(p.x, 260, p.w, p.h);
  var b = brkState.ball;
  g.fillStyle = '#fff';
  g.beginPath();
  g.arc(b.x, b.y, b.r, 0, Math.PI * 2);
  g.fill();
  var sc = document.getElementById('brkScore');
  if (sc) sc.textContent = 'SCORE: ' + brkState.score;
  var bst = document.getElementById('brkBest');
  if (bst) bst.textContent = 'BEST: ' + brkState.best;
  var st = document.getElementById('brkStatus');
  if (st) {
    if (brkState.dead) st.textContent = 'GAME OVER - Tap Start';
    else if (!brkState.running) st.textContent = 'Tap Start, use LEFT / RIGHT';
    else st.textContent = 'Use LEFT / RIGHT buttons';
  }
}
function brkMoveLeft() {
  if (!brkState.running) return;
  brkState.paddle.x = Math.max(0, brkState.paddle.x - brkState.paddle.speed);
  brkDraw();
}
function brkMoveRight() {
  if (!brkState.running) return;
  brkState.paddle.x = Math.min(280 - brkState.paddle.w, brkState.paddle.x + brkState.paddle.speed);
  brkDraw();
}
function renderBreakout() {
  brkReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Breakout</h2>';
  h += '<div class="game-score-row"><div class="game-score" id="brkScore">SCORE: 0</div><div class="game-best" id="brkBest">BEST: ' + brkState.best + '</div></div>';
  h += '<div class="game-status" id="brkStatus">Tap Start, use LEFT / RIGHT</div>';
  h += '<canvas id="brkCanvas" class="game-canvas" width="280" height="280"></canvas>';
  h += '<div class="breakout-controls">';
  h += '<button class="breakout-btn" id="brkLeft">LEFT</button>';
  h += '<button class="breakout-btn" id="brkRight">RIGHT</button>';
  h += '</div>';
  h += '<button class="game-btn" id="brkStart" style="margin-top:12px">START</button>';
  appScreenContent.innerHTML = h;
  brkState.canvas = document.getElementById('brkCanvas');
  brkDraw();
  document.getElementById('brkStart').onclick = function() {
    if (brkState.dead) { brkReset(); }
    brkState.running = true;
    if (brkState.timer) clearInterval(brkState.timer);
    brkState.timer = setInterval(brkTick, 25);
    brkDraw();
  };
  document.getElementById('brkLeft').onclick = brkMoveLeft;
  document.getElementById('brkRight').onclick = brkMoveRight;
}
/* ============================================================
   SIMON SAYS
   ============================================================ */
var simonState = {
  sequence: [],
  playerIndex: 0,
  level: 1,
  playing: false,
  showing: false,
  colors: ['green', 'red', 'yellow', 'blue']
};
function simonReset() {
  simonState.sequence = [];
  simonState.playerIndex = 0;
  simonState.level = 1;
  simonState.playing = false;
  simonState.showing = false;
  var btns = document.querySelectorAll('.simon-btn');
  for (var i = 0; i < btns.length; i++) btns[i].classList.remove('active');
  var lv = document.getElementById('simonLevel');
  if (lv) lv.textContent = 'LEVEL ' + simonState.level;
  var st = document.getElementById('simonStatus');
  if (st) st.textContent = 'Tap Start';
}
function simonFlash(color, duration) {
  var el = document.querySelector('.simon-' + color);
  if (!el) return;
  el.classList.add('active');
  setTimeout(function() { el.classList.remove('active'); }, duration);
}
function simonShowSequence() {
  simonState.showing = true;
  var st = document.getElementById('simonStatus');
  if (st) st.textContent = 'Watch...';
  var i = 0;
  var step = function() {
    if (i >= simonState.sequence.length) {
      simonState.showing = false;
      simonState.playerIndex = 0;
      if (st) st.textContent = 'Your turn';
      return;
    }
    simonFlash(simonState.sequence[i], 400);
    i++;
    setTimeout(step, 600);
  };
  setTimeout(step, 500);
}
function simonAddStep() {
  var next = simonState.colors[Math.floor(Math.random() * 4)];
  simonState.sequence.push(next);
  simonShowSequence();
}
function simonStart() {
  simonReset();
  simonState.playing = true;
  simonAddStep();
}
function simonPress(color) {
  if (!simonState.playing) return;
  if (simonState.showing) return;
  simonFlash(color, 200);
  var expected = simonState.sequence[simonState.playerIndex];
  if (color !== expected) {
    simonState.playing = false;
    var st = document.getElementById('simonStatus');
    if (st) st.textContent = 'WRONG! You reached level ' + simonState.level;
    setTimeout(function() {
      var st2 = document.getElementById('simonStatus');
      if (st2) st2.textContent = 'Tap Start to play again';
    }, 1500);
    return;
  }
  simonState.playerIndex++;
  if (simonState.playerIndex >= simonState.sequence.length) {
    simonState.level++;
    var lv = document.getElementById('simonLevel');
    if (lv) lv.textContent = 'LEVEL ' + simonState.level;
    var st3 = document.getElementById('simonStatus');
    if (st3) st3.textContent = 'Good! Next level...';
    setTimeout(simonAddStep, 1000);
  }
}
function renderSimon() {
  simonReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Simon Says</h2>';
  h += '<div class="simon-level" id="simonLevel">LEVEL 1</div>';
  h += '<div class="game-status" id="simonStatus">Tap Start</div>';
  h += '<div class="simon-grid">';
  h += '<div class="simon-btn simon-green" data-simon="green"></div>';
  h += '<div class="simon-btn simon-red" data-simon="red"></div>';
  h += '<div class="simon-btn simon-blue" data-simon="blue"></div>';
  h += '<div class="simon-btn simon-yellow" data-simon="yellow"></div>';
  h += '</div>';
  h += '<button class="game-btn" id="simonStart">START</button>';
  appScreenContent.innerHTML = h;
  var btns = appScreenContent.querySelectorAll('.simon-btn');
  for (var i = 0; i < btns.length; i++) {
    btns[i].onclick = (function(el) {
      return function() { simonPress(el.getAttribute('data-simon')); };
    })(btns[i]);
  }
  document.getElementById('simonStart').onclick = simonStart;
}
/* ============================================================
   ADD NEW GAMES TO THE FOLDER
   ============================================================ */
(function addNewGames(){
  /* Add 3 new tiles to the games list array if not already there */
  var newGames = [
    ['Flappy Bird', 'F', '#ffcc00'],
    ['Breakout',    'B', '#00e5ff'],
    ['Simon Says',  'S', '#ff006e']
  ];
  if (typeof gamesList !== 'undefined') {
    for (var i = 0; i < newGames.length; i++) {
      var exists = false;
      for (var j = 0; j < gamesList.length; j++) {
        if (gamesList[j][0] === newGames[i][0]) { exists = true; break; }
      }
      if (!exists) gamesList.push(newGames[i]);
    }
  }

  /* Hook openGame so it opens the new games */
  var _origOpenGame = window.openGame;
  if (typeof _origOpenGame === 'function') {
    window.openGame = function(name){
      if (name === 'Flappy Bird') { renderFlappy(); return; }
      if (name === 'Breakout')    { renderBreakout(); return; }
      if (name === 'Simon Says')  { renderSimon(); return; }
      return _origOpenGame.apply(this, arguments);
    };
  }
})();
/* ============================================================
   FULL GAMES FOLDER - ALL 9 GAMES
   ============================================================ */
var ALL_GAMES = [
  ['Tic Tac Toe', 'X', '#00e5ff'],
  ['Snake',       'S', '#3ddc84'],
  ['2048',        '2', '#ffcc00'],
  ['Whack',       'W', '#ff006e'],
  ['Memory',      'M', '#1a88ff'],
  ['RPS',         'R', '#ff6600'],
  ['Flappy Bird', 'F', '#ffcc00'],
  ['Breakout',    'B', '#00e5ff'],
  ['Simon Says',  'S', '#ff006e']
];

window.renderGamesFolder = function(){
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 16px">GAMES</h2>';
  h += '<div class="games-grid">';
  for (var i = 0; i < ALL_GAMES.length; i++) {
    h += '<div class="games-tile" data-game="' + ALL_GAMES[i][0] + '">';
    h += '<div class="games-icon" style="background:' + ALL_GAMES[i][2] + '">' + ALL_GAMES[i][1] + '</div>';
    h += '<div class="games-label">' + ALL_GAMES[i][0] + '</div>';
    h += '</div>';
  }
  h += '</div>';
  appScreenContent.innerHTML = h;
  var tiles = appScreenContent.querySelectorAll('.games-tile');
  for (var j = 0; j < tiles.length; j++) {
    tiles[j].onclick = (function(el){
      return function(){ openGame(el.getAttribute('data-game')); };
    })(tiles[j]);
  }
};
/* ============================================================
   PONG
   ============================================================ */
var pongState = {
  canvas: null, timer: null,
  player: { y: 110, h: 60, speed: 22 },
  cpu: { y: 110, h: 60, speed: 4 },
  ball: { x: 140, y: 160, vx: 3, vy: 2.5, r: 6 },
  playerScore: 0,
  cpuScore: 0,
  running: false,
  dead: false
};
function pongReset() {
  if (pongState.timer) { clearInterval(pongState.timer); pongState.timer = null; }
  pongState.player = { y: 110, h: 60, speed: 22 };
  pongState.cpu = { y: 110, h: 60, speed: 4 };
  pongState.ball = { x: 140, y: 160, vx: 3, vy: 2.5, r: 6 };
  pongState.playerScore = 0;
  pongState.cpuScore = 0;
  pongState.running = false;
  pongState.dead = false;
}
function pongTick() {
  if (!pongState.running) return;
  var b = pongState.ball;
  b.x += b.vx;
  b.y += b.vy;
  if (b.y - b.r < 0) { b.y = b.r; b.vy *= -1; }
  if (b.y + b.r > 320) { b.y = 320 - b.r; b.vy *= -1; }
  var p = pongState.player;
  if (b.x - b.r < 20 && b.x - b.r > 10 && b.y > p.y && b.y < p.y + p.h) {
    b.x = 20 + b.r;
    b.vx = Math.abs(b.vx);
  }
  var c = pongState.cpu;
  var targetY = b.y - c.h / 2;
  if (c.y < targetY - 4) c.y += c.speed;
  else if (c.y > targetY + 4) c.y -= c.speed;
  if (c.y < 0) c.y = 0;
  if (c.y + c.h > 320) c.y = 320 - c.h;
  if (b.x + b.r > 280 - 20 && b.x + b.r < 280 - 10 && b.y > c.y && b.y < c.y + c.h) {
    b.x = 280 - 20 - b.r;
    b.vx = -Math.abs(b.vx);
  }
  if (b.x - b.r < 0) {
    pongState.cpuScore++;
    pongResetBall();
  }
  if (b.x + b.r > 280) {
    pongState.playerScore++;
    pongResetBall();
  }
  if (pongState.playerScore >= 5 || pongState.cpuScore >= 5) {
    pongGameOver();
    return;
  }
  pongDraw();
}
function pongResetBall() {
  pongState.ball.x = 140;
  pongState.ball.y = 160;
  pongState.ball.vx = Math.random() > 0.5 ? 3 : -3;
  pongState.ball.vy = Math.random() > 0.5 ? 2.5 : -2.5;
  pongDraw();
}
function pongGameOver() {
  pongState.running = false;
  pongState.dead = true;
  if (pongState.timer) { clearInterval(pongState.timer); pongState.timer = null; }
  pongDraw();
}
function pongDraw() {
  var cv = pongState.canvas;
  if (!cv) return;
  var g = cv.getContext('2d');
  g.fillStyle = '#0a0f1e';
  g.fillRect(0, 0, 280, 320);
  g.strokeStyle = 'rgba(255,255,255,0.15)';
  g.setLineDash([5, 5]);
  g.beginPath();
  g.moveTo(140, 0);
  g.lineTo(140, 320);
  g.stroke();
  g.setLineDash([]);
  g.fillStyle = '#00e5ff';
  g.fillRect(10, pongState.player.y, 6, pongState.player.h);
  g.fillStyle = '#ff2d55';
  g.fillRect(264, pongState.cpu.y, 6, pongState.cpu.h);
  g.fillStyle = '#fff';
  g.beginPath();
  g.arc(pongState.ball.x, pongState.ball.y, pongState.ball.r, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = 'rgba(255,255,255,0.5)';
  g.font = 'bold 24px system-ui';
  g.fillText(String(pongState.playerScore), 100, 40);
  g.fillText(String(pongState.cpuScore), 170, 40);
  var s1 = document.getElementById('pongPlayerScore');
  if (s1) s1.textContent = 'YOU: ' + pongState.playerScore;
  var s2 = document.getElementById('pongCpuScore');
  if (s2) s2.textContent = 'CPU: ' + pongState.cpuScore;
  var st = document.getElementById('pongStatus');
  if (st) {
    if (pongState.dead) st.textContent = pongState.playerScore >= 5 ? 'YOU WIN!' : 'CPU WINS - Tap Start';
    else if (!pongState.running) st.textContent = 'First to 5 wins';
    else st.textContent = 'Playing...';
  }
}
function pongMoveUp() {
  pongState.player.y = Math.max(0, pongState.player.y - pongState.player.speed);
  pongDraw();
}
function pongMoveDown() {
  pongState.player.y = Math.min(320 - pongState.player.h, pongState.player.y + pongState.player.speed);
  pongDraw();
}
function renderPong() {
  pongReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Pong</h2>';
  h += '<div class="game-score-row"><div class="game-score" id="pongPlayerScore">YOU: 0</div><div class="game-best" id="pongCpuScore">CPU: 0</div></div>';
  h += '<div class="game-status" id="pongStatus">First to 5 wins</div>';
  h += '<canvas id="pongCanvas" width="280" height="320" style="width:100%;max-width:280px;height:320px;background:#0a0f1e;border-radius:12px;display:block;margin:0 auto 12px;border:2px solid rgba(0,229,255,0.2)"></canvas>';
  h += '<div class="pong-controls">';
  h += '<button class="pong-btn" id="pongUp">UP</button>';
  h += '<button class="pong-btn" id="pongDown">DOWN</button>';
  h += '</div>';
  h += '<button class="game-btn" id="pongStart" style="margin-top:12px">START</button>';
  appScreenContent.innerHTML = h;
  pongState.canvas = document.getElementById('pongCanvas');
  pongDraw();
  document.getElementById('pongStart').onclick = function() {
    if (pongState.dead) { pongReset(); pongState.canvas = document.getElementById('pongCanvas'); }
    pongState.running = true;
    if (pongState.timer) clearInterval(pongState.timer);
    pongState.timer = setInterval(pongTick, 25);
    pongDraw();
  };
  document.getElementById('pongUp').onclick = pongMoveUp;
  document.getElementById('pongDown').onclick = pongMoveDown;
}
/* ============================================================
   TOWER STACK
   ============================================================ */
var towerState = {
  canvas: null, timer: null,
  blocks: [],
  currentX: 0, currentDir: 1, currentW: 140, currentH: 22,
  score: 0,
  best: parseInt(localStorage.getItem('towerBest') || '0', 10),
  running: false, dead: false
};
function towerReset() {
  if (towerState.timer) { clearInterval(towerState.timer); towerState.timer = null; }
  towerState.blocks = [];
  towerState.currentX = 60;
  towerState.currentDir = 1;
  towerState.currentW = 140;
  towerState.currentH = 22;
  towerState.score = 0;
  towerState.running = false;
  towerState.dead = false;
}
function towerTick() {
  if (!towerState.running) return;
  towerState.currentX += towerState.currentDir * 3;
  if (towerState.currentX <= 0) { towerState.currentX = 0; towerState.currentDir = 1; }
  if (towerState.currentX + towerState.currentW >= 280) {
    towerState.currentX = 280 - towerState.currentW;
    towerState.currentDir = -1;
  }
  towerDraw();
}
function towerDrop() {
  if (!towerState.running) return;
  var last = towerState.blocks.length > 0 ? towerState.blocks[towerState.blocks.length - 1] : null;
  var newX = towerState.currentX;
  var newW = towerState.currentW;
  if (last) {
    var lastLeft = last.x;
    var lastRight = last.x + last.w;
    var newLeft = newX;
    var newRight = newX + newW;
    var overlapLeft = Math.max(lastLeft, newLeft);
    var overlapRight = Math.min(lastRight, newRight);
    var overlapW = overlapRight - overlapLeft;
    if (overlapW <= 0) { towerGameOver(); return; }
    newX = overlapLeft;
    newW = overlapW;
  }
  towerState.blocks.push({ x: newX, y: 0, w: newW, h: towerState.currentH });
  towerState.score++;
  if (towerState.score > towerState.best) {
    towerState.best = towerState.score;
    localStorage.setItem('towerBest', String(towerState.best));
  }
  towerState.currentW = newW;
  towerState.currentX = 0;
  towerState.currentDir = 1;
  towerDraw();
}
function towerGameOver() {
  towerState.running = false;
  towerState.dead = true;
  if (towerState.timer) { clearInterval(towerState.timer); towerState.timer = null; }
  towerDraw();
}
function towerDraw() {
  var cv = towerState.canvas;
  if (!cv) return;
  var g = cv.getContext('2d');
  g.fillStyle = '#0a0f1e';
  g.fillRect(0, 0, 280, 320);
  var baseY = 300;
  for (var i = 0; i < towerState.blocks.length; i++) {
    var b = towerState.blocks[i];
    var y = baseY - (i + 1) * towerState.currentH - i * 2;
    g.fillStyle = 'hsl(' + (i * 40 % 360) + ', 70%, 60%)';
    g.fillRect(b.x, y, b.w, b.h);
  }
  if (towerState.running) {
    var cy = baseY - (towerState.blocks.length + 1) * towerState.currentH - towerState.blocks.length * 2;
    g.fillStyle = '#ffcc00';
    g.fillRect(towerState.currentX, cy, towerState.currentW, towerState.currentH);
  }
  var sc = document.getElementById('towerScore');
  if (sc) sc.textContent = 'HEIGHT: ' + towerState.score;
  var bst = document.getElementById('towerBest');
  if (bst) bst.textContent = 'BEST: ' + towerState.best;
  var st = document.getElementById('towerStatus');
  if (st) {
    if (towerState.dead) st.textContent = 'GAME OVER - Tap Start';
    else if (!towerState.running) st.textContent = 'Tap DROP when aligned';
    else st.textContent = 'Tap DROP to place';
  }
}
function renderTower() {
  towerReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Tower Stack</h2>';
  h += '<div class="game-score-row"><div class="game-score" id="towerScore">HEIGHT: 0</div><div class="game-best" id="towerBest">BEST: ' + towerState.best + '</div></div>';
  h += '<div class="game-status" id="towerStatus">Tap DROP when aligned</div>';
  h += '<canvas id="towerCanvas" class="tower-canvas" width="280" height="320"></canvas>';
  h += '<button class="game-btn" id="towerDropBtn" style="margin-bottom:8px">DROP</button>';
  h += '<button class="game-btn" id="towerStart" style="background:rgba(255,255,255,0.1);color:#fff">START</button>';
  appScreenContent.innerHTML = h;
  towerState.canvas = document.getElementById('towerCanvas');
  towerDraw();
  document.getElementById('towerStart').onclick = function() {
    if (towerState.dead) { towerReset(); towerState.canvas = document.getElementById('towerCanvas'); }
    towerState.running = true;
    if (towerState.timer) clearInterval(towerState.timer);
    towerState.timer = setInterval(towerTick, 25);
    towerDraw();
  };
  document.getElementById('towerDropBtn').onclick = towerDrop;
}
/* ============================================================
   BUBBLE POP
   ============================================================ */
var bubbleState = {
  timer: null,
  spawnTimer: null,
  bubbles: [],
  score: 0,
  timeLeft: 30,
  best: parseInt(localStorage.getItem('bubbleBest') || '0', 10),
  running: false,
  nextId: 0
};
function bubbleReset() {
  if (bubbleState.timer) { clearInterval(bubbleState.timer); bubbleState.timer = null; }
  if (bubbleState.spawnTimer) { clearInterval(bubbleState.spawnTimer); bubbleState.spawnTimer = null; }
  bubbleState.bubbles = [];
  bubbleState.score = 0;
  bubbleState.timeLeft = 30;
  bubbleState.running = false;
  bubbleState.nextId = 0;
}
function bubbleSpawn() {
  if (!bubbleState.running) return;
  var area = document.getElementById('bubbleArea');
  if (!area) return;
  var colors = ['#00e5ff','#ff006e','#3ddc84','#ffcc00','#a855f7','#ff6699'];
  var size = 40 + Math.random() * 30;
  var x = Math.random() * (area.offsetWidth - size);
  var y = Math.random() * (area.offsetHeight - size);
  var color = colors[Math.floor(Math.random() * colors.length)];
  var id = bubbleState.nextId++;
  var lifetime = 1200 + Math.random() * 800;
  var el = document.createElement('div');
  el.className = 'bubble';
  el.style.width = size + 'px';
  el.style.height = size + 'px';
  el.style.left = x + 'px';
  el.style.top = y + 'px';
  el.style.background = color;
  el.style.boxShadow = '0 0 20px ' + color;
  el.setAttribute('data-id', id);
  var self = { id: id, el: el, timer: null };
  el.onclick = function() {
    if (!bubbleState.running) return;
    if (!self.el.parentNode) return;
    bubbleState.score++;
    if (bubbleState.score > bubbleState.best) {
      bubbleState.best = bubbleState.score;
      localStorage.setItem('bubbleBest', String(bubbleState.best));
    }
    clearTimeout(self.timer);
    self.el.remove();
    bubbleRenderScore();
  };
  area.appendChild(el);
  self.timer = setTimeout(function() {
    if (self.el.parentNode) self.el.remove();
  }, lifetime);
}
function bubbleTick() {
  if (!bubbleState.running) return;
  bubbleState.timeLeft -= 1;
  var t = document.getElementById('bubbleTime');
  if (t) t.textContent = 'TIME: ' + bubbleState.timeLeft;
  if (bubbleState.timeLeft <= 0) bubbleEnd();
}
function bubbleEnd() {
  bubbleState.running = false;
  if (bubbleState.timer) { clearInterval(bubbleState.timer); bubbleState.timer = null; }
  if (bubbleState.spawnTimer) { clearInterval(bubbleState.spawnTimer); bubbleState.spawnTimer = null; }
  if (bubbleState.score > bubbleState.best) {
    bubbleState.best = bubbleState.score;
    localStorage.setItem('bubbleBest', String(bubbleState.best));
  }
  var area = document.getElementById('bubbleArea');
  if (area) {
    var bubbles = area.querySelectorAll('.bubble');
    for (var i = 0; i < bubbles.length; i++) bubbles[i].remove();
  }
  var st = document.getElementById('bubbleStatus');
  if (st) st.textContent = 'GAME OVER - Final: ' + bubbleState.score;
  bubbleRenderScore();
}
function bubbleRenderScore() {
  var sc = document.getElementById('bubbleScore');
  if (sc) sc.textContent = 'SCORE: ' + bubbleState.score;
  var bst = document.getElementById('bubbleBest');
  if (bst) bst.textContent = 'BEST: ' + bubbleState.best;
}
function renderBubble() {
  bubbleReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Bubble Pop</h2>';
  h += '<div class="game-score-row"><div class="game-score" id="bubbleScore">SCORE: 0</div><div class="game-best" id="bubbleBest">BEST: ' + bubbleState.best + '</div></div>';
  h += '<div class="game-status" id="bubbleStatus">Tap Start, pop bubbles fast</div>';
  h += '<div class="game-status" id="bubbleTime" style="color:#ffcc00;font-weight:700">TIME: 30</div>';
  h += '<div class="bubble-area" id="bubbleArea"></div>';
  h += '<button class="game-btn" id="bubbleStart">START</button>';
  appScreenContent.innerHTML = h;
  bubbleRenderScore();
  document.getElementById('bubbleStart').onclick = function() {
    if (bubbleState.running) return;
    bubbleReset();
    bubbleState.running = true;
    var st = document.getElementById('bubbleStatus');
    if (st) st.textContent = 'POP THEM ALL!';
    bubbleState.spawnTimer = setInterval(bubbleSpawn, 550);
    bubbleState.timer = setInterval(bubbleTick, 1000);
    bubbleSpawn();
  };
}
/* ============================================================
   ADD BATCH 1 GAMES TO FOLDER
   ============================================================ */
(function addBatch1Games(){
  if (typeof ALL_GAMES !== 'undefined') {
    var newBatch = [
      ['Pong',        'P', '#1a88ff'],
      ['Tower Stack', 'T', '#a855f7'],
      ['Bubble Pop',  'B', '#ff6699']
    ];
    for (var i = 0; i < newBatch.length; i++) {
      var exists = false;
      for (var j = 0; j < ALL_GAMES.length; j++) {
        if (ALL_GAMES[j][0] === newBatch[i][0]) { exists = true; break; }
      }
      if (!exists) ALL_GAMES.push(newBatch[i]);
    }
  }
  var _origOpenGame3 = window.openGame;
  if (typeof _origOpenGame3 === 'function') {
    window.openGame = function(name){
      if (name === 'Pong')        { renderPong(); return; }
      if (name === 'Tower Stack') { renderTower(); return; }
      if (name === 'Bubble Pop')  { renderBubble(); return; }
      return _origOpenGame3.apply(this, arguments);
    };
  }
})();
/* ============================================================
   COLOR SWITCH
   ============================================================ */
var csState = {
  timer: null, spawnTimer: null,
  ballY: 200, ballVY: 0,
  ballColor: '#00e5ff',
  obstacles: [],
  score: 0,
  best: parseInt(localStorage.getItem('csBest') || '0', 10),
  running: false, dead: false,
  colors: ['#00e5ff', '#ff006e', '#3ddc84', '#ffcc00'],
  colorIdx: 0,
  frame: 0
};
function csReset() {
  if (csState.timer) { clearInterval(csState.timer); csState.timer = null; }
  if (csState.spawnTimer) { clearInterval(csState.spawnTimer); csState.spawnTimer = null; }
  csState.ballY = 200;
  csState.ballVY = 0;
  csState.ballColor = '#00e5ff';
  csState.colorIdx = 0;
  csState.obstacles = [];
  csState.score = 0;
  csState.running = false;
  csState.dead = false;
  csState.frame = 0;
  var stage = document.getElementById('csStage');
  if (stage) stage.innerHTML = '';
}
function csTick() {
  if (!csState.running) return;
  csState.frame++;
  csState.ballVY += 0.5;
  csState.ballY += csState.ballVY;
  if (csState.ballY > 220) { csState.ballY = 220; csState.ballVY = 0; }
  if (csState.ballY < 0) { csState.ballY = 0; csState.ballVY = 0; }
  var stage = document.getElementById('csStage');
  if (!stage) return;
  var stageH = stage.offsetHeight || 280;
  var ballEl = document.getElementById('csBall');
  if (ballEl) {
    ballEl.style.bottom = (stageH - csState.ballY - 30) + 'px';
    ballEl.style.background = csState.ballColor;
    ballEl.style.boxShadow = '0 0 20px ' + csState.ballColor;
  }
  if (csState.frame % 40 === 0) {
    var colors = [];
    var baseColors = csState.colors;
    for (var s = 0; s < 4; s++) {
      colors.push(baseColors[(csState.colorIdx + s) % 4]);
    }
    csState.obstacles.push({ y: -20, colors: colors, el: null, passed: false });
  }
  for (var i = csState.obstacles.length - 1; i >= 0; i--) {
    var ob = csState.obstacles[i];
    ob.y += 2.5;
    if (ob.el) {
      ob.el.style.top = ob.y + 'px';
    } else {
      var div = document.createElement('div');
      div.className = 'cs-obstacle';
      div.style.top = ob.y + 'px';
      for (var k = 0; k < 4; k++) {
        var seg = document.createElement('div');
        seg.style.background = ob.colors[k];
        div.appendChild(seg);
      }
      stage.appendChild(div);
      ob.el = div;
    }
    if (!ob.passed && ob.y > 260) {
      ob.passed = true;
      csState.score++;
      if (csState.score > csState.best) {
        csState.best = csState.score;
        localStorage.setItem('csBest', String(csState.best));
      }
      var sc = document.getElementById('csScore');
      if (sc) sc.textContent = 'SCORE: ' + csState.score;
      var bst = document.getElementById('csBest');
      if (bst) bst.textContent = 'BEST: ' + csState.best;
    }
    if (ob.y > 320) {
      if (ob.el && ob.el.parentNode) ob.el.remove();
      csState.obstacles.splice(i, 1);
      continue;
    }
    if (csState.ballY + 30 > ob.y && csState.ballY < ob.y + 24) {
      var relX = 0.5;
      var colIdx = Math.floor(relX * 4);
      if (colIdx < 0) colIdx = 0;
      if (colIdx > 3) colIdx = 3;
      var obstacleColor = ob.colors[colIdx];
      if (obstacleColor !== csState.ballColor) {
        csGameOver();
        return;
      }
    }
  }
}
function csTap() {
  if (!csState.running) return;
  csState.ballVY = -7;
  csState.colorIdx = (csState.colorIdx + 1) % 4;
  csState.ballColor = csState.colors[csState.colorIdx];
}
function csGameOver() {
  csState.running = false;
  csState.dead = true;
  if (csState.timer) { clearInterval(csState.timer); csState.timer = null; }
  if (csState.spawnTimer) { clearInterval(csState.spawnTimer); csState.spawnTimer = null; }
  var st = document.getElementById('csStatus');
  if (st) st.textContent = 'GAME OVER - Final: ' + csState.score;
}
function renderColorSwitch() {
  csReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Color Switch</h2>';
  h += '<div class="game-score-row"><div class="game-score" id="csScore">SCORE: 0</div><div class="game-best" id="csBest">BEST: ' + csState.best + '</div></div>';
  h += '<div class="game-status" id="csStatus">Tap to fly and change color</div>';
  h += '<div class="cs-stage" id="csStage">';
  h += '<div class="cs-ball" id="csBall" style="background:' + csState.ballColor + '"></div>';
  h += '</div>';
  h += '<button class="game-btn" id="csStart" style="margin-top:12px">START</button>';
  appScreenContent.innerHTML = h;
  var stage = document.getElementById('csStage');
  if (stage) {
    stage.onclick = function() {
      if (!csState.running) return;
      csTap();
    };
  }
  document.getElementById('csStart').onclick = function(e) {
    e.stopPropagation();
    csReset();
    var s = document.getElementById('csStage');
    if (s) {
      s.innerHTML = '<div class="cs-ball" id="csBall"></div>';
      s.onclick = function() {
        if (!csState.running) return;
        csTap();
      };
    }
    csState.running = true;
    var st = document.getElementById('csStatus');
    if (st) st.textContent = 'Tap anywhere to fly + change color';
    csState.timer = setInterval(csTick, 25);
  };
}
/* ============================================================
   WORD GUESS
   ============================================================ */
var wgState = {
  words: ['APPLE','TIGER','HOUSE','BRAIN','MOUSE','LIGHT','MUSIC','HAPPY','WATER','PHONE','STONE','CLOUD','DREAM','SMILE','HORSE','PLANT','BEACH','PARTY','MONEY','RIVER'],
  word: '',
  guesses: [],
  current: '',
  maxGuesses: 6,
  letters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),
  letterStates: {},
  finished: false
};
function wgReset() {
  wgState.word = wgState.words[Math.floor(Math.random() * wgState.words.length)];
  wgState.guesses = [];
  wgState.current = '';
  wgState.letterStates = {};
  wgState.finished = false;
}
function wgRender() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Word Guess</h2>';
  var st = document.getElementById('wgStatus');
  var statusText = 'Guess the 5-letter word';
  if (wgState.finished) {
    statusText = 'YOU GOT IT! Word: ' + wgState.word;
  }
  h += '<div class="game-status" id="wgStatus">' + statusText + '</div>';
  for (var g = 0; g < wgState.maxGuesses; g++) {
    h += '<div class="wg-letters">';
    var guess = wgState.guesses[g] || '';
    if (g === wgState.guesses.length && !wgState.finished) guess = wgState.current;
    for (var c = 0; c < 5; c++) {
      var ch = guess[c] || '';
      var cls = 'wg-letter';
      if (ch) cls += ' filled';
      if (wgState.guesses[g]) {
        if (wgState.guesses[g][c] === wgState.word[c]) cls = 'wg-letter correct';
        else if (wgState.word.indexOf(wgState.guesses[g][c]) !== -1) cls = 'wg-letter filled';
        else cls = 'wg-letter wrong';
      }
      h += '<div class="' + cls + '">' + ch + '</div>';
    }
    h += '</div>';
  }
  h += '<div class="wg-keyboard">';
  for (var k = 0; k < wgState.letters.length; k++) {
    var L = wgState.letters[k];
    var kcls = 'wg-key';
    if (wgState.letterStates[L] === 'correct') kcls += ' correct';
    else if (wgState.letterStates[L] === 'wrong') kcls += ' wrong';
    h += '<button class="' + kcls + '" data-wg-key="' + L + '">' + L + '</button>';
  }
  h += '</div>';
  h += '<div style="display:flex;gap:10px;justify-content:center;margin-top:14px">';
  h += '<button class="game-btn" id="wgSubmit">ENTER</button>';
  h += '<button class="game-btn" id="wgDelete" style="background:rgba(255,255,255,0.1);color:#fff">DELETE</button>';
  h += '<button class="game-btn" id="wgNew" style="background:rgba(255,255,255,0.1);color:#fff">NEW</button>';
  h += '</div>';
  appScreenContent.innerHTML = h;
  var keys = appScreenContent.querySelectorAll('[data-wg-key]');
  for (var i = 0; i < keys.length; i++) {
    keys[i].onclick = (function(k){
      return function(){ wgPress(k.getAttribute('data-wg-key')); };
    })(keys[i]);
  }
  document.getElementById('wgSubmit').onclick = wgSubmit;
  document.getElementById('wgDelete').onclick = wgDelete;
  document.getElementById('wgNew').onclick = function(){ wgReset(); wgRender(); };
}
function wgPress(L) {
  if (wgState.finished) return;
  if (wgState.current.length >= 5) return;
  wgState.current += L;
  wgRender();
}
function wgDelete() {
  if (wgState.finished) return;
  if (wgState.current.length === 0) return;
  wgState.current = wgState.current.slice(0, -1);
  wgRender();
}
function wgSubmit() {
  if (wgState.finished) return;
  if (wgState.current.length !== 5) {
    var st = document.getElementById('wgStatus');
    if (st) st.textContent = 'Need 5 letters';
    setTimeout(function(){
      var st2 = document.getElementById('wgStatus');
      if (st2) st2.textContent = 'Guess the 5-letter word';
    }, 1200);
    return;
  }
  var guess = wgState.current;
  wgState.guesses.push(guess);
  for (var i = 0; i < 5; i++) {
    var L = guess[i];
    if (guess[i] === wgState.word[i]) {
      wgState.letterStates[L] = 'correct';
    } else if (wgState.word.indexOf(L) !== -1) {
      if (wgState.letterStates[L] !== 'correct') wgState.letterStates[L] = 'filled';
    } else {
      wgState.letterStates[L] = 'wrong';
    }
  }
  wgState.current = '';
  if (guess === wgState.word) {
    wgState.finished = true;
  } else if (wgState.guesses.length >= wgState.maxGuesses) {
    wgState.finished = true;
    var st3 = document.getElementById('wgStatus');
    if (st3) st3.textContent = 'OUT OF TRIES! Word was: ' + wgState.word;
    wgRender();
    var st4 = document.getElementById('wgStatus');
    if (st4) st4.textContent = 'OUT OF TRIES! Word was: ' + wgState.word;
    return;
  }
  wgRender();
}
function renderWordGuess() {
  wgReset();
  wgRender();
}
/* ============================================================
   ADD BATCH 2 GAMES TO FOLDER
   ============================================================ */
(function addBatch2Games(){
  if (typeof ALL_GAMES !== 'undefined') {
    var newBatch = [
      ['Color Switch', 'C', '#a855f7'],
      ['Word Guess',   'W', '#3ddc84']
    ];
    for (var i = 0; i < newBatch.length; i++) {
      var exists = false;
      for (var j = 0; j < ALL_GAMES.length; j++) {
        if (ALL_GAMES[j][0] === newBatch[i][0]) { exists = true; break; }
      }
      if (!exists) ALL_GAMES.push(newBatch[i]);
    }
  }
  var _origOpenGame4 = window.openGame;
  if (typeof _origOpenGame4 === 'function') {
    window.openGame = function(name){
      if (name === 'Color Switch') { renderColorSwitch(); return; }
      if (name === 'Word Guess')   { renderWordGuess(); return; }
      return _origOpenGame4.apply(this, arguments);
    };
  }
})();
/* ============================================================
   TETRIS
   ============================================================ */
var TETRIS_SHAPES = {
  I: { color: '#00e5ff', cells: [[1,1,1,1]] },
  O: { color: '#ffcc00', cells: [[1,1],[1,1]] },
  T: { color: '#a855f7', cells: [[0,1,0],[1,1,1]] },
  S: { color: '#3ddc84', cells: [[0,1,1],[1,1,0]] },
  Z: { color: '#ff2d55', cells: [[1,1,0],[0,1,1]] },
  J: { color: '#1a88ff', cells: [[1,0,0],[1,1,1]] },
  L: { color: '#ff8800', cells: [[0,0,1],[1,1,1]] }
};
var TETRIS_KEYS = ['I','O','T','S','Z','J','L'];
var tetrisState = {
  board: [],
  current: null,
  currentX: 0,
  currentY: 0,
  next: null,
  score: 0,
  lines: 0,
  level: 1,
  best: parseInt(localStorage.getItem('tetrisBest') || '0', 10),
  running: false,
  dead: false,
  timer: null,
  speed: 500
};
function tetrisReset() {
  if (tetrisState.timer) { clearInterval(tetrisState.timer); tetrisState.timer = null; }
  tetrisState.board = [];
  for (var i = 0; i < 20; i++) {
    var row = [];
    for (var j = 0; j < 10; j++) row.push(0);
    tetrisState.board.push(row);
  }
  tetrisState.score = 0;
  tetrisState.lines = 0;
  tetrisState.level = 1;
  tetrisState.speed = 500;
  tetrisState.running = false;
  tetrisState.dead = false;
  tetrisState.next = tetrisRandomShape();
  tetrisSpawnPiece();
}
function tetrisRandomShape() {
  var key = TETRIS_KEYS[Math.floor(Math.random() * TETRIS_KEYS.length)];
  return { key: key, cells: TETRIS_SHAPES[key].cells.map(function(r){ return r.slice(); }), color: TETRIS_SHAPES[key].color };
}
function tetrisSpawnPiece() {
  if (!tetrisState.next) tetrisState.next = tetrisRandomShape();
  tetrisState.current = tetrisState.next;
  tetrisState.next = tetrisRandomShape();
  tetrisState.currentX = Math.floor((10 - tetrisState.current.cells[0].length) / 2);
  tetrisState.currentY = 0;
  if (tetrisCollide(tetrisState.current.cells, tetrisState.currentX, tetrisState.currentY)) {
    tetrisGameOver();
  }
}
function tetrisCollide(cells, ox, oy) {
  for (var r = 0; r < cells.length; r++) {
    for (var c = 0; c < cells[r].length; c++) {
      if (!cells[r][c]) continue;
      var bx = ox + c;
      var by = oy + r;
      if (bx < 0 || bx >= 10 || by >= 20) return true;
      if (by >= 0 && tetrisState.board[by][bx]) return true;
    }
  }
  return false;
}
function tetrisTick() {
  if (!tetrisState.running) return;
  if (!tetrisCollide(tetrisState.current.cells, tetrisState.currentX, tetrisState.currentY + 1)) {
    tetrisState.currentY++;
    tetrisRender();
  } else {
    tetrisLock();
  }
}
function tetrisLock() {
  var cells = tetrisState.current.cells;
  for (var r = 0; r < cells.length; r++) {
    for (var c = 0; c < cells[r].length; c++) {
      if (!cells[r][c]) continue;
      var bx = tetrisState.currentX + c;
      var by = tetrisState.currentY + r;
      if (by >= 0 && by < 20 && bx >= 0 && bx < 10) {
        tetrisState.board[by][bx] = tetrisState.current.color;
      }
    }
  }
  tetrisClearLines();
  tetrisSpawnPiece();
  tetrisRender();
}
function tetrisClearLines() {
  var cleared = 0;
  for (var r = 19; r >= 0; r--) {
    var full = true;
    for (var c = 0; c < 10; c++) {
      if (!tetrisState.board[r][c]) { full = false; break; }
    }
    if (full) {
      tetrisState.board.splice(r, 1);
      var newRow = [];
      for (var k = 0; k < 10; k++) newRow.push(0);
      tetrisState.board.unshift(newRow);
      cleared++;
      r++;
    }
  }
  if (cleared > 0) {
    tetrisState.lines += cleared;
    var points = [0, 100, 300, 500, 800];
    tetrisState.score += points[cleared] || 800;
    tetrisState.level = Math.floor(tetrisState.lines / 10) + 1;
    tetrisState.speed = Math.max(80, 500 - (tetrisState.level - 1) * 40);
    if (tetrisState.score > tetrisState.best) {
      tetrisState.best = tetrisState.score;
      localStorage.setItem('tetrisBest', String(tetrisState.best));
    }
    if (tetrisState.timer) {
      clearInterval(tetrisState.timer);
      tetrisState.timer = setInterval(tetrisTick, tetrisState.speed);
    }
  }
}
function tetrisGameOver() {
  tetrisState.running = false;
  tetrisState.dead = true;
  if (tetrisState.timer) { clearInterval(tetrisState.timer); tetrisState.timer = null; }
  if (tetrisState.score > tetrisState.best) {
    tetrisState.best = tetrisState.score;
    localStorage.setItem('tetrisBest', String(tetrisState.best));
  }
  var st = document.getElementById('tetrisStatus');
  if (st) st.textContent = 'GAME OVER - Final: ' + tetrisState.score;
  tetrisRender();
}
function tetrisRender() {
  var board = document.getElementById('tetrisBoard');
  if (board) {
    var h = '';
    for (var r = 0; r < 20; r++) {
      for (var c = 0; c < 10; c++) {
        var v = tetrisState.board[r][c];
        var active = false;
        var color = null;
        if (tetrisState.current) {
          var cells = tetrisState.current.cells;
          for (var cr = 0; cr < cells.length; cr++) {
            for (var cc = 0; cc < cells[cr].length; cc++) {
              if (!cells[cr][cc]) continue;
              if (tetrisState.currentY + cr === r && tetrisState.currentX + cc === c) {
                active = true;
                color = tetrisState.current.color;
              }
            }
          }
        }
        var cls = 'tetris-cell';
        var bg = '';
        if (active) {
          cls += ' filled';
          bg = color;
        } else if (v) {
          cls += ' filled';
          bg = v;
        }
        h += '<div class="' + cls + '"' + (bg ? ' style="background:' + bg + '"' : '') + '></div>';
      }
    }
    board.innerHTML = h;
  }
  var nextBoard = document.getElementById('tetrisNext');
  if (nextBoard && tetrisState.next) {
    var nh = '';
    for (var nr = 0; nr < 2; nr++) {
      for (var nc = 0; nc < 4; nc++) {
        var nv = (tetrisState.next.cells[nr] && tetrisState.next.cells[nr][nc]) ? tetrisState.next.color : null;
        nh += '<div class="tetris-next-cell' + (nv ? ' filled' : '') + '"' + (nv ? ' style="background:' + nv + '"' : '') + '></div>';
      }
    }
    nextBoard.innerHTML = nh;
  }
  var sc = document.getElementById('tetrisScore');
  if (sc) sc.textContent = 'SCORE: ' + tetrisState.score;
  var bst = document.getElementById('tetrisBest');
  if (bst) bst.textContent = 'BEST: ' + tetrisState.best;
  var ln = document.getElementById('tetrisLines');
  if (ln) ln.textContent = 'LINES: ' + tetrisState.lines;
  var lv = document.getElementById('tetrisLevel');
  if (lv) lv.textContent = 'LVL: ' + tetrisState.level;
}
function tetrisMove(dx) {
  if (!tetrisState.running) return;
  if (!tetrisCollide(tetrisState.current.cells, tetrisState.currentX + dx, tetrisState.currentY)) {
    tetrisState.currentX += dx;
    tetrisRender();
  }
}
function tetrisRotate() {
  if (!tetrisState.running) return;
  var cells = tetrisState.current.cells;
  var rows = cells.length;
  var cols = cells[0].length;
  var rotated = [];
  for (var c = 0; c < cols; c++) {
    var newRow = [];
    for (var r = rows - 1; r >= 0; r--) {
      newRow.push(cells[r][c]);
    }
    rotated.push(newRow);
  }
  if (!tetrisCollide(rotated, tetrisState.currentX, tetrisState.currentY)) {
    tetrisState.current.cells = rotated;
    tetrisRender();
  }
}
function tetrisSoftDrop() {
  if (!tetrisState.running) return;
  if (!tetrisCollide(tetrisState.current.cells, tetrisState.currentX, tetrisState.currentY + 1)) {
    tetrisState.currentY++;
    tetrisRender();
  }
}
function tetrisHardDrop() {
  if (!tetrisState.running) return;
  while (!tetrisCollide(tetrisState.current.cells, tetrisState.currentX, tetrisState.currentY + 1)) {
    tetrisState.currentY++;
  }
  tetrisLock();
}
function renderTetris() {
  tetrisReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 10px">Tetris</h2>';
  h += '<div class="game-score-row"><div class="game-score" id="tetrisScore">SCORE: 0</div><div class="game-best" id="tetrisBest">BEST: ' + tetrisState.best + '</div></div>';
  h += '<div class="game-status" id="tetrisStatus" style="margin-bottom:8px">Tap Start, use buttons to play</div>';
  h += '<div style="display:flex;justify-content:center;gap:12px;margin-bottom:8px;font-size:10px;color:rgba(255,255,255,0.6);font-weight:700">';
  h += '<span id="tetrisLines">LINES: 0</span><span id="tetrisLevel">LVL: 1</span>';
  h += '</div>';
  h += '<div class="tetris-wrap">';
  h += '<div class="tetris-board" id="tetrisBoard"></div>';
  h += '<div class="tetris-side">';
  h += '<div class="tetris-next-label">NEXT</div>';
  h += '<div class="tetris-next" id="tetrisNext"></div>';
  h += '</div>';
  h += '</div>';
  h += '<div class="tetris-controls">';
  h += '<button class="tetris-btn" id="tetrisLeft">L</button>';
  h += '<button class="tetris-btn" id="tetrisRot">ROT</button>';
  h += '<button class="tetris-btn" id="tetrisRight">R</button>';
  h += '<button class="tetris-btn" id="tetrisDrop">DOWN</button>';
  h += '<button class="tetris-btn" id="tetrisHard">DROP</button>';
  h += '</div>';
  h += '<button class="game-btn" id="tetrisStart" style="margin-top:8px">START</button>';
  appScreenContent.innerHTML = h;
  tetrisRender();
  document.getElementById('tetrisStart').onclick = function() {
    if (tetrisState.running) return;
    if (tetrisState.dead) {
      tetrisReset();
      tetrisRender();
    }
    tetrisState.running = true;
    var st = document.getElementById('tetrisStatus');
    if (st) st.textContent = 'Playing...';
    if (tetrisState.timer) clearInterval(tetrisState.timer);
    tetrisState.timer = setInterval(tetrisTick, tetrisState.speed);
  };
  document.getElementById('tetrisLeft').onclick = function(){ tetrisMove(-1); };
  document.getElementById('tetrisRight').onclick = function(){ tetrisMove(1); };
  document.getElementById('tetrisRot').onclick = tetrisRotate;
  document.getElementById('tetrisDrop').onclick = tetrisSoftDrop;
  document.getElementById('tetrisHard').onclick = tetrisHardDrop;
}
/* ============================================================
   ADD TETRIS TO FOLDER
   ============================================================ */
(function addTetris(){
  if (typeof ALL_GAMES !== 'undefined') {
    var exists = false;
    for (var j = 0; j < ALL_GAMES.length; j++) {
      if (ALL_GAMES[j][0] === 'Tetris') { exists = true; break; }
    }
    if (!exists) ALL_GAMES.push(['Tetris', 'T', '#ffcc00']);
  }
  var _origOpenGame5 = window.openGame;
  if (typeof _origOpenGame5 === 'function') {
    window.openGame = function(name){
      if (name === 'Tetris') { renderTetris(); return; }
      return _origOpenGame5.apply(this, arguments);
    };
  }
})();
/* ============================================================
   SUDOKU
   ============================================================ */
var sudokuState = {
  puzzle: [],
  solution: [],
  board: [],
  selected: null,
  best: parseInt(localStorage.getItem('sudokuBest') || '0', 10),
  wins: parseInt(localStorage.getItem('sudokuWins') || '0', 10),
  finished: false
};

var SUDOKU_PUZZLES = [
  {
    puzzle: [
      [5,3,0,0,7,0,0,0,0],
      [6,0,0,1,9,5,0,0,0],
      [0,9,8,0,0,0,0,6,0],
      [8,0,0,0,6,0,0,0,3],
      [4,0,0,8,0,3,0,0,1],
      [7,0,0,0,2,0,0,0,6],
      [0,6,0,0,0,0,2,8,0],
      [0,0,0,4,1,9,0,0,5],
      [0,0,0,0,8,0,0,7,9]
    ],
    solution: [
      [5,3,4,6,7,8,9,1,2],
      [6,7,2,1,9,5,3,4,8],
      [1,9,8,3,4,2,5,6,7],
      [8,5,9,7,6,1,4,2,3],
      [4,2,6,8,5,3,7,9,1],
      [7,1,3,9,2,4,8,5,6],
      [9,6,1,5,3,7,2,8,4],
      [2,8,7,4,1,9,6,3,5],
      [3,4,5,2,8,6,1,7,9]
    ]
  },
  {
    puzzle: [
      [0,0,0,2,6,0,7,0,1],
      [6,8,0,0,7,0,0,9,0],
      [1,9,0,0,0,4,5,0,0],
      [8,2,0,1,0,0,0,4,0],
      [0,0,4,6,0,2,9,0,0],
      [0,5,0,0,0,3,0,2,8],
      [0,0,9,3,0,0,0,7,4],
      [0,4,0,0,5,0,0,3,6],
      [7,0,3,0,1,8,0,0,0]
    ],
    solution: [
      [4,3,5,2,6,9,7,8,1],
      [6,8,2,5,7,1,4,9,3],
      [1,9,7,8,3,4,5,6,2],
      [8,2,6,1,9,5,3,4,7],
      [3,7,4,6,8,2,9,1,5],
      [9,5,1,7,4,3,6,2,8],
      [5,1,9,3,2,6,8,7,4],
      [2,4,8,9,5,7,1,3,6],
      [7,6,3,4,1,8,2,5,9]
    ]
  }
];

function sudokuReset() {
  var pick = SUDOKU_PUZZLES[Math.floor(Math.random() * SUDOKU_PUZZLES.length)];
  sudokuState.puzzle = pick.puzzle.map(function(r){ return r.slice(); });
  sudokuState.solution = pick.solution.map(function(r){ return r.slice(); });
  sudokuState.board = pick.puzzle.map(function(r){ return r.slice(); });
  sudokuState.selected = null;
  sudokuState.finished = false;
}

function sudokuRender() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Sudoku</h2>';
  h += '<div class="game-status" id="sudokuStatus" style="margin-bottom:10px">' + (sudokuState.finished ? 'SOLVED! Great job!' : 'Tap empty cell, then number') + '</div>';
  h += '<div class="sudoku-board" id="sudokuBoard">';
  for (var r = 0; r < 9; r++) {
    for (var c = 0; c < 9; c++) {
      var v = sudokuState.board[r][c];
      var fixed = sudokuState.puzzle[r][c] !== 0;
      var cls = 'sudoku-cell';
      if (fixed) cls += ' fixed';
      if (sudokuState.selected && sudokuState.selected.r === r && sudokuState.selected.c === c) cls += ' selected';
      if (!fixed && v !== 0 && v !== sudokuState.solution[r][c]) cls += ' error';
      if (c === 2 || c === 5) cls += ' thick-r';
      if (r === 2 || r === 5) cls += ' thick-b';
      h += '<button class="' + cls + '" data-sr="' + r + '" data-sc="' + c + '">' + (v === 0 ? '' : v) + '</button>';
    }
  }
  h += '</div>';
  h += '<div class="sudoku-numpad">';
  for (var n = 1; n <= 9; n++) {
    h += '<button class="sudoku-num" data-sn="' + n + '">' + n + '</button>';
  }
  h += '<button class="sudoku-num erase" data-sn="0">X</button>';
  h += '</div>';
  h += '<div style="display:flex;gap:10px;justify-content:center;margin-top:6px">';
  h += '<button class="game-btn" id="sudokuNew" style="background:rgba(255,255,255,0.1);color:#fff">NEW GAME</button>';
  h += '<button class="game-btn" id="sudokuCheck" style="background:rgba(0,229,255,0.2);color:#00e5ff">CHECK</button>';
  h += '</div>';
  appScreenContent.innerHTML = h;

  var cells = appScreenContent.querySelectorAll('.sudoku-cell');
  for (var i = 0; i < cells.length; i++) {
    cells[i].onclick = (function(el){
      return function(){
        var r = parseInt(el.getAttribute('data-sr'), 10);
        var c = parseInt(el.getAttribute('data-sc'), 10);
        if (sudokuState.puzzle[r][c] !== 0) return;
        sudokuState.selected = { r: r, c: c };
        sudokuRender();
      };
    })(cells[i]);
  }
  var nums = appScreenContent.querySelectorAll('[data-sn]');
  for (var j = 0; j < nums.length; j++) {
    nums[j].onclick = (function(el){
      return function(){
        sudokuSetNumber(parseInt(el.getAttribute('data-sn'), 10));
      };
    })(nums[j]);
  }
  document.getElementById('sudokuNew').onclick = function(){ sudokuReset(); sudokuRender(); };
  document.getElementById('sudokuCheck').onclick = sudokuCheck;
}

function sudokuSetNumber(n) {
  if (sudokuState.finished) return;
  if (!sudokuState.selected) {
    var st = document.getElementById('sudokuStatus');
    if (st) st.textContent = 'Tap a cell first';
    setTimeout(function(){ if (st && !sudokuState.finished) st.textContent = 'Tap empty cell, then number'; }, 1000);
    return;
  }
  var r = sudokuState.selected.r;
  var c = sudokuState.selected.c;
  sudokuState.board[r][c] = n;
  sudokuRender();
  sudokuCheckWin();
}

function sudokuCheck() {
  for (var r = 0; r < 9; r++) {
    for (var c = 0; c < 9; c++) {
      if (sudokuState.board[r][c] !== sudokuState.solution[r][c]) {
        var st = document.getElementById('sudokuStatus');
        if (st) st.textContent = 'Not solved yet - keep going';
        setTimeout(function(){ if (st && !sudokuState.finished) st.textContent = 'Tap empty cell, then number'; }, 1500);
        return;
      }
    }
  }
  sudokuCheckWin();
}

function sudokuCheckWin() {
  for (var r = 0; r < 9; r++) {
    for (var c = 0; c < 9; c++) {
      if (sudokuState.board[r][c] !== sudokuState.solution[r][c]) return;
    }
  }
  sudokuState.finished = true;
  sudokuState.wins++;
  localStorage.setItem('sudokuWins', String(sudokuState.wins));
  sudokuRender();
  var st = document.getElementById('sudokuStatus');
  if (st) st.textContent = 'SOLVED! You have won ' + sudokuState.wins + ' games';
}

function renderSudoku() {
  sudokuReset();
  sudokuRender();
}
/* ============================================================
   ADD SUDOKU TO FOLDER
   ============================================================ */
(function addSudoku(){
  if (typeof ALL_GAMES !== 'undefined') {
    var exists = false;
    for (var j = 0; j < ALL_GAMES.length; j++) {
      if (ALL_GAMES[j][0] === 'Sudoku') { exists = true; break; }
    }
    if (!exists) ALL_GAMES.push(['Sudoku', 'N', '#00e5ff']);
  }
  var _origOpenGame6 = window.openGame;
  if (typeof _origOpenGame6 === 'function') {
    window.openGame = function(name){
      if (name === 'Sudoku') { renderSudoku(); return; }
      return _origOpenGame6.apply(this, arguments);
    };
  }
})();
/* ============================================================
   CHECKERS
   ============================================================ */
var checkersState = {
  board: [],
  selected: null,
  turn: 'red',
  redCount: 12,
  blackCount: 12,
  running: false,
  dead: false,
  winner: null,
  aiTimer: null
};
function checkersReset() {
  if (checkersState.aiTimer) { clearTimeout(checkersState.aiTimer); checkersState.aiTimer = null; }
  checkersState.board = [];
  for (var r = 0; r < 8; r++) {
    var row = [];
    for (var c = 0; c < 8; c++) row.push(null);
    checkersState.board.push(row);
  }
  for (var r2 = 0; r2 < 3; r2++) {
    for (var c2 = 0; c2 < 8; c2++) {
      if ((r2 + c2) % 2 === 1) checkersState.board[r2][c2] = { color: 'black', king: false };
    }
  }
  for (var r3 = 5; r3 < 8; r3++) {
    for (var c3 = 0; c3 < 8; c3++) {
      if ((r3 + c3) % 2 === 1) checkersState.board[r3][c3] = { color: 'red', king: false };
    }
  }
  checkersState.selected = null;
  checkersState.turn = 'red';
  checkersState.redCount = 12;
  checkersState.blackCount = 12;
  checkersState.running = true;
  checkersState.dead = false;
  checkersState.winner = null;
}
function checkersInBounds(r, c) {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}
function checkersGetMoves(r, c) {
  var piece = checkersState.board[r][c];
  if (!piece) return [];
  var moves = [];
  var dirs = [];
  if (piece.king) {
    dirs = [[-1,-1],[-1,1],[1,-1],[1,1]];
  } else if (piece.color === 'red') {
    dirs = [[-1,-1],[-1,1]];
  } else {
    dirs = [[1,-1],[1,1]];
  }
  for (var i = 0; i < dirs.length; i++) {
    var dr = dirs[i][0];
    var dc = dirs[i][1];
    var nr = r + dr;
    var nc = c + dc;
    if (checkersInBounds(nr, nc) && !checkersState.board[nr][nc]) {
      moves.push({ r: nr, c: nc, jump: false });
    }
    var jr = r + dr * 2;
    var jc = c + dc * 2;
    if (checkersInBounds(jr, jc) && !checkersState.board[jr][jc]) {
      var mid = checkersState.board[nr][nc];
      if (mid && mid.color !== piece.color) {
        moves.push({ r: jr, c: jc, jump: true, capturedR: nr, capturedC: nc });
      }
    }
  }
  return moves;
}
function checkersSelect(r, c) {
  if (!checkersState.running || checkersState.turn !== 'red') return;
  var piece = checkersState.board[r][c];
  if (!piece || piece.color !== 'red') {
    checkersState.selected = null;
    checkersRender();
    return;
  }
  checkersState.selected = { r: r, c: c };
  checkersRender();
}
function checkersTryMove(r, c) {
  if (!checkersState.running || checkersState.turn !== 'red') return;
  if (!checkersState.selected) return;
  var sr = checkersState.selected.r;
  var sc = checkersState.selected.c;
  var moves = checkersGetMoves(sr, sc);
  for (var i = 0; i < moves.length; i++) {
    var m = moves[i];
    if (m.r === r && m.c === c) {
      checkersMove(sr, sc, m);
      return;
    }
  }
  checkersSelect(r, c);
}
function checkersMove(sr, sc, m) {
  var piece = checkersState.board[sr][sc];
  checkersState.board[m.r][m.c] = piece;
  checkersState.board[sr][sc] = null;
  if (m.jump) {
    checkersState.board[m.capturedR][m.capturedC] = null;
    if (piece.color === 'red') checkersState.blackCount--;
    else checkersState.redCount--;
  }
  if (piece.color === 'red' && m.r === 0) piece.king = true;
  if (piece.color === 'black' && m.r === 7) piece.king = true;
  checkersState.selected = null;
  if (checkersState.redCount === 0 || checkersState.blackCount === 0) {
    checkersState.running = false;
    checkersState.dead = true;
    checkersState.winner = checkersState.redCount > 0 ? 'red' : 'black';
    checkersRender();
    return;
  }
  checkersState.turn = 'black';
  checkersRender();
  checkersState.aiTimer = setTimeout(checkersAiMove, 700);
}
function checkersAiMove() {
  if (!checkersState.running) return;
  var allMoves = [];
  var jumps = [];
  for (var r = 0; r < 8; r++) {
    for (var c = 0; c < 8; c++) {
      var piece = checkersState.board[r][c];
      if (!piece || piece.color !== 'black') continue;
      var moves = checkersGetMoves(r, c);
      for (var i = 0; i < moves.length; i++) {
        var m = moves[i];
        m.fromR = r;
        m.fromC = c;
        allMoves.push(m);
        if (m.jump) jumps.push(m);
      }
    }
  }
  if (allMoves.length === 0) {
    checkersState.running = false;
    checkersState.dead = true;
    checkersState.winner = 'red';
    checkersRender();
    return;
  }
  var pool = jumps.length > 0 ? jumps : allMoves;
  var chosen = pool[Math.floor(Math.random() * pool.length)];
  checkersMove(chosen.fromR, chosen.fromC, chosen);
  if (checkersState.running) checkersState.turn = 'red';
  checkersRender();
}
function checkersRender() {
  var board = document.getElementById('checkersBoard');
  if (!board) return;
  var h = '';
  var selectedMoves = [];
  if (checkersState.selected) {
    selectedMoves = checkersGetMoves(checkersState.selected.r, checkersState.selected.c);
  }
  for (var r = 0; r < 8; r++) {
    for (var c = 0; c < 8; c++) {
      var isDark = (r + c) % 2 === 1;
      var cls = 'checkers-cell ' + (isDark ? 'dark' : 'light');
      if (checkersState.selected && checkersState.selected.r === r && checkersState.selected.c === c) {
        cls += ' highlight';
      }
      var piece = checkersState.board[r][c];
      var isMove = false;
      for (var m = 0; m < selectedMoves.length; m++) {
        if (selectedMoves[m].r === r && selectedMoves[m].c === c) { isMove = true; break; }
      }
      if (isMove) cls += ' highlight';
      h += '<div class="' + cls + '" data-cr="' + r + '" data-cc="' + c + '">';
      if (piece) {
        var pcls = 'checkers-piece ' + piece.color + (piece.king ? ' king' : '');
        h += '<div class="' + pcls + '">' + (piece.king ? '' : '') + '</div>';
      }
      h += '</div>';
    }
  }
  board.innerHTML = h;
  var info = document.getElementById('checkersInfo');
  if (info) {
    if (checkersState.winner) {
      info.textContent = (checkersState.winner === 'red' ? 'YOU WIN!' : 'CPU WINS');
    } else if (checkersState.turn === 'red') {
      info.textContent = 'Your turn - tap a red piece';
    } else {
      info.textContent = 'CPU thinking...';
    }
  }
  var rs = document.getElementById('checkersRed');
  if (rs) rs.textContent = 'YOU: ' + checkersState.redCount;
  var bs = document.getElementById('checkersBlack');
  if (bs) bs.textContent = 'CPU: ' + checkersState.blackCount;
  var cells = board.querySelectorAll('.checkers-cell');
  for (var k = 0; k < cells.length; k++) {
    cells[k].onclick = (function(el){
      return function(){
        var r = parseInt(el.getAttribute('data-cr'), 10);
        var c = parseInt(el.getAttribute('data-cc'), 10);
        if (checkersState.selected) {
          var moves = checkersGetMoves(checkersState.selected.r, checkersState.selected.c);
          for (var i = 0; i < moves.length; i++) {
            if (moves[i].r === r && moves[i].c === c) {
              checkersTryMove(r, c);
              return;
            }
          }
        }
        checkersSelect(r, c);
      };
    })(cells[k]);
  }
}
function renderCheckers() {
  checkersReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Checkers</h2>';
  h += '<div class="checkers-score-row"><div class="checkers-red" id="checkersRed">YOU: 12</div><div class="checkers-black" id="checkersBlack">CPU: 12</div></div>';
  h += '<div class="checkers-info" id="checkersInfo">Your turn - tap a red piece</div>';
  h += '<div class="checkers-board" id="checkersBoard"></div>';
  h += '<button class="game-btn" id="checkersNew" style="margin-top:12px">NEW GAME</button>';
  appScreenContent.innerHTML = h;
  checkersRender();
  document.getElementById('checkersNew').onclick = function() {
    checkersReset();
    checkersRender();
  };
}
/* ============================================================
   ADD CHECKERS TO FOLDER
   ============================================================ */
(function addCheckers(){
  if (typeof ALL_GAMES !== 'undefined') {
    var exists = false;
    for (var j = 0; j < ALL_GAMES.length; j++) {
      if (ALL_GAMES[j][0] === 'Checkers') { exists = true; break; }
    }
    if (!exists) ALL_GAMES.push(['Checkers', 'C', '#ff2d55']);
  }
  var _origOpenGame7 = window.openGame;
  if (typeof _origOpenGame7 === 'function') {
    window.openGame = function(name){
      if (name === 'Checkers') { renderCheckers(); return; }
      return _origOpenGame7.apply(this, arguments);
    };
  }
})();
/* ============================================================
   CORRECT IPHONE BACK IMAGES MAPPING
   ============================================================ */
IPHONE_BACKS = {
  'iPhone 7':           'https://i.postimg.cc/635DgsWG/IMG-20260918-154523-368.png',
  'iPhone X':           'https://i.postimg.cc/d1tzpMsy/IMG-20260918-154448-884.png',
  'iPhone XR':          'https://i.postimg.cc/XJ7TmMjr/IMG-20260918-154507-439.png',
  'iPhone 11':          'https://i.postimg.cc/SKGBgQh6/IMG-20260918-161424-228.png',
  'iPhone 13 Pro Max':  'https://i.postimg.cc/ZRK12kb9/IMG-20260918-161753-924.png',
  'iPhone 14':          'https://i.postimg.cc/QMq2fN3F/IMG-20260918-162529-961.png',
  'iPhone 15 Pro Max':  'https://i.postimg.cc/NMfWShsT/IMG-20260918-154422-912.png',
  'iPhone 16':          'https://i.postimg.cc/SsNw30SC/IMG-20260918-154406-083.png',
  'iPhone 16e':         'https://i.postimg.cc/pTXg4NWJ/IMG-20260918-154145-993.png',
  'iPhone 17e':         'https://i.postimg.cc/85Pq98pB/IMG-20260918-154305-101.png',
  'iPhone 17 Pro Max':  'https://i.postimg.cc/cH4V2qxR/IMG-20260918-154330-469.png'
};
/* ============================================================
   MY PHONES - CORRECT IMAGES
   ============================================================ */
window.renderMyPhones = function() {
  var saved = getSavedPhones();
  if (saved.length === 0) {
    myPhonesList.innerHTML = '<div class="empty-state">No saved phones yet.<br>Spin and tap + to save one.</div>';
    return;
  }
  var h = '';
  for (var i = 0; i < saved.length; i++) {
    var p = saved[i];
    var img = '';
    var model = p.model;
    if (p.brand === 'iphone') {
      if (model === 'iPhone 7') img = 'https://i.postimg.cc/635DgsWG/IMG-20260918-154523-368.png';
      else if (model === 'iPhone X') img = 'https://i.postimg.cc/d1tzpMsy/IMG-20260918-154448-884.png';
      else if (model === 'iPhone XR') img = 'https://i.postimg.cc/XJ7TmMjr/IMG-20260918-154507-439.png';
      else if (model === 'iPhone 11') img = 'https://i.postimg.cc/SKGBgQh6/IMG-20260918-161424-228.png';
      else if (model === 'iPhone 13 Pro Max') img = 'https://i.postimg.cc/ZRK12kb9/IMG-20260918-161753-924.png';
      else if (model === 'iPhone 14') img = 'https://i.postimg.cc/QMq2fN3F/IMG-20260918-162529-961.png';
      else if (model === 'iPhone 15 Pro Max') img = 'https://i.postimg.cc/NMfWShsT/IMG-20260918-154422-912.png';
      else if (model === 'iPhone 16') img = 'https://i.postimg.cc/SsNw30SC/IMG-20260918-154406-083.png';
      else if (model === 'iPhone 16e') img = 'https://i.postimg.cc/pTXg4NWJ/IMG-20260918-154145-993.png';
      else if (model === 'iPhone 17e') img = 'https://i.postimg.cc/85Pq98pB/IMG-20260918-154305-101.png';
      else if (model === 'iPhone 17 Pro Max') img = 'https://i.postimg.cc/cH4V2qxR/IMG-20260918-154330-469.png';
    } else {
      if (model === 'Samsung Galaxy S26 Ultra') img = 'https://i.postimg.cc/RZCgCCBZ/IMG-20260918-144810-157.png';
      else if (model === 'Samsung Galaxy S25') img = 'https://i.postimg.cc/8zkZkkSj/IMG-20260918-144852-814.png';
      else if (model === 'Samsung Galaxy S24') img = 'https://i.postimg.cc/9QXLXXhM/IMG-20260918-144924-747.png';
      else if (model === 'Google Pixel 9 Pro') img = 'https://i.postimg.cc/x1j6jj2q/IMG-20260918-144956-273.png';
      else if (model === 'Google Pixel 8') img = 'https://i.postimg.cc/QdNfNN3C/IMG-20260918-145022-600.png';
      else if (model === 'OnePlus 12') img = 'https://i.postimg.cc/Nj5QnH0J/IMG-20260918-151718-442.png';
      else if (model === 'Xiaomi 14 Ultra') img = 'https://i.postimg.cc/K8RmWMY0/IMG-20260918-151748-315.png';
      else if (model === 'Nothing Phone 2') img = 'https://i.postimg.cc/t4Y9cxgk/IMG-20260918-151836-069.png';
      else if (model === 'Infinix Zero 30') img = 'https://i.postimg.cc/Nj5QnH04/IMG-20260918-151912-113.png';
      else if (model === 'Infinix Note 40 Pro') img = 'https://i.postimg.cc/jSLR17jz/IMG-20260918-151933-378.png';
      else if (model === 'Tecno Camon 30') img = 'https://i.postimg.cc/526frCtq/IMG-20260918-151957-164.png';
      else if (model === 'Tecno Spark 20 Pro') img = 'https://i.postimg.cc/6pyBPvQr/IMG-20260918-152021-476.png';
      else if (model === 'itel P55') img = 'https://i.postimg.cc/L6yHvTmQ/IMG-20260918-152057-749.png';
      else if (model === 'itel A70') img = 'https://i.postimg.cc/J4T1KqRT/IMG-20260918-152131-608.png';
    }
    h += '<div class="saved-phone-card" data-index="' + i + '">';
    h += '<img src="' + img + '" alt="">';
    h += '<div class="saved-phone-name">' + escapeHtml(p.model) + '</div>';
    h += '<div class="saved-phone-number">' + escapeHtml(p.number) + '</div>';
    h += '</div>';
  }
  myPhonesList.innerHTML = h;
  myPhonesList.querySelectorAll('.saved-phone-card').forEach(function(card) {
    card.addEventListener('click', function() {
      var idx = parseInt(card.getAttribute('data-index'), 10);
      var p = getSavedPhones()[idx];
      if (!p) return;
      myPhonesScreen.classList.add('hidden');
      openPhoneViewer(p.model, p.brand, p.number);
    });
  });
};
/* ============================================================
   REMOVE STRAY \n TEXT FROM SCREEN
   ============================================================ */
(function removeStrayNewlines(){
  function cleanNode(node) {
    if (node.nodeType === 3) {
      if (node.nodeValue && node.nodeValue.indexOf('\\n') !== -1) {
        node.nodeValue = node.nodeValue.replace(/\\n/g, '');
      }
    } else if (node.nodeType === 1) {
      for (var i = 0; i < node.childNodes.length; i++) {
        cleanNode(node.childNodes[i]);
      }
    }
  }
  function runClean() {
    var body = document.body;
    if (body) cleanNode(body);
  }
  setInterval(runClean, 500);
})();
/* ============================================================
   PHONE CARD SHAPES
   ============================================================ */
window.renderMyPhones = function() {
  var saved = getSavedPhones();
  if (saved.length === 0) {
    myPhonesList.innerHTML = '<div class="empty-state">No saved phones yet.<br>Spin and tap + to save one.</div>';
    return;
  }
  var h = '';
  for (var i = 0; i < saved.length; i++) {
    var p = saved[i];
    var model = p.model;
    var img = '';
    var shape = 'other';
    if (p.brand === 'iphone') {
      shape = 'iphone';
      if (model === 'iPhone 7') img = 'https://i.postimg.cc/635DgsWG/IMG-20260918-154523-368.png';
      else if (model === 'iPhone X') img = 'https://i.postimg.cc/d1tzpMsy/IMG-20260918-154448-884.png';
      else if (model === 'iPhone XR') img = 'https://i.postimg.cc/XJ7TmMjr/IMG-20260918-154507-439.png';
      else if (model === 'iPhone 11') img = 'https://i.postimg.cc/SKGBgQh6/IMG-20260918-161424-228.png';
      else if (model === 'iPhone 13 Pro Max') img = 'https://i.postimg.cc/ZRK12kb9/IMG-20260918-161753-924.png';
      else if (model === 'iPhone 14') img = 'https://i.postimg.cc/QMq2fN3F/IMG-20260918-162529-961.png';
      else if (model === 'iPhone 15 Pro Max') img = 'https://i.postimg.cc/NMfWShsT/IMG-20260918-154422-912.png';
      else if (model === 'iPhone 16') img = 'https://i.postimg.cc/SsNw30SC/IMG-20260918-154406-083.png';
      else if (model === 'iPhone 16e') img = 'https://i.postimg.cc/pTXg4NWJ/IMG-20260918-154145-993.png';
      else if (model === 'iPhone 17e') img = 'https://i.postimg.cc/85Pq98pB/IMG-20260918-154305-101.png';
      else if (model === 'iPhone 17 Pro Max') img = 'https://i.postimg.cc/cH4V2qxR/IMG-20260918-154330-469.png';
    } else {
      if (model.indexOf('Samsung') === 0) shape = 'samsung';
      else if (model.indexOf('Pixel') !== -1) shape = 'pixel';
      if (model === 'Samsung Galaxy S26 Ultra') img = 'https://i.postimg.cc/RZCgCCBZ/IMG-20260918-144810-157.png';
      else if (model === 'Samsung Galaxy S25') img = 'https://i.postimg.cc/8zkZkkSj/IMG-20260918-144852-814.png';
      else if (model === 'Samsung Galaxy S24') img = 'https://i.postimg.cc/9QXLXXhM/IMG-20260918-144924-747.png';
      else if (model === 'Google Pixel 9 Pro') img = 'https://i.postimg.cc/x1j6jj2q/IMG-20260918-144956-273.png';
      else if (model === 'Google Pixel 8') img = 'https://i.postimg.cc/QdNfNN3C/IMG-20260918-145022-600.png';
      else if (model === 'OnePlus 12') img = 'https://i.postimg.cc/Nj5QnH0J/IMG-20260918-151718-442.png';
      else if (model === 'Xiaomi 14 Ultra') img = 'https://i.postimg.cc/K8RmWMY0/IMG-20260918-151748-315.png';
      else if (model === 'Nothing Phone 2') img = 'https://i.postimg.cc/t4Y9cxgk/IMG-20260918-151836-069.png';
      else if (model === 'Infinix Zero 30') img = 'https://i.postimg.cc/Nj5QnH04/IMG-20260918-151912-113.png';
      else if (model === 'Infinix Note 40 Pro') img = 'https://i.postimg.cc/jSLR17jz/IMG-20260918-151933-378.png';
      else if (model === 'Tecno Camon 30') img = 'https://i.postimg.cc/526frCtq/IMG-20260918-151957-164.png';
      else if (model === 'Tecno Spark 20 Pro') img = 'https://i.postimg.cc/6pyBPvQr/IMG-20260918-152021-476.png';
      else if (model === 'itel P55') img = 'https://i.postimg.cc/L6yHvTmQ/IMG-20260918-152057-749.png';
      else if (model === 'itel A70') img = 'https://i.postimg.cc/J4T1KqRT/IMG-20260918-152131-608.png';
    }
    h += '<div class="saved-phone-card" data-index="' + i + '">';
    h += '<img src="' + img + '" class="' + shape + '" alt="">';
    h += '<div class="saved-phone-name">' + escapeHtml(p.model) + '</div>';
    h += '<div class="saved-phone-number">' + escapeHtml(p.number) + '</div>';
    h += '</div>';
  }
  myPhonesList.innerHTML = h;
  myPhonesList.querySelectorAll('.saved-phone-card').forEach(function(card) {
    card.addEventListener('click', function() {
      var idx = parseInt(card.getAttribute('data-index'), 10);
      var p = getSavedPhones()[idx];
      if (!p) return;
      myPhonesScreen.classList.add('hidden');
      openPhoneViewer(p.model, p.brand, p.number);
    });
  });
};

/* ============================================================
   SPIN RESET - 3 SPINS EVERY 24 HOURS
   ============================================================ */
(function dailySpinSystem(){
  var RESET_MS = 24 * 60 * 60 * 1000; // 24 hours

  window.spinsRemaining = function() {
    var now = Date.now();
    var lastReset = parseInt(localStorage.getItem('spinLastReset') || '0', 10);
    if (lastReset === 0 || now - lastReset >= RESET_MS) {
      localStorage.setItem('spinLastReset', String(now));
      localStorage.setItem('spinsUsedThisWindow', '0');
      return 3;
    }
    var used = parseInt(localStorage.getItem('spinsUsedThisWindow') || '0', 10);
    return Math.max(0, 3 - used);
  };

  window.recordSpin = function() {
    var used = parseInt(localStorage.getItem('spinsUsedThisWindow') || '0', 10);
    localStorage.setItem('spinsUsedThisWindow', String(used + 1));
    updateSpinCounter();
  };

  window.updateSpinCounter = function() {
    var now = Date.now();
    var lastReset = parseInt(localStorage.getItem('spinLastReset') || '0', 10);
    var elapsed = now - lastReset;

    if (lastReset === 0 || elapsed >= RESET_MS) {
      localStorage.setItem('spinLastReset', String(now));
      localStorage.setItem('spinsUsedThisWindow', '0');
      var el0 = document.getElementById('spinCounter');
      if (el0) el0.textContent = 'Spins left today: 3';
      var sb0 = document.getElementById('spinBtn');
      if (sb0) { sb0.disabled = false; sb0.textContent = 'SPIN'; }
      return;
    }

    var used = parseInt(localStorage.getItem('spinsUsedThisWindow') || '0', 10);
    var remaining = Math.max(0, 3 - used);

    var el = document.getElementById('spinCounter');
    var sb = document.getElementById('spinBtn');

    if (remaining === 0) {
      var left = RESET_MS - elapsed;
      var hrs = Math.floor(left / 3600000);
      var mins = Math.floor((left % 3600000) / 60000);
      var secs = Math.floor((left % 60000) / 1000);
      var timeStr = hrs + 'h ' + mins + 'm ' + (secs < 10 ? '0' : '') + secs + 's';
      if (el) el.textContent = 'New spins in ' + timeStr;
      if (sb) { sb.disabled = true; sb.textContent = 'COME BACK LATER'; }
    } else {
      if (el) el.textContent = 'Spins left today: ' + remaining;
      if (sb) { sb.disabled = false; sb.textContent = 'SPIN'; }
    }
  };

  setInterval(window.updateSpinCounter, 1000);
  window.updateSpinCounter();
})();
/* ============================================================
   CONNECT 4 (iPhone only)
   ============================================================ */
var c4State = {
  board: [],
  turn: 'red',
  running: false,
  finished: false,
  winner: null,
  wins: parseInt(localStorage.getItem('c4Wins') || '0', 10),
  losses: parseInt(localStorage.getItem('c4Losses') || '0', 10),
  aiTimer: null
};
function c4Reset() {
  if (c4State.aiTimer) { clearTimeout(c4State.aiTimer); c4State.aiTimer = null; }
  c4State.board = [];
  for (var r = 0; r < 6; r++) {
    var row = [];
    for (var c = 0; c < 7; c++) row.push(null);
    c4State.board.push(row);
  }
  c4State.turn = 'red';
  c4State.running = true;
  c4State.finished = false;
  c4State.winner = null;
}
function c4Drop(col) {
  if (!c4State.running || c4State.finished) return;
  if (c4State.turn !== 'red') return;
  for (var r = 5; r >= 0; r--) {
    if (!c4State.board[r][col]) {
      c4State.board[r][col] = 'red';
      var w = c4CheckWin(r, col, 'red');
      if (w) { c4End('red'); return; }
      if (c4IsFull()) { c4End('draw'); return; }
      c4State.turn = 'yellow';
      c4Render();
      c4State.aiTimer = setTimeout(c4AiMove, 600);
      return;
    }
  }
}
function c4IsFull() {
  for (var r = 0; r < 6; r++) {
    for (var c = 0; c < 7; c++) {
      if (!c4State.board[r][c]) return false;
    }
  }
  return true;
}
function c4CheckWin(r, c, color) {
  var dirs = [[0,1],[1,0],[1,1],[1,-1]];
  for (var d = 0; d < 4; d++) {
    var count = 1;
    for (var s = 1; s < 4; s++) {
      var nr = r + dirs[d][0] * s;
      var nc = c + dirs[d][1] * s;
      if (nr < 0 || nr >= 6 || nc < 0 || nc >= 7) break;
      if (c4State.board[nr][nc] !== color) break;
      count++;
    }
    for (var s2 = 1; s2 < 4; s2++) {
      var nr2 = r - dirs[d][0] * s2;
      var nc2 = c - dirs[d][1] * s2;
      if (nr2 < 0 || nr2 >= 6 || nc2 < 0 || nc2 >= 7) break;
      if (c4State.board[nr2][nc2] !== color) break;
      count++;
    }
    if (count >= 4) return true;
  }
  return false;
}
function c4AiMove() {
  if (!c4State.running || c4State.finished) return;
  if (c4State.turn !== 'yellow') return;
  var col = c4PickColumn();
  for (var r = 5; r >= 0; r--) {
    if (!c4State.board[r][col]) {
      c4State.board[r][col] = 'yellow';
      var w = c4CheckWin(r, col, 'yellow');
      if (w) { c4End('yellow'); return; }
      if (c4IsFull()) { c4End('draw'); return; }
      c4State.turn = 'red';
      c4Render();
      return;
    }
  }
  for (var cc = 0; cc < 7; cc++) {
    for (var rr = 5; rr >= 0; rr--) {
      if (!c4State.board[rr][cc]) {
        c4State.board[rr][cc] = 'yellow';
        var w2 = c4CheckWin(rr, cc, 'yellow');
        if (w2) { c4End('yellow'); return; }
        c4State.board[rr][cc] = null;
        break;
      }
    }
  }
  c4State.turn = 'red';
  c4Render();
}
function c4PickColumn() {
  var valid = [];
  for (var c = 0; c < 7; c++) {
    if (!c4State.board[0][c]) valid.push(c);
  }
  if (valid.length === 0) return 3;
  var check = function(col, color) {
    for (var r = 5; r >= 0; r--) {
      if (!c4State.board[r][col]) {
        c4State.board[r][col] = color;
        var w = c4CheckWin(r, col, color);
        c4State.board[r][col] = null;
        return w;
      }
    }
    return false;
  };
  for (var i = 0; i < valid.length; i++) {
    if (check(valid[i], 'yellow')) return valid[i];
  }
  for (var j = 0; j < valid.length; j++) {
    if (check(valid[j], 'red')) return valid[j];
  }
  var mid = [3,2,4,1,5,0,6];
  for (var k = 0; k < mid.length; k++) {
    if (valid.indexOf(mid[k]) !== -1) return mid[k];
  }
  return valid[Math.floor(Math.random() * valid.length)];
}
function c4End(winner) {
  c4State.running = false;
  c4State.finished = true;
  c4State.winner = winner;
  if (winner === 'red') {
    c4State.wins++;
    localStorage.setItem('c4Wins', String(c4State.wins));
  } else if (winner === 'yellow') {
    c4State.losses++;
    localStorage.setItem('c4Losses', String(c4State.losses));
  }
  c4Render();
}
function c4Render() {
  var board = document.getElementById('c4Board');
  if (!board) return;
  var h = '';
  for (var r = 0; r < 6; r++) {
    for (var c = 0; c < 7; c++) {
      var v = c4State.board[r][c];
      var cls = 'c4-cell';
      if (v) cls += ' ' + v;
      h += '<div class="' + cls + '" data-c4="' + c + '"></div>';
    }
  }
  board.innerHTML = h;
  var cells = board.querySelectorAll('.c4-cell');
  for (var i = 0; i < cells.length; i++) {
    cells[i].onclick = (function(el){
      return function(){ c4Drop(parseInt(el.getAttribute('data-c4'), 10)); };
    })(cells[i]);
  }
  var info = document.getElementById('c4Info');
  if (info) {
    if (c4State.winner === 'red') info.textContent = 'YOU WIN!';
    else if (c4State.winner === 'yellow') info.textContent = 'CPU WINS';
    else if (c4State.winner === 'draw') info.textContent = 'DRAW';
    else if (c4State.turn === 'red') info.textContent = 'Your turn - tap a column';
    else info.textContent = 'CPU thinking...';
  }
  var y = document.getElementById('c4You');
  if (y) y.textContent = 'YOU: ' + c4State.wins;
  var cp = document.getElementById('c4Cpu');
  if (cp) cp.textContent = 'CPU: ' + c4State.losses;
}
function renderConnect4() {
  c4Reset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Connect 4</h2>';
  h += '<div class="c4-score-row"><div class="c4-you" id="c4You">YOU: ' + c4State.wins + '</div><div class="c4-cpu" id="c4Cpu">CPU: ' + c4State.losses + '</div></div>';
  h += '<div class="c4-info" id="c4Info">Your turn - tap a column</div>';
  h += '<div class="c4-board" id="c4Board"></div>';
  h += '<button class="game-btn" id="c4New" style="margin-top:6px">NEW GAME</button>';
  appScreenContent.innerHTML = h;
  c4Render();
  document.getElementById('c4New').onclick = function() { c4Reset(); c4Render(); };
}
/* ============================================================
   MINESWEEPER (iPhone only)
   ============================================================ */
var msState = {
  grid: 8,
  mines: 10,
  board: [],
  revealed: [],
  flags: [],
  started: false,
  finished: false,
  won: false,
  firstClick: true
};
function msReset() {
  msState.board = [];
  msState.revealed = [];
  msState.flags = [];
  for (var r = 0; r < msState.grid; r++) {
    var rowB = [];
    var rowR = [];
    var rowF = [];
    for (var c = 0; c < msState.grid; c++) {
      rowB.push(0);
      rowR.push(false);
      rowF.push(false);
    }
    msState.board.push(rowB);
    msState.revealed.push(rowR);
    msState.flags.push(rowF);
  }
  msState.started = false;
  msState.finished = false;
  msState.won = false;
  msState.firstClick = true;
}
function msPlaceMines(safeR, safeC) {
  var placed = 0;
  while (placed < msState.mines) {
    var r = Math.floor(Math.random() * msState.grid);
    var c = Math.floor(Math.random() * msState.grid);
    if (msState.board[r][c] === -1) continue;
    if (Math.abs(r - safeR) <= 1 && Math.abs(c - safeC) <= 1) continue;
    msState.board[r][c] = -1;
    placed++;
  }
  for (var rr = 0; rr < msState.grid; rr++) {
    for (var cc = 0; cc < msState.grid; cc++) {
      if (msState.board[rr][cc] === -1) continue;
      var count = 0;
      for (var dr = -1; dr <= 1; dr++) {
        for (var dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          var nr = rr + dr;
          var nc = cc + dc;
          if (nr < 0 || nr >= msState.grid || nc < 0 || nc >= msState.grid) continue;
          if (msState.board[nr][nc] === -1) count++;
        }
      }
      msState.board[rr][cc] = count;
    }
  }
}
function msReveal(r, c) {
  if (r < 0 || r >= msState.grid || c < 0 || c >= msState.grid) return;
  if (msState.revealed[r][c]) return;
  if (msState.flags[r][c]) return;
  msState.revealed[r][c] = true;
  if (msState.board[r][c] === 0) {
    for (var dr = -1; dr <= 1; dr++) {
      for (var dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        msReveal(r + dr, c + dc);
      }
    }
  }
}
function msClick(r, c) {
  if (msState.finished) return;
  if (msState.flags[r][c]) return;
  if (msState.revealed[r][c]) return;
  if (msState.firstClick) {
    msPlaceMines(r, c);
    msState.firstClick = false;
  }
  if (msState.board[r][c] === -1) {
    msState.revealed[r][c] = true;
    msState.finished = true;
    msState.won = false;
    msRender();
    return;
  }
  msReveal(r, c);
  msCheckWin();
  msRender();
}
function msFlag(r, c) {
  if (msState.finished) return;
  if (msState.revealed[r][c]) return;
  msState.flags[r][c] = !msState.flags[r][c];
  msRender();
}
function msCheckWin() {
  for (var r = 0; r < msState.grid; r++) {
    for (var c = 0; c < msState.grid; c++) {
      if (msState.board[r][c] !== -1 && !msState.revealed[r][c]) return;
    }
  }
  msState.finished = true;
  msState.won = true;
}
function msRender() {
  var board = document.getElementById('msBoard');
  if (!board) return;
  board.style.gridTemplateColumns = 'repeat(' + msState.grid + ', 1fr)';
  var h = '';
  for (var r = 0; r < msState.grid; r++) {
    for (var c = 0; c < msState.grid; c++) {
      var cls = 'ms-cell';
      var label = '';
      if (msState.revealed[r][c]) {
        cls += ' revealed';
        if (msState.board[r][c] === -1) {
          cls += ' mine';
          label = '*';
        } else if (msState.board[r][c] > 0) {
          cls += ' n' + msState.board[r][c];
          label = String(msState.board[r][c]);
        }
      } else if (msState.flags[r][c]) {
        cls += ' flag';
        label = 'F';
      }
      h += '<div class="' + cls + '" data-msr="' + r + '" data-msc="' + c + '">' + label + '</div>';
    }
  }
  board.innerHTML = h;
  var cells = board.querySelectorAll('.ms-cell');
  for (var i = 0; i < cells.length; i++) {
    var el = cells[i];
    var r = parseInt(el.getAttribute('data-msr'), 10);
    var c = parseInt(el.getAttribute('data-msc'), 10);
    el.onclick = (function(rr, cc) {
      return function() { msClick(rr, cc); };
    })(r, c);
    el.oncontextmenu = (function(rr, cc) {
      return function(e) { e.preventDefault(); msFlag(rr, cc); };
    })(r, c);
  }
  var flagsUsed = 0;
  for (var fr = 0; fr < msState.grid; fr++) {
    for (var fc = 0; fc < msState.grid; fc++) {
      if (msState.flags[fr][fc]) flagsUsed++;
    }
  }
  var info = document.getElementById('msInfo');
  if (info) {
    if (msState.finished && msState.won) info.textContent = 'YOU WIN!';
    else if (msState.finished) info.textContent = 'BOOM - Tap New Game';
    else info.textContent = 'Tap to reveal - long-press to flag';
  }
  var fl = document.getElementById('msFlags');
  if (fl) fl.textContent = 'FLAGS: ' + flagsUsed + '/' + msState.mines;
}
function renderMinesweeper() {
  msReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Minesweeper</h2>';
  h += '<div class="ms-info" id="msInfo">Tap to reveal - long-press to flag</div>';
  h += '<div class="ms-flags" id="msFlags" style="text-align:center;margin-bottom:8px;font-size:12px">FLAGS: 0/' + msState.mines + '</div>';
  h += '<div class="ms-board" id="msBoard"></div>';
  h += '<button class="game-btn" id="msNew" style="margin-top:8px">NEW GAME</button>';
  appScreenContent.innerHTML = h;
  msRender();
  document.getElementById('msNew').onclick = function() { msReset(); msRender(); };
}
/* ============================================================
   HANGMAN (iPhone only)
   ============================================================ */
var hmState = {
  words: [
    { word: 'PHONE', hint: 'You use it every day' },
    { word: 'APPLE', hint: 'A fruit and a brand' },
    { word: 'MUSIC', hint: 'You listen to it' },
    { word: 'TIGER', hint: 'A big cat' },
    { word: 'WATER', hint: 'You drink it' },
    { word: 'HOUSE', hint: 'You live in it' },
    { word: 'DREAM', hint: 'It happens when you sleep' },
    { word: 'LIGHT', hint: 'Opposite of dark' },
    { word: 'HAPPY', hint: 'A good feeling' },
    { word: 'BEACH', hint: 'Sand and ocean' },
    { word: 'CLOUD', hint: 'In the sky' },
    { word: 'MONEY', hint: 'You spend it' },
    { word: 'RIVER', hint: 'Flowing water' },
    { word: 'PLANT', hint: 'Grows in the ground' },
    { word: 'SMILE', hint: 'When you are happy' },
    { word: 'STONE', hint: 'A rock' },
    { word: 'BRAIN', hint: 'Inside your head' },
    { word: 'MOUSE', hint: 'Small animal or computer tool' },
    { word: 'HORSE', hint: 'You can ride it' },
    { word: 'PARTY', hint: 'A celebration' }
  ],
  word: '',
  hint: '',
  guessed: {},
  wrong: 0,
  maxWrong: 6,
  finished: false,
  won: false,
  wins: parseInt(localStorage.getItem('hmWins') || '0', 10),
  losses: parseInt(localStorage.getItem('hmLosses') || '0', 10)
};

var HM_STAGES = [
  '  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========',
  '  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========',
  '  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========',
  '  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========',
  '  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========',
  '  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========',
  '  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n========='
];

function hmReset() {
  var pick = hmState.words[Math.floor(Math.random() * hmState.words.length)];
  hmState.word = pick.word;
  hmState.hint = pick.hint;
  hmState.guessed = {};
  hmState.wrong = 0;
  hmState.finished = false;
  hmState.won = false;
}

function hmGuess(letter) {
  if (hmState.finished) return;
  if (hmState.guessed[letter]) return;
  hmState.guessed[letter] = true;
  if (hmState.word.indexOf(letter) === -1) {
    hmState.wrong++;
    if (hmState.wrong >= hmState.maxWrong) {
      hmState.finished = true;
      hmState.won = false;
      hmState.losses++;
      localStorage.setItem('hmLosses', String(hmState.losses));
    }
  } else {
    var allFound = true;
    for (var i = 0; i < hmState.word.length; i++) {
      if (!hmState.guessed[hmState.word[i]]) { allFound = false; break; }
    }
    if (allFound) {
      hmState.finished = true;
      hmState.won = true;
      hmState.wins++;
      localStorage.setItem('hmWins', String(hmState.wins));
    }
  }
  hmRender();
}

function hmRender() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Hangman</h2>';
  h += '<div class="c4-score-row"><div class="c4-you" id="hmWins">WINS: ' + hmState.wins + '</div><div class="c4-cpu" id="hmLosses">LOSSES: ' + hmState.losses + '</div></div>';

  var stage = HM_STAGES[Math.min(hmState.wrong, 6)];
  h += '<pre class="hm-draw">' + stage + '</pre>';

  var wordH = '<div class="hm-word">';
  for (var i = 0; i < hmState.word.length; i++) {
    var L = hmState.word[i];
    var show = hmState.guessed[L] ? L : '';
    wordH += '<div class="hm-letter shown">' + show + '</div>';
  }
  wordH += '</div>';
  h += wordH;

  h += '<div class="hm-status">';
  if (hmState.finished && hmState.won) h += 'YOU GOT IT!';
  else if (hmState.finished) h += 'OUT OF TRIES! The word was ' + hmState.word;
  else h += 'Hint: ' + hmState.hint;
  h += '</div>';

  h += '<div class="hm-keyboard">';
  var letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  for (var k = 0; k < letters.length; k++) {
    var L2 = letters[k];
    var kcls = 'hm-key';
    if (hmState.guessed[L2]) {
      if (hmState.word.indexOf(L2) !== -1) kcls += ' correct';
      else kcls += ' wrong';
    }
    h += '<button class="' + kcls + '" data-hm="' + L2 + '">' + L2 + '</button>';
  }
  h += '</div>';

  h += '<button class="game-btn" id="hmNew" style="margin-top:8px">NEW WORD</button>';

  appScreenContent.innerHTML = h;

  var keys = appScreenContent.querySelectorAll('[data-hm]');
  for (var j = 0; j < keys.length; j++) {
    keys[j].onclick = (function(el) {
      return function() { hmGuess(el.getAttribute('data-hm')); };
    })(keys[j]);
  }
  document.getElementById('hmNew').onclick = function() { hmReset(); hmRender(); };
}

function renderHangman() {
  hmReset();
  hmRender();
}
/* ============================================================
   IPHONE-ONLY GAMES
   ============================================================ */
var IPHONE_ONLY_GAMES = [
  ['Connect 4',   '4', '#ff2d55'],
  ['Minesweeper', 'M', '#00e5ff'],
  ['Hangman',     'H', '#ffcc00']
];

/* Add these 3 games to the master list */
(function addIphoneGames(){
  if (typeof ALL_GAMES === 'undefined') return;
  for (var i = 0; i < IPHONE_ONLY_GAMES.length; i++) {
    var exists = false;
    for (var j = 0; j < ALL_GAMES.length; j++) {
      if (ALL_GAMES[j][0] === IPHONE_ONLY_GAMES[i][0]) { exists = true; break; }
    }
    if (!exists) ALL_GAMES.push(IPHONE_ONLY_GAMES[i]);
  }
})();

/* Override renderGamesFolder to filter by brand */
(function iphoneOnlyFolder(){
  var _origRenderGamesFolder = window.renderGamesFolder;
  window.renderGamesFolder = function(){
    var iphoneOnlyNames = ['Connect 4', 'Minesweeper', 'Hangman'];
    var list = [];
    for (var i = 0; i < ALL_GAMES.length; i++) {
      var isIphoneOnly = iphoneOnlyNames.indexOf(ALL_GAMES[i][0]) !== -1;
      if (isIphoneOnly && currentBrand !== 'iphone') continue;
      list.push(ALL_GAMES[i]);
    }
    var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 16px">GAMES</h2>';
    h += '<div class="games-grid">';
    for (var j = 0; j < list.length; j++) {
      h += '<div class="games-tile" data-game="' + list[j][0] + '">';
      h += '<div class="games-icon" style="background:' + list[j][2] + '">' + list[j][1] + '</div>';
      h += '<div class="games-label">' + list[j][0] + '</div>';
      h += '</div>';
    }
    h += '</div>';
    appScreenContent.innerHTML = h;
    var tiles = appScreenContent.querySelectorAll('.games-tile');
    for (var k = 0; k < tiles.length; k++) {
      tiles[k].onclick = (function(el){
        return function(){ openGame(el.getAttribute('data-game')); };
      })(tiles[k]);
    }
  };
})();

/* Hook openGame for the new 3 games */
(function hookIphoneGames(){
  var _origOpenGame = window.openGame;
  window.openGame = function(name){
    if (name === 'Connect 4')   { renderConnect4(); return; }
    if (name === 'Minesweeper') { renderMinesweeper(); return; }
    if (name === 'Hangman')     { renderHangman(); return; }
    return _origOpenGame.apply(this, arguments);
  };
})();
/* ============================================================
   DOTS AND BOXES (Android only)
   ============================================================ */
var dbState = {
  size: 4,           // 4x4 dots = 3x3 boxes
  hLines: [],        // horizontal lines
  vLines: [],        // vertical lines
  boxes: [],         // who owns each box
  turn: 'red',
  youScore: 0,
  cpuScore: 0,
  finished: false,
  aiTimer: null
};
function dbReset() {
  if (dbState.aiTimer) { clearTimeout(dbState.aiTimer); dbState.aiTimer = null; }
  var n = dbState.size;
  dbState.hLines = [];
  dbState.vLines = [];
  dbState.boxes = [];
  for (var r = 0; r < n; r++) {
    var hrow = [];
    var vrow = [];
    for (var c = 0; c < n - 1; c++) hrow.push(null);
    for (var c2 = 0; c2 < n; c2++) vrow.push(null);
    dbState.hLines.push(hrow);
    dbState.vLines.push(vrow);
  }
  for (var br = 0; br < n - 1; br++) {
    var brow = [];
    for (var bc = 0; bc < n - 1; bc++) brow.push(null);
    dbState.boxes.push(brow);
  }
  dbState.turn = 'red';
  dbState.youScore = 0;
  dbState.cpuScore = 0;
  dbState.finished = false;
}
function dbDrawH(r, c) {
  if (dbState.finished) return;
  if (dbState.turn !== 'red') return;
  if (dbState.hLines[r][c]) return;
  dbState.hLines[r][c] = 'red';
  dbAfterMove('red');
}
function dbDrawV(r, c) {
  if (dbState.finished) return;
  if (dbState.turn !== 'red') return;
  if (dbState.vLines[r][c]) return;
  dbState.vLines[r][c] = 'red';
  dbAfterMove('red');
}
function dbAfterMove(color) {
  var scored = dbCheckBoxes(color);
  if (scored > 0) {
    if (color === 'red') dbState.youScore += scored;
    else dbState.cpuScore += scored;
  }
  if (dbCheckFull()) {
    dbState.finished = true;
    dbRender();
    return;
  }
  if (scored > 0) {
    dbRender();
    if (dbState.turn === 'yellow') {
      dbState.aiTimer = setTimeout(dbAiMove, 500);
    }
    return;
  }
  dbState.turn = (color === 'red') ? 'yellow' : 'red';
  dbRender();
  if (dbState.turn === 'yellow') {
    dbState.aiTimer = setTimeout(dbAiMove, 600);
  }
}
function dbCheckBoxes(color) {
  var n = dbState.size;
  var count = 0;
  for (var r = 0; r < n - 1; r++) {
    for (var c = 0; c < n - 1; c++) {
      if (dbState.boxes[r][c]) continue;
      var top = dbState.hLines[r][c];
      var bottom = dbState.hLines[r+1][c];
      var left = dbState.vLines[r][c];
      var right = dbState.vLines[r][c+1];
      if (top && bottom && left && right) {
        dbState.boxes[r][c] = color;
        count++;
      }
    }
  }
  return count;
}
function dbCheckFull() {
  var n = dbState.size;
  for (var r = 0; r < n - 1; r++) {
    for (var c = 0; c < n - 1; c++) {
      if (!dbState.boxes[r][c]) return false;
    }
  }
  return true;
}
function dbAiMove() {
  if (dbState.finished) return;
  if (dbState.turn !== 'yellow') return;
  var n = dbState.size;
  // First: complete a box if possible
  for (var r = 0; r < n - 1; r++) {
    for (var c = 0; c < n - 1; c++) {
      if (dbState.boxes[r][c]) continue;
      var missing = dbMissingSides(r, c);
      if (missing.length === 1) {
        var side = missing[0];
        dbPlaySide(side, 'yellow');
        return;
      }
    }
  }
  // Otherwise: play a safe line (avoid giving away a box)
  var candidates = [];
  for (var r2 = 0; r2 < n; r2++) {
    for (var c2 = 0; c2 < n - 1; c2++) {
      if (!dbState.hLines[r2][c2]) {
        candidates.push({ type: 'h', r: r2, c: c2 });
      }
    }
  }
  for (var r3 = 0; r3 < n; r3++) {
    for (var c3 = 0; c3 < n; c3++) {
      if (!dbState.vLines[r3][c3]) {
        candidates.push({ type: 'v', r: r3, c: c3 });
      }
    }
  }
  if (candidates.length === 0) return;
  // Prefer lines that don't create a box for the player
  var safe = [];
  for (var i = 0; i < candidates.length; i++) {
    if (!dbWouldGiveBox(candidates[i])) safe.push(candidates[i]);
  }
  var pool = safe.length > 0 ? safe : candidates;
  var pick = pool[Math.floor(Math.random() * pool.length)];
  dbPlaySide(pick, 'yellow');
}
function dbMissingSides(r, c) {
  var missing = [];
  if (!dbState.hLines[r][c]) missing.push({ type: 'h', r: r, c: c });
  if (!dbState.hLines[r+1][c]) missing.push({ type: 'h', r: r+1, c: c });
  if (!dbState.vLines[r][c]) missing.push({ type: 'v', r: r, c: c });
  if (!dbState.vLines[r][c+1]) missing.push({ type: 'v', r: r, c: c+1 });
  return missing;
}
function dbWouldGiveBox(side) {
  if (side.type === 'h') {
    dbState.hLines[side.r][side.c] = 'yellow';
    var gives = dbCheckAnyBoxPossible();
    dbState.hLines[side.r][side.c] = null;
    return gives;
  } else {
    dbState.vLines[side.r][side.c] = 'yellow';
    var gives2 = dbCheckAnyBoxPossible();
    dbState.vLines[side.r][side.c] = null;
    return gives2;
  }
}
function dbCheckAnyBoxPossible() {
  var n = dbState.size;
  for (var r = 0; r < n - 1; r++) {
    for (var c = 0; c < n - 1; c++) {
      if (dbState.boxes[r][c]) continue;
      var missing = dbMissingSides(r, c);
      if (missing.length === 0) return true;
    }
  }
  return false;
}
function dbPlaySide(side, color) {
  if (side.type === 'h') dbState.hLines[side.r][side.c] = color;
  else dbState.vLines[side.r][side.c] = color;
  dbAfterMove(color);
}
function dbRender() {
  var board = document.getElementById('dbBoard');
  if (!board) return;
  var n = dbState.size;
  board.style.gridTemplateColumns = 'repeat(' + (n * 2 - 1) + ', 1fr)';
  board.style.gridTemplateRows = 'repeat(' + (n * 2 - 1) + ', 1fr)';
  var h = '';
  for (var r = 0; r < n * 2 - 1; r++) {
    for (var c = 0; c < n * 2 - 1; c++) {
      var isEvenR = r % 2 === 0;
      var isEvenC = c % 2 === 0;
      if (isEvenR && isEvenC) {
        h += '<div class="db-dot"></div>';
      } else if (isEvenR && !isEvenC) {
        var hc = Math.floor(c / 2);
        var val = dbState.hLines[r/2][hc];
        var cls = 'db-hline' + (val ? ' ' + val : '');
        h += '<div class="' + cls + '" data-dbt="h" data-dbr="' + (r/2) + '" data-dbc="' + hc + '"></div>';
      } else if (!isEvenR && isEvenC) {
        var vr = Math.floor(r / 2);
        var vc = c / 2;
        var val2 = dbState.vLines[vr][vc];
        var cls2 = 'db-vline' + (val2 ? ' ' + val2 : '');
        h += '<div class="' + cls2 + '" data-dbt="v" data-dbr="' + vr + '" data-dbc="' + vc + '"></div>';
      } else {
        var br = Math.floor(r / 2);
        var bc = Math.floor(c / 2);
        var owner = dbState.boxes[br][bc];
        var cls3 = 'db-box' + (owner ? ' ' + owner : '');
        h += '<div class="' + cls3 + '">' + (owner === 'red' ? 'Y' : (owner === 'yellow' ? 'C' : '')) + '</div>';
      }
    }
  }
  board.innerHTML = h;
  var lines = board.querySelectorAll('[data-dbt]');
  for (var i = 0; i < lines.length; i++) {
    var el = lines[i];
    el.onclick = (function(e){
      return function(){
        var t = e.getAttribute('data-dbt');
        var r = parseInt(e.getAttribute('data-dbr'), 10);
        var c = parseInt(e.getAttribute('data-dbc'), 10);
        if (t === 'h') dbDrawH(r, c);
        else dbDrawV(r, c);
      };
    })(lines[i]);
  }
  var y = document.getElementById('dbYou');
  if (y) y.textContent = 'YOU: ' + dbState.youScore;
  var cp = document.getElementById('dbCpu');
  if (cp) cp.textContent = 'CPU: ' + dbState.cpuScore;
  var info = document.getElementById('dbInfo');
  if (info) {
    if (dbState.finished) {
      if (dbState.youScore > dbState.cpuScore) info.textContent = 'YOU WIN!';
      else if (dbState.cpuScore > dbState.youScore) info.textContent = 'CPU WINS';
      else info.textContent = 'DRAW';
    } else if (dbState.turn === 'red') {
      info.textContent = 'Your turn - tap a line';
    } else {
      info.textContent = 'CPU thinking...';
    }
  }
}
function renderDotsBoxes() {
  dbReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Dots and Boxes</h2>';
  h += '<div class="c4-score-row"><div class="c4-you" id="dbYou">YOU: 0</div><div class="c4-cpu" id="dbCpu">CPU: 0</div></div>';
  h += '<div class="c4-info" id="dbInfo">Your turn - tap a line</div>';
  h += '<div class="db-board" id="dbBoard"></div>';
  h += '<button class="game-btn" id="dbNew" style="margin-top:8px">NEW GAME</button>';
  appScreenContent.innerHTML = h;
  dbRender();
  document.getElementById('dbNew').onclick = function() { dbReset(); dbRender(); };
}
/* ============================================================
   SNAKES AND LADDERS (Android only)
   ============================================================ */
var slState = {
  you: 0,         // 0 = start (before square 1)
  cpu: 0,
  turn: 'you',    // 'you' or 'cpu'
  finished: false,
  winner: null,
  aiTimer: null,
  rolling: false
};
// ladders: from -> to
var SL_LADDERS = { 4: 14, 9: 31, 20: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91 };
// snakes: from -> to
var SL_SNAKES = { 17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 79 };

function slReset() {
  if (slState.aiTimer) { clearTimeout(slState.aiTimer); slState.aiTimer = null; }
  slState.you = 0;
  slState.cpu = 0;
  slState.turn = 'you';
  slState.finished = false;
  slState.winner = null;
  slState.rolling = false;
}
function slRoll() {
  return Math.floor(Math.random() * 6) + 1;
}
function slMove(who, roll) {
  var pos = who === 'you' ? slState.you : slState.cpu;
  var next = pos + roll;
  if (next > 100) next = pos; // need exact to reach 100? we'll allow overshoot by staying
  if (SL_LADDERS[next]) next = SL_LADDERS[next];
  else if (SL_SNAKES[next]) next = SL_SNAKES[next];
  if (who === 'you') slState.you = next;
  else slState.cpu = next;
}
function slPlayerRoll() {
  if (slState.finished || slState.turn !== 'you' || slState.rolling) return;
  slState.rolling = true;
  var roll = slRoll();
  var rollEl = document.getElementById('slRoll');
  if (rollEl) rollEl.textContent = roll;
  slMove('you', roll);
  slRender();
  if (slState.you === 100) {
    slState.finished = true;
    slState.winner = 'you';
    slState.rolling = false;
    slRender();
    return;
  }
  slState.turn = 'cpu';
  slRender();
  slState.rolling = false;
  slState.aiTimer = setTimeout(slCpuRoll, 900);
}
function slCpuRoll() {
  if (slState.finished) return;
  var roll = slRoll();
  var rollEl = document.getElementById('slRoll');
  if (rollEl) rollEl.textContent = roll;
  slMove('cpu', roll);
  slRender();
  if (slState.cpu === 100) {
    slState.finished = true;
    slState.winner = 'cpu';
    slRender();
    return;
  }
  slState.turn = 'you';
  slRender();
}
function slCellPosition(square) {
  // Convert 1-100 to row/col on 10x10 board
  // Row 0 = top (91-100), row 9 = bottom (1-10)
  // Boustrophedon: even rows left-to-right, odd rows right-to-left
  var idx = square - 1;
  var row = 9 - Math.floor(idx / 10);
  var within = idx % 10;
  var col;
  if (Math.floor(idx / 10) % 2 === 0) {
    col = within; // left to right
  } else {
    col = 9 - within; // right to left
  }
  return { row: row, col: col };
}
function slRender() {
  var board = document.getElementById('slBoard');
  if (!board) return;
  board.innerHTML = '';

  // Draw 100 cells
  for (var s = 1; s <= 100; s++) {
    var pos = slCellPosition(s);
    var el = document.createElement('div');
    var cls = 'sl-cell ' + (s % 2 === 0 ? 'even' : 'odd');
    el.className = cls;
    el.style.left = (pos.col * 10) + '%';
    el.style.top = (pos.row * 10) + '%';
    el.textContent = s;

    // Mark ladders and snakes
    if (SL_LADDERS[s]) {
      el.style.color = '#3ddc84';
      el.textContent = s + '↑';
    } else if (SL_SNAKES[s]) {
      el.style.color = '#ff2d55';
      el.textContent = s + '↓';
    }
    board.appendChild(el);
  }

  // Draw player token
  var youPos = slState.you === 0 ? 1 : slState.you;
  var youCell = slCellPosition(youPos);
  var youToken = document.createElement('div');
  youToken.className = 'sl-token you';
  youToken.style.left = (youCell.col * 10 + 5) + '%';
  youToken.style.top = (youCell.row * 10 + 5) + '%';
  youToken.innerHTML = '<div class="dot"></div>';
  board.appendChild(youToken);

  // Draw CPU token
  var cpuPos = slState.cpu === 0 ? 1 : slState.cpu;
  var cpuCell = slCellPosition(cpuPos);
  var cpuToken = document.createElement('div');
  cpuToken.className = 'sl-token cpu';
  cpuToken.style.left = (cpuCell.col * 10 + 2) + '%';
  cpuToken.style.top = (cpuCell.row * 10 + 2) + '%';
  cpuToken.innerHTML = '<div class="dot"></div>';
  board.appendChild(cpuToken);

  // Update info
  var info = document.getElementById('slInfo');
  if (info) {
    if (slState.finished) {
      info.textContent = slState.winner === 'you' ? 'YOU WIN!' : 'CPU WINS';
    } else if (slState.turn === 'you') {
      info.textContent = 'Your turn - tap ROLL';
    } else {
      info.textContent = 'CPU rolling...';
    }
  }
  var youScoreEl = document.getElementById('slYou');
  if (youScoreEl) youScoreEl.textContent = 'YOU: ' + slState.you;
  var cpuScoreEl = document.getElementById('slCpu');
  if (cpuScoreEl) cpuScoreEl.textContent = 'CPU: ' + slState.cpu;

  var rollBtn = document.getElementById('slRollBtn');
  if (rollBtn) {
    rollBtn.disabled = (slState.turn !== 'you' || slState.finished);
  }
}
function renderSnakesLadders() {
  slReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Snakes & Ladders</h2>';
  h += '<div class="c4-score-row"><div class="c4-you" id="slYou">YOU: 0</div><div class="c4-cpu" id="slCpu">CPU: 0</div></div>';
  h += '<div class="sl-info" id="slInfo">Your turn - tap ROLL</div>';
  h += '<div class="sl-board" id="slBoard"></div>';
  h += '<div class="sl-dice">';
  h += '<button class="sl-dice-btn" id="slRollBtn">ROLL</button>';
  h += '<div class="sl-roll" id="slRoll">-</div>';
  h += '</div>';
  h += '<button class="game-btn" id="slNew" style="margin-top:12px;background:rgba(255,255,255,0.1);color:#fff">NEW GAME</button>';
  appScreenContent.innerHTML = h;
  slRender();
  document.getElementById('slRollBtn').onclick = slPlayerRoll;
  document.getElementById('slNew').onclick = function() { slReset(); slRender(); };
}
/* ============================================================
   COLOR MATCH (Android only)
   ============================================================ */
var cmState = {
  wordText: '',
  wordColor: '',
  score: 0,
  timeLeft: 30,
  best: parseInt(localStorage.getItem('cmBest') || '0', 10),
  running: false,
  timer: null,
  finished: false
};
var CM_COLORS = [
  { name: 'RED',    hex: '#ff2d55' },
  { name: 'GREEN',  hex: '#3ddc84' },
  { name: 'BLUE',   hex: '#1a88ff' },
  { name: 'YELLOW', hex: '#ffcc00' }
];
function cmReset() {
  if (cmState.timer) { clearInterval(cmState.timer); cmState.timer = null; }
  cmState.score = 0;
  cmState.timeLeft = 30;
  cmState.running = false;
  cmState.finished = false;
  cmState.wordText = '';
  cmState.wordColor = '';
}
function cmNewRound() {
  var textPick = CM_COLORS[Math.floor(Math.random() * 4)];
  var colorPick = CM_COLORS[Math.floor(Math.random() * 4)];
  // 30% of the time, match them (make it easier sometimes)
  if (Math.random() < 0.3) colorPick = textPick;
  cmState.wordText = textPick.name;
  cmState.wordColor = colorPick.name;
  var wordEl = document.getElementById('cmWord');
  if (wordEl) {
    wordEl.textContent = textPick.name;
    wordEl.style.color = colorPick.hex;
  }
  cmRenderScore();
}
function cmAnswer(colorName) {
  if (!cmState.running) return;
  if (cmState.finished) return;
  if (colorName === cmState.wordColor) {
    cmState.score++;
    if (cmState.score > cmState.best) {
      cmState.best = cmState.score;
      localStorage.setItem('cmBest', String(cmState.best));
    }
    cmNewRound();
  } else {
    cmState.score = Math.max(0, cmState.score - 1);
    cmRenderScore();
  }
}
function cmTick() {
  if (!cmState.running) return;
  cmState.timeLeft -= 1;
  var t = document.getElementById('cmTime');
  if (t) t.textContent = 'TIME: ' + cmState.timeLeft;
  if (cmState.timeLeft <= 0) cmEnd();
}
function cmEnd() {
  cmState.running = false;
  cmState.finished = true;
  if (cmState.timer) { clearInterval(cmState.timer); cmState.timer = null; }
  if (cmState.score > cmState.best) {
    cmState.best = cmState.score;
    localStorage.setItem('cmBest', String(cmState.best));
  }
  var info = document.getElementById('cmInfo');
  if (info) info.textContent = 'GAME OVER - Final: ' + cmState.score;
  cmRenderScore();
}
function cmRenderScore() {
  var sc = document.getElementById('cmScore');
  if (sc) sc.textContent = 'SCORE: ' + cmState.score;
  var bst = document.getElementById('cmBest');
  if (bst) bst.textContent = 'BEST: ' + cmState.best;
}
function renderColorMatch() {
  cmReset();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Color Match</h2>';
  h += '<div class="c4-score-row"><div class="c4-you" id="cmScore">SCORE: 0</div><div class="c4-cpu" id="cmBest">BEST: ' + cmState.best + '</div></div>';
  h += '<div class="c4-info" id="cmInfo">Tap the COLOR, not the word</div>';
  h += '<div class="c4-info" id="cmTime" style="color:#ffcc00;font-weight:900">TIME: 30</div>';
  h += '<div class="cm-stage">';
  h += '<div class="cm-prompt">TAP THE COLOR THIS WORD IS SHOWN IN</div>';
  h += '<div class="cm-word" id="cmWord">READY</div>';
  h += '</div>';
  h += '<div class="cm-buttons">';
  h += '<button class="cm-btn cm-red" data-cm="RED">RED</button>';
  h += '<button class="cm-btn cm-green" data-cm="GREEN">GREEN</button>';
  h += '<button class="cm-btn cm-blue" data-cm="BLUE">BLUE</button>';
  h += '<button class="cm-btn cm-yellow" data-cm="YELLOW">YELLOW</button>';
  h += '</div>';
  h += '<button class="game-btn" id="cmStart" style="margin-top:6px">START</button>';
  appScreenContent.innerHTML = h;

  var btns = appScreenContent.querySelectorAll('[data-cm]');
  for (var i = 0; i < btns.length; i++) {
    btns[i].onclick = (function(el){
      return function(){ cmAnswer(el.getAttribute('data-cm')); };
    })(btns[i]);
  }

  document.getElementById('cmStart').onclick = function() {
    if (cmState.running) return;
    cmReset();
    cmState.running = true;
    var info = document.getElementById('cmInfo');
    if (info) info.textContent = 'Tap the COLOR, not the word';
    var t = document.getElementById('cmTime');
    if (t) t.textContent = 'TIME: 30';
    cmNewRound();
    cmState.timer = setInterval(cmTick, 1000);
  };
}
/* ============================================================
   ANDROID-ONLY GAMES
   ============================================================ */
var ANDROID_ONLY_GAMES = [
  ['Dots and Boxes',  'D', '#3ddc84'],
  ['Snakes Ladders',  'S', '#ff8800'],
  ['Color Match',     'C', '#a855f7']
];

/* Add these to the master list */
(function addAndroidGames(){
  if (typeof ALL_GAMES === 'undefined') return;
  for (var i = 0; i < ANDROID_ONLY_GAMES.length; i++) {
    var exists = false;
    for (var j = 0; j < ALL_GAMES.length; j++) {
      if (ALL_GAMES[j][0] === ANDROID_ONLY_GAMES[i][0]) { exists = true; break; }
    }
    if (!exists) ALL_GAMES.push(ANDROID_ONLY_GAMES[i]);
  }
})();

/* Replace renderGamesFolder with full brand-aware version */
(function fullGamesFolder(){
  var IPHONE_ONLY  = ['Connect 4', 'Minesweeper', 'Hangman'];
  var ANDROID_ONLY = ['Dots and Boxes', 'Snakes Ladders', 'Color Match'];

  window.renderGamesFolder = function(){
    var list = [];
    for (var i = 0; i < ALL_GAMES.length; i++) {
      var name = ALL_GAMES[i][0];
      var isIphoneOnly  = IPHONE_ONLY.indexOf(name) !== -1;
      var isAndroidOnly = ANDROID_ONLY.indexOf(name) !== -1;
      if (isIphoneOnly && currentBrand !== 'iphone') continue;
      if (isAndroidOnly && currentBrand !== 'android') continue;
      list.push(ALL_GAMES[i]);
    }
    var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 16px">GAMES</h2>';
    h += '<div class="games-grid">';
    for (var j = 0; j < list.length; j++) {
      h += '<div class="games-tile" data-game="' + list[j][0] + '">';
      h += '<div class="games-icon" style="background:' + list[j][2] + '">' + list[j][1] + '</div>';
      h += '<div class="games-label">' + list[j][0] + '</div>';
      h += '</div>';
    }
    h += '</div>';
    appScreenContent.innerHTML = h;
    var tiles = appScreenContent.querySelectorAll('.games-tile');
    for (var k = 0; k < tiles.length; k++) {
      tiles[k].onclick = (function(el){
        return function(){ openGame(el.getAttribute('data-game')); };
      })(tiles[k]);
    }
  };
})();

/* Hook the 3 new games into openGame */
(function hookAndroidGames(){
  var _origOpenGame = window.openGame;
  window.openGame = function(name){
    if (name === 'Dots and Boxes') { renderDotsBoxes(); return; }
    if (name === 'Snakes Ladders') { renderSnakesLadders(); return; }
    if (name === 'Color Match')    { renderColorMatch(); return; }
    return _origOpenGame.apply(this, arguments);
  };
})();
/* ============================================================
   CLEAN SPIN SYSTEM - 3 SPINS / 24 HOURS
   ============================================================ */
(function cleanSpinSystem(){
  var RESET_MS = 24 * 60 * 60 * 1000;

  function getLastReset() {
    var v = localStorage.getItem('spinLastReset');
    if (!v) return 0;
    var n = parseInt(v, 10);
    return isNaN(n) ? 0 : n;
  }
  function getUsed() {
    var v = localStorage.getItem('spinsUsed');
    if (!v) return 0;
    var n = parseInt(v, 10);
    return isNaN(n) ? 0 : n;
  }
  function setLastReset(t) { localStorage.setItem('spinLastReset', String(t)); }
  function setUsed(n) { localStorage.setItem('spinsUsed', String(n)); }

  window.spinsRemaining = function() {
    var now = Date.now();
    var last = getLastReset();
    if (last === 0 || (now - last) >= RESET_MS) {
      setLastReset(now);
      setUsed(0);
      return 3;
    }
    return Math.max(0, 3 - getUsed());
  };

  window.recordSpin = function() {
    var last = getLastReset();
    if (last === 0 || (Date.now() - last) >= RESET_MS) {
      setLastReset(Date.now());
      setUsed(1);
    } else {
      setUsed(getUsed() + 1);
    }
    window.updateSpinCounter();
  };

  window.updateSpinCounter = function() {
    var el = document.getElementById('spinCounter');
    var sb = document.getElementById('spinBtn');
    if (!el || !sb) return;

    var now = Date.now();
    var last = getLastReset();

    if (last === 0) {
      setLastReset(now);
      setUsed(0);
      el.textContent = 'Spins left today: 3';
      sb.disabled = false;
      sb.textContent = 'SPIN';
      return;
    }

    var elapsed = now - last;
    if (elapsed >= RESET_MS) {
      setLastReset(now);
      setUsed(0);
      el.textContent = 'Spins left today: 3';
      sb.disabled = false;
      sb.textContent = 'SPIN';
      return;
    }

    var used = getUsed();
    var remaining = Math.max(0, 3 - used);

    if (remaining > 0) {
      el.textContent = 'Spins left today: ' + remaining;
      sb.disabled = false;
      sb.textContent = 'SPIN';
    } else {
      var left = RESET_MS - elapsed;
      var hrs = Math.floor(left / 3600000);
      var mins = Math.floor((left % 3600000) / 60000);
      var secs = Math.floor((left % 60000) / 1000);
      var timeStr = hrs + 'h ' + mins + 'm ' + (secs < 10 ? '0' : '') + secs + 's';
      el.textContent = 'New spins in ' + timeStr;
      sb.disabled = true;
      sb.textContent = 'COME BACK LATER';
    }
  };

  if (window._cleanSpinInterval) {
    clearInterval(window._cleanSpinInterval);
  }
  window._cleanSpinInterval = setInterval(window.updateSpinCounter, 1000);
  window.updateSpinCounter();
})();
/* ============================================================
   INSTAGRAM PROFILE
   ============================================================ */
var igState = {
  following: localStorage.getItem('igFollowing') === 'true',
  likedPosts: JSON.parse(localStorage.getItem('igLiked') || '{}'),
  comments: JSON.parse(localStorage.getItem('igComments') || '{}'),
  tab: 'posts'
};
var IG_POSTS = [
  { id: 1, likes: 2341, caption: 'Sunset vibes today', time: '2 hours ago', color: '#ff6699', icon: 'SUNSET' },
  { id: 2, likes: 890, caption: 'New camera test', time: '5 hours ago', color: '#00e5ff', icon: 'CAM' },
  { id: 3, likes: 12402, caption: 'Beach day with friends', time: '1 day ago', color: '#ffcc00', icon: 'BEACH' },
  { id: 4, likes: 3120, caption: 'Best pizza ever', time: '2 days ago', color: '#a855f7', icon: 'FOOD' },
  { id: 5, likes: 5440, caption: 'City lights at night', time: '3 days ago', color: '#1a88ff', icon: 'CITY' },
  { id: 6, likes: 1892, caption: 'Morning coffee', time: '4 days ago', color: '#ff8800', icon: 'COFFEE' },
  { id: 7, likes: 3310, caption: 'Weekend hike', time: '5 days ago', color: '#3ddc84', icon: 'HIKE' },
  { id: 8, likes: 7640, caption: 'Road trip begins', time: '1 week ago', color: '#ff2d55', icon: 'TRIP' },
  { id: 9, likes: 2200, caption: 'Throwback photo', time: '1 week ago', color: '#a855f7', icon: 'OLD' }
];
function igToggleFollow() {
  igState.following = !igState.following;
  localStorage.setItem('igFollowing', igState.following ? 'true' : 'false');
  igRender();
}
function igToggleLike(postId) {
  igState.likedPosts[postId] = !igState.likedPosts[postId];
  localStorage.setItem('igLiked', JSON.stringify(igState.likedPosts));
  igRender();
}
function igRender() {
  var h = '<h2 style="font-size:18px;letter-spacing:2px;color:#ff006e;margin:0 0 12px">Instagram</h2>';

  h += '<div class="social-profile">';
  h += '<div class="social-header">';
  h += '<div class="social-avatar"></div>';
  h += '<div class="social-stats">';
  h += '<div class="social-stat"><b>9</b><span>POSTS</span></div>';
  h += '<div class="social-stat"><b>1.2M</b><span>FOLLOWERS</span></div>';
  h += '<div class="social-stat"><b>128</b><span>FOLLOWING</span></div>';
  h += '</div></div>';
  h += '<div class="social-username">sarah_official</div>';
  h += '<div class="social-bio">Photographer. Traveler. Coffee lover. Sharing moments from around the world.</div>';
  h += '<button class="social-follow-btn' + (igState.following ? ' following' : '') + '" id="igFollowBtn">' + (igState.following ? 'FOLLOWING' : 'FOLLOW') + '</button>';
  h += '</div>';

  h += '<div class="social-tabs">';
  h += '<div class="social-tab' + (igState.tab === 'posts' ? ' active' : '') + '" data-igtab="posts">POSTS</div>';
  h += '<div class="social-tab' + (igState.tab === 'feed' ? ' active' : '') + '" data-igtab="feed">FEED</div>';
  h += '</div>';

  if (igState.tab === 'feed') {
    for (var i = 0; i < 4; i++) {
      var p = IG_POSTS[i];
      var liked = igState.likedPosts[p.id];
      var likeCount = p.likes + (liked ? 1 : 0);
      var comments = igState.comments[p.id] || 0;
      h += '<div class="social-post">';
      h += '<div class="social-post-header">';
      h += '<div class="social-post-avatar"></div>';
      h += '<div class="social-post-user">sarah_official</div>';
      h += '</div>';
      h += '<div class="social-post-img" style="background:linear-gradient(135deg,' + p.color + ',#222)">' + p.icon + '</div>';
      h += '<div class="social-post-actions">';
      h += '<span data-iglike="' + p.id + '" class="' + (liked ? 'liked' : '') + '">' + (liked ? 'HEART-FILLED' : 'HEART') + '</span>';
      h += '<span data-igcomment="' + p.id + '">COMMENT</span>';
      h += '<span>SHARE</span>';
      h += '</div>';
      h += '<div class="social-post-likes">' + likeCount.toLocaleString() + ' likes</div>';
      h += '<div class="social-post-caption"><b>sarah_official</b> ' + p.caption + '</div>';
      if (comments > 0) {
        h += '<div style="font-size:11px;color:rgba(255,255,255,0.5);margin-top:6px">View all ' + comments + ' comments</div>';
      }
      h += '</div>';
    }
  } else {
    h += '<div class="social-grid">';
    for (var j = 0; j < IG_POSTS.length; j++) {
      var q = IG_POSTS[j];
      h += '<div class="social-grid-item" style="background:linear-gradient(135deg,' + q.color + ',#222)" data-igpost="' + q.id + '">';
      h += '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:20px;color:rgba(255,255,255,0.5);font-weight:900">' + q.icon.substring(0, 3) + '</div>';
      h += '<div class="likes">' + q.likes + '</div>';
      h += '</div>';
    }
    h += '</div>';
  }

  appScreenContent.innerHTML = h;

  document.getElementById('igFollowBtn').onclick = igToggleFollow;

  var tabs = appScreenContent.querySelectorAll('[data-igtab]');
  for (var t = 0; t < tabs.length; t++) {
    tabs[t].onclick = (function(el) {
      return function() {
        igState.tab = el.getAttribute('data-igtab');
        igRender();
      };
    })(tabs[t]);
  }

  var likeBtns = appScreenContent.querySelectorAll('[data-iglike]');
  for (var l = 0; l < likeBtns.length; l++) {
    likeBtns[l].onclick = (function(el) {
      return function() {
        igToggleLike(parseInt(el.getAttribute('data-iglike'), 10));
      };
    })(likeBtns[l]);
  }

  var commentBtns = appScreenContent.querySelectorAll('[data-igcomment]');
  for (var cm = 0; cm < commentBtns.length; cm++) {
    commentBtns[cm].onclick = (function(el) {
      return function() {
        var id = parseInt(el.getAttribute('data-igcomment'), 10);
        var text = prompt('Write a comment:');
        if (text && text.trim()) {
          igState.comments[id] = (igState.comments[id] || 0) + 1;
          localStorage.setItem('igComments', JSON.stringify(igState.comments));
          igRender();
        }
      };
    })(commentBtns[cm]);
  }

  var postTiles = appScreenContent.querySelectorAll('[data-igpost]');
  for (var pt = 0; pt < postTiles.length; pt++) {
    postTiles[pt].onclick = (function(el) {
      return function() {
        var id = parseInt(el.getAttribute('data-igpost'), 10);
        var p = null;
        for (var k = 0; k < IG_POSTS.length; k++) {
          if (IG_POSTS[k].id === id) { p = IG_POSTS[k]; break; }
        }
        if (!p) return;
        var liked = igState.likedPosts[p.id];
        var likeCount = p.likes + (liked ? 1 : 0);
        var hh = '<div class="social-post">';
        hh += '<div class="social-post-header"><div class="social-post-avatar"></div><div class="social-post-user">sarah_official</div></div>';
        hh += '<div class="social-post-img" style="background:linear-gradient(135deg,' + p.color + ',#222);aspect-ratio:1/1;font-size:60px">' + p.icon + '</div>';
        hh += '<div class="social-post-actions"><span data-iglike="' + p.id + '" class="' + (liked ? 'liked' : '') + '">' + (liked ? 'HEART-FILLED' : 'HEART') + '</span><span data-igcomment="' + p.id + '">COMMENT</span><span>SHARE</span></div>';
        hh += '<div class="social-post-likes">' + likeCount.toLocaleString() + ' likes</div>';
        hh += '<div class="social-post-caption"><b>sarah_official</b> ' + p.caption + '</div>';
        hh += '<div style="font-size:10px;color:rgba(255,255,255,0.4);margin-top:8px">' + p.time + '</div>';
        hh += '<button class="game-btn" id="igBackToList" style="margin-top:14px">BACK</button>';
        hh += '</div>';
        appScreenContent.innerHTML = hh;
        document.getElementById('igBackToList').onclick = igRender;
        var lb = document.querySelector('[data-iglike="' + p.id + '"]');
        if (lb) lb.onclick = function() { igToggleLike(p.id); };
        var cb = document.querySelector('[data-igcomment="' + p.id + '"]');
        if (cb) cb.onclick = function() {
          var text = prompt('Write a comment:');
          if (text && text.trim()) {
            igState.comments[p.id] = (igState.comments[p.id] || 0) + 1;
            localStorage.setItem('igComments', JSON.stringify(igState.comments));
            igRender();
          }
        };
      };
    })(postTiles[pt]);
  }
}
function renderInstagram() {
  igState.tab = 'posts';
  igRender();
}
/* ============================================================
   TIKTOK PROFILE
   ============================================================ */
var ttState = {
  following: localStorage.getItem('ttFollowing') === 'true',
  likedVideos: JSON.parse(localStorage.getItem('ttLiked') || '{}'),
  comments: JSON.parse(localStorage.getItem('ttComments') || '{}'),
  tab: 'videos'
};
var TT_VIDEOS = [
  { id: 1, likes: '234K', caption: 'Dance trend 2026', color: '#ff006e', icon: 'DANCE' },
  { id: 2, likes: '89K', caption: 'Funny cat moment', color: '#00e5ff', icon: 'CAT' },
  { id: 3, likes: '1.2M', caption: 'Cooking hack', color: '#3ddc84', icon: 'COOK' },
  { id: 4, likes: '456K', caption: 'Pet reveal', color: '#ffcc00', icon: 'PET' },
  { id: 5, likes: '789K', caption: 'Life hack', color: '#a855f7', icon: 'HACK' },
  { id: 6, likes: '123K', caption: 'Music remix', color: '#ff6699', icon: 'MUSIC' }
];
function ttToggleFollow() {
  ttState.following = !ttState.following;
  localStorage.setItem('ttFollowing', ttState.following ? 'true' : 'false');
  ttRender();
}
function ttToggleLike(videoId) {
  ttState.likedVideos[videoId] = !ttState.likedVideos[videoId];
  localStorage.setItem('ttLiked', JSON.stringify(ttState.likedVideos));
  ttRender();
}
function ttRender() {
  var h = '<div style="background:linear-gradient(90deg,#ff006e,#00e5ff);padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:14px;color:#fff">TikTok</div>';

  h += '<div class="social-profile">';
  h += '<div class="social-header">';
  h += '<div class="social-avatar tiktok"></div>';
  h += '<div class="social-stats">';
  h += '<div class="social-stat"><b>128</b><span>FOLLOWING</span></div>';
  h += '<div class="social-stat"><b>892K</b><span>FOLLOWERS</span></div>';
  h += '<div class="social-stat"><b>4.2M</b><span>LIKES</span></div>';
  h += '</div></div>';
  h += '<div class="social-username">@dancequeen</div>';
  h += '<div class="social-bio">Just dancing my way through life. New video daily!</div>';
  h += '<button class="social-follow-btn' + (ttState.following ? ' following' : '') + '" id="ttFollowBtn">' + (ttState.following ? 'FOLLOWING' : 'FOLLOW') + '</button>';
  h += '</div>';

  h += '<div class="social-tabs">';
  h += '<div class="social-tab' + (ttState.tab === 'videos' ? ' active' : '') + '" data-tttab="videos">VIDEOS</div>';
  h += '<div class="social-tab' + (ttState.tab === 'feed' ? ' active' : '') + '" data-tttab="feed">FEED</div>';
  h += '</div>';

  if (ttState.tab === 'feed') {
    for (var i = 0; i < 3; i++) {
      var v = TT_VIDEOS[i];
      var liked = ttState.likedVideos[v.id];
      var comments = ttState.comments[v.id] || 0;
      h += '<div class="social-post">';
      h += '<div class="social-post-header"><div class="social-post-avatar" style="background:linear-gradient(135deg,#00e5ff,#ff006e)"></div><div class="social-post-user">@dancequeen</div></div>';
      h += '<div class="social-post-img" style="background:linear-gradient(180deg,' + v.color + ',#111);aspect-ratio:9/16;font-size:44px;color:#fff">' + v.icon + '</div>';
      h += '<div class="social-post-actions">';
      h += '<span data-ttlike="' + v.id + '" class="' + (liked ? 'liked' : '') + '">' + (liked ? 'LIKED' : 'LIKE') + '</span>';
      h += '<span data-ttcomment="' + v.id + '">COMMENT</span>';
      h += '<span>SHARE</span>';
      h += '</div>';
      h += '<div class="social-post-likes">' + v.likes + ' likes</div>';
      h += '<div class="social-post-caption"><b>@dancequeen</b> ' + v.caption + '</div>';
      if (comments > 0) {
        h += '<div style="font-size:11px;color:rgba(255,255,255,0.5);margin-top:6px">View ' + comments + ' comments</div>';
      }
      h += '</div>';
    }
  } else {
    h += '<div class="social-grid">';
    for (var j = 0; j < TT_VIDEOS.length; j++) {
      var q = TT_VIDEOS[j];
      h += '<div class="social-grid-item" style="background:linear-gradient(180deg,' + q.color + ',#111)" data-ttvideo="' + q.id + '">';
      h += '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:14px;color:#fff;font-weight:900;padding:4px;text-align:center">' + q.icon + '</div>';
      h += '<div class="likes">' + q.likes + '</div>';
      h += '</div>';
    }
    h += '</div>';
  }

  appScreenContent.innerHTML = h;

  document.getElementById('ttFollowBtn').onclick = ttToggleFollow;

  var tabs = appScreenContent.querySelectorAll('[data-tttab]');
  for (var t = 0; t < tabs.length; t++) {
    tabs[t].onclick = (function(el) {
      return function() {
        ttState.tab = el.getAttribute('data-tttab');
        ttRender();
      };
    })(tabs[t]);
  }

  var likeBtns = appScreenContent.querySelectorAll('[data-ttlike]');
  for (var l = 0; l < likeBtns.length; l++) {
    likeBtns[l].onclick = (function(el) {
      return function() {
        ttToggleLike(parseInt(el.getAttribute('data-ttlike'), 10));
      };
    })(likeBtns[l]);
  }

  var commentBtns = appScreenContent.querySelectorAll('[data-ttcomment]');
  for (var cm = 0; cm < commentBtns.length; cm++) {
    commentBtns[cm].onclick = (function(el) {
      return function() {
        var id = parseInt(el.getAttribute('data-ttcomment'), 10);
        var text = prompt('Write a comment:');
        if (text && text.trim()) {
          ttState.comments[id] = (ttState.comments[id] || 0) + 1;
          localStorage.setItem('ttComments', JSON.stringify(ttState.comments));
          ttRender();
        }
      };
    })(commentBtns[cm]);
  }

  var videoTiles = appScreenContent.querySelectorAll('[data-ttvideo]');
  for (var vt = 0; vt < videoTiles.length; vt++) {
    videoTiles[vt].onclick = (function(el) {
      return function() {
        var id = parseInt(el.getAttribute('data-ttvideo'), 10);
        var v = null;
        for (var k = 0; k < TT_VIDEOS.length; k++) {
          if (TT_VIDEOS[k].id === id) { v = TT_VIDEOS[k]; break; }
        }
        if (!v) return;
        var liked = ttState.likedVideos[v.id];
        var hh = '<div class="social-post">';
        hh += '<div class="social-post-header"><div class="social-post-avatar" style="background:linear-gradient(135deg,#00e5ff,#ff006e)"></div><div class="social-post-user">@dancequeen</div></div>';
        hh += '<div class="social-post-img" style="background:linear-gradient(180deg,' + v.color + ',#111);aspect-ratio:9/16;font-size:60px;color:#fff">' + v.icon + '</div>';
        hh += '<div class="social-post-actions"><span data-ttlike="' + v.id + '" class="' + (liked ? 'liked' : '') + '">' + (liked ? 'LIKED' : 'LIKE') + '</span><span data-ttcomment="' + v.id + '">COMMENT</span><span>SHARE</span></div>';
        hh += '<div class="social-post-likes">' + v.likes + ' likes</div>';
        hh += '<div class="social-post-caption"><b>@dancequeen</b> ' + v.caption + '</div>';
        hh += '<button class="game-btn" id="ttBack" style="margin-top:14px">BACK</button>';
        hh += '</div>';
        appScreenContent.innerHTML = hh;
        document.getElementById('ttBack').onclick = ttRender;
        var lb = document.querySelector('[data-ttlike="' + v.id + '"]');
        if (lb) lb.onclick = function() { ttToggleLike(v.id); };
        var cb = document.querySelector('[data-ttcomment="' + v.id + '"]');
        if (cb) cb.onclick = function() {
          var text = prompt('Write a comment:');
          if (text && text.trim()) {
            ttState.comments[v.id] = (ttState.comments[v.id] || 0) + 1;
            localStorage.setItem('ttComments', JSON.stringify(ttState.comments));
            ttRender();
          }
        };
      };
    })(videoTiles[vt]);
  }
}
function renderTikTok() {
  ttState.tab = 'videos';
  ttRender();
}
/* ============================================================
   BANK APP
   ============================================================ */
var bankState = {
  balance: parseFloat(localStorage.getItem('bankBalance') || '24850.75'),
  accountNumber: localStorage.getItem('bankAccountNum') || '0123456789',
  cardNumber: localStorage.getItem('bankCardNum') || '4532 1567 8901 2345',
  transactions: JSON.parse(localStorage.getItem('bankTx') || 'null') || [
    { name: 'Salary Deposit', amount: 5000, date: 'Sep 15, 2026', type: 'in' },
    { name: 'Netflix Subscription', amount: 15.99, date: 'Sep 14, 2026', type: 'out' },
    { name: 'Transfer to John', amount: 250, date: 'Sep 13, 2026', type: 'out' },
    { name: 'ATM Withdrawal', amount: 100, date: 'Sep 12, 2026', type: 'out' },
    { name: 'Freelance Payment', amount: 800, date: 'Sep 10, 2026', type: 'in' },
    { name: 'Grocery Store', amount: 87.50, date: 'Sep 9, 2026', type: 'out' },
    { name: 'Gas Station', amount: 45, date: 'Sep 8, 2026', type: 'out' },
    { name: 'Refund - Amazon', amount: 32.99, date: 'Sep 7, 2026', type: 'in' }
  ]
};
function bankSave() {
  localStorage.setItem('bankBalance', String(bankState.balance));
  localStorage.setItem('bankAccountNum', bankState.accountNumber);
  localStorage.setItem('bankCardNum', bankState.cardNumber);
  localStorage.setItem('bankTx', JSON.stringify(bankState.transactions));
}
function bankFormatMoney(n) {
  return '$' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
function bankRender() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Bank</h2>';

  h += '<div class="bank-balance-card">';
  h += '<div class="bank-balance-label">AVAILABLE BALANCE</div>';
  h += '<div class="bank-balance-amount">' + bankFormatMoney(bankState.balance) + '</div>';
  h += '<div class="bank-balance-sub">Account •••• ' + bankState.accountNumber.slice(-4) + '</div>';
  h += '</div>';

  h += '<div class="bank-actions">';
  h += '<div class="bank-action" data-bank="send"><div class="bank-action-icon">↑</div><div class="bank-action-label">Send</div></div>';
  h += '<div class="bank-action" data-bank="request"><div class="bank-action-icon">↓</div><div class="bank-action-label">Request</div></div>';
  h += '<div class="bank-action" data-bank="topup"><div class="bank-action-icon">+</div><div class="bank-action-label">Top Up</div></div>';
  h += '<div class="bank-action" data-bank="bills"><div class="bank-action-icon">$</div><div class="bank-action-label">Bills</div></div>';
  h += '</div>';

  h += '<div class="bank-section-title">MY CARD</div>';
  h += '<div class="bank-card">';
  h += '<div class="bank-card-chip"></div>';
  h += '<div class="bank-card-number">' + bankState.cardNumber + '</div>';
  h += '<div class="bank-card-row">';
  h += '<div><div class="bank-card-label">CARD HOLDER</div><div class="bank-card-value">' + (userName || 'CARD USER').toUpperCase() + '</div></div>';
  h += '<div><div class="bank-card-label">EXPIRES</div><div class="bank-card-value">12/29</div></div>';
  h += '<div class="bank-card-brand">VISA</div>';
  h += '</div>';
  h += '</div>';

  h += '<div class="bank-section-title">RECENT TRANSACTIONS</div>';
  for (var i = 0; i < bankState.transactions.length; i++) {
    var t = bankState.transactions[i];
    var sign = t.type === 'in' ? '+' : '-';
    h += '<div class="bank-tx">';
    h += '<div class="bank-tx-icon ' + t.type + '">' + (t.type === 'in' ? '↓' : '↑') + '</div>';
    h += '<div class="bank-tx-info">';
    h += '<div class="bank-tx-name">' + t.name + '</div>';
    h += '<div class="bank-tx-date">' + t.date + '</div>';
    h += '</div>';
    h += '<div class="bank-tx-amount ' + t.type + '">' + sign + bankFormatMoney(t.amount).replace('$','$') + '</div>';
    h += '</div>';
  }

  appScreenContent.innerHTML = h;

  var actions = appScreenContent.querySelectorAll('[data-bank]');
  for (var a = 0; a < actions.length; a++) {
    actions[a].onclick = (function(el) {
      return function() { bankAction(el.getAttribute('data-bank')); };
    })(actions[a]);
  }
}
function bankAction(type) {
  if (type === 'send') {
    var name = prompt('Send to (name):');
    if (!name) return;
    var amt = prompt('Amount:');
    var num = parseFloat(amt);
    if (isNaN(num) || num <= 0) { alert('Invalid amount'); return; }
    if (num > bankState.balance) { alert('Insufficient balance'); return; }
    bankState.balance -= num;
    bankState.transactions.unshift({ name: 'To ' + name, amount: num, date: 'Today', type: 'out' });
    bankSave();
    bankRender();
  } else if (type === 'topup') {
    var amt2 = prompt('Top up amount:');
    var num2 = parseFloat(amt2);
    if (isNaN(num2) || num2 <= 0) { alert('Invalid amount'); return; }
    bankState.balance += num2;
    bankState.transactions.unshift({ name: 'Top Up', amount: num2, date: 'Today', type: 'in' });
    bankSave();
    bankRender();
  } else if (type === 'request') {
    alert('Request sent. You will be notified when they respond.');
  } else if (type === 'bills') {
    alert('No pending bills. All paid.');
  }
}
/* ============================================================
   HOOK: BANK APP + NEW INSTAGRAM/TIKTOK
   ============================================================ */
(function hookBankAndSocial(){
  var _origOpenApp = window.openApp;
  window.openApp = function(name){
    if (name === 'Bank') { renderBank(); return; }
    if (name === 'Instagram') { renderInstagram(); return; }
    if (name === 'TikTok') { renderTikTok(); return; }
    return _origOpenApp.apply(this, arguments);
  };
})();

/* Add Bank icon to both home screens */
(function addBankIcon(){
  var makeIcon = function(){
    var el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'B';
    el.setAttribute('data-label', 'Bank');
    el.style.background = 'linear-gradient(135deg,#00e5ff,#0088ff)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function(){
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderBank();
    });
    return el;
  };
  var ip = document.getElementById('iphoneIcons');
  var an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();
/* ============================================================
   BANK APP
   ============================================================ */
var bankState = {
  balance: parseFloat(localStorage.getItem('bankBalance') || '24850.75'),
  accountNumber: localStorage.getItem('bankAccountNum') || '0123456789',
  cardNumber: localStorage.getItem('bankCardNum') || '4532 1567 8901 2345',
  transactions: JSON.parse(localStorage.getItem('bankTx') || 'null') || [
    { name: 'Salary Deposit', amount: 5000, date: 'Sep 15, 2026', type: 'in' },
    { name: 'Netflix Subscription', amount: 15.99, date: 'Sep 14, 2026', type: 'out' },
    { name: 'Transfer to John', amount: 250, date: 'Sep 13, 2026', type: 'out' },
    { name: 'ATM Withdrawal', amount: 100, date: 'Sep 12, 2026', type: 'out' },
    { name: 'Freelance Payment', amount: 800, date: 'Sep 10, 2026', type: 'in' },
    { name: 'Grocery Store', amount: 87.50, date: 'Sep 9, 2026', type: 'out' },
    { name: 'Gas Station', amount: 45, date: 'Sep 8, 2026', type: 'out' },
    { name: 'Refund - Amazon', amount: 32.99, date: 'Sep 7, 2026', type: 'in' }
  ]
};

function bankSave() {
  localStorage.setItem('bankBalance', String(bankState.balance));
  localStorage.setItem('bankTx', JSON.stringify(bankState.transactions));
}

function bankFormatMoney(n) {
  return '$' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function bankRender() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Bank</h2>';

  h += '<div class="bank-balance-card">';
  h += '<div class="bank-balance-label">AVAILABLE BALANCE</div>';
  h += '<div class="bank-balance-amount">' + bankFormatMoney(bankState.balance) + '</div>';
  h += '<div class="bank-balance-sub">Account •••• ' + bankState.accountNumber.slice(-4) + '</div>';
  h += '</div>';

  h += '<div class="bank-actions">';
  h += '<div class="bank-action" data-bank="send"><div class="bank-action-icon">↑</div><div class="bank-action-label">Send</div></div>';
  h += '<div class="bank-action" data-bank="request"><div class="bank-action-icon">↓</div><div class="bank-action-label">Request</div></div>';
  h += '<div class="bank-action" data-bank="topup"><div class="bank-action-icon">+</div><div class="bank-action-label">Top Up</div></div>';
  h += '<div class="bank-action" data-bank="bills"><div class="bank-action-icon">$</div><div class="bank-action-label">Bills</div></div>';
  h += '</div>';

  h += '<div class="bank-section-title">MY CARD</div>';
  h += '<div class="bank-card">';
  h += '<div class="bank-card-chip"></div>';
  h += '<div class="bank-card-number">' + bankState.cardNumber + '</div>';
  h += '<div class="bank-card-row">';
  h += '<div><div class="bank-card-label">CARD HOLDER</div><div class="bank-card-value">' + ((userName || 'CARD USER') + '').toUpperCase() + '</div></div>';
  h += '<div><div class="bank-card-label">EXPIRES</div><div class="bank-card-value">12/29</div></div>';
  h += '<div class="bank-card-brand">VISA</div>';
  h += '</div></div>';

  h += '<div class="bank-section-title">RECENT TRANSACTIONS</div>';
  for (var i = 0; i < bankState.transactions.length; i++) {
    var t = bankState.transactions[i];
    var sign = t.type === 'in' ? '+' : '-';
    h += '<div class="bank-tx">';
    h += '<div class="bank-tx-icon ' + t.type + '">' + (t.type === 'in' ? '↓' : '↑') + '</div>';
    h += '<div class="bank-tx-info">';
    h += '<div class="bank-tx-name">' + t.name + '</div>';
    h += '<div class="bank-tx-date">' + t.date + '</div>';
    h += '</div>';
    h += '<div class="bank-tx-amount ' + t.type + '">' + sign + bankFormatMoney(t.amount) + '</div>';
    h += '</div>';
  }

  appScreenContent.innerHTML = h;

  var actions = appScreenContent.querySelectorAll('[data-bank]');
  for (var a = 0; a < actions.length; a++) {
    actions[a].onclick = (function(el) {
      return function() { bankAction(el.getAttribute('data-bank')); };
    })(actions[a]);
  }
}

function bankAction(type) {
  if (type === 'send') {
    var name = prompt('Send to (name):');
    if (!name) return;
    var amt = prompt('Amount:');
    var num = parseFloat(amt);
    if (isNaN(num) || num <= 0) { alert('Invalid amount'); return; }
    if (num > bankState.balance) { alert('Insufficient balance'); return; }
    bankState.balance -= num;
    bankState.transactions.unshift({ name: 'To ' + name, amount: num, date: 'Today', type: 'out' });
    bankSave();
    bankRender();
  } else if (type === 'topup') {
    var amt2 = prompt('Top up amount:');
    var num2 = parseFloat(amt2);
    if (isNaN(num2) || num2 <= 0) { alert('Invalid amount'); return; }
    bankState.balance += num2;
    bankState.transactions.unshift({ name: 'Top Up', amount: num2, date: 'Today', type: 'in' });
    bankSave();
    bankRender();
  } else if (type === 'request') {
    alert('Request sent.');
  } else if (type === 'bills') {
    alert('No pending bills.');
  }
}
/* Alias: make renderBank point to bankRender */
window.renderBank = function() {
  if (typeof bankRender === 'function') bankRender();
};
/* ============================================================
   QUICK FIX - INSTAGRAM & TIKTOK OPEN
   ============================================================ */
(function quickFixSocial(){
  // Wait for icons to exist, then override their clicks directly
  function attachIcons() {
    var allApps = document.querySelectorAll('.app');
    for (var i = 0; i < allApps.length; i++) {
      var label = allApps[i].getAttribute('data-label');
      if (label === 'Instagram') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderInstagram === 'function') renderInstagram();
        };
      } else if (label === 'TikTok') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderTikTok === 'function') renderTikTok();
        };
      }
    }
  }
  setTimeout(attachIcons, 800);
  setTimeout(attachIcons, 2000);
})();
/* ============================================================
   MESSAGES (real chat)
   ============================================================ */
var msgContacts = [
  { id: 'mom',    name: 'Mom',        color: '#00e5ff' },
  { id: 'john',   name: 'John',       color: '#ff006e' },
  { id: 'sarah',  name: 'Sarah',      color: '#3ddc84' },
  { id: 'work',   name: 'Work Group', color: '#ffcc00' },
  { id: 'david',  name: 'David',      color: '#a855f7' },
  { id: 'emma',   name: 'Emma',       color: '#ff6699' }
];

function msgGetAll() {
  try { return JSON.parse(localStorage.getItem('msgThreads') || '{}'); }
  catch(e) { return {}; }
}
function msgSaveAll(data) {
  localStorage.setItem('msgThreads', JSON.stringify(data));
}
function msgEscape(s) {
  if (s === undefined || s === null) return '';
  return String(s).replace(/[&<>"']/g, function(c) {
    var map = {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
    return map[c];
  });
}
function msgRenderList() {
  var threads = msgGetAll();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 16px">Messages</h2>';
  h += '<div class="msg-list">';
  for (var i = 0; i < msgContacts.length; i++) {
    var c = msgContacts[i];
    var conv = threads[c.id] || [];
    var last = conv.length > 0 ? conv[conv.length - 1] : null;
    var preview = last ? last.text : 'Tap to start chatting';
    var time = last ? last.time : '';
    h += '<div class="msg-thread" data-msgopen="' + c.id + '">';
    h += '<div class="msg-avatar" style="background:' + c.color + '">' + c.name.charAt(0) + '</div>';
    h += '<div class="msg-thread-info">';
    h += '<div class="msg-thread-name">' + msgEscape(c.name) + '</div>';
    h += '<div class="msg-thread-preview">' + msgEscape(preview) + '</div>';
    h += '</div>';
    h += '<div class="msg-thread-time">' + time + '</div>';
    h += '</div>';
  }
  h += '</div>';
  appScreenContent.innerHTML = h;
  var threads2 = appScreenContent.querySelectorAll('[data-msgopen]');
  for (var j = 0; j < threads2.length; j++) {
    threads2[j].onclick = (function(el) {
      return function() { msgOpenChat(el.getAttribute('data-msgopen')); };
    })(threads2[j]);
  }
}
function msgOpenChat(id) {
  var c = null;
  for (var i = 0; i < msgContacts.length; i++) {
    if (msgContacts[i].id === id) { c = msgContacts[i]; break; }
  }
  if (!c) return;
  var threads = msgGetAll();
  var conv = threads[id] || [];
  var h = '<div class="msg-chat">';
  h += '<div class="msg-chat-header">';
  h += '<button class="game-btn" id="msgBack" style="padding:6px 12px;font-size:11px;margin:0">Back</button>';
  h += '<div class="msg-avatar" style="background:' + c.color + ';width:36px;height:36px;font-size:14px">' + c.name.charAt(0) + '</div>';
  h += '<div><div class="msg-chat-name">' + msgEscape(c.name) + '</div><div class="msg-chat-status">online</div></div>';
  h += '</div>';
  h += '<div class="msg-bubbles" id="msgBubbles">';
  if (conv.length === 0) {
    h += '<div style="text-align:center;color:rgba(255,255,255,0.4);font-size:12px;padding:20px">No messages yet.<br>Say hi!</div>';
  } else {
    for (var k = 0; k < conv.length; k++) {
      var m = conv[k];
      var cls = m.me ? 'me' : 'them';
      h += '<div class="msg-bubble ' + cls + '">' + msgEscape(m.text) + '</div>';
    }
  }
  h += '</div>';
  h += '<div class="msg-input-row">';
  h += '<input class="msg-input" id="msgInput" type="text" placeholder="Type a message...">';
  h += '<button class="msg-send-btn" id="msgSend">➤</button>';
  h += '</div>';
  h += '</div>';
  appScreenContent.innerHTML = h;
  document.getElementById('msgBack').onclick = msgRenderList;
  var input = document.getElementById('msgInput');
  var sendBtn = document.getElementById('msgSend');
  function doSend() {
    var text = input.value.trim();
    if (!text) return;
    var threads2 = msgGetAll();
    if (!threads2[id]) threads2[id] = [];
    var now = new Date();
    var hh = now.getHours();
    var mm = now.getMinutes();
    if (mm < 10) mm = '0' + mm;
    var ampm = hh < 12 ? 'AM' : 'PM';
    var h12 = hh % 12 || 12;
    var timeStr = h12 + ':' + mm + ' ' + ampm;
    threads2[id].push({ text: text, me: true, time: timeStr });
    msgSaveAll(threads2);
    input.value = '';
    msgOpenChat(id);
    setTimeout(function() {
      var bubbles = document.getElementById('msgBubbles');
      if (bubbles) bubbles.scrollTop = bubbles.scrollHeight;
    }, 50);
  }
  sendBtn.onclick = doSend;
  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') doSend();
  });
  setTimeout(function() {
    var bubbles = document.getElementById('msgBubbles');
    if (bubbles) bubbles.scrollTop = bubbles.scrollHeight;
  }, 100);
}

function renderMessages() {
  msgRenderList();
}
/* ============================================================
   CAMERA + GALLERY
   ============================================================ */
var camPhotos = [];
try { camPhotos = JSON.parse(localStorage.getItem('camPhotos') || '[]'); } catch(e) { camPhotos = []; }

var CAM_COLORS = ['#ff006e','#00e5ff','#3ddc84','#ffcc00','#a855f7','#ff6699','#ff8800','#1a88ff'];
var CAM_EMOJIS = ['CAM','SUN','SEA','SKY','CITY','FLOWER','MOON','STAR'];
var CAM_CAPTIONS = ['Sunset view','Great day out','Beautiful moment','Captured this','Just like that','A memory'];

function camSave() {
  localStorage.setItem('camPhotos', JSON.stringify(camPhotos));
}

function camMakePhoto() {
  var c = CAM_COLORS[Math.floor(Math.random() * CAM_COLORS.length)];
  var e = CAM_EMOJIS[Math.floor(Math.random() * CAM_EMOJIS.length)];
  var cap = CAM_CAPTIONS[Math.floor(Math.random() * CAM_CAPTIONS.length)];
  var now = new Date();
  var hh = now.getHours();
  var mm = String(now.getMinutes()).padStart(2, '0');
  var ampm = hh < 12 ? 'AM' : 'PM';
  var h12 = hh % 12 || 12;
  return {
    id: Date.now(),
    color: c,
    icon: e,
    caption: cap,
    time: h12 + ':' + mm + ' ' + ampm,
    date: (now.getMonth() + 1) + '/' + now.getDate() + '/' + now.getFullYear()
  };
}

function renderCamera() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Camera</h2>';
  h += '<div class="cam-info" id="camCount">' + camPhotos.length + ' photos in gallery</div>';
  h += '<div class="cam-viewfinder" id="camViewfinder">';
  h += '<div class="cam-flash" id="camFlash"></div>';
  h += 'READY';
  h += '</div>';
  h += '<button class="cam-shutter" id="camShutter"></button>';
  h += '<div style="display:flex;gap:10px;justify-content:center;margin-top:14px">';
  h += '<button class="game-btn" id="camGoGallery" style="background:rgba(255,255,255,0.1);color:#fff">GALLERY</button>';
  h += '</div>';
  appScreenContent.innerHTML = h;

  document.getElementById('camShutter').onclick = function() {
    if (typeof soundClick === 'function') soundClick();
    var flash = document.getElementById('camFlash');
    if (flash) {
      flash.classList.remove('fire');
      void flash.offsetWidth;
      flash.classList.add('fire');
    }
    var viewfinder = document.getElementById('camViewfinder');
    if (viewfinder) {
      setTimeout(function() {
        var photo = camMakePhoto();
        camPhotos.unshift(photo);
        camSave();
        viewfinder.innerHTML = '<div class="cam-flash" id="camFlash"></div>';
        viewfinder.style.background = 'linear-gradient(135deg,' + photo.color + ',#111)';
        viewfinder.style.color = '#fff';
        viewfinder.style.fontWeight = '900';
        viewfinder.style.fontSize = '20px';
        viewfinder.style.letterSpacing = '3px';
        viewfinder.textContent = photo.icon;
        var count = document.getElementById('camCount');
        if (count) count.textContent = camPhotos.length + ' photos in gallery';
      }, 200);
    }
  };

  document.getElementById('camGoGallery').onclick = renderGallery;
}

function renderGallery() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Gallery</h2>';
  if (camPhotos.length === 0) {
    h += '<div class="gallery-empty">No photos yet.<br>Open Camera and tap the shutter.</div>';
  } else {
    h += '<div class="gallery-grid">';
    for (var i = 0; i < camPhotos.length; i++) {
      var p = camPhotos[i];
      h += '<div class="gallery-item" style="background:linear-gradient(135deg,' + p.color + ',#111);color:#fff;font-weight:900" data-gal="' + p.id + '">' + p.icon + '</div>';
    }
    h += '</div>';
  }
  h += '<div style="display:flex;gap:10px;justify-content:center;margin-top:14px">';
  h += '<button class="game-btn" id="galGoCamera" style="background:rgba(255,255,255,0.1);color:#fff">CAMERA</button>';
  if (camPhotos.length > 0) {
    h += '<button class="game-btn" id="galClear" style="background:rgba(255,45,85,0.2);color:#ff2d55">CLEAR ALL</button>';
  }
  h += '</div>';
  appScreenContent.innerHTML = h;

  var tiles = appScreenContent.querySelectorAll('[data-gal]');
  for (var j = 0; j < tiles.length; j++) {
    tiles[j].onclick = (function(el) {
      return function() {
        var id = parseInt(el.getAttribute('data-gal'), 10);
        galOpenPhoto(id);
      };
    })(tiles[j]);
  }

  var camBtn = document.getElementById('galGoCamera');
  if (camBtn) camBtn.onclick = renderCamera;

  var clearBtn = document.getElementById('galClear');
  if (clearBtn) clearBtn.onclick = function() {
    if (confirm('Delete all photos?')) {
      camPhotos = [];
      camSave();
      renderGallery();
    }
  };
}

function galOpenPhoto(id) {
  var p = null;
  for (var i = 0; i < camPhotos.length; i++) {
    if (camPhotos[i].id === id) { p = camPhotos[i]; break; }
  }
  if (!p) return;
  var h = '<div class="gallery-viewer">';
  h += '<div class="gallery-viewer-img" style="background:linear-gradient(135deg,' + p.color + ',#111);color:#fff;font-weight:900">' + p.icon + '</div>';
  h += '<div style="color:#fff;font-size:14px;font-weight:700;margin-bottom:4px">' + msgEscape(p.caption) + '</div>';
  h += '<div style="color:rgba(255,255,255,0.5);font-size:11px;margin-bottom:16px">' + p.date + ' · ' + p.time + '</div>';
  h += '<div style="display:flex;gap:10px">';
  h += '<button class="gallery-viewer-close" id="galBack">BACK</button>';
  h += '<button class="gallery-viewer-close" id="galDel" style="background:rgba(255,45,85,0.3);color:#fff">DELETE</button>';
  h += '</div></div>';
  var overlay = document.createElement('div');
  overlay.innerHTML = h;
  var viewer = overlay.firstChild;
  var stage = document.getElementById('phoneStage');
  if (stage) stage.appendChild(viewer);

  document.getElementById('galBack').onclick = function() {
    if (viewer.parentNode) viewer.parentNode.removeChild(viewer);
  };
  document.getElementById('galDel').onclick = function() {
    camPhotos = camPhotos.filter(function(x){ return x.id !== id; });
    camSave();
    if (viewer.parentNode) viewer.parentNode.removeChild(viewer);
    renderGallery();
  };
}
/* ============================================================
   HOOK: MESSAGES + CAMERA + GALLERY
   ============================================================ */
(function hookMsgCamGal(){
  var _origOpenApp = window.openApp;
  window.openApp = function(name){
    if (name === 'Messages') { renderMessages(); return; }
    if (name === 'Camera')   { renderCamera();   return; }
    if (name === 'Photos' || name === 'Gallery') { renderGallery(); return; }
    return _origOpenApp.apply(this, arguments);
  };
})();

/* Also attach directly to icons in case openApp doesn't catch them */
(function directIconAttach(){
  function attach() {
    var allApps = document.querySelectorAll('.app');
    for (var i = 0; i < allApps.length; i++) {
      var label = allApps[i].getAttribute('data-label');
      if (label === 'Messages') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderMessages === 'function') renderMessages();
        };
      } else if (label === 'Camera') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderCamera === 'function') renderCamera();
        };
      } else if (label === 'Photos' || label === 'Gallery') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderGallery === 'function') renderGallery();
        };
      }
    }
  }
  setTimeout(attach, 800);
  setTimeout(attach, 2000);
})();
/* ============================================================
   EMAIL APP
   ============================================================ */
var emailState = {
  emails: []
};

function emailLoad() {
  try {
    var saved = localStorage.getItem('emails');
    if (saved) {
      emailState.emails = JSON.parse(saved);
      return;
    }
  } catch(e) {}
  emailState.emails = [
    { id: 1, from: 'Sarah Johnson', color: '#ff006e', subject: 'Coffee this weekend?', preview: 'Hey, are you free Saturday?', body: 'Hey!\n\nAre you free this Saturday for coffee? I found a new place downtown that looks amazing.\n\nLet me know!\n\nSarah', time: '10:32 AM', unread: true },
    { id: 2, from: 'Tech News', color: '#00e5ff', subject: 'iPhone 17 review is live', preview: 'The new camera is incredible...', body: 'The new iPhone 17 Pro Max is here, and the camera system is a huge leap forward.\n\nRead the full review on our site.\n\n- Tech News Team', time: '9:15 AM', unread: true },
    { id: 3, from: 'John Smith', color: '#3ddc84', subject: 'Project update', preview: 'Just sent you the file', body: 'Hi,\n\nI just sent you the updated project file. Let me know what you think.\n\nJohn', time: '8:40 AM', unread: false },
    { id: 4, from: 'Netflix', color: '#cc0000', subject: 'New shows this week', preview: 'Check out the latest arrivals', body: 'New this week:\n\n- The Witcher Season 4\n- Wednesday Season 2\n- Money Heist: Berlin\n\nStreaming now.', time: 'Yesterday', unread: false },
    { id: 5, from: 'Bank Alert', color: '#ffcc00', subject: 'Transaction confirmed', preview: 'Your payment was successful', body: 'Your transaction of $250.00 to John Doe has been confirmed.\n\nBalance: $24,850.75\n\nThank you for banking with us.', time: 'Yesterday', unread: false },
    { id: 6, from: 'Mom', color: '#ff6699', subject: 'Call me when you can', preview: 'Nothing serious, just want to talk', body: 'Hi sweetie,\n\nGive me a call when you have time. Nothing serious, just want to catch up.\n\nLove,\nMom', time: '2 days ago', unread: false }
  ];
  emailSave();
}

function emailSave() {
  try {
    localStorage.setItem('emails', JSON.stringify(emailState.emails));
  } catch(e) {}
}

function emailRenderList() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 16px">Email</h2>';
  var unreadCount = 0;
  for (var i = 0; i < emailState.emails.length; i++) {
    if (emailState.emails[i].unread) unreadCount++;
  }
  h += '<div style="font-size:12px;color:rgba(255,255,255,0.6);margin-bottom:12px;letter-spacing:1px">' + (unreadCount > 0 ? unreadCount + ' UNREAD' : 'ALL CAUGHT UP') + '</div>';
  h += '<div class="email-list">';
  for (var j = 0; j < emailState.emails.length; j++) {
    var e = emailState.emails[j];
    h += '<div class="email-row' + (e.unread ? ' unread' : '') + '" data-email="' + e.id + '">';
    if (e.unread) h += '<div class="email-dot"></div>';
    h += '<div class="email-avatar" style="background:' + e.color + '">' + e.from.charAt(0) + '</div>';
    h += '<div class="email-info">';
    h += '<div class="email-from">' + emailEscape(e.from) + '</div>';
    h += '<div class="email-subject">' + emailEscape(e.subject) + '</div>';
    h += '<div class="email-preview">' + emailEscape(e.preview) + '</div>';
    h += '</div>';
    h += '<div class="email-time">' + e.time + '</div>';
    h += '</div>';
  }
  h += '</div>';
  appScreenContent.innerHTML = h;
  var rows = appScreenContent.querySelectorAll('[data-email]');
  for (var k = 0; k < rows.length; k++) {
    rows[k].onclick = (function(el) {
      return function() {
        emailOpen(parseInt(el.getAttribute('data-email'), 10));
      };
    })(rows[k]);
  }
}

function emailOpen(id) {
  var e = null;
  for (var i = 0; i < emailState.emails.length; i++) {
    if (emailState.emails[i].id === id) { e = emailState.emails[i]; break; }
  }
  if (!e) return;
  if (e.unread) {
    e.unread = false;
    emailSave();
  }
  var h = '<div class="email-full">';
  h += '<button class="game-btn" id="emailBack" style="padding:6px 12px;font-size:11px;margin:0 0 14px 0">Back</button>';
  h += '<div class="email-full-subject">' + emailEscape(e.subject) + '</div>';
  h += '<div class="email-full-from">From: <b style="color:#fff">' + emailEscape(e.from) + '</b> · ' + e.time + '</div>';
  h += '<div class="email-full-body">' + emailEscape(e.body) + '</div>';
  h += '<div class="email-actions">';
  h += '<button class="game-btn" id="emailReply" style="flex:1">REPLY</button>';
  h += '<button class="game-btn" id="emailDelete" style="flex:1;background:rgba(255,45,85,0.2);color:#ff2d55">DELETE</button>';
  h += '</div></div>';
  appScreenContent.innerHTML = h;

  document.getElementById('emailBack').onclick = emailRenderList;
  document.getElementById('emailReply').onclick = function() {
    var reply = prompt('Write your reply:');
    if (reply && reply.trim()) {
      alert('Reply sent to ' + e.from + '!');
    }
  };
  document.getElementById('emailDelete').onclick = function() {
    if (!confirm('Delete this email?')) return;
    emailState.emails = emailState.emails.filter(function(x){ return x.id !== id; });
    emailSave();
    emailRenderList();
  };
}

function emailEscape(s) {
  if (s === undefined || s === null) return '';
  return String(s).replace(/[&<>"']/g, function(c) {
    var map = {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
    return map[c];
  });
}

function renderEmail() {
  emailLoad();
  emailRenderList();
}
/* ============================================================
   NOTIFICATION BANNER
   ============================================================ */
var notifQueue = [];
var notifShowing = false;

var NOTIF_SAMPLES = [
  { app: 'Messages',  icon: 'M', color: '#3ddc84', title: 'Mom',            text: 'Call me when you can' },
  { app: 'Instagram', icon: 'I', color: '#ff006e', title: 'sarah_official', text: 'liked your post' },
  { app: 'TikTok',    icon: 'T', color: '#00e5ff', title: '@dancequeen',    text: 'posted a new video' },
  { app: 'Email',     icon: 'E', color: '#1a88ff', title: 'Tech News',      text: 'iPhone 17 review is live' },
  { app: 'Bank',      icon: 'B', color: '#00e5ff', title: 'Transaction',    text: 'You received $250.00' },
  { app: 'WhatsApp',  icon: 'W', color: '#3ddc84', title: 'John',           text: 'See you tomorrow!' },
  { app: 'Store',     icon: 'S', color: '#a855f7', title: 'Update available', text: 'WhatsApp has an update' },
  { app: 'Weather',   icon: 'W', color: '#00e5ff', title: 'Rain alert',     text: 'Rain expected in 2 hours' }
];

function notifShow(sample) {
  var stage = document.getElementById('phoneStage');
  if (!stage) return;

  var banner = document.createElement('div');
  banner.className = 'notif-banner';

  var icon = document.createElement('div');
  icon.className = 'notif-icon';
  icon.style.background = sample.color;
  icon.textContent = sample.icon;

  var content = document.createElement('div');
  content.className = 'notif-content';

  var appName = document.createElement('div');
  appName.className = 'notif-app';
  appName.textContent = sample.app;

  var title = document.createElement('div');
  title.className = 'notif-title';
  title.textContent = sample.title;

  var text = document.createElement('div');
  text.className = 'notif-text';
  text.textContent = sample.text;

  content.appendChild(appName);
  content.appendChild(title);
  content.appendChild(text);

  banner.appendChild(icon);
  banner.appendChild(content);
  stage.appendChild(banner);

  setTimeout(function() {
    banner.classList.add('show');
  }, 50);

  setTimeout(function() {
    banner.classList.remove('show');
    setTimeout(function() {
      if (banner.parentNode) banner.parentNode.removeChild(banner);
    }, 500);
  }, 4000);
}

function notifRandom() {
  var sample = NOTIF_SAMPLES[Math.floor(Math.random() * NOTIF_SAMPLES.length)];
  notifShow(sample);
}

var notifTimer = null;
function notifStart() {
  if (notifTimer) clearInterval(notifTimer);
  notifTimer = setInterval(function() {
    if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
    if (appScreen && !appScreen.classList.contains('hidden')) return;
    notifRandom();
  }, 25000);
}
function notifStop() {
  if (notifTimer) { clearInterval(notifTimer); notifTimer = null; }
}

window.addEventListener('load', function() {
  setTimeout(notifStart, 5000);
});
/* ============================================================
   PIANO (real sound via Web Audio API)
   ============================================================ */
var pianoCtx = null;
var pianoRecentNotes = [];

var PIANO_KEYS = [
  { note: 'C4',  freq: 261.63, label: 'C',  sharp: false },
  { note: 'C#4', freq: 277.18, label: 'C#', sharp: true  },
  { note: 'D4',  freq: 293.66, label: 'D',  sharp: false },
  { note: 'D#4', freq: 311.13, label: 'D#', sharp: true  },
  { note: 'E4',  freq: 329.63, label: 'E',  sharp: false },
  { note: 'F4',  freq: 349.23, label: 'F',  sharp: false },
  { note: 'F#4', freq: 369.99, label: 'F#', sharp: true  },
  { note: 'G4',  freq: 392.00, label: 'G',  sharp: false },
  { note: 'G#4', freq: 415.30, label: 'G#', sharp: true  },
  { note: 'A4',  freq: 440.00, label: 'A',  sharp: false },
  { note: 'A#4', freq: 466.16, label: 'A#', sharp: true  },
  { note: 'B4',  freq: 493.88, label: 'B',  sharp: false },
  { note: 'C5',  freq: 523.25, label: 'C',  sharp: false }
];

function pianoInitAudio() {
  if (pianoCtx) {
    if (pianoCtx.state === 'suspended') pianoCtx.resume();
    return pianoCtx;
  }
  try {
    pianoCtx = new (window.AudioContext || window.webkitAudioContext)();
  } catch(e) {
    pianoCtx = null;
  }
  return pianoCtx;
}

function pianoPlay(freq, label) {
  var ctx = pianoInitAudio();
  if (!ctx) return;

  // Note key
  var osc = ctx.createOscillator();
  var gain = ctx.createGain();
  osc.type = 'triangle';
  osc.frequency.value = freq;

  gain.gain.setValueAtTime(0.0001, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.4);

  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 1.5);

  // Harmonic layer for richer sound
  var osc2 = ctx.createOscillator();
  var gain2 = ctx.createGain();
  osc2.type = 'sine';
  osc2.frequency.value = freq * 2;
  gain2.gain.setValueAtTime(0.0001, ctx.currentTime);
  gain2.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.01);
  gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
  osc2.connect(gain2);
  gain2.connect(ctx.destination);
  osc2.start(ctx.currentTime);
  osc2.stop(ctx.currentTime + 1.3);

  // Track recent notes
  pianoRecentNotes.unshift(label);
  if (pianoRecentNotes.length > 8) pianoRecentNotes.pop();
  pianoUpdateRecent();
}

function pianoUpdateRecent() {
  var el = document.getElementById('pianoRecent');
  if (!el) return;
  var h = '';
  for (var i = 0; i < pianoRecentNotes.length; i++) {
    h += '<div class="piano-note-chip">' + pianoRecentNotes[i] + '</div>';
  }
  el.innerHTML = h;
}

function pianoPress(el, freq, label) {
  if (el) {
    el.classList.add('pressed');
    setTimeout(function() { el.classList.remove('pressed'); }, 150);
  }
  pianoPlay(freq, label);
}

function renderPiano() {
  pianoRecentNotes = [];
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Piano</h2>';
  h += '<div class="piano-info">Tap the keys to play</div>';
  h += '<div class="piano-keys" id="pianoKeys">';

  for (var i = 0; i < PIANO_KEYS.length; i++) {
    var k = PIANO_KEYS[i];
    var cls = 'piano-key' + (k.sharp ? ' sharp' : '');
    h += '<div class="' + cls + '" data-piano-freq="' + k.freq + '" data-piano-label="' + k.label + '">' + k.label + '</div>';
  }
  h += '</div>';
  h += '<div class="piano-info" style="margin-top:20px">RECENT NOTES</div>';
  h += '<div class="piano-recent" id="pianoRecent"></div>';
  h += '<button class="game-btn" id="pianoDemo" style="margin-top:20px">PLAY MELODY</button>';
  appScreenContent.innerHTML = h;

  var keys = appScreenContent.querySelectorAll('[data-piano-freq]');
  for (var j = 0; j < keys.length; j++) {
    (function(el) {
      el.addEventListener('mousedown', function() {
        pianoPress(el, parseFloat(el.getAttribute('data-piano-freq')), el.getAttribute('data-piano-label'));
      });
      el.addEventListener('touchstart', function(e) {
        e.preventDefault();
        pianoPress(el, parseFloat(el.getAttribute('data-piano-freq')), el.getAttribute('data-piano-label'));
      }, { passive: false });
    })(keys[j]);
  }

  document.getElementById('pianoDemo').onclick = function() {
    var melody = [261.63, 293.66, 329.63, 349.23, 392.00, 349.23, 329.63, 293.66];
    var labels = ['C', 'D', 'E', 'F', 'G', 'F', 'E', 'D'];
    for (var m = 0; m < melody.length; m++) {
      (function(idx) {
        setTimeout(function() {
          pianoPlay(melody[idx], labels[idx]);
        }, idx * 400);
      })(m);
    }
  };
}
/* ============================================================
   HOOK: EMAIL + PIANO + ADD ICONS
   ============================================================ */
(function hookEmailPiano(){
  var _origOpenApp = window.openApp;
  window.openApp = function(name){
    if (name === 'Email') { renderEmail(); return; }
    if (name === 'Piano') { renderPiano(); return; }
    return _origOpenApp.apply(this, arguments);
  };
})();

/* Add Piano icon to both home screens */
(function addPianoIcon(){
  var makeIcon = function(){
    var el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'P';
    el.setAttribute('data-label', 'Piano');
    el.style.background = 'linear-gradient(135deg,#ff006e,#a855f7)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function(){
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      if (typeof renderPiano === 'function') renderPiano();
    });
    return el;
  };
  var ip = document.getElementById('iphoneIcons');
  var an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();

/* Direct attach - Email + Piano icons */
(function directAttachEmailPiano(){
  function attach() {
    var allApps = document.querySelectorAll('.app');
    for (var i = 0; i < allApps.length; i++) {
      var label = allApps[i].getAttribute('data-label');
      if (label === 'Email') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderEmail === 'function') renderEmail();
        };
      } else if (label === 'Piano') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderPiano === 'function') renderPiano();
        };
      }
    }
  }
  setTimeout(attach, 1000);
  setTimeout(attach, 2500);
})();
/* ============================================================
   GMAIL ICON
   ============================================================ */
(function addGmailIcon(){
  function makeGmail(){
    var el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'M';
    el.setAttribute('data-label', 'Gmail');
    el.style.background = 'linear-gradient(135deg,#ffffff,#f1f1f1)';
    el.style.color = '#ea4335';
    el.style.fontWeight = '900';
    el.style.fontSize = '26px';
    el.addEventListener('click', function(e){
      if (e) e.preventDefault();
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      if (typeof renderEmail === 'function') renderEmail();
    });
    return el;
  }
  var ip = document.getElementById('iphoneIcons');
  var an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeGmail());
  if (an) an.appendChild(makeGmail());
})();

/* Hook Gmail in openApp too */
(function hookGmail(){
  var _origOpenApp = window.openApp;
  window.openApp = function(name){
    if (name === 'Gmail') { renderEmail(); return; }
    return _origOpenApp.apply(this, arguments);
  };
})();
/* ============================================================
   WHATSAPP (green theme, real chat)
   ============================================================ */
var waContacts = [
  { id: 'mom',   name: 'Mom',        color: '#00a884' },
  { id: 'john',  name: 'John',       color: '#ff006e' },
  { id: 'sarah', name: 'Sarah',      color: '#3ddc84' },
  { id: 'work',  name: 'Work Group', color: '#ffcc00' },
  { id: 'david', name: 'David',      color: '#a855f7' },
  { id: 'emma',  name: 'Emma',       color: '#ff6699' }
];

function waGetAll() {
  try { return JSON.parse(localStorage.getItem('waThreads') || '{}'); }
  catch(e) { return {}; }
}
function waSaveAll(data) {
  localStorage.setItem('waThreads', JSON.stringify(data));
}
function waEscape(s) {
  if (s === undefined || s === null) return '';
  return String(s).replace(/[&<>"']/g, function(c) {
    var map = {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
    return map[c];
  });
}
function waRenderList() {
  var threads = waGetAll();
  var h = '<div class="wa-header">';
  h += '<div class="wa-header-logo">WhatsApp</div>';
  h += '<div class="wa-header-status">' + waContacts.length + ' contacts</div>';
  h += '</div>';
  for (var i = 0; i < waContacts.length; i++) {
    var c = waContacts[i];
    var conv = threads[c.id] || [];
    var last = conv.length > 0 ? conv[conv.length - 1] : null;
    var preview = last ? last.text : 'Tap to start chatting';
    var time = last ? last.time : '';
    h += '<div class="wa-thread" data-waopen="' + c.id + '">';
    h += '<div class="wa-avatar" style="background:' + c.color + '">' + c.name.charAt(0) + '</div>';
    h += '<div class="wa-info">';
    h += '<div class="wa-name">' + waEscape(c.name) + '</div>';
    h += '<div class="wa-preview">' + waEscape(preview) + '</div>';
    h += '</div>';
    h += '<div class="wa-time">' + time + '</div>';
    h += '</div>';
  }
  appScreenContent.innerHTML = h;
  var rows = appScreenContent.querySelectorAll('[data-waopen]');
  for (var j = 0; j < rows.length; j++) {
    rows[j].onclick = (function(el) {
      return function() { waOpenChat(el.getAttribute('data-waopen')); };
    })(rows[j]);
  }
}
function waOpenChat(id) {
  var c = null;
  for (var i = 0; i < waContacts.length; i++) {
    if (waContacts[i].id === id) { c = waContacts[i]; break; }
  }
  if (!c) return;
  var threads = waGetAll();
  var conv = threads[id] || [];
  var h = '<div class="wa-chat-bg">';
  h += '<div style="display:flex;align-items:center;gap:10px;padding:10px;background:#075e54;border-radius:8px;margin-bottom:12px">';
  h += '<button class="game-btn" id="waBack" style="padding:6px 12px;font-size:11px;margin:0;background:rgba(255,255,255,0.15);color:#fff">Back</button>';
  h += '<div class="wa-avatar" style="background:' + c.color + ';width:34px;height:34px;font-size:14px">' + c.name.charAt(0) + '</div>';
  h += '<div><div style="font-size:13px;font-weight:700;color:#fff">' + waEscape(c.name) + '</div><div style="font-size:10px;color:rgba(255,255,255,0.7)">online</div></div>';
  h += '</div>';
  h += '<div class="msg-bubbles" id="waBubbles" style="max-height:340px">';
  if (conv.length === 0) {
    h += '<div style="text-align:center;color:rgba(255,255,255,0.4);font-size:12px;padding:20px">No messages yet.<br>Say hi!</div>';
  } else {
    for (var k = 0; k < conv.length; k++) {
      var m = conv[k];
      var cls = m.me ? 'me' : 'them';
      h += '<div class="wa-bubble ' + cls + '">' + waEscape(m.text) + '<div class="wa-time-in">' + m.time + (m.me ? ' ✓✓' : '') + '</div></div>';
    }
  }
  h += '</div>';
  h += '<div class="wa-input-row">';
  h += '<input class="wa-input" id="waInput" type="text" placeholder="Type a message...">';
  h += '<button class="wa-send-btn" id="waSend">➤</button>';
  h += '</div>';
  h += '</div>';
  appScreenContent.innerHTML = h;

  document.getElementById('waBack').onclick = waRenderList;

  var input = document.getElementById('waInput');
  var sendBtn = document.getElementById('waSend');

  function doSend() {
    var text = input.value.trim();
    if (!text) return;
    var threads2 = waGetAll();
    if (!threads2[id]) threads2[id] = [];
    var now = new Date();
    var hh = now.getHours();
    var mm = String(now.getMinutes()).padStart(2, '0');
    var ampm = hh < 12 ? 'AM' : 'PM';
    var h12 = hh % 12 || 12;
    var timeStr = h12 + ':' + mm + ' ' + ampm;
    threads2[id].push({ text: text, me: true, time: timeStr });
    waSaveAll(threads2);
    input.value = '';
    waOpenChat(id);
    setTimeout(function() {
      var bubbles = document.getElementById('waBubbles');
      if (bubbles) bubbles.scrollTop = bubbles.scrollHeight;
    }, 50);
  }
  sendBtn.onclick = doSend;
  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') doSend();
  });
  setTimeout(function() {
    var bubbles = document.getElementById('waBubbles');
    if (bubbles) bubbles.scrollTop = bubbles.scrollHeight;
  }, 100);
}
function renderWhatsApp() {
  waRenderList();
}
/* ============================================================
   WALLPAPER PICKER
   ============================================================ */
var WALLPAPERS = [
  { id: 'blue',    name: 'Ocean',     css: 'linear-gradient(160deg,#1a3a6a,#0a1a4a 50%,#020f2a)' },
  { id: 'green',   name: 'Forest',    css: 'linear-gradient(160deg,#0a2a1a,#052a15 50%,#001005)' },
  { id: 'purple',  name: 'Aurora',    css: 'linear-gradient(160deg,#2a1a4a,#1a0a3a 50%,#0a0220)' },
  { id: 'sunset',  name: 'Sunset',    css: 'linear-gradient(160deg,#ff5e62,#ff9966 50%,#3a1a1a)' },
  { id: 'dark',    name: 'Midnight',  css: 'linear-gradient(160deg,#1a1f28,#0d1220 50%,#000000)' },
  { id: 'cyan',    name: 'Cyan Wave', css: 'linear-gradient(160deg,#00b4d8,#0077b6 50%,#03045e)' }
];

function wallGetCurrent() {
  return localStorage.getItem('wallpaper') || 'blue';
}
function wallSetCurrent(id) {
  localStorage.setItem('wallpaper', id);
  wallApply();
}
function wallApply() {
  var id = wallGetCurrent();
  var wp = null;
  for (var i = 0; i < WALLPAPERS.length; i++) {
    if (WALLPAPERS[i].id === id) { wp = WALLPAPERS[i]; break; }
  }
  if (!wp) return;

  // Apply to iPhone home screen
  var ipFront = document.querySelector('.iphone-front .front-screen');
  if (ipFront) {
    ipFront.style.background = wp.css;
  }
  // Apply to Android home screen
  var anScreen = document.querySelector('.android-front .android-screen');
  if (anScreen) {
    anScreen.style.background = wp.css;
  }
}

function renderWallpaper() {
  var current = wallGetCurrent();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Wallpaper</h2>';
  h += '<div style="text-align:center;font-size:12px;color:rgba(255,255,255,0.6);margin-bottom:16px;letter-spacing:1px">Pick a wallpaper for your phone</div>';
  h += '<div class="wallpaper-grid">';
  for (var i = 0; i < WALLPAPERS.length; i++) {
    var w = WALLPAPERS[i];
    var cls = 'wallpaper-option' + (w.id === current ? ' active' : '');
    h += '<div class="' + cls + '" data-wall="' + w.id + '" style="background:' + w.css + '">';
    h += '<div class="wallpaper-check">✓</div>';
    h += '<div style="position:absolute;bottom:8px;left:8px;color:#fff;font-size:11px;font-weight:700;text-shadow:0 1px 3px rgba(0,0,0,0.7)">' + w.name + '</div>';
    h += '</div>';
  }
  h += '</div>';
  appScreenContent.innerHTML = h;

  var options = appScreenContent.querySelectorAll('[data-wall]');
  for (var j = 0; j < options.length; j++) {
    options[j].onclick = (function(el) {
      return function() {
        wallSetCurrent(el.getAttribute('data-wall'));
        if (typeof soundTap === 'function') soundTap();
        renderWallpaper();
      };
    })(options[j]);
  }
}

/* ============================================================
   LIVE CLOCK IN STATUS BAR
   ============================================================ */
(function liveStatusClock(){
  function updateClocks() {
    var now = new Date();
    var hh = now.getHours();
    var mm = String(now.getMinutes()).padStart(2, '0');
    var h12 = hh % 12 || 12;
    var timeStr = h12 + ':' + mm;

    var allTimes = document.querySelectorAll('.sb-time');
    for (var i = 0; i < allTimes.length; i++) {
      allTimes[i].textContent = timeStr;
    }
  }
  setInterval(updateClocks, 10000);
  updateClocks();
})();

/* Apply saved wallpaper on load */
window.addEventListener('load', function() {
  setTimeout(function() {
    wallApply();
  }, 500);
  setTimeout(function() {
    wallApply();
  }, 2000);
});

/* Re-apply wallpaper whenever the phone viewer opens */
(function reapplyWallpaper(){
  var _origOpenPhoneViewer = window.openPhoneViewer;
  window.openPhoneViewer = function(model, brand, number) {
    _origOpenPhoneViewer(model, brand, number);
    setTimeout(function() {
      wallApply();
    }, 100);
  };
})();
/* ============================================================
   HOOK: WHATSAPP + WALLPAPER
   ============================================================ */
(function hookWhatsAppWallpaper(){
  var _origOpenApp = window.openApp;
  window.openApp = function(name){
    if (name === 'WhatsApp')  { renderWhatsApp(); return; }
    if (name === 'Wallpaper') { renderWallpaper(); return; }
    return _origOpenApp.apply(this, arguments);
  };
})();

/* Add Wallpaper icon to both home screens */
(function addWallpaperIcon(){
  var makeIcon = function(){
    var el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'W';
    el.setAttribute('data-label', 'Wallpaper');
    el.style.background = 'linear-gradient(135deg,#ff006e,#ff8800)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function(e){
      if (e) e.preventDefault();
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      if (typeof renderWallpaper === 'function') renderWallpaper();
    });
    return el;
  };
  var ip = document.getElementById('iphoneIcons');
  var an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();

/* Direct attach fallback */
(function directAttachWhatsAppWallpaper(){
  function attach() {
    var allApps = document.querySelectorAll('.app');
    for (var i = 0; i < allApps.length; i++) {
      var label = allApps[i].getAttribute('data-label');
      if (label === 'WhatsApp') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderWhatsApp === 'function') renderWhatsApp();
        };
      } else if (label === 'Wallpaper') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderWallpaper === 'function') renderWallpaper();
        };
      }
    }
  }
  setTimeout(attach, 1000);
  setTimeout(attach, 2500);
})();
/* ============================================================
   STOPWATCH (inside Clock)
   ============================================================ */
var swState = { running: false, startTime: 0, elapsed: 0, timer: null, laps: [] };

function swFormat(ms) {
  var t = Math.floor(ms / 10);
  var cs = t % 100;
  var s = Math.floor(t / 100) % 60;
  var m = Math.floor(t / 6000) % 60;
  var h = Math.floor(t / 360000);
  function pad(n, w) { n = String(n); while (n.length < w) n = '0' + n; return n; }
  return pad(h,2) + ':' + pad(m,2) + ':' + pad(s,2) + '.' + pad(cs,2);
}
function swUpdate() {
  var el = document.getElementById('swDisplay');
  if (!el) return;
  var total = swState.elapsed;
  if (swState.running) total += (Date.now() - swState.startTime);
  el.textContent = swFormat(total);
}
function swTick() {
  swUpdate();
}
function swStartStop() {
  if (swState.running) {
    swState.elapsed += (Date.now() - swState.startTime);
    swState.running = false;
    if (swState.timer) { clearInterval(swState.timer); swState.timer = null; }
  } else {
    swState.startTime = Date.now();
    swState.running = true;
    if (swState.timer) clearInterval(swState.timer);
    swState.timer = setInterval(swTick, 30);
  }
  swRender();
}
function swReset() {
  swState.running = false;
  swState.elapsed = 0;
  swState.laps = [];
  if (swState.timer) { clearInterval(swState.timer); swState.timer = null; }
  swRender();
}
function swLap() {
  if (!swState.running) return;
  var total = swState.elapsed + (Date.now() - swState.startTime);
  swState.laps.unshift({ n: swState.laps.length + 1, time: swFormat(total) });
  swRender();
}
function swRender() {
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Stopwatch</h2>';
  h += '<div class="sw-display" id="swDisplay">' + swFormat(swState.elapsed) + '</div>';
  h += '<div class="sw-buttons">';
  h += '<button class="sw-btn ' + (swState.running ? 'stop' : 'start') + '" id="swStartStop">' + (swState.running ? 'PAUSE' : 'START') + '</button>';
  if (swState.running) {
    h += '<button class="sw-btn" id="swLap">LAP</button>';
  } else {
    h += '<button class="sw-btn reset" id="swReset">RESET</button>';
  }
  h += '</div>';
  if (swState.laps.length > 0) {
    h += '<div class="sw-laps">';
    for (var i = 0; i < swState.laps.length; i++) {
      var l = swState.laps[i];
      h += '<div class="sw-lap"><span class="sw-lap-num">Lap ' + l.n + '</span><span class="sw-lap-time">' + l.time + '</span></div>';
    }
    h += '</div>';
  }
  h += '<button class="game-btn" id="swBackToClock" style="margin-top:16px;background:rgba(255,255,255,0.1);color:#fff">BACK TO CLOCK</button>';
  appScreenContent.innerHTML = h;
  document.getElementById('swStartStop').onclick = swStartStop;
  var lapBtn = document.getElementById('swLap');
  if (lapBtn) lapBtn.onclick = swLap;
  var resetBtn = document.getElementById('swReset');
  if (resetBtn) resetBtn.onclick = swReset;
  document.getElementById('swBackToClock').onclick = function() {
    if (swState.running) { alert('Stop the timer first'); return; }
    if (typeof renderClock === 'function') renderClock();
  };
  if (swState.running) {
    if (swState.timer) clearInterval(swState.timer);
    swState.timer = setInterval(swTick, 30);
  }
}

/* ============================================================
   CALENDAR
   ============================================================ */
var calState = { year: 0, month: 0, selected: null };
function calResetToToday() {
  var n = new Date();
  calState.year = n.getFullYear();
  calState.month = n.getMonth();
  calState.selected = n.getDate();
}
function calEventsGet() {
  try { return JSON.parse(localStorage.getItem('calEvents') || '{}'); } catch(e) { return {}; }
}
function calEventsSave(d) { localStorage.setItem('calEvents', JSON.stringify(d)); }
function calKey(y, m, d) { return y + '-' + (m+1) + '-' + d; }
function calRender() {
  var monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  var dayNames = ['S','M','T','W','T','F','S'];
  var today = new Date();
  var isCurrentMonth = (calState.year === today.getFullYear() && calState.month === today.getMonth());

  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Calendar</h2>';
  h += '<div class="cal-header">';
  h += '<button class="cal-nav-btn" id="calPrev">‹</button>';
  h += '<div class="cal-title">' + monthNames[calState.month] + ' ' + calState.year + '</div>';
  h += '<button class="cal-nav-btn" id="calNext">›</button>';
  h += '</div>';
  h += '<div class="cal-grid">';
  for (var d = 0; d < 7; d++) {
    h += '<div class="cal-day-name">' + dayNames[d] + '</div>';
  }
  var firstDay = new Date(calState.year, calState.month, 1).getDay();
  var daysInMonth = new Date(calState.year, calState.month + 1, 0).getDate();
  for (var e = 0; e < firstDay; e++) {
    h += '<div class="cal-day empty"></div>';
  }
  for (var day = 1; day <= daysInMonth; day++) {
    var cls = 'cal-day';
    if (isCurrentMonth && day === today.getDate()) cls += ' today';
    else if (calState.selected === day) cls += ' selected';
    h += '<div class="' + cls + '" data-calday="' + day + '">' + day + '</div>';
  }
  h += '</div>';

  if (calState.selected) {
    var key = calKey(calState.year, calState.month, calState.selected);
    var events = calEventsGet()[key] || [];
    h += '<div class="cal-events-title">EVENTS · ' + monthNames[calState.month] + ' ' + calState.selected + '</div>';
    if (events.length === 0) {
      h += '<div style="text-align:center;color:rgba(255,255,255,0.4);font-size:12px;padding:12px">No events</div>';
    } else {
      for (var x = 0; x < events.length; x++) {
        h += '<div class="cal-event">' + events[x].title + '<div class="cal-event-time">' + events[x].time + '</div></div>';
      }
    }
    h += '<button class="cal-add-btn" id="calAddBtn">+ ADD EVENT</button>';
  }

  appScreenContent.innerHTML = h;

  document.getElementById('calPrev').onclick = function() {
    calState.month--;
    if (calState.month < 0) { calState.month = 11; calState.year--; }
    calState.selected = null;
    calRender();
  };
  document.getElementById('calNext').onclick = function() {
    calState.month++;
    if (calState.month > 11) { calState.month = 0; calState.year++; }
    calState.selected = null;
    calRender();
  };
  var days = appScreenContent.querySelectorAll('[data-calday]');
  for (var y = 0; y < days.length; y++) {
    days[y].onclick = (function(el) {
      return function() {
        calState.selected = parseInt(el.getAttribute('data-calday'), 10);
        calRender();
      };
    })(days[y]);
  }
  var addBtn = document.getElementById('calAddBtn');
  if (addBtn) addBtn.onclick = function() {
    var title = prompt('Event title:');
    if (!title || !title.trim()) return;
    var time = prompt('Time (e.g. 3:00 PM):') || 'All day';
    var key = calKey(calState.year, calState.month, calState.selected);
    var all = calEventsGet();
    if (!all[key]) all[key] = [];
    all[key].push({ title: title, time: time });
    calEventsSave(all);
    calRender();
  };
}
function renderCalendar() {
  calResetToToday();
  calRender();
}

/* ============================================================
   CONTACTS
   ============================================================ */
var contactsList = [
  { name: 'Mom',        number: '+1 (212) 555-0101', color: '#ff006e' },
  { name: 'John Smith', number: '+1 (310) 555-0142', color: '#3ddc84' },
  { name: 'Sarah',      number: '+1 (415) 555-0177', color: '#00e5ff' },
  { name: 'David',      number: '+1 (404) 555-0233', color: '#a855f7' },
  { name: 'Emma',       number: '+1 (617) 555-0188', color: '#ff6699' },
  { name: 'Work Office',number: '+1 (212) 555-0300', color: '#ffcc00' },
  { name: 'Alex',       number: '+1 (305) 555-0456', color: '#1a88ff' },
  { name: 'Lisa',       number: '+1 (702) 555-0911', color: '#ff8800' }
];
function contactsRender(filter) {
  var query = (filter || '').toLowerCase();
  var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 12px">Contacts</h2>';
  h += '<input class="contacts-search" id="ctSearch" type="text" placeholder="Search contacts..." value="' + contactsEscape(filter || '') + '">';
  var count = 0;
  for (var i = 0; i < contactsList.length; i++) {
    var c = contactsList[i];
    if (query && c.name.toLowerCase().indexOf(query) === -1) continue;
    count++;
    h += '<div class="contact-row">';
    h += '<div class="contact-avatar" style="background:' + c.color + '">' + c.name.charAt(0).toUpperCase() + '</div>';
    h += '<div class="contact-info">';
    h += '<div class="contact-name">' + contactsEscape(c.name) + '</div>';
    h += '<div class="contact-number">' + contactsEscape(c.number) + '</div>';
    h += '</div>';
    h += '<div class="contact-actions">';
    h += '<button class="contact-action-btn" data-ctcall="' + contactsEscape(c.name) + '">📞</button>';
    h += '<button class="contact-action-btn" data-ctmsg="' + contactsEscape(c.name) + '">💬</button>';
    h += '</div>';
    h += '</div>';
  }
  if (count === 0) {
    h += '<div style="text-align:center;color:rgba(255,255,255,0.4);font-size:12px;padding:20px">No contacts found</div>';
  }
  appScreenContent.innerHTML = h;

  var search = document.getElementById('ctSearch');
  search.oninput = function() { contactsRender(search.value); };
  search.focus();

  var callBtns = appScreenContent.querySelectorAll('[data-ctcall]');
  for (var j = 0; j < callBtns.length; j++) {
    callBtns[j].onclick = (function(el) {
      return function() {
        var name = el.getAttribute('data-ctcall');
        alert('Calling ' + name + '...');
      };
    })(callBtns[j]);
  }
  var msgBtns = appScreenContent.querySelectorAll('[data-ctmsg]');
  for (var k = 0; k < msgBtns.length; k++) {
    msgBtns[k].onclick = (function(el) {
      return function() {
        var name = el.getAttribute('data-ctmsg');
        alert('Opening chat with ' + name);
      };
    })(msgBtns[k]);
  }
}
function contactsEscape(s) {
  if (s === undefined || s === null) return '';
  return String(s).replace(/[&<>"']/g, function(c) {
    var map = {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
    return map[c];
  });
}
function renderContacts() {
  contactsRender('');
}
/* ============================================================
   HOOK: STOPWATCH + CALENDAR + CONTACTS
   ============================================================ */

/* Override Clock to show a stopwatch button */
(function hookClockStopwatch(){
  var _origRenderClock = window.renderClock;
  window.renderClock = function(){
    function updateClockDisplay() {
      var d = new Date();
      var hh = d.getHours();
      var mm = String(d.getMinutes()).padStart(2, '0');
      var ss = String(d.getSeconds()).padStart(2, '0');
      var h12 = hh % 12 || 12;
      var ampm = hh < 12 ? 'AM' : 'PM';
      var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
      var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
      var timeEl = document.getElementById('liveClockTime');
      if (timeEl) timeEl.textContent = h12 + ':' + mm + ':' + ss + ' ' + ampm;
      var dateEl = document.getElementById('liveClockDate');
      if (dateEl) dateEl.textContent = days[d.getDay()] + ', ' + months[d.getMonth()] + ' ' + d.getDate();
    }

    var h = '<h2 style="color:#00e5ff;font-size:18px;margin:0 0 20px">Clock</h2>';
    h += '<div style="text-align:center;margin-bottom:30px">';
    h += '<div id="liveClockTime" style="font-size:42px;font-weight:200;color:#fff;letter-spacing:2px;font-variant-numeric:tabular-nums">--:--:--</div>';
    h += '<div id="liveClockDate" style="font-size:12px;color:rgba(255,255,255,0.5);margin-top:6px;letter-spacing:1px">Loading...</div>';
    h += '</div>';
    h += '<button class="game-btn" id="openStopwatch" style="font-size:14px;padding:16px 40px">OPEN STOPWATCH</button>';
    appScreenContent.innerHTML = h;

    updateClockDisplay();
    if (window._liveClockInt) clearInterval(window._liveClockInt);
    window._liveClockInt = setInterval(updateClockDisplay, 1000);

    document.getElementById('openStopwatch').onclick = function() {
      swState.elapsed = 0;
      swState.running = false;
      swState.laps = [];
      swRender();
    };
  };
})();

/* Hook Calendar + Contacts into openApp */
(function hookCalContacts(){
  var _origOpenApp = window.openApp;
  window.openApp = function(name){
    if (name === 'Calendar') { renderCalendar(); return; }
    if (name === 'Contacts') { renderContacts(); return; }
    if (name === 'Stopwatch') {
      swState.elapsed = 0;
      swState.running = false;
      swState.laps = [];
      swRender();
      return;
    }
    return _origOpenApp.apply(this, arguments);
  };
})();

/* Add Calendar + Contacts icons to both home screens */
(function addCalContactIcons(){
  function makeCalendar(){
    var el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'C';
    el.setAttribute('data-label', 'Calendar');
    el.style.background = 'linear-gradient(135deg,#ffffff,#dddddd)';
    el.style.color = '#ff2d55';
    el.style.fontWeight = '900';
    el.addEventListener('click', function(e){
      if (e) e.preventDefault();
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      if (typeof renderCalendar === 'function') renderCalendar();
    });
    return el;
  }
  function makeContacts(){
    var el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'C';
    el.setAttribute('data-label', 'Contacts');
    el.style.background = 'linear-gradient(135deg,#3ddc84,#00aa66)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function(e){
      if (e) e.preventDefault();
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      if (typeof renderContacts === 'function') renderContacts();
    });
    return el;
  }
  var ip = document.getElementById('iphoneIcons');
  var an = document.getElementById('androidIcons');
  if (ip) { ip.appendChild(makeCalendar()); ip.appendChild(makeContacts()); }
  if (an) { an.appendChild(makeCalendar()); an.appendChild(makeContacts()); }
})();

/* Direct attach fallback */
(function directAttachCalContacts(){
  function attach() {
    var allApps = document.querySelectorAll('.app');
    for (var i = 0; i < allApps.length; i++) {
      var label = allApps[i].getAttribute('data-label');
      if (label === 'Calendar') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderCalendar === 'function') renderCalendar();
        };
      } else if (label === 'Contacts') {
        allApps[i].onclick = function(e){
          if (e) e.preventDefault();
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderContacts === 'function') renderContacts();
        };
      }
    }
  }
  setTimeout(attach, 1000);
  setTimeout(attach, 2500);
})();
/* ============================================================
   FIX BANK BUTTONS - working version
   ============================================================ */
window.bankAction = function(type) {
  if (type === 'request') { 
    try { alert('Request sent.'); } catch(e) {}
    return; 
  }
  if (type === 'bills') { 
    try { alert('No pending bills.'); } catch(e) {}
    return; 
  }

  var amountStr = '';
  var recipient = '';

  if (type === 'send') {
    try { recipient = prompt('Send to (name):') || ''; } catch(e) { recipient = 'John'; }
    if (!recipient || !recipient.trim()) recipient = 'John';
  }

  try { amountStr = prompt('Amount ($):'); } catch(e) { amountStr = ''; }
  
  // If prompt was blocked, use a default for testing
  if (!amountStr) {
    amountStr = '10';
  }

  var num = parseFloat(amountStr);
  if (isNaN(num) || num <= 0) { 
    try { alert('Invalid amount'); } catch(e) {}
    return; 
  }

  if (type === 'send') {
    if (num > bankState.balance) { 
      try { alert('Insufficient balance'); } catch(e) {}
      return; 
    }
    bankState.balance -= num;
    bankState.transactions.unshift({ name: 'To ' + recipient, amount: num, date: 'Today', type: 'out' });
  } else if (type === 'topup') {
    bankState.balance += num;
    bankState.transactions.unshift({ name: 'Top Up', amount: num, date: 'Today', type: 'in' });
  }

  bankSave();
  bankRender();
};
/* ============================================================
   FORCE WHATSAPP TO OPEN
   ============================================================ */
(function forceWhatsApp(){
  function attach(){
    var apps = document.querySelectorAll('.app');
    for (var i = 0; i < apps.length; i++) {
      var label = apps[i].getAttribute('data-label');
      if (label === 'WhatsApp') {
        apps[i].onclick = null;
        apps[i].onclick = function(e){
          if (e) { e.preventDefault(); e.stopPropagation(); }
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderWhatsApp === 'function') {
            renderWhatsApp();
          } else {
            appScreenContent.innerHTML = '<div style="text-align:center;padding:40px;color:#ff2d55;font-size:14px">WhatsApp function missing</div>';
          }
        };
      }
    }
  }
  setTimeout(attach, 800);
  setTimeout(attach, 2000);
  setTimeout(attach, 4000);
})();
/* ============================================================
   ROBUST FIX - WHATSAPP ICON ON HOME SCREEN
   ============================================================ */
(function robustWhatsAppFix(){
  setInterval(function(){
    var apps = document.querySelectorAll('.app');
    for (var i = 0; i < apps.length; i++) {
      var label = apps[i].getAttribute('data-label');
      if (label === 'WhatsApp' && !apps[i]._waBound) {
        apps[i]._waBound = true;
        apps[i].onclick = function(e){
          if (e) { e.preventDefault(); e.stopPropagation(); }
          if (typeof soundTap === 'function') soundTap();
          appScreen.classList.remove('hidden');
          flipCard.classList.remove('flipped');
          if (typeof renderWhatsApp === 'function') {
            renderWhatsApp();
          } else {
            appScreenContent.innerHTML = '<div style="text-align:center;padding:40px;color:#ff2d55;font-size:14px">WhatsApp function missing</div>';
          }
        };
      }
    }
  }, 400);
})();