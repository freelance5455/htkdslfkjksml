const panel=document.getElementById('panel'),bar=document.getElementById('bar');
const min=document.getElementById('min'), close=document.getElementById('close');
const fov=document.getElementById('fov'), out=document.getElementById('fovValue');

min.onclick=()=>{panel.classList.toggle('minimized');min.textContent=panel.classList.contains('minimized')?'＋':'−'};
close.onclick=()=>panel.remove();
fov.oninput=()=>out.textContent=fov.value+'°';

let dragging=false,sx=0,sy=0,ox=0,oy=0;
bar.addEventListener('pointerdown',e=>{
  if(e.target.tagName==='BUTTON') return;
  dragging=true; bar.setPointerCapture(e.pointerId);
  sx=e.clientX; sy=e.clientY;
  const r=panel.getBoundingClientRect(); ox=r.left; oy=r.top;
});
bar.addEventListener('pointermove',e=>{
  if(!dragging)return;
  panel.style.left=Math.max(0,Math.min(innerWidth-panel.offsetWidth,ox+e.clientX-sx))+'px';
  panel.style.top=Math.max(0,Math.min(innerHeight-panel.offsetHeight,oy+e.clientY-sy))+'px';
});
bar.addEventListener('pointerup',()=>dragging=false);

const aimbot=document.getElementById('aimbot');
if(aimbot) aimbot.addEventListener('change',()=>panel.dataset.aimbot=aimbot.checked?'on':'off');
