const nouns = [
  {
    word: "كتاب",
    meaning: "مجموعة من الصفحات المكتوبة أو المطبوعة المرتبة.",
    root: "ك ت ب",
    pattern: "فِعال",
    type: "اسم جامد",
    gender: "مذكر",
    singular: "كتاب",
    dual: "كتابان",
    plural: "كتب",
    derivatives: "كاتب، مكتوب، كتابة، مكتبة",
    synonyms: "مؤلَّف، مصنَّف",
    antonyms: "لا مضاد مباشر",
    example: "قرأتُ كتابًا مفيدًا.",
    parsing: "كتابًا: مفعول به منصوب بالفتحة."
  },
  {
    word: "قلم",
    meaning: "أداة تُستخدم في الكتابة.",
    root: "ق ل م",
    pattern: "فَعَل",
    type: "اسم جامد",
    gender: "مذكر",
    singular: "قلم",
    dual: "قلمان",
    plural: "أقلام",
    derivatives: "قَلَمَ، تقليم",
    synonyms: "يراع",
    antonyms: "لا مضاد مباشر",
    example: "كتب الطالب بالقلم.",
    parsing: "القلم: اسم مجرور بالباء."
  },
  {
    word: "مدرسة",
    meaning: "مكان يتعلم فيه الطلاب.",
    root: "د ر س",
    pattern: "مَفْعَلَة",
    type: "اسم مشتق",
    gender: "مؤنث",
    singular: "مدرسة",
    dual: "مدرستان",
    plural: "مدارس",
    derivatives: "درس، دارس، مدرّس، دراسة",
    synonyms: "مَعْلَم تعليمي",
    antonyms: "لا مضاد مباشر",
    example: "ذهبتُ إلى المدرسة.",
    parsing: "المدرسة: اسم مجرور بإلى."
  },
  {
    word: "طالب",
    meaning: "من يطلب العلم أو المعرفة.",
    root: "ط ل ب",
    pattern: "فاعِل",
    type: "اسم فاعل",
    gender: "مذكر",
    singular: "طالب",
    dual: "طالبان",
    plural: "طلاب، طلبة",
    derivatives: "طلب، مطلوب، مطالبة",
    synonyms: "متعلم، دارس",
    antonyms: "لا مضاد مباشر",
    example: "الطالب مجتهد.",
    parsing: "الطالب: مبتدأ مرفوع."
  },
  {
    word: "معلم",
    meaning: "من يقوم بتعليم الآخرين.",
    root: "ع ل م",
    pattern: "مُفَعِّل",
    type: "اسم فاعل من علّم",
    gender: "مذكر",
    singular: "معلم",
    dual: "معلمان",
    plural: "معلمون",
    derivatives: "علم، تعليم، عالم، معلوم",
    synonyms: "مدرّس، مربٍّ",
    antonyms: "متعلم",
    example: "شرح المعلم الدرس.",
    parsing: "المعلم: فاعل مرفوع."
  },
  {
    word: "شجرة",
    meaning: "نبات له جذع وأغصان.",
    root: "ش ج ر",
    pattern: "فَعَلَة",
    type: "اسم جامد",
    gender: "مؤنث",
    singular: "شجرة",
    dual: "شجرتان",
    plural: "أشجار",
    derivatives: "تشاجر، شجار",
    synonyms: "نبتة خشبية",
    antonyms: "لا مضاد مباشر",
    example: "أثمرت الشجرة.",
    parsing: "الشجرة: فاعل مرفوع."
  },
  {
    word: "مكتبة",
    meaning: "مكان تحفظ فيه الكتب أو تُباع.",
    root: "ك ت ب",
    pattern: "مَفْعَلَة",
    type: "اسم مكان",
    gender: "مؤنث",
    singular: "مكتبة",
    dual: "مكتبتان",
    plural: "مكتبات",
    derivatives: "كتاب، كاتب، كتابة، مكتوب",
    synonyms: "خزانة كتب",
    antonyms: "لا مضاد مباشر",
    example: "زرت المكتبة.",
    parsing: "المكتبة: مفعول به منصوب."
  },
  {
    word: "زهرة",
    meaning: "جزء من النبات يتميز بألوانه ورائحته.",
    root: "ز ه ر",
    pattern: "فَعْلَة",
    type: "اسم جامد",
    gender: "مؤنث",
    singular: "زهرة",
    dual: "زهرتان",
    plural: "زهرات، أزهار",
    derivatives: "زهر، أزهر، زاهر",
    synonyms: "وردة",
    antonyms: "لا مضاد مباشر",
    example: "تفتحت الزهرة.",
    parsing: "الزهرة: فاعل مرفوع."
  },
  {
    word: "مهندس",
    meaning: "شخص متخصص في تصميم الأشياء والأنظمة وتنفيذها.",
    root: "ه ن د س",
    pattern: "مُفَعْلِل",
    type: "اسم فاعل",
    gender: "مذكر",
    singular: "مهندس",
    dual: "مهندسان",
    plural: "مهندسون",
    derivatives: "هندسة",
    synonyms: "مصمم تقني",
    antonyms: "لا مضاد مباشر",
    example: "صمم المهندس المبنى.",
    parsing: "المهندس: فاعل مرفوع."
  },
  {
    word: "طبيب",
    meaning: "شخص متخصص في تشخيص الأمراض وعلاجها.",
    root: "ط ب ب",
    pattern: "فعيل",
    type: "اسم مشتق",
    gender: "مذكر",
    singular: "طبيب",
    dual: "طبيبان",
    plural: "أطباء",
    derivatives: "طب، تطبيب",
    synonyms: "معالج",
    antonyms: "مريض من حيث الحال لا من حيث المعنى",
    example: "فحص الطبيب المريض.",
    parsing: "الطبيب: فاعل مرفوع."
  }
];

const verbs = [
  {
    word: "كتب",
    meaning: "خطّ الحروف والكلمات.",
    root: "ك ت ب",
    pattern: "فَعَلَ",
    past: "كتب",
    present: "يكتب",
    imperative: "اكتب",
    verbalNoun: "كتابة",
    activeParticiple: "كاتب",
    passiveParticiple: "مكتوب",
    transitivity: "متعدٍّ",
    letters: "ك، ت، ب",
    extraLetters: "لا توجد",
    synonyms: "دوّن، سجّل",
    antonyms: "محا",
    example: "كتب الطالب الدرس.",
    conjugation: "أنا كتبتُ، نحن كتبنا، أنتَ كتبتَ، أنتِ كتبتِ، أنتما كتبتما، أنتم كتبتم، أنتن كتبتن، هو كتب، هي كتبت، هما كتبا، هما كتبتا، هم كتبوا، هن كتبن."
  },
  {
    word: "قرأ",
    meaning: "تلا الكلمات وفهمها.",
    root: "ق ر أ",
    pattern: "فَعَلَ",
    past: "قرأ",
    present: "يقرأ",
    imperative: "اقرأ",
    verbalNoun: "قراءة",
    activeParticiple: "قارئ",
    passiveParticiple: "مقروء",
    transitivity: "متعدٍّ",
    letters: "ق، ر، أ",
    extraLetters: "لا توجد",
    synonyms: "تلا، طالع",
    antonyms: "أهمل القراءة",
    example: "قرأ الطفل القصة.",
    conjugation: "أنا قرأتُ، نحن قرأنا، أنتَ قرأتَ، أنتِ قرأتِ، أنتما قرأتما، أنتم قرأتم، أنتن قرأتن، هو قرأ، هي قرأت، هما قرآ، هما قرأتا، هم قرؤوا، هن قرأن."
  },
  {
    word: "جلس",
    meaning: "استقر على مقعد أو نحو ذلك.",
    root: "ج ل س",
    pattern: "فَعَلَ",
    past: "جلس",
    present: "يجلس",
    imperative: "اجلس",
    verbalNoun: "جلوس",
    activeParticiple: "جالس",
    passiveParticiple: "لا يستعمل عادة",
    transitivity: "لازم",
    letters: "ج، ل، س",
    extraLetters: "لا توجد",
    synonyms: "قعد",
    antonyms: "وقف",
    example: "جلس الطالب.",
    conjugation: "أنا جلستُ، نحن جلسنا، أنتَ جلستَ، أنتِ جلستِ، أنتما جلستما، أنتم جلستم، أنتن جلستن، هو جلس، هي جلست، هما جلسا، هما جلستا، هم جلسوا، هن جلسن."
  },
  {
    word: "فتح",
    meaning: "جعل الشيء مغلقًا غير مغلق.",
    root: "ف ت ح",
    pattern: "فَعَلَ",
    past: "فتح",
    present: "يفتح",
    imperative: "افتح",
    verbalNoun: "فتح",
    activeParticiple: "فاتح",
    passiveParticiple: "مفتوح",
    transitivity: "متعدٍّ",
    letters: "ف، ت، ح",
    extraLetters: "لا توجد",
    synonyms: "كشف",
    antonyms: "أغلق",
    example: "فتح المعلم الباب.",
    conjugation: "أنا فتحتُ، نحن فتحنا، أنتَ فتحتَ، أنتِ فتحتِ، أنتما فتحتما، أنتم فتحتم، أنتن فتحتن، هو فتح، هي فتحت، هما فتحا، هما فتحتا، هم فتحوا، هن فتحن."
  },
  {
    word: "خرج",
    meaning: "غادر المكان.",
    root: "خ ر ج",
    pattern: "فَعَلَ",
    past: "خرج",
    present: "يخرج",
    imperative: "اخرج",
    verbalNoun: "خروج",
    activeParticiple: "خارج",
    passiveParticiple: "لا يستعمل عادة",
    transitivity: "لازم غالبًا",
    letters: "خ، ر، ج",
    extraLetters: "لا توجد",
    synonyms: "غادر",
    antonyms: "دخل",
    example: "خرج الطالب من الفصل.",
    conjugation: "أنا خرجتُ، نحن خرجنا، أنتَ خرجتَ، أنتِ خرجتِ، أنتما خرجتما، أنتم خرجتم، أنتن خرجتن، هو خرج، هي خرجت، هما خرجا، هما خرجتا، هم خرجوا، هن خرجن."
  },
  {
    word: "استخرج",
    meaning: "أخرج شيئًا من موضعه.",
    root: "خ ر ج",
    pattern: "استفعل",
    past: "استخرج",
    present: "يستخرج",
    imperative: "استخرج",
    verbalNoun: "استخراج",
    activeParticiple: "مستخرِج",
    passiveParticiple: "مستخرَج",
    transitivity: "متعدٍّ",
    letters: "خ، ر، ج",
    extraLetters: "الألف والسين والتاء",
    synonyms: "أخرج، استنبط",
    antonyms: "أدخل",
    example: "استخرج الباحث النتيجة.",
    conjugation: "أنا استخرجتُ، نحن استخرجنا، أنتَ استخرجتَ، أنتِ استخرجتِ، أنتما استخرجتما، أنتم استخرجتم، أنتن استخرجتن، هو استخرج، هي استخرجت، هما استخرجا، هما استخرجتا، هم استخرجوا، هن استخرجن."
  },
  {
    word: "تعاون",
    meaning: "ساعد بعضهم بعضًا.",
    root: "ع و ن",
    pattern: "تفاعل",
    past: "تعاون",
    present: "يتعاون",
    imperative: "تعاون",
    verbalNoun: "تعاون",
    activeParticiple: "متعاون",
    passiveParticiple: "لا يستعمل عادة",
    transitivity: "لازم غالبًا",
    letters: "ع، و، ن",
    extraLetters: "التاء والألف",
    synonyms: "تآزر، تكاتف",
    antonyms: "تنازع",
    example: "تعاون الطلاب في العمل.",
    conjugation: "أنا تعاونتُ، نحن تعاونّا، أنتَ تعاونتَ، أنتِ تعاونتِ، أنتما تعاونتما، أنتم تعاونتم، أنتن تعاونتن، هو تعاون، هي تعاونت، هما تعاونا، هما تعاونتا، هم تعاونوا، هن تعاوَنَّ."
  },
  {
    word: "أحسن",
    meaning: "أتقن العمل أو جعله حسنًا.",
    root: "ح س ن",
    pattern: "أفعل",
    past: "أحسن",
    present: "يحسن",
    imperative: "أحسن",
    verbalNoun: "إحسان",
    activeParticiple: "مُحسِن",
    passiveParticiple: "مُحسَن إليه بحسب السياق",
    transitivity: "قد يكون لازمًا أو متعديًا بحسب المعنى",
    letters: "ح، س، ن",
    extraLetters: "الهمزة",
    synonyms: "أتقن، أجاد",
    antonyms: "أساء",
    example: "أحسن الطالب الإجابة.",
    conjugation: "أنا أحسنتُ، نحن أحسنّا، أنتَ أحسنتَ، أنتِ أحسنتِ، أنتما أحسنتما، أنتم أحسنتم، أنتن أحسنتن، هو أحسن، هي أحسنت، هما أحسنا، هما أحسنتا، هم أحسنوا، هن أحسنَّ."
  },
  {
    word: "شارك",
    meaning: "ساهم مع غيره في عمل.",
    root: "ش ر ك",
    pattern: "فاعل",
    past: "شارك",
    present: "يشارك",
    imperative: "شارك",
    verbalNoun: "مشاركة",
    activeParticiple: "مشارك",
    passiveParticiple: "مشارَك فيه بحسب السياق",
    transitivity: "يتعدى غالبًا بحرف الجر في",
    letters: "ش، ر، ك",
    extraLetters: "الألف",
    synonyms: "ساهم، أسهم",
    antonyms: "انفرد",
    example: "شارك الطالب في المسابقة.",
    conjugation: "أنا شاركتُ، نحن شاركنا، أنتَ شاركتَ، أنتِ شاركتِ، أنتما شاركتما، أنتم شاركتم، أنتن شاركتن، هو شارك، هي شاركت، هما شاركا، هما شاركتا، هم شاركوا، هن شاركن."
  },
  {
    word: "تعلم",
    meaning: "اكتسب المعرفة أو المهارة.",
    root: "ع ل م",
    pattern: "تفعّل",
    past: "تعلّم",
    present: "يتعلّم",
    imperative: "تعلّم",
    verbalNoun: "تعلُّم",
    activeParticiple: "متعلّم",
    passiveParticiple: "متعلَّم",
    transitivity: "متعدٍّ أو لازم بحسب السياق",
    letters: "ع، ل، م",
    extraLetters: "التاء وتضعيف اللام",
    synonyms: "درس، اكتسب المعرفة",
    antonyms: "جهل",
    example: "تعلّم الطفل القراءة.",
    conjugation: "أنا تعلمتُ، نحن تعلمنا، أنتَ تعلمتَ، أنتِ تعلمتِ، أنتما تعلمتما، أنتم تعلمتم، أنتن تعلمتن، هو تعلم، هي تعلمت، هما تعلما، هما تعلمتا، هم تعلموا، هن تعلمن."
  }
];

const wordList = document.getElementById("wordList");
const listTitle = document.getElementById("listTitle");
const results = document.getElementById("results");
const searchInput = document.getElementById("searchInput");

function showList(type) {
  const data = type === "nouns" ? nouns : verbs;

  listTitle.textContent = type === "nouns" ? "قائمة الأسماء" : "قائمة الأفعال";
  wordList.innerHTML = "";

  data.forEach(item => {
    const button = document.createElement("button");
    button.className = "word-button";
    button.textContent = item.word;
    button.addEventListener("click", () => showDetails(item));
    wordList.appendChild(button);
  });

  results.textContent = "اختاري كلمة لعرض جميع بياناتها.";
}

function showDetails(item) {
  results.innerHTML = "";

  const heading = document.createElement("h2");
  heading.textContent = item.word;
  results.appendChild(heading);

  Object.entries(item).forEach(([key, value]) => {
    if (key === "word") return;

    const row = document.createElement("p");
    const label = document.createElement("strong");
    const content = document.createElement("span");

    const labels = {
      meaning: "المعنى",
      root: "الجذر",
      pattern: "الوزن",
      type: "النوع",
      gender: "الجنس",
      singular: "المفرد",
      dual: "المثنى",
      plural: "الجمع",
      derivatives: "المشتقات",
      synonyms: "المرادفات",
      antonyms: "الأضداد",
      example: "مثال",
      parsing: "الإعراب",
      past: "الماضي",
      present: "المضارع",
      imperative: "الأمر",
      verbalNoun: "المصدر",
      activeParticiple: "اسم الفاعل",
      passiveParticiple: "اسم المفعول",
      transitivity: "التعدي واللزوم",
      letters: "الحروف الأصلية",
      extraLetters: "حروف الزيادة",
      conjugation: "التصريف مع الضمائر"
    };

    label.textContent = (labels[key] || key) + ": ";
    content.textContent = value;

    row.append(label, content);
    results.appendChild(row);
  });
}

document.getElementById("nounsButton")
  .addEventListener("click", () => showList("nouns"));

document.getElementById("verbsButton")
  .addEventListener("click", () => showList("verbs"));

function searchWord() {
  const query = searchInput.value.trim();
  const item = [...nouns, ...verbs].find(
    word => word.word === query
  );

  if (item) {
    showDetails(item);
  } else {
    results.textContent = "الكلمة غير موجودة في المعجم الحالي.";
  }
}

document.getElementById("searchButton")
  .addEventListener("click", searchWord);

searchInput.addEventListener("keydown", event => {
  if (event.key === "Enter") searchWord();
});// تطوير عرض بطاقة تفاصيل الكلمة
function showDetails(item) {
  results.innerHTML = "";

  const title = document.createElement("h2");
  title.textContent = item.word;
  results.appendChild(title);

  const sections = [
    {
      title: "البيانات الأساسية",
      keys: ["meaning", "type", "gender"]
    },
    {
      title: "التحليل الصرفي",
      keys: ["root", "pattern", "letters", "extraLetters"]
    },
    {
      title: "التصريف",
      keys: [
        "singular", "dual", "plural",
        "past", "present", "imperative",
        "verbalNoun", "activeParticiple",
        "passiveParticiple", "conjugation"
      ]
    },
    {
      title: "المشتقات والعلاقات اللغوية",
      keys: ["derivatives", "synonyms", "antonyms", "transitivity"]
    },
    {
      title: "التطبيق",
      keys: ["example", "parsing"]
    }
  ];

  const labels = {
    meaning: "المعنى",
    type: "النوع",
    gender: "الجنس",
    root: "الجذر",
    pattern: "الوزن",
    letters: "الحروف الأصلية",
    extraLetters: "حروف الزيادة",
    singular: "المفرد",
    dual: "المثنى",
    plural: "الجمع",
    past: "الماضي",
    present: "المضارع",
    imperative: "الأمر",
    verbalNoun: "المصدر",
    activeParticiple: "اسم الفاعل",
    passiveParticiple: "اسم المفعول",
    conjugation: "التصريف مع الضمائر",
    derivatives: "المشتقات",
    synonyms: "المرادفات",
    antonyms: "الأضداد",
    transitivity: "التعدي واللزوم",
    example: "مثال",
    parsing: "الإعراب"
  };

  sections.forEach(section => {
    const available = section.keys.filter(
      key => item[key] !== undefined
    );

    if (!available.length) return;

    const card = document.createElement("div");
    card.className = "detail-group";

    const heading = document.createElement("h3");
    heading.textContent = section.title;
    card.appendChild(heading);

    available.forEach(key => {
      const row = document.createElement("div");
      row.className = "detail-item";

      const label = document.createElement("strong");
      label.textContent = labels[key] + ":";

      const value = document.createElement("p");
      value.textContent = item[key];

      row.append(label, value);
      card.appendChild(row);
    });

    results.appendChild(card);
  });
}// تحويل تصريف الفعل إلى جدول منظم
const oldShowDetails = showDetails;

showDetails = function(item) {
  oldShowDetails(item);

  if (!item.conjugation) return;

  const rows = document.querySelectorAll(".detail-item");

  rows.forEach(row => {
    const label = row.querySelector("strong");

    if (
      !label ||
      label.textContent !== "التصريف مع الضمائر:"
    ) return;

    const paragraph = row.querySelector("p");
    if (!paragraph) return;

    const entries = item.conjugation
      .split("،")
      .map(part => part.trim());

    const table = document.createElement("table");
    table.className = "conjugation-table";

    const head = document.createElement("thead");
    head.innerHTML = `
      <tr>
        <th>الضمير</th>
        <th>التصريف</th>
      </tr>
    `;

    const body = document.createElement("tbody");

    entries.forEach(entry => {
      const space = entry.indexOf(" ");
      if (space === -1) return;

      const pronoun = entry.slice(0, space);
      const verb = entry.slice(space + 1);

      const tr = document.createElement("tr");
      const td1 = document.createElement("td");
      const td2 = document.createElement("td");

      td1.textContent = pronoun;
      td2.textContent = verb;

      tr.append(td1, td2);
      body.appendChild(tr);
    });

    table.append(head, body);
    paragraph.replaceWith(table);
  });
};// جداول الماضي والمضارع للأفعال
const verbConjugations = {
  "كتب": {
    past: "كتب",
    present: [
      "يكتب", "يكتبان", "يكتبون",
      "تكتب", "تكتبان", "يكتبن",
      "تكتب", "تكتبان", "تكتبون",
      "تكتبين", "تكتبان", "تكتبن",
      "أكتب", "نكتب"
    ]
  },
  "قرأ": {
    past: "قرأ",
    present: [
      "يقرأ", "يقرآن", "يقرؤون",
      "تقرأ", "تقرآن", "يقرأن",
      "تقرأ", "تقرآن", "تقرؤون",
      "تقرئين", "تقرآن", "تقرأن",
      "أقرأ", "نقرأ"
    ]
  },
  "جلس": {
    past: "جلس",
    present: [
      "يجلس", "يجلسان", "يجلسون",
      "تجلس", "تجلسان", "يجلسن",
      "تجلس", "تجلسان", "تجلسون",
      "تجلسين", "تجلسان", "تجلسن",
      "أجلس", "نجلس"
    ]
  },
  "فتح": {
    past: "فتح",
    present: [
      "يفتح", "يفتحان", "يفتحون",
      "تفتح", "تفتحان", "يفتحن",
      "تفتح", "تفتحان", "تفتحون",
      "تفتحين", "تفتحان", "تفتحن",
      "أفتح", "نفتح"
    ]
  },
  "خرج": {
    past: "خرج",
    present: [
      "يخرج", "يخرجان", "يخرجون",
      "تخرج", "تخرجان", "يخرجن",
      "تخرج", "تخرجان", "تخرجون",
      "تخرجين", "تخرجان", "تخرجن",
      "أخرج", "نخرج"
    ]
  },
  "استخرج": {
    past: "استخرج",
    present: [
      "يستخرج", "يستخرجان", "يستخرجون",
      "تستخرج", "تستخرجان", "يستخرجن",
      "تستخرج", "تستخرجان", "تستخرجون",
      "تستخرجين", "تستخرجان", "تستخرجن",
      "أستخرج", "نستخرج"
    ]
  },
  "تعاون": {
    past: "تعاون",
    present: [
      "يتعاون", "يتعاونان", "يتعاونون",
      "تتعاون", "تتعاونان", "يتعاونن",
      "تتعاون", "تتعاونان", "تتعاونون",
      "تتعاونين", "تتعاونان", "تتعاونن",
      "أتعاون", "نتعاون"
    ]
  },
  "أحسن": {
    past: "أحسن",
    present: [
      "يحسن", "يحسنان", "يحسنون",
      "تحسن", "تحسنان", "يحسنن",
      "تحسن", "تحسنان", "تحسنون",
      "تحسنين", "تحسنان", "تحسنن",
      "أحسن", "نحسن"
    ]
  },
  "شارك": {
    past: "شارك",
    present: [
      "يشارك", "يشاركان", "يشاركون",
      "تشارك", "تشاركان", "يشاركن",
      "تشارك", "تشاركان", "تشاركون",
      "تشاركين", "تشاركان", "تشاركن",
      "أشارك", "نشارك"
    ]
  },
  "تعلم": {
    past: "تعلم",
    present: [
      "يتعلم", "يتعلمان", "يتعلمون",
      "تتعلم", "تتعلمان", "يتعلمن",
      "تتعلم", "تتعلمان", "تتعلمون",
      "تتعلمين", "تتعلمان", "تتعلمن",
      "أتعلم", "نتعلم"
    ]
  }
};

const pronouns14 = [
  "هو", "هما (مذكر)", "هم",
  "هي", "هما (مؤنث)", "هن",
  "أنتَ", "أنتما (مذكر)", "أنتم",
  "أنتِ", "أنتما (مؤنث)", "أنتن",
  "أنا", "نحن"
];

const pastEndings14 = [
  "", "ا", "وا", "ت", "تا", "ن",
  "ت", "تما", "تم", "تِ", "تما", "تن",
  "تُ", "نا"
];

const previousDetailsDisplay = showDetails;

showDetails = function(item) {
  previousDetailsDisplay(item);

  if (!verbConjugations[item.word]) return;

  const data = verbConjugations[item.word];

  const detailRows = document.querySelectorAll(".detail-item");

  detailRows.forEach(row => {
    const label = row.querySelector("strong");

    if (
      !label ||
      label.textContent !== "التصريف مع الضمائر:"
    ) return;

    row.innerHTML = "";

    const heading = document.createElement("strong");
    heading.textContent = "تصريف الماضي والمضارع مع الضمائر الأربعة عشر";
    row.appendChild(heading);

    const table = document.createElement("table");
    table.className = "conjugation-table";

    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");

    ["الضمير", "الماضي", "المضارع"].forEach(title => {
      const th = document.createElement("th");
      th.textContent = title;
      headerRow.appendChild(th);
    });

    thead.appendChild(headerRow);
    table.appendChild(thead);

    const tbody = document.createElement("tbody");

    pronouns14.forEach((pronoun, index) => {
      const tr = document.createElement("tr");

      const tdPronoun = document.createElement("td");
      const tdPast = document.createElement("td");
      const tdPresent = document.createElement("td");

      tdPronoun.textContent = pronoun;

      let pastForm = data.past + pastEndings14[index];

      if (item.word === "قرأ" && index === 2) {
        pastForm = "قرؤوا";
      }

      tdPast.textContent = pastForm;
      tdPresent.textContent = data.present[index];

      tr.append(tdPronoun, tdPast, tdPresent);
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    row.appendChild(table);
  });
};// تصريف فعل الأمر مع ضمائر المخاطب الستة
const imperativeForms = {
  "كتب": ["اكتب", "اكتبا", "اكتبوا", "اكتبي", "اكتبا", "اكتبن"],
  "قرأ": ["اقرأ", "اقرآ", "اقرأوا", "اقرئي", "اقرآ", "اقرأن"],
  "جلس": ["اجلس", "اجلسا", "اجلسوا", "اجلسي", "اجلسا", "اجلسن"],
  "فتح": ["افتح", "افتحا", "افتحوا", "افتحي", "افتحا", "افتحن"],
  "خرج": ["اخرج", "اخرجا", "اخرجوا", "اخرجي", "اخرجا", "اخرجن"],
  "استخرج": ["استخرج", "استخرجا", "استخرجوا", "استخرجي", "استخرجا", "استخرجن"],
  "تعاون": ["تعاون", "تعاونا", "تعاونوا", "تعاوني", "تعاونا", "تعاونن"],
  "أحسن": ["أحسن", "أحسنا", "أحسنوا", "أحسني", "أحسنا", "أحسنّ"],
  "شارك": ["شارك", "شاركا", "شاركوا", "شاركي", "شاركا", "شاركن"],
  "تعلم": ["تعلم", "تعلما", "تعلموا", "تعلمي", "تعلما", "تعلمن"]
};

const imperativePronouns = [
  "أنتَ",
  "أنتما (مذكر)",
  "أنتم",
  "أنتِ",
  "أنتما (مؤنث)",
  "أنتن"
];

const previousShowWithPastPresent = showDetails;

showDetails = function(item) {
  previousShowWithPastPresent(item);

  const forms = imperativeForms[item.word];
  if (!forms) return;

  const group = document.createElement("div");
  group.className = "detail-group";

  const heading = document.createElement("h3");
  heading.textContent = "تصريف فعل الأمر";
  group.appendChild(heading);

  const table = document.createElement("table");
  table.className = "conjugation-table";

  const thead = document.createElement("thead");
  thead.innerHTML = "<tr><th>الضمير</th><th>فعل الأمر</th></tr>";
  table.appendChild(thead);

  const tbody = document.createElement("tbody");

  imperativePronouns.forEach((pronoun, index) => {
    const tr = document.createElement("tr");

    const td1 = document.createElement("td");
    const td2 = document.createElement("td");

    td1.textContent = pronoun;
    td2.textContent = forms[index];

    tr.append(td1, td2);
    tbody.appendChild(tr);
  });

  table.appendChild(tbody);
  group.appendChild(table);
  results.appendChild(group);
};// بطاقة الميزان الصرفي التفصيلي للأفعال
const detailedVerbWeights = {
  "كتب": {
    root: "ك ت ب",
    weight: "فَعَلَ",
    kind: "ثلاثي مجرد",
    original: "3 حروف",
    added: "لا توجد حروف زائدة",
    count: "ثلاثة أحرف"
  },
  "قرأ": {
    root: "ق ر أ",
    weight: "فَعَلَ",
    kind: "ثلاثي مجرد مهموز اللام",
    original: "3 حروف",
    added: "لا توجد حروف زائدة",
    count: "ثلاثة أحرف"
  },
  "جلس": {
    root: "ج ل س",
    weight: "فَعَلَ",
    kind: "ثلاثي مجرد",
    original: "3 حروف",
    added: "لا توجد حروف زائدة",
    count: "ثلاثة أحرف"
  },
  "فتح": {
    root: "ف ت ح",
    weight: "فَعَلَ",
    kind: "ثلاثي مجرد",
    original: "3 حروف",
    added: "لا توجد حروف زائدة",
    count: "ثلاثة أحرف"
  },
  "خرج": {
    root: "خ ر ج",
    weight: "فَعَلَ",
    kind: "ثلاثي مجرد",
    original: "3 حروف",
    added: "لا توجد حروف زائدة",
    count: "ثلاثة أحرف"
  },
  "استخرج": {
    root: "خ ر ج",
    weight: "اسْتَفْعَلَ",
    kind: "ثلاثي مزيد بثلاثة أحرف",
    original: "خ، ر، ج",
    added: "الألف والسين والتاء",
    count: "ستة أحرف"
  },
  "تعاون": {
    root: "ع و ن",
    weight: "تَفَاعَلَ",
    kind: "ثلاثي مزيد بحرفين",
    original: "ع، و، ن",
    added: "التاء والألف",
    count: "خمسة أحرف"
  },
  "أحسن": {
    root: "ح س ن",
    weight: "أَفْعَلَ",
    kind: "ثلاثي مزيد بحرف واحد",
    original: "ح، س، ن",
    added: "الهمزة",
    count: "أربعة أحرف"
  },
  "شارك": {
    root: "ش ر ك",
    weight: "فَاعَلَ",
    kind: "ثلاثي مزيد بحرف واحد",
    original: "ش، ر، ك",
    added: "الألف",
    count: "أربعة أحرف"
  },
  "تعلم": {
    root: "ع ل م",
    weight: "تَفَعَّلَ",
    kind: "ثلاثي مزيد بحرفين",
    original: "ع، ل، م",
    added: "التاء والتضعيف",
    count: "أربعة أحرف"
  }
};

const previousWeightDisplay = showDetails;

showDetails = function(item) {
  previousWeightDisplay(item);

  const data = detailedVerbWeights[item.word];
  if (!data) return;

  const card = document.createElement("div");
  card.className = "detail-group";

  const heading = document.createElement("h3");
  heading.textContent = "الميزان الصرفي التفصيلي";
  card.appendChild(heading);

  const fields = [
    ["الجذر", data.root],
    ["الوزن الصرفي", data.weight],
    ["نوع الفعل", data.kind],
    ["الحروف الأصلية", data.original],
    ["حروف الزيادة", data.added],
    ["عدد أحرف الفعل", data.count]
  ];

  fields.forEach(([name, value]) => {
    const row = document.createElement("div");
    row.className = "detail-item";

    const label = document.createElement("strong");
    label.textContent = name;

    const content = document.createElement("p");
    content.textContent = value;

    row.append(label, content);
    card.appendChild(row);
  });

  results.appendChild(card);
};// التحليل الصرفي التفصيلي للأسماء
const nounAnalysis = {
  "كتاب": {
    kind: "اسم جامد",
    feminine: "لا توجد علامة تأنيث",
    pluralType: "جمع تكسير",
    feminineForm: "لا يوجد مؤنث شائع مباشر",
    note: "اسم مفرد مذكر"
  },
  "قلم": {
    kind: "اسم جامد",
    feminine: "لا توجد علامة تأنيث",
    pluralType: "جمع تكسير",
    feminineForm: "لا يوجد مؤنث شائع مباشر",
    note: "اسم مفرد مذكر"
  },
  "مدرسة": {
    kind: "اسم مكان",
    feminine: "التاء المربوطة",
    pluralType: "جمع تكسير",
    feminineForm: "مؤنث بالفعل",
    note: "اسم مشتق من الفعل درس"
  },
  "طالب": {
    kind: "اسم فاعل",
    feminine: "لا توجد علامة تأنيث في صيغة المذكر",
    pluralType: "جمع تكسير",
    feminineForm: "طالبة",
    note: "اسم مشتق من الفعل طلب"
  },
  "معلم": {
    kind: "اسم فاعل من علّم",
    feminine: "لا توجد علامة تأنيث في صيغة المذكر",
    pluralType: "جمع مذكر سالم",
    feminineForm: "معلمة",
    note: "اسم مشتق من الفعل علّم"
  },
  "شجرة": {
    kind: "اسم جامد",
    feminine: "التاء المربوطة",
    pluralType: "جمع تكسير",
    feminineForm: "مؤنث بالفعل",
    note: "اسم مفرد مؤنث"
  },
  "مكتبة": {
    kind: "اسم مكان",
    feminine: "التاء المربوطة",
    pluralType: "جمع مؤنث سالم في مكتبات، وله جمع تكسير: مكاتب",
    feminineForm: "مؤنث بالفعل",
    note: "اسم مشتق من الجذر كتب"
  },
  "زهرة": {
    kind: "اسم جامد",
    feminine: "التاء المربوطة",
    pluralType: "جمع تكسير وجمع مؤنث سالم",
    feminineForm: "مؤنث بالفعل",
    note: "اسم مفرد مؤنث"
  },
  "مهندس": {
    kind: "اسم مهنة",
    feminine: "لا توجد علامة تأنيث في صيغة المذكر",
    pluralType: "جمع مذكر سالم",
    feminineForm: "مهندسة",
    note: "اسم يدل على صاحب مهنة"
  },
  "طبيب": {
    kind: "اسم مهنة",
    feminine: "لا توجد علامة تأنيث في صيغة المذكر",
    pluralType: "جمع تكسير",
    feminineForm: "طبيبة",
    note: "اسم يدل على صاحب مهنة"
  }
};

const previousNounDisplay = showDetails;

showDetails = function(item) {
  previousNounDisplay(item);

  const data = nounAnalysis[item.word];
  if (!data) return;

  const card = document.createElement("div");
  card.className = "detail-group";

  const heading = document.createElement("h3");
  heading.textContent = "التحليل الصرفي للاسم";
  card.appendChild(heading);

  const fields = [
    ["نوع الاسم", data.kind],
    ["علامة التأنيث", data.feminine],
    ["نوع الجمع", data.pluralType],
    ["صيغة المؤنث", data.feminineForm],
    ["ملاحظات صرفية", data.note]
  ];

  fields.forEach(([name, value]) => {
    const row = document.createElement("div");
    row.className = "detail-item";

    const label = document.createElement("strong");
    label.textContent = name;

    const content = document.createElement("p");
    content.textContent = value;

    row.append(label, content);
    card.appendChild(row);
  });

  results.appendChild(card);
};// الميزان الصرفي التفصيلي للأسماء
const nounWeights = {
  "كتاب": {
    root: "ك ت ب",
    weight: "فِعَال",
    original: "ك، ت، ب",
    added: "الألف",
    count: "أربعة أحرف"
  },
  "قلم": {
    root: "ق ل م",
    weight: "فَعَل",
    original: "ق، ل، م",
    added: "لا توجد",
    count: "ثلاثة أحرف"
  },
  "مدرسة": {
    root: "د ر س",
    weight: "مَفْعَلَة",
    original: "د، ر، س",
    added: "الميم والتاء المربوطة",
    count: "خمسة أحرف"
  },
  "طالب": {
    root: "ط ل ب",
    weight: "فَاعِل",
    original: "ط، ل، ب",
    added: "الألف",
    count: "أربعة أحرف"
  },
  "معلم": {
    root: "ع ل م",
    weight: "مُفَعِّل",
    original: "ع، ل، م",
    added: "الميم والتضعيف",
    count: "أربعة أحرف"
  },
  "شجرة": {
    root: "ش ج ر",
    weight: "فَعَلَة",
    original: "ش، ج، ر",
    added: "التاء المربوطة",
    count: "أربعة أحرف"
  },
  "مكتبة": {
    root: "ك ت ب",
    weight: "مَفْعَلَة",
    original: "ك، ت، ب",
    added: "الميم والتاء المربوطة",
    count: "خمسة أحرف"
  },
  "زهرة": {
    root: "ز ه ر",
    weight: "فَعْلَة",
    original: "ز، ه، ر",
    added: "التاء المربوطة",
    count: "أربعة أحرف"
  },
  "مهندس": {
    root: "هَنْدَس",
    weight: "مُفَعْلِل",
    original: "ه، ن، د، س",
    added: "الميم",
    count: "خمسة أحرف"
  },
  "طبيب": {
    root: "ط ب ب",
    weight: "فَعِيل",
    original: "ط، ب، ب",
    added: "الياء",
    count: "أربعة أحرف"
  }
};

const previousNounWeightDisplay = showDetails;

showDetails = function(item) {
  previousNounWeightDisplay(item);

  const data = nounWeights[item.word];
  if (!data) return;

  const card = document.createElement("div");
  card.className = "detail-group";

  const heading = document.createElement("h3");
  heading.textContent = "الميزان الصرفي التفصيلي للاسم";
  card.appendChild(heading);

  [
    ["الجذر", data.root],
    ["الوزن الصرفي", data.weight],
    ["الحروف الأصلية", data.original],
    ["الحروف الزائدة", data.added],
    ["عدد أحرف الكلمة", data.count]
  ].forEach(([name, value]) => {
    const row = document.createElement("div");
    row.className = "detail-item";

    const label = document.createElement("strong");
    label.textContent = name;

    const content = document.createElement("p");
    content.textContent = value;

    row.append(label, content);
    card.appendChild(row);
  });

  results.appendChild(card);
};// جدول المفرد والمثنى والجمع للأسماء
const nounForms = {
  "كتاب": ["كتاب", "كتابان", "كتب", "جمع تكسير"],
  "قلم": ["قلم", "قلمان", "أقلام", "جمع تكسير"],
  "مدرسة": ["مدرسة", "مدرستان", "مدارس", "جمع تكسير"],
  "طالب": ["طالب", "طالبان", "طلاب", "جمع تكسير"],
  "معلم": ["معلم", "معلمان", "معلمون", "جمع مذكر سالم"],
  "شجرة": ["شجرة", "شجرتان", "أشجار", "جمع تكسير"],
  "مكتبة": ["مكتبة", "مكتبتان", "مكتبات", "جمع مؤنث سالم"],
  "زهرة": ["زهرة", "زهرتان", "أزهار", "جمع تكسير"],
  "مهندس": ["مهندس", "مهندسان", "مهندسون", "جمع مذكر سالم"],
  "طبيب": ["طبيب", "طبيبان", "أطباء", "جمع تكسير"]
};

const previousNounFormsDisplay = showDetails;

showDetails = function(item) {
  previousNounFormsDisplay(item);

  const forms = nounForms[item.word];
  if (!forms) return;

  const card = document.createElement("div");
  card.className = "detail-group";

  const heading = document.createElement("h3");
  heading.textContent = "جدول المفرد والمثنى والجمع";
  card.appendChild(heading);

  const table = document.createElement("table");
  table.className = "conjugation-table";

  const thead = document.createElement("thead");
  thead.innerHTML =
    "<tr><th>المفرد</th><th>المثنى</th><th>الجمع</th></tr>";
  table.appendChild(thead);

  const tbody = document.createElement("tbody");
  const tr = document.createElement("tr");

  forms.slice(0, 3).forEach(value => {
    const td = document.createElement("td");
    td.textContent = value;
    tr.appendChild(td);
  });

  tbody.appendChild(tr);
  table.appendChild(tbody);
  card.appendChild(table);

  const type = document.createElement("div");
  type.className = "detail-item";

  const label = document.createElement("strong");
  label.textContent = "نوع الجمع";

  const value = document.createElement("p");
  value.textContent = forms[3];

  type.append(label, value);
  card.appendChild(type);

  results.appendChild(card);
};// المشتقات والعلاقات اللغوية للأسماء
const nounRelations = {
  "كتاب": {
    derivatives: "كاتب، مكتوب، كتابة، مكتبة",
    synonyms: "مؤلَّف، مصنَّف",
    antonyms: "لا يوجد ضد مباشر",
    family: "كتب، كاتب، مكتوب، كتابة"
  },
  "قلم": {
    derivatives: "أقلام، قَلَمَ، تقليم",
    synonyms: "يراعة",
    antonyms: "لا يوجد ضد مباشر",
    family: "قلم، أقلام، تقليم"
  },
  "مدرسة": {
    derivatives: "مُدرِّس، تدريس، دراسة، دارس",
    synonyms: "مَعهد تعليمي",
    antonyms: "لا يوجد ضد مباشر",
    family: "درس، دارس، مدرس، تدريس"
  },
  "طالب": {
    derivatives: "طلب، مطلوب، مطالبة، طلبة",
    synonyms: "دارس، متعلم",
    antonyms: "لا يوجد ضد مباشر",
    family: "طلب، طالب، مطلوب، مطالبة"
  },
  "معلم": {
    derivatives: "علَّم، تعليم، معلِّم، متعلِّم",
    synonyms: "مدرِّس، مربٍّ",
    antonyms: "متعلِّم في بعض السياقات",
    family: "علم، علَّم، تعليم، معلِّم"
  },
  "شجرة": {
    derivatives: "شجري، أشجار، تشجير",
    synonyms: "نبتة خشبية",
    antonyms: "لا يوجد ضد مباشر",
    family: "شجر، شجرة، أشجار، تشجير"
  },
  "مكتبة": {
    derivatives: "كتاب، كاتب، مكتوب، كتابة",
    synonyms: "دار كتب",
    antonyms: "لا يوجد ضد مباشر",
    family: "كتب، كتاب، كاتب، مكتبة"
  },
  "زهرة": {
    derivatives: "أزهار، مزهر، إزهار",
    synonyms: "وردة، نَوْر",
    antonyms: "لا يوجد ضد مباشر",
    family: "زهر، زهرة، أزهار، إزهار"
  },
  "مهندس": {
    derivatives: "هندسة، هندسي، مهندسة",
    synonyms: "مصمّم في بعض التخصصات",
    antonyms: "لا يوجد ضد مباشر",
    family: "هندس، هندسة، مهندس، هندسي"
  },
  "طبيب": {
    derivatives: "طب، طبيبة، طبي، تطبيب",
    synonyms: "معالج",
    antonyms: "لا يوجد ضد مباشر",
    family: "طب، طبيب، طبيبة، طبي"
  }
};

const previousNounRelationsDisplay = showDetails;

showDetails = function(item) {
  previousNounRelationsDisplay(item);

  const data = nounRelations[item.word];
  if (!data) return;

  const card = document.createElement("div");
  card.className = "detail-group";

  const heading = document.createElement("h3");
  heading.textContent = "المشتقات والعلاقات اللغوية";
  card.appendChild(heading);

  [
    ["المشتقات", data.derivatives],
    ["المرادفات", data.synonyms],
    ["الأضداد", data.antonyms],
    ["عائلة الكلمة", data.family]
  ].forEach(([name, value]) => {
    const row = document.createElement("div");
    row.className = "detail-item";

    const label = document.createElement("strong");
    label.textContent = name;

    const content = document.createElement("p");
    content.textContent = value;

    row.append(label, content);
    card.appendChild(row);
  });

  results.appendChild(card);
};// الإعراب والتطبيق النحوي للأسماء
const nounGrammar = {
  "كتاب": [
    ["المبتدأ", "الكتابُ مفيدٌ", "مبتدأ مرفوع وعلامة رفعه الضمة"],
    ["المفعول به", "قرأتُ الكتابَ", "مفعول به منصوب وعلامة نصبه الفتحة"],
    ["اسم مجرور", "استفدتُ من الكتابِ", "اسم مجرور وعلامة جره الكسرة"]
  ],
  "قلم": [
    ["المبتدأ", "القلمُ جديدٌ", "مبتدأ مرفوع بالضمة"],
    ["المفعول به", "أمسكتُ القلمَ", "مفعول به منصوب بالفتحة"],
    ["اسم مجرور", "كتبتُ بالقلمِ", "اسم مجرور بالكسرة"]
  ],
  "مدرسة": [
    ["المبتدأ", "المدرسةُ واسعةٌ", "مبتدأ مرفوع بالضمة"],
    ["المفعول به", "زرتُ المدرسةَ", "مفعول به منصوب بالفتحة"],
    ["اسم مجرور", "ذهبتُ إلى المدرسةِ", "اسم مجرور بالكسرة"]
  ],
  "طالب": [
    ["المبتدأ", "الطالبُ مجتهدٌ", "مبتدأ مرفوع بالضمة"],
    ["الفاعل", "حضر الطالبُ", "فاعل مرفوع بالضمة"],
    ["المفعول به", "كرّم المعلمُ الطالبَ", "مفعول به منصوب بالفتحة"]
  ],
  "معلم": [
    ["المبتدأ", "المعلمُ مخلصٌ", "مبتدأ مرفوع بالضمة"],
    ["الفاعل", "شرح المعلمُ الدرسَ", "فاعل مرفوع بالضمة"],
    ["اسم مجرور", "استمعتُ إلى المعلمِ", "اسم مجرور بالكسرة"]
  ],
  "شجرة": [
    ["المبتدأ", "الشجرةُ مثمرةٌ", "مبتدأ مرفوع بالضمة"],
    ["الفاعل", "نمت الشجرةُ", "فاعل مرفوع بالضمة"],
    ["المفعول به", "زرعتُ الشجرةَ", "مفعول به منصوب بالفتحة"]
  ],
  "مكتبة": [
    ["المبتدأ", "المكتبةُ كبيرةٌ", "مبتدأ مرفوع بالضمة"],
    ["المفعول به", "زرتُ المكتبةَ", "مفعول به منصوب بالفتحة"],
    ["اسم مجرور", "ذهبتُ إلى المكتبةِ", "اسم مجرور بالكسرة"]
  ],
  "زهرة": [
    ["المبتدأ", "الزهرةُ جميلةٌ", "مبتدأ مرفوع بالضمة"],
    ["الفاعل", "تفتحت الزهرةُ", "فاعل مرفوع بالضمة"],
    ["المفعول به", "قطفتُ الزهرةَ", "مفعول به منصوب بالفتحة"]
  ],
  "مهندس": [
    ["المبتدأ", "المهندسُ ماهرٌ", "مبتدأ مرفوع بالضمة"],
    ["الفاعل", "صمّم المهندسُ المبنى", "فاعل مرفوع بالضمة"],
    ["اسم مجرور", "تحدثتُ مع المهندسِ", "اسم مجرور بالكسرة"]
  ],
  "طبيب": [
    ["المبتدأ", "الطبيبُ ماهرٌ", "مبتدأ مرفوع بالضمة"],
    ["الفاعل", "فحص الطبيبُ المريضَ", "فاعل مرفوع بالضمة"],
    ["اسم مجرور", "ذهبتُ إلى الطبيبِ", "اسم مجرور بالكسرة"]
  ]
};

const previousGrammarDisplay = showDetails;

showDetails = function(item) {
  previousGrammarDisplay(item);

  const examples = nounGrammar[item.word];
  if (!examples) return;

  const card = document.createElement("div");
  card.className = "detail-group";

  const heading = document.createElement("h3");
  heading.textContent = "الإعراب والتطبيق النحوي";
  card.appendChild(heading);

  examples.forEach(([position, sentence, parsing]) => {
    const row = document.createElement("div");
    row.className = "detail-item";

    const label = document.createElement("strong");
    label.textContent = position;

    const example = document.createElement("p");
    example.textContent = "الجملة: " + sentence;

    const analysis = document.createElement("p");
    analysis.textContent = "الإعراب: " + parsing;

    row.append(label, example, analysis);
    card.appendChild(row);
  });

  results.appendChild(card);
};const developerPhoto = document.getElementById("developerPhoto");
const developerAvatar = document.getElementById("developerAvatar");

developerPhoto.addEventListener("change", function () {
  const file = this.files[0];

  if (!file) return;

  if (!file.type.startsWith("image/")) {
    alert("اختاري ملف صورة من فضلك");
    return;
  }

  const reader = new FileReader();

  reader.onload = function (event) {
    developerAvatar.innerHTML = "";

    const img = document.createElement("img");
    img.src = event.target.result;

    developerAvatar.appendChild(img);
  };

  reader.readAsDataURL(file);
});