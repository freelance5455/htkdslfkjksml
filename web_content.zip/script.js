/* =========================================================
   MINDGUARD — COMPLETE SCRIPT.JS
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

  /* =======================================================
     BASIC ELEMENTS
     ======================================================= */

  const pages = document.querySelectorAll("[data-page]");
  const navItems = document.querySelectorAll("[data-page-target]");
  const toast = document.getElementById("toast");

  const lockModal = document.getElementById("lockModal");
  const focusModal = document.getElementById("focusModal");

  /* =======================================================
     APP STATE
     ======================================================= */

  const state = {
    currentPage: "home",

    screenMinutes: Number(
      localStorage.getItem("mg_screen_minutes") || 127
    ),

    reelsCount: Number(
      localStorage.getItem("mg_reels_count") || 38
    ),

    appsUsed: Number(
      localStorage.getItem("mg_apps_used") || 3
    ),

    brainHealth: Number(
      localStorage.getItem("mg_brain_health") || 86
    ),

    focusActive: false,

    focusSeconds: 25 * 60,

    focusTimer: null,

    limits: JSON.parse(
      localStorage.getItem("mg_limits") ||
      JSON.stringify({
        Instagram: 60,
        YouTube: 60,
        Snapchat: 30
      })
    ),

    used: JSON.parse(
      localStorage.getItem("mg_used") ||
      JSON.stringify({
        Instagram: 42,
        YouTube: 28,
        Snapchat: 17
      })
    )
  };


  /* =======================================================
     LOCAL STORAGE
     ======================================================= */

  function saveState() {
    localStorage.setItem(
      "mg_screen_minutes",
      state.screenMinutes
    );

    localStorage.setItem(
      "mg_reels_count",
      state.reelsCount
    );

    localStorage.setItem(
      "mg_apps_used",
      state.appsUsed
    );

    localStorage.setItem(
      "mg_brain_health",
      state.brainHealth
    );

    localStorage.setItem(
      "mg_limits",
      JSON.stringify(state.limits)
    );

    localStorage.setItem(
      "mg_used",
      JSON.stringify(state.used)
    );
  }


  /* =======================================================
     PAGE NAVIGATION
     ======================================================= */

  function showPage(pageName) {

    state.currentPage = pageName;

    pages.forEach(page => {
      page.classList.remove("active");

      if (page.dataset.page === pageName) {
        page.classList.add("active");
      }
    });

    navItems.forEach(item => {
      item.classList.remove("active");

      if (item.dataset.pageTarget === pageName) {
        item.classList.add("active");
      }
    });

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });

    updatePageData();
  }


  navItems.forEach(item => {

    item.addEventListener("click", () => {

      const target = item.dataset.pageTarget;

      if (target) {
        showPage(target);
      }

    });

  });


  /* Buttons that directly contain data-page-target */
  document.querySelectorAll("[data-page-target]").forEach(button => {

    button.addEventListener("click", event => {

      const target = button.dataset.pageTarget;

      if (!target) return;

      /*
        Prevent duplicate navigation for bottom nav.
      */
      if (
        button.tagName === "BUTTON" ||
        button.classList.contains("quick-card")
      ) {
        showPage(target);
      }

    });

  });


  /* =======================================================
     INITIAL PAGE
     ======================================================= */

  showPage("home");


  /* =======================================================
     TOAST
     ======================================================= */

  let toastTimer = null;

  function showToast(message) {

    if (!toast) return;

    toast.textContent = message;

    toast.classList.add("show");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
      toast.classList.remove("show");
    }, 2400);
  }


  /* =======================================================
     NUMBER FORMAT
     ======================================================= */

  function formatMinutes(minutes) {

    minutes = Math.max(0, Math.round(minutes));

    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;

    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }

    return `${mins}m`;
  }


  /* =======================================================
     FIND ELEMENT HELPERS
     ======================================================= */

  function findTextElement(selectors) {

    for (const selector of selectors) {

      const element = document.querySelector(selector);

      if (element) return element;
    }

    return null;
  }


  /* =======================================================
     HOME DATA
     ======================================================= */

  function updateHome() {

    const screenTime = findTextElement([
      "#homeScreenTime",
      ".screen-time-value",
      "[data-screen-time]"
    ]);

    if (screenTime) {
      screenTime.textContent =
        formatMinutes(state.screenMinutes);
    }


    const appsUsed = findTextElement([
      "#appsUsed",
      ".apps-used-value",
      "[data-apps-used]"
    ]);

    if (appsUsed) {
      appsUsed.textContent = state.appsUsed;
    }


    const reels = findTextElement([
      "#reelsCount",
      ".reels-count",
      "[data-reels-count]"
    ]);

    if (reels) {
      reels.textContent = state.reelsCount;
    }


    const health = findTextElement([
      "#brainHealth",
      ".health-value",
      "[data-health]"
    ]);

    if (health) {
      health.textContent = `${state.brainHealth}%`;
    }


    const healthBar = findTextElement([
      "#healthBar",
      ".health-fill",
      "[data-health-bar]"
    ]);

    if (healthBar) {
      healthBar.style.width =
        `${state.brainHealth}%`;
    }


    const healthMessage =
      document.querySelector(".health-message");

    if (healthMessage) {

      if (state.brainHealth >= 80) {
        healthMessage.textContent =
          "Your brain is doing great. Keep going!";
      }
      else if (state.brainHealth >= 60) {
        healthMessage.textContent =
          "A little less scrolling could help.";
      }
      else if (state.brainHealth >= 40) {
        healthMessage.textContent =
          "Your brain needs a little more rest.";
      }
      else {
        healthMessage.textContent =
          "Time to take a break and reset.";
      }
    }
  }


  /* =======================================================
     STATS PAGE
     ======================================================= */

  function updateStats() {

    const total = findTextElement([
      "#statsScreenTime",
      ".stats-total-time",
      "[data-total-time]"
    ]);

    if (total) {
      total.textContent =
        formatMinutes(state.screenMinutes);
    }


    const reels = findTextElement([
      "#statsReels",
      ".stats-reels-count",
      "[data-stats-reels]"
    ]);

    if (reels) {
      reels.textContent = state.reelsCount;
    }


    const brainProgress =
      document.querySelector(".brain-progress");

    if (brainProgress) {
      brainProgress.style.setProperty(
        "--progress",
        `${state.brainHealth}%`
      );
    }


    const statHealth =
      findTextElement([
        "#statsBrainHealth",
        ".stats-health-value",
        "[data-stats-health]"
      ]);

    if (statHealth) {
      statHealth.textContent =
        `${state.brainHealth}%`;
    }


    /*
      Animate bars if they exist.
    */
    document.querySelectorAll(
      ".weekly-bar, .chart-bar"
    ).forEach((bar, index) => {

      const values = [
        42, 58, 48, 71, 62, 82, 55
      ];

      if (!bar.style.height) {

        const value =
          values[index % values.length];

        bar.style.height =
          `${value}%`;
      }
    });
  }


  /* =======================================================
     APP LIMITS
     ======================================================= */

  function updateLimits() {

    document.querySelectorAll(
      "[data-app]"
    ).forEach(card => {

      const appName =
        card.dataset.app;

      if (!appName) return;

      const limit =
        state.limits[appName] || 30;

      const used =
        state.used[appName] || 0;

      const percentage =
        Math.min(
          100,
          Math.round((used / limit) * 100)
        );


      const usedElement =
        card.querySelector(
          ".app-used, .used-time, [data-used]"
        );

      if (usedElement) {

        usedElement.textContent =
          `${used}m / ${limit}m`;
      }


      const progress =
        card.querySelector(
          ".progress-fill, .app-progress-fill"
        );

      if (progress) {

        progress.style.width =
          `${percentage}%`;
      }


      const limitElement =
        card.querySelector(
          ".limit-value, [data-limit]"
        );

      if (limitElement) {
        limitElement.textContent =
          `${limit}m`;
      }


      const lockStatus =
        card.querySelector(
          ".lock-status, [data-lock-status]"
        );

      if (lockStatus) {

        if (used >= limit) {

          lockStatus.textContent =
            "Limit reached";

          lockStatus.classList.add("locked");

        } else {

          lockStatus.textContent =
            "Protected";

          lockStatus.classList.remove("locked");
        }
      }


      card.dataset.percentage =
        percentage;
    });
  }


  /* =======================================================
     LIMIT +/- BUTTONS
     ======================================================= */

  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          "[data-limit-action]"
        );

      if (!button) return;

      const card =
        button.closest("[data-app]");

      if (!card) return;

      const appName =
        card.dataset.app;

      if (!appName) return;

      const action =
        button.dataset.limitAction;


      if (!state.limits[appName]) {
        state.limits[appName] = 30;
      }


      if (action === "increase") {

        state.limits[appName] += 5;

        showToast(
          `${appName} limit increased`
        );
      }


      if (action === "decrease") {

        state.limits[appName] =
          Math.max(
            5,
            state.limits[appName] - 5
          );

        showToast(
          `${appName} limit decreased`
        );
      }


      saveState();
      updateLimits();
    }
  );


  /* =======================================================
     ALTERNATIVE PLUS/MINUS CLASSES
     ======================================================= */

  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          ".limit-plus, .limit-minus"
        );

      if (!button) return;

      const card =
        button.closest("[data-app]");

      if (!card) return;

      const appName =
        card.dataset.app;

      if (!appName) return;

      if (!state.limits[appName]) {
        state.limits[appName] = 30;
      }


      if (
        button.classList.contains(
          "limit-plus"
        )
      ) {

        state.limits[appName] += 5;

      } else {

        state.limits[appName] =
          Math.max(
            5,
            state.limits[appName] - 5
          );
      }


      saveState();
      updateLimits();
    }
  );


  /* =======================================================
     LOCK MODAL
     ======================================================= */

  function openLockModal(appName) {

    if (!lockModal) return;

    const name =
      lockModal.querySelector(
        ".lock-app-name, [data-lock-app]"
      );

    if (name) {
      name.textContent =
        appName || "This app";
    }

    lockModal.classList.add("show");
    lockModal.setAttribute(
      "aria-hidden",
      "false"
    );
  }


  function closeLockModal() {

    if (!lockModal) return;

    lockModal.classList.remove("show");

    lockModal.setAttribute(
      "aria-hidden",
      "true"
    );
  }


  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          "[data-close-lock], .close-lock, #closeLock, #lockDone"
        );

      if (button) {
        closeLockModal();
      }
    }
  );


  if (lockModal) {

    lockModal.addEventListener(
      "click",
      event => {

        if (event.target === lockModal) {
          closeLockModal();
        }

      }
    );
  }


  /* =======================================================
     CHECK LIMITS
     ======================================================= */

  function checkLimits() {

    Object.keys(state.limits)
      .forEach(appName => {

        const limit =
          state.limits[appName] || 30;

        const used =
          state.used[appName] || 0;

        if (used >= limit) {

          /*
            Browser simulation only.
            Real Android app locking requires
            native Android permissions/APIs.
          */

          const card =
            document.querySelector(
              `[data-app="${appName}"]`
            );

          if (card) {
            card.classList.add("limit-reached");
          }
        }

      });
  }


  /* =======================================================
     FOCUS MODE
     ======================================================= */

  function openFocusModal() {

    if (!focusModal) return;

    state.focusActive = true;
    state.focusSeconds = 25 * 60;

    focusModal.classList.add("show");

    focusModal.setAttribute(
      "aria-hidden",
      "false"
    );

    updateFocusDisplay();

    clearInterval(
      state.focusTimer
    );

    state.focusTimer =
      setInterval(() => {

        state.focusSeconds--;

        updateFocusDisplay();

        if (state.focusSeconds <= 0) {

          finishFocusMode();

          showToast(
            "Focus session complete! 🎉"
          );
        }

      }, 1000);
  }


  function updateFocusDisplay() {

    if (!focusModal) return;

    const minutes =
      Math.floor(
        state.focusSeconds / 60
      );

    const seconds =
      state.focusSeconds % 60;

    const formatted =
      `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;


    const display =
      focusModal.querySelector(
        ".focus-timer, #focusTimer, [data-focus-timer]"
      );

    if (display) {
      display.textContent =
        formatted;
    }
  }


  function finishFocusMode() {

    clearInterval(
      state.focusTimer
    );

    state.focusTimer = null;
    state.focusActive = false;

    if (focusModal) {

      focusModal.classList.remove(
        "show"
      );

      focusModal.setAttribute(
        "aria-hidden",
        "true"
      );
    }
  }


  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          ".focus-button, #focusMode, [data-action='focus']"
        );

      if (!button) return;

      openFocusModal();
    }
  );


  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          ".end-focus, #endFocus, [data-end-focus]"
        );

      if (!button) return;

      finishFocusMode();

      showToast(
        "Focus Mode ended"
      );
    }
  );


  if (focusModal) {

    focusModal.addEventListener(
      "click",
      event => {

        if (event.target === focusModal) {
          finishFocusMode();
        }

      }
    );
  }


  /* =======================================================
     SETTINGS TOGGLES
     ======================================================= */

  document.querySelectorAll(
    ".toggle input, input[type='checkbox'][data-setting]"
  ).forEach(toggle => {

    toggle.addEventListener(
      "change",
      () => {

        const key =
          toggle.dataset.setting ||
          toggle.closest(".setting-item")
            ?.dataset.setting;

        if (key) {

          localStorage.setItem(
            `mg_setting_${key}`,
            toggle.checked
          );
        }


        showToast(
          toggle.checked
            ? "Setting enabled"
            : "Setting disabled"
        );
      }
    );

  });


  /* =======================================================
     RESTORE SETTINGS
     ======================================================= */

  document.querySelectorAll(
    "input[type='checkbox'][data-setting]"
  ).forEach(toggle => {

    const key =
      toggle.dataset.setting;

    const saved =
      localStorage.getItem(
        `mg_setting_${key}`
      );

    if (saved !== null) {
      toggle.checked =
        saved === "true";
    }
  });


  /* =======================================================
     BRAIN ANIMATION CONTROL
     ======================================================= */

  function setupBrainAnimation() {

    const brain =
      document.querySelector(".brain");

    if (!brain) return;

    let animationEnabled =
      localStorage.getItem(
        "mg_setting_brain"
      );

    /*
      Default = enabled
    */

    if (animationEnabled === null) {
      animationEnabled = "true";
    }


    if (animationEnabled === "false") {

      brain.style.animation =
        "none";

      document
        .querySelectorAll(
          ".brain-ring, .brain-glow, .neuron, .brain-particle"
        )
        .forEach(element => {
          element.style.animationPlayState =
            "paused";
        });
    }
  }


  /* =======================================================
     BRAIN HEALTH VISUAL
     ======================================================= */

  function updateBrainVisual() {

    const brain =
      document.querySelector(".brain");

    if (!brain) return;

    const health =
      Math.max(
        0,
        Math.min(
          100,
          state.brainHealth
        )
      );


    brain.dataset.health =
      health;


    /*
      Higher health = brighter brain.
    */

    brain.style.setProperty(
      "--brain-intensity",
      (0.55 + health / 200).toFixed(2)
    );


    /*
      Add health class.
    */

    brain.classList.remove(
      "brain-good",
      "brain-warning",
      "brain-tired"
    );


    if (health >= 70) {

      brain.classList.add(
        "brain-good"
      );

    } else if (health >= 40) {

      brain.classList.add(
        "brain-warning"
      );

    } else {

      brain.classList.add(
        "brain-tired"
      );
    }
  }


  /* =======================================================
     NEURAL SPARKS
     ======================================================= */

  function createBrainSparks() {

    const section =
      document.querySelector(
        ".brain-section"
      );

    if (!section) return;

    if (
      section.querySelector(
        ".dynamic-brain-sparks"
      )
    ) {
      return;
    }


    const container =
      document.createElement("div");

    container.className =
      "dynamic-brain-sparks";


    Object.assign(
      container.style,
      {
        position: "absolute",
        inset: "0",
        pointerEvents: "none",
        zIndex: "3"
      }
    );


    for (let i = 0; i < 14; i++) {

      const spark =
        document.createElement("span");

      const size =
        2 + Math.random() * 3;

      spark.style.position =
        "absolute";

      spark.style.width =
        `${size}px`;

      spark.style.height =
        `${size}px`;

      spark.style.borderRadius =
        "50%";

      spark.style.background =
        "#7ffff4";

      spark.style.boxShadow =
        "0 0 10px #59f6ff";

      spark.style.left =
        `${15 + Math.random() * 70}%`;

      spark.style.top =
        `${15 + Math.random() * 70}%`;

      spark.style.opacity =
        "0";

      spark.style.animation =
        `mgBrainSpark ${2 + Math.random() * 3}s ease-in-out ${Math.random() * 2}s infinite`;

      container.appendChild(
        spark
      );
    }


    section.appendChild(
      container
    );
  }


  /* =======================================================
     BRAIN SPARK CSS
     ======================================================= */

  if (!document.getElementById(
    "mindguardBrainAnimationCSS"
  )) {

    const style =
      document.createElement("style");

    style.id =
      "mindguardBrainAnimationCSS";

    style.textContent = `

      @keyframes mgBrainSpark {

        0%, 100% {
          transform:
            translate(0, 0)
            scale(.25);
          opacity: 0;
        }

        25% {
          opacity: .7;
        }

        50% {
          transform:
            translate(
              8px,
              -18px
            )
            scale(1.2);
          opacity: 1;
        }

        75% {
          opacity: .3;
        }

      }

      .brain {
        --brain-intensity: 1;
      }

      .brain.brain-good {
        filter:
          brightness(
            var(--brain-intensity)
          );
      }

      .brain.brain-warning {
        filter:
          saturate(.88)
          brightness(.92);
      }

      .brain.brain-tired {
        filter:
          saturate(.68)
          brightness(.78);
      }

    `;

    document.head.appendChild(
      style
    );
  }


  /* =======================================================
     QUICK CARD NAVIGATION
     ======================================================= */

  document.querySelectorAll(
    ".quick-card, [data-feature-page]"
  ).forEach(card => {

    card.addEventListener(
      "click",
      () => {

        const target =
          card.dataset.pageTarget ||
          card.dataset.featurePage;

        if (target) {
          showPage(target);
        }

      }
    );

  });


  /* =======================================================
     SETTINGS BUTTON
     ======================================================= */

  const settingsButton =
    document.querySelector(
      "[data-action='open-settings']"
    );

  if (settingsButton) {

    settingsButton.addEventListener(
      "click",
      () => {
        showPage("settings");
      }
    );
  }


  /* =======================================================
     ADD APP BUTTON
     ======================================================= */

  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          ".add-app, [data-action='add-app']"
        );

      if (!button) return;

      showToast(
        "App selection will be available in the Android version."
      );
    }
  );


  /* =======================================================
     SIMULATE APP USAGE
     ======================================================= */

  function simulateUsage() {

    /*
      Small demo update.

      This does NOT read actual phone usage.
      It only keeps the web prototype alive.
    */

    if (state.focusActive) {
      return;
    }


    /*
      Keep values stable instead of
      increasing every second.
    */
  }


  /* =======================================================
     UPDATE EVERYTHING
     ======================================================= */

  function updatePageData() {

    updateHome();
    updateStats();
    updateLimits();
    updateBrainVisual();
    checkLimits();
  }


  /* =======================================================
     INITIALIZE BRAIN
     ======================================================= */

  createBrainSparks();
  setupBrainAnimation();


  /* =======================================================
     INITIAL DATA UPDATE
     ======================================================= */

  updatePageData();


  /* =======================================================
     DEMO: REELS COUNTER BUTTON
     ======================================================= */

  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          "[data-action='add-reel']"
        );

      if (!button) return;

      state.reelsCount++;

      /*
        Small health reduction for demo.
      */

      state.brainHealth =
        Math.max(
          0,
          state.brainHealth - 1
        );

      saveState();

      updatePageData();

      showToast(
        "Reels activity recorded"
      );
    }
  );


  /* =======================================================
     DEMO RESET
     ======================================================= */

  document.addEventListener(
    "click",
    event => {

      const button =
        event.target.closest(
          "[data-action='reset-data']"
        );

      if (!button) return;

      state.screenMinutes = 127;
      state.reelsCount = 38;
      state.appsUsed = 3;
      state.brainHealth = 86;

      state.limits = {
        Instagram: 60,
        YouTube: 60,
        Snapchat: 30
      };

      state.used = {
        Instagram: 42,
        YouTube: 28,
        Snapchat: 17
      };

      saveState();

      updatePageData();

      showToast(
        "MindGuard data reset"
      );
    }
  );


  /* =======================================================
     KEYBOARD / ACCESSIBILITY
     ======================================================= */

  document.addEventListener(
    "keydown",
    event => {

      if (event.key === "Escape") {

        closeLockModal();
        finishFocusMode();

      }

    }
  );


  /* =======================================================
     SAVE BEFORE PAGE CLOSE
     ======================================================= */

  window.addEventListener(
    "beforeunload",
    saveState
  );


  /* =======================================================
     PERIODIC UI REFRESH
     ======================================================= */

  setInterval(() => {

    updateHome();
    updateStats();
    updateLimits();

  }, 5000);


  /* =======================================================
     CONSOLE INFO
     ======================================================= */

  console.log(
    "MindGuard initialized successfully."
  );

  console.log(
    "Note: browser version simulates app protection."
  );

});