let injectedCDN = "";

const defaultOutputHTML = `
  <style>
    body {
      background: #09090b;
      color: #71717a;
      font-family: system-ui, sans-serif;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      text-align: center;
    }
    .status-icon { font-size: 30px; margin-bottom: 8px; opacity: 0.8; }
    .status-text { font-size: 12px; letter-spacing: 0.5px; }
  </style>
  <div class="status-icon">🚀</div>
  <div class="status-text">Ready for Output</div>
`;

window.onload = function() {
  if (localStorage.getItem('vip_html')) {
    document.getElementById('htmlCode').value = localStorage.getItem('vip_html');
    document.getElementById('cssCode').value = localStorage.getItem('vip_css');
    document.getElementById('jsCode').value = localStorage.getItem('vip_js');
    executeCode();
  } else {
    showDefaultPreview();
  }
};

function showDefaultPreview() {
  let previewFrame = document.getElementById('preview').contentWindow.document;
  previewFrame.open();
  previewFrame.write(defaultOutputHTML);
  previewFrame.close();
}

function saveToStorage() {
  localStorage.setItem('vip_html', document.getElementById('htmlCode').value);
  localStorage.setItem('vip_css', document.getElementById('cssCode').value);
  localStorage.setItem('vip_js', document.getElementById('jsCode').value);
  if (document.getElementById('autoRunCheck').checked) executeCode();
}

function executeCode() {
  let html = document.getElementById('htmlCode').value;
  let css = "<style>" + document.getElementById('cssCode').value + "</style>";
  let js = "<script>" + document.getElementById('jsCode').value + "</" + "script>";

  if (!html.trim() && !css.replace(/<[^>]*>/g, '').trim() && !js.replace(/<[^>]*>/g, '').trim()) {
    showDefaultPreview();
    return;
  }

  let previewFrame = document.getElementById('preview').contentWindow.document;
  previewFrame.open();
  previewFrame.write(injectedCDN + css + html + js);
  previewFrame.close();
}

function openTab(tabName) {
  let contents = document.querySelectorAll('.tab-content');
  let buttons = document.querySelectorAll('.tab-btn');
  contents.forEach(c => c.classList.remove('active'));
  buttons.forEach(b => b.classList.remove('active'));

  if(tabName === 'html') { document.getElementById('htmlCode').classList.add('active'); buttons[0].classList.add('active'); }
  else if(tabName === 'css') { document.getElementById('cssCode').classList.add('active'); buttons[1].classList.add('active'); }
  else if(tabName === 'js') { document.getElementById('jsCode').classList.add('active'); buttons[2].classList.add('active'); }
}

function insertSymbol(symbol) {
  let activeTab = document.querySelector('.tab-content.active');
  if (activeTab) {
    let start = activeTab.selectionStart;
    let end = activeTab.selectionEnd;
    activeTab.value = activeTab.value.substring(0, start) + symbol + activeTab.value.substring(end);
    activeTab.selectionStart = activeTab.selectionEnd = start + symbol.length;
    activeTab.focus();
    saveToStorage();
  }
}

function injectLibrary() {
  let val = document.getElementById('cdnSelect').value;
  if(val === 'tailwind') injectedCDN = '<script src="https://cdn.tailwindcss.com"></script>';
  else if(val === 'bootstrap') injectedCDN = '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">';
  else if(val === 'fontawesome') injectedCDN = '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">';
  executeCode();
  if(val) alert(val.toUpperCase() + ' Library Injected Successfully!');
}

function toggleFullScreen() {
  document.getElementById('previewWrapper').classList.toggle('fullscreen');
}

document.getElementById('runBtn').addEventListener('click', executeCode);

function clearCurrentTab() {
  let activeTab = document.querySelector('.tab-content.active');
  if (activeTab) { activeTab.value = ''; saveToStorage(); executeCode(); }
}

function copyCode() {
  let activeTab = document.querySelector('.tab-content.active');
  if (activeTab && activeTab.value !== '') {
    navigator.clipboard.writeText(activeTab.value);
    alert('Code Copied to Clipboard! 📋');
  }
}

function loadTemplate() {
  let val = document.getElementById('templateSelect').value;
  if (val === 'button') {
    document.getElementById('htmlCode').value = '<button class="glow-btn">Hover & Click Me</button>';
    document.getElementById('cssCode').value = 'body{display:flex;justify-content:center;align-items:center;height:100vh;background:#0c0a09;}\n.glow-btn{padding:15px 30px;background:#f59e0b;color:#000;border:none;border-radius:30px;font-size:18px;font-weight:bold;box-shadow:0 0 25px #f59e0b;cursor:pointer;}';
    document.getElementById('jsCode').value = 'document.querySelector(".glow-btn").onclick = () => alert("Master VIP Button Clicked!");';
  } else if (val === 'chat') {
    document.getElementById('htmlCode').value = '<div class="chat-container">\n  <div class="chat-header">VibeChat 💬</div>\n  <div class="chat-box" id="chatBox">\n    <div class="msg received">Hey! Kaisa hai?</div>\n  </div>\n  <div class="chat-input">\n    <input type="text" id="msgInput" placeholder="Message likhein...">\n    <button onclick="sendMsg()">Send</button>\n  </div>\n</div>';
    document.getElementById('cssCode').value = 'body { background: #0c0a09; font-family: sans-serif; display: flex; justify-content: center; padding: 10px; }\n.chat-container { width: 100%; max-width: 350px; background: #1c1917; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column; height: 350px; border: 1px solid #27272a; }\n.chat-header { background: #f59e0b; color: #000; padding: 10px; font-weight: bold; text-align: center; }\n.chat-box { flex: 1; padding: 10px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; }\n.msg { padding: 8px 12px; border-radius: 12px; max-width: 75%; font-size: 14px; }\n.received { background: #27272a; color: white; align-self: flex-start; }\n.sent { background: #d97706; color: white; align-self: flex-end; }\n.chat-input { display: flex; padding: 10px; background: #0c0a09; }\n.chat-input input { flex: 1; padding: 8px; border-radius: 20px; border: none; outline: none; background: #27272a; color: white; }\n.chat-input button { background: #f59e0b; color: #000; border: none; padding: 6px 12px; margin-left: 5px; border-radius: 20px; font-weight: bold; }';
    document.getElementById('jsCode').value = 'function sendMsg() {\n  let input = document.getElementById("msgInput");\n  let text = input.value.trim();\n  if (text !== "") {\n    let chatBox = document.getElementById("chatBox");\n    let userMsg = document.createElement("div");\n    userMsg.className = "msg sent";\n    userMsg.innerText = text;\n    chatBox.appendChild(userMsg);\n    input.value = "";\n    chatBox.scrollTop = chatBox.scrollHeight;\n    setTimeout(() => {\n      let botMsg = document.createElement("div");\n      botMsg.className = "msg received";\n      botMsg.innerText = "Reply: " + text;\n      chatBox.appendChild(botMsg);\n      chatBox.scrollTop = chatBox.scrollHeight;\n    }, 1000);\n  }\n}';
  }
  saveToStorage();
  executeCode();
}

/* Modal Control & Direct File Export */
function openSaveModal() {
  document.getElementById('saveModal').classList.add('active');
}

function closeSaveModal() {
  document.getElementById('saveModal').classList.remove('active');
}

function exportProjectFile() {
  let fileName = document.getElementById('fileNameInput').value.trim() || "VIP_Project";
  if (!fileName.endsWith('.html')) {
    fileName += '.html';
  }

  let html = document.getElementById('htmlCode').value;
  let css = "<style>" + document.getElementById('cssCode').value + "</style>";
  let js = "<script>" + document.getElementById('jsCode').value + "</" + "script>";

  let fullCode = "<!DOCTYPE html><html><head>" + css + "</head><body>" + html + js + "</body></html>";

  let blob = new Blob([fullCode], { type: "text/html" });
  let a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = fileName;
  a.click();
  
  closeSaveModal();
  alert('File Successfully Downloaded! 💾');
}
