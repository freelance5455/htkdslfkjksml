const form = document.getElementById("converterForm");
const amountInput = document.getElementById("amount");
const fromCurrency = document.getElementById("fromCurrency");
const toCurrency = document.getElementById("toCurrency");
const swapButton = document.getElementById("swapButton");

const loading = document.getElementById("loading");
const errorMessage = document.getElementById("errorMessage");
const result = document.getElementById("result");
const resultText = document.getElementById("resultText");
const rateText = document.getElementById("rateText");
const dateText = document.getElementById("dateText");

const API_URL = "https://api.frankfurter.app/latest";

form.addEventListener("submit", async function (event) {
  event.preventDefault();

  const amount = Number(amountInput.value);
  const from = fromCurrency.value;
  const to = toCurrency.value;

  hideMessages();

  if (!amount || amount < 0) {
    showError("يرجى إدخال مبلغ صحيح.");
    return;
  }

  if (from === to) {
    displayResult(amount, amount, from, to, 1, new Date().toISOString());
    return;
  }

  showLoading(true);

  try {
    const response = await fetch(
      `${API_URL}?amount=1&from=${from}&to=${to}`
    );

    if (!response.ok) {
      throw new Error("تعذر الحصول على سعر الصرف.");
    }

    const data = await response.json();
    const rate = data.rates?.[to];

    if (typeof rate !== "number") {
      throw new Error("سعر الصرف غير متوفر حاليًا.");
    }

    const convertedAmount = amount * rate;

    displayResult(
      amount,
      convertedAmount,
      from,
      to,
      rate,
      data.date
    );
  } catch (error) {
    showError(
      "حدث خطأ أثناء جلب سعر الصرف. تحقق من اتصال الإنترنت وحاول مرة أخرى."
    );
  } finally {
    showLoading(false);
  }
});

swapButton.addEventListener("click", function () {
  const oldFrom = fromCurrency.value;

  fromCurrency.value = toCurrency.value;
  toCurrency.value = oldFrom;

  if (!result.classList.contains("hidden")) {
    form.dispatchEvent(new Event("submit"));
  }
});

function displayResult(amount, convertedAmount, from, to, rate, date) {
  resultText.textContent =
    `${formatNumber(amount)} ${from} = ${formatNumber(convertedAmount)} ${to}`;

  rateText.textContent =
    `1 ${from} = ${formatNumber(rate, 6)} ${to}`;

  dateText.textContent =
    `آخر تحديث متوفر: ${formatDate(date)}`;

  result.classList.remove("hidden");
}

function formatNumber(number, maximumFractionDigits = 2) {
  return new Intl.NumberFormat("ar-EG", {
    maximumFractionDigits
  }).format(number);
}

function formatDate(dateValue) {
  if (!dateValue) {
    return "غير معروف";
  }

  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return dateValue;
  }

  return new Intl.DateTimeFormat("ar-EG", {
    year: "numeric",
    month: "long",
    day: "numeric"
  }).format(date);
}

function showLoading(isLoading) {
  loading.classList.toggle("hidden", !isLoading);
}

function showError(message) {
  errorMessage.textContent = message;
  errorMessage.classList.remove("hidden");
}

function hideMessages() {
  errorMessage.classList.add("hidden");
  result.classList.add("hidden");
}
