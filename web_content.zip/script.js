const products=[
{name:"Castroviejo Forceps (Straight)",cat:"Forceps",group:"Featured",icon:"⌁",desc:"Fine forceps for delicate tissue handling and grasping."},
{name:"McPherson Forceps (1x2 Teeth)",cat:"Forceps",group:"Featured",icon:"⌁",desc:"Designed for delicate and precise ophthalmic procedures."},
{name:"Colibri Corneal Forceps",cat:"Forceps",group:"New",icon:"⌁",desc:"Fine corneal forceps for controlled microsurgical handling."},
{name:"Capsulorhexis Forceps",cat:"Forceps",group:"New",icon:"⌁",desc:"Precision forceps for controlled capsulorhexis procedures."},
{name:"Vannas Scissors (Angled)",cat:"Scissors",group:"Featured",icon:"✂",desc:"Fine precision scissors for delicate ophthalmic cutting."},
{name:"Westcott Tenotomy Scissors",cat:"Scissors",group:"All",icon:"✂",desc:"Fine scissors for ophthalmic soft-tissue procedures."},
{name:"Castroviejo Needle Holder (Straight)",cat:"Needles",group:"Featured",icon:"╱",desc:"High precision needle holder for ophthalmic suturing."},
{name:"Barraquer Needle Holder (Curved)",cat:"Needles",group:"New",icon:"╱",desc:"Curved design for access and visibility during suturing."},
{name:"Micro Needle Holder",cat:"Micro",group:"New",icon:"◈",desc:"Fine microsurgical holder for delicate ophthalmic needles."},
{name:"Iris Spatula",cat:"Micro",group:"All",icon:"◈",desc:"Fine instrument for delicate intraocular manipulation."},
{name:"Wire Eye Speculum",cat:"Other",group:"All",icon:"◉",desc:"Ophthalmic speculum for maintaining surgical exposure."},
{name:"Lacrimal Dilator",cat:"Other",group:"All",icon:"◇",desc:"Fine dilator for delicate ophthalmic procedures."}
];

let activeFilter="All", cart=JSON.parse(localStorage.getItem("farmistaCart")||"[]");
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);

const savedTheme=localStorage.getItem("farmistaTheme")||"light";
function applyTheme(theme){
  document.body.classList.toggle("dark",theme==="dark");
  localStorage.setItem("farmistaTheme",theme);
  const d=$("#darkModeBtn"), l=$("#lightModeBtn");
  if(d)d.classList.toggle("active",theme==="dark");
  if(l)l.classList.toggle("active",theme==="light");
}
applyTheme(savedTheme);

window.addEventListener("load",()=>setTimeout(()=>$("#splash").style.display="none",650));

function updateCounts(){ $("#cartCount").textContent=cart.length; $("#navCount").textContent=cart.length; }

function card(p,i){
return `<article class="product-card"><div class="product-photo">${p.icon}</div><div class="product-body"><div class="tag">${p.cat}</div><h3>${p.name}</h3><p>${p.desc}</p><div class="card-actions"><button class="view-btn" onclick="showDetail(${i})">View Details</button><button class="add-btn" onclick="addCart(${i})">＋</button></div></div></article>`;
}
function mini(p,i){return `<div class="mini-product"><div class="mini-photo">${p.icon}</div><div class="mini-info"><div class="tag">${p.cat}</div><h3>${p.name}</h3><p>${p.desc}</p></div><button class="mini-arrow" onclick="showDetail(${i})">›</button></div>`}

function renderHome(){
$("#homeProducts").innerHTML=products.filter(p=>p.group==="Featured").slice(0,4).map((p)=>mini(p,products.indexOf(p))).join("");
}
function renderCatalog(){
let q=$("#search").value.toLowerCase().trim();
let list=products.filter(p=>(activeFilter==="All"||p.cat===activeFilter)&&(q===""||(`${p.name} ${p.desc} ${p.cat}`).toLowerCase().includes(q)));
$("#catalogProducts").innerHTML=list.map(p=>card(p,products.indexOf(p))).join("")||`<div class="empty-cart">No instruments found.</div>`;
$$(".filters button").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));
}
function updateNavIndicator(page){
  const nav=$(".bottom-nav"); const indicator=$(".nav-indicator"); if(!nav||!indicator)return;
  const buttons=[...nav.querySelectorAll("button")]; const idx=buttons.findIndex(b=>b.dataset.page===page);
  if(idx<0)return;
  indicator.style.transform=`translateX(${idx*100}%)`;
}
function showPage(page){
["homePage","catalogPage","detailPage","inquiryPage","aboutPage","settingsPage"].forEach(x=>$("#"+x).classList.add("hidden"));
const map={home:"homePage",categories:"catalogPage",detail:"detailPage",inquiry:"inquiryPage",about:"aboutPage",settings:"settingsPage"};
$("#"+map[page]).classList.remove("hidden");
if(page==="categories")renderCatalog();
if(page==="inquiry")renderCart();
$$(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
updateNavIndicator(page);
window.scrollTo({top:0,behavior:"smooth"}); closeDrawer();
}
function showDetail(i){
const p=products[i];
$("#detail").innerHTML=`<article class="detail-card"><div class="detail-photo">${p.icon}</div><div class="detail-body"><div class="tag">${p.cat}</div><h1>${p.name}</h1><p>${p.desc} This catalog does not display prices. Contact Farmista Surgical for specifications, availability and quotation.</p><div class="features"><div><b>◇</b>Stainless<br>Steel</div><div><b>◎</b>High<br>Precision</div><div><b>✧</b>Ergonomic<br>Design</div></div><button class="detail-add" onclick="addCart(${i})">🛒 Add to Inquiry</button></div></article>`;
showPage("detail");
}
function addCart(i){if(!cart.includes(i))cart.push(i);localStorage.setItem("farmistaCart",JSON.stringify(cart));updateCounts();showPage("inquiry")}
function renderCart(){
const box=$("#cartItems");
if(!cart.length){box.innerHTML=`<div class="empty-cart"><b>🛒</b>Your inquiry cart is empty.<br>Select instruments from the catalog.</div>`;return}
box.innerHTML=cart.map(i=>{const p=products[i];return `<div class="cart-row"><div class="mini-photo">${p.icon}</div><div class="cart-row-info"><h3>${p.name}</h3><small>${p.cat} · Price on request</small></div><button class="remove" onclick="removeCart(${i})">×</button></div>`}).join("");
}
function removeCart(i){cart=cart.filter(x=>x!==i);localStorage.setItem("farmistaCart",JSON.stringify(cart));updateCounts();renderCart()}
function closeDrawer(){$("#drawer").classList.remove("open");$("#backdrop").classList.remove("open")}
function openDrawer(){$("#drawer").classList.add("open");$("#backdrop").classList.add("open")}

function filterTo(f){activeFilter=f;showPage("categories");}
$$("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$$("[data-filter]").forEach(b=>b.addEventListener("click",()=>filterTo(b.dataset.filter)));

$("#menuBtn").onclick=openDrawer; $("#closeDrawer").onclick=closeDrawer; $("#backdrop").onclick=closeDrawer;
$("#searchBtn").onclick=()=>{$("#searchPanel").classList.toggle("open");$("#search").focus()};
$("#search").oninput=()=>{if(!$("#catalogPage").classList.contains("hidden"))renderCatalog()};
$("#cartBtn").onclick=()=>showPage("inquiry");
$("#clearCart").onclick=()=>{cart=[];localStorage.setItem("farmistaCart","[]");updateCounts();renderCart()};
$("#sendWhatsApp").onclick=()=>{
if(!cart.length)return;
const names=cart.map(i=>products[i].name).join(", ");
window.open("https://wa.me/923007105143?text="+encodeURIComponent("Assalam o Alaikum, I am interested in: "+names+". Please share specifications, availability and quotation."),"_blank");
};
renderHome(); renderCatalog(); updateCounts(); updateNavIndicator("home");

$("#darkModeBtn")?.addEventListener("click",()=>applyTheme("dark"));
$("#lightModeBtn")?.addEventListener("click",()=>applyTheme("light"));
