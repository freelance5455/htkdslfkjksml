const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const W = canvas.width, H = canvas.height;
const WORLD = { w: 1500, h: 1050 };
const fighters = [
  { id: 'scout', name: 'Искра', art: '🟦', color: '#45dcca', hp: 88, speed: 205, damage: 10, rate: .19, range: 430, bulletSpeed: 570, attack: 'Быстрые заряды', ultimate: 'Рывок и ускорение' },
  { id: 'tank', name: 'Гром', art: '🟧', color: '#ff9b50', hp: 145, speed: 145, damage: 9, rate: .64, range: 270, bulletSpeed: 390, attack: 'Короткий залп', ultimate: 'Щит и удар по кругу' },
  { id: 'sniper', name: 'Вектор', art: '🟪', color: '#b18cff', hp: 78, speed: 165, damage: 27, rate: .9, range: 620, bulletSpeed: 760, attack: 'Точный дальний выстрел', ultimate: 'Пробивной суперзаряд' }
];
const walls = [
  {x:270,y:155,w:190,h:42},{x:270,y:197,w:42,h:155},{x:515,y:92,w:54,h:160},
  {x:690,y:180,w:200,h:44},{x:890,y:180,w:45,h:150},{x:1100,y:105,w:180,h:45},
  {x:135,y:410,w:190,h:48},{x:420,y:385,w:48,h:190},{x:610,y:340,w:230,h:48},
  {x:1010,y:350,w:54,h:185},{x:1190,y:425,w:190,h:48},{x:200,y:700,w:200,h:44},
  {x:510,y:625,w:180,h:48},{x:760,y:730,w:52,h:175},{x:940,y:650,w:210,h:48},
  {x:1240,y:710,w:50,h:170},{x:460,y:890,w:195,h:45},{x:890,y:890,w:190,h:45}
];
let selected = 0, actors = [], bullets = [], particles = [], player = null;
let running = false, lastTime = 0, camera = {x:0,y:0}, keys = {}, pointer = {x:W/2,y:H/2,down:false};
let mobileMove = {x:0,y:0}, stickPointer = null, attackHeld = false, lastHud = 0;
const rand = (a,b) => a + Math.random() * (b-a);
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const dist = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);

const fighterHolder = document.getElementById('fighters');
fighters.forEach((f,i) => {
  const button = document.createElement('button');
  button.className = 'fighter-option' + (i === 0 ? ' selected' : '');
  button.innerHTML = `<span class="fighter-art">${f.art}</span><span class="fighter-name">${f.name}</span><span class="fighter-stats">${f.hp} HP · ${f.attack}<br>✦ ${f.ultimate}</span>`;
  button.addEventListener('click', () => {
    selected = i;
    [...fighterHolder.children].forEach((el,n) => el.classList.toggle('selected', n === i));
  });
  fighterHolder.appendChild(button);
});

function canStand(x,y,r=13) {
  if(x<r || y<r || x>WORLD.w-r || y>WORLD.h-r) return false;
  return !walls.some(w => x+r>w.x && x-r<w.x+w.w && y+r>w.y && y-r<w.y+w.h);
}
function visible(a,b) {
  const d=dist(a,b), steps=Math.ceil(d/9);
  for(let i=1;i<steps;i++){
    const t=i/steps, x=a.x+(b.x-a.x)*t, y=a.y+(b.y-a.y)*t;
    if(walls.some(w=>x>w.x && x<w.x+w.w && y>w.y && y<w.y+w.h)) return false;
  }
  return true;
}
function newActor(x,y,type,isPlayer=false) {
  const spec=fighters[type];
  return {x,y,vx:0,vy:0,type,spec,isPlayer,alive:true,hp:spec.hp,maxHp:spec.hp,radius:type===1?16:13,angle:0,cooldown:rand(.15,.8),ult:0,shield:0,boost:0,target:null,think:0,roam:rand(0,Math.PI*2),kills:0};
}
function spawnAt(index) {
  const spots=[{x:110,y:115},{x:730,y:95},{x:1370,y:290},{x:1390,y:880},{x:1050,y:990},{x:680,y:510},{x:100,y:850},{x:1130,y:560},{x:360,y:555}];
  return spots[index % spots.length];
}
function startGame(){
  actors=[];bullets=[];particles=[];
  const p=spawnAt(0);player=newActor(p.x,p.y,selected,true);actors.push(player);
  for(let i=1;i<=8;i++){
    const s=spawnAt(i), type=Math.floor(Math.random()*fighters.length);
    actors.push(newActor(s.x,s.y,type));
  }
  running=true;lastTime=performance.now();
  document.getElementById('menu').classList.add('hidden');
  document.getElementById('result').classList.add('hidden');
  document.getElementById('remaining').textContent=actors.length;
  requestAnimationFrame(loop);
}
document.getElementById('startButton').addEventListener('click',startGame);
document.getElementById('againButton').addEventListener('click',()=>{document.getElementById('result').classList.add('hidden');document.getElementById('menu').classList.remove('hidden');});

function moveActor(a,dx,dy,dt){
  const speed=a.spec.speed*(a.boost>0?1.6:1);
  let nx=a.x+dx*speed*dt, ny=a.y+dy*speed*dt;
  if(canStand(nx,a.y,a.radius))a.x=nx;
  if(canStand(a.x,ny,a.radius))a.y=ny;
  if(!canStand(a.x,a.y,a.radius)){a.x-=dx*speed*dt;a.y-=dy*speed*dt;}
}
function fire(a,angle,superShot=false){
  if(a.cooldown>0 || !a.alive)return;
  a.cooldown=superShot?1.1:a.spec.rate;
  const pellets=a.type===1&&!superShot?5:1;
  const spread=a.type===1&&!superShot ? 0.23 : 0;
  for(let i=0;i<pellets;i++){
    const ang=angle+(pellets>1?rand(-spread,spread):0);
    bullets.push({x:a.x+Math.cos(ang)*(a.radius+7),y:a.y+Math.sin(ang)*(a.radius+7),vx:Math.cos(ang)*(superShot?640:a.spec.bulletSpeed),vy:Math.sin(ang)*(superShot?640:a.spec.bulletSpeed),owner:a,damage:superShot?(a.type===2?52:25):a.spec.damage,life:(superShot?1.4:a.spec.range/a.spec.bulletSpeed),color:superShot?'#fff18a':a.spec.color,superShot,pierce:superShot&&a.type===2?3:0});
  }
}
function useUltimate(a){
  if(!a.alive||a.ult>0)return;
  a.ult=12;
  if(a.type===0){
    a.boost=2.5;
    const dx=Math.cos(a.angle),dy=Math.sin(a.angle);
    for(let n=0;n<7;n++){const x=a.x+dx*n*11,y=a.y+dy*n*11;if(canStand(x,y,a.radius)){a.x=x;a.y=y;}}
  }else if(a.type===1){
    a.shield=3;
    for(const enemy of actors){if(enemy!==a&&enemy.alive&&dist(a,enemy)<105){damage(enemy,25,a);}}
    burst(a.x,a.y,a.spec.color,18);
  }else{
    a.cooldown=0;
    fire(a,a.angle,true);
  }
}
function damage(target,amount,source){
  if(!target.alive)return;
  if(target.shield>0)amount*=.25;
  target.hp-=amount;
  burst(target.x,target.y,target.spec.color,3);
  if(target.hp<=0){target.hp=0;target.alive=false;if(source&&source!==target)source.kills++;burst(target.x,target.y,target.spec.color,15);if(target===player)finish(false);}
}
function burst(x,y,color,count){for(let i=0;i<count;i++)particles.push({x,y,vx:rand(-100,100),vy:rand(-100,100),life:rand(.2,.55),color,size:rand(2,5)});}
function nearestVisible(a){
  let best=null,bestD=Infinity;
  for(const b of actors){if(b===a||!b.alive)continue;const d=dist(a,b);if(d<bestD&&visible(a,b)){best=b;bestD=d;}}
  return best;
}
function botStep(a,dt){
  a.think-=dt;
  if(a.think<=0){a.target=nearestVisible(a);a.think=rand(.18,.38);}
  const t=a.target&&a.target.alive&&visible(a,a.target)?a.target:null;
  if(t){
    const dx=t.x-a.x,dy=t.y-a.y,d=Math.hypot(dx,dy)||1;
    a.angle=Math.atan2(dy,dx);
    const desired=a.type===1?135:(a.type===2?Math.min(390,a.spec.range*.68):190);
    let mx=0,my=0;
    if(d>desired+28){mx=dx/d;my=dy/d;}else if(d<desired*.62){mx=-dx/d;my=-dy/d;}
    // If a wall blocks the route, try nearby directions instead of walking into it.
    if(mx||my){
      let nx=mx,ny=my;
      if(!canStand(a.x+mx*a.spec.speed*dt,a.y+my*a.spec.speed*dt,a.radius)){
        const options=[.8,-.8,1.5,-1.5,2.3,-2.3];let found=false;
        for(const turn of options){const c=Math.cos(turn)*mx-Math.sin(turn)*my,s=Math.sin(turn)*mx+Math.cos(turn)*my;if(canStand(a.x+c*25,a.y+s*25,a.radius)){nx=c;ny=s;found=true;break;}}
        if(!found){nx=Math.cos(a.roam);ny=Math.sin(a.roam);}
      }
      moveActor(a,nx,ny,dt);
    }
    if(d<a.spec.range && visible(a,t)){
      // Bots aim at the target's current position, with only a small spread.
      const aim=Math.atan2(t.y-a.y,t.x-a.x)+rand(-.018,.018);
      if(a.cooldown<=0)fire(a,aim);
    }
    if(a.ult<=0&&d<170&&Math.random()<.008)useUltimate(a);
  }else{
    if(Math.random()<dt*.55)a.roam+=rand(-1.2,1.2);
    let mx=Math.cos(a.roam),my=Math.sin(a.roam);
    if(!canStand(a.x+mx*30,a.y+my*30,a.radius)){a.roam+=Math.PI*rand(.45,1.1);mx=Math.cos(a.roam);my=Math.sin(a.roam);}
    moveActor(a,mx,my,dt);
  }
}
function playerStep(dt){
  let mx=mobileMove.x,my=mobileMove.y;
  if(keys.KeyW||keys.ArrowUp)my-=1;if(keys.KeyS||keys.ArrowDown)my+=1;
  if(keys.KeyA||keys.ArrowLeft)mx-=1;if(keys.KeyD||keys.ArrowRight)mx+=1;
  const mag=Math.hypot(mx,my);if(mag>1){mx/=mag;my/=mag;}if(mag>0)moveActor(player,mx,my,dt);
  const mobile=matchMedia('(pointer: coarse)').matches;
  if(mobile){const t=nearestVisible(player);if(t)player.angle=Math.atan2(t.y-player.y,t.x-player.x);}
  else{const wx=pointer.x+camera.x,wy=pointer.y+camera.y;player.angle=Math.atan2(wy-player.y,wx-player.x);}
  if((attackHeld||keys.Space||pointer.down)&&player.cooldown<=0)fire(player,player.angle);
  if(keys.KeyE){useUltimate(player);keys.KeyE=false;}
}
function update(dt){
  for(const a of actors){if(!a.alive)continue;a.cooldown=Math.max(0,a.cooldown-dt);a.ult=Math.max(0,a.ult-dt);a.shield=Math.max(0,a.shield-dt);a.boost=Math.max(0,a.boost-dt);}
  playerStep(dt);
  for(const a of actors)if(a.alive&&!a.isPlayer)botStep(a,dt);
  for(let i=bullets.length-1;i>=0;i--){
    const b=bullets[i],oldX=b.x,oldY=b.y;b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;
    const steps=Math.ceil(Math.hypot(b.x-oldX,b.y-oldY)/6);let hitWall=false;
    for(let s=0;s<=steps;s++){const t=s/Math.max(1,steps),x=oldX+(b.x-oldX)*t,y=oldY+(b.y-oldY)*t;if(walls.some(w=>x>w.x&&x<w.x+w.w&&y>w.y&&y<w.y+w.h)){hitWall=true;break;}}
    let hit=hitWall;
    if(!hitWall){for(const a of actors){if(!a.alive||a===b.owner)continue;if(Math.hypot(a.x-b.x,a.y-b.y)<a.radius+4){damage(a,b.damage,b.owner);if(b.pierce>0){b.pierce--;b.damage*=.72;}else hit=true;break;}}}
    if(hit||b.life<=0||b.x<0||b.y<0||b.x>WORLD.w||b.y>WORLD.h)bullets.splice(i,1);
  }
  for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;if(p.life<=0)particles.splice(i,1);}
  camera.x=clamp(player.x-W/2,0,WORLD.w-W);camera.y=clamp(player.y-H/2,0,WORLD.h-H);
  const alive=actors.filter(a=>a.alive).length;
  if(performance.now()-lastHud>150){document.getElementById('remaining').textContent=alive;document.getElementById('healthBar').style.width=`${Math.max(0,player.hp/player.maxHp*100)}%`;document.getElementById('healthText').textContent=Math.ceil(player.hp);document.getElementById('superButton').classList.toggle('ready',player.ult<=0);lastHud=performance.now();}
  if(player.alive&&alive===1)finish(true);
}
function rect(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(Math.round(x),Math.round(y),w,h);}
function draw(){
  ctx.clearRect(0,0,W,H);ctx.save();ctx.translate(-Math.floor(camera.x),-Math.floor(camera.y));
  rect(camera.x,camera.y,W,H,'#263c39');
  const startX=Math.floor(camera.x/32)*32,startY=Math.floor(camera.y/32)*32;
  for(let y=startY;y<camera.y+H+32;y+=32)for(let x=startX;x<camera.x+W+32;x+=32){const alt=(Math.floor(x/32)+Math.floor(y/32))%2===0;rect(x,y,31,31,alt?'#2b423e':'#293f3b');rect(x+2,y+2,2,2,alt?'#38544b':'#324b44');}
  // Arena boundary and cover blocks have visible top and shaded sides.
  rect(0,0,WORLD.w,8,'#557268');rect(0,WORLD.h-8,WORLD.w,8,'#172c29');rect(0,0,8,WORLD.h,'#557268');rect(WORLD.w-8,0,8,WORLD.h,'#172c29');
  for(const w of walls){rect(w.x+7,w.y+9,w.w,w.h,'#172522');rect(w.x+5,w.y+6,w.w,w.h,'#30443f');rect(w.x,w.y,w.w,w.h,'#65736c');rect(w.x+3,w.y+3,w.w-6,6,'#8d9a86');rect(w.x+4,w.y+10,w.w-8,w.h-14,'#58665f');rect(w.x+10,w.y+14,Math.max(8,w.w-20),3,'#738176');}
  for(const b of bullets){rect(b.x-4,b.y-4,9,9,'#101719');rect(b.x-3,b.y-5,7,7,b.color);rect(b.x-1,b.y-4,3,3,'#fff8cf');}
  for(const p of particles)rect(p.x,p.y,p.size,p.size,p.color);
  for(const a of actors)if(a.alive)drawActor(a);
  ctx.restore();
}
function drawActor(a){
  const x=Math.round(a.x),y=Math.round(a.y),size=a.radius*1.45;
  rect(x-size/2+4,y+size/2-1,size,size*.25,'#10171599');
  if(a.shield>0){ctx.strokeStyle='#e5ddffcc';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,size*.72,0,Math.PI*2);ctx.stroke();}
  const dx=Math.cos(a.angle),dy=Math.sin(a.angle);
  rect(x+dx*8-4,y+dy*8-4,12,11,'#171a20');rect(x+dx*8-3,y+dy*7-5,10,8,a.spec.color);
  rect(x-size/2+3,y-size/2+4,size,size,'#151a1c');rect(x-size/2,y-size/2,size,size*.78,a.spec.color);
  rect(x-size/2+3,y-size/2+2,size-6,4,'#ffffff88');rect(x-size/2+4,y+1,size-8,3,'#17201f88');
  const eyeX=x+dx*size*.22,eyeY=y+dy*size*.16;rect(eyeX-2,eyeY-2,4,4,'#fff3c2');
  if(!a.isPlayer){rect(x-13,y-size/2-13,26,4,'#17221f');rect(x-12,y-size/2-12,24*Math.max(0,a.hp/a.maxHp),2,'#ff687d');}
  if(a.isPlayer){rect(x-5,y-size/2-15,10,3,'#e9ffff');}
}
function loop(now){if(!running)return;const dt=Math.min(.035,(now-lastTime)/1000);lastTime=now;update(dt);draw();if(running)requestAnimationFrame(loop);}
function finish(won){if(!running)return;running=false;document.getElementById('resultTitle').textContent=won?'ПОБЕДА!':'ПОРАЖЕНИЕ';document.getElementById('resultText').textContent=won?`Ты остался последним на арене. Уничтожено: ${player.kills}.`:`Тебя выбили из боя. Уничтожено: ${player.kills}.`;document.getElementById('result').classList.remove('hidden');}

canvas.addEventListener('pointermove',e=>{const r=canvas.getBoundingClientRect();pointer.x=(e.clientX-r.left)*W/r.width;pointer.y=(e.clientY-r.top)*H/r.height;});
canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'){pointer.down=true;canvas.setPointerCapture(e.pointerId);}});
canvas.addEventListener('pointerup',()=>pointer.down=false);
window.addEventListener('keydown',e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();});
window.addEventListener('keyup',e=>keys[e.code]=false);
const attackButton=document.getElementById('attackButton');
attackButton.addEventListener('pointerdown',e=>{e.preventDefault();attackHeld=true;attackButton.setPointerCapture(e.pointerId);});
attackButton.addEventListener('pointerup',()=>attackHeld=false);attackButton.addEventListener('pointercancel',()=>attackHeld=false);
document.getElementById('superButton').addEventListener('pointerdown',e=>{e.preventDefault();if(running)useUltimate(player);});
const stickArea=document.getElementById('stickArea'),stick=document.getElementById('stick');
stickArea.addEventListener('pointerdown',e=>{e.preventDefault();stickPointer=e.pointerId;stickArea.setPointerCapture(e.pointerId);setStick(e);});
stickArea.addEventListener('pointermove',e=>{if(e.pointerId===stickPointer)setStick(e);});
function setStick(e){const r=stickArea.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const limit=r.width*.34,d=Math.hypot(dx,dy);if(d>limit){dx*=limit/d;dy*=limit/d;}mobileMove={x:dx/limit,y:dy/limit};stick.style.transform=`translate(${dx}px,${dy}px)`;}
function releaseStick(){stickPointer=null;mobileMove={x:0,y:0};stick.style.transform='translate(0,0)';}
stickArea.addEventListener('pointerup',releaseStick);stickArea.addEventListener('pointercancel',releaseStick);

// Keep the arena preview visible behind the character-selection menu.
function preview(){if(running)return;camera.x=0;camera.y=0;draw();requestAnimationFrame(preview);}
preview();
