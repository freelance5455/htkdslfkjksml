let workbook;
let sheet1;

let selectedMonthCell;
let selectedMonthColumn;

let activeStudents = {};
let lastStudentRow;

let inactivePaidStudents = [];

// Excel file
document.getElementById("fileInput").addEventListener(
    "change",
    function (event) {
        const file = event.target.files[0];
        document.getElementById("fileName").textContent = file ? file.name : "No file chosen";
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            const data = new Uint8Array(e.target.result);
            workbook = XLSX.read(data, { type: "array" });
            sheet1 = workbook.Sheets["Sheet1"];

            if (!sheet1) {
                alert("Sheet1 not found.");
                return;
            }

            // Read months from D1:O1
            const monthSelect = document.getElementById("monthSelect");
            monthSelect.innerHTML = '<option value="">Select Month</option>';

            for (let column = 3; column <= 14; column++) {
                const cellAddress = XLSX.utils.encode_cell({ r: 0, c: column });
                const cell = sheet1[cellAddress];

                if (cell && cell.v !== undefined && cell.v !== "") {
                    const option = document.createElement("option");
                    option.value = cellAddress;
                    option.textContent = cell.v;
                    monthSelect.appendChild(option);
                }
            }
        };
        reader.readAsArrayBuffer(file);
    }
);

// Find the last student row
function findLastStudentRow() {
    let lastRow = 1;
    for (let row = 2; ; row++) {
        const nameCell = sheet1["A" + row];
        if (!nameCell || nameCell.v === undefined || nameCell.v === "") break;
        lastRow = row;
    }
    return lastRow;
}

// Submit button
document.getElementById("submitButton").addEventListener(
    "click",
    function () {
        selectedMonthCell = document.getElementById("monthSelect").value;
        selectedMonthColumn = selectedMonthCell.replace(/[0-9]/g, "");
        const month = sheet1[selectedMonthCell].v;
        lastStudentRow = findLastStudentRow();
        activeStudents = {};
        const studentList = document.getElementById("studentList");
        studentList.innerHTML = "";

        // Create student list
        for (let row = 2; row <= lastStudentRow; row++) {
            const nameCell = sheet1["A" + row];
            if (!nameCell || nameCell.v === undefined || nameCell.v === "") continue;
            const name = nameCell.v;

            // Initial active status comes from column C
            const activeCell = sheet1["C" + row];
            activeStudents[row] = activeCell && String(activeCell.v).trim().toUpperCase() === "Y";
            const studentRow = document.createElement("div");
            studentRow.className = "studentRow";
            const nameSpan = document.createElement("span");
            nameSpan.textContent = name;

            // Circular button
            const circle = document.createElement("button");
            circle.className = "activeCircle";
            function updateCircle() {
                if (activeStudents[row]) circle.classList.add("active");
                else circle.classList.remove("active");
            }
            updateCircle();

            circle.addEventListener("click", function () {
                activeStudents[row] = !activeStudents[row];
                updateCircle();
            }
            );
            studentRow.appendChild(nameSpan);
            studentRow.appendChild(circle);
            studentList.appendChild(studentRow);
        }
        document.getElementById("activeQuestion").textContent = "Are these students active for " + month + "?";
        document.getElementById("background").style.display = "block";
        document.getElementById("activePopup").style.display = "block";
    }
);

// Confirm active students
document.getElementById("confirmActive").addEventListener(
    "click",
    function () {
        document.getElementById("activePopup").style.display = "none";
        document.getElementById("background").style.display = "none";
        generatePaymentRecord();
    }
);

//Generate payment record
function generatePaymentRecord() {
    const subject = document.getElementById("subjectSelect").value;
    const month = sheet1[selectedMonthCell].v;
    let paidStudents = [];
    let notPaidStudents = [];
    inactivePaidStudents = [];

    for (let row = 2; row <= lastStudentRow; row++) {
        const nameCell = sheet1["A" + row];
        const statusCell = sheet1[selectedMonthColumn + row];
        let status = statusCell && statusCell.v !== undefined ? String(statusCell.v).trim().toUpperCase() : "";

        //Non-active student
        if (activeStudents[row] !== true) {

            // If a non-active student has paid, store their name and amount separately.
            if (status === "PS" || status === "PN") {

                const amountCell = sheet1["P" + row];
                let amount = amountCell && amountCell.v !== undefined ? amountCell.v : "";
                inactivePaidStudents.push(nameCell.v + ": " + amount);
            }

            // Do not include non-active students in the normal paid/unpaid lists.
            continue;
        }

        // Active Student
        if (status === "PS" || status === "PN") {
            const amountCell = sheet1["P" + row];
            let amount = amountCell && amountCell.v !== undefined ? amountCell.v : "";
            paidStudents.push(nameCell.v + ": " + amount);
        }
        else notPaidStudents.push(nameCell.v);
    }

    // Create output
    let result = "<b>PAYMENT RECORD</b><br><br>";
    result += "SUBJECT: " + subject + "<br>";
    result += "MONTH: " + month + "<br><br>";

    //Active students who paid
    result += "<b>Students who have paid:</b><br>";
    if (paidStudents.length > 0) result += paidStudents.join("<br>");
    else result += "None";
    result += "<br><br>";

    // Active students who did not pay
    result += "<b>Students who have not paid:</b><br>";
    if (notPaidStudents.length > 0) result += notPaidStudents.join("<br>");
    else result += "None";
    result += "<br><br>";

    //Non-active students who paid
    result += "<b>Non-active students who have paid:</b><br>";
    if (inactivePaidStudents.length > 0) result += inactivePaidStudents.join("<br>");
    else result += "None";

    document.getElementById("output").innerHTML = result;
    calculateTeacherPayments();
    document.getElementById("copyButton").style.display = "block";
}

document.getElementById("copyButton").addEventListener(
    "click",
    function () {
        const text = document.getElementById("output").innerText + "\n" + document.getElementById("teacherOutput").innerText + "\n\nLatest Checked: " + new Date().toLocaleDateString("en-GB");
        navigator.clipboard.writeText(text).then(
            function () {
                document.getElementById("copyButton").innerHTML = 'Copied <span class="copyTick"></span>';
                setTimeout(
                    function () {
                        document.getElementById("copyButton").innerHTML = "Copy Payment Record";
                    },
                    2000
                );
            }
        );
    }
);

function calculateTeacherPayments() {
    let PS = 0;
    let PN = 0;

    for (let row = 2; row <= lastStudentRow; row++) {
        const nameCell = sheet1["A" + row];

        if (!nameCell || nameCell.v === undefined || nameCell.v === "") continue;

        const statusCell = sheet1[selectedMonthColumn + row];
        let status = statusCell && statusCell.v !== undefined ? String(statusCell.v).trim().toUpperCase() : "";

        const amountCell = sheet1["P" + row];
        let amount = amountCell && amountCell.v !== undefined ? Number(amountCell.v) || 0 : 0;

        if (status === "PS") PS += amount;
        else if (status === "PN") PN += amount;
    }
    const amountToSumitSir = (PS + PN) * 0.25;
    const amountToNiladriSir = (PS + PN) * 0.75;

    // Niladri Sir should receive 75% of the total amount. Difference = Niladri Sir's 75% share minus what Niladri Sir has already received.
    const difference = amountToNiladriSir - PN;

    let result = "---------------------------<br>";
    result += "<b>TEACHER PAYMENT RECORD</b><br><br>";
    result += "Amount received by Sumit Sir: ₹" + PS + "<br>";
    result += "Amount received by Niladri Sir: ₹" + PN + "<br>";
    result += "Total amount received: ₹" + (PS + PN) + "<br><br>";
    result += "<b>Amount to be paid to Sumit Sir: ₹" + amountToSumitSir + "</b><br>";
    result += "<b>Amount to be paid to Niladri Sir: ₹" + amountToNiladriSir + "</b><br><br>";

    // Settlement
    if (difference > 0) result += "<b>Amount to be credited to Niladri Sir: ₹" + difference + "</b>";
    else if (difference < 0) result += "<b>Amount to be credited to Sumit Sir: ₹" + Math.abs(difference) + "</b>";
    else result += "<b>No amount to be credited.</b>";

    document.getElementById("teacherOutput").innerHTML = result;
}