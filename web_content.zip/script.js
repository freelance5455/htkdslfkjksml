const areas=[
["Anatomia","Estrutura do corpo humano: órgãos, sistemas, tecidos e regiões anatômicas."],
["Fisiologia","Funcionamento normal dos sistemas e mecanismos de regulação do organismo."],
["Cardiologia","Coração, vasos sanguíneos, circulação, hipertensão e doenças cardiovasculares."],
["Neurologia","Sistema nervoso, cérebro, medula, nervos e principais doenças neurológicas."],
["Pneumologia","Pulmões, vias respiratórias, ventilação e doenças respiratórias."],
["Gastroenterologia","Sistema digestivo, fígado, vias biliares e pâncreas."],
["Nefrologia","Rins, equilíbrio hidroeletrolítico, pressão arterial e doenças renais."],
["Endocrinologia","Hormônios, diabetes, tireoide, suprarrenais e metabolismo."],
["Hematologia","Sangue, medula óssea, anemias, coagulação e doenças hematológicas."],
["Oncologia","Prevenção, diagnóstico, tratamento e acompanhamento do câncer."],
["Infectologia","Infecções, microrganismos, prevenção, diagnóstico e tratamento."],
["Imunologia","Sistema imune, imunidade, alergias e doenças autoimunes."],
["Pediatria","Saúde da criança e do adolescente, crescimento, desenvolvimento e doenças pediátricas."],
["Ginecologia e Obstetrícia","Saúde reprodutiva, gestação, parto, puerpério e doenças ginecológicas."],
["Cirurgia","Princípios cirúrgicos, avaliação pré-operatória e cuidados pós-operatórios."],
["Urgência e Emergência","Avaliação inicial, suporte básico, triagem e atendimento de emergências."],
["Psiquiatria","Saúde mental, transtornos psiquiátricos e abordagens terapêuticas."],
["Dermatologia","Pele, cabelos, unhas e doenças dermatológicas."],
["Oftalmologia","Olhos, visão e principais doenças oculares."],
["Otorrinolaringologia","Ouvido, nariz, garganta e estruturas relacionadas."],
["Radiologia","Radiografia, ultrassom, tomografia, ressonância e segurança em imagem."],
["Farmacologia","Princípios dos medicamentos, mecanismos, efeitos adversos e segurança."],
["Microbiologia","Bactérias, vírus, fungos, parasitas e métodos microbiológicos."],
["Bioquímica","Moléculas, metabolismo e processos químicos do organismo."],
["Genética","Genes, cromossomos, hereditariedade e doenças genéticas."],
["Nutrição","Nutrientes, alimentação, metabolismo e avaliação nutricional."],
["Odontologia","Saúde oral, dentes, periodonto e prevenção."],
["Medicina Legal","Aplicações médicas relacionadas à justiça e à investigação."],
["Saúde Pública","Epidemiologia, prevenção, vacinação, políticas e sistemas de saúde."]
];

const topics={
"Anatomia":["Planos e eixos anatômicos","Sistema esquelético","Sistema muscular","Sistema cardiovascular","Sistema respiratório","Sistema digestivo"],
"Cardiologia":["Anatomia do coração","Ciclo cardíaco","Hipertensão arterial","Insuficiência cardíaca","Arritmias","Infarto do miocárdio"],
"Neurologia":["Neurônio","Exame neurológico","Acidente vascular cerebral","Epilepsia","Cefaleias","Doença de Parkinson"],
"Farmacologia":["Farmacocinética","Farmacodinâmica","Interações medicamentosas","Efeitos adversos","Segurança na administração","Uso racional de medicamentos"],
"Urgência e Emergência":["Avaliação inicial","Suporte básico de vida","Choque","Trauma","Emergências respiratórias","Emergências cardiovasculares"]
};

const desc={};
areas.forEach(a=>desc[a[0]]=a[1]);

function show(view){
 document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));
 document.getElementById(view).classList.add("active");
 document.getElementById("side").classList.remove("open");
 if(view==="favorites")renderFav();
}
document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>show(b.dataset.view));
document.getElementById("menuBtn").onclick=()=>document.getElementById("side").classList.toggle("open");

function card(name,description){
 return `<div class="card"><button class="favorite" onclick="toggleFav('${name.replaceAll("'","\\'")}')">☆</button><h3>${name}</h3><p>${description}</p><button onclick="openArea('${name.replaceAll("'","\\'")}')">Estudar →</button></div>`;
}
function renderAreas(target){
 document.getElementById(target).innerHTML=areas.map(a=>card(a[0],a[1])).join("");
}
renderAreas("areaCards");renderAreas("allAreas");
document.getElementById("stats").innerHTML=`<div class="stat"><b>${areas.length}</b><br>áreas</div><div class="stat"><b>∞</b><br>conteúdo expansível</div><div class="stat"><b>📝</b><br>questionários</div>`;

function openArea(name){
 show("reader");
 const list=topics[name]||["Introdução","Conceitos fundamentais","Anatomia e fisiologia relacionada","Principais doenças","Diagnóstico","Prevenção e tratamento"];
 document.getElementById("readerContent").innerHTML=`<h2>${name}</h2><p>${desc[name]||""}</p><div class="grid">${list.map((t,i)=>`<div class="card"><h3>${i+1}. ${t}</h3><p>Conteúdo educacional introdutório. Consulte livros, diretrizes e profissionais habilitados para informações clínicas completas.</p></div>`).join("")}</div>`;
}

function toggleFav(name){
 let f=JSON.parse(localStorage.getItem("fav")||"[]");
 f=f.includes(name)?f.filter(x=>x!==name):[...f,name];
 localStorage.setItem("fav",JSON.stringify(f)); renderFav();
}
function renderFav(){
 const f=JSON.parse(localStorage.getItem("fav")||"[]");
 document.getElementById("favList").innerHTML=f.length?f.map(x=>`<div class="item"><b>${x}</b><button onclick="openArea('${x.replaceAll("'","\\'")}')">Abrir</button></div>`).join(""):"<div class='item'>Nenhum favorito ainda.</div>";
}
document.getElementById("videoList").innerHTML=["Aulas de anatomia","Exame físico","Procedimentos e técnicas","Primeiros socorros","Revisões para concursos"].map(x=>`<div class="item"><b>🎥 ${x}</b><p>Espaço para adicionar vídeos educativos.</p></div>`).join("");

const questions=[
["Qual órgão bombeia o sangue para todo o corpo?","Coração",["Pulmão","Coração","Rim","Fígado"]],
["Qual sistema é responsável principalmente pelas trocas gasosas?","Respiratório",["Digestivo","Nervoso","Respiratório","Endócrino"]],
["Qual estrutura é a unidade funcional básica do sistema nervoso?","Neurônio",["Neurônio","Hemácia","Néfron","Alvéolo"]]
];
let qi=0;
function renderQuiz(){
 const q=questions[qi%questions.length];
 document.getElementById("quizBox").innerHTML=`<div class="quiz"><h3>${q[0]}</h3>${q[2].map(a=>`<button style="display:block;width:100%;margin:8px 0" onclick="answer('${a.replaceAll("'","\\'")}')">${a}</button>`).join("")}<p class="small">Questão ${(qi%questions.length)+1} de ${questions.length}</p></div>`;
}
function answer(a){const q=questions[qi%questions.length];alert(a===q[1]?"✅ Resposta correta!":"❌ Resposta incorreta. Resposta: "+q[1]);qi++;renderQuiz()}
renderQuiz();

document.getElementById("search").oninput=function(){
 const q=this.value.toLowerCase();
 document.getElementById("areaCards").innerHTML=areas.filter(a=>(a[0]+" "+a[1]).toLowerCase().includes(q)).map(a=>card(a[0],a[1])).join("");
};
document.getElementById("langBtn").onclick=()=>alert("Versão inicial: Português. A estrutura está preparada para adicionar outros idiomas.");
