/* =========================================================
   Control de Asistencia y Nómina — Lógica de la aplicación
   JavaScript vanilla, sin dependencias externas.
   Soporta navegador (localStorage) y Capacitor (Preferences).
   PARTE 1: Config, storage, utilidades, estado, cálculos, tema
   ========================================================= */

(function () {
  'use strict';

  /* ---------------------------------------------------------
     1. CONFIGURACIÓN Y CONSTANTES
  --------------------------------------------------------- */

  const STORAGE_KEY = 'nomina_sistema_datos_v2';
  const THEME_KEY = 'nomina_tema';
  const DENSITY_KEY = 'nomina_densidad';
  const LAST_BACKUP_KEY = 'nomina_ultimo_backup';

  const THEME_LIGHT = 'light';
  const THEME_DARK = 'dark';
  const DENSITY_COMFORTABLE = 'comfortable';
  const DENSITY_COMPACT = 'compact';

  const DAYS = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
  const DAY_LABELS = {
    lunes: 'Lunes',
    martes: 'Martes',
    miercoles: 'Miércoles',
    jueves: 'Jueves',
    viernes: 'Viernes',
    sabado: 'Sábado'
  };

  const MAX_DAILY_HOURS = 24;
  const MAX_WEEKLY_HOURS = 144;
  const DEFAULT_OVERTIME_THRESHOLD = 48;
  const OVERTIME_DEFAULT_MULTIPLIER = 1.5;
  const MAX_HISTORY_ENTRIES = 52;

  const CURRENCY_LOCALE = 'es-PY';
  const CURRENCY_SYMBOL = '₲';

  const PAYMENT_METHODS = {
    efectivo: 'Efectivo',
    transferencia: 'Transferencia',
    otro: 'Otro'
  };

  const PAY_TYPE_LABELS = {
    hourly: 'Por hora',
    percentage: 'Por porcentaje'
  };

  const MONEY_EPSILON = 0.5;
  const BULK_PAYMENT_NOTE = 'Pago masivo';

  const BACKUP_APP_ID = 'planilla';
  const BACKUP_VERSION = 'v2';
  const BACKUP_MAX_SIZE = 10 * 1024 * 1024;

  /* ---------------------------------------------------------
     2. DETECCIÓN DE ENTORNO (navegador vs. Capacitor)
  --------------------------------------------------------- */

  const isNative =
    typeof window.Capacitor !== 'undefined' &&
    typeof window.Capacitor.isNativePlatform === 'function' &&
    window.Capacitor.isNativePlatform();

  const PreferencesPlugin =
    isNative &&
    window.Capacitor.Plugins &&
    window.Capacitor.Plugins.Preferences
      ? window.Capacitor.Plugins.Preferences
      : null;

  /* ---------------------------------------------------------
     3. CAPA DE ALMACENAMIENTO UNIFICADA
        - Datos de nómina: Preferences (nativo) o localStorage (web)
        - Tema y densidad: SIEMPRE localStorage (porque el script
          anti-flash en <head> los necesita de forma síncrona)
  --------------------------------------------------------- */

  const Storage = {
    async get(key) {
      if (PreferencesPlugin) {
        try {
          const { value } = await PreferencesPlugin.get({ key });
          return value;
        } catch (err) {
          console.warn('[Storage] Error leyendo Preferences:', err);
          return null;
        }
      }
      try {
        return window.localStorage.getItem(key);
      } catch (err) {
        return null;
      }
    },

    async set(key, value) {
      if (PreferencesPlugin) {
        await PreferencesPlugin.set({ key, value });
        return;
      }
      window.localStorage.setItem(key, value);
    },

    async remove(key) {
      if (PreferencesPlugin) {
        await PreferencesPlugin.remove({ key });
        return;
      }
      window.localStorage.removeItem(key);
    }
  };

  let storageAvailable = true;
  let memoryFallback = null;

  async function checkStorageAvailability() {
    try {
      if (PreferencesPlugin) {
        const testKey = '__storage_test__';
        await PreferencesPlugin.set({ key: testKey, value: '1' });
        await PreferencesPlugin.remove({ key: testKey });
        return true;
      }
      const testKey = '__storage_test__';
      window.localStorage.setItem(testKey, '1');
      window.localStorage.removeItem(testKey);
      return true;
    } catch (err) {
      return false;
    }
  }

  async function loadData() {
    let raw = null;

    if (!storageAvailable) {
      raw = memoryFallback;
    } else {
      try {
        const rawString = await Storage.get(STORAGE_KEY);
        raw = rawString ? JSON.parse(rawString) : null;
      } catch (err) {
        console.error('Error al leer almacenamiento, se reinicia el estado:', err);
        raw = null;
      }
    }

    if (!raw || !Array.isArray(raw.employees)) return createEmptyState();

    return {
      employees: raw.employees.map(normalizeEmployee),
      history: Array.isArray(raw.history)
        ? raw.history.map((entry) => ({
            id: entry.id || uid(),
            label: entry.label || 'Semana archivada',
            archivedAt: entry.archivedAt || '',
            employees: Array.isArray(entry.employees)
              ? entry.employees.map(normalizeEmployee)
              : []
          }))
        : [],
      weekStartLabel: raw.weekStartLabel || getCurrentWeekLabel()
    };
  }

  async function saveData(dataState) {
    if (!storageAvailable) {
      memoryFallback = dataState;
      return;
    }
    try {
      await Storage.set(STORAGE_KEY, JSON.stringify(dataState));
    } catch (err) {
      console.error('No se pudo guardar en almacenamiento:', err);
      storageAvailable = false;
      memoryFallback = dataState;
      showStorageWarning();
    }
  }

  function createEmptyState() {
    return { employees: [], history: [], weekStartLabel: getCurrentWeekLabel() };
  }

  function normalizeEmployee(raw) {
    raw = raw || {};

    const payType = raw.payType === 'percentage' ? 'percentage' : 'hourly';

    const hours = {};
    DAYS.forEach((day) => {
      const value = Number(raw.hours && raw.hours[day]);
      hours[day] = Number.isFinite(value) && value >= 0 ? value : 0;
    });

    const hourlyRate = Number(raw.hourlyRate);
    const safeHourlyRate = Number.isFinite(hourlyRate) && hourlyRate >= 0 ? hourlyRate : 0;

    const overtimeThreshold = Number(raw.overtimeThreshold);
    const overtimeRate = Number(raw.overtimeRate);

    const commissionRate = Number(raw.commissionRate);
    const safeCommissionRate =
      Number.isFinite(commissionRate) && commissionRate >= 0 && commissionRate <= 100
        ? commissionRate
        : 0;

    return {
      id: raw.id || uid(),
      name: raw.name && String(raw.name).trim() ? String(raw.name).trim() : 'Sin nombre',
      payType,
      hourlyRate: safeHourlyRate,
      overtimeThreshold:
        Number.isFinite(overtimeThreshold) && overtimeThreshold >= 0
          ? overtimeThreshold
          : DEFAULT_OVERTIME_THRESHOLD,
      overtimeRate:
        Number.isFinite(overtimeRate) && overtimeRate >= 0
          ? overtimeRate
          : Math.round(safeHourlyRate * OVERTIME_DEFAULT_MULTIPLIER),
      hours,
      commissionRate: safeCommissionRate,
      jobs: Array.isArray(raw.jobs)
        ? raw.jobs.map((j) => {
            const jr = Number(j.commissionRate);
            const hasOwnRate =
              j.commissionRate !== null &&
              j.commissionRate !== undefined &&
              j.commissionRate !== '' &&
              Number.isFinite(jr) &&
              jr >= 0 &&
              jr <= 100;
            return {
              id: j.id || uid(),
              description: j.description ? String(j.description).trim() : '',
              value:
                Number.isFinite(Number(j.value)) && Number(j.value) >= 0
                  ? Number(j.value)
                  : 0,
              commissionRate: hasOwnRate ? jr : null,
              date: j.date || ''
            };
          })
        : [],
      advances: Array.isArray(raw.advances)
        ? raw.advances.map((a) => ({
            id: a.id || uid(),
            amount:
              Number.isFinite(Number(a.amount)) && Number(a.amount) >= 0
                ? Number(a.amount)
                : 0,
            note: a.note ? String(a.note).trim() : '',
            date: a.date || ''
          }))
        : [],
      payments: Array.isArray(raw.payments)
        ? raw.payments.map((p) => ({
            id: p.id || uid(),
            amount:
              Number.isFinite(Number(p.amount)) && Number(p.amount) >= 0
                ? Number(p.amount)
                : 0,
            method: PAYMENT_METHODS[p.method] ? p.method : 'efectivo',
            note: p.note ? String(p.note).trim() : '',
            date: p.date || ''
          }))
        : []
    };
  }

  /* ---------------------------------------------------------
     4. UTILIDADES
  --------------------------------------------------------- */

  function uid() {
    return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
  }

  function formatCurrency(amount) {
    const safeAmount = Number.isFinite(amount) ? amount : 0;
    try {
      const numero = new Intl.NumberFormat(CURRENCY_LOCALE, {
        maximumFractionDigits: 0
      }).format(Math.round(safeAmount));
      return CURRENCY_SYMBOL + ' ' + numero;
    } catch (err) {
      return CURRENCY_SYMBOL + ' ' + Math.round(safeAmount);
    }
  }

  function formatHours(hours) {
    const safeHours = Number.isFinite(hours) ? hours : 0;
    return (Math.round(safeHours * 100) / 100).toString();
  }

  function formatPercent(value) {
    const n = Number.isFinite(value) ? value : 0;
    return (Math.round(n * 100) / 100).toString();
  }

  function getCurrentWeekLabel() {
    const now = new Date();
    const options = { day: '2-digit', month: 'short' };
    const start = new Date(now);
    const offset = (now.getDay() + 6) % 7;
    start.setDate(now.getDate() - offset);
    const end = new Date(start);
    end.setDate(start.getDate() + 5);
    const fmt = (d) => d.toLocaleDateString('es-ES', options);
    return `Semana del ${fmt(start)} al ${fmt(end)}`;
  }

  function clampNonNegativeNumber(value) {
    const n = parseFloat(value);
    if (!Number.isFinite(n) || n < 0) return null;
    return n;
  }

  function normalizeText(str) {
    return String(str || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();
  }

  function slugify(str) {
    return (
      normalizeText(str)
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '') || 'planilla'
    );
  }

  function paymentMethodLabel(method) {
    return PAYMENT_METHODS[method] || PAYMENT_METHODS.efectivo;
  }

  function payTypeLabel(payType) {
    return PAY_TYPE_LABELS[payType] || PAY_TYPE_LABELS.hourly;
  }

  function isPercentage(employee) {
    return employee.payType === 'percentage';
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /* ---------------------------------------------------------
     5. ESTADO EN MEMORIA
  --------------------------------------------------------- */

  let state = createEmptyState();

  function persist() {
    saveData(state).catch((err) => {
      console.error('Error persistiendo datos:', err);
      showStorageWarning();
    });
  }

  function findEmployee(id) {
    return state.employees.find((e) => e.id === id) || null;
  }

  function findHistoryEntry(id) {
    return state.history.find((h) => h.id === id) || null;
  }

  /* ---------------------------------------------------------
     6. CÁLCULOS DE NÓMINA
  --------------------------------------------------------- */

  function getTotalHours(employee) {
    if (isPercentage(employee)) return 0;
    return DAYS.reduce((sum, day) => sum + (Number(employee.hours[day]) || 0), 0);
  }

  function getRegularHours(employee) {
    if (isPercentage(employee)) return 0;
    const total = getTotalHours(employee);
    const threshold = Number(employee.overtimeThreshold) || 0;
    return Math.min(total, threshold);
  }

  function getOvertimeHours(employee) {
    if (isPercentage(employee)) return 0;
    const total = getTotalHours(employee);
    const threshold = Number(employee.overtimeThreshold) || 0;
    return Math.max(0, total - threshold);
  }

  function getTotalJobValue(employee) {
    return (employee.jobs || []).reduce((sum, j) => sum + (Number(j.value) || 0), 0);
  }

  function isJobCustomRate(job) {
    return (
      job &&
      job.commissionRate !== null &&
      job.commissionRate !== undefined &&
      Number.isFinite(Number(job.commissionRate))
    );
  }

  function getJobCommissionRate(employee, job) {
    if (isJobCustomRate(job)) return Number(job.commissionRate);
    return Number(employee.commissionRate) || 0;
  }

  function getJobCommission(employee, job) {
    return ((Number(job.value) || 0) * getJobCommissionRate(employee, job)) / 100;
  }

  function getGrossPay(employee) {
    if (isPercentage(employee)) {
      return (employee.jobs || []).reduce(
        (sum, job) => sum + getJobCommission(employee, job),
        0
      );
    }
    const regularPay = getRegularHours(employee) * (Number(employee.hourlyRate) || 0);
    const overtimeRate = Number(employee.overtimeRate) || Number(employee.hourlyRate) || 0;
    const overtimePay = getOvertimeHours(employee) * overtimeRate;
    return regularPay + overtimePay;
  }

  function getTotalAdvances(employee) {
    return employee.advances.reduce((sum, a) => sum + (Number(a.amount) || 0), 0);
  }

  function getNetPay(employee) {
    return getGrossPay(employee) - getTotalAdvances(employee);
  }

  function getTotalPaid(employee) {
    return employee.payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  }

  function getPendingPay(employee) {
    return Math.max(0, getNetPay(employee) - getTotalPaid(employee));
  }

  function getPaymentStatus(employee) {
    const net = getNetPay(employee);
    const paid = getTotalPaid(employee);
    if (net <= MONEY_EPSILON) return 'none';
    if (paid <= MONEY_EPSILON) return 'pending';
    if (paid + MONEY_EPSILON < net) return 'partial';
    return 'paid';
  }

  function getGroupTotals(employees) {
    return employees.reduce(
      (acc, emp) => {
        acc.regularHours += getRegularHours(emp);
        acc.overtimeHours += getOvertimeHours(emp);
        acc.hours += getTotalHours(emp);
        acc.gross += getGrossPay(emp);
        acc.advances += getTotalAdvances(emp);
        acc.net += getNetPay(emp);
        acc.paid += getTotalPaid(emp);
        acc.pending += getPendingPay(emp);
        return acc;
      },
      {
        regularHours: 0,
        overtimeHours: 0,
        hours: 0,
        gross: 0,
        advances: 0,
        net: 0,
        paid: 0,
        pending: 0
      }
    );
  }

  function getPendingEmployees() {
    return state.employees.filter((e) => getPendingPay(e) > MONEY_EPSILON);
  }

  function getPaymentTotalsByMethod(employees) {
    const totals = { efectivo: 0, transferencia: 0, otro: 0 };
    employees.forEach((emp) => {
      emp.payments.forEach((p) => {
        const method = PAYMENT_METHODS[p.method] ? p.method : 'efectivo';
        totals[method] += Number(p.amount) || 0;
      });
    });
    return totals;
  }

  function historyEntryHasPaymentMethod(entry, method) {
    if (!method) return true;
    return entry.employees.some((emp) =>
      emp.payments.some((p) => p.method === method)
    );
  }

  /* ---------------------------------------------------------
     7. REFERENCIAS AL DOM
  --------------------------------------------------------- */

  const storageWarningEl = document.getElementById('storageWarning');
  const weekLabelEl = document.getElementById('weekLabel');
  const exportCsvBtn = document.getElementById('exportCsvBtn');
  const resetWeekBtn = document.getElementById('resetWeekBtn');
  const clearAllBtn = document.getElementById('clearAllBtn');
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const densityToggleBtn = document.getElementById('densityToggleBtn');
  const installAppBtn = document.getElementById('installAppBtn');
  const lastBackupInfoEl = document.getElementById('lastBackupInfo');

  const exportBackupBtn = document.getElementById('exportBackupBtn');
  const importBackupBtn = document.getElementById('importBackupBtn');
  const importBackupInput = document.getElementById('importBackupInput');

  const sumEmployeesEl = document.getElementById('sumEmployees');
  const sumHoursEl = document.getElementById('sumHours');
  const sumOvertimeEl = document.getElementById('sumOvertime');
  const sumGrossEl = document.getElementById('sumGross');
  const sumAdvancesEl = document.getElementById('sumAdvances');
  const sumNetEl = document.getElementById('sumNet');
  const sumPaidEl = document.getElementById('sumPaid');
  const sumPendingEl = document.getElementById('sumPending');

  const addEmployeeForm = document.getElementById('addEmployeeForm');
  const empNameInput = document.getElementById('empName');
  const empPayTypeSelect = document.getElementById('empPayType');
  const empRateInput = document.getElementById('empRate');
  const empRateLabel = document.getElementById('empRateLabel');
  const addEmployeeError = document.getElementById('addEmployeeError');

  const employeeSearchInput = document.getElementById('employeeSearch');
  const filterPendingCheckbox = document.getElementById('filterPending');
  const pendingCountBadgeEl = document.getElementById('pendingCountBadge');
  const employeeListEl = document.getElementById('employeeList');
  const emptyStateEl = document.getElementById('emptyState');
  const noSearchResultsEl = document.getElementById('noSearchResults');

  const pendingSectionEl = document.getElementById('pendingSection');
  const pendingListEl = document.getElementById('pendingList');
  const pendingTotalBadgeEl = document.getElementById('pendingTotalBadge');
  const bulkPayMethodSelect = document.getElementById('bulkPayMethod');
  const payAllPendingBtn = document.getElementById('payAllPendingBtn');

  const profitSectionEl = document.getElementById('profitSection');
  const profitPeriodSelect = document.getElementById('profitPeriodSelect');
  const profitTopSelect = document.getElementById('profitTopSelect');
  const profitStatsEl = document.getElementById('profitStats');
  const profitTopListEl = document.getElementById('profitTopList');
  const profitTopEmptyEl = document.getElementById('profitTopEmpty');
  const profitByEmployeeListEl = document.getElementById('profitByEmployeeList');
  const profitByEmployeeEmptyEl = document.getElementById('profitByEmployeeEmpty');

  const historyListEl = document.getElementById('historyList');
  const emptyHistoryStateEl = document.getElementById('emptyHistoryState');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');
  const historyMethodFilter = document.getElementById('historyMethodFilter');

  const employeeCardTemplate = document.getElementById('employeeCardTemplate');
  const advanceItemTemplate = document.getElementById('advanceItemTemplate');
  const paymentItemTemplate = document.getElementById('paymentItemTemplate');
  const jobItemTemplate = document.getElementById('jobItemTemplate');
  const pendingItemTemplate = document.getElementById('pendingItemTemplate');
  const historyItemTemplate = document.getElementById('historyItemTemplate');
  const historyRowTemplate = document.getElementById('historyRowTemplate');

  /* ---------------------------------------------------------
     8. TEMA (claro / oscuro) — sincrónico, siempre localStorage
  --------------------------------------------------------- */

  function readSavedTheme() {
    try {
      const t = window.localStorage.getItem(THEME_KEY);
      return t === THEME_LIGHT || t === THEME_DARK ? t : null;
    } catch (err) {
      return null;
    }
  }

  function saveTheme(theme) {
    try {
      window.localStorage.setItem(THEME_KEY, theme);
    } catch (err) {
      /* sin persistencia */
    }
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    if (themeToggleBtn) {
      const next = theme === THEME_DARK ? 'claro' : 'oscuro';
      themeToggleBtn.setAttribute('aria-label', 'Cambiar a tema ' + next);
      themeToggleBtn.title = 'Cambiar a tema ' + next;
    }
  }

  function handleThemeToggle() {
    const current =
      document.documentElement.getAttribute('data-theme') === THEME_DARK
        ? THEME_DARK
        : THEME_LIGHT;
    const next = current === THEME_DARK ? THEME_LIGHT : THEME_DARK;
    saveTheme(next);
    applyTheme(next);
  }

  function watchSystemTheme() {
    if (!window.matchMedia) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const listener = (e) => {
      if (readSavedTheme() !== null) return;
      applyTheme(e.matches ? THEME_DARK : THEME_LIGHT);
    };
    if (mq.addEventListener) mq.addEventListener('change', listener);
    else if (mq.addListener) mq.addListener(listener);
  }

  /* ---------------------------------------------------------
     9. DENSIDAD (cómoda / compacta) — sincrónico, localStorage
  --------------------------------------------------------- */

  function readSavedDensity() {
    try {
      const d = window.localStorage.getItem(DENSITY_KEY);
      return d === DENSITY_COMPACT || d === DENSITY_COMFORTABLE ? d : null;
    } catch (err) {
      return null;
    }
  }

  function saveDensity(density) {
    try {
      window.localStorage.setItem(DENSITY_KEY, density);
    } catch (err) {
      /* sin persistencia */
    }
  }

  function applyDensity(density) {
    document.documentElement.setAttribute('data-density', density);
    if (densityToggleBtn) {
      const next = density === DENSITY_COMPACT ? 'cómoda' : 'compacta';
      densityToggleBtn.setAttribute('aria-label', 'Cambiar a vista ' + next);
      densityToggleBtn.title = 'Cambiar a vista ' + next;
    }
  }

  function handleDensityToggle() {
    const current =
      document.documentElement.getAttribute('data-density') === DENSITY_COMPACT
        ? DENSITY_COMPACT
        : DENSITY_COMFORTABLE;
    const next = current === DENSITY_COMPACT ? DENSITY_COMFORTABLE : DENSITY_COMPACT;
    saveDensity(next);
    applyDensity(next);
  }
    /* ---------------------------------------------------------
     10. RENDERIZADO — RESUMEN Y ENCABEZADO
  --------------------------------------------------------- */

  function showStorageWarning() {
    if (storageWarningEl) storageWarningEl.classList.remove('hidden');
  }

  function renderWeekLabel() {
    if (!weekLabelEl) return;
    weekLabelEl.textContent = state.weekStartLabel || getCurrentWeekLabel();
  }

  function renderSummary() {
    const totals = getGroupTotals(state.employees);
    if (sumEmployeesEl) sumEmployeesEl.textContent = state.employees.length.toString();
    if (sumHoursEl) sumHoursEl.textContent = formatHours(totals.hours);
    if (sumOvertimeEl) sumOvertimeEl.textContent = formatHours(totals.overtimeHours);
    if (sumGrossEl) sumGrossEl.textContent = formatCurrency(totals.gross);
    if (sumAdvancesEl) sumAdvancesEl.textContent = formatCurrency(totals.advances);
    if (sumNetEl) sumNetEl.textContent = formatCurrency(totals.net);
    if (sumPaidEl) sumPaidEl.textContent = formatCurrency(totals.paid);
    if (sumPendingEl) {
      sumPendingEl.textContent = formatCurrency(totals.pending);
      const pendingCard = sumPendingEl.closest('.summary-item-pending');
      if (pendingCard) pendingCard.classList.toggle('is-zero', totals.pending <= MONEY_EPSILON);
    }

    const pendingCount = getPendingEmployees().length;
    if (pendingCountBadgeEl) {
      pendingCountBadgeEl.textContent = pendingCount.toString();
      pendingCountBadgeEl.classList.toggle('hidden', pendingCount === 0);
    }
  }

  /* ---------------------------------------------------------
     11. RENDERIZADO — TARJETAS DE EMPLEADOS
  --------------------------------------------------------- */

  function renderEmployeeStats(card, employee) {
    const primaryLabel = card.querySelector('.stat-primary-label');
    const primaryValue = card.querySelector('.stat-primary-value');
    const secondaryLabel = card.querySelector('.stat-secondary-label');
    const secondaryValue = card.querySelector('.stat-secondary-value');

    if (isPercentage(employee)) {
      primaryLabel.textContent = 'Trabajos';
      primaryValue.textContent = employee.jobs.length.toString();
      secondaryLabel.textContent = 'Valor trabajos';
      secondaryValue.textContent = formatCurrency(getTotalJobValue(employee));
    } else {
      primaryLabel.textContent = 'Horas normales';
      primaryValue.textContent = formatHours(getRegularHours(employee));
      secondaryLabel.textContent = 'Horas extra';
      secondaryValue.textContent = formatHours(getOvertimeHours(employee));
    }

    card.querySelector('.stat-gross').textContent = formatCurrency(getGrossPay(employee));
    card.querySelector('.stat-advances').textContent = formatCurrency(getTotalAdvances(employee));

    const netEl = card.querySelector('.stat-net');
    const net = getNetPay(employee);
    netEl.textContent = formatCurrency(net);
    netEl.classList.toggle('negative', net < 0);

    card.querySelector('.employee-rate').textContent = isPercentage(employee)
      ? formatPercent(employee.commissionRate) + '% por defecto'
      : formatCurrency(employee.hourlyRate) + ' / hora normal';

    const jobRateInput = card.querySelector('.job-rate');
    if (jobRateInput) {
      jobRateInput.placeholder = 'Auto (' + formatPercent(employee.commissionRate) + '%)';
    }
  }

  function renderPaymentBadge(card, employee) {
    const badge = card.querySelector('.payment-badge');
    const status = getPaymentStatus(employee);
    const net = getNetPay(employee);
    const paid = getTotalPaid(employee);
    const pending = getPendingPay(employee);

    badge.classList.remove('status-pending', 'status-partial', 'status-paid', 'status-none');
    badge.classList.add('status-' + status);

    let text = '';
    let title = '';
    switch (status) {
      case 'paid':
        text = '✓ Pagado';
        title =
          paid > net + MONEY_EPSILON
            ? `Pagado ${formatCurrency(paid)} (incluye ${formatCurrency(paid - net)} de más)`
            : `Pagado por completo (${formatCurrency(paid)})`;
        break;
      case 'partial':
        text = '◐ Falta ' + formatCurrency(pending);
        title = `Pagado ${formatCurrency(paid)} de ${formatCurrency(net)}`;
        break;
      case 'pending':
        text = '● Pendiente ' + formatCurrency(net);
        title = 'Sin pagos registrados';
        break;
      default:
        text = '— Sin saldo';
        title = 'El empleado no tiene saldo a favor esta semana';
    }
    badge.textContent = text;
    badge.title = title;
    badge.setAttribute('aria-label', title);

    const cardEl = card.querySelector('.employee-card') || card;
    cardEl.classList.toggle('is-fully-paid', status === 'paid');
  }

  function renderAdvancesList(card, employee) {
    const listEl = card.querySelector('.advances-list');
    const noAdvancesMsg = card.querySelector('.no-advances-msg');
    listEl.innerHTML = '';

    if (employee.advances.length === 0) {
      noAdvancesMsg.classList.remove('hidden');
    } else {
      noAdvancesMsg.classList.add('hidden');
      employee.advances.forEach((advance) => {
        const item = advanceItemTemplate.content.cloneNode(true);
        const li = item.querySelector('.advance-item');
        li.dataset.advanceId = advance.id;
        li.querySelector('.advance-amount-text').textContent =
          '-' + formatCurrency(advance.amount);
        li.querySelector('.advance-note-text').textContent = advance.note || 'Sin nota';
        li.querySelector('.advance-date-text').textContent = advance.date;
        listEl.appendChild(item);
      });
    }
  }

  function renderPaymentsList(card, employee) {
    const listEl = card.querySelector('.payments-list');
    const noPaymentsMsg = card.querySelector('.no-payments-msg');
    const summaryEl = card.querySelector('.payment-summary');
    listEl.innerHTML = '';

    const net = getNetPay(employee);
    const paid = getTotalPaid(employee);
    const pending = getPendingPay(employee);

    if (employee.payments.length === 0) {
      noPaymentsMsg.classList.remove('hidden');
    } else {
      noPaymentsMsg.classList.add('hidden');
      employee.payments.forEach((payment) => {
        const item = paymentItemTemplate.content.cloneNode(true);
        const li = item.querySelector('.payment-item');
        li.dataset.paymentId = payment.id;
        li.querySelector('.payment-amount-text').textContent = formatCurrency(payment.amount);
        li.querySelector('.payment-method-text').textContent = paymentMethodLabel(
          payment.method
        );
        li.querySelector('.payment-note-text').textContent = payment.note || 'Sin nota';
        li.querySelector('.payment-date-text').textContent = payment.date;
        listEl.appendChild(item);
      });
    }

    if (net <= MONEY_EPSILON) {
      summaryEl.innerHTML = 'Sin saldo a favor esta semana.';
    } else if (pending <= MONEY_EPSILON) {
      summaryEl.innerHTML = `<strong>${formatCurrency(paid)}</strong> pagado · <strong>al día</strong>`;
    } else {
      summaryEl.innerHTML = `<strong>${formatCurrency(paid)}</strong> de <strong>${formatCurrency(
        net
      )}</strong> · falta <strong>${formatCurrency(pending)}</strong>`;
    }
  }

  function renderJobsList(card, employee) {
    const listEl = card.querySelector('.jobs-list');
    const noJobsMsg = card.querySelector('.no-jobs-msg');
    const summaryEl = card.querySelector('.jobs-summary');
    listEl.innerHTML = '';

    if (employee.jobs.length === 0) {
      noJobsMsg.classList.remove('hidden');
    } else {
      noJobsMsg.classList.add('hidden');
      employee.jobs.forEach((job) => {
        const item = jobItemTemplate.content.cloneNode(true);
        const li = item.querySelector('.job-item');
        li.dataset.jobId = job.id;

        const effectiveRate = getJobCommissionRate(employee, job);
        const commission = getJobCommission(employee, job);
        const isCustom = isJobCustomRate(job);

        li.querySelector('.job-description-text').textContent =
          job.description || 'Sin descripción';
        li.querySelector('.job-value-text').textContent = formatCurrency(job.value);

        const rateEl = li.querySelector('.job-rate-text');
        rateEl.textContent = formatPercent(effectiveRate) + '%';
        if (isCustom) {
          rateEl.classList.add('custom-rate');
          rateEl.title = 'Comisión propia de este trabajo';
        } else {
          rateEl.title =
            'Usa la comisión por defecto del empleado (' +
            formatPercent(employee.commissionRate) +
            '%)';
        }

        li.querySelector('.job-commission-text').textContent =
          '→ ' + formatCurrency(commission);
        li.querySelector('.job-date-text').textContent = job.date;
        listEl.appendChild(li);
      });
    }

    const totalValue = getTotalJobValue(employee);
    const totalCommission = getGrossPay(employee);
    const customCount = employee.jobs.filter(isJobCustomRate).length;

    if (employee.jobs.length === 0) {
      summaryEl.textContent = 'Sin trabajos cargados.';
    } else {
      const jobsWord = employee.jobs.length === 1 ? 'trabajo' : 'trabajos';
      const customInfo =
        customCount > 0 ? ` · <strong>${customCount}</strong> con % propio` : '';
      summaryEl.innerHTML = `<strong>${formatCurrency(
        totalValue
      )}</strong> en <strong>${
        employee.jobs.length
      }</strong> ${jobsWord} · comisiones <strong>${formatCurrency(
        totalCommission
      )}</strong>${customInfo}`;
    }
  }

  function renderEmployeeCard(employee) {
    const fragment = employeeCardTemplate.content.cloneNode(true);
    const card = fragment.querySelector('.employee-card');
    card.dataset.employeeId = employee.id;
    card.querySelector('.employee-name').textContent = employee.name;
    card.querySelector('.pay-type-select').value = employee.payType;

    DAYS.forEach((day) => {
      const input = card.querySelector(`.hours-input[data-day="${day}"]`);
      const value = employee.hours[day];
      input.value = value ? value : '';
    });

    card.querySelector('.overtime-threshold-input').value = employee.overtimeThreshold;
    card.querySelector('.overtime-rate-input').value = employee.overtimeRate;

    const hoursPanel = card.querySelector('.hours-panel');
    const jobsPanel = card.querySelector('.jobs-panel');
    if (isPercentage(employee)) {
      hoursPanel.classList.add('hidden');
      jobsPanel.classList.remove('hidden');
    } else {
      hoursPanel.classList.remove('hidden');
      jobsPanel.classList.add('hidden');
    }

    renderEmployeeStats(card, employee);
    renderPaymentBadge(card, employee);
    renderAdvancesList(card, employee);
    renderPaymentsList(card, employee);
    renderJobsList(card, employee);
    attachCardEvents(card);

    return card;
  }

  function renderEmployeeList() {
    employeeListEl.innerHTML = '';

    if (state.employees.length === 0) {
      emptyStateEl.classList.remove('hidden');
      noSearchResultsEl.classList.add('hidden');
      return;
    }
    emptyStateEl.classList.add('hidden');

    const term = normalizeText(employeeSearchInput.value);
    const onlyPending = filterPendingCheckbox.checked;

    const visibleEmployees = state.employees.filter((emp) => {
      if (term && !normalizeText(emp.name).includes(term)) return false;
      if (onlyPending && getPendingPay(emp) <= MONEY_EPSILON) return false;
      return true;
    });

    if (visibleEmployees.length === 0) {
      let msg = 'No se encontraron empleados con ese nombre.';
      if (onlyPending && term) {
        msg = 'Ningún empleado pendiente coincide con la búsqueda.';
      } else if (onlyPending) {
        msg = 'No hay empleados con pagos pendientes esta semana. 🎉';
      }
      noSearchResultsEl.textContent = msg;
      noSearchResultsEl.classList.remove('hidden');
      return;
    }
    noSearchResultsEl.classList.add('hidden');

    visibleEmployees.forEach((employee) => {
      employeeListEl.appendChild(renderEmployeeCard(employee));
    });
  }

  /* ---------------------------------------------------------
     12. RENDERIZADO — VISTA COMPACTA "FALTAN PAGAR"
  --------------------------------------------------------- */

  function renderPendingList() {
    const pendingEmployees = getPendingEmployees();

    if (pendingEmployees.length === 0) {
      pendingSectionEl.classList.add('hidden');
      pendingListEl.innerHTML = '';
      return;
    }

    pendingSectionEl.classList.remove('hidden');
    pendingListEl.innerHTML = '';

    let totalPending = 0;
    pendingEmployees.forEach((employee) => {
      const pending = getPendingPay(employee);
      const net = getNetPay(employee);
      totalPending += pending;

      const item = pendingItemTemplate.content.cloneNode(true);
      const li = item.querySelector('.pending-item');
      li.dataset.employeeId = employee.id;
      li.querySelector('.pending-name').textContent = employee.name;
      li.querySelector('.pending-amount-strong').textContent = formatCurrency(pending);
      li.querySelector('.pending-amount-detail').textContent = 'de ' + formatCurrency(net);
      pendingListEl.appendChild(li);
    });

    pendingTotalBadgeEl.textContent =
      pendingEmployees.length === 1
        ? `1 empleado · ${formatCurrency(totalPending)}`
        : `${pendingEmployees.length} empleados · ${formatCurrency(totalPending)}`;
  }

  function handlePendingPayClick(employeeId) {
    employeeSearchInput.value = '';
    filterPendingCheckbox.checked = false;
    renderEmployeeList();

    const card = employeeListEl.querySelector(
      `.employee-card[data-employee-id="${employeeId}"]`
    );
    if (!card) return;

    handleQuickPay(card, employeeId);
  }

  /* ---------------------------------------------------------
     13. RENDERIZADO — REPORTE DE RENTABILIDAD
  --------------------------------------------------------- */

  function rebuildProfitPeriodOptions() {
    const currentValue = profitPeriodSelect.value || 'current';

    const options = [
      {
        value: 'current',
        label: 'Semana actual — ' + (state.weekStartLabel || getCurrentWeekLabel())
      }
    ];
    state.history.forEach((entry) => {
      options.push({ value: 'history-' + entry.id, label: entry.label });
    });

    profitPeriodSelect.innerHTML = '';
    options.forEach((opt) => {
      const optionEl = document.createElement('option');
      optionEl.value = opt.value;
      optionEl.textContent = opt.label;
      profitPeriodSelect.appendChild(optionEl);
    });

    const stillThere = options.some((o) => o.value === currentValue);
    profitPeriodSelect.value = stillThere ? currentValue : 'current';
  }

  function getProfitPeriodEmployees() {
    const value = profitPeriodSelect.value || 'current';
    if (value === 'current') {
      return {
        employees: state.employees,
        label: state.weekStartLabel || getCurrentWeekLabel()
      };
    }
    if (value.indexOf('history-') === 0) {
      const id = value.slice('history-'.length);
      const entry = findHistoryEntry(id);
      if (entry) return { employees: entry.employees, label: entry.label };
    }
    return {
      employees: state.employees,
      label: state.weekStartLabel || getCurrentWeekLabel()
    };
  }

  function getProfitData(employees) {
    const jobs = [];

    employees.forEach((emp) => {
      if (!isPercentage(emp)) return;
      (emp.jobs || []).forEach((job) => {
        jobs.push({
          job,
          employeeName: emp.name,
          rate: getJobCommissionRate(emp, job),
          commission: getJobCommission(emp, job),
          isCustom: isJobCustomRate(job)
        });
      });
    });

    const totals = jobs.reduce(
      (acc, j) => {
        acc.count += 1;
        acc.value += Number(j.job.value) || 0;
        acc.commission += j.commission;
        return acc;
      },
      { count: 0, value: 0, commission: 0 }
    );
    totals.effectiveRate = totals.value > 0 ? (totals.commission / totals.value) * 100 : 0;
    totals.avgTicket = totals.count > 0 ? totals.value / totals.count : 0;

    return { jobs, totals };
  }

  function renderProfitStats(totals) {
    const stats = [
      { label: 'Trabajos', value: totals.count.toString() },
      { label: 'Valor total', value: formatCurrency(totals.value) },
      { label: 'Comisión total', value: formatCurrency(totals.commission), highlight: true },
      { label: 'Ticket promedio', value: formatCurrency(totals.avgTicket) },
      { label: '% efectivo promedio', value: formatPercent(totals.effectiveRate) + '%' }
    ];

    profitStatsEl.innerHTML = '';
    stats.forEach((stat) => {
      const div = document.createElement('div');
      div.className = 'profit-stat' + (stat.highlight ? ' profit-stat-highlight' : '');
      const valueEl = document.createElement('span');
      valueEl.className = 'profit-stat-value';
      valueEl.textContent = stat.value;
      const labelEl = document.createElement('span');
      labelEl.className = 'profit-stat-label';
      labelEl.textContent = stat.label;
      div.appendChild(valueEl);
      div.appendChild(labelEl);
      profitStatsEl.appendChild(div);
    });
  }

  function renderProfitTopList(jobs) {
    const limit = profitTopSelect.value;
    const sorted = jobs.slice().sort((a, b) => b.commission - a.commission);
    const visible = limit === 'all' ? sorted : sorted.slice(0, parseInt(limit, 10));

    profitTopListEl.innerHTML = '';

    if (sorted.length === 0) {
      profitTopEmptyEl.classList.remove('hidden');
      return;
    }
    profitTopEmptyEl.classList.add('hidden');

    visible.forEach((item, index) => {
      const tr = document.createElement('tr');
      if (index === 0) tr.classList.add('profit-rank-1');
      else if (index === 1) tr.classList.add('profit-rank-2');
      else if (index === 2) tr.classList.add('profit-rank-3');

      const rankTd = document.createElement('td');
      rankTd.className = 'col-rank';
      rankTd.textContent = (index + 1).toString();

      const descTd = document.createElement('td');
      descTd.className = 'col-desc';
      descTd.textContent = item.job.description || 'Sin descripción';
      descTd.title = item.job.description || '';

      const empTd = document.createElement('td');
      empTd.className = 'col-emp';
      empTd.textContent = item.employeeName;

      const valueTd = document.createElement('td');
      valueTd.className = 'num';
      valueTd.textContent = formatCurrency(item.job.value);

      const rateTd = document.createElement('td');
      rateTd.className = 'num';
      const badge = document.createElement('span');
      badge.className =
        'rate-badge ' + (item.isCustom ? 'rate-badge-custom' : 'rate-badge-default');
      badge.textContent = formatPercent(item.rate) + '%';
      badge.title = item.isCustom
        ? 'Comisión propia del trabajo'
        : 'Comisión por defecto del empleado';
      rateTd.appendChild(badge);

      const commTd = document.createElement('td');
      commTd.className = 'num col-commission';
      commTd.textContent = formatCurrency(item.commission);

      tr.appendChild(rankTd);
      tr.appendChild(descTd);
      tr.appendChild(empTd);
      tr.appendChild(valueTd);
      tr.appendChild(rateTd);
      tr.appendChild(commTd);
      profitTopListEl.appendChild(tr);
    });
  }

  function renderProfitByEmployee(employees) {
    const byEmp = new Map();

    employees.forEach((emp) => {
      if (!isPercentage(emp)) return;
      const jobs = emp.jobs || [];
      if (jobs.length === 0) return;

      let value = 0;
      let commission = 0;
      jobs.forEach((job) => {
        value += Number(job.value) || 0;
        commission += getJobCommission(emp, job);
      });

      byEmp.set(emp.id, {
        name: emp.name,
        count: jobs.length,
        value,
        commission,
        effectiveRate: value > 0 ? (commission / value) * 100 : 0
      });
    });

    const rows = Array.from(byEmp.values()).sort((a, b) => b.commission - a.commission);

    profitByEmployeeListEl.innerHTML = '';

    if (rows.length === 0) {
      profitByEmployeeEmptyEl.classList.remove('hidden');
      return;
    }
    profitByEmployeeEmptyEl.classList.add('hidden');

    rows.forEach((row) => {
      const tr = document.createElement('tr');

      const nameTd = document.createElement('td');
      nameTd.textContent = row.name;

      const countTd = document.createElement('td');
      countTd.className = 'num';
      countTd.textContent = row.count.toString();

      const valueTd = document.createElement('td');
      valueTd.className = 'num';
      valueTd.textContent = formatCurrency(row.value);

      const commTd = document.createElement('td');
      commTd.className = 'num col-commission';
      commTd.textContent = formatCurrency(row.commission);

      const rateTd = document.createElement('td');
      rateTd.className = 'num';
      rateTd.textContent = formatPercent(row.effectiveRate) + '%';

      tr.appendChild(nameTd);
      tr.appendChild(countTd);
      tr.appendChild(valueTd);
      tr.appendChild(commTd);
      tr.appendChild(rateTd);
      profitByEmployeeListEl.appendChild(tr);
    });
  }

  function renderProfitReport() {
    rebuildProfitPeriodOptions();

    const hasAnyPercentageEmployee =
      state.employees.some((e) => isPercentage(e)) ||
      state.history.some((h) => h.employees.some((e) => isPercentage(e)));

    if (!hasAnyPercentageEmployee) {
      profitSectionEl.classList.add('hidden');
      return;
    }
    profitSectionEl.classList.remove('hidden');

    const period = getProfitPeriodEmployees();
    const { jobs, totals } = getProfitData(period.employees);

    renderProfitStats(totals);
    renderProfitTopList(jobs);
    renderProfitByEmployee(period.employees);
  }

  /* ---------------------------------------------------------
     14. ACCIÓN: PAGAR TODOS LOS PENDIENTES
  --------------------------------------------------------- */

  function handlePayAllPending() {
    const pendingEmployees = getPendingEmployees();
    if (pendingEmployees.length === 0) {
      window.alert('No hay empleados con saldo pendiente.');
      return;
    }

    const totalToPay = pendingEmployees.reduce((sum, e) => sum + getPendingPay(e), 0);
    const method = PAYMENT_METHODS[bulkPayMethodSelect.value]
      ? bulkPayMethodSelect.value
      : 'efectivo';
    const methodLabel = paymentMethodLabel(method);

    const detalle =
      pendingEmployees.length === 1
        ? `1 empleado (${pendingEmployees[0].name})`
        : `${pendingEmployees.length} empleados`;

    const confirmed = window.confirm(
      `¿Registrar el pago de ${detalle} por un total de ${formatCurrency(totalToPay)}?\n\n` +
        `Método: ${methodLabel}\n` +
        `Nota: "${BULK_PAYMENT_NOTE}"\n\n` +
        `Se va a crear un pago individual por el saldo pendiente de cada empleado.`
    );
    if (!confirmed) return;

    const date = new Date().toLocaleDateString('es-ES');
    let registered = 0;

    pendingEmployees.forEach((employee) => {
      const amount = getPendingPay(employee);
      if (amount <= MONEY_EPSILON) return;
      employee.payments.push({
        id: uid(),
        amount,
        method,
        note: BULK_PAYMENT_NOTE,
        date
      });
      registered++;
    });

    persist();
    renderAll();

    if (registered > 0) {
      console.info(
        `Pago masivo registrado: ${registered} empleado(s), total ${formatCurrency(
          totalToPay
        )} (${methodLabel}).`
      );
    }
  }

  function renderAll() {
    renderWeekLabel();
    renderSummary();
    renderEmployeeList();
    renderPendingList();
    renderProfitReport();
    renderHistory();
  }

  /* ---------------------------------------------------------
     15. VALIDACIÓN Y MENSAJES DE ERROR
  --------------------------------------------------------- */

  function showFieldError(el, message) {
    el.textContent = message;
    el.classList.remove('hidden');
  }

  function hideFieldError(el) {
    el.textContent = '';
    el.classList.add('hidden');
  }

  function markInvalid(inputEl, invalid) {
    inputEl.classList.toggle('input-invalid', invalid);
  }

  /* ---------------------------------------------------------
     16. ALTA DE EMPLEADO
  --------------------------------------------------------- */

  function syncAddFormFields() {
    const type = empPayTypeSelect.value === 'percentage' ? 'percentage' : 'hourly';
    if (type === 'percentage') {
      empRateLabel.textContent = 'Comisión por defecto (%)';
      empRateInput.placeholder = 'Ej: 30';
      empRateInput.step = '0.5';
      empRateInput.max = '100';
    } else {
      empRateLabel.textContent = 'Salario por hora (₲)';
      empRateInput.placeholder = 'Ej: 15000';
      empRateInput.step = '0.01';
      empRateInput.removeAttribute('max');
    }
  }

  function handleAddEmployee(evt) {
    evt.preventDefault();
    hideFieldError(addEmployeeError);
    markInvalid(empNameInput, false);
    markInvalid(empRateInput, false);

    const name = empNameInput.value.trim();
    const payType = empPayTypeSelect.value === 'percentage' ? 'percentage' : 'hourly';
    const rate = clampNonNegativeNumber(empRateInput.value);

    if (!name) {
      markInvalid(empNameInput, true);
      showFieldError(addEmployeeError, 'Ingresá el nombre del empleado.');
      empNameInput.focus();
      return;
    }
    if (rate === null || rate === 0) {
      markInvalid(empRateInput, true);
      showFieldError(
        addEmployeeError,
        payType === 'percentage'
          ? 'Ingresá una comisión por defecto válida (mayor a 0 y hasta 100).'
          : 'Ingresá un salario por hora válido, mayor a 0.'
      );
      empRateInput.focus();
      return;
    }
    if (payType === 'percentage' && rate > 100) {
      markInvalid(empRateInput, true);
      showFieldError(addEmployeeError, 'La comisión debe estar entre 0 y 100 %.');
      empRateInput.focus();
      return;
    }

    const newEmployee = normalizeEmployee({
      name,
      payType,
      hourlyRate: payType === 'hourly' ? rate : 0,
      commissionRate: payType === 'percentage' ? rate : 0
    });
    state.employees.push(newEmployee);
    persist();

    addEmployeeForm.reset();
    syncAddFormFields();
    employeeSearchInput.value = '';
    filterPendingCheckbox.checked = false;
    renderAll();
    empNameInput.focus();
  }

  function handleRemoveEmployee(employeeId) {
    const employee = findEmployee(employeeId);
    if (!employee) return;
    const confirmed = window.confirm(
      `¿Eliminar a "${employee.name}" y todos sus datos de esta semana? Esta acción no se puede deshacer.`
    );
    if (!confirmed) return;

    state.employees = state.employees.filter((e) => e.id !== employeeId);
    persist();
    renderAll();
  }

  function handleEditRate(employeeId) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    if (isPercentage(employee)) {
      const input = window.prompt(
        `Nueva comisión por defecto (%) para ${employee.name}.\n\n` +
          `Este % aplica a los trabajos que no tengan comisión propia.`,
        employee.commissionRate
      );
      if (input === null) return;
      const rate = clampNonNegativeNumber(input);
      if (rate === null || rate === 0 || rate > 100) {
        window.alert('La comisión por defecto debe ser un número entre 0 y 100.');
        return;
      }
      employee.commissionRate = rate;
    } else {
      const input = window.prompt(
        `Nuevo salario por hora para ${employee.name} (₲):`,
        employee.hourlyRate
      );
      if (input === null) return;
      const rate = clampNonNegativeNumber(input);
      if (rate === null || rate === 0) {
        window.alert('El salario por hora debe ser un número mayor a 0.');
        return;
      }
      const autoAnterior = Math.round(employee.hourlyRate * OVERTIME_DEFAULT_MULTIPLIER);
      const eraAutomatica = employee.overtimeRate === autoAnterior;
      employee.hourlyRate = rate;
      if (eraAutomatica) {
        employee.overtimeRate = Math.round(rate * OVERTIME_DEFAULT_MULTIPLIER);
      }
    }

    persist();
    renderAll();
  }

  function handlePayTypeChange(card, employeeId, selectEl) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const newType = selectEl.value === 'percentage' ? 'percentage' : 'hourly';
    if (newType === employee.payType) return;

    const confirmed = window.confirm(
      `¿Cambiar a "${payTypeLabel(newType)}" el tipo de pago de ${employee.name}?\n\n` +
        `Los datos de horas y trabajos se conservan, pero el cálculo del salario cambiará.`
    );
    if (!confirmed) {
      selectEl.value = employee.payType;
      return;
    }

    employee.payType = newType;
    persist();
    renderAll();
  }

  /* ---------------------------------------------------------
     17. ACCIONES: HORAS DIARIAS
  --------------------------------------------------------- */

  function handleHoursChange(card, employeeId, inputEl) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const errorEl = card.querySelector('.hours-error');
    const day = inputEl.dataset.day;
    const rawValue = inputEl.value;

    if (rawValue.trim() === '') {
      employee.hours[day] = 0;
      markInvalid(inputEl, false);
      hideFieldError(errorEl);
      persist();
      refreshEmployeeDerivedViews(card, employee);
      return;
    }

    const hours = parseFloat(rawValue);
    if (!Number.isFinite(hours) || hours < 0 || hours > MAX_DAILY_HOURS) {
      markInvalid(inputEl, true);
      showFieldError(errorEl, `Las horas deben ser un número entre 0 y ${MAX_DAILY_HOURS}.`);
      inputEl.value = employee.hours[day] ? employee.hours[day] : '';
      return;
    }

    markInvalid(inputEl, false);
    hideFieldError(errorEl);
    employee.hours[day] = hours;
    persist();
    refreshEmployeeDerivedViews(card, employee);
  }

  /* ---------------------------------------------------------
     18. ACCIONES: HORAS EXTRA
  --------------------------------------------------------- */

  function handleOvertimeThresholdChange(card, employeeId, inputEl) {
    const employee = findEmployee(employeeId);
    if (!employee) return;
    const errorEl = card.querySelector('.overtime-error');

    const value = clampNonNegativeNumber(inputEl.value);
    if (value === null || value > MAX_WEEKLY_HOURS) {
      markInvalid(inputEl, true);
      showFieldError(
        errorEl,
        `El umbral debe ser un número entre 0 y ${MAX_WEEKLY_HOURS} horas semanales.`
      );
      return;
    }

    markInvalid(inputEl, false);
    hideFieldError(errorEl);
    employee.overtimeThreshold = value;
    persist();
    refreshEmployeeDerivedViews(card, employee);
  }

  function handleOvertimeRateChange(card, employeeId, inputEl) {
    const employee = findEmployee(employeeId);
    if (!employee) return;
    const errorEl = card.querySelector('.overtime-error');

    const value = clampNonNegativeNumber(inputEl.value);
    if (value === null) {
      markInvalid(inputEl, true);
      showFieldError(errorEl, 'La tarifa de hora extra debe ser un número válido (0 o mayor).');
      return;
    }

    markInvalid(inputEl, false);
    hideFieldError(errorEl);
    employee.overtimeRate = value;
    persist();
    refreshEmployeeDerivedViews(card, employee);
  }

  /* ---------------------------------------------------------
     19. ACCIONES: TRABAJOS POR PORCENTAJE
  --------------------------------------------------------- */

  function handleAddJob(card, employeeId, form) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const descInput = form.querySelector('.job-description');
    const valueInput = form.querySelector('.job-value');
    const rateInput = form.querySelector('.job-rate');
    const errorEl = card.querySelector('.job-error');

    hideFieldError(errorEl);
    markInvalid(valueInput, false);
    markInvalid(rateInput, false);

    const value = clampNonNegativeNumber(valueInput.value);
    if (value === null || value === 0) {
      markInvalid(valueInput, true);
      showFieldError(errorEl, 'Ingresá un valor de trabajo válido, mayor a 0.');
      valueInput.focus();
      return;
    }

    let commissionRate = null;
    const rawRate = rateInput.value.trim();
    if (rawRate !== '') {
      const parsed = parseFloat(rawRate);
      if (!Number.isFinite(parsed) || parsed < 0 || parsed > 100) {
        markInvalid(rateInput, true);
        showFieldError(
          errorEl,
          'La comisión del trabajo debe ser un número entre 0 y 100, o dejarse vacía para usar la del empleado.'
        );
        rateInput.focus();
        return;
      }
      commissionRate = parsed;
    }

    employee.jobs.push({
      id: uid(),
      description: descInput.value.trim(),
      value,
      commissionRate,
      date: new Date().toLocaleDateString('es-ES')
    });

    persist();
    renderJobsList(card, employee);
    refreshEmployeeDerivedViews(card, employee);

    form.reset();
    rateInput.placeholder = 'Auto (' + formatPercent(employee.commissionRate) + '%)';
    descInput.focus();
  }

  function handleRemoveJob(card, employeeId, jobId) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const confirmed = window.confirm('¿Eliminar este trabajo?');
    if (!confirmed) return;

    employee.jobs = employee.jobs.filter((j) => j.id !== jobId);
    persist();
    renderJobsList(card, employee);
    refreshEmployeeDerivedViews(card, employee);
  }

  function handleEditJobRate(card, employeeId, jobId) {
    const employee = findEmployee(employeeId);
    if (!employee) return;
    const job = employee.jobs.find((j) => j.id === jobId);
    if (!job) return;

    const currentValue = isJobCustomRate(job) ? job.commissionRate : '';
    const prompt =
      `Comisión (%) para "${job.description || 'trabajo'}".\n\n` +
      `Dejalo vacío para usar la comisión por defecto del empleado (${formatPercent(
        employee.commissionRate
      )}%).`;

    const input = window.prompt(prompt, currentValue);
    if (input === null) return;

    const trimmed = String(input).trim();
    if (trimmed === '') {
      job.commissionRate = null;
    } else {
      const parsed = parseFloat(trimmed);
      if (!Number.isFinite(parsed) || parsed < 0 || parsed > 100) {
        window.alert('La comisión debe ser un número entre 0 y 100.');
        return;
      }
      job.commissionRate = parsed;
    }

    persist();
    renderJobsList(card, employee);
    refreshEmployeeDerivedViews(card, employee);
  }

  /* ---------------------------------------------------------
     20. ACCIONES: PAGOS ADELANTADOS
  --------------------------------------------------------- */

  function handleAddAdvance(card, employeeId, form) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const amountInput = form.querySelector('.advance-amount');
    const noteInput = form.querySelector('.advance-note');
    const errorEl = card.querySelector('.advance-error');

    hideFieldError(errorEl);
    markInvalid(amountInput, false);

    const amount = clampNonNegativeNumber(amountInput.value);
    if (amount === null || amount === 0) {
      markInvalid(amountInput, true);
      showFieldError(errorEl, 'Ingresá un monto de adelanto válido, mayor a 0.');
      amountInput.focus();
      return;
    }

    const gross = getGrossPay(employee);
    const currentAdvances = getTotalAdvances(employee);
    if (currentAdvances + amount > gross && gross > 0) {
      const proceed = window.confirm(
        'Este adelanto supera el salario bruto calculado hasta ahora. ¿Registrarlo de todas formas?'
      );
      if (!proceed) return;
    }

    employee.advances.push({
      id: uid(),
      amount,
      note: noteInput.value.trim(),
      date: new Date().toLocaleDateString('es-ES')
    });

    persist();
    renderAdvancesList(card, employee);
    refreshEmployeeDerivedViews(card, employee);

    form.reset();
    amountInput.focus();
  }

  function handleRemoveAdvance(card, employeeId, advanceId) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const confirmed = window.confirm('¿Eliminar este adelanto?');
    if (!confirmed) return;

    employee.advances = employee.advances.filter((a) => a.id !== advanceId);
    persist();
    renderAdvancesList(card, employee);
    refreshEmployeeDerivedViews(card, employee);
  }

  /* ---------------------------------------------------------
     21. ACCIONES: PAGOS AL EMPLEADO
  --------------------------------------------------------- */

  function handleQuickPay(card, employeeId) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const pending = getPendingPay(employee);
    const form = card.querySelector('.payment-form');
    const amountInput = form.querySelector('.payment-amount');
    const errorEl = card.querySelector('.payment-error');

    if (pending <= MONEY_EPSILON) {
      const net = getNetPay(employee);
      if (net <= MONEY_EPSILON) {
        window.alert(
          'Este empleado no tiene saldo a favor esta semana (el neto es 0 o negativo).'
        );
      } else {
        window.alert('Este empleado ya está pagado por completo esta semana.');
      }
      return;
    }

    hideFieldError(errorEl);
    markInvalid(amountInput, false);
    amountInput.value = pending;

    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(() => amountInput.focus(), 300);
  }

  function handleAddPayment(card, employeeId, form) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const amountInput = form.querySelector('.payment-amount');
    const methodSelect = form.querySelector('.payment-method');
    const noteInput = form.querySelector('.payment-note');
    const errorEl = card.querySelector('.payment-error');

    hideFieldError(errorEl);
    markInvalid(amountInput, false);

    const amount = clampNonNegativeNumber(amountInput.value);
    if (amount === null || amount === 0) {
      markInvalid(amountInput, true);
      showFieldError(errorEl, 'Ingresá un monto de pago válido, mayor a 0.');
      amountInput.focus();
      return;
    }

    const net = getNetPay(employee);
    const pending = getPendingPay(employee);

    if (net <= MONEY_EPSILON) {
      const proceed = window.confirm(
        `Este empleado no tiene saldo a favor esta semana (neto: ${formatCurrency(
          net
        )}). ¿Registrar el pago de todas formas?`
      );
      if (!proceed) return;
    } else if (pending > MONEY_EPSILON && amount > pending + MONEY_EPSILON) {
      const proceed = window.confirm(
        `El monto (${formatCurrency(amount)}) supera el saldo pendiente (${formatCurrency(
          pending
        )}). ¿Registrar de todas formas?`
      );
      if (!proceed) return;
    }

    const method = PAYMENT_METHODS[methodSelect.value] ? methodSelect.value : 'efectivo';

    employee.payments.push({
      id: uid(),
      amount,
      method,
      note: noteInput.value.trim(),
      date: new Date().toLocaleDateString('es-ES')
    });

    persist();
    renderPaymentsList(card, employee);
    refreshEmployeeDerivedViews(card, employee);

    form.reset();
    methodSelect.value = 'efectivo';
    amountInput.focus();
  }

  function handleRemovePayment(card, employeeId, paymentId) {
    const employee = findEmployee(employeeId);
    if (!employee) return;

    const confirmed = window.confirm('¿Eliminar este pago registrado?');
    if (!confirmed) return;

    employee.payments = employee.payments.filter((p) => p.id !== paymentId);
    persist();
    renderPaymentsList(card, employee);
    refreshEmployeeDerivedViews(card, employee);
  }

  /* ---------------------------------------------------------
     22. HELPER: refrescar vistas derivadas
  --------------------------------------------------------- */

  function refreshEmployeeDerivedViews(card, employee) {
    renderEmployeeStats(card, employee);
    renderPaymentBadge(card, employee);
    renderPaymentsList(card, employee);
    renderJobsList(card, employee);
    renderSummary();
    renderPendingList();
    renderProfitReport();

    if (filterPendingCheckbox.checked) {
      renderEmployeeList();
    }
  }

  /* ---------------------------------------------------------
     23. ACCIONES GLOBALES
  --------------------------------------------------------- */

  function archiveCurrentWeek() {
    const hasData = state.employees.some(
      (e) =>
        getTotalHours(e) > 0 ||
        e.advances.length > 0 ||
        e.payments.length > 0 ||
        (e.jobs && e.jobs.length > 0)
    );
    if (!hasData) return;

    const snapshot = {
      id: uid(),
      label: state.weekStartLabel || getCurrentWeekLabel(),
      archivedAt: new Date().toLocaleString('es-ES'),
      employees: state.employees.map((e) => ({
        id: e.id,
        name: e.name,
        payType: e.payType,
        hourlyRate: e.hourlyRate,
        overtimeThreshold: e.overtimeThreshold,
        overtimeRate: e.overtimeRate,
        hours: { ...e.hours },
        commissionRate: e.commissionRate,
        jobs: e.jobs.map((j) => ({ ...j })),
        advances: e.advances.map((a) => ({ ...a })),
        payments: e.payments.map((p) => ({ ...p }))
      }))
    };

    state.history.unshift(snapshot);
    if (state.history.length > MAX_HISTORY_ENTRIES) {
      state.history.length = MAX_HISTORY_ENTRIES;
    }
  }

  function handleResetWeek() {
    if (state.employees.length === 0) {
      window.alert('No hay empleados para reiniciar.');
      return;
    }
    const confirmed = window.confirm(
      'La semana actual se va a guardar en el historial y las horas, trabajos, adelantos y pagos de todos los ' +
        'empleados van a quedar en 0 (se mantienen empleados, tarifas, comisiones y configuración de horas extra). ¿Continuar?'
    );
    if (!confirmed) return;

    archiveCurrentWeek();

    state.employees.forEach((employee) => {
      DAYS.forEach((day) => {
        employee.hours[day] = 0;
      });
      employee.advances = [];
      employee.payments = [];
      employee.jobs = [];
    });
    state.weekStartLabel = getCurrentWeekLabel();

    persist();
    renderAll();
  }

  function handleClearAll() {
    const confirmed = window.confirm(
      '⚠ Esto eliminará TODOS los empleados, adelantos, pagos, trabajos e historial de semanas guardado de forma ' +
        'permanente. ¿Confirmás que querés borrar todo?'
    );
    if (!confirmed) return;

    state = createEmptyState();
    persist();
    renderAll();
  }

  function handleClearHistory() {
    if (state.history.length === 0) return;
    const confirmed = window.confirm(
      '¿Eliminar todas las semanas archivadas del historial? Esta acción no se puede deshacer.'
    );
    if (!confirmed) return;

    state.history = [];
    persist();
    renderHistory();
    renderProfitReport();
  }

  function handleRemoveHistoryEntry(historyId) {
    const entry = findHistoryEntry(historyId);
    if (!entry) return;
    const confirmed = window.confirm(
      `¿Eliminar "${entry.label}" del historial? Esta acción no se puede deshacer.`
    );
    if (!confirmed) return;

    state.history = state.history.filter((h) => h.id !== historyId);
    persist();
    renderHistory();
    renderProfitReport();
  }

  /* ---------------------------------------------------------
     24. HISTORIAL DE SEMANAS — RENDERIZADO
  --------------------------------------------------------- */

  function renderHistoryRow(tbody, employee, weekLabel) {
    const fragment = historyRowTemplate.content.cloneNode(true);
    const row = fragment.querySelector('.history-row');
    row.querySelector('.h-name').textContent = employee.name;
    row.querySelector('.h-row-hours').textContent = isPercentage(employee)
      ? employee.jobs.length + ' trabajos'
      : formatHours(getTotalHours(employee));
    row.querySelector('.h-row-gross').textContent = formatCurrency(getGrossPay(employee));
    row.querySelector('.h-row-advances').textContent = formatCurrency(getTotalAdvances(employee));
    row.querySelector('.h-row-net').textContent = formatCurrency(getNetPay(employee));
    row.querySelector('.h-row-paid').textContent = formatCurrency(getTotalPaid(employee));
    row.querySelector('.h-row-pending').textContent = formatCurrency(getPendingPay(employee));
    row.querySelector('.btn-history-receipt').addEventListener('click', () => {
      openReceiptWindow(employee, weekLabel);
    });
    tbody.appendChild(fragment);
  }

  function renderMethodBreakdown(container, employees) {
    const totals = getPaymentTotalsByMethod(employees);
    const parts = [];
    if (totals.efectivo > MONEY_EPSILON) {
      parts.push(`<span class="method-tag">Efectivo</span> ${formatCurrency(totals.efectivo)}`);
    }
    if (totals.transferencia > MONEY_EPSILON) {
      parts.push(
        `<span class="method-tag">Transf.</span> ${formatCurrency(totals.transferencia)}`
      );
    }
    if (totals.otro > MONEY_EPSILON) {
      parts.push(`<span class="method-tag">Otro</span> ${formatCurrency(totals.otro)}`);
    }
    if (parts.length === 0) {
      container.textContent = '';
      container.classList.add('hidden');
      return;
    }
    container.innerHTML = parts.join(' · ');
    container.classList.remove('hidden');
  }

  function renderHistoryItem(entry) {
    const fragment = historyItemTemplate.content.cloneNode(true);
    const item = fragment.querySelector('.history-item');
    item.dataset.historyId = entry.id;

    item.querySelector('.history-label').textContent = entry.label;
    item.querySelector('.history-archived-at').textContent = 'Guardada el ' + entry.archivedAt;
    renderMethodBreakdown(item.querySelector('.history-method-breakdown'), entry.employees);

    const totals = getGroupTotals(entry.employees);
    item.querySelector('.h-employees').textContent = entry.employees.length.toString();
    item.querySelector('.h-hours').textContent = formatHours(totals.hours);
    item.querySelector('.h-net').textContent = formatCurrency(totals.net);
    item.querySelector('.h-pending').textContent = formatCurrency(totals.pending);

    const detailEl = item.querySelector('.history-detail');
    const tbody = item.querySelector('.history-detail-body');
    const toggleBtn = item.querySelector('.btn-toggle-detail');

    entry.employees.forEach((employee) => renderHistoryRow(tbody, employee, entry.label));

    toggleBtn.setAttribute('aria-expanded', 'false');
    detailEl.setAttribute('aria-hidden', 'true');

    toggleBtn.addEventListener('click', () => {
      const isHidden = detailEl.classList.toggle('hidden');
      toggleBtn.textContent = isHidden ? 'Ver detalle' : 'Ocultar detalle';
      toggleBtn.setAttribute('aria-expanded', isHidden ? 'false' : 'true');
      detailEl.setAttribute('aria-hidden', isHidden ? 'true' : 'false');
    });

    item.querySelector('.btn-export-history').addEventListener('click', () => {
      exportWeekToCSV(entry.employees, entry.label);
    });

    item.querySelector('.btn-remove-history').addEventListener('click', () => {
      handleRemoveHistoryEntry(entry.id);
    });

    return item;
  }

  function renderHistory() {
    historyListEl.innerHTML = '';

    const activeFilter = historyMethodFilter ? historyMethodFilter.value : '';

    if (state.history.length === 0) {
      emptyHistoryStateEl.textContent =
        'Todavía no hay semanas archivadas. Van a aparecer acá cuando uses "Reiniciar semana".';
      emptyHistoryStateEl.classList.remove('hidden');
      clearHistoryBtn.classList.add('hidden');
      return;
    }

    clearHistoryBtn.classList.remove('hidden');

    const filtered = state.history.filter((entry) =>
      historyEntryHasPaymentMethod(entry, activeFilter)
    );

    if (filtered.length === 0) {
      emptyHistoryStateEl.textContent = `Ninguna semana del historial tiene pagos con método "${paymentMethodLabel(
        activeFilter
      )}".`;
      emptyHistoryStateEl.classList.remove('hidden');
      return;
    }

    emptyHistoryStateEl.classList.add('hidden');

    filtered.forEach((entry) => {
      historyListEl.appendChild(renderHistoryItem(entry));
    });
  }

  /* ---------------------------------------------------------
     25. EXPORTAR A CSV
  --------------------------------------------------------- */

  function csvEscape(value) {
    const str = value === null || value === undefined ? '' : String(value);
    if (/[;"\n]/.test(str)) {
      return '"' + str.replace(/"/g, '""') + '"';
    }
    return str;
  }

  function buildWeekCSV(employees, weekLabel) {
    const rows = [];
    rows.push(['Planilla de asistencia y nomina']);
    rows.push([weekLabel]);
    rows.push([]);
    rows.push([
      'Empleado',
      'Tipo',
      'Lunes',
      'Martes',
      'Miercoles',
      'Jueves',
      'Viernes',
      'Sabado',
      'Horas normales',
      'Horas extra',
      'Horas totales',
      'Tarifa normal (Gs/h)',
      'Tarifa extra (Gs/h)',
      'Comision por defecto (%)',
      'Cant. trabajos',
      'Valor trabajos (Gs)',
      'Salario bruto (Gs)',
      'Adelantos (Gs)',
      'Salario neto (Gs)',
      'Pagado (Gs)',
      'Pendiente (Gs)'
    ]);

    employees.forEach((employee) => {
      const pct = isPercentage(employee);
      rows.push([
        employee.name,
        pct ? 'Porcentaje' : 'Hora',
        pct ? '' : formatHours(employee.hours.lunes),
        pct ? '' : formatHours(employee.hours.martes),
        pct ? '' : formatHours(employee.hours.miercoles),
        pct ? '' : formatHours(employee.hours.jueves),
        pct ? '' : formatHours(employee.hours.viernes),
        pct ? '' : formatHours(employee.hours.sabado),
        pct ? '' : formatHours(getRegularHours(employee)),
        pct ? '' : formatHours(getOvertimeHours(employee)),
        pct ? '' : formatHours(getTotalHours(employee)),
        pct ? '' : Math.round(employee.hourlyRate),
        pct ? '' : Math.round(employee.overtimeRate),
        pct ? formatPercent(employee.commissionRate) : '',
        pct ? employee.jobs.length : '',
        pct ? Math.round(getTotalJobValue(employee)) : '',
        Math.round(getGrossPay(employee)),
        Math.round(getTotalAdvances(employee)),
        Math.round(getNetPay(employee)),
        Math.round(getTotalPaid(employee)),
        Math.round(getPendingPay(employee))
      ]);
    });

    const totals = getGroupTotals(employees);
    rows.push([]);
    rows.push([
      'TOTAL',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      formatHours(totals.regularHours),
      formatHours(totals.overtimeHours),
      formatHours(totals.hours),
      '',
      '',
      '',
      '',
      '',
      Math.round(totals.gross),
      Math.round(totals.advances),
      Math.round(totals.net),
      Math.round(totals.paid),
      Math.round(totals.pending)
    ]);

    const employeesWithJobs = employees.filter(
      (e) => isPercentage(e) && e.jobs && e.jobs.length > 0
    );
    if (employeesWithJobs.length > 0) {
      rows.push([]);
      rows.push(['Trabajos por porcentaje']);
      rows.push([
        'Empleado',
        'Descripcion',
        'Valor (Gs)',
        'Comision (%)',
        'Comision (Gs)',
        'Tipo de comision',
        'Fecha'
      ]);
      employeesWithJobs.forEach((emp) => {
        emp.jobs.forEach((job) => {
          const rate = getJobCommissionRate(emp, job);
          const commission = getJobCommission(emp, job);
          const tipo = isJobCustomRate(job) ? 'Propia' : 'Por defecto';
          rows.push([
            emp.name,
            job.description || '',
            Math.round(job.value),
            formatPercent(rate),
            Math.round(commission),
            tipo,
            job.date || ''
          ]);
        });
      });
    }

    const methodTotals = getPaymentTotalsByMethod(employees);
    const hasAnyMethod = Object.values(methodTotals).some((v) => v > MONEY_EPSILON);
    if (hasAnyMethod) {
      rows.push([]);
      rows.push(['Pagos por metodo']);
      if (methodTotals.efectivo > MONEY_EPSILON)
        rows.push(['Efectivo (Gs)', Math.round(methodTotals.efectivo)]);
      if (methodTotals.transferencia > MONEY_EPSILON)
        rows.push(['Transferencia (Gs)', Math.round(methodTotals.transferencia)]);
      if (methodTotals.otro > MONEY_EPSILON)
        rows.push(['Otro (Gs)', Math.round(methodTotals.otro)]);
    }

    return rows.map((row) => row.map(csvEscape).join(';')).join('\r\n');
  }

  /* ---------------------------------------------------------
     26. GUARDAR / COMPARTIR ARCHIVOS
  --------------------------------------------------------- */

  async function downloadTextFile(content, filename, mimeType) {
    if (isNative && window.Capacitor.Plugins.Filesystem) {
      try {
        const { Filesystem, Share } = window.Capacitor.Plugins;
        const base64 = btoa(unescape(encodeURIComponent('\uFEFF' + content)));

        const writeResult = await Filesystem.writeFile({
          path: filename,
          data: base64,
          directory: 'CACHE',
          encoding: 'base64'
        });

        if (Share) {
          await Share.share({
            title: filename,
            url: writeResult.uri,
            dialogTitle: 'Compartir archivo'
          });
        } else {
          window.alert('Archivo guardado en: ' + writeResult.uri);
        }
        return;
      } catch (err) {
        console.error('Error al guardar/compartir archivo:', err);
        window.alert('No se pudo guardar el archivo: ' + (err.message || err));
        return;
      }
    }

    try {
      const blob = new Blob(['\uFEFF' + content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('No se pudo generar el archivo de descarga:', err);
      window.alert(
        'No se pudo generar el archivo. Probá de nuevo o revisá los permisos de descarga del navegador.'
      );
    }
  }

  function exportWeekToCSV(employees, weekLabel) {
    if (!employees || employees.length === 0) {
      window.alert('No hay empleados para exportar en esta semana.');
      return;
    }
    const csv = buildWeekCSV(employees, weekLabel);
    const filename = 'planilla_' + slugify(weekLabel) + '.csv';
    downloadTextFile(csv, filename, 'text/csv;charset=utf-8;');
  }

  /* ---------------------------------------------------------
     26b. BACKUP Y RESTAURACIÓN
  --------------------------------------------------------- */

  async function handleExportBackup() {
    const backup = {
      app: BACKUP_APP_ID,
      version: BACKUP_VERSION,
      exportedAt: new Date().toISOString(),
      exportedAtLocal: new Date().toLocaleString('es-ES'),
      summary: {
        employees: state.employees.length,
        history: state.history.length
      },
      state: {
        employees: state.employees,
        history: state.history,
        weekStartLabel: state.weekStartLabel
      }
    };

    const json = JSON.stringify(backup, null, 2);
    const today = new Date().toISOString().slice(0, 10);
    const filename = 'planilla_backup_' + today + '.json';

    await downloadTextFile(json, filename, 'application/json;charset=utf-8;');

    saveLastBackupTime();
    renderLastBackupInfo();
  }

  function handleImportBackupClick() {
    if (importBackupInput) importBackupInput.value = '';
    if (importBackupInput) importBackupInput.click();
  }

  async function handleImportBackupFile(file) {
    if (!file) return;

    if (file.size > BACKUP_MAX_SIZE) {
      window.alert('El archivo es demasiado grande (máximo 10 MB).');
      return;
    }

    let text;
    try {
      text = await file.text();
    } catch (err) {
      console.error('No se pudo leer el archivo:', err);
      window.alert('No se pudo leer el archivo. Probá de nuevo.');
      return;
    }

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (err) {
      window.alert('El archivo no es un JSON válido.');
      return;
    }

    let incoming = null;
    if (parsed && typeof parsed === 'object') {
      if (parsed.state && Array.isArray(parsed.state.employees)) {
        incoming = parsed.state;
      } else if (Array.isArray(parsed.employees)) {
        incoming = parsed;
      }
    }

    if (!incoming) {
      window.alert(
        'El archivo no tiene el formato esperado.\n\n' +
          'Se esperaba un backup generado por esta app (debe contener la lista de empleados).'
      );
      return;
    }

    const employees = incoming.employees.map(normalizeEmployee);
    const history = Array.isArray(incoming.history)
      ? incoming.history.map((entry) => ({
          id: entry.id || uid(),
          label: entry.label || 'Semana archivada',
          archivedAt: entry.archivedAt || '',
          employees: Array.isArray(entry.employees)
            ? entry.employees.map(normalizeEmployee)
            : []
        }))
      : [];

    const resumen =
      'Contenido del archivo:\n\n' +
      '• ' + employees.length + ' empleado' + (employees.length === 1 ? '' : 's') + '\n' +
      '• ' + history.length + ' semana' + (history.length === 1 ? '' : 's') +
      ' archivada' + (history.length === 1 ? '' : 's') + '\n\n' +
      '⚠ Esto va a REEMPLAZAR todos los datos actuales.\n\n' +
      '¿Continuar?';

    if (!window.confirm(resumen)) return;

    const dobleCheck = window.confirm(
      '¿Estás seguro? Se van a borrar los datos actuales y no se puede deshacer.\n\n' +
        'Tip: si no exportaste un backup antes, cancelá y hacelo primero.'
    );
    if (!dobleCheck) return;

    state = {
      employees,
      history,
      weekStartLabel: incoming.weekStartLabel || getCurrentWeekLabel()
    };

    persist();
    renderAll();

    saveLastBackupTime();
    renderLastBackupInfo();

    window.alert(
      '✓ Backup restaurado correctamente.\n\n' +
        employees.length + ' empleado' + (employees.length === 1 ? '' : 's') +
        ' y ' + history.length + ' semana' + (history.length === 1 ? '' : 's') +
        ' cargados.'
    );
  }

  /* ---------------------------------------------------------
     26c. INDICADOR DE ÚLTIMO BACKUP
  --------------------------------------------------------- */

  function getLastBackupTime() {
    try {
      const v = window.localStorage.getItem(LAST_BACKUP_KEY);
      const n = Number(v);
      return Number.isFinite(n) && n > 0 ? n : null;
    } catch (err) {
      return null;
    }
  }

  function saveLastBackupTime() {
    try {
      window.localStorage.setItem(LAST_BACKUP_KEY, String(Date.now()));
    } catch (err) {
      /* sin persistencia */
    }
  }

  function formatRelativeTime(ms) {
    const diffMs = Date.now() - ms;
    const minutes = Math.floor(diffMs / 60000);
    if (minutes < 1) return 'recién';
    if (minutes < 60) return 'hace ' + minutes + ' min';
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return 'hace ' + hours + ' h';
    const days = Math.floor(hours / 24);
    if (days === 1) return 'ayer';
    if (days < 30) return 'hace ' + days + ' días';
    const months = Math.floor(days / 30);
    if (months === 1) return 'hace 1 mes';
    return 'hace ' + months + ' meses';
  }

  function renderLastBackupInfo() {
    if (!lastBackupInfoEl) return;

    const ts = getLastBackupTime();

    lastBackupInfoEl.classList.remove('is-recent', 'is-old', 'is-never');

    if (!ts) {
      lastBackupInfoEl.textContent = '⚠ Sin backup';
      lastBackupInfoEl.title = 'Nunca exportaste un backup. Hacé uno para proteger tus datos.';
      lastBackupInfoEl.classList.add('is-never');
      lastBackupInfoEl.classList.remove('hidden');
      return;
    }

    const diffDays = (Date.now() - ts) / 86400000;
    const relative = formatRelativeTime(ts);
    const fullDate = new Date(ts).toLocaleString('es-ES');

    lastBackupInfoEl.textContent = '💾 Backup ' + relative;
    lastBackupInfoEl.title = 'Último backup: ' + fullDate;

    if (diffDays <= 7) {
      lastBackupInfoEl.classList.add('is-recent');
    } else {
      lastBackupInfoEl.classList.add('is-old');
    }
    lastBackupInfoEl.classList.remove('hidden');
  }

  /* ---------------------------------------------------------
     27. RECIBO IMPRIMIBLE / PDF
  --------------------------------------------------------- */

  function buildReceiptHTML(employee, weekLabel) {
    const pct = isPercentage(employee);
    const regularHours = getRegularHours(employee);
    const overtimeHours = getOvertimeHours(employee);
    const gross = getGrossPay(employee);
    const advances = getTotalAdvances(employee);
    const net = getNetPay(employee);
    const paid = getTotalPaid(employee);
    const pending = getPendingPay(employee);
    const status = getPaymentStatus(employee);

    const dayRows = DAYS.map(
      (day) => `
      <tr>
        <td>${DAY_LABELS[day]}</td>
        <td class="num">${escapeHtml(formatHours(employee.hours[day]))} h</td>
      </tr>`
    ).join('');

    const jobRows = employee.jobs.length
      ? employee.jobs
          .map((j) => {
            const rate = getJobCommissionRate(employee, j);
            const commission = getJobCommission(employee, j);
            const badge = isJobCustomRate(j) ? '' : ' <span class="muted">(def.)</span>';
            return `
            <tr>
              <td>${escapeHtml(j.description || 'Sin descripción')}${
              j.date ? ' <span class="muted">· ' + escapeHtml(j.date) + '</span>' : ''
            }</td>
              <td class="num">${escapeHtml(formatCurrency(j.value))}</td>
              <td class="num">${escapeHtml(formatPercent(rate))}%${badge}</td>
              <td class="num">${escapeHtml(formatCurrency(commission))}</td>
            </tr>`;
          })
          .join('')
      : `<tr><td colspan="4" class="muted">Sin trabajos registrados.</td></tr>`;

    const advanceRows = employee.advances.length
      ? employee.advances
          .map(
            (a) => `
        <tr>
          <td>${escapeHtml(a.date)}${a.note ? ' — ' + escapeHtml(a.note) : ''}</td>
          <td class="num">-${escapeHtml(formatCurrency(a.amount))}</td>
        </tr>`
          )
          .join('')
      : `<tr><td colspan="2" class="muted">Sin adelantos registrados.</td></tr>`;

    const paymentRows = employee.payments.length
      ? employee.payments
          .map(
            (p) => `
        <tr>
          <td>${escapeHtml(p.date)} — ${escapeHtml(paymentMethodLabel(p.method))}${
              p.note ? ' · ' + escapeHtml(p.note) : ''
            }</td>
          <td class="num">${escapeHtml(formatCurrency(p.amount))}</td>
        </tr>`
          )
          .join('')
      : `<tr><td colspan="2" class="muted">Sin pagos registrados.</td></tr>`;

    let statusBanner = '';
    if (status === 'paid') {
      statusBanner = `<div class="banner banner-paid">✓ Pagado por completo</div>`;
    } else if (status === 'partial') {
      statusBanner = `<div class="banner banner-partial">Saldo pendiente: ${escapeHtml(
        formatCurrency(pending)
      )}</div>`;
    } else if (status === 'pending') {
      statusBanner = `<div class="banner banner-pending">Sin pagos registrados — pendiente ${escapeHtml(
        formatCurrency(pending)
      )}</div>`;
    }

    const workSection = pct
      ? `<h2>Trabajos realizados</h2>
         <table>
           <thead>
             <tr>
               <th>Descripción</th>
               <th class="num">Valor</th>
               <th class="num">Com. %</th>
               <th class="num">Comisión</th>
             </tr>
           </thead>
           <tbody>${jobRows}</tbody>
         </table>
         <p class="muted" style="margin-top:6px">Comisión por defecto del empleado: <strong>${escapeHtml(
           formatPercent(employee.commissionRate)
         )}%</strong>. Los trabajos con "(def.)" usan este valor.</p>`
      : `<h2>Horas trabajadas</h2>
         <table>${dayRows}</table>`;

    const summaryRows = pct
      ? `<tr><td>Total valor trabajos</td><td class="num">${escapeHtml(
          formatCurrency(getTotalJobValue(employee))
        )}</td></tr>
         <tr><td>Comisión por defecto</td><td class="num">${escapeHtml(
           formatPercent(employee.commissionRate)
         )} %</td></tr>`
      : `<tr><td>Horas normales (${escapeHtml(
          formatCurrency(employee.hourlyRate)
        )}/h)</td><td class="num">${escapeHtml(formatHours(regularHours))} h</td></tr>
         <tr><td>Horas extra (${escapeHtml(
           formatCurrency(employee.overtimeRate)
         )}/h)</td><td class="num">${escapeHtml(formatHours(overtimeHours))} h</td></tr>`;

    return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Recibo — ${escapeHtml(employee.name)}</title>
<style>
  * { box-sizing: border-box; }
  body {
    color-scheme: light;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
    color: #1C2430;
    max-width: 620px;
    margin: 32px auto;
    padding: 0 20px;
  }
  h1 { font-size: 19px; margin: 0 0 2px; }
  .subtitle { color: #5B6570; font-size: 13px; margin-bottom: 20px; }
  h2 { font-size: 13px; text-transform: none; margin: 22px 0 8px; color: #1C2430; border-bottom: 1px solid #DAE0DA; padding-bottom: 4px; }
  table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
  th { text-align: left; font-size: 11px; color: #5B6570; font-weight: 600; padding: 4px; border-bottom: 1px solid #DAE0DA; }
  th.num { text-align: right; }
  td { padding: 5px 4px; border-bottom: 1px solid #EEF1EE; }
  td.num { text-align: right; font-variant-numeric: tabular-nums; }
  td.muted { color: #5B6570; }
  .muted { color: #5B6570; font-size: 12px; }
  .totals td { font-size: 14px; padding: 7px 4px; }
  .totals tr:last-child td { font-weight: 700; font-size: 15.5px; border-top: 2px solid #1C2430; border-bottom: none; }
  .neg td.num { color: #B23A2E; }
  .meta { display: flex; justify-content: space-between; font-size: 12.5px; color: #5B6570; margin-top: 4px; }
  .banner { margin: 14px 0 4px; padding: 8px 12px; border-radius: 6px; font-size: 13px; font-weight: 600; }
  .banner-paid { background: #E3EFE7; color: #234F39; }
  .banner-partial { background: #FCE8C9; color: #8A5A1F; }
  .banner-pending { background: #F7EFD9; color: #8A6A1F; }
  .signatures { display: flex; justify-content: space-between; margin-top: 56px; gap: 40px; }
  .signature { flex: 1; text-align: center; }
  .signature .line { border-top: 1px solid #1C2430; margin-bottom: 6px; }
  .signature span { font-size: 12px; color: #5B6570; }
  .no-print { margin-top: 28px; text-align: center; }
  .no-print button {
    font-family: inherit; font-size: 13.5px; padding: 8px 16px; margin: 0 4px;
    border-radius: 6px; border: 1px solid #C3CBC3; background: #F5F7F4; cursor: pointer;
  }
  @media print { .no-print { display: none; } body { margin: 0; } }
</style>
</head>
<body>
  <h1>Recibo de pago</h1>
  <p class="subtitle">${escapeHtml(weekLabel)}</p>

  <div class="meta">
    <span><strong>Empleado:</strong> ${escapeHtml(employee.name)}</span>
    <span>Tipo: <strong>${escapeHtml(payTypeLabel(employee.payType))}</strong></span>
  </div>

  ${statusBanner}

  ${workSection}

  <h2>Adelantos</h2>
  <table>${advanceRows}</table>

  <h2>Pagos realizados</h2>
  <table>${paymentRows}</table>

  <h2>Resumen</h2>
  <table class="totals">
    ${summaryRows}
    <tr><td>Salario bruto</td><td class="num">${escapeHtml(formatCurrency(gross))}</td></tr>
    <tr><td>Adelantos descontados</td><td class="num">-${escapeHtml(formatCurrency(advances))}</td></tr>
    <tr><td>Neto a pagar</td><td class="num">${escapeHtml(formatCurrency(net))}</td></tr>
    <tr><td>Total pagado</td><td class="num">${escapeHtml(formatCurrency(paid))}</td></tr>
    <tr class="${pending > 0 ? 'neg' : ''}"><td>Saldo pendiente</td><td class="num">${escapeHtml(
      formatCurrency(pending)
    )}</td></tr>
  </table>

  <div class="signatures">
    <div class="signature"><div class="line"></div><span>Firma empleador</span></div>
    <div class="signature"><div class="line"></div><span>Firma empleado</span></div>
  </div>

  <div class="no-print">
    <button onclick="window.print()">Imprimir / Guardar PDF</button>
    <button onclick="window.close()">Cerrar</button>
  </div>

  <script>
    window.addEventListener('load', function () {
      setTimeout(function () { window.print(); }, 150);
    });
  <\/script>
</body>
</html>`;
  }

  async function openReceiptWindow(employee, weekLabel) {
    const html = buildReceiptHTML(employee, weekLabel);

    if (isNative && window.Capacitor.Plugins.Filesystem && window.Capacitor.Plugins.Share) {
      try {
        const { Filesystem, Share } = window.Capacitor.Plugins;
        const filename = 'recibo_' + slugify(employee.name) + '.html';
        const base64 = btoa(unescape(encodeURIComponent(html)));
        const result = await Filesystem.writeFile({
          path: filename,
          data: base64,
          directory: 'CACHE',
          encoding: 'base64'
        });
        await Share.share({
          title: 'Recibo de ' + employee.name,
          url: result.uri,
          dialogTitle: 'Compartir recibo'
        });
        return;
      } catch (err) {
        console.error('Error al compartir recibo:', err);
      }
    }

    const receiptWindow = window.open('', '_blank', 'width=680,height=860');
    if (!receiptWindow) {
      window.alert(
        'El navegador bloqueó la ventana del recibo. Habilitá las ventanas emergentes para este sitio e intentá de nuevo.'
      );
      return;
    }
    receiptWindow.document.open();
    receiptWindow.document.write(html);
    receiptWindow.document.close();
    receiptWindow.focus();
  }

  /* ---------------------------------------------------------
     28. DELEGACIÓN DE EVENTOS DENTRO DE UNA TARJETA
  --------------------------------------------------------- */

  function attachCardEvents(card) {
    const employeeId = card.dataset.employeeId;

    card.querySelector('.pay-type-select').addEventListener('change', (evt) => {
      handlePayTypeChange(card, employeeId, evt.target);
    });

    card.querySelectorAll('.hours-input').forEach((input) => {
      input.addEventListener('change', () => handleHoursChange(card, employeeId, input));
    });

    card.querySelector('.overtime-threshold-input').addEventListener('change', (evt) => {
      handleOvertimeThresholdChange(card, employeeId, evt.target);
    });
    card.querySelector('.overtime-rate-input').addEventListener('change', (evt) => {
      handleOvertimeRateChange(card, employeeId, evt.target);
    });

    card.querySelector('.btn-receipt').addEventListener('click', () => {
      const employee = findEmployee(employeeId);
      if (employee) openReceiptWindow(employee, state.weekStartLabel);
    });

    card.querySelector('.btn-remove').addEventListener('click', () => {
      handleRemoveEmployee(employeeId);
    });

    card.querySelector('.btn-edit-rate').addEventListener('click', () => {
      handleEditRate(employeeId);
    });

    card.querySelector('.btn-pay').addEventListener('click', () => {
      handleQuickPay(card, employeeId);
    });

    const jobForm = card.querySelector('.job-form');
    jobForm.addEventListener('submit', (evt) => {
      evt.preventDefault();
      handleAddJob(card, employeeId, jobForm);
    });

    card.querySelector('.jobs-list').addEventListener('click', (evt) => {
      const removeBtn = evt.target.closest('.btn-remove-job');
      if (removeBtn) {
        const jobLi = removeBtn.closest('.job-item');
        handleRemoveJob(card, employeeId, jobLi.dataset.jobId);
        return;
      }
      const editBtn = evt.target.closest('.btn-edit-job');
      if (editBtn) {
        const jobLi = editBtn.closest('.job-item');
        handleEditJobRate(card, employeeId, jobLi.dataset.jobId);
      }
    });

    const advanceForm = card.querySelector('.advance-form');
    advanceForm.addEventListener('submit', (evt) => {
      evt.preventDefault();
      handleAddAdvance(card, employeeId, advanceForm);
    });

    card.querySelector('.advances-list').addEventListener('click', (evt) => {
      const btn = evt.target.closest('.btn-remove-advance');
      if (!btn) return;
      const advanceLi = btn.closest('.advance-item');
      handleRemoveAdvance(card, employeeId, advanceLi.dataset.advanceId);
    });

    const paymentForm = card.querySelector('.payment-form');
    paymentForm.addEventListener('submit', (evt) => {
      evt.preventDefault();
      handleAddPayment(card, employeeId, paymentForm);
    });

    card.querySelector('.payments-list').addEventListener('click', (evt) => {
      const btn = evt.target.closest('.btn-remove-payment');
      if (!btn) return;
      const paymentLi = btn.closest('.payment-item');
      handleRemovePayment(card, employeeId, paymentLi.dataset.paymentId);
    });
  }

  /* ---------------------------------------------------------
     29. PWA: Service Worker + Instalación
  --------------------------------------------------------- */

  let deferredInstallPrompt = null;

  function setupPwa() {
    if (!isNative && 'serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          .register('sw.js')
          .then((reg) => {
            console.info('[PWA] Service Worker registrado:', reg.scope);
            setInterval(() => reg.update(), 60 * 60 * 1000);
          })
          .catch((err) => {
            console.warn('[PWA] No se pudo registrar el Service Worker:', err);
          });
      });
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredInstallPrompt = e;
      if (installAppBtn) installAppBtn.classList.remove('hidden');
    });

    if (installAppBtn) {
      installAppBtn.addEventListener('click', async () => {
        if (!deferredInstallPrompt) {
          window.alert(
            'Para instalar la app:\n\n' +
              '1. Tocá el menú ⋮ del navegador\n' +
              '2. Elegí "Instalar aplicación" o "Agregar a pantalla de inicio"\n\n' +
              'Si no aparece la opción, verificá que estés accediendo por HTTPS.'
          );
          return;
        }
        deferredInstallPrompt.prompt();
        const choice = await deferredInstallPrompt.userChoice;
        console.info('[PWA] Resultado de la instalación:', choice.outcome);
        deferredInstallPrompt = null;
        installAppBtn.classList.add('hidden');
      });
    }

    window.addEventListener('appinstalled', () => {
      if (installAppBtn) installAppBtn.classList.add('hidden');
      deferredInstallPrompt = null;
      console.info('[PWA] App instalada correctamente.');
    });
  }

  /* ---------------------------------------------------------
     30. INICIALIZACIÓN
  --------------------------------------------------------- */

  async function init() {
    storageAvailable = await checkStorageAvailability();
    if (!storageAvailable) {
      showStorageWarning();
    }

    state = await loadData();

    applyTheme(document.documentElement.getAttribute('data-theme') || THEME_LIGHT);
    if (themeToggleBtn) themeToggleBtn.addEventListener('click', handleThemeToggle);
    watchSystemTheme();

    applyDensity(document.documentElement.getAttribute('data-density') || DENSITY_COMFORTABLE);
    if (densityToggleBtn) densityToggleBtn.addEventListener('click', handleDensityToggle);

    empPayTypeSelect.addEventListener('change', syncAddFormFields);
    syncAddFormFields();
    addEmployeeForm.addEventListener('submit', handleAddEmployee);

    resetWeekBtn.addEventListener('click', handleResetWeek);
    clearAllBtn.addEventListener('click', handleClearAll);
    clearHistoryBtn.addEventListener('click', handleClearHistory);
    exportCsvBtn.addEventListener('click', () =>
      exportWeekToCSV(state.employees, state.weekStartLabel)
    );

    if (exportBackupBtn) exportBackupBtn.addEventListener('click', handleExportBackup);
    if (importBackupBtn) importBackupBtn.addEventListener('click', handleImportBackupClick);
    if (importBackupInput) {
      importBackupInput.addEventListener('change', (evt) => {
        const file = evt.target.files && evt.target.files[0];
        handleImportBackupFile(file);
      });
    }

    renderLastBackupInfo();
    setInterval(renderLastBackupInfo, 60000);

    employeeSearchInput.addEventListener('input', renderEmployeeList);
    filterPendingCheckbox.addEventListener('change', renderEmployeeList);
    payAllPendingBtn.addEventListener('click', handlePayAllPending);
    historyMethodFilter.addEventListener('change', renderHistory);

    profitPeriodSelect.addEventListener('change', renderProfitReport);
    profitTopSelect.addEventListener('change', renderProfitReport);

    // Listener único para "Pagar" en la lista de pendientes (no va dentro de render)
    pendingListEl.addEventListener('click', (evt) => {
      const btn = evt.target.closest('.btn-pending-pay');
      if (!btn) return;
      const li = btn.closest('.pending-item');
      if (li) handlePendingPayClick(li.dataset.employeeId);
    });

    setupPwa();

    renderAll();
  }

  document.addEventListener('DOMContentLoaded', init);
})();