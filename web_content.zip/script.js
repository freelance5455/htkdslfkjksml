const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

const menu = document.getElementById("menu");
const levelsScreen = document.getElementById("levels");
const game = document.getElementById("game");
const grid = document.getElementById("levelGrid");
const hud = document.getElementById("hud");
const pauseBox = document.getElementById("pauseBox");

const playBtn = document.getElementById("playBtn");
const resetBtn = document.getElementById("resetBtn");
const backBtn = document.getElementById("backBtn");
const resumeBtn = document.getElementById("resumeBtn");
const levelBtn = document.getElementById("levelBtn");

let W = 960;
let H = 540;

const worlds = [
  { name: "FLORESTA", icon: "🌳" },
  { name: "DESERTO", icon: "🏜️" },
  { name: "GELO", icon: "❄️" },
  { name: "VULCÃO", icon: "🌋" },
  { name: "OCEANO", icon: "🌊" },
  { name: "CASTELO", icon: "🏰" },
  { name: "NOITE", icon: "🌙" },
  { name: "FÁBRICA", icon: "⚙️" },
  { name: "ESPAÇO", icon: "🚀" },
  { name: "FINAL", icon: "💀" }
];

const TOTAL_LEVELS = 100;

let unlocked = Number(localStorage.getItem("67_unlocked") || 1);
let completed = JSON.parse(
  localStorage.getItem("67_completed") || "[]"
);

let currentLevel = 1;
let level = null;

let keys = {
  left: false,
  right: false,
  jump: false
};

let jumpPressed = false;
let paused = false;
let gameRunning = false;

let lastTime = 0;
let cameraX = 0;

let player = null;

function resize() {
  W = window.innerWidth;
  H = window.innerHeight;

  canvas.width = Math.max(320, Math.floor(W));
  canvas.height = Math.max(240, Math.floor(H));

  ctx.imageSmoothingEnabled = false;
}

window.addEventListener("resize", resize);
resize();

function saveProgress() {
  localStorage.setItem("67_unlocked", unlocked);
  localStorage.setItem(
    "67_completed",
    JSON.stringify(completed)
  );
}

function rand(seed) {
  let x = Math.sin(seed * 9999.91) * 43758.5453;
  return x - Math.floor(x);
}

function randomRange(min, max) {
  return min + Math.random() * (max - min);
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function rectsOverlap(a, b) {
  return (
    a.x < b.x + b.w &&
    a.x + a.w > b.x &&
    a.y < b.y + b.h &&
    a.y + a.h > b.y
  );
}

function makeLevel(number) {
  const difficulty = Math.min(10, Math.ceil(number / 10));
  const world = Math.floor((number - 1) / 10);

  const groundY = H - 105;

  const data = {
    number,
    difficulty,
    world,

    width: 0,

    platforms: [],
    spikes: [],
    coins: [],
    enemies: [],
    movingPlatforms: [],
    buttons: [],
    doors: [],
    finish: null
  };

  /*
   * PLATAFORMA INICIAL
   * Sempre grande para o jogador nunca nascer em uma situação impossível.
   */
  data.platforms.push({
    x: 0,
    y: groundY,
    w: 620,
    h: 105
  });

  let x = 560;
  let previousY = groundY;

  /*
   * GERAÇÃO DAS PLATAFORMAS
   */
  const amount = 7 + difficulty * 2;

  for (let i = 0; i < amount; i++) {
    const maxGap = 95 + difficulty * 12;

    let gap = randomRange(
      55,
      maxGap
    );

    let width = randomRange(
      Math.max(110, 170 - difficulty * 4),
      Math.max(145, 230 - difficulty * 3)
    );

    let verticalChange = randomRange(
      -45 - difficulty * 4,
      45 + difficulty * 3
    );

    let y = previousY + verticalChange;

    y = clamp(
      y,
      groundY - 220,
      groundY - 20
    );

    x += gap;

    data.platforms.push({
      x,
      y,
      w: width,
      h: 30
    });

    previousY = y;
    x += width;
  }

  /*
   * PLATAFORMA FINAL
   */
  x += 80;

  data.platforms.push({
    x,
    y: groundY - 20,
    w: 420,
    h: 125
  });

  data.width = x + 500;

  /*
   * MOEDAS
   */
  for (let i = 1; i < data.platforms.length - 1; i++) {
    const p = data.platforms[i];

    if (Math.random() < 0.82) {
      data.coins.push({
        x: p.x + p.w / 2 - 10,
        y: p.y - 38,
        w: 20,
        h: 20,
        taken: false
      });
    }

    if (
      difficulty >= 2 &&
      Math.random() < 0.35
    ) {
      data.coins.push({
        x: p.x + p.w * 0.25,
        y: p.y - 70,
        w: 20,
        h: 20,
        taken: false
      });
    }
  }

  /*
   * INIMIGOS
   */
  if (difficulty >= 2) {
    const enemyCount =
      Math.floor(difficulty / 2) + 1;

    for (let i = 0; i < enemyCount; i++) {
      const index =
        1 +
        Math.floor(
          Math.random() *
          Math.max(1, data.platforms.length - 2)
        );

      const p = data.platforms[index];

      data.enemies.push({
        x: p.x + 20,
        y: p.y - 32,
        w: 30,
        h: 30,
        vx: Math.random() < 0.5 ? -1 : 1,
        speed: 0.7 + difficulty * 0.12,
        left: p.x,
        right: p.x + p.w - 30,
        dead: false
      });
    }
  }

  /*
   * ESPINHOS
   */
  if (difficulty >= 4) {
    const spikeCount =
      Math.floor(difficulty * 1.5);

    for (let i = 0; i < spikeCount; i++) {
      const index =
        1 +
        Math.floor(
          Math.random() *
          Math.max(1, data.platforms.length - 2)
        );

      const p = data.platforms[index];

      if (p.w > 150) {
        data.spikes.push({
          x:
            p.x +
            randomRange(30, Math.max(31, p.w - 55)),
          y: p.y - 22,
          w: 24,
          h: 22
        });
      }
    }
  }

  /*
   * PLATAFORMAS MÓVEIS
   */
  if (difficulty >= 3) {
    const movingCount =
      Math.floor(difficulty / 2);

    for (let i = 0; i < movingCount; i++) {
      const index =
        1 +
        Math.floor(
          Math.random() *
          Math.max(1, data.platforms.length - 2)
        );

      const p = data.platforms[index];

      data.movingPlatforms.push({
        x: p.x,
        y: p.y - 80,
        w: 130,
        h: 25,

        startX: p.x,
        startY: p.y - 80,

        rangeX: 80 + difficulty * 10,
        rangeY: difficulty >= 6 ? 70 : 0,

        speed:
          0.008 +
          difficulty * 0.0015,

        t: Math.random() * 100
      });
    }
  }

  /*
   * BOTÕES E PORTAS
   * A partir da fase 51.
   */
  if (number >= 51) {
    const buttonIndex =
      2 +
      Math.floor(
        Math.random() *
        Math.max(1, data.platforms.length - 3)
      );

    const bp = data.platforms[
      buttonIndex
    ];

    data.buttons.push({
      x: bp.x + bp.w / 2 - 14,
      y: bp.y - 18,
      w: 28,
      h: 18,
      pressed: false
    });

    const doorX =
      data.width - 350;

    data.doors.push({
      x: doorX,
      y: groundY - 120,
      w: 45,
      h: 120,
      open: false
    });
  }

  /*
   * BANDEIRA FINAL
   */
  data.finish = {
    x: data.width - 250,
    y: groundY - 150,
    w: 45,
    h: 150
  };

  /*
   * AJUSTE PARA FASES MAIS DIFÍCEIS
   */
  if (difficulty >= 7) {
    for (let i = 0; i < data.platforms.length; i++) {
      const p = data.platforms[i];

      if (
        i > 0 &&
        i < data.platforms.length - 1 &&
        Math.random() < 0.35
      ) {
        p.w = Math.max(105, p.w - 25);
      }
    }
  }

  return data;
}

function startLevel(number) {
  currentLevel = number;

  level = makeLevel(number);

  player = {
    x: 80,
    y: H - 180,

    w: 34,
    h: 42,

    vx: 0,
    vy: 0,

    speed: 4.4,
    jump: -11.5,

    onGround: false,

    lives: 3,
    coins: 0,

    spawnX: 80,
    spawnY: H - 180,

    invincible: 0
  };

  cameraX = 0;
  paused = false;
  gameRunning = true;

  menu.classList.add("hidden");
  levelsScreen.classList.add("hidden");
  game.classList.remove("hidden");
  pauseBox.classList.add("hidden");

  updateHUD();
}

function updateHUD() {
  if (!player || !level) return;

  const world = worlds[level.world];

  hud.innerHTML =
    `${world.icon} ${world.name} ` +
    `| FASE ${currentLevel}/100 ` +
    `| ❤️ ${player.lives} ` +
    `| 🪙 ${player.coins}`;
}

function showLevels() {
  gameRunning = false;
  paused = false;

  game.classList.add("hidden");
  menu.classList.add("hidden");
  pauseBox.classList.add("hidden");
  levelsScreen.classList.remove("hidden");

  grid.innerHTML = "";

  for (let w = 0; w < worlds.length; w++) {
    const label = document.createElement("div");

    label.className = "worldLabel";
    label.textContent =
      `${worlds[w].icon} MUNDO ${w + 1} • ${worlds[w].name}`;

    grid.appendChild(label);

    for (let i = 1; i <= 10; i++) {
      const number =
        w * 10 + i;

      const button =
        document.createElement("button");

      button.className = "level";
      button.textContent = number;

      if (completed.includes(number)) {
        button.classList.add("done");
      }

      if (number <= unlocked) {
        button.classList.add("unlocked");

        button.addEventListener(
          "click",
          () => startLevel(number)
        );
      } else {
        button.classList.add("locked");
        button.textContent = "🔒";
      }

      grid.appendChild(button);
    }
  }
}

function loseLife() {
  if (!player || !level) return;

  if (player.invincible > 0) return;

  player.lives--;

  if (player.lives <= 0) {
    showGameOver();
    return;
  }

  player.x = player.spawnX;
  player.y = player.spawnY;

  player.vx = 0;
  player.vy = 0;

  player.invincible = 120;

  cameraX = 0;
}

function completeLevel() {
  if (!gameRunning) return;

  if (!completed.includes(currentLevel)) {
    completed.push(currentLevel);
  }

  if (
    currentLevel < TOTAL_LEVELS &&
    unlocked < currentLevel + 1
  ) {
    unlocked = currentLevel + 1;
  }

  saveProgress();

  if (currentLevel >= TOTAL_LEVELS) {
    showWin();
    return;
  }

  const next =
    currentLevel + 1;

  startLevel(next);
}

function showWin() {
  gameRunning = false;

  setTimeout(() => {
    alert(
      "🏆 VOCÊ ZEROU O 67 ADVENTURE!\n\n" +
      "100 fases concluídas."
    );

    showLevels();
  }, 50);
}

function showGameOver() {
  gameRunning = false;

  setTimeout(() => {
    const retry =
      confirm(
        `💀 GAME OVER!\n\n` +
        `Você chegou à fase ${currentLevel}.\n\n` +
        `Tentar novamente?`
      );

    if (retry) {
      startLevel(currentLevel);
    } else {
      showLevels();
    }
  }, 50);
}

function collide(entity, platform) {
  return (
    entity.x < platform.x + platform.w &&
    entity.x + entity.w > platform.x &&
    entity.y < platform.y + platform.h &&
    entity.y + entity.h > platform.y
  );
}

function updateMovingPlatforms(dt) {
  if (!level) return;

  for (const p of level.movingPlatforms) {
    p.t += p.speed * dt;

    p.x =
      p.startX +
      Math.sin(p.t) * p.rangeX;

    if (p.rangeY > 0) {
      p.y =
        p.startY +
        Math.sin(p.t * 0.7) * p.rangeY;
    }
  }
}

function updatePlayer(dt) {
  if (!player || !level) return;

  /*
   * MOVIMENTO HORIZONTAL
   */
  if (keys.left && !keys.right) {
    player.vx = -player.speed;
  } else if (
    keys.right &&
    !keys.left
  ) {
    player.vx = player.speed;
  } else {
    player.vx *= 0.78;
  }

  /*
   * PULO
   */
  if (
    keys.jump &&
    !jumpPressed &&
    player.onGround
  ) {
    player.vy = player.jump;
    player.onGround = false;
    jumpPressed = true;
  }

  if (!keys.jump) {
    jumpPressed = false;
  }

  /*
   * GRAVIDADE
   */
  player.vy += 0.55 * dt;

  if (player.vy > 15) {
    player.vy = 15;
  }

  /*
   * MOVIMENTO X
   */
  player.x += player.vx * dt;

  if (player.x < 0) {
    player.x = 0;
  }

  /*
   * MOVIMENTO Y
   */
  const oldY = player.y;

  player.y += player.vy * dt;

  player.onGround = false;

  /*
   * PLATAFORMAS FIXAS
   */
  for (const p of level.platforms) {
    if (!collide(player, p)) continue;

    const oldBottom =
      oldY + player.h;

    const newBottom =
      player.y + player.h;

    if (
      player.vy >= 0 &&
      oldBottom <= p.y + 8 &&
      newBottom >= p.y
    ) {
      player.y = p.y - player.h;
      player.vy = 0;
      player.onGround = true;
    } else if (
      player.vy < 0 &&
      oldY >= p.y + p.h - 8 &&
      player.y <= p.y + p.h
    ) {
      player.y =
        p.y + p.h;

      player.vy = 0;
    }
  }

  /*
   * PLATAFORMAS MÓVEIS
   */
  for (const p of level.movingPlatforms) {
    if (!collide(player, p)) continue;

    const oldBottom =
      oldY + player.h;

    const newBottom =
      player.y + player.h;

    if (
      player.vy >= 0 &&
      oldBottom <= p.y + 10 &&
      newBottom >= p.y
    ) {
      player.y = p.y - player.h;
      player.vy = 0;
      player.onGround = true;

      player.x +=
        Math.cos(p.t) *
        p.rangeX *
        p.speed *
        dt;
    }
  }

  /*
   * CAIU
   */
  if (
    player.y >
    H + 250
  ) {
    loseLife();
  }

  /*
   * ESPINHOS
   */
  for (const spike of level.spikes) {
    if (
      rectsOverlap(
        player,
        spike
      )
    ) {
      loseLife();
      break;
    }
  }

  /*
   * INIMIGOS
   */
  for (const enemy of level.enemies) {
    if (enemy.dead) continue;

    enemy.x +=
      enemy.vx *
      enemy.speed *
      dt;

    if (
      enemy.x <= enemy.left ||
      enemy.x >= enemy.right
    ) {
      enemy.vx *= -1;
    }

    if (
      rectsOverlap(
        player,
        enemy
      )
    ) {
      const playerBottom =
        player.y + player.h;

      if (
        player.vy > 0 &&
        playerBottom <
          enemy.y + 18
      ) {
        enemy.dead = true;
        player.vy = -8;
      } else {
        loseLife();
      }
    }
  }

  /*
   * MOEDAS
   */
  for (const coin of level.coins) {
    if (coin.taken) continue;

    if (
      rectsOverlap(
        player,
        coin
      )
    ) {
      coin.taken = true;
      player.coins++;
    }
  }

  /*
   * BOTÕES
   */
  for (const button of level.buttons) {
    if (
      rectsOverlap(
        player,
        button
      )
    ) {
      button.pressed = true;

      for (const door of level.doors) {
        door.open = true;
      }
    }
  }

  /*
   * PORTAS
   */
  for (const door of level.doors) {
    if (!door.open) {
      if (
        rectsOverlap(
          player,
          door
        )
      ) {
        player.x =
          door.x - player.w - 1;
        player.vx = 0;
      }
    }
  }

  /*
   * BANDEIRA
   */
  if (
    level.finish &&
    rectsOverlap(
      player,
      level.finish
    )
  ) {
    completeLevel();
  }

  /*
   * INVENCIBILIDADE
   */
  if (player.invincible > 0) {
    player.invincible -= dt;
  }

  /*
   * CÂMERA
   */
  const targetCamera =
    player.x - W * 0.35;

  cameraX +=
    (targetCamera - cameraX) *
    0.12;

  cameraX = clamp(
    cameraX,
    0,
    Math.max(
      0,
      level.width - W
    )
  );

  updateHUD();
}
// ================================
// PARTE 2/2
// ================================

function drawBackground() {
  const world = level
    ? level.world
    : 0;

  const skyColors = [
    "#74c9ff",
    "#e7b85c",
    "#bfe9ff",
    "#ff704d",
    "#4bb9d6",
    "#6d78a8",
    "#171b45",
    "#59636b",
    "#10152e",
    "#090909"
  ];

  ctx.fillStyle =
    skyColors[world] || "#74c9ff";

  ctx.fillRect(
    0,
    0,
    W,
    H
  );

  /*
   * SOL / LUA
   */
  if (world === 6) {
    ctx.fillStyle = "#fff4a8";
    ctx.beginPath();
    ctx.arc(
      W - 100,
      90,
      38,
      0,
      Math.PI * 2
    );
    ctx.fill();
  } else if (world !== 9) {
    ctx.fillStyle = "#fff1a8";
    ctx.beginPath();
    ctx.arc(
      W - 100,
      85,
      42,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }

  /*
   * ESTRELAS
   */
  if (
    world === 6 ||
    world === 8 ||
    world === 9
  ) {
    ctx.fillStyle = "#fff";

    for (let i = 0; i < 55; i++) {
      const sx =
        (i * 137) % W;

      const sy =
        (i * 73) % Math.max(100, H - 160);

      const size =
        i % 3 === 0
          ? 3
          : 2;

      ctx.fillRect(
        sx,
        sy,
        size,
        size
      );
    }
  }

  /*
   * MONTANHAS / FUNDO
   */
  ctx.fillStyle =
    world === 1
      ? "#d59b45"
      : world === 2
      ? "#b9e7ff"
      : world === 3
      ? "#d94a32"
      : world === 5
      ? "#4b5278"
      : world === 7
      ? "#424b52"
      : "#5597ad";

  ctx.beginPath();

  ctx.moveTo(
    0,
    H - 105
  );

  for (
    let x = 0;
    x <= W;
    x += 120
  ) {
    const height =
      60 +
      ((x / 120) % 3) * 30;

    ctx.lineTo(
      x,
      H - 105 - height
    );
  }

  ctx.lineTo(
    W,
    H
  );

  ctx.lineTo(
    0,
    H
  );

  ctx.closePath();
  ctx.fill();
}

function drawPlatforms() {
  if (!level) return;

  /*
   * PLATAFORMAS FIXAS
   */
  for (const p of level.platforms) {
    const x =
      Math.floor(p.x - cameraX);

    const y =
      Math.floor(p.y);

    if (
      x + p.w < 0 ||
      x > W
    ) {
      continue;
    }

    let top = "#49a942";
    let body = "#75462b";

    if (level.world === 1) {
      top = "#d7a447";
      body = "#a96f2f";
    }

    if (level.world === 2) {
      top = "#ffffff";
      body = "#9ed4ef";
    }

    if (level.world === 3) {
      top = "#ff9b38";
      body = "#74342a";
    }

    if (level.world === 4) {
      top = "#2b9fc1";
      body = "#236478";
    }

    if (level.world === 5) {
      top = "#8174b5";
      body = "#45486e";
    }

    if (level.world === 6) {
      top = "#696969";
      body = "#343434";
    }

    if (level.world === 7) {
      top = "#77858b";
      body = "#394247";
    }

    if (level.world === 8) {
      top = "#aaa";
      body = "#555";
    }

    if (level.world === 9) {
      top = "#7d7d7d";
      body = "#292929";
    }

    ctx.fillStyle = top;

    ctx.fillRect(
      x,
      y,
      p.w,
      12
    );

    ctx.fillStyle = body;

    ctx.fillRect(
      x,
      y + 12,
      p.w,
      Math.max(
        0,
        p.h - 12
      )
    );

    ctx.fillStyle = "#0003";

    for (
      let bx = x + 8;
      bx < x + p.w;
      bx += 32
    ) {
      ctx.fillRect(
        bx,
        y + 18,
        10,
        6
      );
    }
  }

  /*
   * PLATAFORMAS MÓVEIS
   */
  for (const p of level.movingPlatforms) {
    const x =
      Math.floor(p.x - cameraX);

    const y =
      Math.floor(p.y);

    ctx.fillStyle = "#e8e8e8";

    ctx.fillRect(
      x,
      y,
      p.w,
      p.h
    );

    ctx.fillStyle = "#555";

    ctx.fillRect(
      x,
      y,
      p.w,
      6
    );

    ctx.fillStyle = "#222";

    ctx.fillRect(
      x + 12,
      y + 10,
      18,
      6
    );

    ctx.fillRect(
      x + p.w - 30,
      y + 10,
      18,
      6
    );
  }
}

function drawSpikes() {
  if (!level) return;

  for (const spike of level.spikes) {
    const x =
      Math.floor(
        spike.x - cameraX
      );

    const y =
      Math.floor(spike.y);

    ctx.fillStyle = "#eee";

    ctx.beginPath();

    ctx.moveTo(
      x,
      y + spike.h
    );

    ctx.lineTo(
      x + spike.w / 2,
      y
    );

    ctx.lineTo(
      x + spike.w,
      y + spike.h
    );

    ctx.closePath();

    ctx.fill();

    ctx.fillStyle = "#777";

    ctx.fillRect(
      x,
      y + spike.h - 4,
      spike.w,
      4
    );
  }
}

function drawCoins() {
  if (!level) return;

  for (const coin of level.coins) {
    if (coin.taken) continue;

    const x =
      Math.floor(
        coin.x - cameraX
      );

    const y =
      Math.floor(coin.y);

    ctx.fillStyle = "#ffd92f";

    ctx.beginPath();

    ctx.arc(
      x + coin.w / 2,
      y + coin.h / 2,
      9,
      0,
      Math.PI * 2
    );

    ctx.fill();

    ctx.fillStyle = "#fff3a0";

    ctx.fillRect(
      x + 6,
      y + 4,
      4,
      7
    );
  }
}

function drawEnemies() {
  if (!level) return;

  for (const enemy of level.enemies) {
    if (enemy.dead) continue;

    const x =
      Math.floor(
        enemy.x - cameraX
      );

    const y =
      Math.floor(enemy.y);

    ctx.fillStyle = "#d93434";

    ctx.fillRect(
      x,
      y,
      enemy.w,
      enemy.h
    );

    ctx.fillStyle = "#8f1717";

    ctx.fillRect(
      x,
      y + enemy.h - 7,
      enemy.w,
      7
    );

    ctx.fillStyle = "#fff";

    ctx.fillRect(
      x + 6,
      y + 6,
      6,
      7
    );

    ctx.fillRect(
      x + 18,
      y + 6,
      6,
      7
    );

    ctx.fillStyle = "#111";

    ctx.fillRect(
      x + 8,
      y + 8,
      3,
      4
    );

    ctx.fillRect(
      x + 20,
      y + 8,
      3,
      4
    );
  }
}

function drawButtonsAndDoors() {
  if (!level) return;

  /*
   * BOTÕES
   */
  for (const button of level.buttons) {
    const x =
      Math.floor(
        button.x - cameraX
      );

    const y =
      Math.floor(button.y);

    ctx.fillStyle =
      button.pressed
        ? "#45e65b"
        : "#e83c3c";

    ctx.fillRect(
      x,
      y,
      button.w,
      button.h
    );

    ctx.fillStyle = "#222";

    ctx.fillRect(
      x + 4,
      y + 4,
      button.w - 8,
      5
    );
  }

  /*
   * PORTAS
   */
  for (const door of level.doors) {
    if (door.open) continue;

    const x =
      Math.floor(
        door.x - cameraX
      );

    const y =
      Math.floor(door.y);

    ctx.fillStyle = "#242424";

    ctx.fillRect(
      x,
      y,
      door.w,
      door.h
    );

    ctx.fillStyle = "#888";

    ctx.fillRect(
      x + 7,
      y + 8,
      8,
      8
    );

    ctx.fillRect(
      x + 7,
      y + 30,
      8,
      8
    );

    ctx.fillRect(
      x + 7,
      y + 52,
      8,
      8
    );
  }
}

function drawFinish() {
  if (!level || !level.finish) return;

  const f = level.finish;

  const x =
    Math.floor(
      f.x - cameraX
    );

  const y =
    Math.floor(f.y);

  /*
   * POSTE
   */
  ctx.fillStyle = "#eee";

  ctx.fillRect(
    x + 18,
    y,
    7,
    f.h
  );

  /*
   * BANDEIRA
   */
  ctx.fillStyle = "#ff3333";

  ctx.beginPath();

  ctx.moveTo(
    x + 25,
    y + 8
  );

  ctx.lineTo(
    x + 65,
    y + 25
  );

  ctx.lineTo(
    x + 25,
    y + 42
  );

  ctx.closePath();

  ctx.fill();

  /*
   * BASE
   */
  ctx.fillStyle = "#555";

  ctx.fillRect(
    x,
    y + f.h - 8,
    45,
    8
  );
}

function drawPlayer() {
  if (!player) return;

  /*
   * PISCAR DURANTE INVENCIBILIDADE
   */
  if (
    player.invincible > 0 &&
    Math.floor(
      player.invincible / 8
    ) % 2 === 0
  ) {
    return;
  }

  const x =
    Math.floor(
      player.x - cameraX
    );

  const y =
    Math.floor(player.y);

  /*
   * CORPO DO 67
   */
  ctx.fillStyle = "#111";

  ctx.fillRect(
    x + 2,
    y + 2,
    player.w - 4,
    player.h - 4
  );

  ctx.fillStyle = "#fff";

  ctx.font =
    "bold 24px monospace";

  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  ctx.fillText(
    "67",
    x + player.w / 2,
    y + player.h / 2 + 1
  );

  /*
   * OLHOS
   */
  ctx.fillStyle = "#111";

  ctx.fillRect(
    x + 8,
    y + 7,
    4,
    5
  );

  ctx.fillRect(
    x + 22,
    y + 7,
    4,
    5
  );

  /*
   * PÉS
   */
  ctx.fillStyle = "#222";

  ctx.fillRect(
    x + 3,
    y + player.h - 5,
    11,
    5
  );

  ctx.fillRect(
    x + player.w - 14,
    y + player.h - 5,
    11,
    5
  );
}

function draw() {
  ctx.clearRect(
    0,
    0,
    W,
    H
  );

  drawBackground();

  if (!level) return;

  drawPlatforms();
  drawSpikes();
  drawCoins();
  drawEnemies();
  drawButtonsAndDoors();
  drawFinish();
  drawPlayer();
}

function update(dt) {
  if (
    !gameRunning ||
    paused
  ) {
    return;
  }

  updateMovingPlatforms(dt);
  updatePlayer(dt);
}

function gameLoop(time) {
  if (!lastTime) {
    lastTime = time;
  }

  let dt =
    (time - lastTime) / 16.6667;

  lastTime = time;

  /*
   * EVITA BUGS SE O CELULAR TRAVAR
   */
  dt = Math.min(
    dt,
    2
  );

  update(dt);
  draw();

  requestAnimationFrame(
    gameLoop
  );
}

requestAnimationFrame(
  gameLoop
);

/* ================================
   TECLADO
================================ */

window.addEventListener(
  "keydown",
  (e) => {
    if (
      e.key === "ArrowLeft" ||
      e.key.toLowerCase() === "a"
    ) {
      keys.left = true;
      e.preventDefault();
    }

    if (
      e.key === "ArrowRight" ||
      e.key.toLowerCase() === "d"
    ) {
      keys.right = true;
      e.preventDefault();
    }

    if (
      e.key === "ArrowUp" ||
      e.key === " " ||
      e.key.toLowerCase() === "w"
    ) {
      keys.jump = true;
      e.preventDefault();
    }

    if (
      e.key === "Escape" &&
      gameRunning
    ) {
      togglePause();
    }
  },
  { passive: false }
);

window.addEventListener(
  "keyup",
  (e) => {
    if (
      e.key === "ArrowLeft" ||
      e.key.toLowerCase() === "a"
    ) {
      keys.left = false;
    }

    if (
      e.key === "ArrowRight" ||
      e.key.toLowerCase() === "d"
    ) {
      keys.right = false;
    }

    if (
      e.key === "ArrowUp" ||
      e.key === " " ||
      e.key.toLowerCase() === "w"
    ) {
      keys.jump = false;
    }
  }
);

/* ================================
   CONTROLES TOUCH
================================ */

const touchButtons =
  document.querySelectorAll(
    "#touchControls button"
  );

touchButtons.forEach(
  (button) => {
    const key =
      button.dataset.key;

    function press(e) {
      e.preventDefault();

      keys[key] = true;
    }

    function release(e) {
      e.preventDefault();

      keys[key] = false;
    }

    button.addEventListener(
      "touchstart",
      press,
      { passive: false }
    );

    button.addEventListener(
      "touchend",
      release,
      { passive: false }
    );

    button.addEventListener(
      "touchcancel",
      release,
      { passive: false }
    );

    /*
     * Também funciona com mouse
     */
    button.addEventListener(
      "mousedown",
      press
    );

    button.addEventListener(
      "mouseup",
      release
    );

    button.addEventListener(
      "mouseleave",
      release
    );
  }
);

/* ================================
   PAUSA
================================ */

function togglePause() {
  if (!gameRunning) return;

  paused = !paused;

  if (paused) {
    pauseBox.classList.remove(
      "hidden"
    );
  } else {
    pauseBox.classList.add(
      "hidden"
    );
  }
}

resumeBtn.addEventListener(
  "click",
  () => {
    paused = false;

    pauseBox.classList.add(
      "hidden"
    );
  }
);

levelBtn.addEventListener(
  "click",
  () => {
    showLevels();
  }
);

/* ================================
   MENU
================================ */

playBtn.addEventListener(
  "click",
  () => {
    showLevels();
  }
);

backBtn.addEventListener(
  "click",
  () => {
    levelsScreen.classList.add(
      "hidden"
    );

    menu.classList.remove(
      "hidden"
    );
  }
);

resetBtn.addEventListener(
  "click",
  () => {
    const ok =
      confirm(
        "Apagar todo o progresso?"
      );

    if (!ok) return;

    unlocked = 1;
    completed = [];

    saveProgress();

    showLevels();
  }
);

/* ================================
   IMPEDIR SCROLL / ZOOM NO JOGO
================================ */

document.addEventListener(
  "touchmove",
  (e) => {
    if (
      game.classList.contains(
        "hidden"
      )
    ) {
      return;
    }

    e.preventDefault();
  },
  { passive: false }
);

document.addEventListener(
  "contextmenu",
  (e) => {
    if (
      e.target.closest(
        "#touchControls"
      )
    ) {
      e.preventDefault();
    }
  }
);

/* ================================
   INICIALIZAÇÃO
================================ */

showLevels();