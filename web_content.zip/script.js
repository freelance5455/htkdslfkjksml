(() => {
  'use strict';

  const canvas = document.getElementById('board');
  const ctx = canvas.getContext('2d');
  const W = 1000;
  const TAU = Math.PI * 2;
  const bounds = { min: 86, max: 914 };
  const pockets = [{ x: 87, y: 87 }, { x: 913, y: 87 }, { x: 87, y: 913 }, { x: 913, y: 913 }];
  const THEMES = {
    classic: { label: 'CLASSIC WOOD', outer: '#3e2116', rim: '#8d4c29', frame: '#bd7940', surface: '#e5c18b', surface2: '#d4a76c', line: '#8a4a2c', lineSoft: 'rgba(105,48,26,.35)', pocket: '#1b100d', pocketRing: '#522818', ink: '#4a251c', grain: '#7a3f25', accent: '#e5a24b' },
    dark: { label: 'DARK PREMIUM', outer: '#17141a', rim: '#362026', frame: '#82513c', surface: '#b6825b', surface2: '#906044', line: '#522b2c', lineSoft: 'rgba(45,22,28,.38)', pocket: '#09090d', pocketRing: '#241319', ink: '#2a1c22', grain: '#5e392d', accent: '#dfa05e' },
    light: { label: 'LIGHT MODERN', outer: '#d4c4af', rim: '#9c5b3e', frame: '#e5a06a', surface: '#f1d8ad', surface2: '#e4bd84', line: '#a05a3a', lineSoft: 'rgba(126,61,36,.28)', pocket: '#3b211d', pocketRing: '#8b5034', ink: '#774129', grain: '#bb754d', accent: '#a95431' }
  };
  const DIFFICULTY = { easy: { label: 'EASY', error: .26, power: .68 }, medium: { label: 'MEDIUM', error: .11, power: .82 }, hard: { label: 'HARD', error: .035, power: .94 } };
  const ownColor = index => index === 0 ? 'white' : 'black';
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const normalize = (x, y) => { const l = Math.hypot(x, y) || 1; return { x: x / l, y: y / l }; };
  const makeId = () => Math.random().toString(36).slice(2, 8);

  const state = {
    view: 'menu', mode: 'ai', difficulty: localStorage.getItem('carrom-difficulty') || 'medium', theme: localStorage.getItem('carrom-theme') || 'classic', sound: localStorage.getItem('carrom-sound') !== 'off', music: localStorage.getItem('carrom-music') !== 'off',
    turn: 0, phase: 'menu', shot: null, coins: [], striker: null, queen: { status: 'onboard', captured: false }, particles: [], floats: [], lastFrame: 0, aiTimer: null, toastTimer: null, pointer: null, audioContext: null, musicAudio: null
  };
  state.players = [
    { name: 'YOU', score: 0, remaining: 9, color: 'white' },
    { name: 'COMPUTER', score: 0, remaining: 9, color: 'black' }
  ];

  const ui = {
    menu: document.getElementById('main-menu'), game: document.getElementById('game-screen'), modalLayer: document.getElementById('modal-layer'), settings: document.getElementById('settings-modal'), howto: document.getElementById('howto-modal'), pause: document.getElementById('pause-modal'), result: document.getElementById('result-modal'), slider: document.getElementById('striker-slider'), powerValue: document.getElementById('power-value'), powerFill: document.getElementById('power-fill'), positionValue: document.getElementById('position-value'), aimLabel: document.getElementById('aim-label'), turnLabel: document.getElementById('turn-label'), queenStatus: document.getElementById('queen-status'), modeLabel: document.getElementById('match-mode-label'), toast: document.getElementById('toast'), shoot: document.getElementById('shoot-button')
  };

  const sounds = {
    click: 'assets/sounds/click.wav', shoot: 'assets/sounds/shot.wav', collision: 'assets/sounds/collision.wav', pocket: 'assets/sounds/pocket.wav', queen: 'assets/sounds/queen.wav', foul: 'assets/sounds/foul.wav', win: 'assets/sounds/win.wav', lose: 'assets/sounds/lose.wav'
  };

  function setTheme(theme) {
    if (!THEMES[theme]) theme = 'classic';
    state.theme = theme;
    document.body.dataset.theme = theme;
    document.getElementById('board-theme-label').textContent = THEMES[theme].label;
    localStorage.setItem('carrom-theme', theme);
    document.querySelectorAll('[data-theme-choice]').forEach(btn => btn.classList.toggle('selected', btn.dataset.themeChoice === theme));
    draw();
  }

  function updateSoundUI() {
    const icon = state.sound ? '◉' : '⊘';
    document.getElementById('menu-sound-icon').textContent = icon;
    document.getElementById('menu-sound').lastChild.textContent = state.sound ? ' SOUND ON' : ' SOUND OFF';
    document.getElementById('game-sound').textContent = icon;
    document.querySelector('#sound-toggle .toggle').classList.toggle('on', state.sound);
    document.querySelector('#music-toggle .toggle').classList.toggle('on', state.music);
  }

  function playSound(name, volume = 1) {
    if (!state.sound || !sounds[name]) return;
    try {
      const audio = new Audio(sounds[name]);
      audio.volume = Math.min(1, volume);
      audio.play().catch(() => fallbackTone(name));
    } catch { fallbackTone(name); }
  }

  function fallbackTone(name) {
    if (!state.sound) return;
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    if (!state.audioContext) state.audioContext = new AudioCtx();
    const ac = state.audioContext;
    const osc = ac.createOscillator(); const gain = ac.createGain();
    const presets = { click: [520, .05, 'square'], shoot: [120, .12, 'triangle'], collision: [220, .08, 'sine'], pocket: [180, .16, 'sine'], queen: [420, .34, 'sine'], foul: [95, .3, 'sawtooth'], win: [620, .5, 'sine'], lose: [170, .45, 'sawtooth'] };
    const [freq, duration, type] = presets[name] || presets.click;
    osc.type = type; osc.frequency.setValueAtTime(freq, ac.currentTime); osc.frequency.exponentialRampToValueAtTime(Math.max(35, freq * .55), ac.currentTime + duration);
    gain.gain.setValueAtTime(.0001, ac.currentTime); gain.gain.exponentialRampToValueAtTime(.11, ac.currentTime + .012); gain.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + duration);
    osc.connect(gain).connect(ac.destination); osc.start(); osc.stop(ac.currentTime + duration + .02);
  }

  function startMusic() {
    if (!state.music || state.musicAudio) return;
    try { state.musicAudio = new Audio('assets/sounds/ambient-loop.wav'); state.musicAudio.loop = true; state.musicAudio.volume = .14; state.musicAudio.play().catch(() => {}); } catch { /* audio is optional */ }
  }
  function stopMusic() { if (state.musicAudio) { state.musicAudio.pause(); state.musicAudio = null; } }

  function showToast(message, duration = 1900) {
    clearTimeout(state.toastTimer); ui.toast.textContent = message; ui.toast.classList.add('show');
    state.toastTimer = setTimeout(() => ui.toast.classList.remove('show'), duration);
  }

  function showView(name) {
    state.view = name;
    ui.menu.classList.toggle('hidden', name !== 'menu'); ui.game.classList.toggle('hidden', name !== 'game');
  }

  function openModal(which) {
    ui.modalLayer.classList.remove('hidden');
    [ui.settings, ui.howto, ui.pause, ui.result].forEach(modal => modal.classList.add('hidden'));
    which.classList.remove('hidden');
  }
  function closeModal() { ui.modalLayer.classList.add('hidden'); [ui.settings, ui.howto, ui.pause, ui.result].forEach(modal => modal.classList.add('hidden')); }

  function makeCoin(color, x, y, kind = 'coin') { return { id: makeId(), color, x, y, vx: 0, vy: 0, r: kind === 'queen' ? 20 : 18, kind, pocketed: false, fade: 1 }; }

  function buildRack() {
    const coins = [];
    const spacing = 39;
    coins.push(makeCoin('red', 500, 500, 'queen'));
    for (let ring = 1; ring <= 2; ring++) {
      const count = ring === 1 ? 6 : 12;
      for (let i = 0; i < count; i++) {
        const angle = (i / count) * TAU + (ring === 2 ? Math.PI / count : 0);
        const radius = ring * spacing;
        const color = (i + ring) % 2 === 0 ? 'white' : 'black';
        coins.push(makeCoin(color, 500 + Math.cos(angle) * radius, 500 + Math.sin(angle) * radius));
      }
    }
    return coins;
  }

  function currentBaseline() { return state.turn === 0 ? 855 : 145; }
  function resetStriker() {
    const y = currentBaseline();
    state.striker = { x: 500, y, vx: 0, vy: 0, r: 25, color: 'striker', pocketed: false, fade: 1 };
    ui.slider.value = 50; updateAimUI();
  }

  function startMatch(mode = 'ai') {
    playSound('click'); startMusic();
    state.mode = mode; state.phase = 'aiming'; state.turn = 0; state.shot = null; state.coins = buildRack(); state.queen = { status: 'onboard', captured: false }; state.particles = []; state.floats = [];
    state.players = [{ name: 'YOU', score: 0, remaining: 9, color: 'white' }, { name: mode === 'ai' ? 'COMPUTER' : 'PLAYER 2', score: 0, remaining: 9, color: 'black' }];
    document.getElementById('player-name-1').textContent = state.players[1].name; document.getElementById('result-score-name-1').textContent = state.players[1].name;
    ui.modeLabel.textContent = mode === 'ai' ? `CPU • ${DIFFICULTY[state.difficulty].label}` : 'LOCAL • 2P';
    closeModal(); showView('game'); setTheme(state.theme); updateHUD(); resetStriker(); resizeCanvas(); draw();
    if (mode === 'ai') showToast(`Break shot • ${state.players[0].name} to play`, 1500);
  }

  function updateHUD() {
    state.players.forEach((player, i) => { document.getElementById(`player-score-${i}`).textContent = player.score; document.getElementById(`player-remaining-${i}`).textContent = player.remaining; document.getElementById(`player-card-${i}`).classList.toggle('active', state.turn === i); });
    const isAI = state.mode === 'ai' && state.turn === 1;
    ui.turnLabel.textContent = isAI ? 'COMPUTER AIMING' : `${state.players[state.turn].name} TURN`;
    ui.queenStatus.textContent = state.queen.status === 'covered' ? 'QUEEN COVERED' : state.queen.status === 'captured' ? 'QUEEN POCKETED' : 'QUEEN ON BOARD';
    ui.aimLabel.textContent = state.phase === 'moving' ? 'TABLE IN MOTION' : isAI ? 'COMPUTER THINKING' : 'AIM & PULL BACK';
    const canControl = state.phase === 'aiming' && !isAI;
    [ui.slider, ui.shoot, document.getElementById('move-left'), document.getElementById('move-right'), document.getElementById('nudge-center')].forEach(el => { el.disabled = !canControl; });
  }

  function updateAimUI() {
    if (!state.striker) return;
    const percentage = Math.round(((state.striker.x - bounds.min) / (bounds.max - bounds.min)) * 100);
    ui.positionValue.textContent = percentage < 38 ? 'LEFT LANE' : percentage > 62 ? 'RIGHT LANE' : 'CENTER';
    ui.slider.value = clamp(((state.striker.x - bounds.min) / (bounds.max - bounds.min)) * 76 + 12, 12, 88);
    const power = state.pointer?.power || 0;
    ui.powerValue.textContent = `${Math.round(power * 100)}%`; ui.powerFill.style.width = `${power * 100}%`;
  }

  function moveStriker(percent) { if (state.phase !== 'aiming' || (state.mode === 'ai' && state.turn === 1)) return; state.striker.x = bounds.min + (bounds.max - bounds.min) * clamp((percent - 12) / 76, 0, 1); playSound('click', .35); updateAimUI(); draw(); }

  function canvasPoint(event) {
    const rect = canvas.getBoundingClientRect(); return { x: ((event.clientX - rect.left) / rect.width) * W, y: ((event.clientY - rect.top) / rect.height) * W };
  }

  function handlePointerDown(event) {
    if (state.phase !== 'aiming' || (state.mode === 'ai' && state.turn === 1)) return;
    event.preventDefault(); canvas.setPointerCapture?.(event.pointerId);
    const p = canvasPoint(event); const s = state.striker;
    const touchingStriker = dist(p, s) <= s.r + 34;
    const nearBaseline = Math.abs(p.y - s.y) < 105;
    // Touch the striker itself to aim/pull back; touch elsewhere on the baseline to reposition it.
    state.pointer = { start: p, current: p, mode: touchingStriker ? 'aim' : nearBaseline ? 'position' : 'aim', power: 0 };
    if (state.pointer.mode === 'position') { s.x = clamp(p.x, bounds.min + s.r, bounds.max - s.r); updateAimUI(); }
    else updateAimFromPoint(p);
    draw();
  }

  function updateAimFromPoint(p) {
    if (!state.pointer || state.pointer.mode !== 'aim') return;
    state.pointer.current = p; const dx = state.striker.x - p.x; const dy = state.striker.y - p.y; const length = Math.hypot(dx, dy);
    state.pointer.dir = normalize(dx, dy); state.pointer.power = clamp(length / 330, 0, 1); updateAimUI();
  }

  function handlePointerMove(event) {
    if (!state.pointer) return; event.preventDefault(); const p = canvasPoint(event);
    if (state.pointer.mode === 'position') { state.striker.x = clamp(p.x, bounds.min + 32, bounds.max - 32); updateAimUI(); }
    else updateAimFromPoint(p);
    draw();
  }

  function handlePointerUp(event) {
    if (!state.pointer) return; event.preventDefault();
    const shotPower = state.pointer.power; const direction = state.pointer.dir; const mode = state.pointer.mode; state.pointer = null;
    if (mode === 'aim' && shotPower > .09 && direction) fireShot(direction, shotPower);
    else { ui.powerValue.textContent = '0%'; ui.powerFill.style.width = '0%'; updateAimUI(); draw(); }
  }

  function fireShot(direction, power) {
    if (state.phase !== 'aiming' || !direction || !state.striker) return;
    state.phase = 'moving'; state.shot = { pocketed: [], ownPocketed: 0, opponentPocketed: 0, queenPocketed: false, strikerPocketed: false, started: performance.now() };
    state.striker.vx = direction.x * (620 + power * 770); state.striker.vy = direction.y * (620 + power * 770); state.striker.pocketed = false;
    playSound('shoot'); updateHUD(); showToast(power > .75 ? 'Power shot' : power < .3 ? 'Soft touch' : 'Clean break', 900); draw();
  }

  function activePieces() { return [state.striker, ...state.coins].filter(Boolean).filter(piece => !piece.pocketed); }
  function allStopped() { return activePieces().every(piece => Math.hypot(piece.vx, piece.vy) < 5); }

  function pocketPiece(piece) {
    if (piece.pocketed) return;
    piece.pocketed = true; piece.vx = piece.vy = 0;
    const pocket = pockets.reduce((best, p) => dist(piece, p) < dist(piece, best) ? p : best, pockets[0]);
    state.particles.push(...Array.from({ length: 8 }, (_, i) => ({ x: pocket.x, y: pocket.y, vx: Math.cos(i) * 50, vy: Math.sin(i) * 50, life: 1, color: piece.kind === 'queen' ? '#d84d4d' : '#f0b65a' })));
    if (piece === state.striker) { state.shot.strikerPocketed = true; playSound('foul'); addFloat('FOUL', piece.x, piece.y, '#d96f5d'); }
    else { state.shot.pocketed.push(piece); if (piece.kind === 'queen') { state.shot.queenPocketed = true; state.queen.status = 'captured'; playSound('queen'); addFloat('QUEEN!', piece.x, piece.y, '#e0584e'); } else { const currentColor = ownColor(state.turn); if (piece.color === currentColor) state.shot.ownPocketed += 1; else state.shot.opponentPocketed += 1; playSound('pocket', .82); addFloat(piece.color === currentColor ? '+1' : 'OPPONENT COIN', piece.x, piece.y, piece.color === currentColor ? '#84c59f' : '#efb574'); } }
  }

  function resolveCollision(a, b) {
    if (a.pocketed || b.pocketed) return;
    const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy), min = a.r + b.r;
    if (d >= min) return;
    // Give perfectly overlapping pieces a stable separation direction instead of ignoring them.
    const safeD = d || 0.001;
    const nx = d ? dx / safeD : 1, ny = d ? dy / safeD : 0;
    const overlap = min - safeD;
    a.x -= nx * (overlap * .51); a.y -= ny * (overlap * .51);
    b.x += nx * (overlap * .51); b.y += ny * (overlap * .51);
    const rvx = a.vx - b.vx, rvy = a.vy - b.vy;
    const vel = rvx * nx + rvy * ny;
    if (vel <= 0) return;
    // Near-elastic collision: the struck coin receives the striker's forward momentum.
    const restitution = .94;
    const impulse = vel * restitution;
    a.vx -= impulse * nx; a.vy -= impulse * ny;
    b.vx += impulse * nx; b.vy += impulse * ny;
    const now = performance.now();
    if (Math.abs(vel) > 110 && now - (state.lastCollisionSound || 0) > 75) {
      state.lastCollisionSound = now; playSound('collision', .2);
    }
  }

  function updatePhysics(dt) {
    if (state.phase !== 'moving') return;
    // Small physics steps prevent fast striker shots from jumping through coins.
    const maxStep = 1 / 120;
    const steps = Math.max(1, Math.ceil(dt / maxStep));
    const step = dt / steps;
    const friction = Math.pow(.988, step * 60);
    for (let n = 0; n < steps; n++) {
      const pieces = activePieces();
      pieces.forEach(piece => {
        piece.x += piece.vx * step; piece.y += piece.vy * step;
        piece.vx *= friction; piece.vy *= friction;
        if (Math.abs(piece.vx) < 1.2) piece.vx = 0;
        if (Math.abs(piece.vy) < 1.2) piece.vy = 0;
        // Pocket check happens before rail bounce so corner shots can enter naturally.
        for (const pocket of pockets) {
          if (dist(piece, pocket) < 43) { pocketPiece(piece); break; }
        }
        if (piece.pocketed) return;
        const limit = bounds.max - piece.r; const low = bounds.min + piece.r;
        if (piece.x < low) { piece.x = low; piece.vx = Math.abs(piece.vx) * .9; }
        if (piece.x > limit) { piece.x = limit; piece.vx = -Math.abs(piece.vx) * .9; }
        if (piece.y < low) { piece.y = low; piece.vy = Math.abs(piece.vy) * .9; }
        if (piece.y > limit) { piece.y = limit; piece.vy = -Math.abs(piece.vy) * .9; }
      });
      const moving = activePieces();
      // A second pass resolves crowded racks more reliably.
      for (let pass = 0; pass < 2; pass++) {
        for (let i = 0; i < moving.length; i++) {
          for (let j = i + 1; j < moving.length; j++) resolveCollision(moving[i], moving[j]);
        }
      }
    }
    updateParticles(dt);
    if (allStopped()) { state.phase = 'resolving'; setTimeout(resolveShot, 100); }
  }

  function resolveShot() {
    if (!state.shot) return;
    const shot = state.shot; const player = state.players[state.turn]; const opponent = state.players[1 - state.turn];
    if (shot.strikerPocketed) { player.score = Math.max(0, player.score - 1); showToast('Foul — striker pocketed (-1)', 1800); }
    const currentColor = ownColor(state.turn); const capturedOwn = shot.pocketed.filter(piece => piece.kind !== 'queen' && piece.color === currentColor);
    capturedOwn.forEach(() => { player.score += 1; player.remaining = Math.max(0, player.remaining - 1); });
    shot.pocketed.filter(piece => piece.kind !== 'queen' && piece.color !== currentColor).forEach(() => { opponent.remaining = Math.min(9, opponent.remaining + 1); });
    if (shot.queenPocketed) {
      if (capturedOwn.length > 0 && !shot.strikerPocketed) { state.queen.status = 'covered'; player.score += 3; addFloat('+3 QUEEN COVER', 500, 500, '#e0584e'); showToast('Queen covered — +3 bonus', 1900); }
      else { returnQueen(); showToast('Queen returned — cover it with your colour', 2100); }
    }
    const won = player.remaining === 0 && state.queen.status === 'covered';
    state.shot = null; state.pointer = null;
    if (won) { finishMatch(state.turn); return; }
    const continueTurn = capturedOwn.length > 0 && !shot.strikerPocketed;
    if (!continueTurn) state.turn = 1 - state.turn;
    state.phase = 'aiming'; resetStriker(); updateHUD();
    if (capturedOwn.length > 0 && continueTurn) showToast(`${player.name}: clean pocket, shoot again`, 1500);
    if (state.mode === 'ai' && state.turn === 1) scheduleAI();
    draw();
  }

  function returnQueen() {
    state.queen.status = 'onboard'; state.queen.captured = false;
    const spots = [{ x: 500, y: 500 }, { x: 466, y: 500 }, { x: 534, y: 500 }]; const spot = spots[Math.floor(Math.random() * spots.length)];
    state.coins.push(makeCoin('red', spot.x, spot.y, 'queen')); addFloat('QUEEN RETURNS', spot.x, spot.y, '#e0584e');
  }

  function scheduleAI() {
    clearTimeout(state.aiTimer); state.phase = 'ai'; updateHUD(); showToast(`${state.players[1].name} is lining up…`, 1200);
    state.aiTimer = setTimeout(() => { if (state.phase === 'ai') makeAIShot(); }, 780);
  }

  function makeAIShot() {
    const skill = DIFFICULTY[state.difficulty]; const targets = state.coins.filter(c => !c.pocketed && c.color === 'black');
    if (!targets.length) { state.phase = 'aiming'; resetStriker(); updateHUD(); return; }
    const target = targets.reduce((best, coin) => coin.y < best.y ? coin : best, targets[0]);
    const pocket = pockets.reduce((best, p) => dist(target, p) < dist(target, best) ? p : best, pockets[0]);
    const toPocket = normalize(pocket.x - target.x, pocket.y - target.y); const contact = { x: target.x - toPocket.x * 42, y: target.y - toPocket.y * 42 };
    const jitter = (Math.random() - .5) * skill.error * 310; const x = clamp(contact.x + jitter, bounds.min + 36, bounds.max - 36); state.striker.x = x; state.striker.y = currentBaseline();
    const dir = normalize(contact.x - state.striker.x + jitter * .2, contact.y - state.striker.y); const power = clamp(skill.power * (.72 + dist(state.striker, contact) / 650), .44, 1);
    state.phase = 'aiming'; fireShot(dir, power);
  }

  function finishMatch(winner) {
    state.phase = 'over'; const won = winner === 0; playSound(won ? 'win' : 'lose'); stopMusic();
    document.getElementById('result-eyebrow').textContent = won ? 'TABLE COMPLETE' : 'MATCH COMPLETE'; document.getElementById('result-title').textContent = won ? 'YOU WIN' : `${state.players[winner].name} WINS`; document.getElementById('result-copy').textContent = won ? 'A clean finish. The board belongs to you.' : 'A sharp finish. There is always another break.';
    document.getElementById('result-score-0').textContent = state.players[0].score; document.getElementById('result-score-1').textContent = state.players[1].score; openModal(ui.result); updateHUD(); draw();
  }

  function addFloat(text, x, y, color) { state.floats.push({ text, x, y, color, life: 1, vy: -36 }); }
  function updateParticles(dt) { state.particles.forEach(p => { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= .94; p.vy *= .94; p.life -= dt * 2.3; }); state.particles = state.particles.filter(p => p.life > 0); state.floats.forEach(f => { f.y += f.vy * dt; f.life -= dt * .8; }); state.floats = state.floats.filter(f => f.life > 0); }

  function roundRect(c, x, y, w, h, r) { c.beginPath(); c.roundRect(x, y, w, h, r); }

  function drawBoard() {
    const t = THEMES[state.theme]; ctx.clearRect(0, 0, W, W); ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,.38)'; ctx.shadowBlur = 26; ctx.shadowOffsetY = 18; roundRect(ctx, 26, 22, 948, 948, 56); ctx.fillStyle = t.outer; ctx.fill(); ctx.restore();
    const frame = ctx.createLinearGradient(0, 30, 0, 970); frame.addColorStop(0, t.frame); frame.addColorStop(.5, t.rim); frame.addColorStop(1, t.outer);
    roundRect(ctx, 36, 32, 928, 928, 52); ctx.fillStyle = frame; ctx.fill(); ctx.strokeStyle = 'rgba(255,228,173,.34)'; ctx.lineWidth = 4; ctx.stroke();
    roundRect(ctx, 69, 65, 862, 862, 29); const surface = ctx.createRadialGradient(330, 270, 80, 500, 500, 700); surface.addColorStop(0, t.surface); surface.addColorStop(1, t.surface2); ctx.fillStyle = surface; ctx.fill();
    ctx.save(); ctx.globalAlpha = .16; ctx.strokeStyle = t.grain; ctx.lineWidth = 2; for (let i = 0; i < 28; i++) { const y = 87 + i * 29; ctx.beginPath(); ctx.moveTo(76, y + Math.sin(i * 2.1) * 5); ctx.bezierCurveTo(280, y - 14, 650, y + 18, 925, y - 5); ctx.stroke(); } ctx.restore();
    ctx.strokeStyle = 'rgba(255,245,211,.48)'; ctx.lineWidth = 3; roundRect(ctx, 82, 78, 836, 836, 19); ctx.stroke();
    drawMarkings(t); pockets.forEach(p => drawPocket(p, t));
  }

  function drawMarkings(t) {
    ctx.save(); ctx.strokeStyle = t.line; ctx.fillStyle = t.line; ctx.lineWidth = 4; ctx.globalAlpha = .88;
    ctx.beginPath(); ctx.arc(500, 500, 73, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(500, 500, 22, 0, TAU); ctx.stroke(); ctx.beginPath(); ctx.arc(500, 500, 8, 0, TAU); ctx.fill();
    ctx.lineWidth = 2; ctx.globalAlpha = .6; ctx.beginPath(); ctx.arc(500, 500, 111, 0, TAU); ctx.stroke();
    [145, 855].forEach(y => { ctx.globalAlpha = .9; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(165, y); ctx.lineTo(835, y); ctx.stroke(); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(195, y - 18); ctx.lineTo(195, y + 18); ctx.moveTo(805, y - 18); ctx.lineTo(805, y + 18); ctx.stroke(); ctx.globalAlpha = .4; ctx.beginPath(); ctx.moveTo(245, y - 12); ctx.lineTo(755, y - 12); ctx.moveTo(245, y + 12); ctx.lineTo(755, y + 12); ctx.stroke(); });
    const arrows = [[164, 145, 1, 1], [836, 145, -1, 1], [164, 855, 1, -1], [836, 855, -1, -1]]; ctx.globalAlpha = .8; arrows.forEach(([x, y, sx, sy]) => { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + sx * 54, y + sy * 42); ctx.moveTo(x + sx * 54, y + sy * 42); ctx.lineTo(x + sx * 39, y + sy * 42); ctx.moveTo(x + sx * 54, y + sy * 42); ctx.lineTo(x + sx * 49, y + sy * 27); ctx.stroke(); });
    ctx.restore();
  }

  function drawPocket(p, t) {
    ctx.save(); const ring = ctx.createRadialGradient(p.x - 8, p.y - 8, 3, p.x, p.y, 47); ring.addColorStop(0, '#09090a'); ring.addColorStop(.52, t.pocket); ring.addColorStop(.7, t.pocketRing); ring.addColorStop(1, t.frame); ctx.fillStyle = ring; ctx.beginPath(); ctx.arc(p.x, p.y, 45, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(255,229,167,.42)'; ctx.lineWidth = 3; ctx.stroke(); ctx.restore();
  }

  function drawPiece(piece) {
    if (!piece || piece.pocketed || piece.fade <= 0) return; ctx.save(); ctx.globalAlpha = piece.fade; ctx.shadowColor = 'rgba(45,22,12,.42)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 5; ctx.beginPath(); ctx.arc(piece.x, piece.y, piece.r + 3, 0, TAU); ctx.fillStyle = '#5a301f'; ctx.fill(); ctx.restore();
    ctx.save(); ctx.globalAlpha = piece.fade; const radius = piece.r; let fill;
    if (piece.kind === 'queen') { fill = ctx.createRadialGradient(piece.x - 6, piece.y - 8, 2, piece.x, piece.y, radius); fill.addColorStop(0, '#ff9b84'); fill.addColorStop(.35, '#de544a'); fill.addColorStop(1, '#8b231e'); }
    else if (piece.color === 'white') { fill = ctx.createRadialGradient(piece.x - 6, piece.y - 8, 2, piece.x, piece.y, radius); fill.addColorStop(0, '#fffdf4'); fill.addColorStop(.55, '#e8ddc6'); fill.addColorStop(1, '#a89077'); }
    else { fill = ctx.createRadialGradient(piece.x - 6, piece.y - 8, 2, piece.x, piece.y, radius); fill.addColorStop(0, '#756255'); fill.addColorStop(.35, '#2d2828'); fill.addColorStop(1, '#0d0d10'); }
    ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(piece.x, piece.y, radius, 0, TAU); ctx.fill(); ctx.strokeStyle = piece.kind === 'queen' ? '#ffb39a' : 'rgba(255,238,205,.52)'; ctx.lineWidth = 2; ctx.stroke(); ctx.globalAlpha = .55; ctx.fillStyle = piece.kind === 'queen' ? '#ffd1c0' : '#fff6de'; ctx.beginPath(); ctx.arc(piece.x - radius * .36, piece.y - radius * .42, radius * .18, 0, TAU); ctx.fill();
    if (piece.kind === 'queen') { ctx.globalAlpha = .75; ctx.strokeStyle = '#ffd0a6'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(piece.x, piece.y, 7, 0, TAU); ctx.stroke(); }
    ctx.restore();
  }

  function drawStriker() { const s = state.striker; if (!s || s.pocketed) return; ctx.save(); ctx.shadowColor = 'rgba(36,23,15,.52)'; ctx.shadowBlur = 13; ctx.shadowOffsetY = 7; const fill = ctx.createRadialGradient(s.x - 7, s.y - 9, 2, s.x, s.y, s.r); fill.addColorStop(0, '#fbf4e6'); fill.addColorStop(.4, '#d8ccb9'); fill.addColorStop(1, '#71645d'); ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, TAU); ctx.fill(); ctx.strokeStyle = '#e2a65b'; ctx.lineWidth = 4; ctx.stroke(); ctx.strokeStyle = '#554a4b'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y, 13, 0, TAU); ctx.stroke(); ctx.fillStyle = '#c76c43'; ctx.beginPath(); ctx.arc(s.x, s.y, 5, 0, TAU); ctx.fill(); ctx.restore(); }

  function drawAim() {
    if (!state.pointer || state.pointer.mode !== 'aim' || state.phase !== 'aiming' || !state.striker) return;
    const s = state.striker; const dir = state.pointer.dir || { x: 0, y: -1 }; const length = 300 + (state.pointer.power || 0) * 260;
    ctx.save(); ctx.setLineDash([12, 13]); ctx.strokeStyle = 'rgba(255,247,218,.72)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x + dir.x * length, s.y + dir.y * length); ctx.stroke(); ctx.setLineDash([]); ctx.strokeStyle = THEMES[state.theme].accent; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(s.x - dir.x * 28, s.y - dir.y * 28); ctx.lineTo(s.x + dir.x * 28, s.y + dir.y * 28); ctx.stroke(); ctx.fillStyle = THEMES[state.theme].accent; ctx.beginPath(); ctx.arc(s.x + dir.x * length, s.y + dir.y * length, 7, 0, TAU); ctx.fill(); ctx.restore();
  }

  function drawParticles() { state.particles.forEach(p => { ctx.save(); ctx.globalAlpha = Math.max(0, p.life); ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, 3 + p.life * 3, 0, TAU); ctx.fill(); ctx.restore(); }); state.floats.forEach(f => { ctx.save(); ctx.globalAlpha = Math.max(0, f.life); ctx.fillStyle = f.color; ctx.font = '700 18px DM Mono, monospace'; ctx.textAlign = 'center'; ctx.shadowColor = 'rgba(0,0,0,.4)'; ctx.shadowBlur = 4; ctx.fillText(f.text, f.x, f.y); ctx.restore(); }); }

  function draw() { if (state.view !== 'game') return; drawBoard(); state.coins.forEach(drawPiece); drawStriker(); drawAim(); drawParticles(); }
  function resizeCanvas() { const rect = canvas.getBoundingClientRect(); const ratio = Math.min(2, window.devicePixelRatio || 1); canvas.width = Math.max(1, Math.floor(rect.width * ratio)); canvas.height = Math.max(1, Math.floor(rect.height * ratio)); ctx.setTransform(canvas.width / W, 0, 0, canvas.height / W, 0, 0); draw(); }

  function loop(now) { const dt = Math.min(.034, (now - state.lastFrame) / 1000 || .016); state.lastFrame = now; updatePhysics(dt); if (state.phase === 'moving' || state.particles.length || state.floats.length) draw(); requestAnimationFrame(loop); }

  function bindEvents() {
    document.getElementById('play-ai').addEventListener('click', () => startMatch('ai'));
    document.getElementById('play-local').addEventListener('click', () => startMatch('local'));
    document.getElementById('open-settings').addEventListener('click', () => { playSound('click'); openModal(ui.settings); });
    document.getElementById('open-howto').addEventListener('click', () => { playSound('click'); openModal(ui.howto); });
    document.getElementById('menu-sound').addEventListener('click', toggleSound);
    document.getElementById('game-sound').addEventListener('click', toggleSound);
    document.getElementById('pause-game').addEventListener('click', () => { if (state.phase === 'moving' || state.phase === 'aiming' || state.phase === 'ai') { state.pausedPhase = state.phase; state.phase = 'paused'; openModal(ui.pause); updateHUD(); playSound('click'); } });
    document.getElementById('game-home').addEventListener('click', () => { stopMusic(); closeModal(); state.phase = 'menu'; showView('menu'); playSound('click'); });
    document.getElementById('resume-game').addEventListener('click', () => { state.phase = state.pausedPhase || 'aiming'; closeModal(); updateHUD(); playSound('click'); });
    document.getElementById('pause-restart').addEventListener('click', () => startMatch(state.mode));
    document.getElementById('pause-home').addEventListener('click', () => { stopMusic(); closeModal(); state.phase = 'menu'; showView('menu'); });
    document.getElementById('settings-restart').addEventListener('click', () => { if (state.view === 'game') startMatch(state.mode); else closeModal(); });
    document.getElementById('play-again').addEventListener('click', () => startMatch(state.mode));
    document.getElementById('result-home').addEventListener('click', () => { closeModal(); state.phase = 'menu'; showView('menu'); });
    document.querySelectorAll('[data-close-modal]').forEach(btn => btn.addEventListener('click', () => { closeModal(); playSound('click', .5); }));
    document.querySelectorAll('[data-theme-choice]').forEach(btn => btn.addEventListener('click', () => { setTheme(btn.dataset.themeChoice); playSound('click', .5); }));
    document.querySelectorAll('[data-difficulty]').forEach(btn => btn.addEventListener('click', () => { state.difficulty = btn.dataset.difficulty; localStorage.setItem('carrom-difficulty', state.difficulty); ui.modeLabel.textContent = state.mode === 'ai' ? `CPU • ${DIFFICULTY[state.difficulty].label}` : 'LOCAL • 2P'; document.querySelectorAll('[data-difficulty]').forEach(b => b.classList.toggle('selected', b.dataset.difficulty === state.difficulty)); playSound('click', .5); }));
    document.getElementById('sound-toggle').addEventListener('click', toggleSound);
    document.getElementById('music-toggle').addEventListener('click', () => { state.music = !state.music; localStorage.setItem('carrom-music', state.music ? 'on' : 'off'); if (state.music) startMusic(); else stopMusic(); updateSoundUI(); playSound('click', .4); });
    ui.slider.addEventListener('input', e => moveStriker(Number(e.target.value)));
    document.getElementById('move-left').addEventListener('click', () => moveStriker(Number(ui.slider.value) - 5));
    document.getElementById('move-right').addEventListener('click', () => moveStriker(Number(ui.slider.value) + 5));
    document.getElementById('nudge-center').addEventListener('click', () => moveStriker(50));
    ui.shoot.addEventListener('click', () => { if (state.phase !== 'aiming' || (state.mode === 'ai' && state.turn === 1)) return; const dir = state.turn === 0 ? { x: 0, y: -1 } : { x: 0, y: 1 }; fireShot(dir, .68); });
    canvas.addEventListener('pointerdown', handlePointerDown); canvas.addEventListener('pointermove', handlePointerMove); canvas.addEventListener('pointerup', handlePointerUp); canvas.addEventListener('pointercancel', handlePointerUp);
    window.addEventListener('resize', resizeCanvas);
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && !ui.modalLayer.classList.contains('hidden')) { closeModal(); return; } if (state.view !== 'game') return; if (event.key === 'ArrowLeft') moveStriker(Number(ui.slider.value) - 3); if (event.key === 'ArrowRight') moveStriker(Number(ui.slider.value) + 3); if (event.key === ' ' && state.phase === 'aiming') { event.preventDefault(); ui.shoot.click(); } if (event.key.toLowerCase() === 'p') document.getElementById('pause-game').click(); });
  }

  function toggleSound() { state.sound = !state.sound; localStorage.setItem('carrom-sound', state.sound ? 'on' : 'off'); updateSoundUI(); if (state.sound) playSound('click'); }

  setTheme(state.theme); updateSoundUI(); document.querySelectorAll('[data-difficulty]').forEach(btn => btn.classList.toggle('selected', btn.dataset.difficulty === state.difficulty)); bindEvents(); requestAnimationFrame(loop);
})();
