const API_KEY = "nc7NEgqqiUzKRQrpxT9EPPbKk30t1ckNW7L0xwtqhsGJy2679Bm6rS6D";

// رقم Binance Pay ID الخاص بك
const BINANCE_PAY_ID = "569640312"; 

// الحد الأدنى للدقة لتصبح الصورة مدفوعة (يمكنك تعديلها، مثلاً 3500 أو 4000 بكسل)
const HIGH_RES_LIMIT = 4000; 

const gallery = document.getElementById("gallery");
let unlockedPhotos = [];

async function fetchWallpapers(query = "") {
    if (!gallery) return;
    
    gallery.innerHTML = "<p style='grid-column: span 2; padding: 20px; color: #38bdf8; text-align: center;'>جاري تحميل الخلفيات...</p>";
    
    let url = "https://api.pexels.com/v1/curated?per_page=30";
    if (query && query !== 'all') {
        url = `https://api.pexels.com/v1/search?query=${query}&per_page=30`;
    }

    try {
        const response = await fetch(url, {
            headers: { Authorization: API_KEY }
        });
        
        if (!response.ok) throw new Error("API Error");
        
        const data = await response.json();
        displayImages(data.photos);
    } catch (error) {
        gallery.innerHTML = "<p style='grid-column: span 2; color: #ef4444; text-align: center; padding: 20px;'>تأكد من الاتصال بالإنترنت ومفتاح API.</p>";
    }
}

function displayImages(photos) {
    gallery.innerHTML = "";
    if (!photos || photos.length === 0) {
        gallery.innerHTML = "<p style='grid-column: span 2; text-align: center;'>لم يتم العثور على خلفيات.</p>";
        return;
    }

    photos.forEach((photo) => {
        const card = document.createElement("div");
        card.className = "card";

        // فحص دقة الصورة: هل أبعادها (العرض أو الارتفاع) تتجاوز الحد المحدد؟
        const isHighResolution = (photo.width >= HIGH_RES_LIMIT || photo.height >= HIGH_RES_LIMIT);
        const isUnlocked = unlockedPhotos.includes(photo.id);

        const img = document.createElement("img");
        img.src = photo.src.portrait;
        img.alt = photo.alt || "Wallpaper";

        const actionBtn = document.createElement("button");

        // إذا كانت فائقة الدقة وغير مفتوحة بعد -> تكون مدفوعة
        if (isHighResolution && !isUnlocked) {
            card.innerHTML = `<span class="premium-badge">👑 Ultra HD $1</span>`;
            actionBtn.className = "download-btn buy-btn";
            actionBtn.innerHTML = `🔒 شراء HD (${photo.width}x${photo.height})`;
            actionBtn.onclick = (e) => {
                e.stopPropagation();
                openBinanceModal(photo.id, photo.src.original, photo.width, photo.height);
            };
        } else {
            // صورة عادية الدقة -> تنزيل مجاني
            actionBtn.className = "download-btn";
            actionBtn.innerHTML = "⬇ تنزيل مجاني";
            actionBtn.onclick = (e) => {
                e.stopPropagation();
                window.open(photo.src.original, '_blank');
            };
        }

        card.appendChild(img);
        card.appendChild(actionBtn);
        gallery.appendChild(card);
    });
}

// نافذة الدفع عبر Binance
function openBinanceModal(photoId, photoUrl, width, height) {
    const modal = document.createElement("div");
    modal.className = "modal-overlay";
    modal.id = "payModal";
    modal.innerHTML = `
        <div class="modal-content">
            <h3 style="color: #f0b90b;">🟡 الدفع عبر Binance Pay</h3>
            <p>خلفية فائقة الدقة <strong>(${width} × ${height})</strong></p>
            <p style="margin-bottom: 12px;">السعر: <strong style="color:#f0b90b;">1.00 $ (USDT)</strong></p>
            
            <div style="background: #0f172a; padding: 12px; border-radius: 10px; margin-bottom: 15px; text-align: right;">
                <p style="font-size: 12px; color: #94a3b8; margin-bottom: 4px;">Binance Pay ID:</p>
                <code style="color: #f0b90b; font-size: 16px; font-weight: bold;">${BINANCE_PAY_ID}</code>
            </div>

            <div class="modal-buttons">
                <button class="pay-confirm-btn" style="background: #f0b90b; color: #000;" onclick="copyBinanceID()">📋 نسخ Pay ID</button>
                <button class="pay-confirm-btn" onclick="confirmPayment('${photoId}', '${photoUrl}')">✅ فتح الصورة بعد التحويل</button>
                <button class="close-modal-btn" onclick="closePaymentModal()">إلغاء</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

function copyBinanceID() {
    navigator.clipboard.writeText(BINANCE_PAY_ID);
    alert("تم نسخ Binance Pay ID بنجاح!");
}

function closePaymentModal() {
    const modal = document.getElementById("payModal");
    if (modal) modal.remove();
}

function confirmPayment(photoId, photoUrl) {
    unlockedPhotos.push(photoId);
    closePaymentModal();
    alert("تم تأكيد العملية وفتح القفل عن الصورة!");
    window.open(photoUrl, '_blank');
    fetchWallpapers();
}

function filterImages(category) {
    const buttons = document.querySelectorAll('.cat-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    
    if (window.event && window.event.target) {
        window.event.target.classList.add('active');
    }
    
    fetchWallpapers(category);
}

function handleSearch() {
    const searchInput = document.getElementById("searchInput");
    if (!searchInput) return;
    
    const query = searchInput.value.trim();
    if (query !== "") {
        const buttons = document.querySelectorAll('.cat-btn');
        buttons.forEach(btn => btn.classList.remove('active'));
        fetchWallpapers(query);
    }
}

fetchWallpapers();
