const DEFAULT_FACTOR = 4.3318;

let FACTOR =
  Number(localStorage.getItem("shayan_gold_factor")) ||
  DEFAULT_FACTOR;

let pdfGenerating = false;
let trades = [];

try {
  const savedTrades =
    localStorage.getItem("shayan_gold_trades");

  trades = savedTrades ? JSON.parse(savedTrades) : [];

  if (!Array.isArray(trades)) {
    trades = [];
  }
} catch (error) {
  trades = [];
}

let editingTradeId = null;


/* ================= DATE ================= */

function getPersianDate(date = new Date()) {
  return new Intl.DateTimeFormat(
    "fa-IR-u-ca-persian",
    {
      year: "numeric",
      month: "long",
      day: "numeric"
    }
  ).format(date);
}

function getDateKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");

  return `${y}-${m}-${d}`;
}

function getTime(date = new Date()) {
  return date.toLocaleTimeString(
    "fa-IR",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );
}


/* ================= NUMBERS ================= */

function normalizeNumber(value) {
  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return 0;
  }

  let text =
    String(value)
      .replace(/,/g, "")
      .replace(/\s/g, "");

  text = text.replace(
    /[۰-۹]/g,
    d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)
  );

  text = text.replace(
    /[٠-٩]/g,
    d => "٠١٢٣٤٥٦٧٨٩".indexOf(d)
  );

  return Number(text) || 0;
}

function formatNumber(number) {
  return Number(number || 0).toLocaleString(
    "en-US",
    {
      maximumFractionDigits: 3
    }
  );
}

function formatMoney(number) {
  return Number(number || 0).toLocaleString(
    "en-US",
    {
      maximumFractionDigits: 0
    }
  );
}

function formatInputNumber(value) {
  const number = normalizeNumber(value);

  if (!number) {
    return "";
  }

  return number.toLocaleString(
    "en-US",
    {
      maximumFractionDigits: 3
    }
  );
}


/* ================= STORAGE ================= */

function saveTrades() {
  localStorage.setItem(
    "shayan_gold_trades",
    JSON.stringify(trades)
  );
}


/* ================= LEDGER ================= */

function calculateLedger() {
  let position = 0;
  let averageCost = 0;
  let realizedProfit = 0;

  const sortedTrades =
    [...trades].sort(
      (a, b) =>
        new Date(a.createdAt).getTime() -
        new Date(b.createdAt).getTime()
    );

  for (const trade of sortedTrades) {
    const qty = Number(trade.weight) || 0;
    const price = Number(trade.price18) || 0;

    if (qty <= 0 || price <= 0) {
      continue;
    }

    if (trade.type === "buy") {
      if (position < 0) {
        const shortQty = Math.abs(position);

        const closeQty =
          Math.min(qty, shortQty);

        realizedProfit +=
          closeQty *
          (averageCost - price);

        position += closeQty;

        if (qty > closeQty) {
          const remaining =
            qty - closeQty;

          position = remaining;
          averageCost = price;
        } else if (position === 0) {
          averageCost = 0;
        }
      } else if (position > 0) {
        const oldQty = position;
        const newQty = oldQty + qty;

        averageCost =
          (
            oldQty * averageCost +
            qty * price
          ) / newQty;

        position = newQty;
      } else {
        position = qty;
        averageCost = price;
      }
    }

    else if (trade.type === "sell") {
      if (position > 0) {
        const closeQty =
          Math.min(position, qty);

        realizedProfit +=
          closeQty *
          (price - averageCost);

        position -= closeQty;

        if (qty > closeQty) {
          const remaining =
            qty - closeQty;

          position = -remaining;
          averageCost = price;
        } else if (position === 0) {
          averageCost = 0;
        }
      } else if (position < 0) {
        const oldShortQty =
          Math.abs(position);

        const newShortQty =
          oldShortQty + qty;

        averageCost =
          (
            oldShortQty * averageCost +
            qty * price
          ) / newShortQty;

        position = -newShortQty;
      } else {
        position = -qty;
        averageCost = price;
      }
    }
  }

  return {
    position,
    averageCost,
    realizedProfit
  };
}


/* ================= TRADE HTML ================= */

function createTradeHTML(trade) {
  return `
    <div class="trade-item">

      <div class="trade-main">

        <span>
          ${trade.type === "buy" ? "خرید" : "فروش"}
        </span>

        <span class="trade-type ${trade.type}">
          ${trade.type === "buy" ? "خرید" : "فروش"}
        </span>

      </div>

      <div class="trade-details">

        <span>
          وزن:
          ${formatNumber(trade.weight)}
          گرم
        </span>

        <span>
          فی:
          ${formatMoney(trade.price18)}
          تومان
        </span>

        <span>
          مظنه:
          ${formatMoney(trade.mazhane)}
          تومان
        </span>

        <span>
          کل:
          ${formatMoney(trade.totalPrice)}
          تومان
        </span>

        <span>
          ${trade.time || "-"}
        </span>

      </div>

    </div>
  `;
}


/* ================= HOME ================= */

function renderHome() {
  const today = getDateKey();

  const todayTrades =
    trades.filter(
      trade => trade.date === today
    );

  let bought = 0;
  let sold = 0;

  todayTrades.forEach(trade => {
    if (trade.type === "buy") {
      bought += Number(trade.weight) || 0;
    } else {
      sold += Number(trade.weight) || 0;
    }
  });

  const ledger = calculateLedger();

  const balance = Math.abs(ledger.position);
  const average = ledger.averageCost;
  const averageMazhane = average * FACTOR;

  const todayDate =
    document.getElementById("todayDate");

  if (todayDate) {
    todayDate.textContent = getPersianDate();
  }

  const homeTradeCount =
    document.getElementById("homeTradeCount");

  if (homeTradeCount) {
    homeTradeCount.textContent =
      formatNumber(todayTrades.length);
  }

  const homeBought =
    document.getElementById("homeBought");

  if (homeBought) {
    homeBought.textContent =
      `${formatNumber(bought)} گرم`;
  }

  const homeSold =
    document.getElementById("homeSold");

  if (homeSold) {
    homeSold.textContent =
      `${formatNumber(sold)} گرم`;
  }

  const homeBalance =
    document.getElementById("homeBalance");

  if (homeBalance) {
    homeBalance.textContent =
      `${formatNumber(balance)} گرم`;
  }

  const averageLabel =
    document.getElementById("homeAverageLabel");

  if (averageLabel) {
    if (ledger.position < 0) {
      averageLabel.textContent =
        "فی میانگین فروش باز";
    } else {
      averageLabel.textContent =
        "فی میانگین موجودی باقی‌مانده";
    }
  }

  const homeAveragePrice =
    document.getElementById("homeAveragePrice");

  if (homeAveragePrice) {
    homeAveragePrice.textContent =
      `${formatMoney(average)} تومان`;
  }

  const homeAverageMazhane =
    document.getElementById("homeAverageMazhane");

  if (homeAverageMazhane) {
    homeAverageMazhane.textContent =
      `مظنه میانگین: ${formatMoney(averageMazhane)} تومان`;
  }

  const profitElement =
    document.getElementById("homeRealizedProfit");

  if (profitElement) {
    profitElement.textContent =
      `${formatMoney(ledger.realizedProfit)} تومان`;

    profitElement.classList.remove(
      "closed-profit",
      "closed-loss"
    );

    if (ledger.realizedProfit > 0) {
      profitElement.classList.add(
        "closed-profit"
      );
    } else if (ledger.realizedProfit < 0) {
      profitElement.classList.add(
        "closed-loss"
      );
    }
  }

  renderTradeList(
    todayTrades,
    "homeTrades"
  );
}


/* ================= TODAY TRADES ================= */

function renderTodayTrades() {
  const today = getDateKey();

  const todayTrades =
    trades.filter(
      trade => trade.date === today
    );

  renderTradeList(
    todayTrades,
    "todayTrades"
  );
}


/* ================= GENERIC LIST ================= */

function renderTradeList(list, elementId) {
  const container =
    document.getElementById(elementId);

  if (!container) {
    return;
  }

  if (
    !Array.isArray(list) ||
    list.length === 0
  ) {
    container.innerHTML =
      `<div class="empty">
        معامله‌ای ثبت نشده است.
      </div>`;

    return;
  }

  const sorted =
    [...list].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() -
        new Date(a.createdAt).getTime()
    );

  container.innerHTML =
    sorted
      .map(trade => createTradeHTML(trade))
      .join("");
}


/* ================= HISTORY ================= */

function renderHistory(openDateKey = null) {
  const container =
    document.getElementById("historyList");

  if (!container) {
    return;
  }

  const openDates =
    new Set(
      Array.from(
        container.querySelectorAll(
          ".history-folder.open"
        )
      ).map(
        folder => folder.dataset.date
      )
    );

  if (openDateKey) {
    openDates.add(openDateKey);
  }

  if (
    !Array.isArray(trades) ||
    trades.length === 0
  ) {
    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;
  }

  const groups = {};

  trades.forEach(trade => {
    if (!trade) {
      return;
    }

    let dateKey = trade.date;

    if (!dateKey && trade.createdAt) {
      const createdDate =
        new Date(trade.createdAt);

      if (!isNaN(createdDate.getTime())) {
        dateKey =
          getDateKey(createdDate);
      }
    }

    if (!dateKey) {
      return;
    }

    if (!groups[dateKey]) {
      groups[dateKey] = [];
    }

    groups[dateKey].push(trade);
  });

  const dates =
    Object.keys(groups).sort(
      (a, b) => b.localeCompare(a)
    );

  if (dates.length === 0) {
    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;
  }

  container.innerHTML =
    dates
      .map(date => {
        const list =
          [...groups[date]].sort(
            (a, b) => {
              const timeA =
                a.createdAt
                  ? new Date(a.createdAt).getTime()
                  : 0;

              const timeB =
                b.createdAt
                  ? new Date(b.createdAt).getTime()
                  : 0;

              return timeB - timeA;
            }
          );

        let dateObject;

        if (
          list[0] &&
          list[0].createdAt
        ) {
          dateObject =
            new Date(list[0].createdAt);
        }

        if (
          !dateObject ||
          isNaN(dateObject.getTime())
        ) {
          dateObject =
            new Date(`${date}T00:00:00`);
        }

        const persianDate =
          getPersianDate(dateObject);

        const isOpen =
          openDates.has(date);

        return `
          <div
            class="history-folder ${isOpen ? "open" : ""}"
            data-date="${date}"
          >

            <div class="folder-header">

              <button
                type="button"
                class="folder-toggle"
                onclick="toggleFolder(this)"
              >

                <div class="folder-title">

                  <span class="folder-icon">
                    📁
                  </span>

                  <span>
                    ${persianDate}
                  </span>

                </div>

              </button>

              <div class="folder-header-actions">

                <span class="folder-count">
                  ${list.length} معامله
                </span>

                <button
                  type="button"
                  class="pdf-action"
                  onclick="event.stopPropagation(); generateDatePDF('${date}')"
                  title="گزارش PDF این تاریخ"
                >
                  PDF
                </button>

              </div>

            </div>

            <div class="folder-content">

              ${list
                .map(trade =>
                  createHistoryTradeHTML(trade)
                )
                .join("")}

            </div>

          </div>
        `;
      })
      .join("");
}


function createHistoryTradeHTML(trade) {
  return `
    <div class="history-trade">

      <div class="history-trade-top">

        <span class="trade-type ${trade.type}">
          ${trade.type === "buy" ? "خرید" : "فروش"}
        </span>

        <div class="history-actions">

          <button
            type="button"
            class="small-action"
            onclick="editTrade(${trade.id})"
            title="ویرایش"
          >
            ✎
          </button>

          <button
            type="button"
            class="small-action"
            onclick="deleteTrade(${trade.id})"
            title="حذف"
          >
            🗑
          </button>

        </div>

      </div>

      <div class="history-trade-info">

        <div>
          <span>وزن</span>
          <strong>
            ${formatNumber(trade.weight)}
            گرم
          </strong>
        </div>

        <div>
          <span>فی گرم ۱۸</span>
          <strong>
            ${formatMoney(trade.price18)}
          </strong>
        </div>

        <div>
          <span>مظنه</span>
          <strong>
            ${formatMoney(trade.mazhane)}
          </strong>
        </div>

        <div>
          <span>قیمت کل</span>
          <strong>
            ${formatMoney(trade.totalPrice)}
          </strong>
        </div>

      </div>

      <div class="history-time">
        ساعت معامله:
        ${trade.time || "-"}
      </div>

    </div>
  `;
}


function toggleFolder(button) {
  const folder =
    button.closest(".history-folder");

  if (folder) {
    folder.classList.toggle("open");
  }
}


/* =========================================================
   ================= PDF / PRINT ===========================
   ========================================================= */

function generateDatePDF(dateKey) {
  if (pdfGenerating) {
    return;
  }

  pdfGenerating = true;

  const dateTrades =
    trades
      .filter(
        trade =>
          trade &&
          (
            trade.date === dateKey ||
            (
              !trade.date &&
              trade.createdAt &&
              getDateKey(
                new Date(trade.createdAt)
              ) === dateKey
            )
          )
      )
      .sort(
        (a, b) => {
          const timeA =
            a.createdAt
              ? new Date(a.createdAt).getTime()
              : 0;

          const timeB =
            b.createdAt
              ? new Date(b.createdAt).getTime()
              : 0;

          return timeA - timeB;
        }
      );

  if (dateTrades.length === 0) {
    pdfGenerating = false;

    alert(
      "برای این تاریخ معامله‌ای پیدا نشد."
    );

    return;
  }

  const pdfButtons =
    document.querySelectorAll(
      `.history-folder[data-date="${dateKey}"] .pdf-action`
    );

  pdfButtons.forEach(button => {
    button.disabled = true;
    button.dataset.oldText =
      button.textContent;
    button.textContent =
      "آماده‌سازی...";
  });

  try {
    const firstDate =
      dateTrades[0].createdAt
        ? new Date(dateTrades[0].createdAt)
        : new Date(`${dateKey}T00:00:00`);

    const persianDate =
      getPersianDate(firstDate);

    const buyTrades =
      dateTrades.filter(
        trade => trade.type === "buy"
      );

    const sellTrades =
      dateTrades.filter(
        trade => trade.type === "sell"
      );

    let totalBoughtWeight = 0;
    let totalSoldWeight = 0;

    let totalBoughtMoney = 0;
    let totalSoldMoney = 0;

    buyTrades.forEach(trade => {
      totalBoughtWeight +=
        Number(trade.weight) || 0;

      totalBoughtMoney +=
        Number(trade.totalPrice) || 0;
    });

    sellTrades.forEach(trade => {
      totalSoldWeight +=
        Number(trade.weight) || 0;

      totalSoldMoney +=
        Number(trade.totalPrice) || 0;
    });


    /*
     * هر صفحه:
     * سمت چپ = فروش
     * سمت راست = خرید
     */

    const ROWS_PER_PAGE = 13;

    const buyPageCount =
      Math.ceil(
        buyTrades.length /
        ROWS_PER_PAGE
      );

    const sellPageCount =
      Math.ceil(
        sellTrades.length /
        ROWS_PER_PAGE
      );

    const pagesCount =
      Math.max(
        buyPageCount,
        sellPageCount
      );

    let pagesHTML = "";


    for (
      let pageIndex = 0;
      pageIndex < pagesCount;
      pageIndex++
    ) {
      const pageBuys =
        buyTrades.slice(
          pageIndex * ROWS_PER_PAGE,
          (pageIndex + 1) * ROWS_PER_PAGE
        );

      const pageSells =
        sellTrades.slice(
          pageIndex * ROWS_PER_PAGE,
          (pageIndex + 1) * ROWS_PER_PAGE
        );


      let buyHTML = "";

      pageBuys.forEach(
        (trade, index) => {
          const number =
            pageIndex *
              ROWS_PER_PAGE +
            index +
            1;

          buyHTML += `
            <div class="trade-card buy-trade">

              <div class="trade-card-number">
                خرید ${number}
              </div>

              <div class="trade-card-grid">

                <div>
                  <span>وزن</span>
                  <strong>
                    ${formatNumber(trade.weight)}
                    گرم
                  </strong>
                </div>

                <div>
                  <span>فی گرم ۱۸</span>
                  <strong>
                    ${formatMoney(trade.price18)}
                  </strong>
                </div>

                <div>
                  <span>مظنه</span>
                  <strong>
                    ${formatMoney(trade.mazhane)}
                  </strong>
                </div>

                <div>
                  <span>قیمت کل</span>
                  <strong>
                    ${formatMoney(trade.totalPrice)}
                  </strong>
                </div>

              </div>

              <div class="trade-card-time">
                ساعت معامله:
                ${trade.time || "-"}
              </div>

            </div>
          `;
        }
      );


      let sellHTML = "";

      pageSells.forEach(
        (trade, index) => {
          const number =
            pageIndex *
              ROWS_PER_PAGE +
            index +
            1;

          sellHTML += `
            <div class="trade-card sell-trade">

              <div class="trade-card-number">
                فروش ${number}
              </div>

              <div class="trade-card-grid">

                <div>
                  <span>وزن</span>
                  <strong>
                    ${formatNumber(trade.weight)}
                    گرم
                  </strong>
                </div>

                <div>
                  <span>فی گرم ۱۸</span>
                  <strong>
                    ${formatMoney(trade.price18)}
                  </strong>
                </div>

                <div>
                  <span>مظنه</span>
                  <strong>
                    ${formatMoney(trade.mazhane)}
                  </strong>
                </div>

                <div>
                  <span>قیمت کل</span>
                  <strong>
                    ${formatMoney(trade.totalPrice)}
                  </strong>
                </div>

              </div>

              <div class="trade-card-time">
                ساعت معامله:
                ${trade.time || "-"}
              </div>

            </div>
          `;
        }
      );


      const buyFinished =
        pageIndex ===
        buyPageCount - 1;

      const sellFinished =
        pageIndex ===
        sellPageCount - 1;


      if (
        buyFinished &&
        buyTrades.length > 0
      ) {
        buyHTML += `
          <div class="total-box buy-total">

            <div class="total-title">
              جمع کل خرید
            </div>

            <div class="total-row">
              <span>وزن کل</span>
              <strong>
                ${formatNumber(totalBoughtWeight)}
                گرم
              </strong>
            </div>

            <div class="total-row">
              <span>مبلغ کل</span>
              <strong>
                ${formatMoney(totalBoughtMoney)}
                تومان
              </strong>
            </div>

          </div>
        `;
      }


      if (
        sellFinished &&
        sellTrades.length > 0
      ) {
        sellHTML += `
          <div class="total-box sell-total">

            <div class="total-title">
              جمع کل فروش
            </div>

            <div class="total-row">
              <span>وزن کل</span>
              <strong>
                ${formatNumber(totalSoldWeight)}
                گرم
              </strong>
            </div>

            <div class="total-row">
              <span>مبلغ کل</span>
              <strong>
                ${formatMoney(totalSoldMoney)}
                تومان
              </strong>
            </div>

          </div>
        `;
      }


      if (
        buyTrades.length === 0
      ) {
        buyHTML = `
          <div class="empty-column">
            معامله خریدی ثبت نشده است.
          </div>
        `;
      }

      if (
        sellTrades.length === 0
      ) {
        sellHTML = `
          <div class="empty-column">
            معامله فروشی ثبت نشده است.
          </div>
        `;
      }


      pagesHTML += `
        <section class="print-page">

          <div class="report-header">

            <div class="report-title">
              ماشین حساب معاملاتی شایان
            </div>

            <div class="report-subtitle">
              گزارش معاملات روزانه
            </div>

            <div class="report-date">
              ${persianDate}
            </div>

          </div>


          <div class="summary">

            <div class="summary-card">

              <span>
                تعداد معاملات
              </span>

              <strong>
                ${dateTrades.length}
              </strong>

            </div>

            <div class="summary-card buy-card">

              <span>
                مجموع خرید
              </span>

              <strong>
                ${formatNumber(totalBoughtWeight)}
                گرم
              </strong>

            </div>

            <div class="summary-card sell-card">

              <span>
                مجموع فروش
              </span>

              <strong>
                ${formatNumber(totalSoldWeight)}
                گرم
              </strong>

            </div>

          </div>


          <div class="trade-columns">

            <div class="trade-column sell-column">

              <div class="column-title sell-title">
                فروش‌ها
              </div>

              ${sellHTML}

            </div>


            <div class="trade-column buy-column">

              <div class="column-title buy-title">
                خریدها
              </div>

              ${buyHTML}

            </div>

          </div>


          <div class="print-footer">

            <span>
              ماشین حساب معاملاتی شایان
            </span>

            <span>
              صفحه
              ${pageIndex + 1}
              از
              ${pagesCount}
            </span>

          </div>

        </section>
      `;
    }


    const reportHTML = `
      <!DOCTYPE html>

      <html
        lang="fa"
        dir="rtl"
      >

      <head>

        <meta charset="UTF-8">

        <meta
          name="viewport"
          content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
        >

        <title>
          گزارش معاملات - ${persianDate}
        </title>


        <style>

          * {
            box-sizing: border-box;
          }


          html {
            margin: 0;
            padding: 0;
            background: #eef2f6;
          }


          body {
            margin: 0;
            padding: 70px 10px 20px;
            background: #eef2f6;
            color: #172536;
            font-family:
              Tahoma,
              Arial,
              sans-serif;
            direction: rtl;
            font-size: 14px;
            overflow-x: hidden;
          }


          /* ================= TOOLBAR ================= */

          .print-controls {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            width: 100%;
            min-height: 58px;
            padding: 8px 10px;
            background: #ffffff;
            border-bottom:
              1px solid #dce3ea;
            box-shadow:
              0 2px 8px
              rgba(0,0,0,0.08);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            z-index: 99999;
          }


          .print-controls button {
            border: 0;
            border-radius: 9px;
            padding: 10px 15px;
            font-family:
              Tahoma,
              Arial,
              sans-serif;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            white-space: nowrap;
          }


          .print-button {
            background: #10243b;
            color: #ffffff;
          }


          .back-button {
            background: #e7edf2;
            color: #172536;
          }


          /* ================= A4 PAGE ================= */

          .print-page {
            width: 100%;
            max-width: 794px;
            min-height: 1123px;
            margin: 0 auto 15px;
            padding: 30px 30px 45px;
            background: #ffffff;
            box-shadow:
              0 2px 12px
              rgba(0,0,0,0.08);
            position: relative;
            overflow: hidden;
            page-break-after: always;
          }


          .print-page:last-child {
            page-break-after: auto;
          }


          /* ================= HEADER ================= */

          .report-header {
            background: #10243b;
            color: #ffffff;
            border-radius: 14px;
            padding: 18px 20px;
            margin-bottom: 14px;
            border-bottom:
              5px solid #d6ad43;
          }


          .report-title {
            font-size: 22px;
            line-height: 1.5;
            font-weight: 900;
            margin-bottom: 5px;
          }


          .report-subtitle {
            font-size: 12px;
            color: #c9d5e0;
            margin-bottom: 7px;
          }


          .report-date {
            font-size: 15px;
            line-height: 1.5;
            font-weight: 800;
            color: #f4c95d;
          }


          /* ================= SUMMARY ================= */

          .summary {
            display: grid;
            grid-template-columns:
              repeat(3, minmax(0, 1fr));
            gap: 8px;
            margin-bottom: 14px;
          }


          .summary-card {
            border:
              1px solid #dce3ea;
            border-radius: 9px;
            padding: 9px 6px;
            background: #f8fafc;
            text-align: center;
          }


          .summary-card span {
            display: block;
            font-size: 10px;
            line-height: 1.5;
            color: #718096;
            margin-bottom: 3px;
          }


          .summary-card strong {
            display: block;
            font-size: 13px;
            line-height: 1.5;
            color: #172536;
          }


          .summary-card.buy-card strong {
            color: #15915b;
          }


          .summary-card.sell-card strong {
            color: #d8465b;
          }


          /* ================= TWO COLUMNS ================= */

          .trade-columns {
            width: 100%;
            display: grid;
            grid-template-columns: 1fr 1fr;
            direction: ltr;
            border:
              1px solid #cfd8e1;
            border-radius: 10px;
            overflow: hidden;
            background: #ffffff;
          }


          .trade-column {
            direction: rtl;
            min-width: 0;
            padding: 10px;
          }


          .buy-column {
            border-left:
              1.5px solid #9aa8b5;
          }


          .sell-column {
            border-left: 0;
          }


          .column-title {
            text-align: center;
            font-size: 15px;
            font-weight: 900;
            padding: 8px;
            border-radius: 8px;
            margin-bottom: 8px;
          }


          .buy-title {
            background: #eaf8f1;
            color: #15915b;
            border:
              1px solid #bfe8d2;
          }


          .sell-title {
            background: #fff0f2;
            color: #d8465b;
            border:
              1px solid #f0c4ca;
          }


          /* ================= TRADE CARD ================= */

          .trade-card {
            border:
              1px solid #dce3ea;
            border-radius: 8px;
            margin-bottom: 7px;
            padding: 7px 8px;
            background: #ffffff;
            page-break-inside: avoid;
          }


          .buy-trade {
            border-right:
              4px solid #15915b;
          }


          .sell-trade {
            border-right:
              4px solid #d8465b;
          }


          .trade-card-number {
            font-size: 10px;
            font-weight: 900;
            margin-bottom: 5px;
          }


          .buy-trade .trade-card-number {
            color: #15915b;
          }


          .sell-trade .trade-card-number {
            color: #d8465b;
          }


          .trade-card-grid {
            display: grid;
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
            gap: 5px;
          }


          .trade-card-grid > div {
            background: #f7f9fb;
            border-radius: 5px;
            padding: 4px;
            text-align: center;
            min-width: 0;
          }


          .trade-card-grid span {
            display: block;
            color: #718096;
            font-size: 8px;
            margin-bottom: 2px;
          }


          .trade-card-grid strong {
            display: block;
            color: #172536;
            font-size: 9px;
            word-break: break-word;
          }


          .trade-card-time {
            margin-top: 5px;
            text-align: center;
            color: #718096;
            font-size: 8px;
          }


          /* ================= TOTAL ================= */

          .total-box {
            margin-top: 9px;
            padding: 9px;
            border-radius: 8px;
            page-break-inside: avoid;
          }


          .buy-total {
            background: #eaf8f1;
            border:
              1px solid #bfe8d2;
          }


          .sell-total {
            background: #fff0f2;
            border:
              1px solid #f0c4ca;
          }


          .total-title {
            text-align: center;
            font-size: 12px;
            font-weight: 900;
            margin-bottom: 6px;
          }


          .buy-total .total-title {
            color: #15915b;
          }


          .sell-total .total-title {
            color: #d8465b;
          }


          .total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 5px;
            font-size: 9px;
            padding: 2px 0;
          }


          .total-row span {
            color: #718096;
          }


          .total-row strong {
            color: #172536;
          }


          .empty-column {
            min-height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #8a98a8;
            font-size: 10px;
          }


          /* ================= FOOTER ================= */

          .print-footer {
            position: absolute;
            bottom: 20px;
            left: 30px;
            right: 30px;
            border-top:
              1px solid #dce3ea;
            padding-top: 7px;
            display: flex;
            justify-content: space-between;
            font-size: 8px;
            color: #718096;
          }


          /* ================= MOBILE ================= */

          @media screen and (max-width: 600px) {

            body {
              padding:
                68px
                6px
                15px;
            }


            .print-controls {
              min-height: 56px;
              padding: 7px 6px;
              gap: 6px;
            }


            .print-controls button {
              padding:
                9px
                11px;
              font-size: 12px;
            }


            .print-page {
              width: 100%;
              max-width: 100%;
              min-height: auto;
              padding:
                18px
                8px
                50px;
              margin-bottom: 10px;
              border-radius: 2px;
              box-shadow:
                0 1px 5px
                rgba(0,0,0,0.08);
            }


            .report-header {
              padding: 13px;
              border-radius: 9px;
              border-bottom-width: 4px;
              margin-bottom: 10px;
            }


            .report-title {
              font-size: 17px;
            }


            .report-subtitle {
              font-size: 10px;
            }


            .report-date {
              font-size: 12px;
            }


            .summary {
              gap: 4px;
              margin-bottom: 10px;
            }


            .summary-card {
              padding:
                7px 2px;
              border-radius: 6px;
            }


            .summary-card span {
              font-size: 8px;
              margin-bottom: 2px;
            }


            .summary-card strong {
              font-size: 10px;
            }


            .trade-columns {
              border-radius: 7px;
            }


            .trade-column {
              padding: 5px;
            }


            .column-title {
              font-size: 11px;
              padding: 6px 3px;
              border-radius: 6px;
              margin-bottom: 5px;
            }


            .trade-card {
              padding: 5px;
              margin-bottom: 5px;
              border-radius: 6px;
            }


            .buy-trade {
              border-right-width: 3px;
            }


            .sell-trade {
              border-right-width: 3px;
            }


            .trade-card-number {
              font-size: 8px;
              margin-bottom: 4px;
            }


            .trade-card-grid {
              gap: 3px;
            }


            .trade-card-grid > div {
              padding: 3px 2px;
              border-radius: 4px;
            }


            .trade-card-grid span {
              font-size: 6px;
            }


            .trade-card-grid strong {
              font-size: 7px;
            }


            .trade-card-time {
              font-size: 6px;
              margin-top: 4px;
            }


            .total-box {
              padding: 6px;
              border-radius: 6px;
            }


            .total-title {
              font-size: 9px;
              margin-bottom: 4px;
            }


            .total-row {
              font-size: 7px;
            }


            .empty-column {
              min-height: 100px;
              font-size: 7px;
            }


            .print-footer {
              bottom: 13px;
              left: 8px;
              right: 8px;
              font-size: 7px;
            }
          }


          /* ================= PRINT ================= */

          @page {
            size: A4 portrait;
            margin: 0;
          }


          @media print {

            html {
              background: #ffffff;
            }


            body {
              width: 210mm;
              margin: 0;
              padding: 0;
              background: #ffffff;
            }


            .print-controls {
              display: none !important;
            }


            .print-page {
              width: 210mm;
              height: 297mm;
              min-height: 297mm;
              max-width: none;
              margin: 0;
              padding:
                10mm
                10mm
                14mm;
              box-shadow: none;
              border-radius: 0;
              overflow: hidden;
              page-break-after: always;
            }


            .print-page:last-child {
              page-break-after: auto;
            }


            .report-header {
              border-radius: 4mm;
              padding: 5mm;
              margin-bottom: 3mm;
              border-bottom-width: 1.5mm;
            }


            .report-title {
              font-size: 21px;
            }


            .report-subtitle {
              font-size: 12px;
            }


            .report-date {
              font-size: 15px;
            }


            .summary {
              gap: 2.5mm;
              margin-bottom: 3mm;
            }


            .summary-card {
              border-radius: 2.5mm;
              padding: 2.5mm 1.5mm;
            }


            .summary-card span {
              font-size: 9px;
            }


            .summary-card strong {
              font-size: 12px;
            }


            .trade-columns {
              border-radius: 2.5mm;
              border-width: 0.3mm;
            }


            .trade-column {
              padding: 2.5mm;
            }


            .buy-column {
              border-left-width: 0.4mm;
            }


            .column-title {
              font-size: 12px;
              padding: 2mm;
              border-radius: 2mm;
              margin-bottom: 2mm;
            }


            .trade-card {
              border-radius: 1.8mm;
              margin-bottom: 1.5mm;
              padding: 1.7mm;
            }


            .buy-trade,
            .sell-trade {
              border-right-width: 1mm;
            }


            .trade-card-number {
              font-size: 8px;
              margin-bottom: 1.2mm;
            }


            .trade-card-grid {
              gap: 1.2mm;
            }


            .trade-card-grid > div {
              border-radius: 1mm;
              padding: 1.2mm;
            }


            .trade-card-grid span {
              font-size: 6.5px;
              margin-bottom: 0.5mm;
            }


            .trade-card-grid strong {
              font-size: 7.5px;
            }


            .trade-card-time {
              margin-top: 1mm;
              font-size: 6.5px;
            }


            .total-box {
              margin-top: 2mm;
              padding: 2mm;
              border-radius: 2mm;
            }


            .total-title {
              font-size: 9px;
              margin-bottom: 1mm;
            }


            .total-row {
              font-size: 7px;
              padding: 0.5mm 0;
            }


            .empty-column {
              min-height: 35mm;
              font-size: 8px;
            }


            .print-footer {
              bottom: 6mm;
              left: 10mm;
              right: 10mm;
              font-size: 7px;
            }
          }

        </style>

      </head>


      <body>

        <div class="print-controls">

          <button
            type="button"
            class="print-button"
            onclick="printReport()"
          >
            🖨 چاپ / ذخیره PDF
          </button>

          <button
            type="button"
            class="back-button"
            onclick="goBackFromReport()"
          >
            ← بازگشت
          </button>

        </div>


        ${pagesHTML}


        <script>

          function printReport() {
            try {
              window.print();
            } catch (error) {
              alert(
                "امکان باز کردن صفحه چاپ وجود ندارد."
              );
            }
          }


          function goBackFromReport() {
            try {
              if (window.history.length > 1) {
                window.history.back();
              } else {
                location.reload();
              }
            } catch (error) {
              location.reload();
            }
          }


          window.addEventListener(
            "load",
            function() {

              setTimeout(
                function() {

                  try {
                    window.print();
                  } catch (error) {
                    console.log(
                      "Auto print unavailable"
                    );
                  }

                },
                500
              );

            }
          );

        <\/script>

      </body>

      </html>
    `;


    const printWindow =
      window.open("", "_blank");


    if (!printWindow) {

      createPrintPageInSameWindow(
        pagesHTML,
        persianDate,
        totalBoughtWeight,
        totalSoldWeight,
        dateTrades.length,
        totalBoughtMoney,
        totalSoldMoney
      );

      return;
    }


    printWindow.document.open();

    printWindow.document.write(
      reportHTML
    );

    printWindow.document.close();

  }

  catch (error) {

    console.error(
      "PRINT PDF ERROR:",
      error
    );

    alert(
      "امکان باز کردن صفحه گزارش وجود ندارد."
    );

  }

  finally {

    pdfButtons.forEach(button => {

      button.disabled = false;

      button.textContent =
        button.dataset.oldText ||
        "PDF";

    });

    pdfGenerating = false;
  }
}


/* =========================================================
   FALLBACK PRINT PAGE
   ========================================================= */

function createPrintPageInSameWindow(
  pagesHTML,
  persianDate,
  totalBoughtWeight = 0,
  totalSoldWeight = 0,
  totalTradeCount = 0,
  totalBoughtMoney = 0,
  totalSoldMoney = 0
) {

  if (!pagesHTML) {

    const dateKey =
      getDateKey();

    const dateTrades =
      trades.filter(
        trade =>
          trade &&
          (
            trade.date === dateKey ||
            (
              !trade.date &&
              trade.createdAt &&
              getDateKey(
                new Date(trade.createdAt)
              ) === dateKey
            )
          )
      );


    if (dateTrades.length === 0) {

      alert(
        "برای این تاریخ معامله‌ای پیدا نشد."
      );

      return;
    }


    totalTradeCount =
      dateTrades.length;

    totalBoughtWeight = 0;
    totalSoldWeight = 0;
    totalBoughtMoney = 0;
    totalSoldMoney = 0;


    dateTrades.forEach(trade => {

      const weight =
        Number(trade.weight) || 0;

      const money =
        Number(trade.totalPrice) || 0;

      if (trade.type === "buy") {

        totalBoughtWeight += weight;
        totalBoughtMoney += money;

      } else {

        totalSoldWeight += weight;
        totalSoldMoney += money;

      }

    });


    const buyTrades =
      dateTrades.filter(
        trade => trade.type === "buy"
      );

    const sellTrades =
      dateTrades.filter(
        trade => trade.type === "sell"
      );


    const firstDate =
      dateTrades[0].createdAt
        ? new Date(dateTrades[0].createdAt)
        : new Date();

    persianDate =
      getPersianDate(firstDate);


    let buyHTML = "";
    let sellHTML = "";


    buyTrades.forEach(
      (trade, index) => {

        buyHTML += `
          <div class="trade-card buy-trade">

            <div class="trade-card-number">
              خرید ${index + 1}
            </div>

            <div class="trade-card-grid">

              <div>
                <span>وزن</span>
                <strong>
                  ${formatNumber(trade.weight)}
                  گرم
                </strong>
              </div>

              <div>
                <span>فی گرم ۱۸</span>
                <strong>
                  ${formatMoney(trade.price18)}
                </strong>
              </div>

              <div>
                <span>مظنه</span>
                <strong>
                  ${formatMoney(trade.mazhane)}
                </strong>
              </div>

              <div>
                <span>قیمت کل</span>
                <strong>
                  ${formatMoney(trade.totalPrice)}
                </strong>
              </div>

            </div>

            <div class="trade-card-time">
              ساعت معامله:
              ${trade.time || "-"}
            </div>

          </div>
        `;

      }
    );


    sellTrades.forEach(
      (trade, index) => {

        sellHTML += `
          <div class="trade-card sell-trade">

            <div class="trade-card-number">
              فروش ${index + 1}
            </div>

            <div class="trade-card-grid">

              <div>
                <span>وزن</span>
                <strong>
                  ${formatNumber(trade.weight)}
                  گرم
                </strong>
              </div>

              <div>
                <span>فی گرم ۱۸</span>
                <strong>
                  ${formatMoney(trade.price18)}
                </strong>
              </div>

              <div>
                <span>مظنه</span>
                <strong>
                  ${formatMoney(trade.mazhane)}
                </strong>
              </div>

              <div>
                <span>قیمت کل</span>
                <strong>
                  ${formatMoney(trade.totalPrice)}
                </strong>
              </div>

            </div>

            <div class="trade-card-time">
              ساعت معامله:
              ${trade.time || "-"}
            </div>

          </div>
        `;

      }
    );


    if (buyTrades.length === 0) {

      buyHTML = `
        <div class="empty-column">
          معامله خریدی ثبت نشده است.
        </div>
      `;

    } else {

      buyHTML += `
        <div class="total-box buy-total">

          <div class="total-title">
            جمع کل خرید
          </div>

          <div class="total-row">
            <span>وزن کل</span>
            <strong>
              ${formatNumber(totalBoughtWeight)}
              گرم
            </strong>
          </div>

          <div class="total-row">
            <span>مبلغ کل</span>
            <strong>
              ${formatMoney(totalBoughtMoney)}
              تومان
            </strong>
          </div>

        </div>
      `;

    }


    if (sellTrades.length === 0) {

      sellHTML = `
        <div class="empty-column">
          معامله فروشی ثبت نشده است.
        </div>
      `;

    } else {

      sellHTML += `
        <div class="total-box sell-total">

          <div class="total-title">
            جمع کل فروش
          </div>

          <div class="total-row">
            <span>وزن کل</span>
            <strong>
              ${formatNumber(totalSoldWeight)}
              گرم
            </strong>
          </div>

          <div class="total-row">
            <span>مبلغ کل</span>
            <strong>
              ${formatMoney(totalSoldMoney)}
              تومان
            </strong>
          </div>

        </div>
      `;

    }


    pagesHTML = `
      <section class="print-page">

        <div class="report-header">

          <div class="report-title">
            ماشین حساب معاملاتی شایان
          </div>

          <div class="report-subtitle">
            گزارش معاملات روزانه
          </div>

          <div class="report-date">
            ${persianDate}
          </div>

        </div>


        <div class="summary">

          <div class="summary-card">

            <span>
              تعداد معاملات
            </span>

            <strong>
              ${totalTradeCount}
            </strong>

          </div>

          <div class="summary-card buy-card">

            <span>
              مجموع خرید
            </span>

            <strong>
              ${formatNumber(totalBoughtWeight)}
              گرم
            </strong>

          </div>

          <div class="summary-card sell-card">

            <span>
              مجموع فروش
            </span>

            <strong>
              ${formatNumber(totalSoldWeight)}
              گرم
            </strong>

          </div>

        </div>


        <div class="trade-columns">

          <div class="trade-column sell-column">

            <div class="column-title sell-title">
              فروش‌ها
            </div>

            ${sellHTML}

          </div>


          <div class="trade-column buy-column">

            <div class="column-title buy-title">
              خریدها
            </div>

            ${buyHTML}

          </div>

        </div>


        <div class="print-footer">

          <span>
            ماشین حساب معاملاتی شایان
          </span>

          <span>
            گزارش معاملات
          </span>

        </div>

      </section>
    `;
  }


  document.body.innerHTML = `

    <style>

      * {
        box-sizing: border-box;
      }

      html {
        background: #eef2f6;
      }

      body {
        margin: 0;
        padding: 68px 6px 15px;
        direction: rtl;
        font-family:
          Tahoma,
          Arial,
          sans-serif;
        background: #eef2f6;
        color: #172536;
        overflow-x: hidden;
      }

      .print-controls {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        min-height: 56px;
        padding: 7px;
        background: white;
        border-bottom:
          1px solid #dce3ea;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 7px;
        z-index: 99999;
      }

      .print-controls button {
        border: 0;
        border-radius: 9px;
        padding: 9px 12px;
        font-family: Tahoma;
        font-size: 12px;
        font-weight: 700;
      }

      .print-button {
        background: #10243b;
        color: white;
      }

      .back-button {
        background: #e7edf2;
        color: #172536;
      }

      .print-page {
        width: 100%;
        max-width: 794px;
        min-height: 1123px;
        padding: 18px 8px 50px;
        margin: 0 auto 10px;
        background: white;
        position: relative;
        overflow: hidden;
      }

      .report-header {
        background: #10243b;
        color: white;
        padding: 13px;
        border-radius: 9px;
        border-bottom:
          4px solid #d6ad43;
        margin-bottom: 10px;
      }

      .report-title {
        font-size: 17px;
        font-weight: 900;
      }

      .report-subtitle {
        margin-top: 5px;
        font-size: 10px;
        color: #c9d5e0;
      }

      .report-date {
        margin-top: 7px;
        color: #f4c95d;
        font-size: 12px;
        font-weight: 800;
      }

      .summary {
        display: grid;
        grid-template-columns:
          repeat(3, 1fr);
        gap: 4px;
        margin-bottom: 10px;
      }

      .summary-card {
        border:
          1px solid #dce3ea;
        border-radius: 6px;
        padding: 7px 2px;
        background: #f8fafc;
        text-align: center;
      }

      .summary-card span {
        display: block;
        font-size: 8px;
        color: #718096;
        margin-bottom: 2px;
      }

      .summary-card strong {
        display: block;
        font-size: 10px;
      }

      .summary-card.buy-card strong {
        color: #15915b;
      }

      .summary-card.sell-card strong {
        color: #d8465b;
      }

      .trade-columns {
        width: 100%;
        display: grid;
        grid-template-columns: 1fr 1fr;
        direction: ltr;
        border:
          1px solid #cfd8e1;
        border-radius: 7px;
        overflow: hidden;
        background: white;
      }

      .trade-column {
        direction: rtl;
        min-width: 0;
        padding: 5px;
      }

      .buy-column {
        border-left:
          1.5px solid #9aa8b5;
      }

      .column-title {
        text-align: center;
        font-size: 11px;
        font-weight: 900;
        padding: 6px 3px;
        border-radius: 6px;
        margin-bottom: 5px;
      }

      .buy-title {
        background: #eaf8f1;
        color: #15915b;
        border:
          1px solid #bfe8d2;
      }

      .sell-title {
        background: #fff0f2;
        color: #d8465b;
        border:
          1px solid #f0c4ca;
      }

      .trade-card {
        border:
          1px solid #dce3ea;
        border-radius: 6px;
        margin-bottom: 5px;
        padding: 5px;
        background: white;
      }

      .buy-trade {
        border-right:
          3px solid #15915b;
      }

      .sell-trade {
        border-right:
          3px solid #d8465b;
      }

      .trade-card-number {
        font-size: 8px;
        font-weight: 900;
        margin-bottom: 4px;
      }

      .buy-trade .trade-card-number {
        color: #15915b;
      }

      .sell-trade .trade-card-number {
        color: #d8465b;
      }

      .trade-card-grid {
        display: grid;
        grid-template-columns:
          repeat(2, 1fr);
        gap: 3px;
      }

      .trade-card-grid > div {
        background: #f7f9fb;
        border-radius: 4px;
        padding: 3px 2px;
        text-align: center;
      }

      .trade-card-grid span {
        display: block;
        color: #718096;
        font-size: 6px;
      }

      .trade-card-grid strong {
        display: block;
        color: #172536;
        font-size: 7px;
      }

      .trade-card-time {
        margin-top: 4px;
        text-align: center;
        color: #718096;
        font-size: 6px;
      }

      .total-box {
        margin-top: 6px;
        padding: 6px;
        border-radius: 6px;
      }

      .buy-total {
        background: #eaf8f1;
        border:
          1px solid #bfe8d2;
      }

      .sell-total {
        background: #fff0f2;
        border:
          1px solid #f0c4ca;
      }

      .total-title {
        text-align: center;
        font-size: 9px;
        font-weight: 900;
        margin-bottom: 4px;
      }

      .buy-total .total-title {
        color: #15915b;
      }

      .sell-total .total-title {
        color: #d8465b;
      }

      .total-row {
        display: flex;
        justify-content: space-between;
        font-size: 7px;
        padding: 1px 0;
      }

      .total-row span {
        color: #718096;
      }

      .total-row strong {
        color: #172536;
      }

      .empty-column {
        min-height: 100px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        color: #8a98a8;
        font-size: 7px;
      }

      .print-footer {
        position: absolute;
        bottom: 13px;
        left: 8px;
        right: 8px;
        border-top:
          1px solid #dce3ea;
        padding-top: 7px;
        display: flex;
        justify-content: space-between;
        font-size: 7px;
        color: #718096;
      }

      @page {
        size: A4 portrait;
        margin: 0;
      }

      @media print {

        html,
        body {
          width: 210mm;
          background: white;
          margin: 0;
          padding: 0;
        }

        .print-controls {
          display: none !important;
        }

        .print-page {
          width: 210mm;
          height: 297mm;
          min-height: 297mm;
          max-width: none;
          margin: 0;
          padding: 10mm 10mm 14mm;
          box-shadow: none;
          page-break-after: always;
        }

        .print-page:last-child {
          page-break-after: auto;
        }
      }

    </style>


    <div class="print-controls">

      <button
        type="button"
        class="print-button"
        onclick="window.print()"
      >
        🖨 چاپ / ذخیره PDF
      </button>

      <button
        type="button"
        class="back-button"
        onclick="location.reload()"
      >
        ← بازگشت
      </button>

    </div>


    ${pagesHTML}

  `;


  setTimeout(
    function() {

      try {
        window.print();
      } catch (error) {
        console.log(
          "PRINT FALLBACK ERROR:",
          error
        );
      }

    },
    500
  );
}


/* ================= DEMO ================= */

function calculateDemo() {
  const current = calculateLedger();

  const currentPosition =
    current.position;

  const currentWeight =
    Math.abs(currentPosition);

  const currentAverage =
    current.averageCost;

  const currentStatus =
    document.getElementById(
      "demoCurrentStatus"
    );

  const currentWeightElement =
    document.getElementById(
      "demoCurrentWeight"
    );

  const currentAverageElement =
    document.getElementById(
      "demoCurrentAverage"
    );

  if (
    !currentStatus ||
    !currentWeightElement ||
    !currentAverageElement
  ) {
    return;
  }

  if (currentPosition > 0) {
    currentStatus.textContent =
      "موجودی خرید";
  } else if (currentPosition < 0) {
    currentStatus.textContent =
      "فروش باز";
  } else {
    currentStatus.textContent =
      "بدون موجودی";
  }

  currentWeightElement.textContent =
    `${formatNumber(currentWeight)} گرم`;

  currentAverageElement.textContent =
    `${formatMoney(currentAverage)} تومان`;

  const demoWeightElement =
    document.getElementById("demoWeight");

  const demoPriceElement =
    document.getElementById("demoPrice18");

  const demoTypeElement =
    document.getElementById("demoType");

  const resultAverage =
    document.getElementById(
      "demoResultAverage"
    );

  const resultMazhane =
    document.getElementById(
      "demoResultMazhane"
    );

  const resultMessage =
    document.getElementById(
      "demoResultMessage"
    );

  if (
    !demoWeightElement ||
    !demoPriceElement ||
    !demoTypeElement ||
    !resultAverage ||
    !resultMazhane ||
    !resultMessage
  ) {
    return;
  }

  const demoWeight =
    normalizeNumber(
      demoWeightElement.value
    );

  const demoPrice =
    normalizeNumber(
      demoPriceElement.value
    );

  const demoType =
    demoTypeElement.value;

  if (
    demoWeight <= 0 ||
    demoPrice <= 0
  ) {
    resultAverage.textContent =
      "0 تومان";

    resultMazhane.textContent =
      "مظنه میانگین: 0 تومان";

    resultMessage.textContent =
      "وزن و فی معامله فرضی را وارد کنید.";

    resultMessage.className =
      "demo-result-message";

    return;
  }

  let simulatedPosition =
    currentPosition;

  let simulatedAverage =
    currentAverage;

  let simulatedRealized = 0;


  if (demoType === "buy") {

    if (simulatedPosition < 0) {

      const shortQty =
        Math.abs(simulatedPosition);

      const closeQty =
        Math.min(
          demoWeight,
          shortQty
        );

      simulatedRealized =
        closeQty *
        (
          simulatedAverage -
          demoPrice
        );

      simulatedPosition +=
        closeQty;

      if (demoWeight > closeQty) {

        const remaining =
          demoWeight -
          closeQty;

        simulatedPosition =
          remaining;

        simulatedAverage =
          demoPrice;

      } else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;
      }

    }

    else if (
      simulatedPosition > 0
    ) {

      const oldQty =
        simulatedPosition;

      const newQty =
        oldQty +
        demoWeight;

      simulatedAverage =
        (
          oldQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newQty;

      simulatedPosition =
        newQty;

    }

    else {

      simulatedPosition =
        demoWeight;

      simulatedAverage =
        demoPrice;
    }

  }

  else {

    if (simulatedPosition > 0) {

      const closeQty =
        Math.min(
          simulatedPosition,
          demoWeight
        );

      simulatedRealized =
        closeQty *
        (
          demoPrice -
          simulatedAverage
        );

      simulatedPosition -=
        closeQty;

      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;

        simulatedPosition =
          -remaining;

        simulatedAverage =
          demoPrice;

      } else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;
      }

    }

    else if (
      simulatedPosition < 0
    ) {

      const oldShortQty =
        Math.abs(
          simulatedPosition
        );

      const newShortQty =
        oldShortQty +
        demoWeight;

      simulatedAverage =
        (
          oldShortQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newShortQty;

      simulatedPosition =
        -newShortQty;

    }

    else {

      simulatedPosition =
        -demoWeight;

      simulatedAverage =
        demoPrice;
    }
  }


  const simulatedMazhane =
    simulatedAverage *
    FACTOR;

  resultAverage.textContent =
    `${formatMoney(simulatedAverage)} تومان`;

  resultMazhane.textContent =
    `مظنه میانگین: ${formatMoney(simulatedMazhane)} تومان`;

  let statusText = "";

  if (simulatedPosition > 0) {

    statusText =
      `بعد از این خرید، موجودی شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else if (simulatedPosition < 0) {

    statusText =
      `بعد از این فروش، فروش باز شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else {

    statusText =
      "با این معامله موجودی باز شما صفر می‌شود.";
  }

  if (simulatedRealized !== 0) {

    statusText +=
      ` سود/زیان این سناریو: ${formatMoney(
        simulatedRealized
      )} تومان.`;
  }

  resultMessage.textContent =
    statusText;

  resultMessage.className =
    "demo-result-message success";
}


/* ================= DEMO INPUTS ================= */

const demoWeightInput =
  document.getElementById(
    "demoWeight"
  );

const demoPriceInput =
  document.getElementById(
    "demoPrice18"
  );

const demoTypeInput =
  document.getElementById(
    "demoType"
  );

if (demoWeightInput) {

  demoWeightInput.addEventListener(
    "input",
    function() {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );

      calculateDemo();
    }
  );
}

if (demoPriceInput) {

  demoPriceInput.addEventListener(
    "input",
    function() {

      this.value =
        formatInputNumber(
          this.value
        );

      calculateDemo();
    }
  );
}

if (demoTypeInput) {

  demoTypeInput.addEventListener(
    "change",
    calculateDemo
  );
}


/* ================= TRADE INPUTS ================= */

const weightInput =
  document.getElementById(
    "weight"
  );

const price18Input =
  document.getElementById(
    "price18"
  );

const mazhaneInput =
  document.getElementById(
    "mazhane"
  );

const totalPriceInput =
  document.getElementById(
    "totalPrice"
  );


function updateFromPrice18() {

  const price =
    normalizeNumber(
      price18Input.value
    );

  const weight =
    normalizeNumber(
      weightInput.value
    );

  if (price > 0) {

    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );
  }

  if (
    price > 0 &&
    weight > 0
  ) {

    totalPriceInput.value =
      formatInputNumber(
        price * weight
      );
  }
}


function updateFromMazhane() {

  const mazhane =
    normalizeNumber(
      mazhaneInput.value
    );

  const weight =
    normalizeNumber(
      weightInput.value
    );

  if (mazhane > 0) {

    const price =
      mazhane / FACTOR;

    price18Input.value =
      formatInputNumber(price);

    if (weight > 0) {

      totalPriceInput.value =
        formatInputNumber(
          price * weight
        );
    }
  }
}


function updateFromTotal() {

  const total =
    normalizeNumber(
      totalPriceInput.value
    );

  const weight =
    normalizeNumber(
      weightInput.value
    );

  if (
    total > 0 &&
    weight > 0
  ) {

    const price =
      total / weight;

    price18Input.value =
      formatInputNumber(price);

    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );
  }
}


if (
  weightInput &&
  price18Input &&
  mazhaneInput &&
  totalPriceInput
) {

  weightInput.addEventListener(
    "input",
    function() {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );

      const weight =
        normalizeNumber(
          this.value
        );

      const price =
        normalizeNumber(
          price18Input.value
        );

      if (
        weight > 0 &&
        price > 0
      ) {

        totalPriceInput.value =
          formatInputNumber(
            weight * price
          );
      }
    }
  );


  price18Input.addEventListener(
    "input",
    function() {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromPrice18();
    }
  );


  mazhaneInput.addEventListener(
    "input",
    function() {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromMazhane();
    }
  );


  totalPriceInput.addEventListener(
    "input",
    function() {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromTotal();
    }
  );
}


/* ================= SAVE TRADE ================= */

const saveTradeButton =
  document.getElementById(
    "saveTrade"
  );

if (saveTradeButton) {

  saveTradeButton.addEventListener(
    "click",
    function() {

      const type =
        document.getElementById(
          "tradeType"
        ).value;

      const weight =
        normalizeNumber(
          weightInput.value
        );

      const price18 =
        normalizeNumber(
          price18Input.value
        );

      const mazhane =
        normalizeNumber(
          mazhaneInput.value
        );

      const totalPrice =
        normalizeNumber(
          totalPriceInput.value
        );

      if (weight <= 0) {

        alert(
          "وزن معامله را وارد کنید."
        );

        return;
      }

      if (price18 <= 0) {

        alert(
          "فی گرم ۱۸ را وارد کنید."
        );

        return;
      }

      if (totalPrice <= 0) {

        alert(
          "قیمت کل معامله را وارد کنید."
        );

        return;
      }

      const finalMazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;

      const now =
        new Date();

      const trade = {

        id:
          Date.now() +
          Math.floor(
            Math.random() * 1000
          ),

        type,

        weight,

        price18,

        mazhane:
          finalMazhane,

        totalPrice,

        date:
          getDateKey(now),

        time:
          getTime(now),

        createdAt:
          now.toISOString()
      };

      trades.push(trade);

      saveTrades();

      weightInput.value = "";
      price18Input.value = "";
      mazhaneInput.value = "";
      totalPriceInput.value = "";

      renderAll();
      renderTodayTrades();
      renderHistory();

      showPage("trades");
    }
  );
}


/* ================= EDIT ================= */

function editTrade(id) {

  const trade =
    trades.find(
      item =>
        Number(item.id) ===
        Number(id)
    );

  if (!trade) {
    return;
  }

  editingTradeId = id;

  const editType =
    document.getElementById(
      "editType"
    );

  const editWeight =
    document.getElementById(
      "editWeight"
    );

  const editPrice18 =
    document.getElementById(
      "editPrice18"
    );

  const editMazhane =
    document.getElementById(
      "editMazhane"
    );

  const editTotalPrice =
    document.getElementById(
      "editTotalPrice"
    );

  if (
    !editType ||
    !editWeight ||
    !editPrice18 ||
    !editMazhane ||
    !editTotalPrice
  ) {
    return;
  }

  editType.value =
    trade.type;

  editWeight.value =
    formatInputNumber(
      trade.weight
    );

  editPrice18.value =
    formatInputNumber(
      trade.price18
    );

  editMazhane.value =
    formatInputNumber(
      trade.mazhane
    );

  editTotalPrice.value =
    formatInputNumber(
      trade.totalPrice
    );

  document.getElementById(
    "editModal"
  ).classList.add("show");
}


const closeModalButton =
  document.getElementById(
    "closeModal"
  );

if (closeModalButton) {

  closeModalButton.addEventListener(
    "click",
    function() {

      document.getElementById(
        "editModal"
      ).classList.remove("show");

    }
  );
}


const updateTradeButton =
  document.getElementById(
    "updateTrade"
  );

if (updateTradeButton) {

  updateTradeButton.addEventListener(
    "click",
    function() {

      const trade =
        trades.find(
          item =>
            Number(item.id) ===
            Number(editingTradeId)
        );

      if (!trade) {
        return;
      }

      const weight =
        normalizeNumber(
          document.getElementById(
            "editWeight"
          ).value
        );

      const price18 =
        normalizeNumber(
          document.getElementById(
            "editPrice18"
          ).value
        );

      const mazhane =
        normalizeNumber(
          document.getElementById(
            "editMazhane"
          ).value
        );

      const totalPrice =
        normalizeNumber(
          document.getElementById(
            "editTotalPrice"
          ).value
        );

      if (
        weight <= 0 ||
        price18 <= 0 ||
        totalPrice <= 0
      ) {

        alert(
          "اطلاعات معامله کامل نیست."
        );

        return;
      }

      trade.type =
        document.getElementById(
          "editType"
        ).value;

      trade.weight =
        weight;

      trade.price18 =
        price18;

      trade.mazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;

      trade.totalPrice =
        totalPrice;

      saveTrades();

      document.getElementById(
        "editModal"
      ).classList.remove("show");

      renderAll();
      renderTodayTrades();
      renderHistory();
    }
  );
}


/* ================= DELETE ================= */

function deleteTrade(id) {

  const tradeToDelete =
    trades.find(
      trade =>
        Number(trade.id) ===
        Number(id)
    );

  if (!tradeToDelete) {
    return;
  }

  const ok =
    confirm(
      "آیا از حذف این معامله مطمئن هستید؟"
    );

  if (!ok) {
    return;
  }

  let deletedTradeDate =
    tradeToDelete.date;

  if (
    !deletedTradeDate &&
    tradeToDelete.createdAt
  ) {

    const createdDate =
      new Date(
        tradeToDelete.createdAt
      );

    if (
      !isNaN(
        createdDate.getTime()
      )
    ) {

      deletedTradeDate =
        getDateKey(
          createdDate
        );
    }
  }

  trades =
    trades.filter(
      trade =>
        Number(trade.id) !==
        Number(id)
    );

  saveTrades();

  renderHome();
  renderTodayTrades();
  calculateDemo();

  const sameDateStillExists =
    deletedTradeDate &&
    trades.some(trade => {

      let tradeDate =
        trade.date;

      if (
        !tradeDate &&
        trade.createdAt
      ) {

        const d =
          new Date(
            trade.createdAt
          );

        if (
          !isNaN(
            d.getTime()
          )
        ) {

          tradeDate =
            getDateKey(d);
        }
      }

      return (
        tradeDate ===
        deletedTradeDate
      );
    });

  if (sameDateStillExists) {

    renderHistory(
      deletedTradeDate
    );

  } else {

    renderHistory();
  }
}


/* ================= SETTINGS ================= */

const factorInput =
  document.getElementById(
    "factorInput"
  );

if (factorInput) {

  factorInput.value =
    FACTOR;
}


const saveFactorButton =
  document.getElementById(
    "saveFactor"
  );

if (saveFactorButton) {

  saveFactorButton.addEventListener(
    "click",
    function() {

      const value =
        Number(
          factorInput.value
        );

      if (
        !value ||
        value <= 0
      ) {

        alert(
          "ضریب واردشده معتبر نیست."
        );

        return;
      }

      FACTOR =
        value;

      localStorage.setItem(
        "shayan_gold_factor",
        String(FACTOR)
      );

      renderAll();
      calculateDemo();

      alert(
        "ضریب با موفقیت ذخیره شد."
      );
    }
  );
}


/* ================= NAVIGATION ================= */

function showPage(pageId) {

  document
    .querySelectorAll(".page")
    .forEach(
      page =>
        page.classList.remove(
          "active"
        )
    );

  document
    .querySelectorAll(".nav-btn")
    .forEach(
      button =>
        button.classList.remove(
          "active"
        )
    );

  const page =
    document.getElementById(
      pageId
    );

  const navButton =
    document.querySelector(
      `.nav-btn[data-page="${pageId}"]`
    );

  if (page) {

    page.classList.add(
      "active"
    );
  }

  if (navButton) {

    navButton.classList.add(
      "active"
    );
  }

  if (pageId === "trades") {
    renderTodayTrades();
  }

  if (pageId === "history") {
    renderHistory();
  }

  if (pageId === "demo") {
    calculateDemo();
  }
}


document
  .querySelectorAll(".nav-btn")
  .forEach(
    button => {

      button.addEventListener(
        "click",
        function() {

          showPage(
            this.dataset.page
          );

        }
      );

    }
  );


/* ================= RENDER ALL ================= */

function renderAll() {

  renderHome();

  renderTodayTrades();

  renderHistory();

  calculateDemo();

}


renderAll();

showPage("home");

