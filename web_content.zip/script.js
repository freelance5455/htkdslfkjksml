let audioCtx = null;
let soundEnabled = localStorage.getItem('soundEnabled') !== 'false';

function getAudioCtx() {
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e) { return null; }
  }
  if (audioCtx.state === 'suspended') audioCtx.resume();
  return audioCtx;
}
function playTone(freq, duration, type, volume) {
  if (!soundEnabled) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(volume || 0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + duration);
  } catch(e) {}
}
function soundTap() { playTone(800, 0.05, 'sine', 0.05); }
function soundClick() { playTone(1200, 0.04, 'square', 0.03); }
function soundWin() {
  if (!soundEnabled) return;
  setTimeout(function() { playTone(523, 0.15, 'sine', 0.1); }, 0);
  setTimeout(function() { playTone(659, 0.15, 'sine', 0.1); }, 150);
  setTimeout(function() { playTone(784, 0.15, 'sine', 0.1); }, 300);
  setTimeout(function() { playTone(1047, 0.3, 'sine', 0.12); }, 450);
}
function soundUnlock() {
  setTimeout(function() { playTone(600, 0.08, 'sine', 0.08); }, 0);
  setTimeout(function() { playTone(900, 0.12, 'sine', 0.08); }, 80);
}
function soundWrong() {
  setTimeout(function() { playTone(300, 0.15, 'square', 0.08); }, 0);
  setTimeout(function() { playTone(200, 0.25, 'square', 0.08); }, 150);
}
function soundLockClick() { playTone(1500, 0.03, 'square', 0.04); }

const IMAGES = {
  iphone11to15_back: 'https://i.postimg.cc/TPfnNp6C/IMG-20260915-081707-934.png',
  iphone16_back:     'https://i.postimg.cc/jjty3LbM/IMG-20260915-081735-182.png',
  iphone17_back:     'https://i.postimg.cc/pLDDBKwN/IMG-20260915-081752-665.png',
  iphone17e_back:    'https://i.postimg.cc/pLDDBKwN/IMG-20260915-081813-363.png',
  iphone16e_back:    'https://i.postimg.cc/K8nn5tdp/IMG-20260915-081840-608.png',
  iphoneX_back:      'https://i.postimg.cc/52wwm8ZD/IMG-20260915-081908-470.png',
  iphoneXR_back:     'https://i.postimg.cc/L8zzVjrC/IMG-20260915-081930-228.png',
  iphone7_back:      'https://i.postimg.cc/52wwm8Zg/IMG-20260915-082012-727.png',
  android_back:      'https://i.postimg.cc/QdF0p6Db/IMG-20260915-122805-845.png'
};

const wheel = document.getElementById('wheel');
const spinBtn = document.getElementById('spinBtn');
const spinCounter = document.getElementById('spinCounter');
const loading = document.getElementById('loading');
const loadingText = document.getElementById('loadingText');
const result = document.getElementById('result');
const prizeName = document.getElementById('prizeName');
const miniPhone = document.getElementById('miniPhone');
const phoneViewer = document.getElementById('phoneViewer');
const phoneStage = document.getElementById('phoneStage');
const flipCard = document.getElementById('flipCard');
const rotateBtn = document.getElementById('rotateBtn');
const closeBtn = document.getElementById('closeBtn');
const saveBtn = document.getElementById('saveBtn');
const androidBrand = document.getElementById('androidBrand');
const iphoneIcons = document.getElementById('iphoneIcons');
const androidIcons = document.getElementById('androidIcons');
const appScreen = document.getElementById('appScreen');
const appBackBtn = document.getElementById('appBackBtn');
const appScreenContent = document.getElementById('appScreenContent');
const ipBatteryEl = document.getElementById('ipBattery');
const anBatteryEl = document.getElementById('anBattery');
const setupScreen = document.getElementById('setupScreen');
const nameInput = document.getElementById('nameInput');
const saveNameBtn = document.getElementById('saveNameBtn');
const iphoneBackImg = document.getElementById('iphoneBackImg');
const androidBackImg = document.getElementById('androidBackImg');
const myPhonesBtn = document.getElementById('myPhonesBtn');
const myPhonesScreen = document.getElementById('myPhonesScreen');
const myPhonesBackBtn = document.getElementById('myPhonesBackBtn');
const myPhonesList = document.getElementById('myPhonesList');

const iPhones = ['iPhone 7','iPhone X','iPhone XR','iPhone 11','iPhone 12','iPhone 13 Pro Max','iPhone 14','iPhone 15 Pro','iPhone 16','iPhone 16e','iPhone 17e','iPhone 17 Pro Max'];
const androids = ['Samsung Galaxy S26 Ultra','Samsung Galaxy S25','Samsung Galaxy S24','Google Pixel 9 Pro','Google Pixel 8','OnePlus 12','Xiaomi 14 Ultra','Nothing Phone 2','Infinix Zero 30','Infinix Note 40 Pro','Tecno Camon 30','Tecno Spark 20 Pro','itel P55','itel A70'];

const iosApps = [
  { label: 'Phone', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { label: 'Messages', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { label: 'Safari', color: 'linear-gradient(135deg,#3ddc84,#0088cc)' },
  { label: 'Camera', color: 'linear-gradient(135deg,#a0a0a0,#404040)' },
  { label: 'Music', color: 'linear-gradient(135deg,#ff006e,#cc0066)' },
  { label: 'Notes', color: 'linear-gradient(135deg,#ffcc00,#ff8800)' },
  { label: 'Calculator', color: 'linear-gradient(135deg,#a855f7,#6600ff)' },
  { label: 'Photos', color: 'linear-gradient(135deg,#ff6699,#cc0066)' },
  { label: 'App Store', color: 'linear-gradient(135deg,#1a88ff,#0066ff)' },
  { label: 'Settings', color: 'linear-gradient(135deg,#555,#222)' }
];

const androidApps = [
  { label: 'Phone', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { label: 'Messages', color: 'linear-gradient(135deg,#00e5ff,#0088ff)' },
  { label: 'Chrome', color: 'linear-gradient(135deg,#ffcc00,#ff6600)' },
  { label: 'Camera', color: 'linear-gradient(135deg,#a0a0a0,#404040)' },
  { label: 'Music', color: 'linear-gradient(135deg,#ff006e,#cc0066)' },
  { label: 'Notes', color: 'linear-gradient(135deg,#ffcc00,#ff8800)' },
  { label: 'Calculator', color: 'linear-gradient(135deg,#a855f7,#6600ff)' },
  { label: 'Gallery', color: 'linear-gradient(135deg,#ff6699,#cc0066)' },
  { label: 'Play Store', color: 'linear-gradient(135deg,#00e5ff,#0088ff)' },
  { label: 'Settings', color: 'linear-gradient(135deg,#555,#222)' }
];

let currentRotation = 0;
let spinning = false;
let currentBrand = 'iphone';
let currentModel = '';
let currentPhoneNumber = '';
let userName = '';
let battery = 87;
let settingsState = { wifi: true, bluetooth: true, mobileData: true, notifications: true, sounds: true };
let iphonePage = 0;
let androidPage = 0;
let pwInput = '';

function getInstalledApps() {
  try { return JSON.parse(localStorage.getItem('installedApps') || '[]'); }
  catch(e) { return []; }
}
function setInstalledApps(arr) {
  localStorage.setItem('installedApps', JSON.stringify(arr));
  refreshPage2();
}
function isAppInstalled(name) { return getInstalledApps().indexOf(name) !== -1; }
function installApp(name) {
  const installed = getInstalledApps();
  if (installed.indexOf(name) !== -1) return;
  installed.push(name);
  setInstalledApps(installed);
}

const STORE_APPS = {
  'Instagram': 'linear-gradient(135deg,#ff006e,#a855f7)',
  'WhatsApp':  'linear-gradient(135deg,#3ddc84,#00aa66)',
  'TikTok':    'linear-gradient(135deg,#ff006e,#00e5ff)',
  'YouTube':   'linear-gradient(135deg,#ff0000,#cc0000)',
  'Spotify':   'linear-gradient(135deg,#3ddc84,#00aa66)',
  'Netflix':   'linear-gradient(135deg,#cc0000,#880000)',
  'Snapchat':  'linear-gradient(135deg,#ffcc00,#ff8800)',
  'Twitter':   'linear-gradient(135deg,#00e5ff,#0088ff)',
  'Facebook':  'linear-gradient(135deg,#1a88ff,#0066ff)',
  'Telegram':  'linear-gradient(135deg,#00e5ff,#0088ff)'
};

function refreshPage2() {
  const installed = getInstalledApps();
  const build = function(container) {
    container.innerHTML = '';
    installed.forEach(function(name) {
      const color = STORE_APPS[name] || 'linear-gradient(135deg,#555,#222)';
      const el = document.createElement('div');
      el.className = 'app';
      el.textContent = name.charAt(0);
      el.setAttribute('data-label', name);
      el.style.background = color;
      el.style.color = '#fff';
      el.style.fontWeight = '900';
      el.addEventListener('click', function() { soundTap(); openApp(name); });
      container.appendChild(el);
    });
  };
  const ip2 = document.getElementById('iphoneIcons2');
  const an2 = document.getElementById('androidIcons2');
  if (ip2) build(ip2);
  if (an2) build(an2);
}

function switchPage(brand, dir) {
  const installedCount = getInstalledApps().length;
  if (brand === 'iphone') {
    const maxPage = installedCount > 0 ? 1 : 0;
    iphonePage = Math.max(0, Math.min(maxPage, iphonePage + dir));
    document.getElementById('iphoneIcons').classList.toggle('hidden', iphonePage !== 0);
    document.getElementById('iphoneIcons2').classList.toggle('hidden', iphonePage !== 1);
    document.querySelectorAll('#ipDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === iphonePage); });
  } else {
    const maxPage = installedCount > 0 ? 1 : 0;
    androidPage = Math.max(0, Math.min(maxPage, androidPage + dir));
    document.getElementById('androidIcons').classList.toggle('hidden', androidPage !== 0);
    document.getElementById('androidIcons2').classList.toggle('hidden', androidPage !== 1);
    document.querySelectorAll('#anDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === androidPage); });
  }
}

const DAILY_SPINS = 3;
function getTodayKey() {
  const d = new Date();
  return 'spins_' + d.getFullYear() + '-' + (d.getMonth()+1) + '-' + d.getDate();
}
function getSpinsToday() {
  const raw = localStorage.getItem(getTodayKey());
  return raw === null ? 0 : (parseInt(raw, 10) || 0);
}
function recordSpin() {
  localStorage.setItem(getTodayKey(), String(getSpinsToday() + 1));
  updateSpinCounter();
}
function spinsRemaining() { return Math.max(0, DAILY_SPINS - getSpinsToday()); }
function updateSpinCounter() {
  const remaining = spinsRemaining();
  spinCounter.textContent = 'Spins left today: ' + remaining;
  spinCounter.classList.remove('warning', 'empty');
  if (remaining === 0) {
    spinCounter.classList.add('empty');
    spinBtn.disabled = true;
    spinBtn.textContent = 'COME BACK TOMORROW';
  } else {
    if (remaining === 1) spinCounter.classList.add('warning');
    spinBtn.disabled = false;
    spinBtn.textContent = 'SPIN';
  }
}
setInterval(updateSpinCounter, 30000);

function getSavedPhones() {
  try { return JSON.parse(localStorage.getItem('savedPhones') || '[]'); }
  catch(e) { return []; }
}
function savePhoneToCollection(model, brand, number) {
  const saved = getSavedPhones();
  if (!saved.some(function(p) { return p.model === model; })) {
    saved.push({ model: model, brand: brand, number: number, savedAt: Date.now() });
    localStorage.setItem('savedPhones', JSON.stringify(saved));
  }
  refreshSaveButton();
}
function removePhoneFromCollection(model) {
  const saved = getSavedPhones().filter(function(p) { return p.model !== model; });
  localStorage.setItem('savedPhones', JSON.stringify(saved));
  refreshSaveButton();
}
function isPhoneSaved(model) {
  return getSavedPhones().some(function(p) { return p.model === model; });
}
function refreshSaveButton() {
  if (!currentModel) return;
  if (isPhoneSaved(currentModel)) {
    saveBtn.textContent = '*';
    saveBtn.classList.add('saved');
  } else {
    saveBtn.textContent = 'o';
    saveBtn.classList.remove('saved');
  }
}
saveBtn.addEventListener('click', function() {
  if (!currentModel) return;
  soundClick();
  if (isPhoneSaved(currentModel)) removePhoneFromCollection(currentModel);
  else savePhoneToCollection(currentModel, currentBrand, currentPhoneNumber);
});

function generatePhoneNumber() {
  const areaCodes = ['212','310','415','305','404','617','702','713','206','312','646','718'];
  const area = areaCodes[Math.floor(Math.random() * areaCodes.length)];
  const prefix = String(Math.floor(Math.random() * 900) + 100);
  const line = String(Math.floor(Math.random() * 9000) + 1000);
  return '+1 (' + area + ') ' + prefix + '-' + line;
}

function buildIcons(container, apps) {
  container.innerHTML = '';
  apps.forEach(function(app) {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = app.label.charAt(0);
    el.setAttribute('data-label', app.label);
    el.style.background = app.color;
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() { soundTap(); openApp(app.label); });
    container.appendChild(el);
  });
}
buildIcons(iphoneIcons, iosApps);
buildIcons(androidIcons, androidApps);

window.addEventListener('load', function() {
  const saved = localStorage.getItem('userName');
  if (saved) userName = saved;
  else setupScreen.classList.remove('hidden');
  updateSpinCounter();
  refreshPage2();
  soundEnabled = localStorage.getItem('soundEnabled') !== 'false';
  settingsState.sounds = soundEnabled;
});
saveNameBtn.addEventListener('click', function() {
  const val = nameInput.value.trim();
  if (!val) { nameInput.focus(); return; }
  userName = val;
  localStorage.setItem('userName', val);
  setupScreen.classList.add('hidden');
  soundClick();
});
nameInput.addEventListener('keydown', function(e) {
  if (e.key === 'Enter') saveNameBtn.click();
});

function getIphoneBackImage(model) {
  if (model === 'iPhone 7') return IMAGES.iphone7_back;
  if (model === 'iPhone X') return IMAGES.iphoneX_back;
  if (model === 'iPhone XR') return IMAGES.iphoneXR_back;
  if (model === 'iPhone 11' || model === 'iPhone 12' || model === 'iPhone 13 Pro Max' || model === 'iPhone 14' || model === 'iPhone 15 Pro') return IMAGES.iphone11to15_back;
  if (model === 'iPhone 16') return IMAGES.iphone16_back;
  if (model === 'iPhone 16e') return IMAGES.iphone16e_back;
  if (model === 'iPhone 17e') return IMAGES.iphone17e_back;
  if (model === 'iPhone 17 Pro Max') return IMAGES.iphone17_back;
  return IMAGES.iphone11to15_back;
}
spinBtn.addEventListener('click', function() {
  if (spinning) return;
  if (spinsRemaining() <= 0) { updateSpinCounter(); return; }
  spinning = true;
  spinBtn.disabled = true;
  recordSpin();
  soundClick();
  result.classList.add('hidden');
  loading.classList.add('hidden');
  const isIPhone = Math.random() < 0.5;
  currentBrand = isIPhone ? 'iphone' : 'android';
  const targetAngle = isIPhone ? 90 : 270;
  const fullSpins = 5 + Math.floor(Math.random() * 3);
  const delta = ((targetAngle - (currentRotation % 360)) + 360) % 360;
  currentRotation = currentRotation + (fullSpins * 360) + delta;
  wheel.style.transform = 'rotate(' + currentRotation + 'deg)';
  setTimeout(function() {
    loading.classList.remove('hidden');
    loadingText.textContent = 'Scanning devices...';
    setTimeout(function() { loadingText.textContent = isIPhone ? 'Finding an iPhone...' : 'Finding an Android...'; }, 700);
    setTimeout(function() { loadingText.textContent = 'Almost there...'; }, 1400);
    setTimeout(function() {
      loading.classList.add('hidden');
      const list = isIPhone ? iPhones : androids;
      const picked = list[Math.floor(Math.random() * list.length)];
      currentModel = picked;
      currentPhoneNumber = generatePhoneNumber();
      prizeName.textContent = picked;
      if (!isIPhone) {
        const brand = picked.split(' ')[0];
        androidBrand.textContent = brand.toUpperCase();
      }
      result.classList.remove('hidden');
      soundWin();
      spinning = false;
      updateSpinCounter();
    }, 2000);
  }, 4200);
});

miniPhone.addEventListener('click', function() {
  soundClick();
  openPhoneViewer(currentModel, currentBrand, currentPhoneNumber);
});

function openPhoneViewer(model, brand, number) {
  const iphoneFrontEl = document.querySelector('.iphone-front');
  if (iphoneFrontEl) {
    iphoneFrontEl.classList.remove('show-home-button', 'show-home-bar');
    if (brand === 'iphone') {
      if (model === 'iPhone 7') iphoneFrontEl.classList.add('show-home-button');
      else iphoneFrontEl.classList.add('show-home-bar');
    }
  }
  currentModel = model;
  currentBrand = brand;
  currentPhoneNumber = number;
  phoneStage.className = brand;
  flipCard.classList.remove('flipped');
  appScreen.classList.add('hidden');
  iphonePage = 0;
  androidPage = 0;
  if (document.getElementById('iphoneIcons')) document.getElementById('iphoneIcons').classList.remove('hidden');
  if (document.getElementById('iphoneIcons2')) document.getElementById('iphoneIcons2').classList.add('hidden');
  if (document.getElementById('androidIcons')) document.getElementById('androidIcons').classList.remove('hidden');
  if (document.getElementById('androidIcons2')) document.getElementById('androidIcons2').classList.add('hidden');
  document.querySelectorAll('#ipDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === 0); });
  document.querySelectorAll('#anDots .dot').forEach(function(d, i) { d.classList.toggle('active', i === 0); });
  refreshPage2();
  if (brand === 'iphone') { iphoneBackImg.src = getIphoneBackImage(model); }
  else {
    androidBackImg.src = IMAGES.android_back;
    androidBrand.textContent = model.split(' ')[0].toUpperCase();
  }
  refreshSaveButton();
  phoneViewer.classList.remove('hidden');
  const lock = document.getElementById('lockScreen');
  if (lock) { lock.classList.remove('hidden'); lock.style.display = 'flex'; }
  const pwScreen = document.getElementById('passwordScreen');
  if (pwScreen) { pwScreen.classList.add('hidden'); pwScreen.style.display = 'none'; }
  updateLockClock();
}

rotateBtn.addEventListener('click', function() {
  if (!appScreen.classList.contains('hidden')) return;
  soundClick();
  flipCard.classList.toggle('flipped');
});

closeBtn.addEventListener('click', function() {
  soundClick();
  phoneViewer.classList.add('hidden');
  flipCard.classList.remove('flipped');
  appScreen.classList.add('hidden');
  const lock = document.getElementById('lockScreen');
  if (lock) lock.classList.add('hidden');
  const pw = document.getElementById('passwordScreen');
  if (pw) pw.classList.add('hidden');
});

function openApp(name) {
  appScreenContent.innerHTML = '';
  appScreen.classList.remove('hidden');
  flipCard.classList.remove('flipped');
  if (name === 'Settings') renderSettings();
  else if (name === 'App Store' || name === 'Play Store') renderStore(name);
  else if (name === 'Phone') renderPhoneApp();
  else if (name === 'Calculator') renderCalculator();
  else if (name === 'WhatsApp') renderWhatsApp();
  else if (name === 'YouTube') renderYouTube();
  else if (name === 'Instagram') renderInstagram();
  else if (name === 'TikTok') renderTikTok();
  else if (name === 'Spotify') renderSpotify();
  else if (name === 'Netflix') renderNetflix();
  else if (name === 'Facebook') renderFacebook();
  else if (name === 'Twitter') renderTwitter();
  else if (name === 'Snapchat') renderSnapchat();
  else if (name === 'Telegram') renderTelegram();
  else renderPlaceholder(name);
}

let calcState = { display: '0', firstNumber: null, operator: null, waitingForSecond: false };

function renderCalculator() {
  let html = '<div style="display:flex;flex-direction:column;height:100%;">';
  html += '<div class="calc-display" id="calcDisplay">' + calcState.display + '</div>';
  html += '<div class="calc-grid">';
  html += '<button class="calc-btn gray" data-calc="AC">AC</button>';
  html += '<button class="calc-btn gray" data-calc="+/-">+/-</button>';
  html += '<button class="calc-btn gray" data-calc="%">%</button>';
  html += '<button class="calc-btn op" data-calc="/">/</button>';
  html += '<button class="calc-btn" data-calc="7">7</button>';
  html += '<button class="calc-btn" data-calc="8">8</button>';
  html += '<button class="calc-btn" data-calc="9">9</button>';
  html += '<button class="calc-btn op" data-calc="*">x</button>';
  html += '<button class="calc-btn" data-calc="4">4</button>';
  html += '<button class="calc-btn" data-calc="5">5</button>';
  html += '<button class="calc-btn" data-calc="6">6</button>';
  html += '<button class="calc-btn op" data-calc="-">-</button>';
  html += '<button class="calc-btn" data-calc="1">1</button>';
  html += '<button class="calc-btn" data-calc="2">2</button>';
  html += '<button class="calc-btn" data-calc="3">3</button>';
  html += '<button class="calc-btn op" data-calc="+">+</button>';
  html += '<button class="calc-btn zero" data-calc="0">0</button>';
  html += '<button class="calc-btn" data-calc=".">.</button>';
  html += '<button class="calc-btn op" data-calc="=">=</button>';
  html += '</div></div>';
  appScreenContent.innerHTML = html;
  appScreenContent.querySelectorAll('.calc-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      calcHandleKey(btn.getAttribute('data-calc'));
    });
  });
}

function calcUpdateDisplay() {
  const el = document.getElementById('calcDisplay');
  if (el) el.textContent = calcState.display;
}
function calcInput(digit) {
  if (calcState.waitingForSecond) {
    calcState.display = digit;
    calcState.waitingForSecond = false;
  } else {
    calcState.display = calcState.display === '0' ? digit : calcState.display + digit;
  }
  if (calcState.display.length > 12) calcState.display = calcState.display.slice(0, 12);
  calcUpdateDisplay();
}
function calcDecimal() {
  if (calcState.waitingForSecond) {
    calcState.display = '0.';
    calcState.waitingForSecond = false;
  } else if (calcState.display.indexOf('.') === -1) {
    calcState.display += '.';
  }
  calcUpdateDisplay();
}
function calcClear() {
  calcState.display = '0';
  calcState.firstNumber = null;
  calcState.operator = null;
  calcState.waitingForSecond = false;
  calcUpdateDisplay();
}
function calcToggleSign() {
  if (calcState.display.charAt(0) === '-') calcState.display = calcState.display.slice(1);
  else if (calcState.display !== '0') calcState.display = '-' + calcState.display;
  calcUpdateDisplay();
}
function calcPercent() {
  calcState.display = String(parseFloat(calcState.display) / 100);
  calcUpdateDisplay();
}
function calcCalculate(a, b, op) {
  a = parseFloat(a);
  b = parseFloat(b);
  if (op === '+') return a + b;
  if (op === '-') return a - b;
  if (op === '*') return a * b;
  if (op === '/') return b === 0 ? 'Error' : a / b;
  return b;
}
function calcOperator(op) {
  const current = parseFloat(calcState.display);
  if (calcState.firstNumber === null) {
    calcState.firstNumber = current;
  } else if (!calcState.waitingForSecond) {
    const r = calcCalculate(calcState.firstNumber, current, calcState.operator);
    if (r === 'Error') {
      calcState.display = 'Error';
      calcUpdateDisplay();
      calcClear();
      return;
    }
    calcState.display = String(r);
    calcState.firstNumber = r;
    calcUpdateDisplay();
  }
  calcState.operator = op;
  calcState.waitingForSecond = true;
}
function calcEquals() {
  if (calcState.operator === null || calcState.firstNumber === null) return;
  const current = parseFloat(calcState.display);
  const r = calcCalculate(calcState.firstNumber, current, calcState.operator);
  calcState.display = r === 'Error' ? 'Error' : String(Math.round(r * 100000000) / 100000000);
  calcState.firstNumber = null;
  calcState.operator = null;
  calcState.waitingForSecond = false;
  calcUpdateDisplay();
}
function calcHandleKey(key) {
  soundClick();
  if (key >= '0' && key <= '9') { calcInput(key); return; }
  if (key === '.') { calcDecimal(); return; }
  if (key === 'AC') { calcClear(); return; }
  if (key === '+/-') { calcToggleSign(); return; }
  if (key === '%') { calcPercent(); return; }
  if (key === '=') { calcEquals(); return; }
  if (key === '+' || key === '-' || key === '*' || key === '/') { calcOperator(key); return; }
}
function renderWhatsApp() {
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#3ddc84;margin:0 0 16px;">WhatsApp</h2>';
  const chats = [
    { name: 'Mom', msg: 'Did you eat?', time: 'now' },
    { name: 'John', msg: 'See you tomorrow', time: '5m' },
    { name: 'Sarah', msg: 'Sent a photo', time: '1h' },
    { name: 'Work Group', msg: 'Alex: Meeting at 3pm', time: '2h' },
    { name: 'David', msg: 'Okay thanks!', time: '1d' },
    { name: 'Emma', msg: 'Nice', time: '2d' }
  ];
  const colors = ['#00e5ff','#ff006e','#3ddc84','#ffcc00','#a855f7','#ff6699'];
  for (let i = 0; i < chats.length; i++) {
    html += '<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:48px;height:48px;border-radius:50%;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:18px;color:#fff;flex-shrink:0;">' + chats[i].name.charAt(0) + '</div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:14px;font-weight:600;margin-bottom:2px;">' + chats[i].name + '</div>';
    html += '<div style="font-size:12px;color:rgba(255,255,255,0.55);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + chats[i].msg + '</div></div>';
    html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);flex-shrink:0;">' + chats[i].time + '</div></div>';
  }
  appScreenContent.innerHTML = html;
}

function renderYouTube() {
  let html = '<div style="background:#ff0000;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">YouTube</div>';
  const videos = [
    { title: 'How to build an app', ch: 'Tech Tips', dur: '12:34', views: '1.2M views' },
    { title: 'Best songs 2026', ch: 'Music World', dur: '3:45', views: '892K views' },
    { title: 'Funny cats compilation', ch: 'Funny Pets', dur: '8:21', views: '5.4M views' },
    { title: 'Learn coding fast', ch: 'CodeMaster', dur: '22:10', views: '340K views' },
    { title: 'Top 10 phones 2026', ch: 'Tech Review', dur: '15:02', views: '2.1M views' }
  ];
  videos.forEach(function(v) {
    html += '<div style="display:flex;gap:12px;margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:120px;height:70px;background:linear-gradient(135deg,#333,#111);border-radius:8px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:16px;position:relative;color:#fff;font-weight:700;">PLAY<span style="position:absolute;bottom:4px;right:4px;background:rgba(0,0,0,0.8);font-size:10px;padding:2px 4px;border-radius:3px;font-weight:400;">' + v.dur + '</span></div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;margin-bottom:4px;">' + v.title + '</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.5);">' + v.ch + '</div>';
    html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);">' + v.views + '</div></div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderInstagram() {
  let html = '<div style="background:linear-gradient(90deg,#ff006e,#a855f7);padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Instagram</div>';
  const posts = [
    { user: 'sarah_official', likes: '2,341', caption: 'Sunset vibes' },
    { user: 'john.photo', likes: '890', caption: 'New camera' },
    { user: 'travel_world', likes: '12,402', caption: 'Beach day' },
    { user: 'foodie_life', likes: '3,120', caption: 'Best pizza ever' }
  ];
  const colors = ['#ff6699','#00e5ff','#ffcc00','#a855f7'];
  posts.forEach(function(p, i) {
    html += '<div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">';
    html += '<div style="width:32px;height:32px;border-radius:50%;background:' + colors[i] + ';"></div>';
    html += '<div style="font-size:12px;font-weight:600;">' + p.user + '</div></div>';
    html += '<div style="width:100%;height:180px;border-radius:10px;background:linear-gradient(135deg,' + colors[i] + ',#222);margin-bottom:8px;"></div>';
    html += '<div style="font-size:12px;margin-bottom:4px;">' + p.likes + ' likes</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.65);">' + p.caption + '</div>';
    html += '</div>';
  });
  appScreenContent.innerHTML = html;
}

function renderTikTok() {
  let html = '<div style="background:linear-gradient(90deg,#ff006e,#00e5ff);padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">TikTok</div>';
  const videos = ['Dance trend', 'Funny cat', 'Cooking hack', 'Pet reveal', 'Life hack', 'Music remix'];
  const colors = ['#ff006e','#a855f7','#00e5ff','#3ddc84','#ffcc00','#ff6699'];
  html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">';
  videos.forEach(function(v, i) {
    html += '<div style="aspect-ratio:9/16;border-radius:10px;background:linear-gradient(180deg,' + colors[i] + ',#111);position:relative;overflow:hidden;">';
    html += '<div style="position:absolute;bottom:8px;left:8px;right:8px;font-size:10px;color:#fff;font-weight:600;">' + v + '</div>';
    html += '</div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
}

function renderSpotify() {
  let html = '<div style="background:linear-gradient(90deg,#3ddc84,#00aa66);padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Spotify</div>';
  const songs = [
    { title: 'Blinding Lights', artist: 'The Weeknd', dur: '3:20' },
    { title: 'Levitating', artist: 'Dua Lipa', dur: '3:23' },
    { title: 'Stay', artist: 'Kid Laroi', dur: '2:21' },
    { title: 'Heat Waves', artist: 'Glass Animals', dur: '3:58' },
    { title: 'As It Was', artist: 'Harry Styles', dur: '2:47' },
    { title: 'Bad Habit', artist: 'Steve Lacy', dur: '3:52' }
  ];
  html += '<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);margin-bottom:10px;">PLAYLIST - LIKED SONGS</div>';
  songs.forEach(function(s, i) {
    html += '<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.4);width:14px;">' + (i+1) + '</div>';
    html += '<div style="width:36px;height:36px;border-radius:6px;background:linear-gradient(135deg,#3ddc84,#0088ff);flex-shrink:0;"></div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;">' + s.title + '</div><div style="font-size:11px;color:rgba(255,255,255,0.5);">' + s.artist + '</div></div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.4);">' + s.dur + '</div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderNetflix() {
  let html = '<div style="background:#cc0000;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">NETFLIX</div>';
  const shows = [
    { title: 'Money Heist', genre: 'Action - Thriller' },
    { title: 'Stranger Things', genre: 'Sci-Fi - Horror' },
    { title: 'The Witcher', genre: 'Fantasy - Adventure' },
    { title: 'Squid Game', genre: 'Drama - Thriller' },
    { title: 'Wednesday', genre: 'Comedy - Mystery' }
  ];
  const colors = ['#cc0000','#a855f7','#3ddc84','#ff006e','#333'];
  shows.forEach(function(s, i) {
    html += '<div style="display:flex;gap:12px;margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:80px;height:120px;border-radius:8px;background:linear-gradient(180deg,' + colors[i] + ',#111);flex-shrink:0;"></div>';
    html += '<div style="flex:1;padding-top:8px;"><div style="font-size:14px;font-weight:700;margin-bottom:6px;">' + s.title + '</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.5);margin-bottom:8px;">' + s.genre + '</div>';
    html += '<div style="display:inline-block;background:#fff;color:#000;font-size:10px;font-weight:700;padding:4px 12px;border-radius:4px;">PLAY</div></div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderFacebook() {
  let html = '<div style="background:#1a88ff;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Facebook</div>';
  const posts = [
    { user: 'Sarah Johnson', time: '2h', text: 'Had an amazing day at the beach!' },
    { user: 'John Smith', time: '5h', text: 'Just finished my new project' },
    { user: 'Tech News', time: '1d', text: 'iPhone 17 Pro Max review is out!' }
  ];
  const colors = ['#00e5ff','#3ddc84','#ffcc00'];
  posts.forEach(function(p, i) {
    html += '<div style="background:rgba(255,255,255,0.04);border-radius:12px;padding:14px;margin-bottom:12px;">';
    html += '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">';
    html += '<div style="width:36px;height:36px;border-radius:50%;background:' + colors[i] + ';"></div>';
    html += '<div><div style="font-size:13px;font-weight:600;">' + p.user + '</div><div style="font-size:10px;color:rgba(255,255,255,0.4);">' + p.time + ' ago</div></div></div>';
    html += '<div style="font-size:12px;color:rgba(255,255,255,0.85);margin-bottom:10px;">' + p.text + '</div>';
    html += '<div style="display:flex;gap:16px;font-size:11px;color:rgba(255,255,255,0.5);">Like  Comment  Share</div>';
    html += '</div>';
  });
  appScreenContent.innerHTML = html;
}

function renderTwitter() {
  let html = '<div style="background:#00e5ff;color:#0a0f1e;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Twitter</div>';
  const tweets = [
    { user: '@techguru', text: 'Just got my hands on the new iPhone 17 Pro!', time: '2m' },
    { user: '@newsupdate', text: 'Breaking: New AI model released today', time: '15m' },
    { user: '@foodie', text: 'Best pizza in town, highly recommend!', time: '1h' },
    { user: '@coder_life', text: 'JavaScript tip: use const by default', time: '3h' }
  ];
  const colors = ['#00e5ff','#ff006e','#3ddc84','#ffcc00'];
  tweets.forEach(function(t, i) {
    html += '<div style="padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);display:flex;gap:12px;">';
    html += '<div style="width:36px;height:36px;border-radius:50%;background:' + colors[i] + ';flex-shrink:0;"></div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:12px;font-weight:600;margin-bottom:4px;">' + t.user + ' - ' + t.time + '</div>';
    html += '<div style="font-size:13px;color:rgba(255,255,255,0.85);margin-bottom:6px;">' + t.text + '</div>';
    html += '<div style="display:flex;gap:16px;font-size:11px;color:rgba(255,255,255,0.45);">Reply  Retweet  Like</div></div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderSnapchat() {
  let html = '<div style="background:#ffcc00;color:#000;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Snapchat</div>';
  html += '<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);margin-bottom:12px;">RECENT SNAPS</div>';
  const snaps = ['Sarah','John','Emma','Mike','Lisa','David','Anna','Tom'];
  const colors = ['#ffcc00','#ff006e','#00e5ff','#3ddc84','#a855f7','#ff6699','#ff8800','#00aa66'];
  html += '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">';
  snaps.forEach(function(n, i) {
    html += '<div style="aspect-ratio:3/4;border-radius:10px;background:linear-gradient(180deg,' + colors[i] + ',#222);position:relative;display:flex;align-items:flex-end;padding:8px;">';
    html += '<div style="font-size:12px;font-weight:600;">' + n + '</div></div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
}

function renderTelegram() {
  let html = '<div style="background:#00e5ff;color:#0a0f1e;padding:8px 12px;border-radius:8px;display:inline-block;font-weight:900;letter-spacing:2px;margin-bottom:16px;">Telegram</div>';
  const chats = [
    { name: 'Family Group', msg: 'Mom: See you soon!', time: 'now' },
    { name: 'Crypto News', msg: 'BTC up 5% today', time: '10m' },
    { name: 'Tech Friends', msg: 'Alex: Anyone tried the new iPhone?', time: '1h' },
    { name: 'Study Group', msg: 'Exam notes shared', time: '3h' }
  ];
  const colors = ['#00e5ff','#3ddc84','#ff006e','#ffcc00'];
  chats.forEach(function(c, i) {
    html += '<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:44px;height:44px;border-radius:50%;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;color:#fff;flex-shrink:0;">' + c.name.charAt(0) + '</div>';
    html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;">' + c.name + '</div>';
    html += '<div style="font-size:11px;color:rgba(255,255,255,0.55);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + c.msg + '</div></div>';
    html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);">' + c.time + '</div></div>';
  });
  appScreenContent.innerHTML = html;
}

function renderPlaceholder(name) {
  let html = '';
  if (name === 'Messages') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">Messages</h2>';
    const names = ['Mom','John','Sarah','Work Group','David','Emma'];
    const colors = ['#00e5ff','#ff006e','#3ddc84','#ffcc00','#a855f7','#ff6699'];
    const times = ['now','5m','1h','2h','3h','1d'];
    for (let i = 0; i < names.length; i++) {
      html += '<div style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(255,255,255,0.05);border-radius:12px;margin-bottom:8px;">';
      html += '<div style="width:44px;height:44px;border-radius:50%;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:16px;color:#fff;">' + names[i].charAt(0) + '</div>';
      html += '<div style="flex:1;min-width:0;"><div style="font-size:13px;font-weight:600;">' + names[i] + '</div><div style="font-size:11px;color:rgba(255,255,255,0.5);">Hey, how are you?</div></div>';
      html += '<div style="font-size:10px;color:rgba(255,255,255,0.4);">' + times[i] + '</div></div>';
    }
  } else if (name === 'Safari' || name === 'Chrome') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">' + name + '</h2>';
    html += '<div style="background:rgba(255,255,255,0.08);border-radius:12px;padding:10px 14px;margin-bottom:16px;"><span style="font-size:12px;color:rgba(255,255,255,0.7);">Search or type URL</span></div>';
    const sites = ['Google','YouTube','Facebook','Twitter','Instagram','Reddit'];
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">';
    for (let i = 0; i < sites.length; i++) {
      html += '<div style="background:rgba(255,255,255,0.06);border-radius:12px;padding:16px;text-align:center;">';
      html += '<div style="font-size:11px;color:rgba(255,255,255,0.7);">' + sites[i] + '</div></div>';
    }
    html += '</div>';
  } else if (name === 'Camera') {
    html += '<div style="display:flex;flex-direction:column;height:100%;">';
    html += '<div style="flex:1;width:100%;background:linear-gradient(135deg,#0a0f1e,#1a2238);border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:16px;color:#fff;font-weight:900;">CAMERA</div>';
    html += '<div style="display:flex;gap:24px;align-items:center;justify-content:center;padding-bottom:10px;">';
    html += '<div style="width:70px;height:70px;border-radius:50%;background:#fff;border:4px solid #ccc;"></div>';
    html += '</div></div>';
  } else if (name === 'Music') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#ff006e;margin:0 0 16px;">Now Playing</h2>';
    html += '<div style="background:linear-gradient(135deg,#ff006e,#a855f7);border-radius:16px;aspect-ratio:1/1;max-width:180px;margin:0 auto 16px;"></div>';
    html += '<div style="text-align:center;margin-bottom:20px;"><div style="font-size:15px;font-weight:700;margin-bottom:4px;">Blinding Lights</div><div style="font-size:11px;color:rgba(255,255,255,0.5);">The Weeknd</div></div>';
  } else if (name === 'Notes') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#ffcc00;margin:0 0 16px;">Notes</h2>';
    const notes = ['Shopping List','Meeting notes','Ideas','To-Do','Birthday plans'];
    const dates = ['Today','Yesterday','3 days ago','Last week','2 weeks ago'];
    for (let i = 0; i < notes.length; i++) {
      html += '<div style="padding:12px 0;border-bottom:1px solid rgba(255,255,255,0.06);"><div style="font-size:13px;font-weight:600;margin-bottom:2px;">' + notes[i] + '</div><div style="font-size:11px;color:rgba(255,255,255,0.4);">' + dates[i] + '</div></div>';
    }
  } else if (name === 'Photos' || name === 'Gallery') {
    html += '<h2 style="font-size:18px;letter-spacing:2px;color:#ff6699;margin:0 0 16px;">' + name + '</h2>';
    html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px;">';
    const colors = ['#ff6699','#00e5ff','#3ddc84','#ffcc00','#a855f7','#ff006e'];
    for (let i = 0; i < 18; i++) {
      html += '<div style="aspect-ratio:1/1;background:linear-gradient(135deg,' + colors[i % 6] + ',#222);border-radius:4px;"></div>';
    }
    html += '</div>';
  } else {
    html += '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;"><h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;">' + name + '</h2></div>';
  }
  appScreenContent.innerHTML = html;
}

function renderPhoneApp() {
  let html = '<div style="display:flex;flex-direction:column;align-items:center;padding-top:20px;text-align:center;">';
  html += '<div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#3ddc84,#00aa66);display:flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:18px;color:#fff;font-weight:900;">PHONE</div>';
  html += '<div style="font-size:11px;letter-spacing:2px;color:rgba(255,255,255,0.5);margin-bottom:6px;">MY NUMBER</div>';
  html += '<div style="font-size:18px;font-weight:700;letter-spacing:1px;color:#3ddc84;margin-bottom:20px;">' + (currentPhoneNumber || 'No SIM') + '</div>';
  html += '<div style="font-size:12px;color:rgba(255,255,255,0.5);letter-spacing:1px;margin-bottom:24px;">Carrier: ' + (currentBrand === 'iphone' ? 'T-Mobile' : 'Verizon') + '</div>';
  html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;width:100%;max-width:240px;">';
  const nums = [1,2,3,4,5,6,7,8,9,'*',0,'#'];
  for (let i = 0; i < nums.length; i++) {
    html += '<div style="width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,0.08);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:600;color:#fff;">' + nums[i] + '</div>';
  }
  html += '</div></div>';
  appScreenContent.innerHTML = html;
}

function renderStore(name) {
  const isApple = name === 'App Store';
  const list = isApple ? ['Instagram','WhatsApp','TikTok','YouTube','Spotify','Netflix','Snapchat','Twitter'] : ['Facebook','WhatsApp','TikTok','YouTube','Spotify','Netflix','Telegram','Instagram'];
  const colors = ['#ff006e','#3ddc84','#00e5ff','#ffcc00','#a855f7','#ff6699','#00aa66','#ff6600'];
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">' + name + '</h2>';
  for (let i = 0; i < list.length; i++) {
    const installed = isAppInstalled(list[i]);
    const btnClass = installed ? 'store-open-btn' : 'store-get-btn';
    const btnText = installed ? 'OPEN' : 'GET';
    const btnColor = installed ? '#3ddc84' : '#00e5ff';
    html += '<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.06);">';
    html += '<div style="width:44px;height:44px;border-radius:12px;background:' + colors[i] + ';display:flex;align-items:center;justify-content:center;font-weight:900;font-size:18px;color:#fff;">' + list[i].charAt(0) + '</div>';
    html += '<div style="flex:1;"><div style="font-size:13px;font-weight:600;">' + list[i] + '</div><div style="font-size:10px;color:rgba(255,255,255,0.4);">Free - Get</div></div>';
    html += '<button class="' + btnClass + '" data-app="' + list[i] + '" style="padding:6px 16px;font-size:11px;border-radius:20px;background:' + btnColor + ';color:#0a0f1e;border:none;font-weight:700;box-shadow:none;">' + btnText + '</button></div>';
  }
  appScreenContent.innerHTML = html;
}

function renderSettings() {
  const usedGB = 64, totalGB = 128;
  const pct = Math.round((usedGB / totalGB) * 100);
  const initial = userName ? userName.charAt(0).toUpperCase() : '?';
  let html = '';
  html += '<div class="settings-profile"><div class="profile-avatar">' + initial + '</div>';
  html += '<div class="profile-info"><div class="profile-name">' + escapeHtml(userName || 'Your Name') + '</div>';
  html += '<div class="profile-sub">' + (currentBrand === 'iphone' ? 'Apple ID, iCloud' : 'Samsung Account') + '</div></div></div>';
  html += '<div class="section-heading">Connectivity</div><div class="settings-section">';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#007aff;">W</div><div class="settings-label">Wi-Fi</div><div class="settings-value">Home_5G</div><div class="toggle ' + (settingsState.wifi ? 'on' : '') + '" data-key="wifi"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#007aff;">B</div><div class="settings-label">Bluetooth</div><div class="toggle ' + (settingsState.bluetooth ? 'on' : '') + '" data-key="bluetooth"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#34c759;">M</div><div class="settings-label">Mobile Data</div><div class="toggle ' + (settingsState.mobileData ? 'on' : '') + '" data-key="mobileData"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#00aa66;">N</div><div class="settings-label">My Number</div><div class="settings-value">' + (currentPhoneNumber || '-') + '</div></div>';
  html += '</div>';
  html += '<div class="section-heading">Device</div><div class="settings-section">';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#ff9500;">B</div><div class="settings-label">Battery</div><div class="settings-value" id="batteryValue">' + battery + '%</div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#5856d6;">S</div><div class="settings-label">Storage</div><div class="settings-value">' + usedGB + ' GB of ' + totalGB + ' GB</div></div>';
  html += '<div style="padding:0 0 12px 44px;"><div class="storage-bar"><div class="storage-fill" style="width:' + pct + '%"></div></div>';
  html += '<div class="storage-labels"><span>Used: ' + usedGB + ' GB</span><span>Free: ' + (totalGB - usedGB) + ' GB</span></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#ff2d55;">N</div><div class="settings-label">Notifications</div><div class="toggle ' + (settingsState.notifications ? 'on' : '') + '" data-key="notifications"></div></div>';
  html += '<div class="settings-row"><div class="settings-icon" style="background:#af52de;">S</div><div class="settings-label">Sounds</div><div class="toggle ' + (settingsState.sounds ? 'on' : '') + '" data-key="sounds"></div></div>';
  html += '</div>';

  const hasPw = getPassword() !== '';
  html += '<div class="section-heading">Security</div><div class="settings-section">';
  html += '<div class="settings-row" id="settingsPasswordRow">';
  html += '<div class="settings-icon" style="background:#ff2d55;">L</div>';
  html += '<div class="settings-label">' + (hasPw ? 'Change Password' : 'Set Password') + '</div>';
  html += '<div class="settings-value">' + (hasPw ? '....' : 'Off') + '</div></div>';
  if (hasPw) {
    html += '<div class="settings-row" id="settingsRemovePwRow">';
    html += '<div class="settings-icon" style="background:#ff6600;">U</div>';
    html += '<div class="settings-label">Remove Password</div>';
    html += '<div class="settings-value">Tap to remove</div></div>';
  }
  html += '</div>';

  html += '<div class="section-heading">About</div><div class="settings-section">';
  html += '<div class="info-block"><span>Name</span><strong>' + escapeHtml(currentModel || 'Unknown') + '</strong></div>';
  html += '<div class="info-block"><span>Model</span><strong>' + escapeHtml(currentModel || 'Unknown') + '</strong></div>';
  html += '<div class="info-block"><span>Capacity</span><strong>' + totalGB + ' GB</strong></div>';
  html += '<div class="info-block"><span>OS Version</span><strong>' + (currentBrand === 'iphone' ? 'iOS 18.2' : 'Android 15') + '</strong></div>';
  html += '<div class="info-block"><span>Serial</span><strong>' + randomSerial() + '</strong></div>';
  html += '<div class="info-block"><span>Owner</span><strong>' + escapeHtml(userName || '-') + '</strong></div>';
  html += '</div>';
  appScreenContent.innerHTML = html;

  appScreenContent.querySelectorAll('.toggle').forEach(function(t) {
    t.addEventListener('click', function() {
      const key = t.dataset.key;
      settingsState[key] = !settingsState[key];
      t.classList.toggle('on', settingsState[key]);
      if (key === 'sounds') {
        soundEnabled = settingsState.sounds;
        localStorage.setItem('soundEnabled', soundEnabled ? 'true' : 'false');
        if (soundEnabled) soundClick();
      } else {
        soundClick();
      }
    });
  });

  const pwRow = document.getElementById('settingsPasswordRow');
  if (pwRow) {
    pwRow.addEventListener('click', function() {
      soundClick();
      const newPw = prompt('Enter a new 4-6 digit password:');
      if (newPw === null) return;
      const clean = String(newPw || '').replace(/[^0-9]/g, '');
      if (clean.length < 4 || clean.length > 6) { alert('Password must be 4-6 digits.'); return; }
      setPassword(clean);
      renderSettings();
    });
  }
  const removeRow = document.getElementById('settingsRemovePwRow');
  if (removeRow) {
    removeRow.addEventListener('click', function() {
      soundClick();
      if (confirm('Remove password?')) { removePassword(); renderSettings(); }
    });
  }
}

function escapeHtml(s) { return String(s).replace(/[&<>"']/g, function(c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function randomSerial() { const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789'; let s = ''; for (let i = 0; i < 12; i++) s += chars[Math.floor(Math.random() * chars.length)]; return s; }

setInterval(function() {
  if (battery > 1) {
    battery -= 1;
    ipBatteryEl.textContent = battery;
    anBatteryEl.textContent = battery;
    const bv = document.getElementById('batteryValue');
    if (bv) bv.textContent = battery + '%';
  }
}, 45000);

appBackBtn.addEventListener('click', function() { soundClick(); appScreen.classList.add('hidden'); });

myPhonesBtn.addEventListener('click', function() { soundClick(); renderMyPhones(); myPhonesScreen.classList.remove('hidden'); });
myPhonesBackBtn.addEventListener('click', function() { soundClick(); myPhonesScreen.classList.add('hidden'); });

function renderMyPhones() {
  const saved = getSavedPhones();
  if (saved.length === 0) {
    myPhonesList.innerHTML = '<div class="empty-state">No saved phones yet.<br>Spin and tap the star to save one.</div>';
    return;
  }
  let html = '';
  for (let i = 0; i < saved.length; i++) {
    const p = saved[i];
    const img = p.brand === 'iphone' ? getIphoneBackImage(p.model) : IMAGES.android_back;
    html += '<div class="saved-phone-card" data-index="' + i + '">';
    html += '<img src="' + img + '" alt="">';
    html += '<div class="saved-phone-name">' + escapeHtml(p.model) + '</div>';
    html += '<div class="saved-phone-number">' + escapeHtml(p.number) + '</div>';
    html += '</div>';
  }
  myPhonesList.innerHTML = html;
  myPhonesList.querySelectorAll('.saved-phone-card').forEach(function(card) {
    card.addEventListener('click', function() {
      soundClick();
      const idx = parseInt(card.getAttribute('data-index'), 10);
      const p = getSavedPhones()[idx];
      if (!p) return;
      myPhonesScreen.classList.add('hidden');
      openPhoneViewer(p.model, p.brand, p.number);
    });
  });
}

function updateLockClock() {
  const now = new Date();
  const hours = now.getHours();
  const mins = String(now.getMinutes()).padStart(2, '0');
  const h12 = hours % 12 || 12;
  const clock = document.getElementById('lockClock');
  if (clock) clock.textContent = h12 + ':' + mins;
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const dateEl = document.getElementById('lockDate');
  if (dateEl) dateEl.textContent = days[now.getDay()] + ', ' + months[now.getMonth()] + ' ' + now.getDate();
}
setInterval(updateLockClock, 30000);

function getPassword() { return localStorage.getItem('phonePassword') || ''; }
function setPassword(pw) { localStorage.setItem('phonePassword', pw); }
function removePassword() { localStorage.removeItem('phonePassword'); }

function showPasswordScreen() {
  const lock = document.getElementById('lockScreen');
  if (lock) { lock.classList.add('hidden'); lock.style.display = 'none'; }
  const pwScreen = document.getElementById('passwordScreen');
  if (pwScreen) { pwScreen.classList.remove('hidden'); pwScreen.style.display = 'flex'; }
  pwInput = '';
  updatePwDots();
  const err = document.getElementById('pwError');
  if (err) err.classList.add('hidden');
}

function updatePwDots() {
  document.querySelectorAll('.pw-dot').forEach(function(d, i) {
    d.classList.toggle('filled', i < pwInput.length);
  });
}

function pwSubmit() {
  const stored = getPassword();
  if (pwInput === stored) { soundUnlock(); unlockPhone(); }
  else {
    soundWrong();
    const err = document.getElementById('pwError');
    if (err) err.classList.remove('hidden');
    pwInput = '';
    updatePwDots();
  }
}

function unlockPhone() {
  const pwScreen = document.getElementById('passwordScreen');
  if (pwScreen) { pwScreen.classList.add('hidden'); pwScreen.style.display = 'none'; }
  const lock = document.getElementById('lockScreen');
  if (lock) { lock.classList.add('hidden'); lock.style.display = 'none'; }
  pwInput = '';
}

document.addEventListener('touchstart', function(e) {
  const lock = document.getElementById('lockScreen');
  if (!lock || lock.classList.contains('hidden')) return;
  if (!e.touches || !e.touches[0]) return;
  lock.dataset.startY = e.touches[0].clientY;
}, { passive: true });
document.addEventListener('touchend', function(e) {
  const lock = document.getElementById('lockScreen');
  if (!lock || lock.classList.contains('hidden')) return;
  const startY = parseFloat(lock.dataset.startY || '0');
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dy = startY - e.changedTouches[0].clientY;
  if (dy > 40) {
    if (getPassword()) showPasswordScreen();
    else unlockPhone();
  }
}, { passive: true });

document.addEventListener('click', function(e) {
  const lock = document.getElementById('lockScreen');
  if (lock && !lock.classList.contains('hidden') && (e.target === lock || lock.contains(e.target))) {
    if (getPassword()) showPasswordScreen();
    else unlockPhone();
  }
});

document.addEventListener('click', function(e) {
  const key = e.target.closest && e.target.closest('.pw-key');
  if (!key) return;
  const val = key.getAttribute('data-key');
  if (!val || val === 'empty') return;
  if (val === 'del') { soundLockClick(); pwInput = pwInput.slice(0, -1); updatePwDots(); return; }
  soundLockClick();
  if (pwInput.length >= 6) return;
  pwInput += val;
  updatePwDots();
  if (pwInput.length === getPassword().length) setTimeout(pwSubmit, 200);
});

document.addEventListener('click', function(e) {
  const getBtn = e.target.closest && e.target.closest('.store-get-btn');
  if (getBtn) {
    const name = getBtn.getAttribute('data-app');
    if (isAppInstalled(name)) return;
    soundClick();
    getBtn.textContent = '...';
    getBtn.style.background = '#888';
    setTimeout(function() {
      installApp(name);
      getBtn.textContent = 'OPEN';
      getBtn.style.background = '#3ddc84';
      getBtn.classList.remove('store-get-btn');
      getBtn.classList.add('store-open-btn');
      soundUnlock();
    }, 1200);
    return;
  }
  const openBtn = e.target.closest && e.target.closest('.store-open-btn');
  if (openBtn) { soundTap(); openApp(openBtn.getAttribute('data-app')); }
});

document.addEventListener('click', function(e) {
  if (e.target.id === 'iphone7HomeBtn') { soundClick(); appScreen.classList.add('hidden'); switchPage(currentBrand, -100); }
  if (e.target.id === 'androidHome') { soundClick(); appScreen.classList.add('hidden'); switchPage(currentBrand, -100); }
  if (e.target.id === 'androidBack') { soundClick(); if (!appScreen.classList.contains('hidden')) appScreen.classList.add('hidden'); }
  if (e.target.id === 'androidRecent') { soundClick(); if (!appScreen.classList.contains('hidden')) appScreen.classList.add('hidden'); }
});

document.addEventListener('touchstart', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (appScreen && !appScreen.classList.contains('hidden')) return;
  const lock = document.getElementById('lockScreen');
  if (lock && !lock.classList.contains('hidden')) return;
  const pw = document.getElementById('passwordScreen');
  if (pw && !pw.classList.contains('hidden')) return;
  if (!e.touches || !e.touches[0]) return;
  phoneViewer.dataset.touchX = e.touches[0].clientX;
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (appScreen && !appScreen.classList.contains('hidden')) return;
  const lock = document.getElementById('lockScreen');
  if (lock && !lock.classList.contains('hidden')) return;
  const pw = document.getElementById('passwordScreen');
  if (pw && !pw.classList.contains('hidden')) return;
  const startX = parseFloat(phoneViewer.dataset.touchX || '0');
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dx = e.changedTouches[0].clientX - startX;
  if (Math.abs(dx) < 50) return;
  switchPage(currentBrand, dx < 0 ? 1 : -1);
}, { passive: true });

let homeSwipeStartY = 0;
document.addEventListener('touchstart', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (currentBrand !== 'iphone') return;
  if (currentModel === 'iPhone 7') return;
  if (!e.touches || !e.touches[0]) return;
  const stage = document.getElementById('phoneStage');
  if (!stage) return;
  const rect = stage.getBoundingClientRect();
  const touchY = e.touches[0].clientY;
  if (touchY > rect.top + rect.height * 0.85) homeSwipeStartY = touchY;
  else homeSwipeStartY = 0;
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (homeSwipeStartY === 0) return;
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dy = homeSwipeStartY - e.changedTouches[0].clientY;
  homeSwipeStartY = 0;
  if (dy > 50) { appScreen.classList.add('hidden'); switchPage(currentBrand, -100); }
}, { passive: true });
/* ============================================================
   CONTROL CENTER + TORCH + TIC TAC TOE
   ============================================================ */
let ccState = { wifi: true, bluetooth: true, mobileData: true, hotspot: false, airplane: false, screenRecord: false, torch: false, brightness: 80, volume: 70 };

function ensureControlCenter() {
  if (document.getElementById('controlCenter')) return;
  const cc = document.createElement('div');
  cc.id = 'controlCenter';
  cc.className = 'control-center hidden';
  cc.innerHTML = '<div class="cc-title">CONTROL CENTER</div>' +
    '<div class="cc-grid">' +
      '<div class="cc-tile blue" data-cc="wifi"><div class="cc-icon">W</div><div class="cc-label">Wi-Fi</div></div>' +
      '<div class="cc-tile blue" data-cc="bluetooth"><div class="cc-icon">B</div><div class="cc-label">Bluetooth</div></div>' +
      '<div class="cc-tile" data-cc="mobileData"><div class="cc-icon">M</div><div class="cc-label">Mobile Data</div></div>' +
      '<div class="cc-tile orange" data-cc="hotspot"><div class="cc-icon">H</div><div class="cc-label">Hotspot</div></div>' +
      '<div class="cc-tile orange" data-cc="airplane"><div class="cc-icon">A</div><div class="cc-label">Airplane</div></div>' +
      '<div class="cc-tile red" data-cc="screenRecord"><div class="cc-icon">R</div><div class="cc-label">Record</div></div>' +
      '<div class="cc-tile yellow" data-cc="torch"><div class="cc-icon">T</div><div class="cc-label">Torch</div></div>' +
      '<div class="cc-tile purple" data-cc="brightness"><div class="cc-icon">+</div><div class="cc-label">Bright</div></div>' +
      '<div class="cc-tile purple" data-cc="volume"><div class="cc-icon">V</div><div class="cc-label">Volume</div></div>' +
    '</div>' +
    '<div class="cc-slider-wrap"><div class="cc-slider-label">BRIGHTNESS</div><input type="range" min="0" max="100" class="cc-slider" id="ccBrightness" value="80"></div>' +
    '<div class="cc-slider-wrap"><div class="cc-slider-label">VOLUME</div><input type="range" min="0" max="100" class="cc-slider" id="ccVolume" value="70"></div>' +
    '<button class="cc-close-btn" id="ccCloseBtn">CLOSE</button>';
  const stage = document.getElementById('phoneStage');
  if (stage) stage.appendChild(cc);

  const torch = document.createElement('div');
  torch.id = 'torchOverlay';
  torch.className = 'cc-torch-overlay hidden';
  torch.innerHTML = '<div class="torch-text">TORCH ON</div>' +
    '<div class="torch-hint">Screen lights up like a torch</div>' +
    '<button class="torch-btn" id="torchOffBtn">TURN OFF</button>';
  if (stage) stage.appendChild(torch);

  cc.querySelectorAll('.cc-tile').forEach(function(t) {
    t.addEventListener('click', function() {
      const key = t.getAttribute('data-cc');
      if (key === 'torch') {
        ccState.torch = !ccState.torch;
        t.classList.toggle('on', ccState.torch);
        const overlay = document.getElementById('torchOverlay');
        if (overlay) overlay.classList.toggle('hidden', !ccState.torch);
        if (typeof soundClick === 'function') soundClick();
        return;
      }
      if (key === 'brightness' || key === 'volume') return;
      ccState[key] = !ccState[key];
      t.classList.toggle('on', ccState[key]);
      if (typeof soundClick === 'function') soundClick();
      if (key === 'airplane' && ccState.airplane) {
        ccState.mobileData = false;
        ccState.wifi = false;
        cc.querySelector('[data-cc="mobileData"]').classList.remove('on');
        cc.querySelector('[data-cc="wifi"]').classList.remove('on');
      }
    });
  });
  const b = document.getElementById('ccBrightness');
  if (b) b.addEventListener('input', function() { ccState.brightness = parseInt(b.value, 10); });
  const v = document.getElementById('ccVolume');
  if (v) v.addEventListener('input', function() { ccState.volume = parseInt(v.value, 10); });
  const c = document.getElementById('ccCloseBtn');
  if (c) c.addEventListener('click', function() { closeControlCenter(); });
  const tOff = document.getElementById('torchOffBtn');
  if (tOff) tOff.addEventListener('click', function() {
    ccState.torch = false;
    const tile = cc.querySelector('[data-cc="torch"]');
    if (tile) tile.classList.remove('on');
    const ov = document.getElementById('torchOverlay');
    if (ov) ov.classList.add('hidden');
  });

  applyControlCenterState();
}

function applyControlCenterState() {
  const cc = document.getElementById('controlCenter');
  if (!cc) return;
  cc.querySelectorAll('.cc-tile').forEach(function(t) {
    const key = t.getAttribute('data-cc');
    if (key === 'brightness' || key === 'volume') return;
    t.classList.toggle('on', !!ccState[key]);
  });
  const b = document.getElementById('ccBrightness');
  if (b) b.value = ccState.brightness;
  const v = document.getElementById('ccVolume');
  if (v) v.value = ccState.volume;
}

function openControlCenter() {
  ensureControlCenter();
  const cc = document.getElementById('controlCenter');
  if (cc) {
    cc.classList.remove('hidden');
    applyControlCenterState();
  }
}

function closeControlCenter() {
  const cc = document.getElementById('controlCenter');
  if (cc) cc.classList.add('hidden');
}

document.addEventListener('touchstart', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  if (!e.touches || !e.touches[0]) return;
  const stage = document.getElementById('phoneStage');
  if (!stage) return;
  const rect = stage.getBoundingClientRect();
  const touchY = e.touches[0].clientY;
  if (touchY < rect.top + rect.height * 0.12) {
    phoneViewer.dataset.ccStartY = String(touchY);
  } else {
    phoneViewer.dataset.ccStartY = '';
  }
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (!phoneViewer || phoneViewer.classList.contains('hidden')) return;
  const startY = phoneViewer.dataset.ccStartY;
  if (!startY) return;
  phoneViewer.dataset.ccStartY = '';
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dy = e.changedTouches[0].clientY - parseFloat(startY);
  if (dy > 50) openControlCenter();
}, { passive: true });

/* ============================================================
   TIC TAC TOE
   ============================================================ */
let tttBoard = ['','','','','','','','',''];
let tttTurn = 'X';
let tttMode = 'pvp';
let tttGameOver = false;

function renderTicTacToe() {
  let html = '<div class="ttt-header">';
  html += '<h2 class="ttt-title">TIC TAC TOE</h2>';
  html += '<button class="ttt-mode-btn" id="tttModeBtn">' + (tttMode === 'pvp' ? '2 PLAYERS' : 'VS CPU') + '</button>';
  html += '</div>';
  html += '<div class="ttt-status" id="tttStatus">' + (tttGameOver ? '' : tttTurn + "'s TURN") + '</div>';
  html += '<div class="ttt-board" id="tttBoard">';
  for (let i = 0; i < 9; i++) {
    const cls = 'ttt-cell' + (tttBoard[i] ? ' ' + tttBoard[i].toLowerCase() : '');
    html += '<div class="' + cls + '" data-ttt="' + i + '">' + tttBoard[i] + '</div>';
  }
  html += '</div>';
  html += '<button class="ttt-reset" id="tttReset">NEW GAME</button>';
  appScreenContent.innerHTML = html;

  appScreenContent.querySelectorAll('.ttt-cell').forEach(function(cell) {
    cell.addEventListener('click', function() { tttPlay(parseInt(cell.getAttribute('data-ttt'), 10)); });
  });
  const rb = document.getElementById('tttReset');
  if (rb) rb.addEventListener('click', function() {
    tttBoard = ['','','','','','','','',''];
    tttTurn = 'X';
    tttGameOver = false;
    renderTicTacToe();
  });
  const mb = document.getElementById('tttModeBtn');
  if (mb) mb.addEventListener('click', function() {
    tttMode = tttMode === 'pvp' ? 'cpu' : 'pvp';
    tttBoard = ['','','','','','','','',''];
    tttTurn = 'X';
    tttGameOver = false;
    renderTicTacToe();
  });
}

function tttCheckWin(board) {
  const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for (let i = 0; i < lines.length; i++) {
    const a = lines[i][0], b = lines[i][1], c = lines[i][2];
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return { winner: board[a], line: lines[i] };
  }
  if (board.indexOf('') === -1) return { winner: 'draw', line: [] };
  return null;
}

function tttPlay(idx) {
  if (tttGameOver) return;
  if (tttBoard[idx] !== '') return;
  if (tttMode === 'cpu' && tttTurn === 'O') return;
  tttBoard[idx] = tttTurn;
  if (typeof soundClick === 'function') soundClick();
  const result = tttCheckWin(tttBoard);
  if (result) {
    tttGameOver = true;
    renderTicTacToe();
    if (result.winner === 'draw') {
      document.getElementById('tttStatus').textContent = "IT'S A DRAW!";
    } else {
      document.getElementById('tttStatus').textContent = result.winner + ' WINS!';
      result.line.forEach(function(i) {
        const cell = document.querySelector('[data-ttt="' + i + '"]');
        if (cell) cell.classList.add('win');
      });
      if (typeof soundWin === 'function') soundWin();
    }
    return;
  }
  tttTurn = tttTurn === 'X' ? 'O' : 'X';
  renderTicTacToe();
  if (tttMode === 'cpu' && tttTurn === 'O' && !tttGameOver) {
    setTimeout(tttCpuMove, 500);
  }
}

function tttCpuMove() {
  if (tttGameOver) return;
  const empty = [];
  for (let i = 0; i < 9; i++) if (tttBoard[i] === '') empty.push(i);
  if (empty.length === 0) return;
  for (let i = 0; i < empty.length; i++) {
    const t = tttBoard.slice();
    t[empty[i]] = 'O';
    const r = tttCheckWin(t);
    if (r && r.winner === 'O') { tttPlay(empty[i]); return; }
  }
  for (let i = 0; i < empty.length; i++) {
    const t = tttBoard.slice();
    t[empty[i]] = 'X';
    const r = tttCheckWin(t);
    if (r && r.winner === 'X') { tttPlay(empty[i]); return; }
  }
  if (tttBoard[4] === '') { tttPlay(4); return; }
  const corners = [0,2,6,8].filter(function(i) { return tttBoard[i] === ''; });
  if (corners.length) { tttPlay(corners[Math.floor(Math.random() * corners.length)]); return; }
  tttPlay(empty[Math.floor(Math.random() * empty.length)]);
}

/* Add Tic Tac Toe icon to both home screens */
(function addTicTacToeIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'X';
    el.setAttribute('data-label', 'Tic Tac Toe');
    el.style.background = 'linear-gradient(135deg,#00e5ff,#a855f7)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      tttBoard = ['','','','','','','','',''];
      tttTurn = 'X';
      tttGameOver = false;
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderTicTacToe();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();

/* Browser requires Mobile Data */
(function patchBrowser() {
  const origOpenApp = window.openApp;
  if (typeof origOpenApp !== 'function') return;
  window.openApp = function(name) {
    if (name === 'Safari' || name === 'Chrome') {
      if (!ccState.mobileData) {
        appScreenContent.innerHTML = '<div class="no-internet">' +
          '<div class="no-internet-icon">!</div>' +
          '<h2 class="no-internet-title">No Internet Connection</h2>' +
          '<p class="no-internet-msg">Turn on Mobile Data in Control Center.<br>Swipe down from the top of the screen.</p>' +
          '</div>';
        appScreen.classList.remove('hidden');
        flipCard.classList.remove('flipped');
        return;
      }
    }
    return origOpenApp.apply(this, arguments);
  };
})();
/* ============================================================
   STORE REQUIRES MOBILE DATA
   ============================================================ */
(function patchStoreInternet() {
  const originalRenderStore = window.renderStore;
  if (typeof originalRenderStore !== 'function') return;
  window.renderStore = function(name) {
    if (!ccState.mobileData) {
      let html = '<div class="no-internet">';
      html += '<div class="no-internet-icon">!</div>';
      html += '<h2 class="no-internet-title">No Internet Connection</h2>';
      html += '<p class="no-internet-msg">Turn on Mobile Data in Control Center.<br>Swipe down from the top of the screen.</p>';
      html += '</div>';
      appScreenContent.innerHTML = html;
      return;
    }
    return originalRenderStore.apply(this, arguments);
  };
})();

/* ============================================================
   SNAKE GAME
   ============================================================ */
let snakeState = {
  grid: 15,
  snake: [{ x: 7, y: 7 }],
  dir: { x: 1, y: 0 },
  nextDir: { x: 1, y: 0 },
  food: { x: 10, y: 7 },
  score: 0,
  best: parseInt(localStorage.getItem('snakeBest') || '0', 10),
  running: false,
  dead: false,
  timer: null,
  speed: 180
};

function snakeReset() {
  snakeState.snake = [{ x: 7, y: 7 }];
  snakeState.dir = { x: 1, y: 0 };
  snakeState.nextDir = { x: 1, y: 0 };
  snakeState.score = 0;
  snakeState.dead = false;
  snakeState.running = false;
  snakeState.speed = 180;
  snakePlaceFood();
  if (snakeState.timer) { clearInterval(snakeState.timer); snakeState.timer = null; }
}

function snakePlaceFood() {
  let attempts = 0;
  while (attempts < 200) {
    const fx = Math.floor(Math.random() * snakeState.grid);
    const fy = Math.floor(Math.random() * snakeState.grid);
    let onSnake = false;
    for (let i = 0; i < snakeState.snake.length; i++) {
      if (snakeState.snake[i].x === fx && snakeState.snake[i].y === fy) { onSnake = true; break; }
    }
    if (!onSnake) {
      snakeState.food = { x: fx, y: fy };
      return;
    }
    attempts++;
  }
  snakeState.food = { x: 0, y: 0 };
}

function snakeTick() {
  if (!snakeState.running) return;
  snakeState.dir = snakeState.nextDir;
  const head = snakeState.snake[0];
  const newHead = { x: head.x + snakeState.dir.x, y: head.y + snakeState.dir.y };
  if (newHead.x < 0 || newHead.x >= snakeState.grid || newHead.y < 0 || newHead.y >= snakeState.grid) {
    snakeGameOver();
    return;
  }
  for (let i = 0; i < snakeState.snake.length; i++) {
    if (snakeState.snake[i].x === newHead.x && snakeState.snake[i].y === newHead.y) {
      snakeGameOver();
      return;
    }
  }
  snakeState.snake.unshift(newHead);
  if (newHead.x === snakeState.food.x && newHead.y === snakeState.food.y) {
    snakeState.score += 10;
    if (typeof soundTap === 'function') soundTap();
    if (snakeState.snake.length > 0) {
      if (snakeState.speed > 80) snakeState.speed -= 3;
    }
    snakePlaceFood();
    snakeRestartTimer();
  } else {
    snakeState.snake.pop();
  }
  snakeRenderBoard();
}

function snakeRestartTimer() {
  if (snakeState.timer) clearInterval(snakeState.timer);
  snakeState.timer = setInterval(snakeTick, snakeState.speed);
}

function snakeGameOver() {
  snakeState.running = false;
  snakeState.dead = true;
  if (snakeState.timer) { clearInterval(snakeState.timer); snakeState.timer = null; }
  if (snakeState.score > snakeState.best) {
    snakeState.best = snakeState.score;
    localStorage.setItem('snakeBest', String(snakeState.best));
  }
  if (typeof soundWrong === 'function') soundWrong();
  snakeRenderBoard();
}

function snakeRenderBoard() {
  const board = document.getElementById('snakeBoard');
  if (!board) return;
  let html = '';
  for (let y = 0; y < snakeState.grid; y++) {
    for (let x = 0; x < snakeState.grid; x++) {
      let cls = 'snake-cell';
      for (let i = 0; i < snakeState.snake.length; i++) {
        if (snakeState.snake[i].x === x && snakeState.snake[i].y === y) {
          cls += i === 0 ? ' snake-head' : ' snake-body';
          break;
        }
      }
      if (snakeState.food.x === x && snakeState.food.y === y) cls += ' snake-food';
      html += '<div class="' + cls + '"></div>';
    }
  }
  board.innerHTML = html;
  const scoreEl = document.getElementById('snakeScore');
  if (scoreEl) scoreEl.textContent = 'SCORE: ' + snakeState.score;
  const bestEl = document.getElementById('snakeBest');
  if (bestEl) bestEl.textContent = 'BEST: ' + snakeState.best;
  const statusEl = document.getElementById('snakeStatus');
  if (statusEl) {
    if (snakeState.dead) statusEl.textContent = 'GAME OVER - Tap Start';
    else if (!snakeState.running) statusEl.textContent = 'Tap Start to play';
    else statusEl.textContent = 'Playing...';
  }
}

function renderSnake() {
  let html = '<div class="snake-header">';
  html += '<div class="snake-score" id="snakeScore">SCORE: 0</div>';
  html += '<div class="snake-best" id="snakeBest">BEST: ' + snakeState.best + '</div>';
  html += '</div>';
  html += '<div class="snake-status" id="snakeStatus">Tap Start to play</div>';
  html += '<div class="snake-board-wrap"><div class="snake-board" id="snakeBoard" style="grid-template-columns:repeat(' + snakeState.grid + ',1fr);"></div></div>';
  html += '<div class="snake-controls">';
  html += '<button class="snake-btn" id="snakeStart">START</button>';
  html += '<button class="snake-btn" id="snakeReset">RESET</button>';
  html += '</div>';
  html += '<div class="snake-dpad">';
  html += '<div></div><button class="dpad-btn" data-snake-dir="up">UP</button><div></div>';
  html += '<button class="dpad-btn" data-snake-dir="left">LEFT</button>';
  html += '<div></div>';
  html += '<button class="dpad-btn" data-snake-dir="right">RIGHT</button>';
  html += '<div></div><button class="dpad-btn" data-snake-dir="down">DOWN</button><div></div>';
  html += '</div>';

  appScreenContent.innerHTML = html;

  snakeRenderBoard();

  const startBtn = document.getElementById('snakeStart');
  if (startBtn) {
    startBtn.addEventListener('click', function() {
      if (snakeState.dead) { snakeReset(); snakeRenderBoard(); }
      snakeState.running = true;
      snakeRestartTimer();
      snakeRenderBoard();
    });
  }
  const resetBtn = document.getElementById('snakeReset');
  if (resetBtn) {
    resetBtn.addEventListener('click', function() {
      snakeReset();
      snakeRenderBoard();
    });
  }
  appScreenContent.querySelectorAll('.dpad-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const d = btn.getAttribute('data-snake-dir');
      snakeSetDir(d);
    });
  });
}

function snakeSetDir(d) {
  const cur = snakeState.dir;
  let nx = cur.x, ny = cur.y;
  if (d === 'up') { nx = 0; ny = -1; }
  else if (d === 'down') { nx = 0; ny = 1; }
  else if (d === 'left') { nx = -1; ny = 0; }
  else if (d === 'right') { nx = 1; ny = 0; }
  if (nx === -cur.x && ny === -cur.y) return;
  snakeState.nextDir = { x: nx, y: ny };
}

function snakeSwipe(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('snakeBoard')) return;
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dx = e.changedTouches[0].clientX - parseFloat(appScreen.dataset.swipeX || '0');
  const dy = e.changedTouches[0].clientY - parseFloat(appScreen.dataset.swipeY || '0');
  if (Math.abs(dx) < 20 && Math.abs(dy) < 20) return;
  if (Math.abs(dx) > Math.abs(dy)) snakeSetDir(dx > 0 ? 'right' : 'left');
  else snakeSetDir(dy > 0 ? 'down' : 'up');
}

document.addEventListener('touchstart', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('snakeBoard')) return;
  if (!e.touches || !e.touches[0]) return;
  appScreen.dataset.swipeX = String(e.touches[0].clientX);
  appScreen.dataset.swipeY = String(e.touches[0].clientY);
}, { passive: true });
document.addEventListener('touchend', snakeSwipe, { passive: true });

document.addEventListener('keydown', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('snakeBoard')) return;
  if (e.key === 'ArrowUp') { snakeSetDir('up'); e.preventDefault(); }
  if (e.key === 'ArrowDown') { snakeSetDir('down'); e.preventDefault(); }
  if (e.key === 'ArrowLeft') { snakeSetDir('left'); e.preventDefault(); }
  if (e.key === 'ArrowRight') { snakeSetDir('right'); e.preventDefault(); }
});

/* Add Snake icon to both home screens */
(function addSnakeIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'S';
    el.setAttribute('data-label', 'Snake');
    el.style.background = 'linear-gradient(135deg,#3ddc84,#00aa66)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      snakeReset();
      renderSnake();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();
/* ============================================================
   2048 GAME
   ============================================================ */
let g2048State = {
  board: [],
  score: 0,
  best: parseInt(localStorage.getItem('g2048Best') || '0', 10),
  gameOver: false,
  won: false
};

function g2048Reset() {
  g2048State.board = [];
  for (let i = 0; i < 16; i++) g2048State.board.push(0);
  g2048State.score = 0;
  g2048State.gameOver = false;
  g2048State.won = false;
  g2048AddTile();
  g2048AddTile();
}

function g2048AddTile() {
  const empty = [];
  for (let i = 0; i < 16; i++) if (g2048State.board[i] === 0) empty.push(i);
  if (empty.length === 0) return;
  const idx = empty[Math.floor(Math.random() * empty.length)];
  g2048State.board[idx] = Math.random() < 0.9 ? 2 : 4;
}

function g2048Slide(row) {
  let arr = row.filter(function(v) { return v !== 0; });
  const result = [];
  let i = 0;
  while (i < arr.length) {
    if (i + 1 < arr.length && arr[i] === arr[i+1]) {
      result.push(arr[i] * 2);
      g2048State.score += arr[i] * 2;
      if (arr[i] * 2 === 2048) g2048State.won = true;
      i += 2;
    } else {
      result.push(arr[i]);
      i++;
    }
  }
  while (result.length < 4) result.push(0);
  return result;
}

function g2048Move(dir) {
  if (g2048State.gameOver) return;
  const b = g2048State.board;
  let moved = false;
  const before = b.slice();

  if (dir === 'left' || dir === 'right') {
    for (let r = 0; r < 4; r++) {
      let row = [b[r*4], b[r*4+1], b[r*4+2], b[r*4+3]];
      if (dir === 'right') row.reverse();
      row = g2048Slide(row);
      if (dir === 'right') row.reverse();
      for (let c = 0; c < 4; c++) b[r*4+c] = row[c];
    }
  } else {
    for (let c = 0; c < 4; c++) {
      let col = [b[c], b[c+4], b[c+8], b[c+12]];
      if (dir === 'down') col.reverse();
      col = g2048Slide(col);
      if (dir === 'down') col.reverse();
      for (let r = 0; r < 4; r++) b[c+r*4] = col[r];
    }
  }

  for (let i = 0; i < 16; i++) if (before[i] !== b[i]) { moved = true; break; }
  if (moved) {
    g2048AddTile();
    if (g2048State.score > g2048State.best) {
      g2048State.best = g2048State.score;
      localStorage.setItem('g2048Best', String(g2048State.best));
    }
    if (!g2048CanMove()) g2048State.gameOver = true;
    if (typeof soundTap === 'function') soundTap();
    g2048Render();
  }
}

function g2048CanMove() {
  const b = g2048State.board;
  for (let i = 0; i < 16; i++) if (b[i] === 0) return true;
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      const v = b[r*4+c];
      if (c < 3 && b[r*4+c+1] === v) return true;
      if (r < 3 && b[(r+1)*4+c] === v) return true;
    }
  }
  return false;
}

function g2048TileClass(v) {
  if (v === 0) return 'g2048-cell empty';
  if (v <= 4) return 'g2048-cell t2';
  if (v <= 8) return 'g2048-cell t4';
  if (v <= 16) return 'g2048-cell t8';
  if (v <= 32) return 'g2048-cell t16';
  if (v <= 64) return 'g2048-cell t32';
  if (v <= 128) return 'g2048-cell t64';
  if (v <= 256) return 'g2048-cell t128';
  if (v <= 512) return 'g2048-cell t256';
  if (v <= 1024) return 'g2048-cell t512';
  return 'g2048-cell t1024';
}

function g2048Render() {
  const board = document.getElementById('g2048Board');
  if (!board) return;
  let html = '';
  for (let i = 0; i < 16; i++) {
    const v = g2048State.board[i];
    html += '<div class="' + g2048TileClass(v) + '">' + (v === 0 ? '' : v) + '</div>';
  }
  board.innerHTML = html;

  const scoreEl = document.getElementById('g2048Score');
  if (scoreEl) scoreEl.textContent = 'SCORE: ' + g2048State.score;
  const bestEl = document.getElementById('g2048Best');
  if (bestEl) bestEl.textContent = 'BEST: ' + g2048State.best;
  const statusEl = document.getElementById('g2048Status');
  if (statusEl) {
    if (g2048State.gameOver) statusEl.textContent = 'GAME OVER - Tap New Game';
    else if (g2048State.won) statusEl.textContent = 'YOU REACHED 2048! Keep going';
    else statusEl.textContent = 'Swipe to move tiles';
  }
}

function render2048() {
  let html = '<div class="g2048-header">';
  html += '<div class="g2048-score" id="g2048Score">SCORE: 0</div>';
  html += '<div class="g2048-best" id="g2048Best">BEST: ' + g2048State.best + '</div>';
  html += '</div>';
  html += '<div class="g2048-status" id="g2048Status">Swipe to move tiles</div>';
  html += '<div class="g2048-board" id="g2048Board"></div>';
  html += '<div class="g2048-controls">';
  html += '<button class="g2048-btn" id="g2048New">NEW GAME</button>';
  html += '</div>';
  html += '<div class="g2048-dpad">';
  html += '<div></div><button class="dpad-btn" data-g2048-dir="up">UP</button><div></div>';
  html += '<button class="dpad-btn" data-g2048-dir="left">LEFT</button>';
  html += '<div></div>';
  html += '<button class="dpad-btn" data-g2048-dir="right">RIGHT</button>';
  html += '<div></div><button class="dpad-btn" data-g2048-dir="down">DOWN</button><div></div>';
  html += '</div>';

  appScreenContent.innerHTML = html;

  if (g2048State.board.length === 0) g2048Reset();
  g2048Render();

  const nb = document.getElementById('g2048New');
  if (nb) nb.addEventListener('click', function() {
    g2048Reset();
    g2048Render();
  });
  appScreenContent.querySelectorAll('[data-g2048-dir]').forEach(function(b) {
    b.addEventListener('click', function() {
      g2048Move(b.getAttribute('data-g2048-dir'));
    });
  });
}

document.addEventListener('touchstart', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('g2048Board')) return;
  if (!e.touches || !e.touches[0]) return;
  appScreen.dataset.g2048X = String(e.touches[0].clientX);
  appScreen.dataset.g2048Y = String(e.touches[0].clientY);
}, { passive: true });
document.addEventListener('touchend', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('g2048Board')) return;
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const dx = e.changedTouches[0].clientX - parseFloat(appScreen.dataset.g2048X || '0');
  const dy = e.changedTouches[0].clientY - parseFloat(appScreen.dataset.g2048Y || '0');
  if (Math.abs(dx) < 25 && Math.abs(dy) < 25) return;
  if (Math.abs(dx) > Math.abs(dy)) g2048Move(dx > 0 ? 'right' : 'left');
  else g2048Move(dy > 0 ? 'down' : 'up');
}, { passive: true });

document.addEventListener('keydown', function(e) {
  if (!appScreen || appScreen.classList.contains('hidden')) return;
  if (!document.getElementById('g2048Board')) return;
  if (e.key === 'ArrowUp') { g2048Move('up'); e.preventDefault(); }
  if (e.key === 'ArrowDown') { g2048Move('down'); e.preventDefault(); }
  if (e.key === 'ArrowLeft') { g2048Move('left'); e.preventDefault(); }
  if (e.key === 'ArrowRight') { g2048Move('right'); e.preventDefault(); }
});

(function add2048Icon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = '2';
    el.setAttribute('data-label', '2048');
    el.style.background = 'linear-gradient(135deg,#ffcc00,#ff8800)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      g2048Reset();
      render2048();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();
/* ============================================================
   WHACK-A-MOLE
   ============================================================ */
let wamState = {
  activeMole: -1,
  score: 0,
  timeLeft: 30,
  running: false,
  best: parseInt(localStorage.getItem('wamBest') || '0', 10),
  moleTimer: null,
  countdownTimer: null,
  holeCount: 9
};

function wamReset() {
  if (wamState.moleTimer) clearInterval(wamState.moleTimer);
  if (wamState.countdownTimer) clearInterval(wamState.countdownTimer);
  wamState.moleTimer = null;
  wamState.countdownTimer = null;
  wamState.activeMole = -1;
  wamState.score = 0;
  wamState.timeLeft = 30;
  wamState.running = false;
}

function wamStart() {
  wamReset();
  wamState.running = true;
  wamRenderBoard();
  wamShowMole();
  wamState.moleTimer = setInterval(wamShowMole, 800);
  wamState.countdownTimer = setInterval(function() {
    wamState.timeLeft -= 1;
    const t = document.getElementById('wamTime');
    if (t) t.textContent = 'TIME: ' + wamState.timeLeft;
    if (wamState.timeLeft <= 0) wamEnd();
  }, 1000);
}

function wamShowMole() {
  if (!wamState.running) return;
  wamState.activeMole = Math.floor(Math.random() * wamState.holeCount);
  wamRenderBoard();
}

function wamWhack(idx) {
  if (!wamState.running) return;
  if (idx !== wamState.activeMole) return;
  wamState.score += 1;
  if (typeof soundTap === 'function') soundTap();
  wamState.activeMole = -1;
  wamRenderBoard();
  const s = document.getElementById('wamScore');
  if (s) s.textContent = 'SCORE: ' + wamState.score;
}

function wamEnd() {
  wamState.running = false;
  if (wamState.moleTimer) clearInterval(wamState.moleTimer);
  if (wamState.countdownTimer) clearInterval(wamState.countdownTimer);
  wamState.moleTimer = null;
  wamState.countdownTimer = null;
  if (wamState.score > wamState.best) {
    wamState.best = wamState.score;
    localStorage.setItem('wamBest', String(wamState.best));
  }
  if (typeof soundWin === 'function') soundWin();
  wamRenderBoard();
  const s = document.getElementById('wamStatus');
  if (s) s.textContent = 'GAME OVER - Final: ' + wamState.score;
  const b = document.getElementById('wamBest');
  if (b) b.textContent = 'BEST: ' + wamState.best;
}

function wamRenderBoard() {
  const board = document.getElementById('wamBoard');
  if (!board) return;
  let html = '';
  for (let i = 0; i < wamState.holeCount; i++) {
    const isActive = i === wamState.activeMole;
    html += '<div class="wam-hole' + (isActive ? ' wam-active' : '') + '" data-wam="' + i + '">';
    html += isActive ? 'M' : '';
    html += '</div>';
  }
  board.innerHTML = html;
  board.querySelectorAll('.wam-hole').forEach(function(el) {
    el.addEventListener('click', function() {
      wamWhack(parseInt(el.getAttribute('data-wam'), 10));
    });
  });
  const s = document.getElementById('wamScore');
  if (s) s.textContent = 'SCORE: ' + wamState.score;
  const t = document.getElementById('wamTime');
  if (t) t.textContent = 'TIME: ' + wamState.timeLeft;
  const b = document.getElementById('wamBest');
  if (b) b.textContent = 'BEST: ' + wamState.best;
}

function renderWhackAMole() {
  let html = '<div class="wam-header">';
  html += '<div class="wam-score" id="wamScore">SCORE: 0</div>';
  html += '<div class="wam-best" id="wamBest">BEST: ' + wamState.best + '</div>';
  html += '</div>';
  html += '<div class="wam-status" id="wamStatus">Tap Start to play</div>';
  html += '<div class="wam-time" id="wamTime">TIME: 30</div>';
  html += '<div class="wam-board" id="wamBoard"></div>';
  html += '<div class="wam-controls">';
  html += '<button class="wam-btn" id="wamStart">START</button>';
  html += '<button class="wam-btn" id="wamReset">RESET</button>';
  html += '</div>';
  appScreenContent.innerHTML = html;

  wamRenderBoard();

  const sb = document.getElementById('wamStart');
  if (sb) sb.addEventListener('click', function() { wamStart(); });
  const rb = document.getElementById('wamReset');
  if (rb) rb.addEventListener('click', function() {
    wamReset();
    wamRenderBoard();
    const s = document.getElementById('wamStatus');
    if (s) s.textContent = 'Tap Start to play';
    const t = document.getElementById('wamTime');
    if (t) t.textContent = 'TIME: 30';
  });
}

(function addWamIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'W';
    el.setAttribute('data-label', 'Whack');
    el.style.background = 'linear-gradient(135deg,#ff006e,#a855f7)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      wamReset();
      renderWhackAMole();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();
/* ============================================================
   GAMES FOLDER + MEMORY MATCH + ROCK PAPER SCISSORS
   ============================================================ */

/* Remove the individual game icons from home screens */
(function removeGameIcons() {
  const removeByLabel = function(containerId, labels) {
    const c = document.getElementById(containerId);
    if (!c) return;
    const icons = c.querySelectorAll('.app');
    icons.forEach(function(el) {
      const lbl = el.getAttribute('data-label');
      if (lbl && labels.indexOf(lbl) !== -1) el.remove();
    });
  };
  const toRemove = ['Tic Tac Toe', 'Snake', '2048', 'Whack'];
  removeByLabel('iphoneIcons', toRemove);
  removeByLabel('androidIcons', toRemove);
})();

/* Memory Match state */
let memState = {
  cards: [],
  flipped: [],
  matched: 0,
  moves: 0,
  lock: false,
  totalPairs: 8
};

function memReset() {
  const symbols = ['A','B','C','D','E','F','G','H'];
  const deck = symbols.concat(symbols);
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = deck[i]; deck[i] = deck[j]; deck[j] = t;
  }
  memState.cards = deck;
  memState.flipped = [];
  memState.matched = 0;
  memState.moves = 0;
  memState.lock = false;
}

function memRender() {
  const board = document.getElementById('memBoard');
  if (!board) return;
  let html = '';
  for (let i = 0; i < memState.cards.length; i++) {
    const isFlipped = memState.flipped.indexOf(i) !== -1;
    const isMatched = memState.matchedCards && memState.matchedCards.indexOf(i) !== -1;
    let cls = 'mem-card';
    if (isFlipped || isMatched) cls += ' mem-open';
    html += '<div class="' + cls + '" data-mem="' + i + '">';
    html += (isFlipped || isMatched) ? memState.cards[i] : '?';
    html += '</div>';
  }
  board.innerHTML = html;
  const movesEl = document.getElementById('memMoves');
  if (movesEl) movesEl.textContent = 'MOVES: ' + memState.moves;
  const pairsEl = document.getElementById('memPairs');
  if (pairsEl) pairsEl.textContent = 'PAIRS: ' + memState.matched + '/' + memState.totalPairs;
  board.querySelectorAll('.mem-card').forEach(function(el) {
    el.addEventListener('click', function() {
      memFlip(parseInt(el.getAttribute('data-mem'), 10));
    });
  });
}

function memFlip(idx) {
  if (memState.lock) return;
  if (memState.flipped.indexOf(idx) !== -1) return;
  if (!memState.matchedCards) memState.matchedCards = [];
  if (memState.matchedCards.indexOf(idx) !== -1) return;
  memState.flipped.push(idx);
  if (typeof soundTap === 'function') soundTap();
  memRender();
  if (memState.flipped.length === 2) {
    memState.moves += 1;
    memState.lock = true;
    const a = memState.flipped[0];
    const b = memState.flipped[1];
    if (memState.cards[a] === memState.cards[b]) {
      memState.matchedCards.push(a, b);
      memState.matched += 1;
      memState.flipped = [];
      memState.lock = false;
      memRender();
      if (memState.matched === memState.totalPairs) {
        if (typeof soundWin === 'function') soundWin();
        const s = document.getElementById('memStatus');
        if (s) s.textContent = 'YOU WON in ' + memState.moves + ' moves!';
      }
    } else {
      setTimeout(function() {
        memState.flipped = [];
        memState.lock = false;
        memRender();
      }, 800);
    }
  }
}

function renderMemory() {
  if (!memState.cards.length || memState.matched === memState.totalPairs) {
    memReset();
    memState.matchedCards = [];
  }
  let html = '<div class="mem-header">';
  html += '<div class="mem-moves" id="memMoves">MOVES: 0</div>';
  html += '<div class="mem-pairs" id="memPairs">PAIRS: 0/8</div>';
  html += '</div>';
  html += '<div class="mem-status" id="memStatus">Match all pairs</div>';
  html += '<div class="mem-board" id="memBoard"></div>';
  html += '<button class="mem-btn" id="memNew">NEW GAME</button>';
  appScreenContent.innerHTML = html;
  memRender();
  const nb = document.getElementById('memNew');
  if (nb) nb.addEventListener('click', function() {
    memReset();
    memState.matchedCards = [];
    renderMemory();
  });
}

/* Rock Paper Scissors state */
let rpsState = {
  playerScore: 0,
  cpuScore: 0,
  round: 1,
  maxRounds: 3,
  finished: false
};

function rpsReset() {
  rpsState.playerScore = 0;
  rpsState.cpuScore = 0;
  rpsState.round = 1;
  rpsState.finished = false;
}

function rpsPlay(player) {
  if (rpsState.finished) return;
  const opts = ['Rock', 'Paper', 'Scissors'];
  const cpu = opts[Math.floor(Math.random() * 3)];
  let result = '';
  if (player === cpu) result = 'DRAW';
  else if ((player === 'Rock' && cpu === 'Scissors') ||
           (player === 'Paper' && cpu === 'Rock') ||
           (player === 'Scissors' && cpu === 'Paper')) {
    result = 'YOU WIN';
    rpsState.playerScore += 1;
  } else {
    result = 'CPU WINS';
    rpsState.cpuScore += 1;
  }
  if (typeof soundTap === 'function') soundTap();
  const resultEl = document.getElementById('rpsResult');
  if (resultEl) {
    resultEl.innerHTML = 'You: <b>' + player + '</b> - CPU: <b>' + cpu + '</b><br>' + result;
  }
  const ps = document.getElementById('rpsPlayer');
  if (ps) ps.textContent = 'YOU: ' + rpsState.playerScore;
  const cs = document.getElementById('rpsCpu');
  if (cs) cs.textContent = 'CPU: ' + rpsState.cpuScore;
  if (rpsState.round >= rpsState.maxRounds || rpsState.playerScore >= 2 || rpsState.cpuScore >= 2) {
    rpsState.finished = true;
    let msg = '';
    if (rpsState.playerScore > rpsState.cpuScore) msg = 'YOU WIN THE MATCH!';
    else if (rpsState.cpuScore > rpsState.playerScore) msg = 'CPU WINS THE MATCH';
    else msg = 'MATCH DRAW';
    if (typeof soundWin === 'function') soundWin();
    const res = document.getElementById('rpsResult');
    if (res) res.innerHTML = msg;
  } else {
    rpsState.round += 1;
    const rd = document.getElementById('rpsRound');
    if (rd) rd.textContent = 'ROUND ' + rpsState.round + ' of ' + rpsState.maxRounds;
  }
}

function renderRPS() {
  rpsReset();
  let html = '<div class="rps-header">';
  html += '<div class="rps-score" id="rpsPlayer">YOU: 0</div>';
  html += '<div class="rps-round" id="rpsRound">ROUND 1 of 3</div>';
  html += '<div class="rps-score-cpu" id="rpsCpu">CPU: 0</div>';
  html += '</div>';
  html += '<div class="rps-result" id="rpsResult">Pick your move</div>';
  html += '<div class="rps-buttons">';
  html += '<button class="rps-btn" data-rps="Rock">ROCK</button>';
  html += '<button class="rps-btn" data-rps="Paper">PAPER</button>';
  html += '<button class="rps-btn" data-rps="Scissors">SCISSORS</button>';
  html += '</div>';
  html += '<button class="rps-new" id="rpsNew">NEW MATCH</button>';
  appScreenContent.innerHTML = html;
  appScreenContent.querySelectorAll('[data-rps]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      rpsPlay(btn.getAttribute('data-rps'));
    });
  });
  const nb = document.getElementById('rpsNew');
  if (nb) nb.addEventListener('click', function() { renderRPS(); });
}

/* Games folder */
const GAMES_LIST = [
  { name: 'Tic Tac Toe', emoji: 'X', color: 'linear-gradient(135deg,#00e5ff,#a855f7)' },
  { name: 'Snake', emoji: 'S', color: 'linear-gradient(135deg,#3ddc84,#00aa66)' },
  { name: '2048', emoji: '2', color: 'linear-gradient(135deg,#ffcc00,#ff8800)' },
  { name: 'Whack', emoji: 'W', color: 'linear-gradient(135deg,#ff006e,#a855f7)' },
  { name: 'Memory', emoji: 'M', color: 'linear-gradient(135deg,#1a88ff,#0066ff)' },
  { name: 'RPS', emoji: 'R', color: 'linear-gradient(135deg,#ffcc00,#ff6600)' }
];

function openGame(name) {
  if (typeof soundTap === 'function') soundTap();
  appScreen.classList.remove('hidden');
  flipCard.classList.remove('flipped');
  if (name === 'Tic Tac Toe') {
    tttBoard = ['','','','','','','','',''];
    tttTurn = 'X';
    tttGameOver = false;
    renderTicTacToe();
  } else if (name === 'Snake') {
    snakeReset();
    renderSnake();
  } else if (name === '2048') {
    g2048Reset();
    render2048();
  } else if (name === 'Whack') {
    wamReset();
    renderWhackAMole();
  } else if (name === 'Memory') {
    memReset();
    memState.matchedCards = [];
    renderMemory();
  } else if (name === 'RPS') {
    renderRPS();
  }
}

function renderGamesFolder() {
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">GAMES</h2>';
  html += '<div class="games-grid">';
  GAMES_LIST.forEach(function(g) {
    html += '<div class="games-tile" data-game="' + g.name + '">';
    html += '<div class="games-icon" style="background:' + g.color + ';">' + g.emoji + '</div>';
    html += '<div class="games-label">' + g.name + '</div>';
    html += '</div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
  appScreenContent.querySelectorAll('.games-tile').forEach(function(t) {
    t.addEventListener('click', function() {
      openGame(t.getAttribute('data-game'));
    });
  });
}

/* Add Games folder icon to both home screens */
(function addGamesFolderIcon() {
  const makeIcon = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'G';
    el.setAttribute('data-label', 'Games');
    el.style.background = 'linear-gradient(135deg,#1a88ff,#a855f7)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderGamesFolder();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) ip.appendChild(makeIcon());
  if (an) an.appendChild(makeIcon());
})();

/* Route folder games from openApp */
(function patchOpenAppForGames() {
  const orig = window.openApp;
  if (typeof orig !== 'function') return;
  window.openApp = function(name) {
    if (name === 'Games') { renderGamesFolder(); return; }
    if (name === 'Memory') { memReset(); memState.matchedCards = []; renderMemory(); return; }
    if (name === 'RPS') { renderRPS(); return; }
    return orig.apply(this, arguments);
  };
})();
/* ============================================================
   CLOCK APP (live time + stopwatch)
   ============================================================ */
let clockState = {
  swRunning: false,
  swElapsed: 0,
  swStartedAt: 0,
  clockTimer: null,
  swTimer: null
};

function clockFormatTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  const cs = Math.floor((ms % 1000) / 10);
  return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0') + '.' + String(cs).padStart(2, '0');
}

function clockUpdateLive() {
  const el = document.getElementById('clockLive');
  if (!el) return;
  const now = new Date();
  const h = now.getHours();
  const m = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');
  const h12 = h % 12 || 12;
  const ampm = h < 12 ? 'AM' : 'PM';
  el.textContent = h12 + ':' + m + ':' + s + ' ' + ampm;
  const dateEl = document.getElementById('clockDate');
  if (dateEl) {
    const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    dateEl.textContent = days[now.getDay()] + ', ' + months[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear();
  }
}

function clockUpdateStopwatch() {
  const el = document.getElementById('clockStopwatch');
  if (!el) return;
  let ms = clockState.swElapsed;
  if (clockState.swRunning) ms += (Date.now() - clockState.swStartedAt);
  el.textContent = clockFormatTime(ms);
}

function renderClock() {
  if (clockState.clockTimer) clearInterval(clockState.clockTimer);
  if (clockState.swTimer) clearInterval(clockState.swTimer);

  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 20px;">Clock</h2>';
  html += '<div class="clock-live-wrap">';
  html += '<div class="clock-live" id="clockLive">--:--:--</div>';
  html += '<div class="clock-date" id="clockDate">Loading...</div>';
  html += '</div>';
  html += '<div class="clock-sw-title">STOPWATCH</div>';
  html += '<div class="clock-stopwatch" id="clockStopwatch">00:00.00</div>';
  html += '<div class="clock-sw-buttons">';
  html += '<button class="clock-btn start" id="clockStart">START</button>';
  html += '<button class="clock-btn" id="clockReset">RESET</button>';
  html += '</div>';

  appScreenContent.innerHTML = html;

  clockUpdateLive();
  clockUpdateStopwatch();

  clockState.clockTimer = setInterval(clockUpdateLive, 1000);
  clockState.swTimer = setInterval(clockUpdateStopwatch, 50);

  const startBtn = document.getElementById('clockStart');
  if (startBtn) {
    startBtn.addEventListener('click', function() {
      if (typeof soundClick === 'function') soundClick();
      if (clockState.swRunning) {
        clockState.swElapsed += (Date.now() - clockState.swStartedAt);
        clockState.swRunning = false;
        startBtn.textContent = 'START';
        startBtn.classList.remove('pause');
        startBtn.classList.add('start');
      } else {
        clockState.swStartedAt = Date.now();
        clockState.swRunning = true;
        startBtn.textContent = 'PAUSE';
        startBtn.classList.remove('start');
        startBtn.classList.add('pause');
      }
    });
  }
  const resetBtn = document.getElementById('clockReset');
  if (resetBtn) {
    resetBtn.addEventListener('click', function() {
      if (typeof soundClick === 'function') soundClick();
      clockState.swRunning = false;
      clockState.swElapsed = 0;
      clockUpdateStopwatch();
      const s = document.getElementById('clockStart');
      if (s) { s.textContent = 'START'; s.classList.remove('pause'); s.classList.add('start'); }
    });
  }
}

/* ============================================================
   WEATHER APP (fake data)
   ============================================================ */
const WEATHER_CITIES = [
  { name: 'Lagos', temp: 31, condition: 'Sunny', humidity: 78, wind: 12 },
  { name: 'Abuja', temp: 29, condition: 'Cloudy', humidity: 65, wind: 8 },
  { name: 'New York', temp: 15, condition: 'Rainy', humidity: 82, wind: 20 },
  { name: 'London', temp: 11, condition: 'Foggy', humidity: 88, wind: 15 }
];

function renderWeather() {
  let html = '<h2 style="font-size:18px;letter-spacing:2px;color:#00e5ff;margin:0 0 16px;">Weather</h2>';
  html += '<div class="weather-list">';
  WEATHER_CITIES.forEach(function(city, i) {
    html += '<div class="weather-card" data-weather="' + i + '">';
    html += '<div class="weather-city">' + city.name + '</div>';
    html += '<div class="weather-temp">' + city.temp + '°C</div>';
    html += '<div class="weather-cond">' + city.condition + '</div>';
    html += '<div class="weather-details">Humidity ' + city.humidity + '% · Wind ' + city.wind + ' km/h</div>';
    html += '</div>';
  });
  html += '</div>';
  appScreenContent.innerHTML = html;
}

/* Add Clock + Weather icons to both home screens */
(function addClockWeatherIcons() {
  const makeClock = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'C';
    el.setAttribute('data-label', 'Clock');
    el.style.background = 'linear-gradient(135deg,#555,#222)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderClock();
    });
    return el;
  };
  const makeWeather = function() {
    const el = document.createElement('div');
    el.className = 'app';
    el.textContent = 'W';
    el.setAttribute('data-label', 'Weather');
    el.style.background = 'linear-gradient(135deg,#00e5ff,#0088ff)';
    el.style.color = '#fff';
    el.style.fontWeight = '900';
    el.addEventListener('click', function() {
      if (typeof soundTap === 'function') soundTap();
      appScreen.classList.remove('hidden');
      flipCard.classList.remove('flipped');
      renderWeather();
    });
    return el;
  };
  const ip = document.getElementById('iphoneIcons');
  const an = document.getElementById('androidIcons');
  if (ip) { ip.appendChild(makeClock()); ip.appendChild(makeWeather()); }
  if (an) { an.appendChild(makeClock()); an.appendChild(makeWeather()); }
})();

/* Route Clock/Weather in openApp */
(function patchOpenAppForClockWeather() {
  const orig = window.openApp;
  if (typeof orig !== 'function') return;
  window.openApp = function(name) {
    if (name === 'Clock') { renderClock(); return; }
    if (name === 'Weather') { renderWeather(); return; }
    return orig.apply(this, arguments);
  };
})();