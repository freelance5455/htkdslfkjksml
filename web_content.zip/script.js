(function () {
  "use strict";

  /* =====================================================================
   * تنظیمات
   * ---------------------------------------------------------------------
   * مرورگر نمی‌تواند تونل VPN بسازد. دکمه وسط صفحه از طریق یک «موتور اتصال»
   * کار می‌کند. به‌صورت پیش‌فرض DEMO_MODE روشن است تا ظاهر دکمه (روشن/خاموش)
   * را ببینید؛ در این حالت هیچ ترافیکی از تونل رد نمی‌شود و صفحه این را
   * صریحاً نشان می‌دهد.
   *
   * برای اتصال واقعی، قبل از این اسکریپت یک موتور تعریف کنید:
   *   window.PARSNET_ENGINE = {
   *     async connect(server) { ... },   // server.link, server.host, ...
   *     async disconnect() { ... }
   *   };
   * و DEMO_MODE را false کنید.
   * ===================================================================== */
  const DEMO_MODE = true;

  const demoEngine = {
    connect: () => new Promise((res) => setTimeout(res, 1500)),
    disconnect: () => Promise.resolve()
  };
  const missingEngine = {
    connect: () => Promise.reject(new Error("موتور اتصال هنوز به این نسخه متصل نشده است.")),
    disconnect: () => Promise.resolve()
  };
  const engine = window.PARSNET_ENGINE || (DEMO_MODE ? demoEngine : missingEngine);
  const isDemo = !window.PARSNET_ENGINE && DEMO_MODE;

  /* ---------- Storage (localStorage with in-memory fallback) ---------- */
  const mem = {};
  const store = {
    get(k, def) {
      try { const v = localStorage.getItem(k); if (v !== null) return JSON.parse(v); } catch (e) {}
      return k in mem ? mem[k] : def;
    },
    set(k, v) {
      mem[k] = v;
      try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
    }
  };

  /* ---------- State ---------- */
  let catalog = store.get("parsnet_catalog", []);
  let announcement = store.get("parsnet_announcement", "به پارس‌نت خوش آمدید");
  let adText = store.get("parsnet_ad", "");
  let admin = store.get("parsnet_admin", { name: "admin", password: "change-this-password" });
  let selectedId = null;
  let adminLogged = false;
  let vpnState = "off"; // off | connecting | on | error
  let connectToken = 0;
  let timerId = null;
  let connectedAt = 0;

  const $ = (id) => document.getElementById(id);
  const faNum = (n) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(16).slice(2));

  /* ---------- Link parsing ---------- */
  function b64decode(s) {
    s = s.replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4) s += "=";
    return decodeURIComponent(escape(atob(s)));
  }

  function parseLink(input, customName) {
    const link = (input || "").trim();
    if (!link || !link.includes("://")) return null;
    const scheme = link.split("://")[0].toLowerCase();
    const map = { vless: "VLESS", vmess: "VMESS", trojan: "TROJAN", ss: "SHADOWSOCKS", shadowsocks: "SHADOWSOCKS" };
    const protocol = map[scheme];
    if (!protocol) return null;

    let host = "", port = 0, name = "";
    try {
      if (protocol === "VMESS") {
        const j = JSON.parse(b64decode(link.slice(link.indexOf("://") + 3).split("#")[0]));
        host = j.add || ""; port = parseInt(j.port, 10) || 0; name = j.ps || "";
      } else {
        const rest = link.slice(link.indexOf("://") + 3);
        if (rest.includes("#")) name = decodeURIComponent(rest.slice(rest.indexOf("#") + 1));
        let body = rest.split("#")[0].split("?")[0];
        if (protocol === "SHADOWSOCKS" && !body.includes("@")) body = b64decode(body);
        const hp = body.includes("@") ? body.slice(body.lastIndexOf("@") + 1) : body;
        const m = hp.match(/^\[?([^\]]+?)\]?:(\d+)\/?$/);
        if (m) { host = m[1]; port = parseInt(m[2], 10); }
        else { host = hp.replace(/\/$/, ""); }
        if (!name) {
          const qs = link.split("?")[1] ? link.split("?")[1].split("#")[0] : "";
          name = new URLSearchParams(qs).get("remarks") || "";
        }
      }
    } catch (e) { /* keep whatever was parsed */ }

    return {
      id: uid(),
      name: (customName || "").trim() || name || host || protocol,
      link, protocol, host, port, enabled: true
    };
  }

  /* ---------- Catalog ---------- */
  function save() { store.set("parsnet_catalog", catalog); }
  function publish(cfg) {
    catalog = catalog.filter((c) => c.link !== cfg.link);
    catalog.unshift(cfg);
    save();
  }

  /* ---------- Status helpers ---------- */
  function setStatus(text, warn) {
    const el = $("status");
    el.textContent = text;
    el.classList.toggle("warn", !!warn);
  }

  const idleStatus = "سرورهای منتشرشده توسط مدیریت";
  const demoNote = "حالت نمایشی: ظاهر اتصال را می‌بینید، اما ترافیکی از تونل عبور نمی‌کند.";

  /* ---------- Power button / VPN state ---------- */
  function selectedServer() { return catalog.find((c) => c.id === selectedId && c.enabled); }

  function fmtTime(sec) {
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return faNum([h, m, s].map((n) => String(n).padStart(2, "0")).join(":"));
  }
  function tick() { $("timer").textContent = fmtTime(Math.floor((Date.now() - connectedAt) / 1000)); }

  function paintVpn() {
    const btn = $("powerBtn");
    btn.dataset.state = vpnState;
    btn.setAttribute("aria-pressed", vpnState === "on" ? "true" : "false");
    btn.setAttribute("aria-label",
      vpnState === "on" ? "قطع اتصال" : vpnState === "connecting" ? "لغو اتصال" : "اتصال به سرور");
    document.querySelector(".readout").dataset.state = vpnState;
    $("stateText").textContent =
      { off: "قطع", connecting: "در حال اتصال…", on: "متصل", error: "اتصال برقرار نشد" }[vpnState];
    $("timer").hidden = vpnState !== "on";

    const s = selectedServer();
    $("chosen").textContent = s ? "سرور: " + s.name : "سروری انتخاب نشده";
  }

  async function goOnline() {
    const s = selectedServer();
    if (!s) { setStatus("ابتدا یک سرور از فهرست انتخاب کنید.", true); return; }
    const token = ++connectToken;
    vpnState = "connecting";
    setStatus("در حال برقراری اتصال به " + s.name + "…");
    paintVpn();
    try {
      await engine.connect(s);
      if (token !== connectToken) return; // cancelled
      vpnState = "on";
      connectedAt = Date.now();
      tick();
      clearInterval(timerId);
      timerId = setInterval(tick, 1000);
      setStatus(isDemo ? demoNote : "اتصال برقرار است.");
    } catch (err) {
      if (token !== connectToken) return;
      vpnState = "error";
      setStatus(err && err.message ? err.message : "اتصال برقرار نشد.", true);
    }
    paintVpn();
  }

  async function goOffline(message) {
    connectToken++;
    clearInterval(timerId);
    const wasOn = vpnState === "on";
    vpnState = "off";
    setStatus(message || (wasOn ? "اتصال قطع شد." : idleStatus));
    paintVpn();
    try { await engine.disconnect(); } catch (e) {}
  }

  $("powerBtn").addEventListener("click", () => {
    if (vpnState === "on" || vpnState === "connecting") goOffline();
    else goOnline();
  });

  /* ---------- Rendering ---------- */
  function renderMain() {
    $("announcement").textContent = announcement;
    const ad = $("adText");
    ad.textContent = adText;
    ad.hidden = !adText.trim();

    const active = catalog.filter((c) => c.enabled);
    $("count").textContent = faNum(active.length) + " سرور فعال";

    if (selectedId && !active.some((c) => c.id === selectedId)) {
      selectedId = null;
      if (vpnState !== "off") goOffline("سرور انتخاب‌شده دیگر در دسترس نیست.");
    }

    const list = $("list");
    list.replaceChildren();
    if (!active.length) {
      const p = document.createElement("div");
      p.className = "empty";
      p.textContent = "فعلاً سرور فعالی منتشر نشده است.";
      list.appendChild(p);
    }
    active.forEach((s) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "server" + (s.id === selectedId ? " selected" : "");
      b.setAttribute("role", "radio");
      b.setAttribute("aria-checked", s.id === selectedId ? "true" : "false");
      b.innerHTML = '<span class="badge"></span><span class="info"><span class="name" style="display:block"></span><span class="meta" style="display:block"></span></span><span class="tick"></span>';
      b.querySelector(".badge").textContent = s.protocol;
      b.querySelector(".name").textContent = s.name;
      b.querySelector(".meta").textContent = s.host + ":" + s.port;
      b.addEventListener("click", () => {
        if (vpnState === "on" || vpnState === "connecting") {
          if (s.id !== selectedId) setStatus("برای تغییر سرور، ابتدا اتصال را قطع کنید.", true);
          return;
        }
        selectedId = s.id;
        if (vpnState === "error") { vpnState = "off"; }
        setStatus(idleStatus);
        renderMain();
      });
      list.appendChild(b);
    });
    paintVpn();
  }

  function renderAdminList() {
    const box = $("adminList");
    box.replaceChildren();
    catalog.forEach((s) => {
      const row = document.createElement("div");
      row.className = "admin-item";
      const cb = document.createElement("input");
      cb.type = "checkbox"; cb.checked = s.enabled;
      cb.setAttribute("aria-label", "فعال بودن " + s.name);
      cb.addEventListener("change", () => { s.enabled = cb.checked; save(); renderMain(); });
      const label = document.createElement("span");
      label.textContent = s.name;
      const del = document.createElement("button");
      del.type = "button"; del.textContent = "حذف";
      del.setAttribute("aria-label", "حذف " + s.name);
      del.addEventListener("click", () => {
        catalog = catalog.filter((c) => c.id !== s.id);
        save(); renderAdminList(); renderMain();
      });
      row.append(cb, label, del);
      box.appendChild(row);
    });
  }

  /* ---------- Admin dialog ---------- */
  const dlg = $("adminDialog");

  function showAdminView() {
    $("loginView").hidden = adminLogged;
    $("panelView").hidden = !adminLogged;
    $("dlgTitle").textContent = adminLogged ? "پنل مدیریت PARSNET" : "ورود مدیر";
    if (adminLogged) {
      $("annInput").value = announcement;
      $("adInput").value = adText;
      $("newAdminName").value = admin.name;
      $("newAdminPass").value = "";
      renderAdminList();
    }
  }

  $("adminBtn").addEventListener("click", () => { showAdminView(); dlg.showModal(); });
  dlg.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => dlg.close()));
  dlg.addEventListener("close", () => { adminLogged = false; });

  function doLogin() {
    if ($("loginName").value === admin.name && $("loginPass").value === admin.password) {
      adminLogged = true;
      $("loginName").value = ""; $("loginPass").value = "";
      $("loginError").textContent = "";
      showAdminView();
    } else {
      $("loginError").textContent = "نام کاربری یا رمز اشتباه است.";
    }
  }
  $("loginBtn").addEventListener("click", doLogin);
  $("loginPass").addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });

  document.querySelectorAll(".tabs button").forEach((tabBtn) => {
    tabBtn.addEventListener("click", () => {
      const i = tabBtn.dataset.tab;
      document.querySelectorAll(".tabs button").forEach((b) => b.setAttribute("aria-selected", b === tabBtn ? "true" : "false"));
      document.querySelectorAll("[data-pane]").forEach((p) => { p.hidden = p.dataset.pane !== i; });
    });
  });

  $("publishBtn").addEventListener("click", () => {
    const cfg = parseLink($("newLink").value, $("newName").value);
    if (!cfg) { setStatus("لینک معتبر VLESS/VMess/Trojan/SS وارد کنید.", true); return; }
    publish(cfg);
    $("newName").value = ""; $("newLink").value = "";
    setStatus("سرور برای فهرست محلی منتشر شد.");
    renderAdminList(); renderMain();
  });

  $("importBtn").addEventListener("click", () => $("fileInput").click());
  $("fileInput").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const parsed = String(reader.result).split(/\r?\n/).map((l) => parseLink(l)).filter(Boolean);
      parsed.forEach(publish);
      setStatus(faNum(parsed.length) + " کانفیگ به فهرست سرورها اضافه شد.");
      renderAdminList(); renderMain();
    };
    reader.readAsText(file);
    e.target.value = "";
  });

  $("annInput").addEventListener("input", (e) => { announcement = e.target.value; store.set("parsnet_announcement", announcement); renderMain(); });
  $("adInput").addEventListener("input", (e) => { adText = e.target.value; store.set("parsnet_ad", adText); renderMain(); });

  $("saveAccountBtn").addEventListener("click", () => {
    const n = $("newAdminName").value.trim(), p = $("newAdminPass").value;
    if (!n || !p) { setStatus("نام کاربری و رمز جدید را وارد کنید.", true); return; }
    admin = { name: n, password: p };
    store.set("parsnet_admin", admin);
    setStatus("اطلاعات حساب مدیر ذخیره شد.");
    $("newAdminPass").value = "";
  });

  renderMain();
})();
