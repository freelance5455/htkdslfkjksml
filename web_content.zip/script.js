/* Пули ман — ҳисобкунии даромад, хароҷот ва статистика */
(() => {
  "use strict";
  const STORAGE_KEY = "pulMan_transactions_v1";
  const THEME_KEY = "pulMan_theme_v1";
  const SHOPPING_KEY = "pulMan_future_shopping_v1";
  const money = n => `${Number(n || 0).toLocaleString("tg-TJ",{minimumFractionDigits:2,maximumFractionDigits:2})} <small>с.</small>`;
  const plainMoney = n => `${Number(n || 0).toLocaleString("tg-TJ",{minimumFractionDigits:2,maximumFractionDigits:2})} с.`;
  const dateLabel = value => {
    const d = new Date(value);
    return d.toLocaleString("tg-TJ",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"});
  };
  const dayKey = value => {
    const d = new Date(value);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  };
  const getTransactions = () => {
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  };
  const saveTransactions = data => localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  const makeId = () => {
    try { if (globalThis.crypto && typeof globalThis.crypto.randomUUID === "function") return globalThis.crypto.randomUUID(); } catch {}
    return `tx_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  };
  const PROFILE_KEY = "pulMan_profile_v1";
  const getProfile = () => { try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || "null"); } catch { return null; } };
  const saveProfile = profile => localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  function renderProfile() {
    const profile = getProfile();
    const name = profile?.name || "Ҳисоби шахсӣ";
    document.querySelectorAll("[data-profile-name]").forEach(el => el.textContent = name);
    document.querySelectorAll("[data-profile-avatar]").forEach(el => {
      if (profile?.photo) { el.textContent = ""; el.style.backgroundImage = `url("${profile.photo}")`; el.classList.add("has-photo"); }
      else { el.style.backgroundImage = ""; el.classList.remove("has-photo"); el.textContent = name === "Ҳисоби шахсӣ" ? "👤" : [...name][0].toLocaleUpperCase("tg"); }
    });
    const nameInput = document.getElementById("profileName");
    if (nameInput && profile?.name) nameInput.value = profile.name;
    const jobInput = document.getElementById("profileJob");
    if (jobInput && profile?.job) jobInput.value = profile.job;
    const bioInput = document.getElementById("profileBio");
    if (bioInput && profile?.bio) bioInput.value = profile.bio;
    const preview = document.getElementById("profilePhotoPreview");
    if (preview) {
      preview.style.backgroundImage = profile?.photo ? `url("${profile.photo}")` : "";
      preview.textContent = profile?.photo ? "" : (profile?.name ? [...profile.name][0].toLocaleUpperCase("tg") : "👤");
    }
  }
  function showModal(id) {
    const modal = document.getElementById(id);
    if (modal) { modal.classList.remove("hidden"); modal.setAttribute("aria-hidden","false"); }
  }
  function hideModal(id) {
    const modal = document.getElementById(id);
    if (modal) { modal.classList.add("hidden"); modal.setAttribute("aria-hidden","true"); }
  }
  function initProfile() {
    const existing = getProfile();
    const form = document.getElementById("profileForm");
    if (form) form.addEventListener("submit", async e => {
      e.preventDefault();
      const name = document.getElementById("profileName")?.value.trim();
      if (!name) { showToast("Лутфан номро навис."); return; }
      const old = getProfile() || {};
      let photo = old.photo || "";
      const file = document.getElementById("profilePhoto")?.files?.[0];
      if (file) {
        if (!file.type.startsWith("image/")) { showToast("Файл бояд акс бошад."); return; }
        if (file.size > 8*1024*1024) { showToast("Акс бояд аз 8 MB хурд бошад."); return; }
        try { photo = await resizePhoto(file); } catch { showToast("Акс хонда нашуд. Акси дигарро интихоб кун."); return; }
      }
      saveProfile({name, job:document.getElementById("profileJob")?.value.trim() || "", bio:document.getElementById("profileBio")?.value.trim() || "", photo});
      renderProfile(); hideModal("profileModal"); showToast("Профил сабт шуд.");
    });
    document.getElementById("editProfile")?.addEventListener("click", () => { renderProfile(); showModal("profileModal"); });
    document.getElementById("cancelProfile")?.addEventListener("click", () => hideModal("profileModal"));
    document.getElementById("profilePhoto")?.addEventListener("change", async e => {
      const file=e.target.files?.[0]; if(!file)return;
      if(!file.type.startsWith("image/") || file.size>8*1024*1024){showToast("Акс бояд тасвир ва камтар аз 8 MB бошад.");e.target.value="";return;}
      try { const data=await resizePhoto(file), preview=document.getElementById("profilePhotoPreview"); if(preview){preview.style.backgroundImage=`url("${data}")`;preview.textContent="";} }
      catch { showToast("Акс хонда нашуд."); }
    });
    renderProfile();
    if (!existing?.name) showModal("profileModal");
  }
  function resizePhoto(file) {
    return new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onerror=()=>reject(new Error("photo read failed"));
      reader.onload=()=>{
        const img=new Image();
        img.onerror=()=>reject(new Error("invalid image"));
        img.onload=()=>{
          const max=320, scale=Math.min(1,max/Math.max(img.width,img.height));
          const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));
          const ctx=canvas.getContext("2d");ctx.drawImage(img,0,0,canvas.width,canvas.height);
          resolve(canvas.toDataURL("image/jpeg",.78));
        };
        img.src=reader.result;
      };
      reader.readAsDataURL(file);
    });
  }
  function initSecurityActions() {
    document.getElementById("resetAllData")?.addEventListener("click",()=>{
      const details=document.getElementById("resetConfirmText");
      if(details) details.textContent="Ҳамаи даромадҳо, хароҷот ва статистика тоза мешаванд. Ном, акси профил ва маълумоти шахсиат боқӣ мемонанд. Ин амал баргардонида намешавад.";
      showModal("resetModal");
    });
    document.getElementById("cancelReset")?.addEventListener("click",()=>hideModal("resetModal"));
    document.getElementById("confirmReset")?.addEventListener("click",()=>{
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(SHOPPING_KEY);
      hideModal("resetModal");
      refresh();
      showToast("Даромадҳо ва хароҷот тоза шуданд. Профил боқӣ монд.");
    });
    document.getElementById("cancelConfirm")?.addEventListener("click",()=>hideModal("confirmModal"));
    document.getElementById("confirmDelete")?.addEventListener("click",()=>{
      const id=document.getElementById("confirmModal")?.dataset.transactionId;
      if(id){
        const tx=getTransactions();
        const deleted=tx.find(x=>String(x.id)===String(id));
        saveTransactions(tx.filter(x=>String(x.id)!==String(id)));
        if(deleted?.shoppingItemId){
          const items=getShoppingItems(); const item=items.find(x=>String(x.id)===String(deleted.shoppingItemId));
          if(item){item.done=false;item.transactionId="";saveShoppingItems(items);renderShopping();}
        }
        refresh();showToast("Амалиёт нест карда шуд.");
      }
      hideModal("confirmModal");
    });
  }

  const total = (items, type) => items.filter(x => !type || x.type === type).reduce((sum,x) => sum + Number(x.amount || 0), 0);
  const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const normalized = text => String(text || "").trim().toLocaleLowerCase("tg");
  function categoryFor(note) {
    const s = normalized(note);
    if (/chat\s?gpt|чат\s?гпт|openai|subscription|обуна/.test(s)) return "ChatGPT ва обуна";
    if (/food|хӯрок|хурок|нон|об|кафе|ресторан|ош|маҳсулот|махсулот/.test(s)) return "Хӯрок";
    if (/taxi|такси|автобус|маршрут|роҳкиро|роҳ|транспорт|бензин/.test(s)) return "Нақлиёт";
    if (/internet|интернет|телефон|мегафон|тселл|вагон|алоқа|алока/.test(s)) return "Алоқа";
    if (/учеб|китоб|дафтар|қалам|ручка|дониш|курс|обучение|универ/.test(s)) return "Таҳсил";
    if (/либос|пойафзол|одежда|куртка|футболка/.test(s)) return "Либос";
    if (/игра|бозӣ|game|steam|pubg|free fire/.test(s)) return "Бозӣ ва фароғат";
    if (/врач|дору|дорув|бемор|табобат|аптека/.test(s)) return "Саломатӣ";
    if (/хона|ижора|коммунал|барқ|цах|свет/.test(s)) return "Хона";
    return String(note || "").trim() || "Дигар";
  }
  function categoryTotals(items) {
    const map = new Map();
    items.filter(x=>x.type==="expense").forEach(x=>{
      const key = categoryFor(x.note);
      const prev = map.get(key) || {name:key,total:0,count:0};
      prev.total += Number(x.amount); prev.count += 1; map.set(key,prev);
    });
    return [...map.values()].sort((a,b)=>b.total-a.total);
  }
  const colors = ["#5878f5","#f06a78","#24b47e","#a17be5","#f0ad4e","#32b8c5","#8090a8","#e47cbd","#7a9b57"];
  let charts = {};
  function isDark(){ return document.body.classList.contains("dark"); }
  function chartDefaults(){
    return {responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.dataset.label||ctx.label}: ${plainMoney(ctx.parsed.y ?? ctx.parsed)}`}}},scales:{x:{grid:{display:false},ticks:{color:isDark()?"#98a4bc":"#8b94a7",font:{family:"Inter",size:10}},border:{display:false}},y:{beginAtZero:true,grid:{color:isDark()?"#29334a":"#edf0f5"},ticks:{color:isDark()?"#98a4bc":"#8b94a7",font:{family:"Inter",size:10},callback:v=>v.toLocaleString("tg-TJ")},border:{display:false}}}};
  }
  function destroyChart(id){ if(charts[id]){charts[id].destroy();delete charts[id];} }
  function makeLine(id, labels, incomes, expenses) {
    const canvas=document.getElementById(id); if(!canvas||!window.Chart)return;
    destroyChart(id);
    charts[id]=new Chart(canvas,{type:"line",data:{labels,datasets:[{label:"Даромад",data:incomes,borderColor:"#24b47e",backgroundColor:"#24b47e18",fill:true,tension:.35,pointRadius:3,pointHoverRadius:5,borderWidth:2},{label:"Хароҷот",data:expenses,borderColor:"#f06a78",backgroundColor:"#f06a7815",fill:true,tension:.35,pointRadius:3,pointHoverRadius:5,borderWidth:2}]},options:{...chartDefaults(),interaction:{mode:"index",intersect:false}}});
  }
  function makeDoughnut(id, cats) {
    const canvas=document.getElementById(id); if(!canvas||!window.Chart)return;
    destroyChart(id);
    charts[id]=new Chart(canvas,{type:"doughnut",data:{labels:cats.map(x=>x.name),datasets:[{data:cats.map(x=>x.total),backgroundColor:cats.map((_,i)=>colors[i%colors.length]),borderWidth:0,hoverOffset:5}]},options:{responsive:true,maintainAspectRatio:false,cutout:"72%",plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.label}: ${plainMoney(ctx.parsed)}`}}}}});
  }
  function setTheme(theme){
    document.body.classList.toggle("dark",theme==="dark");
    try { localStorage.setItem(THEME_KEY,theme); } catch {}
    const btn=document.getElementById("themeToggle");
    if(btn)btn.innerHTML=(theme==="dark"?"☀":"☾")+" <span>"+(theme==="dark"?"Режими рӯзона":"Режими шабона")+"</span>";
    Object.keys(charts).forEach(id=>{
      const c=charts[id]; if(!c)return;
      if(c.options.scales){const opts=chartDefaults();c.options.scales=opts.scales;}
      c.update();
    });
  }
  function showToast(message){
    const el=document.getElementById("toast"); if(!el)return;
    el.textContent=message;el.classList.add("show");
    clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>el.classList.remove("show"),2800);
  }
  function updateSharedStats(){
    const tx=getTransactions(), incomes=total(tx,"income"), expenses=total(tx,"expense"), balance=incomes-expenses;
    const now=new Date(), month=tx.filter(x=>x.type==="expense"&&new Date(x.date).getMonth()===now.getMonth()&&new Date(x.date).getFullYear()===now.getFullYear());
    const put=(id,val)=>{const el=document.getElementById(id);if(el)el.innerHTML=val;};
    put("balance",money(balance));put("income",money(incomes));put("expense",money(expenses));put("monthExpense",money(total(month)));put("transactions",String(tx.length));
  }
  function transactionHTML(x, showType=true){
    const income=x.type==="income";
    return `<tr>
      <td><div class="transaction-name"><span class="transaction-symbol ${income?"income":"expense"}">${income?"↗":"↙"}</span><span>${escapeHTML(x.note|| (income?"Даромад":"Хароҷот"))}<span class="subline">${income?"Воридшавии пул":"Категория: "+escapeHTML(categoryFor(x.note))}</span></span></div></td>
      <td>${dateLabel(x.date)}</td>
      ${showType?`<td><span class="type-pill ${income?"income":"expense"}">${income?"Даромад":"Хароҷот"}</span></td>`:""}
      <td class="align-right ${income?"money-positive":"money-negative"}">${income?"+":"−"}${plainMoney(x.amount)}</td>
      <td class="transaction-actions"><button type="button" class="delete-transaction" data-delete-id="${escapeHTML(x.id)}" aria-label="Нест кардани амалиёт" title="Нест кардан">✕</button></td>
    </tr>`;
  }
  function initDeleteActions() {
    document.addEventListener("click", e => {
      const button = e.target.closest("[data-delete-id]");
      if (!button) return;
      const id = button.getAttribute("data-delete-id");
      const tx = getTransactions();
      const item = tx.find(x => String(x.id) === String(id));
      if (!item) return;
      const label = item.type === "income" ? "даромад" : "хароҷот";
      const modal = document.getElementById("confirmModal");
      if (!modal) { showToast("Равзанаи тасдиқ ёфт нашуд."); return; }
      modal.dataset.transactionId = id;
      const title = document.getElementById("confirmTitle");
      const message = document.getElementById("confirmMessage");
      if (title) title.textContent = `Нест кардани ${label}?`;
      if (message) message.textContent = `Маблағи ${plainMoney(item.amount)} нест карда мешавад. Баланс ва статистика аз нав ҳисоб мешаванд.`;
      showModal("confirmModal");
    });
  }
  function renderRecent(){
    const body=document.getElementById("recentTransactions");if(!body)return;
    const tx=getTransactions().sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,7);
    body.innerHTML=tx.map(x=>transactionHTML(x,true)).join("");
    const empty=document.getElementById("emptyRecent");if(empty)empty.classList.toggle("hidden",tx.length>0);
  }
  function renderIncome(){
    const body=document.getElementById("incomeHistory");if(!body)return;
    const tx=getTransactions().filter(x=>x.type==="income").sort((a,b)=>new Date(b.date)-new Date(a.date));
    body.innerHTML=tx.map(x=>transactionHTML(x,false)).join("");
    const empty=document.getElementById("emptyIncome");if(empty)empty.classList.toggle("hidden",tx.length>0);
    const count=document.getElementById("incomeCount");if(count)count.textContent=`${tx.length} амалиёт`;
  }
  function renderExpenses(){
    const body=document.getElementById("expenseHistory");if(!body)return;
    const tx=getTransactions().filter(x=>x.type==="expense").sort((a,b)=>new Date(b.date)-new Date(a.date));
    body.innerHTML=tx.map(x=>transactionHTML(x,false)).join("");
    const empty=document.getElementById("emptyExpense");if(empty)empty.classList.toggle("hidden",tx.length>0);
    const count=document.getElementById("expenseCount");if(count)count.textContent=`${tx.length} амалиёт`;
  }
  function lastSevenDays(items){
    const labels=[],incs=[],exps=[];
    for(let i=6;i>=0;i--){const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-i);const key=dayKey(d);labels.push(d.toLocaleDateString("tg-TJ",{day:"2-digit",month:"short"}));const day=items.filter(x=>dayKey(x.date)===key);incs.push(total(day,"income"));exps.push(total(day,"expense"));}
    return {labels,incs,exps};
  }
  function rangeFlow(items, fromValue, toValue) {
    let start = fromValue ? new Date(fromValue + "T00:00:00") : null;
    let end = toValue ? new Date(toValue + "T00:00:00") : null;
    const validDates = items.map(x => new Date(x.date)).filter(d => !Number.isNaN(d.getTime()));
    if (!start) start = validDates.length ? new Date(Math.min(...validDates.map(d => d.getTime()))) : new Date();
    if (!end) end = validDates.length ? new Date(Math.max(...validDates.map(d => d.getTime()))) : new Date();
    start.setHours(0,0,0,0); end.setHours(0,0,0,0);
    if (end < start) return {labels:[], incs:[], exps:[]};
    // Keep charts readable if the user selects many years.
    const days = Math.floor((end - start) / 86400000) + 1;
    const step = Math.max(1, Math.ceil(days / 31));
    const labels=[], incs=[], exps=[];
    for (let offset=0; offset<days; offset+=step) {
      const bucketStart = new Date(start); bucketStart.setDate(start.getDate()+offset);
      const bucketEnd = new Date(bucketStart); bucketEnd.setDate(bucketStart.getDate()+step);
      const bucket = items.filter(x => { const d = new Date(x.date); return d >= bucketStart && d < bucketEnd; });
      labels.push(step === 1 ? bucketStart.toLocaleDateString("tg-TJ",{day:"2-digit",month:"short"}) : bucketStart.toLocaleDateString("tg-TJ",{day:"2-digit",month:"short"}) + "–" + new Date(Math.min(end.getTime(), bucketEnd.getTime()-86400000)).toLocaleDateString("tg-TJ",{day:"2-digit",month:"short"}));
      incs.push(total(bucket,"income")); exps.push(total(bucket,"expense"));
    }
    return {labels,incs,exps};
  }
  function renderOverviewCharts(){
    const tx=getTransactions(),flow=lastSevenDays(tx),cats=categoryTotals(tx);
    makeLine("overviewChart",flow.labels,flow.incs,flow.exps);makeDoughnut("categoryChart",cats);
    const legend=document.getElementById("categoryLegend");
    if(legend)legend.innerHTML=cats.slice(0,4).map((c,i)=>`<div class="legend-row"><span class="legend-label"><i class="legend-dot" style="background:${colors[i%colors.length]}"></i>${escapeHTML(c.name)}</span><span class="legend-amount">${plainMoney(c.total)}</span></div>`).join("")||'<p class="muted">Ҳоло маълумот нест.</p>';
  }
  function renderStatistics(){
    const tx=getTransactions(),fromEl=document.getElementById("dateFrom"),toEl=document.getElementById("dateTo");
    if(!fromEl||!toEl)return;
    const from=fromEl.value?new Date(fromEl.value+"T00:00:00"):null,to=toEl.value?new Date(toEl.value+"T23:59:59.999"):null;
    const filtered=tx.filter(x=>{const d=new Date(x.date);return(!from||d>=from)&&(!to||d<=to);});
    const incomes=total(filtered,"income"),expenses=total(filtered,"expense");
    const put=(id,val)=>{const el=document.getElementById(id);if(el)el.innerHTML=val;};
    put("statIncome",money(incomes));put("statExpense",money(expenses));put("statNet",money(incomes-expenses));
    const expCount=filtered.filter(x=>x.type==="expense").length;put("statCount",String(expCount));
    const flow=rangeFlow(filtered,fromEl.value,toEl.value);makeLine("statFlowChart",flow.labels,flow.incs,flow.exps);
    const cats=categoryTotals(filtered);makeDoughnut("statCategoryChart",cats);
    const body=document.getElementById("categoryTable");
    if(body)body.innerHTML=cats.map((c,i)=>`<tr><td><div class="transaction-name"><i class="legend-dot" style="background:${colors[i%colors.length]}"></i>${escapeHTML(c.name)}</div></td><td>${c.count}</td><td class="align-right money-negative">${plainMoney(c.total)}</td></tr>`).join("");
    const empty=document.getElementById("emptyStats");if(empty)empty.classList.toggle("hidden",cats.length>0||filtered.some(x=>x.type==="income"));
  }
  function initForms(){
    const incomeForm=document.getElementById("incomeForm");
    if(incomeForm)incomeForm.addEventListener("submit",e=>{
      e.preventDefault();const amount=Number(document.getElementById("incomeAmount").value),note=document.getElementById("incomeNote").value.trim();
      if(!Number.isFinite(amount)||amount<=0){showToast("Маблағ бояд аз сифр зиёд бошад.");return;}
      const tx=getTransactions();tx.push({id:makeId(),type:"income",amount,note:note||"Даромад",date:new Date().toISOString()});saveTransactions(tx);incomeForm.reset();refresh();showToast("Даромад бо муваффақият сабт шуд ✓");
    });
    const expenseForm=document.getElementById("expenseForm");
    if(expenseForm)expenseForm.addEventListener("submit",e=>{
      e.preventDefault();const amount=Number(document.getElementById("expenseAmount").value),note=document.getElementById("expenseNote").value.trim();
      if(!Number.isFinite(amount)||amount<=0){showToast("Маблағ бояд аз сифр зиёд бошад.");return;}
      if(!note){showToast("Лутфан сабаби хароҷотро навис.");return;}
      const tx=getTransactions();tx.push({id:makeId(),type:"expense",amount,note,date:new Date().toISOString()});saveTransactions(tx);expenseForm.reset();refresh();showToast("Хароҷот бо муваффақият сабт шуд ✓");
    });
  }
  function initStatistics(){
    const from=document.getElementById("dateFrom"),to=document.getElementById("dateTo");
    if(!from||!to)return;
    const now=new Date(),start=new Date(now.getFullYear(),now.getMonth(),1);
    from.value=dayKey(start);to.value=dayKey(now);
    document.getElementById("applyDates")?.addEventListener("click",()=>{
      if(from.value&&to.value&&from.value>to.value){showToast("Санаи оғоз набояд аз санаи анҷом дертар бошад.");return;}renderStatistics();
    });
    document.getElementById("allTime")?.addEventListener("click",()=>{from.value="";to.value="";renderStatistics();});
    renderStatistics();
  }
  function initNavigation(){
    document.getElementById("themeToggle")?.addEventListener("click",()=>setTheme(isDark()?"light":"dark"));
    document.getElementById("exportPdf")?.addEventListener("click",()=>{
      const profile=getProfile();
      const oldTitle=document.title;
      document.title=`Ҳисоботи молиявӣ - ${profile?.name || "Пули ман"}`;
      window.print();
      setTimeout(()=>{document.title=oldTitle;},800);
    });
    document.getElementById("mobileMenu")?.addEventListener("click",()=>document.querySelector(".sidebar")?.classList.toggle("open"));
    document.addEventListener("click",e=>{const side=document.querySelector(".sidebar");if(side?.classList.contains("open")&&!side.contains(e.target)&&!e.target.closest("#mobileMenu"))side.classList.remove("open");});
    const year=document.getElementById("year");if(year)year.textContent=new Date().getFullYear();
    let savedTheme = "light"; try { savedTheme = localStorage.getItem(THEME_KEY) || "light"; } catch {} setTheme(savedTheme);
  }
  function getShoppingItems(){try{const data=JSON.parse(localStorage.getItem(SHOPPING_KEY)||"[]");return Array.isArray(data)?data:[];}catch{return [];}}
  function saveShoppingItems(items){localStorage.setItem(SHOPPING_KEY,JSON.stringify(items));}
  function renderShopping(){
    const list=document.getElementById("shoppingList"); if(!list)return;
    const items=getShoppingItems();
    const pending=items.filter(x=>!x.done), remaining=total(getTransactions(),"income")-total(getTransactions(),"expense");
    const planned=pending.reduce((sum,x)=>sum+Number(x.price||0),0);
    const put=(id,val)=>{const el=document.getElementById(id);if(el)el.innerHTML=val;};
    put("shoppingPlanned",plainMoney(planned)); put("shoppingBalance",plainMoney(remaining));
    const left=document.getElementById("shoppingAfter");if(left)left.innerHTML=plainMoney(remaining-planned);
    const status=document.getElementById("shoppingAffordability");
    if(status){status.className="shopping-status "+(planned<=remaining?"can-afford":"cannot-afford");status.textContent=planned===0?"Ҳоло хариди интизорӣ нест":planned<=remaining?"Пулҳоят мерасанд ✓":"Пулҳоят намерасанд — маблағ намерасад";}
    list.innerHTML=items.map(item=>`<article class="shopping-item ${item.done?"is-done":""}">
      <label class="shopping-check"><input type="checkbox" data-shopping-check="${escapeHTML(item.id)}" ${item.done?"checked":""}><span class="custom-check"></span></label>
      <div class="shopping-item-copy"><b>${escapeHTML(item.name)}</b><small>${item.done?"Харида шуд · аз баланс кам шуд":"Дар рӯйхати харид"}</small></div>
      <strong class="shopping-price">${plainMoney(item.price)}</strong>
      <button type="button" class="shopping-delete" data-shopping-delete="${escapeHTML(item.id)}" aria-label="Нест кардани харид" title="Нест кардан">✕</button>
    </article>`).join("");
    const empty=document.getElementById("emptyShopping");if(empty)empty.classList.toggle("hidden",items.length>0);
    const count=document.getElementById("shoppingCount");if(count)count.textContent=`${pending.length} харид дар интизорӣ`;
  }
  function initShopping(){
    const form=document.getElementById("shoppingForm");
    form?.addEventListener("submit",e=>{e.preventDefault();const name=document.getElementById("shoppingName").value.trim(),price=Number(document.getElementById("shoppingPrice").value);if(!name){showToast("Номи харидро навис.");return;}if(!Number.isFinite(price)||price<=0){showToast("Нарх бояд аз сифр зиёд бошад.");return;}const items=getShoppingItems();items.push({id:makeId(),name,price,done:false,transactionId:"",createdAt:new Date().toISOString()});saveShoppingItems(items);form.reset();hideModal("shoppingAddModal");renderShopping();showToast("Харид ба рӯйхат илова шуд.");});
    document.getElementById("addShopping")?.addEventListener("click",()=>{form?.reset();showModal("shoppingAddModal");setTimeout(()=>document.getElementById("shoppingName")?.focus(),50);});
    document.getElementById("cancelShoppingAdd")?.addEventListener("click",()=>hideModal("shoppingAddModal"));
    document.getElementById("shoppingList")?.addEventListener("change",e=>{
      const input=e.target.closest("[data-shopping-check]");if(!input)return;
      const id=input.getAttribute("data-shopping-check"),items=getShoppingItems(),item=items.find(x=>String(x.id)===String(id));if(!item)return;
      const tx=getTransactions();
      if(input.checked&&!item.done){
        const balance=total(tx,"income")-total(tx,"expense");
        if(Number(item.price)>balance){input.checked=false;showToast("Пул намерасад. Аввал балансро санҷ.");return;}
        const expense={id:makeId(),type:"expense",amount:Number(item.price),note:"Харид: "+item.name,date:new Date().toISOString(),shoppingItemId:item.id};
        tx.push(expense);item.done=true;item.transactionId=expense.id;saveTransactions(tx);saveShoppingItems(items);showToast("Харид тасдиқ шуд, пул аз баланс кам шуд.");
      }else if(!input.checked&&item.done){
        saveTransactions(tx.filter(x=>String(x.id)!==String(item.transactionId)&&String(x.shoppingItemId)!==String(item.id)));item.done=false;item.transactionId="";saveShoppingItems(items);showToast("Харид аз ҳолати анҷомшуда баргардонда шуд.");
      }
      refresh();renderShopping();
    });
    let pendingShoppingDeleteId = null;
    document.getElementById("shoppingList")?.addEventListener("click",e=>{
      const btn=e.target.closest("[data-shopping-delete]");if(!btn)return;
      const id=btn.getAttribute("data-shopping-delete"),items=getShoppingItems(),item=items.find(x=>String(x.id)===String(id));if(!item)return;
      pendingShoppingDeleteId = String(id);
      const description=document.getElementById("shoppingDeleteText");
      if(description) description.textContent = item.done
        ? `«${item.name}» аллакай ҳамчун хароҷот сабт шудааст. Ин харидро танҳо аз рӯйхат тоза мекунӣ ё хароҷоташро ҳам тоза карда, пулро ба баланс бармегардонӣ?`
        : `Оё мехоҳӣ «${item.name}»-ро аз рӯйхат тоза кунӣ? Ин харид ҳоло аз баланс пул кам накардааст.`;
      const expenseBtn=document.getElementById("deleteShoppingExpense");
      if(expenseBtn) { expenseBtn.textContent="Ҳа, хароҷотро ҳам тоза кун"; expenseBtn.style.display=item.done?"inline-flex":"none"; }
      const onlyBtn=document.getElementById("deleteShoppingOnly"); if(onlyBtn) onlyBtn.textContent=item.done?"Не, танҳо рӯйхат":"Танҳо аз рӯйхат тоза кун";
      showModal("shoppingDeleteModal");
    });
    document.getElementById("cancelShoppingDelete")?.addEventListener("click",()=>{pendingShoppingDeleteId=null;hideModal("shoppingDeleteModal");});
    document.getElementById("deleteShoppingOnly")?.addEventListener("click",()=>{
      if(pendingShoppingDeleteId===null)return;
      const id=pendingShoppingDeleteId;saveShoppingItems(getShoppingItems().filter(x=>String(x.id)!==id));
      pendingShoppingDeleteId=null;hideModal("shoppingDeleteModal");renderShopping();showToast("Харид танҳо аз рӯйхат тоза шуд; хароҷоти сабтшуда бетағйир монд.");
    });
    document.getElementById("deleteShoppingExpense")?.addEventListener("click",()=>{
      if(pendingShoppingDeleteId===null)return;
      const id=pendingShoppingDeleteId,item=getShoppingItems().find(x=>String(x.id)===id);
      saveShoppingItems(getShoppingItems().filter(x=>String(x.id)!==id));
      if(item?.done){saveTransactions(getTransactions().filter(x=>String(x.id)!==String(item.transactionId)&&String(x.shoppingItemId)!==id));refresh();}
      pendingShoppingDeleteId=null;hideModal("shoppingDeleteModal");renderShopping();showToast(item?.done?"Харид ва хароҷот тоза шуданд; пул ба баланс баргашт.":"Харид аз рӯйхат тоза шуд.");
    });
    renderShopping();
  }
  function refresh(){updateSharedStats();renderRecent();renderIncome();renderExpenses();renderOverviewCharts();renderStatistics();renderShopping();}
  document.addEventListener("DOMContentLoaded",()=>{
    initNavigation(); initProfile(); initDeleteActions(); initSecurityActions(); initForms(); initStatistics(); initShopping(); refresh();
  });
})();