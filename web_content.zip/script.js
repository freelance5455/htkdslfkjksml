document.addEventListener("DOMContentLoaded", function() {

    let currentLevel = parseInt(localStorage.getItem("savedLevel")) || 1;
    let todayLevelsCount = parseInt(localStorage.getItem("todayLevels")) || 0;
    let lives = 3;
    let activeArrows = [];
    let isEndlessMode = false;
    let endlessScore = 0;
    let endlessHighScore = parseInt(localStorage.getItem("endlessHighScore")) || 0;
    let endlessLeaderboard = JSON.parse(localStorage.getItem("endlessLeaderboard")) || [];

    let playerName = localStorage.getItem("playerName");

    if (endlessLeaderboard.length > 0 && (!endlessLeaderboard[0].date || !endlessLeaderboard[0].date.includes("2026"))) {
        endlessLeaderboard = []; 
    }

    if (endlessLeaderboard.length === 0) {
        endlessLeaderboard = [
            { name: "Rajesh (Pro)", score: 145, date: "14/07/2026 [02:30 PM]", rank: "🥇 Ultimate Bow-Master" },
            { name: "Vikas_99", score: 82, date: "13/07/2026 [11:15 AM]", rank: "🥈 Chakra Elite" },
            { name: "Priya Gamer", score: 45, date: "12/07/2026 [09:05 PM]", rank: "🥉 Beginner Archer" }
        ];
        localStorage.setItem("endlessLeaderboard", JSON.stringify(endlessLeaderboard));
    }

    let levelStartTime;
    let errorsCount = 0;
    let hintsUsedCount = 0;
    let hintTimeout = null;
    let messageTimeout = null; 

    let bestTimes = JSON.parse(localStorage.getItem("bestTimes")) || {};
    let highScores = JSON.parse(localStorage.getItem("highScores")) || {};

    let totalWins = parseInt(localStorage.getItem("totalWins")) || 0;
    let totalGameOvers = parseInt(localStorage.getItem("totalGameOvers")) || 0;
    let totalMistakes = parseInt(localStorage.getItem("totalMistakes")) || 0;
    let totalHints = parseInt(localStorage.getItem("totalHints")) || 0;

    let coins = parseInt(localStorage.getItem("coins")) || 0;
    let extraLives = parseInt(localStorage.getItem("extraLives")) || 0;
    let extraHints = parseInt(localStorage.getItem("extraHints")) || 0;

    // 🔥 बदलाव: VIP Theme का डेटा लोकल स्टोरेज से उठाया गया है
    let unlockedVipHome = JSON.parse(localStorage.getItem("unlockedVipHome")) || false;

    const THEMES_DB = {
        default: { name: "⚙️ Default", price: 0 },
        blue: { name: "🔵 Royal Blue", price: 150 },
        gold: { name: "👑 Gold Prime", price: 200 },
        green: { name: "🟢 Neon Green", price: 180 },
        gradient: { name: "🔮 Cosmic Gradient", price: 300 },
        galaxy: { name: "🌌 Galaxy (Ultra-Premium)", price: 1500 }
    };

    const SKINS_DB = {
        default: { name: "🌸 Default Pink", price: 0 },
        golden: { name: "✨ Golden Skin", price: 150 },
        "neon-blue": { name: "🔹 Neon Blue", price: 160 },
        "neon-green": { name: "⚡ Neon Green", price: 160 },
        "cyber-purple": { name: "🦄 Cyber Purple", price: 250 },
        "sunset-glow": { name: "💥 Sunset Glow", price: 350 },
        "god-killer": { name: "⚡ The God-Killer (Ultra)", price: 1500 }
    };

    let unlockedThemes = JSON.parse(localStorage.getItem("unlockedThemes")) || { default: true };
    let unlockedSkins = JSON.parse(localStorage.getItem("unlockedSkins")) || { default: true };
    if(JSON.parse(localStorage.getItem("themeUnlocked"))) unlockedThemes['blue'] = true; 
    if(JSON.parse(localStorage.getItem("goldenArrowUnlocked"))) unlockedSkins['golden'] = true; 

    let currentTheme = localStorage.getItem("currentTheme") || "default";
    let arrowSkin = localStorage.getItem("arrowSkin") || "default"; 
    let lastRewardDate = localStorage.getItem("lastRewardDate") || "";

    let achievements = JSON.parse(localStorage.getItem("achievements")) || {
        firstWin: false, level10: false, level25: false, level50: false, level75: false, level100: false, 
        level150: false, level250: false, level500: false, level1000: false, noHint: false, flawless: false, 
        rich500: false, rich1000: false, speedRunner: false
    };

    let isHintUsedInCurrentAttempt = false;
    let glowingArrowId = null; 
    let totalArrowsInCurrentLevel = 0;

    const board = document.getElementById("board");
    const livesDisplay = document.getElementById("lives-display");
    const gameStatus = document.getElementById("game-status");
    const actionBtn = document.getElementById("action-btn");
    const hintBtn = document.getElementById("hint-btn");
    const winPopup = document.getElementById("win-popup");

    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    let bgMusicInterval = null;
    let isMusicPlaying = false;
    let currentNoteIndex = 0;

    let gameMusicEnabled = JSON.parse(localStorage.getItem("gameMusicEnabled"));
    if (gameMusicEnabled === null) gameMusicEnabled = true;
    let homeMusicEnabled = JSON.parse(localStorage.getItem("homeMusicEnabled"));
    if (homeMusicEnabled === null) homeMusicEnabled = true;
    let soundEnabled = JSON.parse(localStorage.getItem("soundEnabled"));
    if (soundEnabled === null) soundEnabled = true;
    let vibrationEnabled = JSON.parse(localStorage.getItem("vibrationEnabled"));
    if (vibrationEnabled === null) vibrationEnabled = true;

    const homeMelody = [ 329.63, 392.00, 440.00, 440.00, 329.63, 392.00, 440.00, 440.00, 329.63, 392.00, 440.00, 523.25, 493.88, 392.00, 440.00, 440.00 ];
    const gameMelody = [ 261.63, 329.63, 392.00, 523.25, 329.63, 392.00, 523.25, 659.25, 293.66, 349.23, 440.00, 587.33, 349.23, 440.00, 523.25, 698.46 ];
    let activeMelody = homeMelody;

    function playTone(freq, type, duration, volume = 0.8) {
        try { 
            if (audioCtx.state === 'suspended') return;
            const osc = audioCtx.createOscillator(); 
            const gain = audioCtx.createGain();
            osc.type = type; 
            osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
            gain.gain.setValueAtTime(volume, audioCtx.currentTime); 
            gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
            osc.connect(gain); 
            gain.connect(audioCtx.destination); 
            osc.start(); 
            osc.stop(audioCtx.currentTime + duration);
        } catch(e) {}
    }

    function playEffect(freq, type, duration, volume = 0.8) { 
        if (!soundEnabled) return; 
        playTone(freq, type, duration, volume); 
    }

    function soundArrowFly() { playEffect(880, 'triangle', 0.12, 0.7); }
    function soundCollision() { playEffect(180, 'sawtooth', 0.3, 0.9); }
    function soundStar(starNumber) { 
        const freqs = [587.33, 698.46, 880]; 
        setTimeout(() => playEffect(freqs[starNumber - 1], 'sine', 0.35, 0.7), 50); 
    }
    function soundScoreTick() { playEffect(1200, 'sine', 0.03, 0.4); }
    function soundCoinTick() { playEffect(2000, 'triangle', 0.04, 0.3); }
    function gameVibrate(time = 100){ 
        if(!vibrationEnabled) return; 
        if(navigator.vibrate) navigator.vibrate(time); 
    }

    function soundExplosion() {
        if (!soundEnabled) return;
        try { 
            const osc = audioCtx.createOscillator(); 
            const gain = audioCtx.createGain(); 
            osc.type = 'sawtooth'; 
            osc.frequency.setValueAtTime(160, audioCtx.currentTime); 
            osc.frequency.exponentialRampToValueAtTime(10, audioCtx.currentTime + 0.8); 
            gain.gain.setValueAtTime(1.2, audioCtx.currentTime); 
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.8); 
            osc.connect(gain); 
            gain.connect(audioCtx.destination); 
            osc.start(); 
            osc.stop(audioCtx.currentTime + 0.8); 
        } catch (e) {}
    }

    function playNextMusicNote() {
        let isHome = (activeMelody === homeMelody);
        let isEnabled = isHome ? homeMusicEnabled : gameMusicEnabled;
        if (!isMusicPlaying || !isEnabled) { 
            isMusicPlaying = false; 
            return; 
        }
        playTone(activeMelody[currentNoteIndex], isHome ? 'triangle' : 'sine', isHome ? 0.4 : 0.8, isHome ? 0.6 : 0.35);
        currentNoteIndex = (currentNoteIndex + 1) % activeMelody.length;
        bgMusicInterval = setTimeout(playNextMusicNote, isHome ? 300 : 600);
    }

    function startPremiumMusic() {
        let isHome = (activeMelody === homeMelody);
        let isEnabled = isHome ? homeMusicEnabled : gameMusicEnabled;
        if (isEnabled && !isMusicPlaying) { 
            isMusicPlaying = true; 
            playNextMusicNote(); 
        }
    }

    function stopPremiumMusic() { 
        isMusicPlaying = false; 
        clearTimeout(bgMusicInterval); 
    }

    setTimeout(() => {
        const studioSplash = document.getElementById("studio-splash");
        const gameSplash = document.getElementById("splash-screen");
        const homeScreen = document.getElementById("home-screen");
        
        if(studioSplash) studioSplash.style.display = "none";
        if(gameSplash) gameSplash.style.display = "flex";
        
        setTimeout(() => {
            if(gameSplash) gameSplash.style.display = "none";
            if(homeScreen) { 
                homeScreen.style.display = "flex"; 
                activeMelody = homeMelody; 

                if (!playerName) {
                    const profilePop = document.getElementById("profile-popup");
                    if (profilePop) profilePop.style.display = "flex";
                }
            }
        }, 2500); 
    }, 2200); 

    function updateGreetingUI() {
        const greetingName = document.getElementById("current-player-name");
        if (greetingName && playerName) {
            let cleanName = playerName.replace(" (You)", "");
            if (cleanName.length > 20) {
                cleanName = cleanName.substring(0, 20) + "...";
            }
            greetingName.innerText = cleanName;
        }
    }

    updateGreetingUI();

    const saveProfileBtn = document.getElementById("save-profile-btn");
    if(saveProfileBtn) {
        saveProfileBtn.onclick = function() {
            let inputName = document.getElementById("player-name-input").value.trim();
            if(inputName === "") {
                inputName = "योद्धा (You)";
            } else {
                inputName = inputName + " (You)";
            }
            
            let oldName = playerName;
            playerName = inputName;
            localStorage.setItem("playerName", playerName);
            
            if (oldName && oldName !== playerName) {
                endlessLeaderboard.forEach(entry => {
                    if (entry.name === oldName) entry.name = playerName;
                });
                localStorage.setItem("endlessLeaderboard", JSON.stringify(endlessLeaderboard));
            }

            document.getElementById("profile-popup").style.display = "none";
            showToast("✅ प्रोफाइल अपडेट हो गई!", "success");
            updateGreetingUI();
            refreshLeaderboardHTML();
        };
    }

    const editProfileBtn = document.getElementById("edit-profile-btn");
    if(editProfileBtn) {
        editProfileBtn.onclick = function() {
            const profilePop = document.getElementById("profile-popup");
            const nameInput = document.getElementById("player-name-input");
            
            if (playerName) {
                nameInput.value = playerName.replace(" (You)", "");
            }
            
            if (profilePop) profilePop.style.display = "flex";
        };
    }

    let isAudioInitialized = false;
    document.body.addEventListener('click', () => {
        if(!isAudioInitialized) {
            isAudioInitialized = true;
            if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
            const homeScreen = document.getElementById("home-screen");
            if (homeScreen && homeScreen.style.display !== "none" && homeMusicEnabled) { 
                startPremiumMusic(); 
            }
        }
    });

    document.addEventListener("visibilitychange", () => {
        if (document.hidden) { 
            stopPremiumMusic(); 
            audioCtx.suspend(); 
        } else { 
            audioCtx.resume().then(() => { startPremiumMusic(); }); 
        }
    });

    function showAchievement(text){
        const popup = document.getElementById("achievement-popup");
        document.getElementById("achievement-text").innerText = text; 
        popup.style.display = "block";
        soundStar(3); 
        gameVibrate(80); 
        setTimeout(() => { popup.style.display = "none"; }, 2500);
    }

    function showToast(msg, type) {
        const container = document.getElementById("toast-container");
        if(!container) return;
        const toast = document.createElement("div");
        toast.className = `toast premium-alert ${type}`; 
        toast.innerText = msg;
        container.appendChild(toast);
        
        if(type === 'success') soundStar(3);
        gameVibrate([80, 40, 80]); 
        
        setTimeout(() => { 
            toast.style.opacity = '0'; 
            setTimeout(() => toast.remove(), 300); 
        }, 2500);
    }

    function isPathBlocked(arrow, allArrows, margin = 24) {
        let blocked = false;
        allArrows.forEach(other => {
            if (other.id === arrow.id) return;
            if (arrow.dir === 'U' && Math.abs(other.x - arrow.x) < margin && other.y < arrow.y) blocked = true;
            if (arrow.dir === 'D' && Math.abs(other.x - arrow.x) < margin && other.y > arrow.y) blocked = true;
            if (arrow.dir === 'L' && Math.abs(other.y - arrow.y) < margin && other.x < arrow.x) blocked = true;
            if (arrow.dir === 'R' && Math.abs(other.y - arrow.y) < margin && other.x > arrow.x) blocked = true;
        }); 
        return blocked;
    }

    function isLevelSolvable(arrowsCopy) {
        let testList = JSON.parse(JSON.stringify(arrowsCopy)); 
        let progress = true;
        while (progress && testList.length > 0) { 
            progress = false;
            for (let i = 0; i < testList.length; i++) {
                if (!isPathBlocked(testList[i], testList, 24)) { 
                    testList.splice(i, 1); 
                    progress = true; 
                    break; 
                }
            }
        } 
        return testList.length === 0;
    }

    // 🔥 बदलाव: हिंट बटन को HTML से कनेक्ट करने के लिए ग्लोबल बनाया गया
    window.useHint = function() {
        if (lives <= 0 || activeArrows.length === 0) return;
        
        let correctArrow = null;
        for (let i = 0; i < activeArrows.length; i++) {
            if (!isPathBlocked(activeArrows[i], activeArrows, 24)) { 
                correctArrow = activeArrows[i]; 
                break; 
            }
        }
        
        if (correctArrow) {
            // पहला हिंट फ्री है, उसके बाद ही एक्स्ट्रा हिंट खर्च होंगे
            if (!isHintUsedInCurrentAttempt) {
                isHintUsedInCurrentAttempt = true; 
            } else {
                if (extraHints <= 0) {
                    showToast("❌ आपके पास Hint नहीं है! Shop से खरीदें।", "error");
                    return; // अगर हिंट नहीं हैं, तो यही रोक दो
                }
                extraHints--; 
                localStorage.setItem("extraHints", extraHints); 
                updateCoins(); 
            }

            gameVibrate(30); 
            clearTimeout(messageTimeout); 
            hintsUsedCount++; 
            totalHints++; 
            localStorage.setItem("totalHints", totalHints);
            glowingArrowId = correctArrow.id; 
            
            const arrowEl = document.getElementById(`arrow-${correctArrow.id}`); 
            if (arrowEl) arrowEl.classList.add("hint-glow"); 
            
            hintTimeout = setTimeout(() => {
                const el = document.getElementById(`arrow-${glowingArrowId}`); 
                if (el) el.classList.remove("hint-glow");
                
                if (gameStatus.innerText.includes("आईडिया:")) { 
                    gameStatus.innerText = isEndlessMode ? `चक्रव्यूह स्कोर: ${endlessScore}` : `लेवल ${currentLevel}: सही क्रम खोजें!`; 
                    gameStatus.style.color = "#e2e8f0"; 
                }
                glowingArrowId = null;
            }, 5000);
            
            gameStatus.innerText = "💡 आईडिया: चमकता हुआ तीर पूरी तरह सुरक्षित है!"; 
            gameStatus.style.color = "#81c784";

            // बटन का टेक्स्ट अपडेट करना (बिना इसे Disable किये ताकि शॉप अलर्ट दिख सके)
            const hBtn = document.getElementById("hint-btn");
            if (hBtn) {
                if (extraHints > 0) {
                    hBtn.innerText = `💡 एक्स्ट्रा हिंट (${extraHints})`;
                } else {
                    hBtn.innerText = `💡 हिंट ख़त्म`;
                }
            }
        }
    };

    function generateLevel(level) {
        const directions = ['U', 'D', 'L', 'R']; 
        const arrowSize = 38; 
        const boardWidth = board.clientWidth || 360; 
        const boardHeight = board.clientHeight || 450;
        const colsCount = Math.floor(boardWidth / arrowSize); 
        const rowsCount = Math.floor(boardHeight / arrowSize);
        const startX = Math.floor((boardWidth - (colsCount * arrowSize)) / 2); 
        const startY = Math.floor((boardHeight - (rowsCount * arrowSize)) / 2);

        let numberOfArrows = 5;
        if (isEndlessMode) { 
            numberOfArrows = 10 + Math.floor(endlessScore / 2); 
            if (numberOfArrows > 32) numberOfArrows = 32; 
        } else { 
            let b = Math.floor((level - 1) / 10); 
            if (level === 1) numberOfArrows = 5; 
            else if (level === 2) numberOfArrows = 8; 
            else numberOfArrows = 8 + (b * 2) + Math.floor((level % 10) * 0.4); 
            if (numberOfArrows > 32) numberOfArrows = 32; 
        }

        if (!isEndlessMode && level % 10 === 0) {
            numberOfArrows += 5; 
            if (numberOfArrows > 40) numberOfArrows = 40; 
            setTimeout(() => {
                const statusBox = document.getElementById("game-status");
                if (statusBox) {
                    statusBox.innerText = "⚠️ बॉस लेवल: चक्रव्यूह का असली इम्तिहान!";
                    statusBox.style.color = "#fbbf24";
                }
            }, 50);
        }

        let finalArrows = []; 
        let isValidLevelFound = false; 
        let gridAttempts = 0;
        
        while (!isValidLevelFound && gridAttempts < 1500) {
            gridAttempts++; 
            let tempArrows = []; 
            let usedPositions = new Set();
            
            for (let i = 0; i < numberOfArrows; i++) {
                let col = Math.floor(Math.random() * colsCount); 
                let row = Math.floor(Math.random() * rowsCount);
                let posKey = `${col},${row}`; 
                let posAttempts = 0;
                
                while (usedPositions.has(posKey) && posAttempts < 50) { 
                    col = Math.floor(Math.random() * colsCount); 
                    row = Math.floor(Math.random() * rowsCount); 
                    posKey = `${col},${row}`; 
                    posAttempts++; 
                }
                usedPositions.add(posKey); 
                const randomDir = directions[Math.floor(Math.random() * directions.length)];
                tempArrows.push({ id: i + 1, x: startX + (col * arrowSize), y: startY + (row * arrowSize), col: col, row: row, dir: randomDir, text: '➔' });
            }
            if (isLevelSolvable(tempArrows)) { 
                finalArrows = tempArrows; 
                isValidLevelFound = true; 
            }
        }
        
        if (!isValidLevelFound) {
            finalArrows = []; 
            let idCounter = 1;
            for (let r = 1; r < rowsCount - 1 && finalArrows.length < numberOfArrows; r++) {
                for (let c = 1; c < colsCount - 1 && finalArrows.length < numberOfArrows; c++) {
                    finalArrows.push({ id: idCounter++, x: startX + (c * arrowSize), y: startY + (r * arrowSize), col: c, row: r, dir: 'U', text: '➔' });
                }
            }
        }
        totalArrowsInCurrentLevel = finalArrows.length; 
        return finalArrows;
    }

    function applySkinToRenderedArrows() {
        const arrowCards = document.querySelectorAll(".arrow-card");
        arrowCards.forEach(card => {
            card.className = "arrow-card"; 
            if (arrowSkin === "golden") card.classList.add("arrow-golden");
            else if (arrowSkin === "neon-blue") card.classList.add("arrow-neon-blue");
            else if (arrowSkin === "neon-green") card.classList.add("arrow-neon-green");
            else if (arrowSkin === "cyber-purple") card.classList.add("arrow-cyber-purple");
            else if (arrowSkin === "sunset-glow") card.classList.add("arrow-sunset-glow");
            else if (arrowSkin === "god-killer") card.classList.add("arrow-god-killer"); 
            else card.classList.add("arrow-default");
        });
    }

    function loadLevel(levelIndex) {
        clearTimeout(hintTimeout); 
        clearTimeout(messageTimeout); 
        board.innerHTML = ""; 
        actionBtn.style.display = "none"; 
        winPopup.style.display = "none"; 
        glowingArrowId = null; 
        document.querySelectorAll(".pop-star").forEach(s => s.classList.remove("active"));
        
        isHintUsedInCurrentAttempt = false; 
        if (hintBtn) {
            hintBtn.innerText = `💡 आईडिया (फ्री)`;
        }
        
        const labelEl = document.getElementById("level-display-text");
        if (isEndlessMode) { 
            labelEl.innerHTML = `स्कोर: <span id="level-num">${endlessScore}</span>`; 
            gameStatus.innerText = `अनंत चक्रव्यूह स्कोर: ${endlessScore}`; 
        } else { 
            labelEl.innerHTML = `लेवल: <span id="level-num">${levelIndex}</span>`; 
            gameStatus.innerText = `लेवल ${levelIndex}: सही क्रम खोजें!`; 
            localStorage.setItem("savedLevel", levelIndex); 
        }
        gameStatus.style.color = "#e2e8f0";

        activeArrows = generateLevel(levelIndex);
        activeArrows.forEach(arrow => {
            const arrowEl = document.createElement("div");
            arrowEl.id = `arrow-${arrow.id}`; 
            arrowEl.className = "arrow-card";
            arrowEl.style.left = `${arrow.x}px`; 
            arrowEl.style.top = `${arrow.y}px`; 
            arrowEl.innerHTML = arrow.text;
            
            let rotation = 0; 
            if (arrow.dir === 'U') rotation = -90; 
            if (arrow.dir === 'D') rotation = 90; 
            if (arrow.dir === 'L') rotation = 180; 
            if (arrow.dir === 'R') rotation = 0;
            
            arrowEl.style.transform = `rotate(${rotation}deg)`; 
            arrowEl.style.setProperty('--rot', `${rotation}deg`);
            arrowEl.onclick = () => tryMove(arrow); 
            board.appendChild(arrowEl);
        });
        
        applySkinToRenderedArrows();
        levelStartTime = new Date(); 
        errorsCount = 0; 
        hintsUsedCount = 0;
    }

    function tryMove(clickedArrow) {
        if (lives <= 0) return;
        let pathBlocked = isPathBlocked(clickedArrow, activeArrows, 24);
        const arrowEl = document.getElementById(`arrow-${clickedArrow.id}`);

        if (pathBlocked) {
            if (arrowEl) arrowEl.classList.add("collision-shake");
            lives--; 
            errorsCount++; 
            totalMistakes++; 
            localStorage.setItem("totalMistakes", totalMistakes);
            updateLives(); 
            soundCollision(); 
            gameVibrate(200);
            gameStatus.innerText = "💥 रास्ता ब्लॉक है! तीर टकरा गया!"; 
            gameStatus.style.color = "#ef4444";
            
            setTimeout(() => { if (arrowEl) arrowEl.classList.remove("collision-shake"); }, 300);
            clearTimeout(messageTimeout);
            
            if (lives > 0) { 
                messageTimeout = setTimeout(() => { 
                    if (!glowingArrowId) { 
                        gameStatus.innerText = isEndlessMode ? `अनंत चक्रव्यूह स्कोर: ${endlessScore}` : `लेवल ${currentLevel}: सही क्रम खोजें!`; 
                        gameStatus.style.color = "#e2e8f0"; 
                    } 
                }, 2000); 
            }
            if (lives <= 0) { 
                clearTimeout(messageTimeout); 
                gameOver(); 
            }
        } else {
            soundArrowFly(); 
            gameVibrate(50);
            if (glowingArrowId === clickedArrow.id) { 
                clearTimeout(hintTimeout); 
                glowingArrowId = null; 
            }
            
            clearTimeout(messageTimeout); 
            activeArrows = activeArrows.filter(a => a.id !== clickedArrow.id);
            
            let flyTime = isEndlessMode ? Math.max(70, 140 - Math.floor(endlessScore / 3) * 10) : (currentLevel <= 50 ? 150 : (currentLevel <= 200 ? 120 : (currentLevel <= 500 ? 100 : 80)));
            if (arrowEl) {
                arrowEl.style.transition = `transform ${flyTime}ms linear, opacity ${flyTime}ms`;
                if (clickedArrow.dir === 'U') arrowEl.classList.add("fly-up"); 
                if (clickedArrow.dir === 'D') arrowEl.classList.add("fly-down"); 
                if (clickedArrow.dir === 'L') arrowEl.classList.add("fly-left"); 
                if (clickedArrow.dir === 'R') arrowEl.classList.add("fly-right");
            }
            
            if (activeArrows.length === 0) {
                if (isEndlessMode) {
                    endlessScore++; 
                    if (endlessScore > endlessHighScore) { 
                        endlessHighScore = endlessScore; 
                        localStorage.setItem("endlessHighScore", endlessHighScore); 
                    }
                    coins += 10; 
                    updateCoins(); 
                    setTimeout(() => { loadLevel(currentLevel); }, 400);
                } else { 
                    showWinPopup("classic"); 
                }
            }
        }
    }

    function updateLives() { 
        let hearts = ""; 
        for (let i = 0; i < lives; i++) hearts += "❤️"; 
        for (let i = lives; i < 3; i++) hearts += "🖤"; 
        livesDisplay.innerText = hearts; 
        
        let homeLifeCount = document.getElementById("home-extra-lives-count");
        if (homeLifeCount) {
            homeLifeCount.innerText = extraLives;
        }
    }

    function updateCoins() { 
        localStorage.setItem("coins", coins); 
        document.getElementById("coin-count").innerText = coins; 
        
        const homeHintCount = document.getElementById("home-hint-count");
        if (homeHintCount) {
            homeHintCount.innerText = extraHints;
        }
        
        const shopCoinEl = document.getElementById("shop-coin-count");
        if (shopCoinEl) {
            shopCoinEl.innerText = coins;
        }
        
        document.querySelectorAll(".sub-coin-count").forEach(el => el.innerText = coins); 
    }

    function applyTheme(theme){
        document.body.classList.remove("theme-default", "theme-blue", "theme-gold", "theme-green", "theme-gradient", "theme-galaxy");
        document.body.classList.add("theme-" + theme); 
        currentTheme = theme; 
        localStorage.setItem("currentTheme", theme); 
        applySkinToRenderedArrows();
    }

    let currentHomeTheme = localStorage.getItem("homeTheme") || "default";
    function applyHomeTheme(theme) {
        const homeScreenEl = document.getElementById("home-screen");
        homeScreenEl.className = "home-screen"; 
        if(theme !== "default") {
            homeScreenEl.classList.add(`home-${theme}`);
        }
        currentHomeTheme = theme;
        localStorage.setItem("homeTheme", theme);
    }
    applyHomeTheme(currentHomeTheme);

    function checkDailyReward() {
        const today = new Date().toDateString();
        if (lastRewardDate !== today) {
            document.getElementById("daily-popup").style.display = "flex";
            document.getElementById("claim-daily-btn").onclick = function(){ 
                coins += 50; 
                lastRewardDate = today; 
                localStorage.setItem("coins", coins); 
                localStorage.setItem("lastRewardDate", today); 
                updateCoins(); 
                document.getElementById("daily-popup").style.display = "none"; 
                soundStar(3); 
                gameVibrate(100); 
            };
        }
    }

    function showWinPopup(modeType = "classic") {
        clearTimeout(messageTimeout); 
        winPopup.style.display = "flex";
        
        let endTime = new Date(); 
        let timeTakenSeconds = Math.floor((endTime - levelStartTime) / 1000);
        document.getElementById("pop-time").innerText = `${Math.floor(timeTakenSeconds / 60).toString().padStart(2, '0')}:${(timeTakenSeconds % 60).toString().padStart(2, '0')}`;
        
        if (modeType === "classic") {
            document.getElementById("pop-win-title").innerText = "FLAWLESS!";
            document.getElementById("pop-diff").innerText = (totalArrowsInCurrentLevel > 22) ? "Hard" : ((totalArrowsInCurrentLevel > 12) ? "Normal" : "Easy");
            
            totalWins++; 
            localStorage.setItem("totalWins", totalWins); 
            todayLevelsCount++; 
            localStorage.setItem("todayLevels", todayLevelsCount);
            
            document.getElementById("pop-today").innerText = todayLevelsCount; 
            document.getElementById("pop-errors").innerText = errorsCount; 
            document.getElementById("pop-hints-used").innerText = hintsUsedCount;

            let accuracy = "100%"; 
            let totalStarsToEarn = 3;
            if (errorsCount === 1) { accuracy = "66%"; totalStarsToEarn = 2; } 
            if (errorsCount >= 2) { accuracy = "33%"; totalStarsToEarn = 1; }
            document.getElementById("pop-accuracy").innerText = accuracy;
            
            let baseScore = 1000; 
            let speedBonus = Math.max(0, (30 - timeTakenSeconds) * 20);
            let targetScore = Math.max(500, baseScore + speedBonus - (errorsCount * 150));
            
            let earnedCoins = 10; 
            if (currentLevel % 10 === 0) {
                earnedCoins = 30;
                setTimeout(() => showToast("बॉस लेवल पार! 3X कॉइन्स मिले! 🪙", "success"), 1000);
            }
            if (currentLevel % 30 === 0) earnedCoins += 100;
            
            if (!bestTimes[currentLevel] || timeTakenSeconds < bestTimes[currentLevel]) { 
                bestTimes[currentLevel] = timeTakenSeconds; 
                localStorage.setItem("bestTimes", JSON.stringify(bestTimes)); 
            }
            if (!highScores[currentLevel] || targetScore > highScores[currentLevel]) { 
                highScores[currentLevel] = targetScore; 
                localStorage.setItem("highScores", JSON.stringify(highScores)); 
            }

            let bestTime = bestTimes[currentLevel] || timeTakenSeconds;
            document.getElementById("pop-best-time").innerText = `${Math.floor(bestTime / 60).toString().padStart(2, "0")}:${(bestTime % 60).toString().padStart(2, "0")}`;
            document.getElementById("pop-high-score").innerText = highScores[currentLevel] || targetScore;
            
            document.getElementById("pop-score").innerText = "0";
            document.getElementById("pop-coins").innerText = "+" + earnedCoins; 
            
            checkAchievements(timeTakenSeconds); 
            animateWinScore(targetScore, earnedCoins, totalStarsToEarn);

            document.getElementById("pop-next-btn").onclick = () => {
                currentLevel++;
                if (currentLevel <= 1000) { 
                    lives = 3; 
                    updateLives(); 
                    loadLevel(currentLevel); 
                } else { 
                    winPopup.style.display = "none"; 
                    gameStatus.innerText = "🏆 विजेता! आपने पूरे 1000 लेवल पार कर लिए!"; 
                    gameStatus.style.color = "#fbbf24"; 
                    actionBtn.innerText = "शुरुઆત से खेलें"; 
                    actionBtn.style.display = "inline-block"; 
                    actionBtn.onclick = restartFromZero; 
                }
            };

        } else if (modeType === "jigsaw") {
            document.getElementById("pop-win-title").innerText = "PUZZLE SOLVED!";
            document.getElementById("pop-diff").innerText = (jigsawGridSize >= 5) ? "Hard" : "Normal";
            document.getElementById("pop-today").innerText = "--"; 
            document.getElementById("pop-errors").innerText = "0"; 
            document.getElementById("pop-hints-used").innerText = "--";
            document.getElementById("pop-accuracy").innerText = "100%";
            document.getElementById("pop-best-time").innerText = "--:--";
            document.getElementById("pop-high-score").innerText = "--";
            
            let earnedCoins = 50; 
            document.getElementById("pop-score").innerText = "0";
            document.getElementById("pop-coins").innerText = "+" + earnedCoins; 
            
            animateWinScore(2500, earnedCoins, 3);

            document.getElementById("pop-next-btn").onclick = () => {
                winPopup.style.display = "none";
                document.getElementById("jigsaw-game-screen").style.display = "none";
                document.getElementById("jigsaw-select-screen").style.display = "flex";
                renderJigsawLevels();
            };
        }
    }

    function animateWinScore(targetScore, earnedCoins, totalStarsToEarn) {
        soundExplosion(); 
        gameVibrate([80,50,80]);

        const overlay = document.getElementById("win-popup"); 
        const colors = ['#ff0055', '#38bdf8', '#4caf50', '#fbbf24', '#a855f7', '#ff7300'];
        for (let i = 0; i < 90; i++) { 
            const confetti = document.createElement("div"); 
            confetti.className = "confetti-piece"; 
            confetti.style.background = colors[Math.floor(Math.random() * colors.length)]; 
            confetti.style.setProperty('--x', `${(Math.random() - 0.5) * 360}px`); 
            confetti.style.setProperty('--y', `${-280 - (Math.random() * 250)}px`); 
            confetti.style.setProperty('--r', `${Math.random() * 720}deg`); 
            confetti.style.width = (7 + Math.random() * 6) + "px"; 
            confetti.style.height = (12 + Math.random() * 9) + "px"; 
            confetti.style.animation = `confettiBoom ${2.2 + Math.random() * 1.3}s cubic-bezier(0.1, 0.85, 0.25, 1) forwards`; 
            overlay.appendChild(confetti); 
            setTimeout(() => { confetti.remove(); }, 3500); 
        }
        for (let i = 1; i <= 3; i++) { 
            setTimeout(() => { 
                if (i <= totalStarsToEarn) { 
                    document.getElementById(`star-${i}`).classList.add("active"); 
                    soundStar(i); 
                } 
            }, i * 400); 
        }

        setTimeout(() => {
            let currentScore = 0; 
            let stepScore = Math.ceil(targetScore / 25); 
            let currentEarnedCoins = 0; 
            let stepCoin = Math.max(1, Math.ceil(earnedCoins / 25));
            
            let counterInterval = setInterval(() => {
                currentScore += stepScore; 
                currentEarnedCoins += stepCoin;
                
                if (currentScore >= targetScore) { currentScore = targetScore; }
                if (currentEarnedCoins >= earnedCoins) { currentEarnedCoins = earnedCoins; }
                
                document.getElementById("pop-score").innerText = currentScore;
                
                soundScoreTick(); 
                if(currentEarnedCoins <= earnedCoins) soundCoinTick();
                
                if (currentScore === targetScore && currentEarnedCoins === earnedCoins) {
                    clearInterval(counterInterval);
                    coins += earnedCoins; 
                    updateCoins(); 
                }
            }, 40); 
        }, 1400);
    }

    function checkAchievements(timeTakenSeconds = 999) {
        let unlocked = "";
        if (!achievements.firstWin) { achievements.firstWin = true; unlocked = "🏅 अचीवमेंट: पहली जीत! 🏹"; }
        if (currentLevel >= 10 && !achievements.level10) { achievements.level10 = true; unlocked = "🏅 अचीवमेंट: लेवल 10 पार! 🎉"; }
        if (currentLevel >= 25 && !achievements.level25) { achievements.level25 = true; unlocked = "🏅 अचीवमेंट: लेवल 25 माइलस्टोन! 🔥"; }
        if (currentLevel >= 50 && !achievements.level50) { achievements.level50 = true; unlocked = "🏅 अचीvमेंट: हाफ सेंचुरी (लेवल 50)! ⚡"; }
        if (currentLevel >= 75 && !achievements.level75) { achievements.level75 = true; unlocked = "🏅 अचीवमेंट: लेवल 75 क्रश किया! 💪"; }
        if (currentLevel >= 100 && !achievements.level100) { achievements.level100 = true; unlocked = "🏅 अचीवमेंट: सेंचुरी (लेवल 100 कंप्लीट)! 🏆"; }
        if (currentLevel >= 150 && !achievements.level150) { achievements.level150 = true; unlocked = "🏅 अचीवमेंट: लेवल 150 MASTER! 👑"; }
        if (currentLevel >= 250 && !achievements.level250) { achievements.level250 = true; unlocked = "🏅 अचीवमेंट: लेवल 250 half चक्रव्यूह! 🌀"; }
        if (currentLevel >= 500 && !achievements.level500) { achievements.level500 = true; unlocked = "🏅 अचीवमेंट: 500 लेवल्स KING! 🦾"; }
        if (currentLevel >= 1000 && !achievements.level1000) { achievements.level1000 = true; unlocked = "🏅 अचीवमेंट: 1000 लेवल्स चक्रव्यूह विजेता! 👑🏅"; }
        if (hintsUsedCount === 0 && !achievements.noHint) { achievements.noHint = true; unlocked = "💡 अचीवमेंट: बिना दिमाग की बत्ती जलाए जीत! (No Hint)"; }
        if (errorsCount === 0 && !achievements.flawless) { achievements.flawless = true; unlocked = "⭐ अचीवमेंट: परफेक्ट निशाना! (Flawless Win)"; }
        if (coins >= 500 && !achievements.rich500) { achievements.rich500 = true; unlocked = "🪙 अचीवमेंट: अमीर खिलाड़ी! (500 Coins) 💰"; }
        if (coins >= 1000 && !achievements.rich1000) { achievements.rich1000 = true; unlocked = "🪙 अचीवमेंट: करोड़पति! (1000 Coins) 💎"; }
        if (timeTakenSeconds <= 10 && !achievements.speedRunner) { achievements.speedRunner = true; unlocked = "⚡ अचीवमेंट: बिजली की रफ़्तार! (Speed Runner) ⏱️"; }

        localStorage.setItem("achievements", JSON.stringify(achievements));
        if (unlocked !== "") showAchievement(unlocked);
    }

    function saveEndlessScoreToLeaderboard(finalScore) {
        if (finalScore === 0) return; 
        const now = new Date();
        const year = now.getFullYear();
        const month = (now.getMonth() + 1).toString().padStart(2, '0');
        const day = now.getDate().toString().padStart(2, '0');
        let hours = now.getHours();
        let ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; 
        const mins = now.getMinutes().toString().padStart(2,'0');
        const dateStr = `${day}/${month}/${year} [${hours.toString().padStart(2,'0')}:${mins} ${ampm}]`;
        const nameToSave = playerName ? playerName : "योद्धा (You)";

        const newRecord = { 
            name: nameToSave, 
            score: finalScore, 
            date: dateStr, 
            rank: (finalScore >= 31 ? "🥇 Ultimate Bow-Master" : (finalScore >= 11 ? "🥈 Chakra Elite" : "🥉 Beginner Archer")) 
        };
        endlessLeaderboard.push(newRecord); 
        endlessLeaderboard.sort((a, b) => b.score - a.score); 
        endlessLeaderboard = endlessLeaderboard.slice(0, 5);
        localStorage.setItem("endlessLeaderboard", JSON.stringify(endlessLeaderboard));
    }

    function refreshLeaderboardHTML() {
        const section = document.getElementById("endless-leaderboard-section");
        const container = document.getElementById("leaderboard-container"); 
        if(!isEndlessMode) { section.style.display = "none"; return; }
        
        section.style.display = "block";
        let html = `<table style="width: 100%; border-collapse: collapse; text-align: left; color: white;">
        <thead>
            <tr style="border-bottom: 1px solid #334155; color: #a855f7; font-weight: bold; font-size: 13px;">
                <th style="padding: 6px 2px; width: 45%;">रैंक/नाम</th>
                <th style="padding: 6px 2px; width: 40%; text-align: center;">तारीख/समय</th>
                <th style="padding: 6px 2px; width: 15%; text-align: right;">स्कोर</th>
            </tr>
        </thead><tbody>`;
        
        endlessLeaderboard.forEach((entry, index) => {
            let entryName = entry.name || "Player"; 
            let isYou = entryName.includes("You") || entryName === playerName ? "color:#4ade80;" : "color:#94a3b8;";
            
            let shortName = entryName;
            if (shortName.length > 20) {
                shortName = shortName.substring(0, 20) + "...";
            }

            let formattedDate = entry.date || "--/--/---- [--:--]";
            html += `<tr style="border-bottom: 1px solid rgba(51, 65, 85, 0.4);">
                <td style="padding: 8px 2px; font-weight: bold; color: #fbbf24; font-size: 14px;">#${index + 1} <span style="font-size: 12px; font-weight: normal; ${isYou} margin-left: 2px;">${shortName}</span></td>
                <td style="padding: 8px 2px; text-align: center; font-size: 10px; color: #cbd5e1; white-space: nowrap;">${formattedDate}</td>
                <td style="padding: 8px 2px; text-align: right; font-weight: 800; color: #f8fafc; font-size: 14px;">${entry.score}</td>
            </tr>`;
        });
        html += `</tbody></table>`; 
        container.innerHTML = html;
    }

    function cleanExitToHome() {
        clearTimeout(messageTimeout);
        clearTimeout(hintTimeout);
        stopPremiumMusic();
        
        board.innerHTML = "";
        activeArrows = [];
        lives = 3;
        isEndlessMode = false;
        
        document.getElementById("game-container").style.display = "none";
        document.getElementById("home-screen").style.display = "flex";
        
        activeMelody = homeMelody;
        currentNoteIndex = 0;
        if(homeMusicEnabled) startPremiumMusic();
    }

    function gameOver() {
        if(extraLives > 0){ 
            document.getElementById("revive-count-text").innerText = extraLives;
            document.getElementById("revive-popup").style.display = "flex";
            return; 
        } 
        executeGameOverFinal();
    }

    function executeGameOverFinal() {
        if (isEndlessMode) saveEndlessScoreToLeaderboard(endlessScore);
        totalGameOvers++; 
        localStorage.setItem("totalGameOvers", totalGameOvers); 
        clearTimeout(messageTimeout); 
        gameStatus.innerText = isEndlessMode ? `💀 गेम ओवर! अनंत चक्रव्यूह में आपका स्कोर: ${endlessScore}` : `💀 गेम ओवर! आप लेवल ${currentLevel} पर हार गए।`;
        gameStatus.style.color = "#ef4444"; 
        actionBtn.innerText = "यहीं से दोबारा कोशिश करें"; 
        actionBtn.style.display = "inline-block"; 
        actionBtn.style.opacity = "1";
        actionBtn.style.visibility = "visible";
        actionBtn.onclick = resetCurrentLevel;
    }

    document.getElementById("btn-revive-yes").onclick = function() {
        document.getElementById("revive-popup").style.display = "none";
        extraLives--; 
        localStorage.setItem("extraLives", extraLives); 
        lives = 1; 
        updateLives(); 
        updateCoins(); 
    };
    document.getElementById("btn-revive-no").onclick = function() {
        document.getElementById("revive-popup").style.display = "none";
        executeGameOverFinal();
    };

    function resetCurrentLevel() { 
        clearTimeout(messageTimeout); 
        lives = 3; 
        updateCoins(); 
        updateLives(); 
        isHintUsedInCurrentAttempt = false; 
        if (hintBtn) {
            hintBtn.disabled = false; 
            hintBtn.innerText = `💡 आईडिया (फ्री)`;
        }
        if (isEndlessMode) endlessScore = 0; 
        loadLevel(currentLevel); 
    }

    function restartFromZero() { 
        clearTimeout(messageTimeout); 
        localStorage.removeItem("savedLevel"); 
        localStorage.setItem("todayLevels", 0); 
        todayLevelsCount = 0; 
        lives = 3; 
        currentLevel = 1; 
        endlessScore = 0; 
        updateLives(); 
        updateCoins(); 
        loadLevel(currentLevel); 
    }

    document.getElementById("start-classic-btn").onclick = function() { isEndlessMode = false; lives = 3; launchGameEngine(); };
    document.getElementById("start-endless-btn").onclick = function() { isEndlessMode = true; endlessScore = 0; lives = 3; launchGameEngine(); };

    function launchGameEngine() {
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
        document.getElementById("home-screen").style.display = "none";
        document.getElementById("game-container").style.display = "flex";
        
        stopPremiumMusic(); 
        activeMelody = gameMelody; 
        currentNoteIndex = 0;
        
        updateLives(); 
        updateCoins(); 
        checkDailyReward(); 
        loadLevel(currentLevel);
        
        document.getElementById("music-toggle").checked = gameMusicEnabled;
        document.getElementById("sound-toggle").checked = soundEnabled;
        document.getElementById("vibration-toggle").checked = vibrationEnabled;
        
        if (gameMusicEnabled) startPremiumMusic();
    }

    document.getElementById("back-home-btn").onclick = function() {
        gameVibrate(30);
        cleanExitToHome();
    };

    document.getElementById("settings-btn").onclick = () => document.getElementById("settings-popup").style.display = "flex";
    document.getElementById("close-settings").onclick = () => document.getElementById("settings-popup").style.display = "none";
    document.getElementById("home-settings-btn").onclick = () => document.getElementById("home-settings-popup").style.display = "flex";
    document.getElementById("close-home-settings").onclick = () => document.getElementById("home-settings-popup").style.display = "none";
    document.getElementById("info-btn").onclick = () => document.getElementById("info-popup").style.display = "flex";
    document.getElementById("close-info").onclick = () => document.getElementById("info-popup").style.display = "none";

    window.openLink = function(type) {
        if(type === 'rate') window.open("https://play.google.com/store/apps/details?id=com.yourgame.teerkaman", "_blank");
        else if(type === 'feedback') window.location.href = "mailto:ranjitjaiswal@gmail.com?subject=Teer Kaman Feedback";
    };

    const gameMusicToggle = document.getElementById("music-toggle");
    const homeMusicToggle = document.getElementById("home-music-toggle");
    const homeThemeSelect = document.getElementById("home-theme-select");

    gameMusicToggle.onchange = function() { 
        gameMusicEnabled = this.checked; localStorage.setItem("gameMusicEnabled", gameMusicEnabled); 
        if(activeMelody === gameMelody) { if(gameMusicEnabled) startPremiumMusic(); else stopPremiumMusic(); } 
    };
    homeMusicToggle.onchange = function() { 
        homeMusicEnabled = this.checked; localStorage.setItem("homeMusicEnabled", homeMusicEnabled); 
        if(activeMelody === homeMelody) { if(homeMusicEnabled) startPremiumMusic(); else stopPremiumMusic(); } 
    };
    
    // 🔥 बदलाव: VIP थीम को चेक करके ही अप्लाई करने का कोड
    if(homeThemeSelect) {
        homeThemeSelect.value = currentHomeTheme;
        homeThemeSelect.onchange = function() { 
            if (this.value === "supreme-king" && !unlockedVipHome) {
                showToast("❌ पहले Shop से VIP Theme खरीदें!", "error");
                this.value = currentHomeTheme; // रिवर्ट कर दो
                return;
            }
            applyHomeTheme(this.value); 
        };
    }
    
    document.getElementById("sound-toggle").onchange = function() { soundEnabled = this.checked; localStorage.setItem("soundEnabled", soundEnabled); };
    document.getElementById("vibration-toggle").onchange = function() { vibrationEnabled = this.checked; localStorage.setItem("vibrationEnabled", vibrationEnabled); };

    if(gameMusicToggle) gameMusicToggle.checked = gameMusicEnabled;
    if(homeMusicToggle) homeMusicToggle.checked = homeMusicEnabled;
    if(document.getElementById("sound-toggle")) document.getElementById("sound-toggle").checked = soundEnabled;
    if(document.getElementById("vibration-toggle")) document.getElementById("vibration-toggle").checked = vibrationEnabled;

    document.getElementById("stats-btn").onclick = function(){
        document.getElementById("stat-level").innerText = isEndlessMode ? "Endless Mode" : currentLevel;
        document.getElementById("classic-stats-group").style.display = isEndlessMode ? "none" : "block";
        document.getElementById("stat-levels").innerText = currentLevel - 1;
        document.getElementById("stat-achievements").innerText = Object.values(achievements).filter(v=>v).length;
        document.getElementById("stat-wins").innerText = totalWins; 
        document.getElementById("stat-gameover").innerText = totalGameOvers;
        document.getElementById("stat-mistakes").innerText = totalMistakes; 
        document.getElementById("stat-hints").innerText = totalHints;
        document.getElementById("stat-today").innerText = todayLevelsCount;
        
        let highestScore = 0; 
        for (let level in highScores) { if (highScores[level] > highestScore) highestScore = highScores[level]; }
        document.getElementById("stat-highscore").innerText = isEndlessMode ? endlessHighScore : highestScore;
        
        let overallBest = null; 
        for (let level in bestTimes) { if (overallBest === null || bestTimes[level] < overallBest) overallBest = bestTimes[level]; }
        if (overallBest !== null && !isEndlessMode) { document.getElementById("stat-besttime").innerText = `${Math.floor(overallBest / 60).toString().padStart(2,"0")}:${(overallBest % 60).toString().padStart(2,"0")}`; } 
        else { document.getElementById("stat-besttime").innerText = "--:--"; }
        
        refreshLeaderboardHTML(); 
        document.getElementById("stats-popup").style.display="flex";
    };
    document.getElementById("close-stats").onclick = () => document.getElementById("stats-popup").style.display="none";

    const shopBtn = document.getElementById("shop-btn");
    const shopPopup = document.getElementById("shop-popup");
    const themesShopPopup = document.getElementById("themes-shop-popup");
    const skinsShopPopup = document.getElementById("skins-shop-popup");

    shopBtn.onclick=() => { updateCoins(); shopPopup.style.display="flex"; };
    document.getElementById("close-shop").onclick=() => shopPopup.style.display="none";
    document.getElementById("open-themes-shop").onclick = () => { buildThemesShop(); themesShopPopup.style.display="flex"; shopPopup.style.display="none"; };
    document.getElementById("open-skins-shop").onclick = () => { buildSkinsShop(); skinsShopPopup.style.display="flex"; shopPopup.style.display="none"; };
    document.getElementById("close-themes-shop").onclick = () => { themesShopPopup.style.display="none"; shopPopup.style.display="flex"; };
    document.getElementById("close-skins-shop").onclick = () => { skinsShopPopup.style.display="none"; shopPopup.style.display="flex"; };

    // 🔥 बदलाव: VIP Theme खरीदने का लॉजिक
    if(unlockedVipHome) {
        const vipBtn = document.getElementById("buy-vip-home");
        if(vipBtn) { vipBtn.innerText = "Owned"; vipBtn.disabled = true; vipBtn.style.opacity = "0.7"; }
    }

    document.getElementById("buy-vip-home").onclick = function() { 
        if(unlockedVipHome) { showToast("✅ आप पहले ही इसे खरीद चुके हैं!", "success"); return; }
        if(coins < 1000){ showToast("❌ Coins कम हैं! (1000 चाहिए)", "error"); return; } 
        coins -= 1000; 
        unlockedVipHome = true; 
        localStorage.setItem("unlockedVipHome", "true"); 
        updateCoins(); 
        showToast("👑 VIP Theme Unlocked!", "success"); 
        this.innerText = "Owned";
        this.disabled = true;
        this.style.opacity = "0.7";
    };

    window.buyItem = function(type, key, price) {
        if(coins < price) { showToast("❌ Coins कम हैं! गेम खेलें और कमाएं।", "error"); return; }
        coins -= price; updateCoins();
        if(type === 'theme') { unlockedThemes[key] = true; localStorage.setItem("unlockedThemes", JSON.stringify(unlockedThemes)); applyTheme(key); buildThemesShop(); document.getElementById("theme-select").value = key; }
        if(type === 'skin') { unlockedSkins[key] = true; localStorage.setItem("unlockedSkins", JSON.stringify(unlockedSkins)); arrowSkin = key; localStorage.setItem("arrowSkin", key); applySkinToRenderedArrows(); buildSkinsShop(); document.getElementById("arrow-select").value = key; }
        showToast("✅ खरीदारी सफल रही!", "success"); 
    };

    window.applyTheme = applyTheme;
    window.buildThemesShop = buildThemesShop;
    window.buildSkinsShop = buildSkinsShop;

    function buildThemesShop() {
        const list = document.getElementById("themes-list"); list.innerHTML = "";
        for(let key in THEMES_DB) {
            let item = THEMES_DB[key]; let isUnlocked = unlockedThemes[key]; let isEquipped = (currentTheme === key);
            let btnHTML = isEquipped ? `<button class="equipped-btn">ACTIVE ✅</button>` : (isUnlocked ? `<button onclick="applyTheme('${key}'); buildThemesShop(); document.getElementById('theme-select').value='${key}';">Use</button>` : `<button onclick="buyItem('theme', '${key}', ${item.price})">${item.price} <span class="coin-icon">🪙</span></button>`);
            list.innerHTML += `<div class="shop-item"><div>${item.name}</div>${btnHTML}</div>`;
        }
    }

    function buildSkinsShop() {
        const list = document.getElementById("skins-list"); list.innerHTML = "";
        for(let key in SKINS_DB) {
            let item = SKINS_DB[key]; let isUnlocked = unlockedSkins[key]; let isEquipped = (arrowSkin === key);
            let btnHTML = isEquipped ? `<button class="equipped-btn">ACTIVE ✅</button>` : (isUnlocked ? `<button onclick="arrowSkin='${key}'; localStorage.setItem('arrowSkin', '${key}'); applySkinToRenderedArrows(); buildSkinsShop(); document.getElementById('arrow-select').value='${key}';">Use</button>` : `<button onclick="buyItem('skin', '${key}', ${item.price})">${item.price} <span class="coin-icon">🪙</span></button>`);
            list.innerHTML += `<div class="shop-item"><div>${item.name}</div>${btnHTML}</div>`;
        }
    }

    document.getElementById("buy-life").onclick = function(){ if(coins < 50){ showToast("❌ Coins कम हैं! गेम खेलें और कमाएं।", "error"); return; } coins -= 50; extraLives++; localStorage.setItem("extraLives", extraLives); updateCoins(); updateLives(); showToast("✅ Extra Life खरीद ली!", "success"); };
    document.getElementById("buy-hint").onclick = function(){ if(coins < 30){ showToast("❌ Coins कम हैं! गेम खेलें और कमाएं।", "error"); return; } coins -= 30; extraHints++; localStorage.setItem("extraHints", extraHints); updateCoins(); showToast("✅ Hint खरीद लिया!", "success"); };

    const themeSelect = document.getElementById("theme-select"); const arrowSelect = document.getElementById("arrow-select");
    themeSelect.value = currentTheme; arrowSelect.value = arrowSkin;
    applyTheme(currentTheme); applySkinToRenderedArrows();
    themeSelect.onchange = function(){ if(!unlockedThemes[this.value]){ showToast("❌ पहले Shop से Theme खरीदें।", "error"); this.value = currentTheme; return; } applyTheme(this.value); };
    arrowSelect.onchange = function(){ if(!unlockedSkins[this.value]){ showToast("❌ पहले Shop से Arrow Skin खरीदें।", "error"); this.value = arrowSkin; return; } arrowSkin = this.value; localStorage.setItem("arrowSkin", arrowSkin); applySkinToRenderedArrows(); };
    updateCoins();

    // =======================================================
    // 🧩 PROFESSIONAL JIGSAW PUZZLE (MEMORY GRID) LOGIC 🧩
    // =======================================================

    const jigsawSelectScreen = document.getElementById("jigsaw-select-screen");
    const jigsawGameScreen = document.getElementById("jigsaw-game-screen");

    const MAX_JIGSAW_LEVELS = 300;
    let unlockedJigsawLevel = parseInt(localStorage.getItem("unlockedJigsawLevel")) || 1;
    let currentJigsawLevel = 1;

    function getJigsawImageForLevel(lvl) {
        return `images/level${lvl}.jpg`;
    }

    const startMemoryBtn = document.getElementById("start-memory-btn");
    if (startMemoryBtn) {
        startMemoryBtn.onclick = function() {
            document.getElementById("home-screen").style.display = "none";
            jigsawSelectScreen.style.display = "flex";
            renderJigsawLevels();
            gameVibrate(30);
            stopPremiumMusic();
            if(gameMusicEnabled) startPremiumMusic(); 
        };
    }

    document.getElementById("jigsaw-back-home").onclick = function() {
        jigsawSelectScreen.style.display = "none";
        document.getElementById("home-screen").style.display = "flex";
        gameVibrate(30);
        stopPremiumMusic();
        activeMelody = homeMelody;
        currentNoteIndex = 0;
        if(homeMusicEnabled) startPremiumMusic();
    };

    document.getElementById("jigsaw-back-select").onclick = function() {
        jigsawGameScreen.style.display = "none";
        jigsawSelectScreen.style.display = "flex";
        renderJigsawLevels();
        gameVibrate(30);
    };

    function renderJigsawLevels() {
        const grid = document.getElementById("jigsaw-levels-grid");
        grid.innerHTML = "";
        
        for(let i = 1; i <= MAX_JIGSAW_LEVELS; i++) {
            let isUnlocked = i <= unlockedJigsawLevel;
            let card = document.createElement("div");
            card.className = "jigsaw-level-card";
            
            if(isUnlocked) {
                let lvlImg = getJigsawImageForLevel(i);
                card.style.backgroundImage = `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.7)), url('${lvlImg}')`;
                card.style.backgroundSize = "cover";
                card.style.backgroundPosition = "center";
                card.innerHTML = `
                    <div style="font-size: 28px; font-weight: 900; color: white; text-shadow: 0 2px 5px rgba(0,0,0,0.8);">${i}</div>
                    <button style="background: #22c55e; color: white; border: none; padding: 6px 18px; border-radius: 15px; font-weight: bold; font-size: 13px; margin-top: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">Play</button>
                `;
                
                card.onclick = () => {
                    currentJigsawLevel = i;
                    document.getElementById("jigsaw-select-screen").style.display = "none";
                    document.getElementById("jigsaw-game-screen").style.display = "flex";
                    gameVibrate(30);
                    initJigsawGame();
                };
                
            } else {
                card.style.background = "#f1f5f9"; 
                card.style.border = "1px solid #e2e8f0";
                card.innerHTML = `
                    <div style="font-size: 28px; font-weight: 900; color: #cbd5e1;">${i}</div>
                    <div class="lock-icon" style="margin-top: 8px; font-size: 22px;">🔒</div>
                `;
                card.onclick = () => showToast(`❌ पहले लेवल ${i-1} पार करें!`, "error");
            }
            grid.appendChild(card);
        }
    }

    let eyeActive = false;
    document.getElementById("btn-toggle-eye").onclick = function() {
        eyeActive = !eyeActive;
        const fullPreview = document.getElementById("jigsaw-full-preview");
        const tray = document.getElementById("jigsaw-tray");
        
        if (eyeActive) {
            fullPreview.style.display = "flex";
            tray.style.visibility = "hidden"; 
            this.style.color = "#22c55e"; 
        } else {
            fullPreview.style.display = "none";
            tray.style.visibility = "visible"; 
            this.style.color = "#94a3b8"; 
        }
        gameVibrate(20);
    };

    document.getElementById("btn-open-broom").onclick = function() {
        document.getElementById("jigsaw-clear-popup").style.display = "flex";
        gameVibrate(20);
    };
    document.getElementById("btn-clear-no").onclick = function() {
        document.getElementById("jigsaw-clear-popup").style.display = "none";
    };

    const themePopup = document.getElementById("jigsaw-theme-popup");
    const boardBg = document.getElementById("jigsaw-board-bg");

    document.getElementById("btn-open-theme").onclick = function() { themePopup.style.display = "flex"; gameVibrate(20); };
    document.getElementById("btn-theme-done").onclick = function() { themePopup.style.display = "none"; };

    document.querySelectorAll(".jigsaw-theme-box").forEach(box => {
        box.onclick = function() {
            document.querySelectorAll(".jigsaw-theme-box").forEach(b => b.classList.remove("active-theme"));
            this.classList.add("active-theme");
            boardBg.style.background = this.getAttribute("data-bg");
            gameVibrate(20);
        };
    });

    const boardSize = 350; 
    let jigsawGridSize = 4; 
    let baseSize = boardSize / jigsawGridSize; 
    let jigsawImage = "";

    let lockedPiecesCount = 0;
    const dropZone = document.getElementById("jigsaw-drop-zone");
    const jigsawTray = document.getElementById("jigsaw-tray");

    function getPiecePath(s, top, right, bottom, left) {
        let p = `M 0 0 `;
        if(top !== 0) { p += `L ${s*0.35} 0 C ${s*0.35} ${top*-12}, ${s*0.65} ${top*-12}, ${s*0.65} 0 L ${s} 0 `; } else { p += `L ${s} 0 `; }
        if(right !== 0) { p += `L ${s} ${s*0.35} C ${s + right*12} ${s*0.35}, ${s + right*12} ${s*0.65}, ${s} ${s*0.65} L ${s} ${s} `; } else { p += `L ${s} ${s} `; }
        if(bottom !== 0) { p += `L ${s*0.65} ${s} C ${s*0.65} ${s + bottom*12}, ${s*0.35} ${s + bottom*12}, ${s*0.35} ${s} L 0 ${s} `; } else { p += `L 0 ${s} `; }
        if(left !== 0) { p += `L 0 ${s*0.65} C ${left*-12} ${s*0.65}, ${left*-12} ${s*0.35}, 0 ${s*0.35} L 0 0 `; } else { p += `L 0 0 `; }
        return p + " Z";
    }

    function initJigsawGame() {
        dropZone.innerHTML = "";
        jigsawTray.innerHTML = "";
        lockedPiecesCount = 0;
        
        eyeActive = false;
        document.getElementById("jigsaw-full-preview").style.display = "none";
        document.getElementById("jigsaw-tray").style.visibility = "visible";
        document.getElementById("btn-toggle-eye").style.color = "#94a3b8";
        
        document.getElementById("jigsaw-current-level-text").innerText = currentJigsawLevel;

        if(currentJigsawLevel <= 15) jigsawGridSize = 5; 
        else if(currentJigsawLevel <= 50) jigsawGridSize = 6; 
        else jigsawGridSize = 7; 
        
        baseSize = boardSize / jigsawGridSize; 
        dropZone.style.width = boardSize + "px";
        dropZone.style.height = boardSize + "px";

        jigsawImage = getJigsawImageForLevel(currentJigsawLevel);
        document.getElementById("jigsaw-preview-img").src = jigsawImage;

        let hKnobs = []; let vKnobs = [];
        for(let r=0; r<=jigsawGridSize; r++) { hKnobs.push([]); vKnobs.push([]); }
        for(let r=0; r<jigsawGridSize; r++) {
            for(let c=0; c<jigsawGridSize; c++) {
                hKnobs[r][c] = c === 0 ? 0 : (Math.random() > 0.5 ? 1 : -1);
                vKnobs[r][c] = r === 0 ? 0 : (Math.random() > 0.5 ? 1 : -1);
            }
        }

        let piecesArray = [];

        for (let r = 0; r < jigsawGridSize; r++) {
            for (let c = 0; c < jigsawGridSize; c++) {
                let piece = document.createElement("div");
                piece.className = "jigsaw-piece";
                piece.style.width = baseSize + "px";
                piece.style.height = baseSize + "px";
                
                let topK = r === 0 ? 0 : vKnobs[r][c] * -1; 
                let bottomK = r === jigsawGridSize - 1 ? 0 : vKnobs[r+1][c];
                let leftK = c === 0 ? 0 : hKnobs[r][c] * -1;
                let rightK = c === jigsawGridSize - 1 ? 0 : hKnobs[r][c+1];
                
                let pathStr = getPiecePath(baseSize, topK, rightK, bottomK, leftK);
                
                let svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                svg.setAttribute("width", baseSize); svg.setAttribute("height", baseSize);
                svg.style.overflow = "visible"; svg.style.position = "absolute"; 
                
                let defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
                let clip = document.createElementNS("http://www.w3.org/2000/svg", "clipPath");
                clip.id = `clip-${r}-${c}`;
                let clipPathD = document.createElementNS("http://www.w3.org/2000/svg", "path");
                clipPathD.setAttribute("d", pathStr);
                clip.appendChild(clipPathD); defs.appendChild(clip); svg.appendChild(defs);
                
                let img = document.createElementNS("http://www.w3.org/2000/svg", "image");
                img.setAttribute("href", jigsawImage);
                img.setAttribute("width", boardSize); img.setAttribute("height", boardSize);
                img.setAttribute("x", -c * baseSize); img.setAttribute("y", -r * baseSize);
                img.setAttribute("preserveAspectRatio", "none");
                img.setAttribute("clip-path", `url(#clip-${r}-${c})`);
                svg.appendChild(img);
                
                let border = document.createElementNS("http://www.w3.org/2000/svg", "path");
                border.setAttribute("d", pathStr); border.setAttribute("stroke", "rgba(0,0,0,0.4)"); border.setAttribute("stroke-width", "1"); border.setAttribute("fill", "none");
                border.setAttribute("class", "puzzle-stroke-border");
                svg.appendChild(border);
                
                piece.appendChild(svg);
                
                piece.dataset.correctX = c * baseSize;
                piece.dataset.correctY = r * baseSize;
                piece.dataset.locked = "false";
                
                addDragEventsToPiece(piece);
                piecesArray.push(piece);
            }
        }
        
        piecesArray.sort(() => Math.random() - 0.5);
        piecesArray.forEach(p => { 
            p.style.position = "relative"; 
            p.style.flexShrink = "0";
            jigsawTray.appendChild(p); 
        });
    }

    document.getElementById("btn-jigsaw-hint").onclick = function() {
        if (coins < 30) {
            showToast("❌ Coins कम हैं! (30 चाहिए)", "error");
            return;
        }
        
        let availablePieces = Array.from(document.querySelectorAll(".jigsaw-piece")).filter(p => p.dataset.locked === "false");
        
        if (availablePieces.length > 0) {
            coins -= 30;
            updateCoins();
            gameVibrate([20, 40]);
            
            let pieceToHint = availablePieces[0];
            let correctX = parseFloat(pieceToHint.dataset.correctX);
            let correctY = parseFloat(pieceToHint.dataset.correctY);
            
            dropZone.appendChild(pieceToHint);
            pieceToHint.style.position = "absolute";
            pieceToHint.style.left = correctX + "px";
            pieceToHint.style.top = correctY + "px";
            pieceToHint.dataset.locked = "true";
            
            let strokePath = pieceToHint.querySelector(".puzzle-stroke-border");
            if(strokePath) strokePath.setAttribute("stroke", "transparent");
            
            pieceToHint.style.animation = "pieceLockFlash 0.4s ease";
            createSparkleEffect(correctX + baseSize / 2, correctY + baseSize / 2);
            playEffect(1200, 'sine', 0.05, 0.5); 
            
            lockedPiecesCount++;
            checkJigsawWin();
        }
    };

    let draggedPiece = null;
    let offsetX = 0, offsetY = 0;
    let initialTouchX = 0, initialTouchY = 0;
    let isActivelyDragging = false;

    function addDragEventsToPiece(piece) {
        piece.style.touchAction = "none"; 
        piece.addEventListener('touchstart', dragStart, {passive: false});
        piece.addEventListener('mousedown', dragStart);
    }

    function dragStart(e) {
        if (this.dataset.locked === "true") return; 
        
        draggedPiece = this;
        isActivelyDragging = false;
        
        let clientX = e.touches ? e.touches[0].clientX : e.clientX;
        let clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        initialTouchX = clientX;
        initialTouchY = clientY;
        
        let rect = draggedPiece.getBoundingClientRect();
        offsetX = clientX - rect.left;
        offsetY = clientY - rect.top;

        document.addEventListener('touchmove', dragMove, {passive: false});
        document.addEventListener('touchend', dragEnd);
        document.addEventListener('mousemove', dragMove, {passive: false});
        document.addEventListener('mouseup', dragEnd);
    }

    function dragMove(e) {
        if (!draggedPiece) return;
        
        let clientX = e.touches ? e.touches[0].clientX : e.clientX;
        let clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        if (!isActivelyDragging) {
            let deltaX = Math.abs(clientX - initialTouchX);
            let deltaY = Math.abs(clientY - initialTouchY);
            
            if (deltaY > 5 || deltaX > 5) {
                isActivelyDragging = true;
                
                let rect = draggedPiece.getBoundingClientRect(); 
                draggedPiece.style.position = "absolute";
                document.body.appendChild(draggedPiece);
                
                offsetX = clientX - rect.left;
                offsetY = clientY - rect.top;
                
                draggedPiece.style.zIndex = 1000;
                gameVibrate(15);
            } else {
                return;
            }
        }
        
        if (isActivelyDragging) {
            e.preventDefault(); 
            draggedPiece.style.left = (clientX - offsetX) + "px";
            draggedPiece.style.top = (clientY - offsetY) + "px";
        }
    }

    function dragEnd(e) {
        if (!draggedPiece) return;
        
        document.removeEventListener('touchmove', dragMove);
        document.removeEventListener('touchend', dragEnd);
        document.removeEventListener('mousemove', dragMove);
        document.removeEventListener('mouseup', dragEnd);

        if (isActivelyDragging) {
            let dropRect = dropZone.getBoundingClientRect();
            let pieceRect = draggedPiece.getBoundingClientRect();
            
            let pCenterX = pieceRect.left + baseSize / 2;
            let pCenterY = pieceRect.top + baseSize / 2;
            
            if (pCenterX > dropRect.left && pCenterX < dropRect.right && pCenterY > dropRect.top && pCenterY < dropRect.bottom) {
                let relX = pieceRect.left - dropRect.left;
                let relY = pieceRect.top - dropRect.top;
                
                let correctX = parseFloat(draggedPiece.dataset.correctX);
                let correctY = parseFloat(draggedPiece.dataset.correctY);
                
                if (Math.abs(relX - correctX) < 30 && Math.abs(relY - correctY) < 30) {
                    dropZone.appendChild(draggedPiece);
                    draggedPiece.style.position = "absolute";
                    draggedPiece.style.left = correctX + "px";
                    draggedPiece.style.top = correctY + "px";
                    draggedPiece.dataset.locked = "true";
                    draggedPiece.style.zIndex = ""; 
                    
                    let strokePath = draggedPiece.querySelector(".puzzle-stroke-border");
                    if(strokePath) strokePath.setAttribute("stroke", "transparent");
                    
                    draggedPiece.style.animation = "pieceLockFlash 0.4s ease";
                    createSparkleEffect(correctX + baseSize / 2, correctY + baseSize / 2);
                    
                    gameVibrate([30, 50]); 
                    playEffect(1200, 'sine', 0.05, 0.5); 
                    setTimeout(() => playEffect(800, 'triangle', 0.1, 0.4), 50);
                    
                    lockedPiecesCount++;
                    checkJigsawWin();
                } else {
                    dropZone.appendChild(draggedPiece);
                    draggedPiece.style.position = "absolute";
                    draggedPiece.style.left = (pieceRect.left - dropRect.left) + "px";
                    draggedPiece.style.top = (pieceRect.top - dropRect.top) + "px";
                    draggedPiece.style.zIndex = "10"; 
                }
            } else {
                returnPieceToTray(); 
            }
        } else {
            if (draggedPiece.parentElement !== jigsawTray && draggedPiece.dataset.locked !== "true") {
                returnPieceToTray();
            }
        }
        
        if (draggedPiece) {
            draggedPiece = null;
        }
        isActivelyDragging = false;
    }

    function createSparkleEffect(x, y) {
        let sparkle = document.createElement("div");
        sparkle.className = "snap-sparkle";
        sparkle.style.left = x + "px";
        sparkle.style.top = y + "px";
        dropZone.appendChild(sparkle);
        setTimeout(() => { if (sparkle.parentNode) { sparkle.remove(); } }, 400);
    }

    function returnPieceToTray() {
        if (draggedPiece) {
            draggedPiece.style.position = "relative";
            draggedPiece.style.left = "0px";
            draggedPiece.style.top = "0px";
            draggedPiece.style.zIndex = ""; 
            jigsawTray.appendChild(draggedPiece);
            gameVibrate(20);
        }
    }

    function checkJigsawWin() {
        if (lockedPiecesCount === jigsawGridSize * jigsawGridSize) {
            setTimeout(() => {
                showToast(`🏆 लेवल ${currentJigsawLevel} पार!`, "success");
                gameVibrate([100, 50, 100, 50, 200]);
                
                dropZone.style.boxShadow = "0 0 30px #22c55e";
                
                if (currentJigsawLevel === unlockedJigsawLevel && unlockedJigsawLevel < MAX_JIGSAW_LEVELS) {
                    unlockedJigsawLevel++;
                    localStorage.setItem("unlockedJigsawLevel", unlockedJigsawLevel);
                }
                
                showWinPopup("jigsaw");
                
                setTimeout(() => dropZone.style.boxShadow = "none", 2000);
            }, 300);
        }
    }

    document.getElementById("btn-clear-yes").onclick = function() {
        document.getElementById("jigsaw-clear-popup").style.display = "none";
        const allPieces = document.querySelectorAll(".jigsaw-piece");
        allPieces.forEach(p => {
            if(p.dataset.locked !== "true") {
                p.style.position = "relative";
                p.style.left = "0px";
                p.style.top = "0px";
                jigsawTray.appendChild(p);
            }
        });
        showToast("अधूरे टुकड़े ट्रे में वापस भेज दिए गए!", "success");
        gameVibrate([50, 50]);
    };

});