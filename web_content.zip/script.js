"use strict";

const API = "https://api.binance.com";
const $ = id => document.getElementById(id);

let symbol = $("symbol").value;
let candles = {};
let busy = false;
let requestVersion = 0;

const timeframes = [
  { name: "3", interval: "3m", limit: 100 },
  { name: "5", interval: "5m", limit: 100 },
  { name: "15", interval: "15m", limit: 100 }
];

function fmt(n) {
  if (!Number.isFinite(n)) return "--";
  return n.toLocaleString("en-US", { maximumFractionDigits: 6 });
}

async function getJSON(url) {
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) throw new Error("HTTP " + response.status);
  return response.json();
}

function ema(values, period) {
  if (values.length < period) return NaN;
  const k = 2 / (period + 1);
  let result = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < values.length; i++) {
    result = values[i] * k + result * (1 - k);
  }
  return result;
}

function rsi(values, period = 14) {
  if (values.length <= period) return NaN;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const change = values[i] - values[i - 1];
    if (change > 0) gain += change;
    else loss -= change;
  }
  gain /= period;
  loss /= period;
  for (let i = period + 1; i < values.length; i++) {
    const change = values[i] - values[i - 1];
    gain = (gain * (period - 1) + Math.max(change, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-change, 0)) / period;
  }
  if (loss === 0) return 100;
  return 100 - 100 / (1 + gain / loss);
}

function macd(values) {
  // MACD line: EMA(12) - EMA(26). Signal-line crossover is not calculated here.
  if (values.length < 35) return NaN;
  return ema(values, 12) - ema(values, 26);
}

function analyze(data) {
  if (!data || data.length < 55) return null;

  // Exclude the currently-forming candle to reduce signal flicker.
  const closed = data.slice(0, -1);
  const close = closed.map(c => c.close);
  const last = closed[closed.length - 1];
  const e9 = ema(close, 9), e21 = ema(close, 21), e50 = ema(close, 50);
  const rv = rsi(close, 14), mv = macd(close);
  const bullish = e9 > e21 && e21 > e50 && last.close > e21;
  const bearish = e9 < e21 && e21 < e50 && last.close < e21;

  return { price: last.close, e9, e21, e50, rsi: rv, macd: mv,
    volume: last.volume, bullish, bearish };
}

async function loadTimeframe(tf, currentSymbol) {
  const url = `${API}/api/v3/klines?symbol=${encodeURIComponent(currentSymbol)}&interval=${tf.interval}&limit=${tf.limit}`;
  const rows = await getJSON(url);
  return rows.map(row => ({
    time: Number(row[0]),
    close: Number(row[4]),
    volume: Number(row[5])
  }));
}

function trendName(a) {
  if (!a) return "Loading";
  if (a.bullish) return "BULLISH";
  if (a.bearish) return "BEARISH";
  return "SIDEWAYS";
}

function setTrend(id, value) {
  const el = $(id);
  el.textContent = value;
  el.style.color = value === "BULLISH" ? "#4ade80" :
    value === "BEARISH" ? "#fb7185" : "#facc15";
}

function updateIndicators(a) {
  $("ema9").textContent = fmt(a.e9);
  $("ema21").textContent = fmt(a.e21);
  $("ema50").textContent = fmt(a.e50);
  $("rsi").textContent = fmt(a.rsi);
  $("macd").textContent = fmt(a.macd);
  $("volume").textContent = fmt(a.volume);
}

function generateSignal(a3, a5, a15) {
  if (!a3 || !a5 || !a15) {
    return { signal: "WAIT", reason: "Waiting for sufficient candle data." };
  }

  const buy = a5.bullish && a15.bullish && a3.bullish &&
    a5.rsi >= 50 && a5.rsi < 70 && a15.rsi >= 50 &&
    a5.macd > 0 && a15.macd > 0;

  const sell = a5.bearish && a15.bearish && a3.bearish &&
    a5.rsi <= 50 && a5.rsi > 30 && a15.rsi <= 50 &&
    a5.macd < 0 && a15.macd < 0;

  if (buy) return { signal: "BUY", reason:
    "3m, 5m and 15m trends agree bullishly, with RSI and MACD confirmation." };
  if (sell) return { signal: "SELL", reason:
    "3m, 5m and 15m trends agree bearishly, with RSI and MACD confirmation." };
  return { signal: "WAIT", reason:
    "Timeframes or indicators disagree. Wait for clearer confirmation." };
}

function updateTradeLevels(signal, price) {
  $("entry").textContent = fmt(price);
  if (signal === "BUY") {
    $("target1").textContent = fmt(price * 1.005);
    $("target2").textContent = fmt(price * 1.01);
    $("stoploss").textContent = fmt(price * 0.995);
  } else if (signal === "SELL") {
    $("target1").textContent = fmt(price * 0.995);
    $("target2").textContent = fmt(price * 0.99);
    $("stoploss").textContent = fmt(price * 1.005);
  } else {
    $("target1").textContent = $("target2").textContent = $("stoploss").textContent = "--";
  }
}

async function refreshMarket() {
  if (busy) return;
  busy = true;
  const thisVersion = ++requestVersion;
  const selectedSymbol = symbol;
  $("connection").textContent = "Loading market data...";

  try {
    const [ticker, ...results] = await Promise.all([
      getJSON(`${API}/api/v3/ticker/24hr?symbol=${encodeURIComponent(selectedSymbol)}`),
      ...timeframes.map(async tf => ({ name: tf.name, data: await loadTimeframe(tf, selectedSymbol) }))
    ]);

    // Ignore stale results if the selected asset changed during a request.
    if (thisVersion !== requestVersion || selectedSymbol !== symbol) return;

    const price = Number(ticker.lastPrice);
    const change = Number(ticker.priceChangePercent);
    $("price").textContent = fmt(price);
    $("change").textContent = `${change >= 0 ? "+" : ""}${fmt(change)}% (24h)`;
    $("change").style.color = change >= 0 ? "#4ade80" : "#fb7185";
    $("updated").textContent = "Updated: " + new Date().toLocaleTimeString();

    results.forEach(item => { candles[item.name] = analyze(item.data); });
    const a3 = candles["3"], a5 = candles["5"], a15 = candles["15"];
    setTrend("trend3", trendName(a3));
    setTrend("trend5", trendName(a5));
    setTrend("trend15", trendName(a15));
    if (a5) updateIndicators(a5);

    const result = generateSignal(a3, a5, a15);
    $("signal").textContent = result.signal;
    $("signal").className = result.signal.toLowerCase();
    $("reason").textContent = result.reason;
    updateTradeLevels(result.signal, price);
    $("connection").textContent = "Connected • Binance public market data";
  } catch (error) {
    console.error("Market data error:", error);
    $("connection").textContent = "Connection error — retrying";
    $("reason").textContent = "Could not load market data. Check your internet connection, symbol availability, or whether Binance API is reachable.";
  } finally {
    busy = false;
  }
}

$("symbol").addEventListener("change", event => {
  symbol = event.target.value;
  requestVersion++; // Invalidate any in-flight request for the previous symbol.
  refreshMarket();
});
$("refresh").addEventListener("click", refreshMarket);

refreshMarket();
setInterval(refreshMarket, 15000);
