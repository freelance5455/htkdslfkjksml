let calculadora = document.getElementById('calculadora')
let visor = document.getElementById('visor')

visor.textContent = 0

let numeros = document.querySelectorAll('.numero')

for (let numero of numeros) {
    numero.addEventListener('click', function() {
        let valor = numero.textContent
        

        if (visor.textContent === '0') {
            visor.textContent = valor
        } else {
            visor.textContent += valor
        }
    })
}

let primeiroNumero = ''
let operacao = ''

let soma = document.getElementById('add')
let mult = document.getElementById('mult')
let div = document.getElementById('div')
let sub = document.getElementById('sub')

function prepararOperacao(sinal) {
    primeiroNumero = visor.textContent
    operacao = sinal
    visor.textContent = '0'
}

soma.addEventListener('click', function() {
    prepararOperacao('+')
})

sub.addEventListener('click', function() {
    prepararOperacao('-')
})

mult.addEventListener('click', function() {
    prepararOperacao('x')
})

div.addEventListener('click', function() {
    prepararOperacao('÷')
})



let resultado = document.getElementById('resultado')

resultado.addEventListener('click', function() {
    let segundoNumero = visor.textContent

    let primeiro = Number(primeiroNumero)
    let segundo = Number(segundoNumero)

    if (operacao === '+') {
        visor.textContent = primeiro + segundo
    } else if (operacao === '-') {
        visor.textContent = primeiro - segundo

    } else if (operacao === 'x') {
        visor.textContent = primeiro * segundo
    } else if (operacao === '÷') {
        visor.textContent = primeiro / segundo
    }    
})


let limpar = document.getElementById('limpar')

limpar.addEventListener('click', function() {
    visor.textContent = 0
    primeiroNumero = ''
    operacao = ''
})
