const DEFAULT_FACTOR = 4.3318;

let FACTOR =
  Number(localStorage.getItem("shayan_gold_factor")) ||
  DEFAULT_FACTOR;

let pdfGenerating = false;

let trades = [];

try {
  const savedTrades =
    localStorage.getItem("shayan_gold_trades");

  trades =
    savedTrades
      ? JSON.parse(savedTrades)
      : [];

  if (!Array.isArray(trades)) {
    trades = [];
  }

} catch (error) {
  trades = [];
}

let editingTradeId = null;


/* ================= DATE ================= */

function getPersianDate(date = new Date()) {

  return new Intl.DateTimeFormat(
    "fa-IR-u-ca-persian",
    {
      year: "numeric",
      month: "long",
      day: "numeric"
    }
  ).format(date);

}


function getDateKey(date = new Date()) {

  const y =
    date.getFullYear();

  const m =
    String(
      date.getMonth() + 1
    ).padStart(2, "0");

  const d =
    String(
      date.getDate()
    ).padStart(2, "0");

  return `${y}-${m}-${d}`;

}


function getTime(date = new Date()) {

  return date.toLocaleTimeString(
    "fa-IR",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );

}


/* ================= NUMBERS ================= */

function normalizeNumber(value) {

  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return 0;
  }

  let text =
    String(value)
      .replace(/,/g, "")
      .replace(/\s/g, "");

  text =
    text.replace(
      /[۰-۹]/g,
      d =>
        "۰۱۲۳۴۵۶۷۸۹".indexOf(d)
    );

  text =
    text.replace(
      /[٠-٩]/g,
      d =>
        "٠١٢٣٤٥٦٧٨٩".indexOf(d)
    );

  return Number(text) || 0;

}


function formatNumber(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 3
      }
    );

}


function formatMoney(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 0
      }
    );

}


function formatInputNumber(value) {

  const number =
    normalizeNumber(value);

  if (!number) {
    return "";
  }

  return number.toLocaleString(
    "en-US",
    {
      maximumFractionDigits: 3
    }
  );

}


/* ================= STORAGE ================= */

function saveTrades() {

  localStorage.setItem(
    "shayan_gold_trades",
    JSON.stringify(trades)
  );

}


/* ================= LEDGER ================= */

function calculateLedger() {

  let position = 0;

  let averageCost = 0;

  let realizedProfit = 0;


  const sortedTrades =
    [...trades].sort(
      (a, b) =>
        new Date(a.createdAt).getTime() -
        new Date(b.createdAt).getTime()
    );


  for (const trade of sortedTrades) {

    const qty =
      Number(trade.weight) || 0;

    const price =
      Number(trade.price18) || 0;


    if (
      qty <= 0 ||
      price <= 0
    ) {
      continue;
    }


    /* ===== BUY ===== */

    if (trade.type === "buy") {

      if (position < 0) {

        const shortQty =
          Math.abs(position);

        const closeQty =
          Math.min(
            qty,
            shortQty
          );


        realizedProfit +=
          closeQty *
          (averageCost - price);


        position += closeQty;


        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position = remaining;

          averageCost = price;

        } else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position > 0) {

        const oldQty =
          position;

        const newQty =
          oldQty + qty;


        averageCost =
          (
            oldQty * averageCost +
            qty * price
          ) / newQty;


        position =
          newQty;

      }

      else {

        position = qty;

        averageCost = price;

      }

    }


    /* ===== SELL ===== */

    else if (trade.type === "sell") {

      if (position > 0) {

        const closeQty =
          Math.min(
            position,
            qty
          );


        realizedProfit +=
          closeQty *
          (price - averageCost);


        position -= closeQty;


        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position =
            -remaining;

          averageCost =
            price;

        }

        else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position < 0) {

        const oldShortQty =
          Math.abs(position);

        const newShortQty =
          oldShortQty + qty;


        averageCost =
          (
            oldShortQty * averageCost +
            qty * price
          ) / newShortQty;


        position =
          -newShortQty;

      }

      else {

        position =
          -qty;

        averageCost =
          price;

      }

    }

  }


  return {
    position,
    averageCost,
    realizedProfit
  };

}


/* ================= TRADE HTML ================= */

function createTradeHTML(trade) {

  return `

    <div class="trade-item">

      <div class="trade-main">

        <span>
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>

        <span class="trade-type ${trade.type}">

          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}

        </span>

      </div>


      <div class="trade-details">

        <span>
          وزن:
          ${formatNumber(trade.weight)}
          گرم
        </span>

        <span>
          فی:
          ${formatMoney(trade.price18)}
          تومان
        </span>

        <span>
          مظنه:
          ${formatMoney(trade.mazhane)}
          تومان
        </span>

        <span>
          کل:
          ${formatMoney(trade.totalPrice)}
          تومان
        </span>

        <span>
          ${trade.time || "-"}
        </span>

      </div>

    </div>

  `;

}


/* ================= HOME ================= */

function renderHome() {

  const today =
    getDateKey();


  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );


  let bought = 0;

  let sold = 0;


  todayTrades.forEach(
    trade => {

      if (trade.type === "buy") {

        bought +=
          Number(trade.weight) || 0;

      } else {

        sold +=
          Number(trade.weight) || 0;

      }

    }
  );


  const ledger =
    calculateLedger();


  const balance =
    Math.abs(ledger.position);


  const average =
    ledger.averageCost;


  const averageMazhane =
    average * FACTOR;


  const todayDate =
    document.getElementById(
      "todayDate"
    );

  if (todayDate) {

    todayDate.textContent =
      getPersianDate();

  }


  const homeTradeCount =
    document.getElementById(
      "homeTradeCount"
    );

  if (homeTradeCount) {

    homeTradeCount.textContent =
      formatNumber(todayTrades.length);

  }


  const homeBought =
    document.getElementById(
      "homeBought"
    );

  if (homeBought) {

    homeBought.textContent =
      `${formatNumber(bought)} گرم`;

  }


  const homeSold =
    document.getElementById(
      "homeSold"
    );

  if (homeSold) {

    homeSold.textContent =
      `${formatNumber(sold)} گرم`;

  }


  const homeBalance =
    document.getElementById(
      "homeBalance"
    );

  if (homeBalance) {

    homeBalance.textContent =
      `${formatNumber(balance)} گرم`;

  }


  const averageLabel =
    document.getElementById(
      "homeAverageLabel"
    );


  if (averageLabel) {

    if (ledger.position < 0) {

      averageLabel.textContent =
        "فی میانگین فروش باز";

    } else {

      averageLabel.textContent =
        "فی میانگین موجودی باقی‌مانده";

    }

  }


  const homeAveragePrice =
    document.getElementById(
      "homeAveragePrice"
    );

  if (homeAveragePrice) {

    homeAveragePrice.textContent =
      `${formatMoney(average)} تومان`;

  }


  const homeAverageMazhane =
    document.getElementById(
      "homeAverageMazhane"
    );

  if (homeAverageMazhane) {

    homeAverageMazhane.textContent =
      `مظنه میانگین: ${formatMoney(averageMazhane)} تومان`;

  }


  const profitElement =
    document.getElementById(
      "homeRealizedProfit"
    );


  if (profitElement) {

    profitElement.textContent =
      `${formatMoney(
        ledger.realizedProfit
      )} تومان`;


    profitElement.classList.remove(
      "closed-profit",
      "closed-loss"
    );


    if (ledger.realizedProfit > 0) {

      profitElement.classList.add(
        "closed-profit"
      );

    }

    else if (
      ledger.realizedProfit < 0
    ) {

      profitElement.classList.add(
        "closed-loss"
      );

    }

  }


  renderTradeList(
    todayTrades,
    "homeTrades"
  );

}


/* ================= TODAY TRADES ================= */

function renderTodayTrades() {

  const today =
    getDateKey();


  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );


  renderTradeList(
    todayTrades,
    "todayTrades"
  );

}


/* ================= GENERIC LIST ================= */

function renderTradeList(
  list,
  elementId
) {

  const container =
    document.getElementById(
      elementId
    );


  if (!container) {
    return;
  }


  if (
    !Array.isArray(list) ||
    list.length === 0
  ) {

    container.innerHTML =
      `<div class="empty">
        معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  const sorted =
    [...list].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() -
        new Date(a.createdAt).getTime()
    );


  container.innerHTML =
    sorted
      .map(
        trade =>
          createTradeHTML(trade)
      )
      .join("");

}


/* ================= HISTORY ================= */

function renderHistory(
  openDateKey = null
) {

  const container =
    document.getElementById(
      "historyList"
    );


  if (!container) {
    return;
  }


  const openDates =
    new Set(
      Array.from(
        container.querySelectorAll(
          ".history-folder.open"
        )
      ).map(
        folder =>
          folder.dataset.date
      )
    );


  if (openDateKey) {

    openDates.add(
      openDateKey
    );

  }


  if (
    !Array.isArray(trades) ||
    trades.length === 0
  ) {

    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  const groups = {};


  trades.forEach(
    trade => {

      if (!trade) {
        return;
      }


      let dateKey =
        trade.date;


      if (
        !dateKey &&
        trade.createdAt
      ) {

        const createdDate =
          new Date(
            trade.createdAt
          );


        if (
          !isNaN(
            createdDate.getTime()
          )
        ) {

          dateKey =
            getDateKey(
              createdDate
            );

        }

      }


      if (!dateKey) {
        return;
      }


      if (!groups[dateKey]) {

        groups[dateKey] = [];

      }


      groups[dateKey].push(
        trade
      );

    }
  );


  const dates =
    Object.keys(groups).sort(
      (a, b) =>
        b.localeCompare(a)
    );


  if (dates.length === 0) {

    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }


  container.innerHTML =
    dates
      .map(
        date => {

          const list =
            [...groups[date]].sort(
              (a, b) => {

                const timeA =
                  a.createdAt
                    ? new Date(
                        a.createdAt
                      ).getTime()
                    : 0;


                const timeB =
                  b.createdAt
                    ? new Date(
                        b.createdAt
                      ).getTime()
                    : 0;


                return timeB - timeA;

              }
            );


          let dateObject;


          if (
            list[0] &&
            list[0].createdAt
          ) {

            dateObject =
              new Date(
                list[0].createdAt
              );

          }


          if (
            !dateObject ||
            isNaN(
              dateObject.getTime()
            )
          ) {

            dateObject =
              new Date(
                `${date}T00:00:00`
              );

          }


          const persianDate =
            getPersianDate(
              dateObject
            );


          const isOpen =
            openDates.has(
              date
            );


          return `

            <div
              class="history-folder ${isOpen ? "open" : ""}"
              data-date="${date}"
            >

              <div class="folder-header">

                <button
                  type="button"
                  class="folder-toggle"
                  onclick="toggleFolder(this)"
                >

                  <div class="folder-title">

                    <span class="folder-icon">
                      📁
                    </span>

                    <span>
                      ${persianDate}
                    </span>

                  </div>

                </button>


                <div class="folder-header-actions">

                  <span class="folder-count">
                    ${list.length} معامله
                  </span>


                  <button
                    type="button"
                    class="pdf-action"
                    onclick="event.stopPropagation(); generateDatePDF('${date}')"
                    title="گزارش PDF این تاریخ"
                  >
                    PDF
                  </button>

                </div>

              </div>


              <div class="folder-content">

                ${list
                  .map(
                    trade =>
                      createHistoryTradeHTML(
                        trade
                      )
                  )
                  .join("")}

              </div>

            </div>

          `;

        }
      )
      .join("");

}


function createHistoryTradeHTML(
  trade
) {

  return `

    <div class="history-trade">

      <div class="history-trade-top">

        <span class="trade-type ${trade.type}">
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>


        <div class="history-actions">

          <button
            type="button"
            class="small-action"
            onclick="editTrade(${trade.id})"
            title="ویرایش"
          >
            ✎
          </button>


          <button
            type="button"
            class="small-action"
            onclick="deleteTrade(${trade.id})"
            title="حذف"
          >
            🗑
          </button>

        </div>

      </div>


      <div class="history-trade-info">

        <div>
          <span>وزن</span>
          <strong>
            ${formatNumber(trade.weight)}
            گرم
          </strong>
        </div>


        <div>
          <span>فی گرم ۱۸</span>
          <strong>
            ${formatMoney(trade.price18)}
          </strong>
        </div>


        <div>
          <span>مظنه</span>
          <strong>
            ${formatMoney(trade.mazhane)}
          </strong>
        </div>


        <div>
          <span>قیمت کل</span>
          <strong>
            ${formatMoney(trade.totalPrice)}
          </strong>
        </div>

      </div>


      <div class="history-time">

        ساعت معامله:
        ${trade.time || "-"}

      </div>

    </div>

  `;

}


function toggleFolder(button) {

  const folder =
    button.closest(
      ".history-folder"
    );


  if (folder) {

    folder.classList.toggle(
      "open"
    );

  }

}


/* =========================================================
   ================= PDF PRINT =============================
   ========================================================= */

/*
 * این نسخه دیگر pdf.save یا دانلود فایل را امتحان نمی‌کند.
 *
 * گزارش را به یک صفحه مخصوص چاپ تبدیل می‌کند.
 *
 * در اندروید:
 *
 * PDF
 * ↓
 * صفحه چاپ
 * ↓
 * Print / چاپ
 * ↓
 * Save as PDF / ذخیره به صورت PDF
 *
 */


/* ================= PRINT PDF ================= */

function generateDatePDF(
  dateKey
) {

  if (pdfGenerating) {
    return;
  }

  pdfGenerating = true;


  const dateTrades =
    trades
      .filter(
        trade =>
          trade &&
          (
            trade.date ===
            dateKey
            ||
            (
              !trade.date &&
              trade.createdAt &&
              getDateKey(
                new Date(
                  trade.createdAt
                )
              ) === dateKey
            )
          )
      )
      .sort(
        (a, b) => {

          const timeA =
            a.createdAt
              ? new Date(
                  a.createdAt
                ).getTime()
              : 0;


          const timeB =
            b.createdAt
              ? new Date(
                  b.createdAt
                ).getTime()
              : 0;


          return timeA - timeB;

        }
      );


  if (
    dateTrades.length === 0
  ) {

    pdfGenerating = false;

    alert(
      "برای این تاریخ معامله‌ای پیدا نشد."
    );

    return;

  }


  const pdfButtons =
    document.querySelectorAll(
      `.history-folder[data-date="${dateKey}"] .pdf-action`
    );


  pdfButtons.forEach(
    button => {

      button.disabled =
        true;

      button.dataset.oldText =
        button.textContent;

      button.textContent =
        "آماده‌سازی...";

    }
  );


  try {

    const firstDate =
      dateTrades[0].createdAt
        ? new Date(
            dateTrades[0].createdAt
          )
        : new Date(
            `${dateKey}T00:00:00`
          );


    const persianDate =
      getPersianDate(
        firstDate
      );


    let totalBoughtWeight =
      0;


    let totalSoldWeight =
      0;


    dateTrades.forEach(
      trade => {

        const weight =
          Number(
            trade.weight
          ) || 0;


        if (
          trade.type ===
          "buy"
        ) {

          totalBoughtWeight +=
            weight;

        }

        else {

          totalSoldWeight +=
            weight;

        }

      }
    );


    /*
     * =====================================================
     * ساخت جدول گزارش
     * =====================================================
     */

    const ROWS_PER_PAGE =
      24;


    const pages = [];


    for (
      let i = 0;
      i < dateTrades.length;
      i += ROWS_PER_PAGE
    ) {

      pages.push(
        dateTrades.slice(
          i,
          i + ROWS_PER_PAGE
        )
      );

    }


    /*
     * =====================================================
     * ساخت HTML چاپ
     * =====================================================
     */

    let pagesHTML = "";


    pages.forEach(
      (
        pageTrades,
        pageIndex
      ) => {

        let rowsHTML = "";


        pageTrades.forEach(
          (
            trade,
            index
          ) => {

            const globalIndex =
              pageIndex *
                ROWS_PER_PAGE +
              index +
              1;


            rowsHTML += `

              <tr>

                <td>
                  ${globalIndex}
                </td>

                <td>
                  ${trade.time || "-"}
                </td>

                <td
                  class="${
                    trade.type === "buy"
                      ? "buy"
                      : "sell"
                  }"
                >
                  ${
                    trade.type === "buy"
                      ? "خرید"
                      : "فروش"
                  }
                </td>

                <td>
                  ${formatNumber(
                    trade.weight
                  )} گرم
                </td>

                <td>
                  ${formatMoney(
                    trade.price18
                  )}
                </td>

                <td>
                  ${formatMoney(
                    trade.mazhane
                  )}
                </td>

                <td>
                  ${formatMoney(
                    trade.totalPrice
                  )}
                </td>

              </tr>

            `;

          }
        );


        pagesHTML += `

          <section class="print-page">

            <div class="report-header">

              <div class="report-title">
                ماشین حساب معاملاتی شایان
              </div>

              <div class="report-subtitle">
                گزارش کامل معاملات روزانه
              </div>

              <div class="report-date">
                ${persianDate}
              </div>

            </div>


            <div class="summary">

              <div class="summary-card">

                <span>
                  تعداد معاملات
                </span>

                <strong>
                  ${dateTrades.length}
                </strong>

              </div>


              <div class="summary-card buy-card">

                <span>
                  مجموع خرید
                </span>

                <strong>
                  ${formatNumber(
                    totalBoughtWeight
                  )} گرم
                </strong>

              </div>


              <div class="summary-card sell-card">

                <span>
                  مجموع فروش
                </span>

                <strong>
                  ${formatNumber(
                    totalSoldWeight
                  )} گرم
                </strong>

              </div>

            </div>


            <table>

              <thead>

                <tr>

                  <th>
                    ردیف
                  </th>

                  <th>
                    ساعت
                  </th>

                  <th>
                    نوع معامله
                  </th>

                  <th>
                    وزن
                  </th>

                  <th>
                    فی گرم ۱۸
                  </th>

                  <th>
                    مظنه
                  </th>

                  <th>
                    قیمت کل
                  </th>

                </tr>

              </thead>


              <tbody>

                ${rowsHTML}

              </tbody>

            </table>


            <div class="print-footer">

              <span>
                ماشین حساب معاملاتی شایان
              </span>

              <span>
                صفحه
                ${pageIndex + 1}
                از
                ${pages.length}
              </span>

            </div>

          </section>

        `;

      }
    );


    /*
     * =====================================================
     * ساخت صفحه چاپ
     * =====================================================
     */

    const printWindow =
      window.open(
        "",
        "_blank"
      );


    if (
      !printWindow
    ) {

      /*
       * اگر WebView اجازه window.open نداد،
       * از همان صفحه استفاده می‌کنیم.
       */

      createPrintPageInSameWindow(
        pagesHTML,
        persianDate
      );

      return;

    }


    printWindow.document.open();


    printWindow.document.write(`

      <!DOCTYPE html>

      <html
        lang="fa"
        dir="rtl"
      >

      <head>

        <meta charset="UTF-8">

        <meta
          name="viewport"
          content="width=device-width, initial-scale=1.0"
        >

        <title>
          گزارش معاملات - ${persianDate}
        </title>


        <style>

          * {
            box-sizing: border-box;
          }


          html,
          body {
            margin: 0;
            padding: 0;
            background: #ffffff;
            font-family:
              Tahoma,
              Arial,
              sans-serif;
            direction: rtl;
            color: #172536;
          }


          body {
            padding: 0;
          }


          .print-page {
            width: 210mm;
            min-height: 297mm;
            padding: 12mm;
            margin: 0 auto;
            background: #ffffff;
            position: relative;
            page-break-after: always;
          }


          .print-page:last-child {
            page-break-after: auto;
          }


          .report-header {
            background: #10243b;
            color: white;
            border-radius: 6mm;
            padding: 9mm;
            margin-bottom: 7mm;
            border-bottom: 2mm solid #d6ad43;
          }


          .report-title {
            font-size: 25px;
            font-weight: 900;
            margin-bottom: 3mm;
          }


          .report-subtitle {
            font-size: 15px;
            color: #c9d5e0;
            margin-bottom: 4mm;
          }


          .report-date {
            font-size: 18px;
            font-weight: 800;
            color: #f4c95d;
          }


          .summary {
            display: grid;
            grid-template-columns:
              repeat(3, 1fr);
            gap: 4mm;
            margin-bottom: 7mm;
          }


          .summary-card {
            border: 1px solid #dce3ea;
            border-radius: 4mm;
            padding: 5mm;
            background: #f8fafc;
            text-align: center;
          }


          .summary-card span {
            display: block;
            font-size: 12px;
            color: #718096;
            margin-bottom: 3mm;
          }


          .summary-card strong {
            display: block;
            font-size: 18px;
            color: #172536;
          }


          .summary-card.buy-card strong {
            color: #15915b;
          }


          .summary-card.sell-card strong {
            color: #d8465b;
          }


          table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 11px;
          }


          th {
            background: #10243b;
            color: #ffffff;
            padding: 4mm 2mm;
            border: 1px solid #29445f;
            font-weight: 800;
          }


          td {
            padding: 3.5mm 1.5mm;
            border: 1px solid #dce3ea;
            text-align: center;
            vertical-align: middle;
            word-wrap: break-word;
          }


          tbody tr:nth-child(even) {
            background: #f7f9fb;
          }


          td.buy {
            color: #15915b;
            font-weight: 800;
          }


          td.sell {
            color: #d8465b;
            font-weight: 800;
          }


          .print-footer {
            position: absolute;
            bottom: 9mm;
            left: 12mm;
            right: 12mm;
            border-top: 1px solid #dce3ea;
            padding-top: 4mm;
            display: flex;
            justify-content: space-between;
            font-size: 10px;
            color: #718096;
          }


          @page {
            size: A4 portrait;
            margin: 0;
          }


          @media print {

            html,
            body {
              width: 210mm;
              background: white;
            }


            .print-page {
              margin: 0;
              width: 210mm;
              height: 297mm;
              min-height: 297mm;
              page-break-after: always;
            }


            .print-page:last-child {
              page-break-after: auto;
            }

          }

        </style>

      </head>


      <body>

        ${pagesHTML}

        <script>

          window.onload = function() {

            setTimeout(
              function() {

                try {

                  window.print();

                } catch (error) {

                  console.error(
                    "PRINT ERROR:",
                    error
                  );

                }

              },
              700
            );

          };

        <\/script>

      </body>

      </html>

    `);


    printWindow.document.close();


  }

  catch (error) {

    console.error(
      "PRINT PDF ERROR:",
      error
    );


    /*
     * اگر window.open یا چاپ مستقیم
     * در WebView مشکل داشته باشد،
     * همان صفحه را وارد حالت چاپ می‌کنیم.
     */

    try {

      createPrintPageInSameWindow(
        "",
        ""
      );

    } catch (secondError) {

      alert(
        "امکان باز کردن صفحه چاپ وجود ندارد."
      );

    }

  }

  finally {

    pdfButtons.forEach(
      button => {

        button.disabled =
          false;

        button.textContent =
          button.dataset.oldText ||
          "PDF";

      }
    );


    pdfGenerating = false;

  }

}


/* =========================================================
   FALLBACK PRINT PAGE
   ========================================================= */

function createPrintPageInSameWindow(
  pagesHTML,
  persianDate
) {

  /*
   * این حالت زمانی استفاده می‌شود که
   * APK اجازه window.open ندهد.
   */

  const oldHTML =
    document.body.innerHTML;


  if (!pagesHTML) {

    /*
     * اگر HTML صفحه چاپ از قبل ساخته نشده،
     * دوباره اطلاعات روز را می‌سازیم.
     */

    const dateKey =
      getDateKey();


    const dateTrades =
      trades.filter(
        trade =>
          trade &&
          trade.date === dateKey
      );


    if (
      dateTrades.length === 0
    ) {

      alert(
        "برای این تاریخ معامله‌ای پیدا نشد."
      );

      return;

    }


    const firstDate =
      dateTrades[0].createdAt
        ? new Date(
            dateTrades[0].createdAt
          )
        : new Date();


    persianDate =
      getPersianDate(
        firstDate
      );


    let rowsHTML = "";


    dateTrades.forEach(
      (
        trade,
        index
      ) => {

        rowsHTML += `

          <tr>

            <td>
              ${index + 1}
            </td>

            <td>
              ${trade.time || "-"}
            </td>

            <td>
              ${
                trade.type === "buy"
                  ? "خرید"
                  : "فروش"
              }
            </td>

            <td>
              ${formatNumber(
                trade.weight
              )} گرم
            </td>

            <td>
              ${formatMoney(
                trade.price18
              )}
            </td>

            <td>
              ${formatMoney(
                trade.mazhane
              )}
            </td>

            <td>
              ${formatMoney(
                trade.totalPrice
              )}
            </td>

          </tr>

        `;

      }
    );


    pagesHTML = `

      <section
        class="print-page"
      >

        <h1>
          ماشین حساب معاملاتی شایان
        </h1>

        <h2>
          گزارش معاملات
        </h2>

        <h3>
          ${persianDate}
        </h3>


        <table>

          <thead>

            <tr>
              <th>ردیف</th>
              <th>ساعت</th>
              <th>نوع معامله</th>
              <th>وزن</th>
              <th>فی گرم ۱۸</th>
              <th>مظنه</th>
              <th>قیمت کل</th>
            </tr>

          </thead>

          <tbody>

            ${rowsHTML}

          </tbody>

        </table>

      </section>

    `;

  }


  document.body.innerHTML = `

    <style>

      * {
        box-sizing: border-box;
      }


      body {
        margin: 0;
        padding: 0;
        direction: rtl;
        font-family:
          Tahoma,
          Arial,
          sans-serif;
        background: white;
        color: #172536;
      }


      .print-page {
        width: 210mm;
        min-height: 297mm;
        padding: 12mm;
        margin: 0 auto;
        page-break-after: always;
      }


      .print-page:last-child {
        page-break-after: auto;
      }


      .report-header {
        background: #10243b;
        color: white;
        padding: 25px;
        border-radius: 20px;
        border-bottom: 8px solid #d6ad43;
        margin-bottom: 20px;
      }


      .report-title {
        font-size: 28px;
        font-weight: 900;
      }


      .report-subtitle {
        margin-top: 10px;
        font-size: 16px;
      }


      .report-date {
        margin-top: 15px;
        color: #f4c95d;
        font-size: 19px;
        font-weight: 800;
      }


      h1 {
        background: #10243b;
        color: white;
        padding: 20px;
        border-radius: 15px;
      }


      h2,
      h3 {
        text-align: center;
      }


      table {
        width: 100%;
        border-collapse: collapse;
        font-size: 11px;
      }


      th {
        background: #10243b;
        color: white;
        padding: 10px;
        border: 1px solid #29445f;
      }


      td {
        padding: 9px;
        border: 1px solid #dce3ea;
        text-align: center;
      }


      tr:nth-child(even) {
        background: #f7f9fb;
      }


      .print-controls {
        position: fixed;
        top: 15px;
        left: 15px;
        right: 15px;
        display: flex;
        gap: 10px;
        justify-content: center;
        z-index: 9999;
      }


      .print-controls button {
        border: 0;
        border-radius: 10px;
        padding: 12px 25px;
        font-size: 16px;
        font-family: Tahoma;
      }


      .print-button {
        background: #10243b;
        color: white;
      }


      .back-button {
        background: #dce3ea;
        color: #172536;
      }


      @page {
        size: A4 portrait;
        margin: 0;
      }


      @media print {

        .print-controls {
          display: none !important;
        }

        .print-page {
          margin: 0;
          width: 210mm;
          min-height: 297mm;
        }

      }

    </style>


    <div class="print-controls">

      <button
        class="print-button"
        onclick="window.print()"
      >
        🖨 چاپ / ذخیره PDF
      </button>


      <button
        class="back-button"
        onclick="location.reload()"
      >
        بازگشت
      </button>

    </div>


    ${pagesHTML}

  `;


  /*
   * کمی صبر می‌کنیم تا صفحه کاملاً رندر شود،
   * سپس چاپ را باز می‌کنیم.
   */

  setTimeout(
    function() {

      try {

        window.print();

      } catch (error) {

        console.error(
          "PRINT FALLBACK ERROR:",
          error
        );

      }

    },
    500
  );

}


/* ================= DEMO ================= */

function calculateDemo() {

  const current =
    calculateLedger();


  const currentPosition =
    current.position;


  const currentWeight =
    Math.abs(
      currentPosition
    );


  const currentAverage =
    current.averageCost;


  const currentStatus =
    document.getElementById(
      "demoCurrentStatus"
    );


  const currentWeightElement =
    document.getElementById(
      "demoCurrentWeight"
    );


  const currentAverageElement =
    document.getElementById(
      "demoCurrentAverage"
    );


  if (
    !currentStatus ||
    !currentWeightElement ||
    !currentAverageElement
  ) {
    return;
  }


  if (currentPosition > 0) {

    currentStatus.textContent =
      "موجودی خرید";

  }

  else if (currentPosition < 0) {

    currentStatus.textContent =
      "فروش باز";

  }

  else {

    currentStatus.textContent =
      "بدون موجودی";

  }


  currentWeightElement.textContent =
    `${formatNumber(
      currentWeight
    )} گرم`;


  currentAverageElement.textContent =
    `${formatMoney(
      currentAverage
    )} تومان`;


  const demoWeightElement =
    document.getElementById(
      "demoWeight"
    );


  const demoPriceElement =
    document.getElementById(
      "demoPrice18"
    );


  const demoTypeElement =
    document.getElementById(
      "demoType"
    );


  const resultAverage =
    document.getElementById(
      "demoResultAverage"
    );


  const resultMazhane =
    document.getElementById(
      "demoResultMazhane"
    );


  const resultMessage =
    document.getElementById(
      "demoResultMessage"
    );


  if (
    !demoWeightElement ||
    !demoPriceElement ||
    !demoTypeElement ||
    !resultAverage ||
    !resultMazhane ||
    !resultMessage
  ) {
    return;
  }


  const demoWeight =
    normalizeNumber(
      demoWeightElement.value
    );


  const demoPrice =
    normalizeNumber(
      demoPriceElement.value
    );


  const demoType =
    demoTypeElement.value;


  if (
    demoWeight <= 0 ||
    demoPrice <= 0
  ) {

    resultAverage.textContent =
      "0 تومان";

    resultMazhane.textContent =
      "مظنه میانگین: 0 تومان";

    resultMessage.textContent =
      "وزن و فی معامله فرضی را وارد کنید.";

    resultMessage.className =
      "demo-result-message";

    return;

  }


  let simulatedPosition =
    currentPosition;


  let simulatedAverage =
    currentAverage;


  let simulatedRealized =
    0;


  /* ================= BUY DEMO ================= */

  if (demoType === "buy") {

    if (simulatedPosition < 0) {

      const shortQty =
        Math.abs(
          simulatedPosition
        );


      const closeQty =
        Math.min(
          demoWeight,
          shortQty
        );


      simulatedRealized =
        closeQty *
        (
          simulatedAverage -
          demoPrice
        );


      simulatedPosition +=
        closeQty;


      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;


        simulatedPosition =
          remaining;


        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition > 0
    ) {

      const oldQty =
        simulatedPosition;


      const newQty =
        oldQty +
        demoWeight;


      simulatedAverage =
        (
          oldQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newQty;


      simulatedPosition =
        newQty;

    }

    else {

      simulatedPosition =
        demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  /* ================= SELL DEMO ================= */

  else {

    if (simulatedPosition > 0) {

      const closeQty =
        Math.min(
          simulatedPosition,
          demoWeight
        );


      simulatedRealized =
        closeQty *
        (
          demoPrice -
          simulatedAverage
        );


      simulatedPosition -=
        closeQty;


      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;


        simulatedPosition =
          -remaining;


        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition < 0
    ) {

      const oldShortQty =
        Math.abs(
          simulatedPosition
        );


      const newShortQty =
        oldShortQty +
        demoWeight;


      simulatedAverage =
        (
          oldShortQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newShortQty;


      simulatedPosition =
        -newShortQty;

    }

    else {

      simulatedPosition =
        -demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  const simulatedMazhane =
    simulatedAverage *
    FACTOR;


  resultAverage.textContent =
    `${formatMoney(
      simulatedAverage
    )} تومان`;


  resultMazhane.textContent =
    `مظنه میانگین: ${formatMoney(
      simulatedMazhane
    )} تومان`;


  let statusText = "";


  if (
    simulatedPosition > 0
  ) {

    statusText =
      `بعد از این خرید، موجودی شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else if (
    simulatedPosition < 0
  ) {

    statusText =
      `بعد از این فروش، فروش باز شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else {

    statusText =
      "با این معامله موجودی باز شما صفر می‌شود.";

  }


  if (
    simulatedRealized !== 0
  ) {

    statusText +=
      ` سود/زیان این سناریو: ${formatMoney(
        simulatedRealized
      )} تومان.`;

  }


  resultMessage.textContent =
    statusText;


  resultMessage.className =
    "demo-result-message success";

}


/* ================= DEMO INPUTS ================= */

const demoWeightInput =
  document.getElementById(
    "demoWeight"
  );


const demoPriceInput =
  document.getElementById(
    "demoPrice18"
  );


const demoTypeInput =
  document.getElementById(
    "demoType"
  );


if (demoWeightInput) {

  demoWeightInput.addEventListener(
    "input",
    function () {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );

      calculateDemo();

    }
  );

}


if (demoPriceInput) {

  demoPriceInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      calculateDemo();

    }
  );

}


if (demoTypeInput) {

  demoTypeInput.addEventListener(
    "change",
    calculateDemo
  );

}


/* ================= TRADE INPUTS ================= */

const weightInput =
  document.getElementById(
    "weight"
  );


const price18Input =
  document.getElementById(
    "price18"
  );


const mazhaneInput =
  document.getElementById(
    "mazhane"
  );


const totalPriceInput =
  document.getElementById(
    "totalPrice"
  );


function updateFromPrice18() {

  const price =
    normalizeNumber(
      price18Input.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (price > 0) {

    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }


  if (
    price > 0 &&
    weight > 0
  ) {

    totalPriceInput.value =
      formatInputNumber(
        price * weight
      );

  }

}


function updateFromMazhane() {

  const mazhane =
    normalizeNumber(
      mazhaneInput.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (mazhane > 0) {

    const price =
      mazhane / FACTOR;


    price18Input.value =
      formatInputNumber(
        price
      );


    if (weight > 0) {

      totalPriceInput.value =
        formatInputNumber(
          price * weight
        );

    }

  }

}


function updateFromTotal() {

  const total =
    normalizeNumber(
      totalPriceInput.value
    );


  const weight =
    normalizeNumber(
      weightInput.value
    );


  if (
    total > 0 &&
    weight > 0
  ) {

    const price =
      total / weight;


    price18Input.value =
      formatInputNumber(
        price
      );


    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }

}


if (
  weightInput &&
  price18Input &&
  mazhaneInput &&
  totalPriceInput
) {

  weightInput.addEventListener(
    "input",
    function () {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );


      const weight =
        normalizeNumber(
          this.value
        );


      const price =
        normalizeNumber(
          price18Input.value
        );


      if (
        weight > 0 &&
        price > 0
      ) {

        totalPriceInput.value =
          formatInputNumber(
            weight * price
          );

      }

    }
  );


  price18Input.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromPrice18();

    }
  );


  mazhaneInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromMazhane();

    }
  );


  totalPriceInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromTotal();

    }
  );

}


/* ================= SAVE TRADE ================= */

const saveTradeButton =
  document.getElementById(
    "saveTrade"
  );


if (saveTradeButton) {

  saveTradeButton.addEventListener(
    "click",
    function () {

      const type =
        document.getElementById(
          "tradeType"
        ).value;


      const weight =
        normalizeNumber(
          weightInput.value
        );


      const price18 =
        normalizeNumber(
          price18Input.value
        );


      const mazhane =
        normalizeNumber(
          mazhaneInput.value
        );


      const totalPrice =
        normalizeNumber(
          totalPriceInput.value
        );


      if (weight <= 0) {

        alert(
          "وزن معامله را وارد کنید."
        );

        return;

      }


      if (price18 <= 0) {

        alert(
          "فی گرم ۱۸ را وارد کنید."
        );

        return;

      }


      if (totalPrice <= 0) {

        alert(
          "قیمت کل معامله را وارد کنید."
        );

        return;

      }


      const finalMazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;


      const now =
        new Date();


      const trade = {

        id:
          Date.now() +
          Math.floor(
            Math.random() * 1000
          ),

        type,

        weight,

        price18,

        mazhane:
          finalMazhane,

        totalPrice,

        date:
          getDateKey(now),

        time:
          getTime(now),

        createdAt:
          now.toISOString()

      };


      trades.push(
        trade
      );


      saveTrades();


      weightInput.value = "";

      price18Input.value = "";

      mazhaneInput.value = "";

      totalPriceInput.value = "";


      renderAll();

      renderTodayTrades();

      renderHistory();

      showPage("trades");

    }
  );

}


/* ================= EDIT ================= */

function editTrade(id) {

  const trade =
    trades.find(
      item =>
        Number(item.id) ===
        Number(id)
    );


  if (!trade) {
    return;
  }


  editingTradeId =
    id;


  const editType =
    document.getElementById(
      "editType"
    );


  const editWeight =
    document.getElementById(
      "editWeight"
    );


  const editPrice18 =
    document.getElementById(
      "editPrice18"
    );


  const editMazhane =
    document.getElementById(
      "editMazhane"
    );


  const editTotalPrice =
    document.getElementById(
      "editTotalPrice"
    );


  if (
    !editType ||
    !editWeight ||
    !editPrice18 ||
    !editMazhane ||
    !editTotalPrice
  ) {
    return;
  }


  editType.value =
    trade.type;


  editWeight.value =
    formatInputNumber(
      trade.weight
    );


  editPrice18.value =
    formatInputNumber(
      trade.price18
    );


  editMazhane.value =
    formatInputNumber(
      trade.mazhane
    );


  editTotalPrice.value =
    formatInputNumber(
      trade.totalPrice
    );


  document.getElementById(
    "editModal"
  ).classList.add(
    "show"
  );

}


const closeModalButton =
  document.getElementById(
    "closeModal"
  );


if (closeModalButton) {

  closeModalButton.addEventListener(
    "click",
    function () {

      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );

    }
  );

}


const updateTradeButton =
  document.getElementById(
    "updateTrade"
  );


if (updateTradeButton) {

  updateTradeButton.addEventListener(
    "click",
    function () {

      const trade =
        trades.find(
          item =>
            Number(item.id) ===
            Number(editingTradeId)
        );


      if (!trade) {
        return;
      }


      const weight =
        normalizeNumber(
          document.getElementById(
            "editWeight"
          ).value
        );


      const price18 =
        normalizeNumber(
          document.getElementById(
            "editPrice18"
          ).value
        );


      const mazhane =
        normalizeNumber(
          document.getElementById(
            "editMazhane"
          ).value
        );


      const totalPrice =
        normalizeNumber(
          document.getElementById(
            "editTotalPrice"
          ).value
        );


      if (
        weight <= 0 ||
        price18 <= 0 ||
        totalPrice <= 0
      ) {

        alert(
          "اطلاعات معامله کامل نیست."
        );

        return;

      }


      trade.type =
        document.getElementById(
          "editType"
        ).value;


      trade.weight =
        weight;


      trade.price18 =
        price18;


      trade.mazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;


      trade.totalPrice =
        totalPrice;


      saveTrades();


      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );


      renderAll();

      renderTodayTrades();

      renderHistory();

    }
  );

}


/* ================= DELETE ================= */

function deleteTrade(id) {

  const tradeToDelete =
    trades.find(
      trade =>
        Number(trade.id) ===
        Number(id)
    );


  if (!tradeToDelete) {
    return;
  }


  const ok =
    confirm(
      "آیا از حذف این معامله مطمئن هستید؟"
    );


  if (!ok) {
    return;
  }


  let deletedTradeDate =
    tradeToDelete.date;


  if (
    !deletedTradeDate &&
    tradeToDelete.createdAt
  ) {

    const createdDate =
      new Date(
        tradeToDelete.createdAt
      );


    if (
      !isNaN(
        createdDate.getTime()
      )
    ) {

      deletedTradeDate =
        getDateKey(
          createdDate
        );

    }

  }


  trades =
    trades.filter(
      trade =>
        Number(trade.id) !==
        Number(id)
    );


  saveTrades();


  renderHome();

  renderTodayTrades();

  calculateDemo();


  const sameDateStillExists =
    deletedTradeDate &&
    trades.some(
      trade => {

        let tradeDate =
          trade.date;


        if (
          !tradeDate &&
          trade.createdAt
        ) {

          const d =
            new Date(
              trade.createdAt
            );


          if (
            !isNaN(
              d.getTime()
            )
          ) {

            tradeDate =
              getDateKey(d);

          }

        }


        return (
          tradeDate ===
          deletedTradeDate
        );

      }
    );


  if (
    sameDateStillExists
  ) {

    renderHistory(
      deletedTradeDate
    );

  }

  else {

    renderHistory();

  }

}


/* ================= SETTINGS ================= */

const factorInput =
  document.getElementById(
    "factorInput"
  );


if (factorInput) {

  factorInput.value =
    FACTOR;

}


const saveFactorButton =
  document.getElementById(
    "saveFactor"
  );


if (saveFactorButton) {

  saveFactorButton.addEventListener(
    "click",
    function () {

      const value =
        Number(
          factorInput.value
        );


      if (
        !value ||
        value <= 0
      ) {

        alert(
          "ضریب واردشده معتبر نیست."
        );

        return;

      }


      FACTOR =
        value;


      localStorage.setItem(
        "shayan_gold_factor",
        String(FACTOR)
      );


      renderAll();

      calculateDemo();


      alert(
        "ضریب با موفقیت ذخیره شد."
      );

    }
  );

}


/* ================= NAVIGATION ================= */

function showPage(pageId) {

  document
    .querySelectorAll(".page")
    .forEach(
      page =>
        page.classList.remove(
          "active"
        )
    );


  document
    .querySelectorAll(".nav-btn")
    .forEach(
      button =>
        button.classList.remove(
          "active"
        )
    );


  const page =
    document.getElementById(
      pageId
    );


  const navButton =
    document.querySelector(
      `.nav-btn[data-page="${pageId}"]`
    );


  if (page) {

    page.classList.add(
      "active"
    );

  }


  if (navButton) {

    navButton.classList.add(
      "active"
    );

  }


  if (pageId === "trades") {

    renderTodayTrades();

  }


  if (pageId === "history") {

    renderHistory();

  }


  if (pageId === "demo") {

    calculateDemo();

  }

}


document
  .querySelectorAll(".nav-btn")
  .forEach(
    button => {

      button.addEventListener(
        "click",
        function () {

          showPage(
            this.dataset.page
          );

        }
      );

    }
  );


/* ================= RENDER ALL ================= */

function renderAll() {

  renderHome();

  renderTodayTrades();

  renderHistory();

  calculateDemo();

}


renderAll();

showPage("home");