(function () {
  "use strict";

  var KEYS = [
    { label: "sin", value: "sin(", kind: "fn" },
    { label: "cos", value: "cos(", kind: "fn" },
    { label: "tan", value: "tan(", kind: "fn" },
    { label: "√", value: "√(", kind: "fn" },
    { label: "ln", value: "ln(", kind: "fn" },
    { label: "log", value: "log(", kind: "fn" },
    { label: "x²", value: "^2", kind: "fn" },
    { label: "xʸ", value: "^", kind: "fn" },
    { label: "π", value: "π", kind: "fn" },
    { label: "e", value: "e", kind: "fn" },
    { label: "n!", value: "!", kind: "fn" },
    { label: "|x|", value: "abs(", kind: "fn" },
    { label: "(", value: "(", kind: "fn" },
    { label: ")", value: ")", kind: "fn" },
    { label: "%", value: "%", kind: "op" },
    { label: "÷", value: "÷", kind: "op" },
    { label: "7", value: "7", kind: "num" },
    { label: "8", value: "8", kind: "num" },
    { label: "9", value: "9", kind: "num" },
    { label: "×", value: "×", kind: "op" },
    { label: "4", value: "4", kind: "num" },
    { label: "5", value: "5", kind: "num" },
    { label: "6", value: "6", kind: "num" },
    { label: "−", value: "−", kind: "op" },
    { label: "1", value: "1", kind: "num" },
    { label: "2", value: "2", kind: "num" },
    { label: "3", value: "3", kind: "num" },
    { label: "+", value: "+", kind: "op" },
    { label: "0", value: "0", kind: "num" },
    { label: ".", value: ".", kind: "num" },
    { label: "⌫", value: "DEL", kind: "action" },
    { label: "=", value: "=", kind: "equals" }
  ];

  var expression = "";
  var mode = "deg";

  var exprEl = document.getElementById("expr");
  var resultEl = document.getElementById("result");
  var keysEl = document.getElementById("keys");
  var clearBtn = document.getElementById("clearBtn");

  function factorial(n) {
    if (n < 0 || n !== Math.floor(n)) return NaN;
    if (n > 170) return Infinity;
    var r = 1;
    for (var i = 2; i <= n; i++) r *= i;
    return r;
  }

  function formatNumber(value) {
    if (!isFinite(value)) return value > 0 ? "∞" : "-∞";
    if (isNaN(value)) return "خطأ";
    var rounded = Math.round(value * 1e12) / 1e12;
    if (Math.abs(rounded) >= 1e15 || (rounded !== 0 && Math.abs(rounded) < 1e-9)) {
      return rounded.toExponential(8).replace(/\.?0+e/, "e");
    }
    return String(rounded);
  }

  function toRad(v) {
    return mode === "deg" ? (v * Math.PI) / 180 : v;
  }

  function evaluate(input) {
    var src = input
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/−/g, "-")
      .replace(/π/g, "pi")
      .replace(/√/g, "sqrt")
      .replace(/\s+/g, "");

    if (!src) return NaN;

    var pos = 0;

    function peek() {
      return src[pos];
    }
    function eat(ch) {
      if (src[pos] === ch) {
        pos++;
        return true;
      }
      return false;
    }

    function parseExpression() {
      var value = parseTerm();
      for (;;) {
        if (eat("+")) value += parseTerm();
        else if (eat("-")) value -= parseTerm();
        else break;
      }
      return value;
    }

    function parseTerm() {
      var value = parseUnary();
      for (;;) {
        if (eat("*")) value *= parseUnary();
        else if (eat("/")) value /= parseUnary();
        else if (eat("%")) value %= parseUnary();
        else break;
      }
      return value;
    }

    function parseUnary() {
      if (eat("-")) return -parseUnary();
      if (eat("+")) return parseUnary();
      return parsePower();
    }

    function parsePower() {
      var base = parsePostfix();
      if (eat("^")) {
        var exp = parseUnary();
        return Math.pow(base, exp);
      }
      return base;
    }

    function parsePostfix() {
      var value = parsePrimary();
      while (eat("!")) value = factorial(value);
      return value;
    }

    function parsePrimary() {
      if (eat("(")) {
        var inner = parseExpression();
        eat(")");
        return inner;
      }

      var ch = peek();
      if (ch && /[a-zA-Z]/.test(ch)) {
        var name = "";
        while (pos < src.length && /[a-zA-Z]/.test(src[pos])) {
          name += src[pos++];
        }
        if (name === "pi") return Math.PI;
        if (name === "e") return Math.E;

        var arg = parsePrimary();
        switch (name) {
          case "sin": return Math.sin(toRad(arg));
          case "cos": return Math.cos(toRad(arg));
          case "tan": return Math.tan(toRad(arg));
          case "asin": return mode === "deg" ? (Math.asin(arg) * 180) / Math.PI : Math.asin(arg);
          case "acos": return mode === "deg" ? (Math.acos(arg) * 180) / Math.PI : Math.acos(arg);
          case "atan": return mode === "deg" ? (Math.atan(arg) * 180) / Math.PI : Math.atan(arg);
          case "log": return Math.log10(arg);
          case "ln": return Math.log(arg);
          case "sqrt": return Math.sqrt(arg);
          case "cbrt": return Math.cbrt(arg);
          case "abs": return Math.abs(arg);
          case "exp": return Math.exp(arg);
          default: return NaN;
        }
      }

      var num = "";
      while (pos < src.length && /[0-9.]/.test(src[pos])) {
        num += src[pos++];
      }
      if (!num) return NaN;
      return parseFloat(num);
    }

    return parseExpression();
  }

  function render() {
    exprEl.innerHTML = expression ? escapeHtml(expression) : "&nbsp;";
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function setResult(text, isError) {
    resultEl.textContent = text;
    resultEl.classList.toggle("is-error", !!isError);
  }

  function flash() {
    resultEl.classList.add("is-flash");
    setTimeout(function () {
      resultEl.classList.remove("is-flash");
    }, 220);
  }

  function compute() {
    if (!expression.trim()) return;
    var value = evaluate(expression);
    if (isNaN(value)) {
      setResult("خطأ في الصيغة", true);
      return;
    }
    setResult(formatNumber(value), false);
    flash();
  }

  function clearAll() {
    expression = "";
    render();
    setResult("0", false);
  }

  function handleKey(key) {
    if (key.value === "DEL") {
      expression = expression.slice(0, -1);
      render();
      return;
    }
    if (key.value === "=") {
      compute();
      return;
    }
    expression += key.value;
    render();
  }

  function buildKeys() {
    KEYS.forEach(function (key) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "key key--" + (key.kind || "num");
      btn.textContent = key.label;
      btn.addEventListener("click", function () {
        handleKey(key);
      });
      keysEl.appendChild(btn);
    });
  }

  document.querySelectorAll(".mode-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      mode = btn.getAttribute("data-mode");
      document.querySelectorAll(".mode-btn").forEach(function (b) {
        b.classList.toggle("is-active", b === btn);
      });
    });
  });

  clearBtn.addEventListener("click", clearAll);

  window.addEventListener("keydown", function (e) {
    var k = e.key;
    if (/^[0-9.]$/.test(k)) {
      expression += k;
      render();
    } else if (k === "+" || k === "-" || k === "*" || k === "/") {
      var map = { "*": "×", "/": "÷", "-": "−", "+": "+" };
      expression += map[k];
      render();
    } else if (k === "(" || k === ")") {
      expression += k;
      render();
    } else if (k === "^") {
      expression += "^";
      render();
    } else if (k === "Enter" || k === "=") {
      e.preventDefault();
      compute();
    } else if (k === "Backspace") {
      expression = expression.slice(0, -1);
      render();
    } else if (k === "Escape") {
      clearAll();
    }
  });

  buildKeys();
  render();
})();