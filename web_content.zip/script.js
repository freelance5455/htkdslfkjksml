/* =========================================
   BHARATI DRESSES
   MAIN JAVASCRIPT
========================================= */


/* ---------- DEFAULT PRODUCTS ---------- */

const defaultProducts = [

  {
    id: 1,
    name: "Women's Fashion Dress",
    price: 499,
    category: "Women",
    image:
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80",
    description:
      "Stylish women's fashion dress suitable for casual and special occasions.",
    affiliate:
      "https://bharatidresses.blogspot.com/"
  },

  {
    id: 2,
    name: "Men's Casual Shirt",
    price: 699,
    category: "Men",
    image:
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80",
    description:
      "Comfortable casual shirt for everyday fashion.",
    affiliate:
      "https://bharatidresses.blogspot.com/"
  },

  {
    id: 3,
    name: "Kids Fashion Dress",
    price: 399,
    category: "Kids",
    image:
      "https://images.unsplash.com/photo-1514090458221-65bb69cf63e6?auto=format&fit=crop&w=800&q=80",
    description:
      "Cute and comfortable fashion wear for kids.",
    affiliate:
      "https://bharatidresses.blogspot.com/"
  },

  {
    id: 4,
    name: "Home Decor Light",
    price: 899,
    category: "Home",
    image:
      "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=800&q=80",
    description:
      "Modern decorative lighting for your home.",
    affiliate:
      "https://bharatidresses.blogspot.com/"
  }

];


/* ---------- STORAGE ---------- */

function getProducts() {

  const saved =
    localStorage.getItem("bharatiProducts");

  if (!saved) {

    localStorage.setItem(
      "bharatiProducts",
      JSON.stringify(defaultProducts)
    );

    return defaultProducts;
  }

  try {

    return JSON.parse(saved);

  } catch (error) {

    return defaultProducts;

  }

}


function saveProducts(products) {

  localStorage.setItem(
    "bharatiProducts",
    JSON.stringify(products)
  );

}


/* ---------- CURRENT FILTER ---------- */

let currentCategory = "All";


/* ---------- DISPLAY PRODUCTS ---------- */

function displayProducts(products = getProducts()) {

  const container =
    document.getElementById("productContainer");

  if (!container) return;

  container.innerHTML = "";

  if (products.length === 0) {

    container.innerHTML =
      "<p>No products found.</p>";

    return;
  }


  products.forEach(product => {

    const card =
      document.createElement("div");

    card.className = "product-card";


    card.innerHTML = `

      <img
        src="${escapeHTML(product.image)}"
        alt="${escapeHTML(product.name)}"
        loading="lazy"
        onerror="this.src='https://via.placeholder.com/600x600?text=Bharati+Dresses'"
      >

      <div class="product-info">

        <div class="category-label">
          ${escapeHTML(product.category)}
        </div>

        <h3>
          ${escapeHTML(product.name)}
        </h3>

        <div class="price">
          ₹${Number(product.price).toLocaleString("en-IN")}
        </div>

        <p class="description">
          ${escapeHTML(product.description)}
        </p>

        <a
          class="main-btn"
          href="${escapeHTML(product.affiliate)}"
          target="_blank"
          rel="noopener noreferrer"
        >
          Buy Now
        </a>

      </div>

    `;

    container.appendChild(card);

  });

}


/* ---------- FILTER ---------- */

function filterProducts(category) {

  currentCategory = category;

  const products = getProducts();

  if (category === "All") {

    displayProducts(products);

  } else {

    const filtered =
      products.filter(
        product =>
          product.category === category
      );

    displayProducts(filtered);

  }

}


/* ---------- SEARCH ---------- */

function searchProducts() {

  const query =
    document
      .getElementById("searchInput")
      .value
      .toLowerCase()
      .trim();


  let products = getProducts();


  if (currentCategory !== "All") {

    products =
      products.filter(
        product =>
          product.category === currentCategory
      );

  }


  if (query) {

    products =
      products.filter(product =>

        product.name
          .toLowerCase()
          .includes(query)

        ||

        product.description
          .toLowerCase()
          .includes(query)

      );

  }


  displayProducts(products);

}


/* =========================================
   ADMIN LOGIN
========================================= */

function adminLogin() {

  const password =
    prompt("Enter Admin Password:");

  /*
    CHANGE THIS PASSWORD
    BEFORE PUBLISHING.
  */

  const ADMIN_PASSWORD =
    "";


  if (password === ADMIN_PASSWORD) {

    document
      .getElementById("adminPanel")
      .classList.remove("hidden");

    document
      .getElementById("adminLoginButton")
      .classList.add("hidden");

    displayAdminProducts();

    alert("Admin login successful.");

  } else {

    alert("Incorrect password.");

  }

}


/* =========================================
   SAVE PRODUCT
========================================= */

function saveProduct() {

  const name =
    document
      .getElementById("productName")
      .value
      .trim();

  const price =
    Number(
      document
        .getElementById("productPrice")
        .value
    );

  const image =
    document
      .getElementById("productImage")
      .value
      .trim();

  const category =
    document
      .getElementById("productCategory")
      .value;

  const description =
    document
      .getElementById("productDescription")
      .value
      .trim();

  const affiliate =
    document
      .getElementById("affiliateLink")
      .value
      .trim();

  const editId =
    document
      .getElementById("editProductId")
      .value;


  if (!name) {

    alert("Please enter product name.");
    return;

  }

  if (!price || price < 0) {

    alert("Please enter a valid price.");
    return;

  }

  if (!image) {

    alert("Please enter product image URL.");
    return;

  }

  if (!affiliate) {

    alert("Please enter Buy/Affiliate URL.");
    return;

  }


  let products = getProducts();


  if (editId) {

    const index =
      products.findIndex(
        product =>
          String(product.id) === String(editId)
      );


    if (index !== -1) {

      products[index] = {

        ...products[index],

        name,
        price,
        image,
        category,
        description,
        affiliate

      };

    }

  } else {

    products.push({

      id: Date.now(),

      name,
      price,
      image,
      category,
      description,
      affiliate

    });

  }


  saveProducts(products);

  clearProductForm();

  displayProducts();

  displayAdminProducts();

  alert("Product saved successfully.");

}


/* =========================================
   ADMIN PRODUCT LIST
========================================= */

function displayAdminProducts() {

  const container =
    document.getElementById("adminProducts");

  if (!container) return;


  const products = getProducts();

  container.innerHTML = "";


  products.forEach(product => {

    const item =
      document.createElement("div");

    item.className = "admin-product";


    item.innerHTML = `

      <div>

        <strong>
          ${escapeHTML(product.name)}
        </strong>

        <br>

        ₹${Number(product.price).toLocaleString("en-IN")}

      </div>

      <div class="admin-actions">

        <button
          class="edit-btn"
          onclick="editProduct(${product.id})"
        >
          Edit
        </button>

        <button
          class="delete-btn"
          onclick="deleteProduct(${product.id})"
        >
          Delete
        </button>

      </div>

    `;


    container.appendChild(item);

  });

}


/* =========================================
   EDIT PRODUCT
========================================= */

function editProduct(id) {

  const products = getProducts();

  const product =
    products.find(
      item =>
        Number(item.id) === Number(id)
    );


  if (!product) return;


  document.getElementById("editProductId").value =
    product.id;

  document.getElementById("productName").value =
    product.name;

  document.getElementById("productPrice").value =
    product.price;

  document.getElementById("productImage").value =
    product.image;

  document.getElementById("productCategory").value =
    product.category;

  document.getElementById("productDescription").value =
    product.description;

  document.getElementById("affiliateLink").value =
    product.affiliate;


  document
    .getElementById("admin")
    .scrollIntoView({
      behavior: "smooth"
    });

}


/* =========================================
   DELETE PRODUCT
========================================= */

function deleteProduct(id) {

  const confirmDelete =
    confirm(
      "Are you sure you want to delete this product?"
    );


  if (!confirmDelete) return;


  let products = getProducts();


  products =
    products.filter(
      product =>
        Number(product.id) !== Number(id)
    );


  saveProducts(products);

  displayProducts();

  displayAdminProducts();

}


/* =========================================
   CLEAR FORM
========================================= */

function clearProductForm() {

  document.getElementById("editProductId").value = "";

  document.getElementById("productName").value = "";

  document.getElementById("productPrice").value = "";

  document.getElementById("productImage").value = "";

  document.getElementById("productDescription").value = "";

  document.getElementById("affiliateLink").value = "";

}


/* =========================================
   REVIEWS
========================================= */

function getReviews() {

  const saved =
    localStorage.getItem("bharatiReviews");


  if (!saved) {

    const defaultReviews = [

      {
        name: "Customer",
        rating: 5,
        text: "Nice product and good shopping experience."
      }

    ];


    localStorage.setItem(
      "bharatiReviews",
      JSON.stringify(defaultReviews)
    );


    return defaultReviews;

  }


  try {

    return JSON.parse(saved);

  } catch (error) {

    return [];

  }

}


/* ---------- DISPLAY REVIEWS ---------- */

function displayReviews() {

  const container =
    document.getElementById("reviewContainer");

  if (!container) return;


  const reviews = getReviews();

  container.innerHTML = "";


  reviews.forEach(review => {

    const card =
      document.createElement("div");

    card.className = "review-card";


    const stars =
      "★".repeat(
        Math.max(
          0,
          Math.min(
            5,
            Number(review.rating)
          )
        )
      );


    card.innerHTML = `

      <div class="review-name">
        ${escapeHTML(review.name)}
      </div>

      <div class="review-stars">
        ${stars}
      </div>

      <div class="review-text">
        ${escapeHTML(review.text)}
      </div>

    `;


    container.appendChild(card);

  });

}


/* ---------- ADD REVIEW ---------- */

function addReview() {

  const name =
    document
      .getElementById("reviewName")
      .value
      .trim();

  const rating =
    Number(
      document
        .getElementById("reviewRating")
        .value
    );

  const text =
    document
      .getElementById("reviewText")
      .value
      .trim();


  if (!name) {

    alert("Please enter your name.");
    return;

  }

  if (!text) {

    alert("Please write a review.");
    return;

  }


  const reviews = getReviews();


  reviews.unshift({

    name,
    rating,
    text

  });


  localStorage.setItem(
    "bharatiReviews",
    JSON.stringify(reviews)
  );


  document.getElementById("reviewName").value = "";

  document.getElementById("reviewText").value = "";


  displayReviews();


  alert("Thank you for your review!");

}


/* =========================================
   MOBILE MENU
========================================= */

function toggleMenu() {

  document
    .getElementById("navMenu")
    .classList.toggle("show");

}


/* =========================================
   SECURITY HELPER
========================================= */

function escapeHTML(value) {

  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");

}


/* =========================================
   INITIALIZE
========================================= */

document.addEventListener(
  "DOMContentLoaded",
  function () {

    displayProducts();

    displayReviews();

    document.getElementById("year").textContent =
      new Date().getFullYear();

  }
);