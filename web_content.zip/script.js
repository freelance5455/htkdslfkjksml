// ================= CONFIGURAÇÃO (guardada no aparelho) =================
let config = {
  usuario: localStorage.getItem('gh_usuario') || '',
  repositorio: localStorage.getItem('gh_repo') || '',
  token: localStorage.getItem('gh_token') || ''
};
let imagens = [];

const $ = (id) => document.getElementById(id);
const caixaConfig = $('caixaConfig');
const inputUsuario = $('inputUsuario');
const inputRepo = $('inputRepo');
const inputToken = $('inputToken');
const inputImagem = $('inputImagem');
const inputLink = $('inputLink');
const listaImagens = $('listaImagens');
const status = $('status');

// ================= UTILIDADES =================
function mostrarStatus(texto, tipo) {
  status.textContent = texto;
  status.className = 'status ' + tipo;
  status.style.display = 'block';
}
function esconderStatus(ms) { setTimeout(() => { status.style.display = 'none'; }, ms); }

function textoParaBase64(txt) { return btoa(unescape(encodeURIComponent(txt))); }
function base64ParaTexto(b64) { return decodeURIComponent(escape(atob(b64.replace(/\s/g, '')))); }

function apiUrl(caminho) {
  return `https://api.github.com/repos/${config.usuario}/${config.repositorio}/contents/${caminho}`;
}
function cabecalho(json) {
  const h = { Authorization: `token ${config.token}`, Accept: 'application/vnd.github+json' };
  if (json) h['Content-Type'] = 'application/json';
  return h;
}
function urlPublica(nome) {
  return `https://${config.usuario}.github.io/${config.repositorio}/imagens/${nome}`;
}
function checar(resposta) {
  if (resposta.status === 401 || resposta.status === 403) throw new Error('Token inválido ou sem permissão');
  if (!resposta.ok) throw new Error('Erro ' + resposta.status + ' no GitHub');
}

// ================= LER / SALVAR lista.json =================
async function pegarArquivo() {
  const r = await fetch(apiUrl('lista.json') + '?t=' + Date.now(), { headers: cabecalho(false) });
  if (r.status === 404) return { conteudo: [], sha: null };
  checar(r);
  const dados = await r.json();
  let conteudo;
  if (dados.content) {
    conteudo = JSON.parse(base64ParaTexto(dados.content));
  } else {
    // arquivo grande (lista antiga com fotos dentro): lê pelo formato "raw"
    const raw = await fetch(apiUrl('lista.json') + '?t=' + Date.now(), {
      headers: { Authorization: `token ${config.token}`, Accept: 'application/vnd.github.raw+json' }
    });
    checar(raw);
    conteudo = await raw.json();
  }
  return { conteudo, sha: dados.sha };
}

async function salvarLista(novaLista, sha) {
  const corpo = {
    message: '📱 Atualizando lista de novidades',
    content: textoParaBase64(JSON.stringify(novaLista, null, 2))
  };
  if (sha) corpo.sha = sha;
  const r = await fetch(apiUrl('lista.json'), { method: 'PUT', headers: cabecalho(true), body: JSON.stringify(corpo) });
  checar(r);
}

// ================= ENVIAR / APAGAR ARQUIVO DE IMAGEM =================
async function enviarArquivo(nome, base64) {
  const r = await fetch(apiUrl('imagens/' + nome), {
    method: 'PUT', headers: cabecalho(true),
    body: JSON.stringify({ message: '🖼️ Nova imagem', content: base64 })
  });
  checar(r);
}

async function apagarArquivo(nome) {
  try {
    const g = await fetch(apiUrl('imagens/' + nome), { headers: cabecalho(false) });
    if (!g.ok) return;
    const { sha } = await g.json();
    await fetch(apiUrl('imagens/' + nome), {
      method: 'DELETE', headers: cabecalho(true),
      body: JSON.stringify({ message: '🗑️ Removendo imagem', sha })
    });
  } catch (e) { console.error(e); }
}

// ================= REDUZIR FOTO (fica leve pra TV) =================
function reduzirImagem(arquivo, larguraMax = 1280, qualidade = 0.82) {
  return new Promise((ok, erro) => {
    const url = URL.createObjectURL(arquivo);
    const img = new Image();
    img.onload = () => {
      let w = img.width, h = img.height;
      if (w > larguraMax) { h = Math.round(h * larguraMax / w); w = larguraMax; }
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url);
      ok(c.toDataURL('image/jpeg', qualidade).split(',')[1]);
    };
    img.onerror = () => erro(new Error('Não consegui abrir essa imagem'));
    img.src = url;
  });
}

// ================= TELA =================
function atualizarTelaLista() {
  listaImagens.innerHTML = '';
  if (imagens.length === 0) {
    listaImagens.innerHTML = '<p class="vazio">Nenhuma imagem adicionada ainda</p>';
    return;
  }
  imagens.forEach((url, indice) => {
    const item = document.createElement('div');
    item.className = 'item-imagem';
    const img = document.createElement('img');
    img.src = url; img.alt = 'Novidade ' + (indice + 1); img.loading = 'lazy';
    const btn = document.createElement('button');
    btn.className = 'btn-apagar'; btn.textContent = '×';
    btn.addEventListener('click', () => removerImagem(indice));
    item.appendChild(img); item.appendChild(btn);
    listaImagens.appendChild(item);
  });
}

async function carregarLista() {
  listaImagens.innerHTML = '<p class="vazio">Carregando...</p>';
  try {
    const { conteudo } = await pegarArquivo();
    imagens = conteudo;
    atualizarTelaLista();
  } catch (erro) {
    listaImagens.innerHTML = '<p class="vazio">❌ Erro ao carregar. Verifique sua configuração.</p>';
    console.error(erro);
  }
}

// ================= ADICIONAR FOTO DA GALERIA =================
inputImagem.addEventListener('change', async (e) => {
  const arquivo = e.target.files[0];
  if (!arquivo) return;
  try {
    mostrarStatus('📤 Reduzindo a imagem...', 'info');
    const base64 = await reduzirImagem(arquivo);
    const nome = 'img_' + Date.now() + '.jpg';
    mostrarStatus('📤 Enviando imagem...', 'info');
    await enviarArquivo(nome, base64);
    const { conteudo, sha } = await pegarArquivo();
    conteudo.push(urlPublica(nome));
    await salvarLista(conteudo, sha);
    imagens = conteudo;
    atualizarTelaLista();
    mostrarStatus('✅ Imagem adicionada e publicada!', 'sucesso');
    esconderStatus(3000);
  } catch (erro) {
    mostrarStatus('❌ Erro ao salvar: ' + erro.message, 'erro');
  }
  inputImagem.value = '';
});

// ================= ADICIONAR POR LINK =================
$('btnAddLink').addEventListener('click', async () => {
  const link = inputLink.value.trim();
  if (!/^https?:\/\/\S+$/i.test(link)) {
    mostrarStatus('Cole um link começando com https://', 'erro');
    return;
  }
  try {
    mostrarStatus('📤 Publicando link...', 'info');
    const { conteudo, sha } = await pegarArquivo();
    conteudo.push(link);
    await salvarLista(conteudo, sha);
    imagens = conteudo;
    atualizarTelaLista();
    inputLink.value = '';
    mostrarStatus('✅ Link adicionado e publicado!', 'sucesso');
    esconderStatus(3000);
  } catch (erro) {
    mostrarStatus('❌ Erro ao salvar: ' + erro.message, 'erro');
  }
});

// ================= REMOVER =================
async function removerImagem(indice) {
  if (!confirm('Tem certeza que quer remover esta imagem?')) return;
  const url = imagens[indice];
  try {
    mostrarStatus('🗑️ Removendo...', 'info');
    const { conteudo, sha } = await pegarArquivo();
    let pos = conteudo.indexOf(url);
    if (pos < 0) pos = indice;
    conteudo.splice(pos, 1);
    await salvarLista(conteudo, sha);
    // se a foto foi enviada por este painel, apaga o arquivo também
    const prefixo = urlPublica('');
    if (typeof url === 'string' && url.startsWith(prefixo)) await apagarArquivo(url.slice(prefixo.length));
    imagens = conteudo;
    atualizarTelaLista();
    mostrarStatus('✅ Imagem removida!', 'sucesso');
    esconderStatus(3000);
  } catch (erro) {
    mostrarStatus('❌ Erro ao remover: ' + erro.message, 'erro');
  }
}

// ================= CONFIGURAÇÃO =================
$('btnSalvarConfig').addEventListener('click', () => {
  const usuario = inputUsuario.value.trim();
  const repo = inputRepo.value.trim();
  const token = inputToken.value.trim();
  if (!usuario || !repo || !token) { mostrarStatus('Preencha todos os campos!', 'erro'); return; }
  config = { usuario, repositorio: repo, token };
  localStorage.setItem('gh_usuario', usuario);
  localStorage.setItem('gh_repo', repo);
  localStorage.setItem('gh_token', token);
  caixaConfig.classList.add('escondida');
  mostrarStatus('✅ Configuração salva!', 'sucesso');
  setTimeout(() => { status.style.display = 'none'; carregarLista(); }, 1500);
});

$('btnSincronizar').addEventListener('click', carregarLista);

$('btnSair').addEventListener('click', (e) => {
  e.preventDefault();
  localStorage.removeItem('gh_token');
  localStorage.removeItem('gh_usuario');
  localStorage.removeItem('gh_repo');
  config = { usuario: '', repositorio: '', token: '' };
  caixaConfig.classList.remove('escondida');
  inputToken.value = '';
});

// ================= INICIAR =================
(function init() {
  if (config.usuario && config.repositorio && config.token) {
    caixaConfig.classList.add('escondida');
    carregarLista();
  } else {
    inputUsuario.value = 'maistv-maker';
    inputRepo.value = 'mais-tv-dados';
  }
})();
