const DEFAULT_FACTOR = 4.3318;

let FACTOR =
  Number(localStorage.getItem("shayan_gold_factor")) ||
  DEFAULT_FACTOR;

let pdfGenerating = false;

let trades = [];

try {
  const savedTrades =
    localStorage.getItem("shayan_gold_trades");

  trades =
    savedTrades
      ? JSON.parse(savedTrades)
      : [];

  if (!Array.isArray(trades)) {
    trades = [];
  }

} catch (error) {
  trades = [];
}

let editingTradeId = null;


/* ================= DATE ================= */

function getPersianDate(date = new Date()) {

  return new Intl.DateTimeFormat(
    "fa-IR-u-ca-persian",
    {
      year: "numeric",
      month: "long",
      day: "numeric"
    }
  ).format(date);

}


function getDateKey(date = new Date()) {

  const y =
    date.getFullYear();

  const m =
    String(
      date.getMonth() + 1
    ).padStart(2, "0");

  const d =
    String(
      date.getDate()
    ).padStart(2, "0");

  return `${y}-${m}-${d}`;

}


function getTime(date = new Date()) {

  return date.toLocaleTimeString(
    "fa-IR",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );

}


/* ================= NUMBERS ================= */

function normalizeNumber(value) {

  if (
    value === null ||
    value === undefined ||
    value === ""
  ) {
    return 0;
  }

  let text =
    String(value)
      .replace(/,/g, "")
      .replace(/\s/g, "");

  text =
    text.replace(
      /[۰-۹]/g,
      d =>
        "۰۱۲۳۴۵۶۷۸۹".indexOf(d)
    );

  text =
    text.replace(
      /[٠-٩]/g,
      d =>
        "٠١٢٣٤٥٦٧٨٩".indexOf(d)
    );

  return Number(text) || 0;

}


function formatNumber(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 3
      }
    );

}


function formatMoney(number) {

  return Number(number || 0)
    .toLocaleString(
      "en-US",
      {
        maximumFractionDigits: 0
      }
    );

}


function formatInputNumber(value) {

  const number =
    normalizeNumber(value);

  if (!number) {
    return "";
  }

  return number.toLocaleString(
    "en-US",
    {
      maximumFractionDigits: 3
    }
  );

}


/* ================= STORAGE ================= */

function saveTrades() {

  localStorage.setItem(
    "shayan_gold_trades",
    JSON.stringify(trades)
  );

}


/* ================= LEDGER ================= */

function calculateLedger() {

  let position = 0;
  let averageCost = 0;
  let realizedProfit = 0;

  const sortedTrades =
    [...trades].sort(
      (a, b) =>
        new Date(a.createdAt).getTime() -
        new Date(b.createdAt).getTime()
    );

  for (const trade of sortedTrades) {

    const qty =
      Number(trade.weight) || 0;

    const price =
      Number(trade.price18) || 0;

    if (
      qty <= 0 ||
      price <= 0
    ) {
      continue;
    }

    /* ===== BUY ===== */

    if (trade.type === "buy") {

      if (position < 0) {

        const shortQty =
          Math.abs(position);

        const closeQty =
          Math.min(
            qty,
            shortQty
          );

        realizedProfit +=
          closeQty *
          (averageCost - price);

        position += closeQty;

        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position = remaining;
          averageCost = price;

        } else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position > 0) {

        const oldQty =
          position;

        const newQty =
          oldQty + qty;

        averageCost =
          (
            oldQty * averageCost +
            qty * price
          ) / newQty;

        position =
          newQty;

      }

      else {

        position = qty;
        averageCost = price;

      }

    }

    /* ===== SELL ===== */

    else if (trade.type === "sell") {

      if (position > 0) {

        const closeQty =
          Math.min(
            position,
            qty
          );

        realizedProfit +=
          closeQty *
          (price - averageCost);

        position -= closeQty;

        if (qty > closeQty) {

          const remaining =
            qty - closeQty;

          position =
            -remaining;

          averageCost =
            price;

        }

        else if (position === 0) {

          averageCost = 0;

        }

      }

      else if (position < 0) {

        const oldShortQty =
          Math.abs(position);

        const newShortQty =
          oldShortQty + qty;

        averageCost =
          (
            oldShortQty * averageCost +
            qty * price
          ) / newShortQty;

        position =
          -newShortQty;

      }

      else {

        position =
          -qty;

        averageCost =
          price;

      }

    }

  }

  return {
    position,
    averageCost,
    realizedProfit
  };

}


/* ================= TRADE HTML ================= */

function createTradeHTML(trade) {

  return `

    <div class="trade-item">

      <div class="trade-main">

        <span>
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>

        <span class="trade-type ${trade.type}">

          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}

        </span>

      </div>

      <div class="trade-details">

        <span>
          وزن:
          ${formatNumber(trade.weight)}
          گرم
        </span>

        <span>
          فی:
          ${formatMoney(trade.price18)}
          تومان
        </span>

        <span>
          مظنه:
          ${formatMoney(trade.mazhane)}
          تومان
        </span>

        <span>
          کل:
          ${formatMoney(trade.totalPrice)}
          تومان
        </span>

        <span>
          ${trade.time || "-"}
        </span>

      </div>

    </div>

  `;

}


/* ================= HOME ================= */

function renderHome() {

  const today =
    getDateKey();

  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );

  let bought = 0;
  let sold = 0;

  todayTrades.forEach(
    trade => {

      if (trade.type === "buy") {

        bought +=
          Number(trade.weight) || 0;

      } else {

        sold +=
          Number(trade.weight) || 0;

      }

    }
  );

  const ledger =
    calculateLedger();

  const balance =
    Math.abs(ledger.position);

  const average =
    ledger.averageCost;

  const averageMazhane =
    average * FACTOR;

  const todayDate =
    document.getElementById(
      "todayDate"
    );

  if (todayDate) {

    todayDate.textContent =
      getPersianDate();

  }

  const homeTradeCount =
    document.getElementById(
      "homeTradeCount"
    );

  if (homeTradeCount) {

    homeTradeCount.textContent =
      formatNumber(todayTrades.length);

  }

  const homeBought =
    document.getElementById(
      "homeBought"
    );

  if (homeBought) {

    homeBought.textContent =
      `${formatNumber(bought)} گرم`;

  }

  const homeSold =
    document.getElementById(
      "homeSold"
    );

  if (homeSold) {

    homeSold.textContent =
      `${formatNumber(sold)} گرم`;

  }

  const homeBalance =
    document.getElementById(
      "homeBalance"
    );

  if (homeBalance) {

    homeBalance.textContent =
      `${formatNumber(balance)} گرم`;

  }

  const averageLabel =
    document.getElementById(
      "homeAverageLabel"
    );

  if (averageLabel) {

    if (ledger.position < 0) {

      averageLabel.textContent =
        "فی میانگین فروش باز";

    } else {

      averageLabel.textContent =
        "فی میانگین موجودی باقی‌مانده";

    }

  }

  const homeAveragePrice =
    document.getElementById(
      "homeAveragePrice"
    );

  if (homeAveragePrice) {

    homeAveragePrice.textContent =
      `${formatMoney(average)} تومان`;

  }

  const homeAverageMazhane =
    document.getElementById(
      "homeAverageMazhane"
    );

  if (homeAverageMazhane) {

    homeAverageMazhane.textContent =
      `مظنه میانگین: ${formatMoney(averageMazhane)} تومان`;

  }

  const profitElement =
    document.getElementById(
      "homeRealizedProfit"
    );

  if (profitElement) {

    profitElement.textContent =
      `${formatMoney(
        ledger.realizedProfit
      )} تومان`;

    profitElement.classList.remove(
      "closed-profit",
      "closed-loss"
    );

    if (ledger.realizedProfit > 0) {

      profitElement.classList.add(
        "closed-profit"
      );

    }

    else if (
      ledger.realizedProfit < 0
    ) {

      profitElement.classList.add(
        "closed-loss"
      );

    }

  }

  renderTradeList(
    todayTrades,
    "homeTrades"
  );

}


/* ================= TODAY TRADES ================= */

function renderTodayTrades() {

  const today =
    getDateKey();

  const todayTrades =
    trades.filter(
      trade =>
        trade.date === today
    );

  renderTradeList(
    todayTrades,
    "todayTrades"
  );

}


/* ================= GENERIC LIST ================= */

function renderTradeList(
  list,
  elementId
) {

  const container =
    document.getElementById(
      elementId
    );

  if (!container) {
    return;
  }

  if (
    !Array.isArray(list) ||
    list.length === 0
  ) {

    container.innerHTML =
      `<div class="empty">
        معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }

  const sorted =
    [...list].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() -
        new Date(a.createdAt).getTime()
    );

  container.innerHTML =
    sorted
      .map(
        trade =>
          createTradeHTML(trade)
      )
      .join("");

}


/* ================= HISTORY ================= */

function renderHistory(
  openDateKey = null
) {

  const container =
    document.getElementById(
      "historyList"
    );

  if (!container) {
    return;
  }

  const openDates =
    new Set(
      Array.from(
        container.querySelectorAll(
          ".history-folder.open"
        )
      ).map(
        folder =>
          folder.dataset.date
      )
    );

  if (openDateKey) {

    openDates.add(
      openDateKey
    );

  }

  if (
    !Array.isArray(trades) ||
    trades.length === 0
  ) {

    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }

  const groups = {};

  trades.forEach(
    trade => {

      if (!trade) {
        return;
      }

      let dateKey =
        trade.date;

      if (
        !dateKey &&
        trade.createdAt
      ) {

        const createdDate =
          new Date(
            trade.createdAt
          );

        if (
          !isNaN(
            createdDate.getTime()
          )
        ) {

          dateKey =
            getDateKey(
              createdDate
            );

        }

      }

      if (!dateKey) {
        return;
      }

      if (!groups[dateKey]) {

        groups[dateKey] = [];

      }

      groups[dateKey].push(
        trade
      );

    }
  );

  const dates =
    Object.keys(groups).sort(
      (a, b) =>
        b.localeCompare(a)
    );

  if (dates.length === 0) {

    container.innerHTML =
      `<div class="empty">
        هنوز معامله‌ای ثبت نشده است.
      </div>`;

    return;

  }

  container.innerHTML =
    dates
      .map(
        date => {

          const list =
            [...groups[date]].sort(
              (a, b) => {

                const timeA =
                  a.createdAt
                    ? new Date(
                        a.createdAt
                      ).getTime()
                    : 0;

                const timeB =
                  b.createdAt
                    ? new Date(
                        b.createdAt
                      ).getTime()
                    : 0;

                return timeB - timeA;

              }
            );

          let dateObject;

          if (
            list[0] &&
            list[0].createdAt
          ) {

            dateObject =
              new Date(
                list[0].createdAt
              );

          }

          if (
            !dateObject ||
            isNaN(
              dateObject.getTime()
            )
          ) {

            dateObject =
              new Date(
                `${date}T00:00:00`
              );

          }

          const persianDate =
            getPersianDate(
              dateObject
            );

          const isOpen =
            openDates.has(
              date
            );

          return `

            <div
              class="history-folder ${isOpen ? "open" : ""}"
              data-date="${date}"
            >

              <div class="folder-header">

                <button
                  type="button"
                  class="folder-toggle"
                  onclick="toggleFolder(this)"
                >

                  <div class="folder-title">

                    <span class="folder-icon">
                      📁
                    </span>

                    <span>
                      ${persianDate}
                    </span>

                  </div>

                </button>

                <div class="folder-header-actions">

                  <span class="folder-count">
                    ${list.length} معامله
                  </span>

                  <button
                    type="button"
                    class="pdf-action"
                    onclick="event.stopPropagation(); generateDatePDF('${date}')"
                    title="گزارش PDF این تاریخ"
                  >
                    PDF
                  </button>

                </div>

              </div>

              <div class="folder-content">

                ${list
                  .map(
                    trade =>
                      createHistoryTradeHTML(
                        trade
                      )
                  )
                  .join("")}

              </div>

            </div>

          `;

        }
      )
      .join("");

}


function createHistoryTradeHTML(
  trade
) {

  return `

    <div class="history-trade">

      <div class="history-trade-top">

        <span class="trade-type ${trade.type}">
          ${trade.type === "buy"
            ? "خرید"
            : "فروش"}
        </span>

        <div class="history-actions">

          <button
            type="button"
            class="small-action"
            onclick="editTrade(${trade.id})"
            title="ویرایش"
          >
            ✎
          </button>

          <button
            type="button"
            class="small-action"
            onclick="deleteTrade(${trade.id})"
            title="حذف"
          >
            🗑
          </button>

        </div>

      </div>

      <div class="history-trade-info">

        <div>
          <span>وزن</span>
          <strong>
            ${formatNumber(trade.weight)}
            گرم
          </strong>
        </div>

        <div>
          <span>فی گرم ۱۸</span>
          <strong>
            ${formatMoney(trade.price18)}
          </strong>
        </div>

        <div>
          <span>مظنه</span>
          <strong>
            ${formatMoney(trade.mazhane)}
          </strong>
        </div>

        <div>
          <span>قیمت کل</span>
          <strong>
            ${formatMoney(trade.totalPrice)}
          </strong>
        </div>

      </div>

      <div class="history-time">

        ساعت معامله:
        ${trade.time || "-"}

      </div>

    </div>

  `;

}


function toggleFolder(button) {

  const folder =
    button.closest(
      ".history-folder"
    );

  if (folder) {

    folder.classList.toggle(
      "open"
    );

  }

}


/* =========================================================
   ================= PDF GENERATOR =========================
   ========================================================= */

function loadJsPDF() {

  return new Promise(
    (resolve, reject) => {

      if (
        window.jspdf &&
        window.jspdf.jsPDF
      ) {

        resolve(
          window.jspdf.jsPDF
        );

        return;

      }

      const script =
        document.createElement(
          "script"
        );

      script.src =
        "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";

      script.onload =
        function () {

          if (
            window.jspdf &&
            window.jspdf.jsPDF
          ) {

            resolve(
              window.jspdf.jsPDF
            );

          }

          else {

            reject(
              new Error(
                "jsPDF loaded but unavailable"
              )
            );

          }

        };

      script.onerror =
        function () {

          reject(
            new Error(
              "Cannot load jsPDF"
            )
          );

        };

      document.head.appendChild(
        script
      );

    }
  );

}


/* =========================================================
   PDF DATA
   ========================================================= */

function getDateTradesForPDF(
  dateKey
) {

  return trades
    .filter(
      trade =>
        trade &&
        (
          trade.date === dateKey
          ||
          (
            !trade.date &&
            trade.createdAt &&
            getDateKey(
              new Date(
                trade.createdAt
              )
            ) === dateKey
          )
        )
    )
    .sort(
      (a, b) => {

        const timeA =
          a.createdAt
            ? new Date(
                a.createdAt
              ).getTime()
            : 0;

        const timeB =
          b.createdAt
            ? new Date(
                b.createdAt
              ).getTime()
            : 0;

        return timeA - timeB;

      }
    );

}


/* =========================================================
   CREATE PDF
   ========================================================= */

async function generateDatePDF(
  dateKey
) {

  if (pdfGenerating) {
    return;
  }

  pdfGenerating = true;

  const pdfButtons =
    document.querySelectorAll(
      `.history-folder[data-date="${dateKey}"] .pdf-action`
    );

  pdfButtons.forEach(
    button => {

      button.disabled =
        true;

      button.dataset.oldText =
        button.textContent;

      button.textContent =
        "PDF...";

    }
  );

  try {

    const dateTrades =
      getDateTradesForPDF(
        dateKey
      );

    if (
      dateTrades.length === 0
    ) {

      throw new Error(
        "NO_TRADES"
      );

    }

    const firstDate =
      dateTrades[0].createdAt
        ? new Date(
            dateTrades[0].createdAt
          )
        : new Date();

    const persianDate =
      getPersianDate(
        firstDate
      );

    let totalBoughtWeight =
      0;

    let totalSoldWeight =
      0;

    dateTrades.forEach(
      trade => {

        const weight =
          Number(
            trade.weight
          ) || 0;

        if (
          trade.type === "buy"
        ) {

          totalBoughtWeight +=
            weight;

        } else {

          totalSoldWeight +=
            weight;

        }

      }
    );


    /* ================= LOAD JSPDF ================= */

    const jsPDF =
      await loadJsPDF();


    /* ================= PDF ================= */

    const pdf =
      new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
        compress: true
      });


    const pageWidth = 210;
    const pageHeight = 297;

    const margin = 10;

    const usableWidth =
      pageWidth -
      margin * 2;


    /* ================= COLORS ================= */

    const navy = [
      16,
      36,
      59
    ];

    const gold = [
      214,
      173,
      67
    ];

    const green = [
      21,
      145,
      91
    ];

    const red = [
      216,
      70,
      91
    ];

    const gray = [
      113,
      128,
      150
    ];

    const lightGray = [
      247,
      249,
      251
    ];


    /* ================= FONT ================= */

    pdf.setFont(
      "helvetica",
      "normal"
    );


    /* ================= ROW SETTINGS ================= */

    const rowsPerPage = 24;

    const totalPages =
      Math.ceil(
        dateTrades.length /
        rowsPerPage
      );


    for (
      let pageIndex = 0;
      pageIndex < totalPages;
      pageIndex++
    ) {

      if (pageIndex > 0) {

        pdf.addPage();

      }


      const pageTrades =
        dateTrades.slice(
          pageIndex * rowsPerPage,
          (pageIndex + 1) *
            rowsPerPage
        );


      /* ================= HEADER ================= */

      pdf.setFillColor(
        navy[0],
        navy[1],
        navy[2]
      );

      pdf.roundedRect(
        margin,
        10,
        usableWidth,
        31,
        4,
        4,
        "F"
      );


      pdf.setFillColor(
        gold[0],
        gold[1],
        gold[2]
      );

      pdf.rect(
        margin,
        38,
        usableWidth,
        3,
        "F"
      );


      pdf.setTextColor(
        255,
        255,
        255
      );

      pdf.setFontSize(
        17
      );

      pdf.setFont(
        "helvetica",
        "bold"
      );

      pdf.text(
        "SHAYAN TRADING CALCULATOR",
        pageWidth / 2,
        21,
        {
          align: "center"
        }
      );


      pdf.setFontSize(
        9
      );

      pdf.setFont(
        "helvetica",
        "normal"
      );

      pdf.setTextColor(
        201,
        213,
        224
      );

      pdf.text(
        "Daily Gold Trading Report",
        pageWidth / 2,
        28,
        {
          align: "center"
        }
      );


      pdf.setFontSize(
        11
      );

      pdf.setFont(
        "helvetica",
        "bold"
      );

      pdf.setTextColor(
        gold[0],
        gold[1],
        gold[2]
      );

      pdf.text(
        persianDate,
        pageWidth / 2,
        35,
        {
          align: "center"
        }
      );


      /* ================= SUMMARY ================= */

      const summaryY = 48;

      const gap = 4;

      const cardWidth =
        (
          usableWidth -
          gap * 2
        ) / 3;


      const cards = [

        {
          x: margin,
          title: "TRADES",
          value:
            String(
              dateTrades.length
            ),
          color:
            navy
        },

        {
          x:
            margin +
            cardWidth +
            gap,
          title: "TOTAL BUY",
          value:
            formatNumber(
              totalBoughtWeight
            ) + " g",
          color:
            green
        },

        {
          x:
            margin +
            (cardWidth + gap) *
              2,
          title: "TOTAL SELL",
          value:
            formatNumber(
              totalSoldWeight
            ) + " g",
          color:
            red
        }

      ];


      cards.forEach(
        card => {

          pdf.setFillColor(
            248,
            250,
            252
          );

          pdf.setDrawColor(
            220,
            227,
            234
          );

          pdf.roundedRect(
            card.x,
            summaryY,
            cardWidth,
            20,
            2,
            2,
            "FD"
          );


          pdf.setTextColor(
            gray[0],
            gray[1],
            gray[2]
          );

          pdf.setFontSize(
            7
          );

          pdf.setFont(
            "helvetica",
            "normal"
          );

          pdf.text(
            card.title,
            card.x +
              cardWidth / 2,
            summaryY + 7,
            {
              align: "center"
            }
          );


          pdf.setTextColor(
            card.color[0],
            card.color[1],
            card.color[2]
          );

          pdf.setFontSize(
            10
          );

          pdf.setFont(
            "helvetica",
            "bold"
          );

          pdf.text(
            card.value,
            card.x +
              cardWidth / 2,
            summaryY + 14,
            {
              align: "center"
            }
          );

        }
      );


      /* ================= TABLE ================= */

      const tableX = margin;

      const tableY =
        summaryY + 27;

      const tableWidth =
        usableWidth;

      const headerHeight =
        11;

      const rowHeight =
        8.7;


      const columns = [

        {
          title: "#",
          width: 10
        },

        {
          title: "TIME",
          width: 23
        },

        {
          title: "TYPE",
          width: 24
        },

        {
          title: "WEIGHT",
          width: 29
        },

        {
          title: "PRICE 18",
          width: 34
        },

        {
          title: "MAZHANE",
          width: 34
        },

        {
          title: "TOTAL",
          width:
            tableWidth -
            (
              10 +
              23 +
              24 +
              29 +
              34 +
              34
            )
        }

      ];


      let currentX =
        tableX;


      /* TABLE HEADER */

      columns.forEach(
        column => {

          pdf.setFillColor(
            navy[0],
            navy[1],
            navy[2]
          );

          pdf.setDrawColor(
            41,
            68,
            95
          );

          pdf.rect(
            currentX,
            tableY,
            column.width,
            headerHeight,
            "FD"
          );


          pdf.setTextColor(
            255,
            255,
            255
          );

          pdf.setFontSize(
            6.5
          );

          pdf.setFont(
            "helvetica",
            "bold"
          );

          pdf.text(
            column.title,
            currentX +
              column.width / 2,
            tableY + 7,
            {
              align: "center"
            }
          );


          currentX +=
            column.width;

        }
      );


      /* TABLE ROWS */

      pageTrades.forEach(
        (
          trade,
          rowIndex
        ) => {

          const y =
            tableY +
            headerHeight +
            rowIndex *
              rowHeight;


          if (
            rowIndex % 2 === 1
          ) {

            pdf.setFillColor(
              lightGray[0],
              lightGray[1],
              lightGray[2]
            );

          } else {

            pdf.setFillColor(
              255,
              255,
              255
            );

          }


          let x =
            tableX;


          const values = [

            String(
              pageIndex *
                rowsPerPage +
                rowIndex +
                1
            ),

            trade.time || "-",

            trade.type === "buy"
              ? "BUY"
              : "SELL",

            formatNumber(
              trade.weight
            ) + " g",

            formatMoney(
              trade.price18
            ),

            formatMoney(
              trade.mazhane
            ),

            formatMoney(
              trade.totalPrice
            )

          ];


          values.forEach(
            (
              value,
              columnIndex
            ) => {

              const column =
                columns[
                  columnIndex
                ];


              pdf.setFillColor(
                rowIndex % 2 === 1
                  ? lightGray[0]
                  : 255,
                rowIndex % 2 === 1
                  ? lightGray[1]
                  : 255,
                rowIndex % 2 === 1
                  ? lightGray[2]
                  : 255
              );


              pdf.setDrawColor(
                220,
                227,
                234
              );


              pdf.rect(
                x,
                y,
                column.width,
                rowHeight,
                "FD"
              );


              if (
                columnIndex === 2
              ) {

                if (
                  trade.type === "buy"
                ) {

                  pdf.setTextColor(
                    green[0],
                    green[1],
                    green[2]
                  );

                } else {

                  pdf.setTextColor(
                    red[0],
                    red[1],
                    red[2]
                  );

                }

              } else {

                pdf.setTextColor(
                  23,
                  37,
                  54
                );

              }


              pdf.setFontSize(
                6.5
              );

              pdf.setFont(
                "helvetica",
                columnIndex === 2
                  ? "bold"
                  : "normal"
              );


              pdf.text(
                String(value),
                x +
                  column.width / 2,
                y + 5.8,
                {
                  align: "center",
                  maxWidth:
                    column.width - 2
                }
              );


              x +=
                column.width;

            }
          );

        }
      );


      /* ================= FOOTER ================= */

      const footerY =
        pageHeight - 12;


      pdf.setDrawColor(
        220,
        227,
        234
      );

      pdf.line(
        margin,
        footerY - 5,
        pageWidth - margin,
        footerY - 5
      );


      pdf.setTextColor(
        gray[0],
        gray[1],
        gray[2]
      );

      pdf.setFontSize(
        6.5
      );

      pdf.setFont(
        "helvetica",
        "normal"
      );


      pdf.text(
        "Shayan Trading Calculator",
        margin,
        footerY
      );


      pdf.text(
        `Page ${pageIndex + 1} / ${totalPages}`,
        pageWidth - margin,
        footerY,
        {
          align: "right"
        }
      );

    }


    /* =====================================================
       ساخت فایل
       ===================================================== */

    const pdfBlob =
      pdf.output(
        "blob"
      );


    const fileName =
      `Shayan-Trading-${dateKey}.pdf`;


    /*
     * اول Share API را امتحان می‌کنیم.
     * در اندروید این می‌تواند گزینه‌هایی مثل
     * Save to Drive / Files / WhatsApp / etc. بدهد.
     */

    const pdfFile =
      new File(
        [pdfBlob],
        fileName,
        {
          type:
            "application/pdf"
        }
      );


    if (
      navigator.share &&
      (
        !navigator.canShare ||
        navigator.canShare({
          files: [pdfFile]
        })
      )
    ) {

      try {

        await navigator.share({

          title:
            "گزارش معاملات",

          text:
            "گزارش معاملات ماشین حساب شایان",

          files:
            [pdfFile]

        });

        return;

      }

      catch (shareError) {

        /*
         * اگر کاربر Share را بست،
         * خطا را نادیده می‌گیریم و
         * گزارش را نمایش می‌دهیم.
         */

        console.log(
          "Share cancelled or failed:",
          shareError
        );

      }

    }


    /*
     * اگر Share API توسط APK پشتیبانی نشد،
     * گزارش PDF را در صفحه نمایش می‌دهیم.
     */

    showPDFPreview(
      pdfBlob,
      fileName
    );

  }

  catch (error) {

    console.error(
      "PDF ERROR:",
      error
    );


    if (
      error &&
      error.message ===
      "NO_TRADES"
    ) {

      alert(
        "برای این تاریخ معامله‌ای پیدا نشد."
      );

    }

    else {

      alert(
        "ساخت PDF انجام نشد.\n\n" +
        "اگر داخل APK هستید، ممکن است WebView این قابلیت را پشتیبانی نکند."
      );

    }

  }

  finally {

    pdfButtons.forEach(
      button => {

        button.disabled =
          false;

        button.textContent =
          button.dataset.oldText ||
          "PDF";

      }
    );

    pdfGenerating = false;

  }

}


/* =========================================================
   PDF PREVIEW
   ========================================================= */

function showPDFPreview(
  pdfBlob,
  fileName
) {

  const blobUrl =
    URL.createObjectURL(
      pdfBlob
    );


  const originalHTML =
    document.body.innerHTML;


  document.body.innerHTML = `

    <style>

      * {
        box-sizing: border-box;
      }


      html,
      body {

        margin: 0;

        padding: 0;

        width: 100%;

        height: 100%;

        overflow: hidden;

        background: #eef1f5;

        font-family:
          Tahoma,
          Arial,
          sans-serif;

        direction: rtl;

      }


      .pdf-toolbar {

        position: fixed;

        top: 0;

        left: 0;

        right: 0;

        height: 62px;

        background:
          #10243b;

        display: flex;

        align-items: center;

        justify-content: center;

        gap: 7px;

        padding: 7px;

        z-index: 99999;

      }


      .pdf-toolbar button {

        border: 0;

        border-radius: 9px;

        padding:
          10px 13px;

        font-family:
          Tahoma,
          Arial,
          sans-serif;

        font-size: 12px;

        font-weight: bold;

        cursor: pointer;

        white-space: nowrap;

      }


      .pdf-share {

        background:
          #d6ad43;

        color:
          #10243b;

      }


      .pdf-print {

        background:
          #ffffff;

        color:
          #10243b;

      }


      .pdf-back {

        background:
          #dce3ea;

        color:
          #172536;

      }


      .pdf-title {

        position: fixed;

        top: 62px;

        left: 0;

        right: 0;

        height: 36px;

        background:
          #ffffff;

        border-bottom:
          1px solid #dce3ea;

        display: flex;

        align-items: center;

        justify-content: center;

        font-size: 11px;

        color:
          #596779;

        z-index: 99998;

        overflow: hidden;

        white-space: nowrap;

        text-overflow: ellipsis;

        padding: 0 10px;

      }


      .pdf-frame {

        position: fixed;

        top: 98px;

        left: 0;

        right: 0;

        bottom: 0;

        width: 100%;

        height: calc(
          100% - 98px
        );

        border: 0;

        background:
          #eef1f5;

      }


      @media print {

        .pdf-toolbar,
        .pdf-title {

          display: none !important;

        }


        .pdf-frame {

          top: 0;

          height: 100%;

        }

      }

    </style>


    <div class="pdf-toolbar">

      <button
        type="button"
        class="pdf-share"
        id="pdfShareButton"
      >
        📤 ذخیره / اشتراک PDF
      </button>


      <button
        type="button"
        class="pdf-print"
        id="pdfPrintButton"
      >
        🖨 چاپ
      </button>


      <button
        type="button"
        class="pdf-back"
        id="pdfBackButton"
      >
        ← بازگشت
      </button>

    </div>


    <div class="pdf-title">

      ${fileName}

    </div>


    <iframe
      class="pdf-frame"
      id="pdfFrame"
      src="${blobUrl}"
      title="PDF"
    ></iframe>

  `;


  /* =====================================================
     SHARE BUTTON
     ===================================================== */

  const shareButton =
    document.getElementById(
      "pdfShareButton"
    );


  if (shareButton) {

    shareButton.addEventListener(
      "click",
      async function () {

        try {

          const pdfFile =
            new File(
              [pdfBlob],
              fileName,
              {
                type:
                  "application/pdf"
              }
            );


          if (
            navigator.share &&
            (
              !navigator.canShare ||
              navigator.canShare({
                files: [pdfFile]
              })
            )
          ) {

            await navigator.share({

              title:
                "گزارش معاملات",

              text:
                "گزارش معاملات ماشین حساب شایان",

              files:
                [pdfFile]

            });

          }

          else {

            alert(
              "این APK امکان اشتراک‌گذاری مستقیم فایل PDF را ندارد.\n\n" +
              "دکمه «چاپ» را امتحان کنید."
            );

          }

        }

        catch (error) {

          console.log(
            "PDF SHARE ERROR:",
            error
          );

        }

      }
    );

  }


  /* =====================================================
     PRINT BUTTON
     ===================================================== */

  const printButton =
    document.getElementById(
      "pdfPrintButton"
    );


  if (printButton) {

    printButton.addEventListener(
      "click",
      function () {

        try {

          const frame =
            document.getElementById(
              "pdfFrame"
            );


          if (
            frame &&
            frame.contentWindow
          ) {

            frame.contentWindow.focus();

            frame.contentWindow.print();

          }

          else {

            window.print();

          }

        }

        catch (error) {

          try {

            window.print();

          }

          catch (secondError) {

            alert(
              "امکان باز کردن چاپ وجود ندارد."
            );

          }

        }

      }
    );

  }


  /* =====================================================
     BACK BUTTON
     ===================================================== */

  const backButton =
    document.getElementById(
      "pdfBackButton"
    );


  if (backButton) {

    backButton.addEventListener(
      "click",
      function () {

        try {

          URL.revokeObjectURL(
            blobUrl
          );

        }

        catch (error) {}


        document.body.innerHTML =
          originalHTML;


        setTimeout(
          function () {

            renderAll();

            showPage(
              "history"
            );

          },
          50
        );

      }
    );

  }

}


/* ================= DEMO ================= */

function calculateDemo() {

  const current =
    calculateLedger();

  const currentPosition =
    current.position;

  const currentWeight =
    Math.abs(
      currentPosition
    );

  const currentAverage =
    current.averageCost;

  const currentStatus =
    document.getElementById(
      "demoCurrentStatus"
    );

  const currentWeightElement =
    document.getElementById(
      "demoCurrentWeight"
    );

  const currentAverageElement =
    document.getElementById(
      "demoCurrentAverage"
    );

  if (
    !currentStatus ||
    !currentWeightElement ||
    !currentAverageElement
  ) {
    return;
  }

  if (currentPosition > 0) {

    currentStatus.textContent =
      "موجودی خرید";

  }

  else if (currentPosition < 0) {

    currentStatus.textContent =
      "فروش باز";

  }

  else {

    currentStatus.textContent =
      "بدون موجودی";

  }

  currentWeightElement.textContent =
    `${formatNumber(
      currentWeight
    )} گرم`;

  currentAverageElement.textContent =
    `${formatMoney(
      currentAverage
    )} تومان`;

  const demoWeightElement =
    document.getElementById(
      "demoWeight"
    );

  const demoPriceElement =
    document.getElementById(
      "demoPrice18"
    );

  const demoTypeElement =
    document.getElementById(
      "demoType"
    );

  const resultAverage =
    document.getElementById(
      "demoResultAverage"
    );

  const resultMazhane =
    document.getElementById(
      "demoResultMazhane"
    );

  const resultMessage =
    document.getElementById(
      "demoResultMessage"
    );

  if (
    !demoWeightElement ||
    !demoPriceElement ||
    !demoTypeElement ||
    !resultAverage ||
    !resultMazhane ||
    !resultMessage
  ) {
    return;
  }

  const demoWeight =
    normalizeNumber(
      demoWeightElement.value
    );

  const demoPrice =
    normalizeNumber(
      demoPriceElement.value
    );

  const demoType =
    demoTypeElement.value;

  if (
    demoWeight <= 0 ||
    demoPrice <= 0
  ) {

    resultAverage.textContent =
      "0 تومان";

    resultMazhane.textContent =
      "مظنه میانگین: 0 تومان";

    resultMessage.textContent =
      "وزن و فی معامله فرضی را وارد کنید.";

    resultMessage.className =
      "demo-result-message";

    return;

  }

  let simulatedPosition =
    currentPosition;

  let simulatedAverage =
    currentAverage;

  let simulatedRealized =
    0;


  /* ================= BUY DEMO ================= */

  if (demoType === "buy") {

    if (simulatedPosition < 0) {

      const shortQty =
        Math.abs(
          simulatedPosition
        );

      const closeQty =
        Math.min(
          demoWeight,
          shortQty
        );

      simulatedRealized =
        closeQty *
        (
          simulatedAverage -
          demoPrice
        );

      simulatedPosition +=
        closeQty;

      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;

        simulatedPosition =
          remaining;

        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition > 0
    ) {

      const oldQty =
        simulatedPosition;

      const newQty =
        oldQty +
        demoWeight;

      simulatedAverage =
        (
          oldQty *
          simulatedAverage +
          demoWeight *
          demoPrice
        ) /
        newQty;

      simulatedPosition =
        newQty;

    }

    else {

      simulatedPosition =
        demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  /* ================= SELL DEMO ================= */

  else {

    if (simulatedPosition > 0) {

      const closeQty =
        Math.min(
          simulatedPosition,
          demoWeight
        );

      simulatedRealized =
        closeQty *
        (
          demoPrice -
          simulatedAverage
        );

      simulatedPosition -=
        closeQty;

      if (
        demoWeight >
        closeQty
      ) {

        const remaining =
          demoWeight -
          closeQty;

        simulatedPosition =
          -remaining;

        simulatedAverage =
          demoPrice;

      }

      else if (
        simulatedPosition === 0
      ) {

        simulatedAverage = 0;

      }

    }

    else if (
      simulatedPosition < 0
    ) {

      const oldShortQty =
        Math.abs(
          simulatedPosition
        );

      const newShortQty =
        oldShortQty +
        demoWeight;

      simulatedAverage =
        (
          oldShortQty *
            simulatedAverage +
          demoWeight *
            demoPrice
        ) /
        newShortQty;

      simulatedPosition =
        -newShortQty;

    }

    else {

      simulatedPosition =
        -demoWeight;

      simulatedAverage =
        demoPrice;

    }

  }


  const simulatedMazhane =
    simulatedAverage *
    FACTOR;

  resultAverage.textContent =
    `${formatMoney(
      simulatedAverage
    )} تومان`;

  resultMazhane.textContent =
    `مظنه میانگین: ${formatMoney(
      simulatedMazhane
    )} تومان`;

  let statusText = "";

  if (
    simulatedPosition > 0
  ) {

    statusText =
      `بعد از این خرید، موجودی شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else if (
    simulatedPosition < 0
  ) {

    statusText =
      `بعد از این فروش، فروش باز شما ${formatNumber(
        Math.abs(simulatedPosition)
      )} گرم با میانگین ${formatMoney(
        simulatedAverage
      )} تومان می‌شود.`;

  }

  else {

    statusText =
      "با این معامله موجودی باز شما صفر می‌شود.";

  }

  if (
    simulatedRealized !== 0
  ) {

    statusText +=
      ` سود/زیان این سناریو: ${formatMoney(
        simulatedRealized
      )} تومان.`;

  }

  resultMessage.textContent =
    statusText;

  resultMessage.className =
    "demo-result-message success";

}


/* ================= DEMO INPUTS ================= */

const demoWeightInput =
  document.getElementById(
    "demoWeight"
  );

const demoPriceInput =
  document.getElementById(
    "demoPrice18"
  );

const demoTypeInput =
  document.getElementById(
    "demoType"
  );

if (demoWeightInput) {

  demoWeightInput.addEventListener(
    "input",
    function () {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );

      calculateDemo();

    }
  );

}

if (demoPriceInput) {

  demoPriceInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      calculateDemo();

    }
  );

}

if (demoTypeInput) {

  demoTypeInput.addEventListener(
    "change",
    calculateDemo
  );

}


/* ================= TRADE INPUTS ================= */

const weightInput =
  document.getElementById(
    "weight"
  );

const price18Input =
  document.getElementById(
    "price18"
  );

const mazhaneInput =
  document.getElementById(
    "mazhane"
  );

const totalPriceInput =
  document.getElementById(
    "totalPrice"
  );


function updateFromPrice18() {

  const price =
    normalizeNumber(
      price18Input.value
    );

  const weight =
    normalizeNumber(
      weightInput.value
    );

  if (price > 0) {

    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }

  if (
    price > 0 &&
    weight > 0
  ) {

    totalPriceInput.value =
      formatInputNumber(
        price * weight
      );

  }

}


function updateFromMazhane() {

  const mazhane =
    normalizeNumber(
      mazhaneInput.value
    );

  const weight =
    normalizeNumber(
      weightInput.value
    );

  if (mazhane > 0) {

    const price =
      mazhane / FACTOR;

    price18Input.value =
      formatInputNumber(
        price
      );

    if (weight > 0) {

      totalPriceInput.value =
        formatInputNumber(
          price * weight
        );

    }

  }

}


function updateFromTotal() {

  const total =
    normalizeNumber(
      totalPriceInput.value
    );

  const weight =
    normalizeNumber(
      weightInput.value
    );

  if (
    total > 0 &&
    weight > 0
  ) {

    const price =
      total / weight;

    price18Input.value =
      formatInputNumber(
        price
      );

    mazhaneInput.value =
      formatInputNumber(
        price * FACTOR
      );

  }

}


if (
  weightInput &&
  price18Input &&
  mazhaneInput &&
  totalPriceInput
) {

  weightInput.addEventListener(
    "input",
    function () {

      this.value =
        this.value.replace(
          /[^0-9۰-۹٠-٩.,]/g,
          ""
        );

      const weight =
        normalizeNumber(
          this.value
        );

      const price =
        normalizeNumber(
          price18Input.value
        );

      if (
        weight > 0 &&
        price > 0
      ) {

        totalPriceInput.value =
          formatInputNumber(
            weight * price
          );

      }

    }
  );


  price18Input.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromPrice18();

    }
  );


  mazhaneInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromMazhane();

    }
  );


  totalPriceInput.addEventListener(
    "input",
    function () {

      this.value =
        formatInputNumber(
          this.value
        );

      updateFromTotal();

    }
  );

}


/* ================= SAVE TRADE ================= */

const saveTradeButton =
  document.getElementById(
    "saveTrade"
  );

if (saveTradeButton) {

  saveTradeButton.addEventListener(
    "click",
    function () {

      const type =
        document.getElementById(
          "tradeType"
        ).value;

      const weight =
        normalizeNumber(
          weightInput.value
        );

      const price18 =
        normalizeNumber(
          price18Input.value
        );

      const mazhane =
        normalizeNumber(
          mazhaneInput.value
        );

      const totalPrice =
        normalizeNumber(
          totalPriceInput.value
        );

      if (weight <= 0) {

        alert(
          "وزن معامله را وارد کنید."
        );

        return;

      }

      if (price18 <= 0) {

        alert(
          "فی گرم ۱۸ را وارد کنید."
        );

        return;

      }

      if (totalPrice <= 0) {

        alert(
          "قیمت کل معامله را وارد کنید."
        );

        return;

      }

      const finalMazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;

      const now =
        new Date();

      const trade = {

        id:
          Date.now() +
          Math.floor(
            Math.random() * 1000
          ),

        type,

        weight,

        price18,

        mazhane:
          finalMazhane,

        totalPrice,

        date:
          getDateKey(now),

        time:
          getTime(now),

        createdAt:
          now.toISOString()

      };

      trades.push(
        trade
      );

      saveTrades();

      weightInput.value = "";

      price18Input.value = "";

      mazhaneInput.value = "";

      totalPriceInput.value = "";

      renderAll();

      renderTodayTrades();

      renderHistory();

      showPage("trades");

    }
  );

}


/* ================= EDIT ================= */

function editTrade(id) {

  const trade =
    trades.find(
      item =>
        Number(item.id) ===
        Number(id)
    );

  if (!trade) {
    return;
  }

  editingTradeId =
    id;

  const editType =
    document.getElementById(
      "editType"
    );

  const editWeight =
    document.getElementById(
      "editWeight"
    );

  const editPrice18 =
    document.getElementById(
      "editPrice18"
    );

  const editMazhane =
    document.getElementById(
      "editMazhane"
    );

  const editTotalPrice =
    document.getElementById(
      "editTotalPrice"
    );

  if (
    !editType ||
    !editWeight ||
    !editPrice18 ||
    !editMazhane ||
    !editTotalPrice
  ) {
    return;
  }

  editType.value =
    trade.type;

  editWeight.value =
    formatInputNumber(
      trade.weight
    );

  editPrice18.value =
    formatInputNumber(
      trade.price18
    );

  editMazhane.value =
    formatInputNumber(
      trade.mazhane
    );

  editTotalPrice.value =
    formatInputNumber(
      trade.totalPrice
    );

  document.getElementById(
    "editModal"
  ).classList.add(
    "show"
  );

}


const closeModalButton =
  document.getElementById(
    "closeModal"
  );

if (closeModalButton) {

  closeModalButton.addEventListener(
    "click",
    function () {

      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );

    }
  );

}


const updateTradeButton =
  document.getElementById(
    "updateTrade"
  );

if (updateTradeButton) {

  updateTradeButton.addEventListener(
    "click",
    function () {

      const trade =
        trades.find(
          item =>
            Number(item.id) ===
            Number(editingTradeId)
        );

      if (!trade) {
        return;
      }

      const weight =
        normalizeNumber(
          document.getElementById(
            "editWeight"
          ).value
        );

      const price18 =
        normalizeNumber(
          document.getElementById(
            "editPrice18"
          ).value
        );

      const mazhane =
        normalizeNumber(
          document.getElementById(
            "editMazhane"
          ).value
        );

      const totalPrice =
        normalizeNumber(
          document.getElementById(
            "editTotalPrice"
          ).value
        );

      if (
        weight <= 0 ||
        price18 <= 0 ||
        totalPrice <= 0
      ) {

        alert(
          "اطلاعات معامله کامل نیست."
        );

        return;

      }

      trade.type =
        document.getElementById(
          "editType"
        ).value;

      trade.weight =
        weight;

      trade.price18 =
        price18;

      trade.mazhane =
        mazhane > 0
          ? mazhane
          : price18 * FACTOR;

      trade.totalPrice =
        totalPrice;

      saveTrades();

      document.getElementById(
        "editModal"
      ).classList.remove(
        "show"
      );

      renderAll();

      renderTodayTrades();

      renderHistory();

    }
  );

}


/* ================= DELETE ================= */

function deleteTrade(id) {

  const tradeToDelete =
    trades.find(
      trade =>
        Number(trade.id) ===
        Number(id)
    );

  if (!tradeToDelete) {
    return;
  }

  const ok =
    confirm(
      "آیا از حذف این معامله مطمئن هستید؟"
    );

  if (!ok) {
    return;
  }

  let deletedTradeDate =
    tradeToDelete.date;

  if (
    !deletedTradeDate &&
    tradeToDelete.createdAt
  ) {

    const createdDate =
      new Date(
        tradeToDelete.createdAt
      );

    if (
      !isNaN(
        createdDate.getTime()
      )
    ) {

      deletedTradeDate =
        getDateKey(
          createdDate
        );

    }

  }

  trades =
    trades.filter(
      trade =>
        Number(trade.id) !==
        Number(id)
    );

  saveTrades();

  renderHome();

  renderTodayTrades();

  calculateDemo();

  const sameDateStillExists =
    deletedTradeDate &&
    trades.some(
      trade => {

        let tradeDate =
          trade.date;

        if (
          !tradeDate &&
          trade.createdAt
        ) {

          const d =
            new Date(
              trade.createdAt
            );

          if (
            !isNaN(
              d.getTime()
            )
          ) {

            tradeDate =
              getDateKey(d);

          }

        }

        return (
          tradeDate ===
          deletedTradeDate
        );

      }
    );

  if (
    sameDateStillExists
  ) {

    renderHistory(
      deletedTradeDate
    );

  }

  else {

    renderHistory();

  }

}


/* ================= SETTINGS ================= */

const factorInput =
  document.getElementById(
    "factorInput"
  );

if (factorInput) {

  factorInput.value =
    FACTOR;

}


const saveFactorButton =
  document.getElementById(
    "saveFactor"
  );

if (saveFactorButton) {

  saveFactorButton.addEventListener(
    "click",
    function () {

      const value =
        Number(
          factorInput.value
        );

      if (
        !value ||
        value <= 0
      ) {

        alert(
          "ضریب واردشده معتبر نیست."
        );

        return;

      }

      FACTOR =
        value;

      localStorage.setItem(
        "shayan_gold_factor",
        String(FACTOR)
      );

      renderAll();

      calculateDemo();

      alert(
        "ضریب با موفقیت ذخیره شد."
      );

    }
  );

}


/* ================= NAVIGATION ================= */

function showPage(pageId) {

  document
    .querySelectorAll(".page")
    .forEach(
      page =>
        page.classList.remove(
          "active"
        )
    );

  document
    .querySelectorAll(".nav-btn")
    .forEach(
      button =>
        button.classList.remove(
          "active"
        )
    );

  const page =
    document.getElementById(
      pageId
    );

  const navButton =
    document.querySelector(
      `.nav-btn[data-page="${pageId}"]`
    );

  if (page) {

    page.classList.add(
      "active"
    );

  }

  if (navButton) {

    navButton.classList.add(
      "active"
    );

  }

  if (pageId === "trades") {

    renderTodayTrades();

  }

  if (pageId === "history") {

    renderHistory();

  }

  if (pageId === "demo") {

    calculateDemo();

  }

}


document
  .querySelectorAll(".nav-btn")
  .forEach(
    button => {

      button.addEventListener(
        "click",
        function () {

          showPage(
            this.dataset.page
          );

        }
      );

    }
  );


/* ================= RENDER ALL ================= */

function renderAll() {

  renderHome();

  renderTodayTrades();

  renderHistory();

  calculateDemo();

}


renderAll();

showPage("home");

