"use strict";

/* =========================================
   ANIMAL FOGHTER JT
   STABLE GAME ENGINE
========================================= */

var characters = [
    {
        name: "Kucing",
        emoji: "🐱",
        color: "#777777",
        skill: "Listrik",
        damage: 80,
        speed: 5.5,
        hp: 900
    },
    {
        name: "Beruang",
        emoji: "🐻",
        color: "#795548",
        skill: "Darah Tebal",
        damage: 95,
        speed: 3,
        hp: 1500
    },
    {
        name: "Serigala",
        emoji: "🐺",
        color: "#777777",
        skill: "Menghilang",
        damage: 75,
        speed: 5,
        hp: 1050
    },
    {
        name: "Kelinci",
        emoji: "🐰",
        color: "#eeeeee",
        skill: "Teleport",
        damage: 70,
        speed: 7,
        hp: 800
    },
    {
        name: "Elang",
        emoji: "🦅",
        color: "#8d6e63",
        skill: "Terbang",
        damage: 100,
        speed: 5,
        hp: 1000
    },
    {
        name: "Babi",
        emoji: "🐷",
        color: "#f48fb1",
        skill: "Laser Mata",
        damage: 110,
        speed: 3.5,
        hp: 1000
    },
    {
        name: "Monyet",
        emoji: "🐒",
        color: "#795548",
        skill: "Energi Biru",
        damage: 90,
        speed: 6,
        hp: 1050
    },
    {
        name: "Kudanil",
        emoji: "🦛",
        color: "#78909c",
        skill: "Pantulan",
        damage: 85,
        speed: 2.5,
        hp: 1700
    },
    {
        name: "Buaya",
        emoji: "🐊",
        color: "#4caf50",
        skill: "Cambuk Ekor",
        damage: 105,
        speed: 3.5,
        hp: 1200
    },
    {
        name: "Gorilla",
        emoji: "🦍",
        color: "#333333",
        skill: "Pukulan Kuat",
        damage: 125,
        speed: 3,
        hp: 1400
    }
];

/* =========================================
   GLOBAL
========================================= */

var playerChar = characters[0];
var enemyChar = characters[1];

var difficulty = "easy";

var player = null;
var enemy = null;

var gameRunning = false;

var playerSkillReady = true;
var enemySkillReady = true;

var playerSkillTimer = null;
var enemySkillTimer = null;

var keys = {};

var canvas = document.getElementById("canvas");
var ctx = canvas ? canvas.getContext("2d") : null;

var lastTime = 0;
var aiTimer = 0;

/* =========================================
   SCREEN
========================================= */

function showScreen(id) {
    var screens = document.querySelectorAll(".screen");

    for (var i = 0; i < screens.length; i++) {
        screens[i].classList.remove("active");
    }

    var screen = document.getElementById(id);

    if (screen) {
        screen.classList.add("active");
    }
}

function showDifficulty() {
    showScreen("difficulty");
}

function showSettings() {
    alert(
        "ANIMAL FOGHTER JT\n\n" +
        "Kontrol:\n" +
        "◀ ▶ = Bergerak\n" +
        "TONJOK = Serangan\n" +
        "TENDANG = Serangan kuat\n" +
        "SKILL = Skill khusus\n\n" +
        "Cooldown SKILL: 3 detik"
    );
}

function setDifficulty(level) {
    difficulty = level;
    createCharacterList();
    showScreen("select");
}

/* =========================================
   CHARACTER SELECT
========================================= */

function createCharacterList() {
    var grid = document.getElementById("characterGrid");

    if (!grid) {
        return;
    }

    grid.innerHTML = "";

    for (var i = 0; i < characters.length; i++) {
        (function(index) {
            var c = characters[index];

            var card = document.createElement("button");

            card.className = "characterCard";

            if (c.name === playerChar.name) {
                card.classList.add("selected");
            }

            card.innerHTML =
                "<div style='font-size:42px'>" +
                c.emoji +
                "</div>" +
                "<b>" +
                c.name.toUpperCase() +
                "</b>";

            card.onclick = function() {
                playerChar = characters[index];

                /* COM otomatis berbeda dari player */
                var randomEnemy;

                do {
                    randomEnemy =
                        characters[
                            Math.floor(Math.random() * characters.length)
                        ];
                } while (randomEnemy.name === playerChar.name);

                enemyChar = randomEnemy;

                createCharacterList();
            };

            grid.appendChild(card);
        })(i);
    }

    var vs = document.querySelector(".vs");

    if (vs) {
        vs.textContent =
            playerChar.emoji +
            " " +
            playerChar.name +
            "  VS  " +
            enemyChar.emoji +
            " " +
            enemyChar.name +
            " COM";
    }
}

/* =========================================
   CANVAS
========================================= */

function resizeCanvas() {
    if (!canvas) {
        return;
    }

    var rect = canvas.getBoundingClientRect();

    if (rect.width > 0 && rect.height > 0) {
        canvas.width = Math.floor(rect.width);
        canvas.height = Math.floor(rect.height);
    }
}

/* =========================================
   START FIGHT
========================================= */

function startFight() {
    if (playerSkillTimer) {
        clearTimeout(playerSkillTimer);
    }

    if (enemySkillTimer) {
        clearTimeout(enemySkillTimer);
    }

    playerSkillReady = true;
    enemySkillReady = true;

    player = {
        char: playerChar,
        x: 180,
        y: 0,
        hp: playerChar.hp,
        maxHp: playerChar.hp,
        facing: 1,
        attackCooldown: 0,
        stun: 0,
        invisible: 0,
        attackEffect: 0,
        skillEffect: 0
    };

    enemy = {
        char: enemyChar,
        x: 700,
        y: 0,
        hp: enemyChar.hp,
        maxHp: enemyChar.hp,
        facing: -1,
        attackCooldown: 0,
        stun: 0,
        invisible: 0,
        attackEffect: 0,
        skillEffect: 0
    };

    resizeCanvas();

    updateNames();
    updateHP();

    showScreen("fight");

    gameRunning = true;
    lastTime = performance.now();
    aiTimer = 0;

    requestAnimationFrame(gameLoop);
}

/* =========================================
   HUD
========================================= */

function updateNames() {
    var playerName = document.getElementById("playerName");
    var enemyName = document.getElementById("enemyName");

    if (playerName) {
        playerName.textContent =
            playerChar.emoji + " " + playerChar.name;
    }

    if (enemyName) {
        enemyName.textContent =
            enemyChar.emoji + " " + enemyChar.name + " COM";
    }
}

function updateHP() {
    if (!player || !enemy) {
        return;
    }

    var playerHp = document.getElementById("playerHp");
    var enemyHp = document.getElementById("enemyHp");

    if (playerHp) {
        var p = Math.max(
            0,
            Math.min(100, (player.hp / player.maxHp) * 100)
        );

        playerHp.style.width = p + "%";
    }

    if (enemyHp) {
        var e = Math.max(
            0,
            Math.min(100, (enemy.hp / enemy.maxHp) * 100)
        );

        enemyHp.style.width = e + "%";
    }
}

/* =========================================
   ATTACK
========================================= */

function attack(attacker, target, type) {
    if (!gameRunning) {
        return;
    }

    if (!attacker || !target) {
        return;
    }

    if (attacker.stun > 0) {
        return;
    }

    if (attacker.attackCooldown > 0) {
        return;
    }

    if (target.invisible > 0) {
        return;
    }

    var distance = Math.abs(attacker.x - target.x);

    var range = type === "skill" ? 260 : 150;

    if (distance > range) {
        return;
    }

    var damage = attacker.char.damage;

    if (type === "punch") {
        damage = damage * 0.8;
    }

    if (type === "kick") {
        damage = damage * 1.15;
    }

    if (type === "skill") {
        damage = damage * 1.4;
    }

    /* Beruang lebih kuat dengan pukulan */
    if (
        attacker.char.name === "Beruang" &&
        type === "punch"
    ) {
        damage += 15;
    }

    /* Gorilla pukulan sangat kuat */
    if (
        attacker.char.name === "Gorilla" &&
        type === "punch"
    ) {
        damage += 35;
    }

    /* Kudanil hanya menerima 50% damage */
    if (target.char.name === "Kudanil") {
        damage = damage * 0.5;
    }

    target.hp -= damage;

    if (target.hp < 0) {
        target.hp = 0;
    }

    /* Pantulan Kudanil */
    if (
        target.char.name === "Kudanil" &&
        type !== "skill"
    ) {
        attacker.hp -= damage * 0.25;

        if (attacker.hp < 0) {
            attacker.hp = 0;
        }
    }

    /* Efek khusus */
    if (
        attacker.char.name === "Kucing" &&
        type === "skill"
    ) {
        target.stun = 1;
    }

    attacker.attackCooldown =
        type === "skill" ? 0.8 : 0.45;

    attacker.attackEffect = 0.15;

    updateHP();

    checkWinner();
}

/* =========================================
   PLAYER ATTACKS
========================================= */

function playerPunch() {
    if (!player || !enemy) {
        return;
    }

    attack(player, enemy, "punch");
}

function playerKick() {
    if (!player || !enemy) {
        return;
    }

    attack(player, enemy, "kick");
}

function playerSkill() {
    if (!player || !enemy) {
        return;
    }

    if (!playerSkillReady) {
        return;
    }

    playerSkillReady = false;
    player.skillEffect = 0.5;

    var name = player.char.name;

    if (name === "Serigala") {
        player.invisible = 1.5;
    }

    if (name === "Kelinci") {
        player.x = enemy.x - 120;
    }

    if (name === "Elang") {
        player.y = -100;
    }

    if (name === "Beruang") {
        player.hp += 150;

        if (player.hp > player.maxHp) {
            player.hp = player.maxHp;
        }
    }

    if (name === "Kudanil") {
        player.stun = 0;
    }

    attack(player, enemy, "skill");

    updateHP();
    startPlayerCooldown();
}

function startPlayerCooldown() {
    var button = document.getElementById("skill");

    if (!button) {
        return;
    }

    if (playerSkillTimer) {
        clearTimeout(playerSkillTimer);
    }

    var seconds = 3;

    button.classList.add("cooldown");
    button.textContent = seconds;

    playerSkillTimer = setInterval(function() {
        seconds--;

        if (seconds > 0) {
            button.textContent = seconds;
        } else {
            clearInterval(playerSkillTimer);

            playerSkillReady = true;

            button.textContent = "SKILL";
            button.classList.remove("cooldown");
        }
    }, 1000);
}

/* =========================================
   ENEMY SKILL
========================================= */

function enemySkill() {
    if (!enemy || !player) {
        return;
    }

    if (!enemySkillReady) {
        return;
    }

    enemySkillReady = false;

    enemy.skillEffect = 0.5;

    var name = enemy.char.name;

    if (name === "Serigala") {
        enemy.invisible = 1.2;
    }

    if (name === "Kelinci") {
        enemy.x = player.x + 100;
    }

    if (name === "Elang") {
        enemy.y = -100;
    }

    if (name === "Beruang") {
        enemy.hp += 120;

        if (enemy.hp > enemy.maxHp) {
            enemy.hp = enemy.maxHp;
        }
    }

    attack(enemy, player, "skill");

    updateHP();

    if (enemySkillTimer) {
        clearTimeout(enemySkillTimer);
    }

    enemySkillTimer = setTimeout(function() {
        enemySkillReady = true;
    }, 3000);
}

/* =========================================
   MOVEMENT
========================================= */

function movePlayer(direction) {
    if (!player || !gameRunning) {
        return;
    }

    if (player.stun > 0) {
        return;
    }

    player.x +=
        direction *
        player.char.speed *
        12;

    player.facing = direction;

    keepInsideArena(player);
}

function keepInsideArena(fighter) {
    if (!canvas || !fighter) {
        return;
    }

    fighter.x = Math.max(
        70,
        Math.min(canvas.width - 70, fighter.x)
    );
}

/* =========================================
   AI
========================================= */

function updateAI(dt) {
    if (!enemy || !player) {
        return;
    }

    if (enemy.stun > 0) {
        enemy.stun -= dt;
        return;
    }

    var distance = player.x - enemy.x;

    enemy.facing = distance >= 0 ? 1 : -1;

    var speed = enemy.char.speed;

    if (difficulty === "easy") {
        speed *= 0.45;
    }

    if (difficulty === "medium") {
        speed *= 0.7;
    }

    if (difficulty === "hard") {
        speed *= 1;
    }

    if (Math.abs(distance) > 140) {
        enemy.x += Math.sign(distance) * speed * dt * 40;
    }

    keepInsideArena(enemy);

    aiTimer += dt;

    var attackDelay = 1.2;

    if (difficulty === "medium") {
        attackDelay = 0.8;
    }

    if (difficulty === "hard") {
        attackDelay = 0.5;
    }

    if (
        Math.abs(distance) < 160 &&
        aiTimer >= attackDelay
    ) {
        aiTimer = 0;

        var random = Math.random();

        if (random < 0.2) {
            enemySkill();
        } else if (random < 0.6) {
            attack(enemy, player, "punch");
        } else {
            attack(enemy, player, "kick");
        }
    }
}

/* =========================================
   UPDATE
========================================= */

function updateGame(dt) {
    if (!player || !enemy) {
        return;
    }

    if (player.attackCooldown > 0) {
        player.attackCooldown -= dt;

        if (player.attackCooldown < 0) {
            player.attackCooldown = 0;
        }
    }

    if (enemy.attackCooldown > 0) {
        enemy.attackCooldown -= dt;

        if (enemy.attackCooldown < 0) {
            enemy.attackCooldown = 0;
        }
    }

    if (player.invisible > 0) {
        player.invisible -= dt;
    }

    if (enemy.invisible > 0) {
        enemy.invisible -= dt;
    }

    if (player.attackEffect > 0) {
        player.attackEffect -= dt;
    }

    if (enemy.attackEffect > 0) {
        enemy.attackEffect -= dt;
    }

    if (player.skillEffect > 0) {
        player.skillEffect -= dt;
    }

    if (enemy.skillEffect > 0) {
        enemy.skillEffect -= dt;
    }

    if (player.stun > 0) {
        player.stun -= dt;
    }

    if (enemy.stun > 0) {
        enemy.stun -= dt;
    }

    /* Keyboard */
    if (keys["ArrowLeft"] || keys["a"]) {
        movePlayer(-1);
    }

    if (keys["ArrowRight"] || keys["d"]) {
        movePlayer(1);
    }

    updateAI(dt);
}

/* =========================================
   BACKGROUND
========================================= */

function drawBackground() {
    if (!ctx || !canvas) {
        return;
    }

    var w = canvas.width;
    var h = canvas.height;

    /* Langit */
    var sky = ctx.createLinearGradient(
        0,
        0,
        0,
        h
    );

    sky.addColorStop(0, "#4db6e9");
    sky.addColorStop(0.6, "#9bd8ee");
    sky.addColorStop(1, "#f4d18a");

    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);

    /* Matahari */
    ctx.fillStyle = "#ffd42a";
    ctx.beginPath();
    ctx.arc(
        w / 2,
        h * 0.22,
        Math.min(w, h) * 0.12,
        0,
        Math.PI * 2
    );
    ctx.fill();

    /* Awan */
    drawCloud(w * 0.18, h * 0.18);
    drawCloud(w * 0.78, h * 0.2);

    /* Bukit */
    ctx.fillStyle = "#b9823c";

    ctx.beginPath();
    ctx.moveTo(0, h * 0.55);
    ctx.quadraticCurveTo(
        w * 0.25,
        h * 0.43,
        w * 0.5,
        h * 0.55
    );
    ctx.quadraticCurveTo(
        w * 0.75,
        h * 0.43,
        w,
        h * 0.55
    );
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();

    /* Pasir */
    ctx.fillStyle = "#d99c45";
    ctx.fillRect(
        0,
        h * 0.63,
        w,
        h * 0.37
    );

    /* Garis tanah */
    ctx.strokeStyle = "rgba(80,50,20,0.25)";
    ctx.lineWidth = 4;

    ctx.beginPath();
    ctx.moveTo(0, h * 0.63);
    ctx.lineTo(w, h * 0.63);
    ctx.stroke();
}

function drawCloud(x, y) {
    if (!ctx) {
        return;
    }

    ctx.fillStyle = "rgba(255,255,255,0.8)";

    ctx.beginPath();
    ctx.arc(x, y, 28, 0, Math.PI * 2);
    ctx.arc(x + 30, y - 15, 38, 0, Math.PI * 2);
    ctx.arc(x + 65, y, 30, 0, Math.PI * 2);
    ctx.fill();
}

/* =========================================
   DRAW FIGHTER
========================================= */

function drawFighter(fighter) {
    if (!ctx || !canvas || !fighter) {
        return;
    }

    var ground = canvas.height * 0.63;
    var x = fighter.x;
    var y = ground - 100 + fighter.y;

    if (fighter.invisible > 0) {
        ctx.globalAlpha = 0.25;
    }

    /* Bayangan */
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.beginPath();
    ctx.ellipse(
        x,
        ground + 3,
        55,
        12,
        0,
        0,
        Math.PI * 2
    );
    ctx.fill();

    /* Kaki */
    ctx.strokeStyle = "#222";
    ctx.lineWidth = 14;
    ctx.lineCap = "round";

    ctx.beginPath();
    ctx.moveTo(x - 15, y + 65);
    ctx.lineTo(x - 25, y + 105);
    ctx.moveTo(x + 15, y + 65);
    ctx.lineTo(x + 25, y + 105);
    ctx.stroke();

    /* Badan */
    ctx.fillStyle = fighter.char.color;

    ctx.beginPath();
    ctx.roundRect(
        x - 34,
        y + 5,
        68,
        70,
        20
    );
    ctx.fill();

    /* Tangan */
    ctx.strokeStyle = fighter.char.color;
    ctx.lineWidth = 16;

    ctx.beginPath();

    ctx.moveTo(
        x - 30,
        y + 20
    );

    ctx.lineTo(
        x - 60 * fighter.facing,
        y + 45
    );

    ctx.moveTo(
        x + 30,
        y + 20
    );

    ctx.lineTo(
        x + 60 * fighter.facing,
        y + 45
    );

    ctx.stroke();

    /* Kepala */
    ctx.fillStyle = "#f1c27d";

    ctx.beginPath();
    ctx.arc(
        x,
        y - 10,
        42,
        0,
        Math.PI * 2
    );
    ctx.fill();

    /* Emoji kepala */
    ctx.font = "48px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    ctx.fillText(
        fighter.char.emoji,
        x,
        y - 12
    );

    /* Efek pukulan */
    if (fighter.attackEffect > 0) {
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 7;

        ctx.beginPath();

        ctx.arc(
            x + fighter.facing * 65,
            y + 35,
            30,
            -1,
            1
        );

        ctx.stroke();
    }

    /* Efek skill */
    if (fighter.skillEffect > 0) {
        drawSkillEffect(fighter);
    }

    ctx.globalAlpha = 1;
}

/* =========================================
   SKILL EFFECT
========================================= */

function drawSkillEffect(fighter) {
    if (!ctx) {
        return;
    }

    var x = fighter.x;
    var y =
        canvas.height * 0.63 -
        60 +
        fighter.y;

    var name = fighter.char.name;

    ctx.lineWidth = 8;

    if (name === "Kucing") {
        ctx.strokeStyle = "#ffff00";

        for (var i = 0; i < 5; i++) {
            ctx.beginPath();
            ctx.moveTo(
                x + fighter.facing * 35,
                y - 30 + i * 15
            );
            ctx.lineTo(
                x + fighter.facing * 35,
                y -50 +i * 20
                );
            ctx.stroke();
        }
    }

    if (name === "Babi") {
        ctx.strokeStyle = "#ff2222";

        ctx.beginPath();
        ctx.moveTo(
            x + fighter.facing * 35,
            y - 15
        );
        ctx.lineTo(
            x + fighter.facing * 300,
            y - 15
        );
        ctx.stroke();
    }

    if (name === "Monyet") {
        ctx.strokeStyle = "#00aaff";

        ctx.beginPath();
        ctx.arc(
            x + fighter.facing * 80,
            y,
            55,
            0,
            Math.PI * 2
        );
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(
            x + fighter.facing * 120,
            y,
            30,
            0,
            Math.PI * 2
        );
        ctx.stroke();
    }

    if (name === "Gorilla") {
        ctx.strokeStyle = "#ffffff";

        ctx.beginPath();
        ctx.arc(
            x + fighter.facing * 80,
            y + 20,
            60,
            -1,
            1
        );
        ctx.stroke();
    }

    if (name === "Elang") {
        ctx.strokeStyle = "#ffffff";

        ctx.beginPath();
        ctx.arc(
            x,
            y,
            70,
            0,
            Math.PI * 2
        );
        ctx.stroke();
    }

    if (name === "Buaya") {
        ctx.strokeStyle = "#55ff55";

        ctx.beginPath();
        ctx.moveTo(
            x - fighter.facing * 30,
            y + 40
        );
        ctx.quadraticCurveTo(
            x - fighter.facing * 120,
            y + 10,
            x - fighter.facing * 180,
            y + 50
        );
        ctx.stroke();
    }

    if (name === "Kelinci") {
        ctx.strokeStyle = "#ffffff";

        ctx.beginPath();
        ctx.arc(
            x,
            y,
            75,
            0,
            Math.PI * 2
        );
        ctx.stroke();
    }
}

/* =========================================
   GAME LOOP
========================================= */

function gameLoop(time) {
    if (!gameRunning) {
        return;
    }

    var dt =
        (time - lastTime) / 1000;

    if (dt > 0.05) {
        dt = 0.05;
    }

    lastTime = time;

    updateGame(dt);

    if (ctx && canvas) {
        ctx.clearRect(
            0,
            0,
            canvas.width,
            canvas.height
        );

        drawBackground();

        drawFighter(player);
        drawFighter(enemy);
    }

    updateHP();

    if (gameRunning) {
        requestAnimationFrame(gameLoop);
    }
}

/* =========================================
   WIN / LOSE
========================================= */

function checkWinner() {
    if (!player || !enemy) {
        return;
    }

    if (player.hp <= 0) {
        endFight("YOU LOSE!");
        return;
    }

    if (enemy.hp <= 0) {
        endFight("YOU WIN!");
    }
}

function endFight(text) {
    if (!gameRunning) {
        return;
    }

    gameRunning = false;

    if (playerSkillTimer) {
        clearInterval(playerSkillTimer);
    }

    if (enemySkillTimer) {
        clearTimeout(enemySkillTimer);
    }

    var result = document.getElementById("resultText");

    if (result) {
        result.textContent = text;
    }

    showScreen("result");
}

/* =========================================
   BUTTON EVENTS
========================================= */

function setupButtons() {
    var left = document.getElementById("leftBtn");
    var right = document.getElementById("rightBtn");
    var punch = document.getElementById("punch");
    var kick = document.getElementById("kick");
    var skill = document.getElementById("skill");

    if (left) {
        left.addEventListener("pointerdown", function() {
            movePlayer(-1);
        });
    }

    if (right) {
        right.addEventListener("pointerdown", function() {
            movePlayer(1);
        });
    }

    if (punch) {
        punch.addEventListener("pointerdown", function() {
            playerPunch();
        });
    }

    if (kick) {
        kick.addEventListener("pointerdown", function() {
            playerKick();
        });
    }

    if (skill) {
        skill.addEventListener("pointerdown", function() {
            playerSkill();
        });
    }
}

/* =========================================
   KEYBOARD
========================================= */

document.addEventListener(
    "keydown",
    function(event) {
        keys[event.key] = true;

        if (event.key === "j") {
            playerPunch();
        }

        if (event.key === "k") {
            playerKick();
        }

        if (event.key === "l") {
            playerSkill();
        }
    }
);

document.addEventListener(
    "keyup",
    function(event) {
        keys[event.key] = false;
    }
);

/* =========================================
   INIT
========================================= */

function initGame() {
    createCharacterList();
    setupButtons();
    resizeCanvas();

    window.addEventListener(
        "resize",
        function() {
            resizeCanvas();
        }
    );
}

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        initGame
    );
} else {
    initGame();
}