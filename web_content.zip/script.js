const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

let score = 0;
let isGameOver = false;
const scoreVal = document.getElementById('score-val');
const gameOverScreen = document.getElementById('game-over-screen');
const finalScore = document.getElementById('final-score');

const player = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  radius: 10,
  speed: 4.5,
  trail: [],
  hasShield: false,
  shieldTime: 0
};

let orb = { x: 0, y: 0, radius: 6 };
let shieldItem = { x: -100, y: -100, radius: 8, active: false };

function spawnOrb() {
  orb.x = Math.random() * (canvas.width - 40) + 20;
  orb.y = Math.random() * (canvas.height - 40) + 20;
}
spawnOrb();

function spawnShieldItem() {
  if (Math.random() < 0.3 && !shieldItem.active && !player.hasShield) {
    shieldItem.x = Math.random() * (canvas.width - 40) + 20;
    shieldItem.y = Math.random() * (canvas.height - 40) + 20;
    shieldItem.active = true;
  }
}

let enemies = [];
let particles = [];

function spawnEnemy(type = 'normal') {
  let x = Math.random() > 0.5 ? 0 : canvas.width;
  let y = Math.random() * canvas.height;
  
  if (type === 'fast') {
    let angle = Math.atan2(player.y - y, player.x - x);
    enemies.push({ x, y, radius: 7, speed: 6, type: 'fast', vx: Math.cos(angle) * 6, vy: Math.sin(angle) * 6 });
  } else {
    enemies.push({ x, y, radius: 12, speed: 1.5 + Math.random(), type: 'normal' });
  }
}

function createExplosion(x, y, color) {
  for (let i = 0; i < 8; i++) {
    particles.push({
      x, y,
      vx: (Math.random() - 0.5) * 4,
      vy: (Math.random() - 0.5) * 4,
      radius: Math.random() * 3,
      alpha: 1,
      color: color
    });
  }
}

const joystick = document.getElementById('joystick-container');
const stick = document.getElementById('joystick-stick');
let joyActive = false;
let joyStart = { x: 0, y: 0 };
let joyMove = { x: 0, y: 0 };

joystick.addEventListener('touchstart', (e) => {
  if (isGameOver) return;
  joyActive = true;
  joyStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
});

window.addEventListener('touchmove', (e) => {
  if (!joyActive) return;
  let dx = e.touches[0].clientX - joyStart.x;
  let dy = e.touches[0].clientY - joyStart.y;
  const dist = Math.min(40, Math.sqrt(dx * dx + dy * dy));
  const angle = Math.atan2(dy, dx);

  const moveX = dist * Math.cos(angle);
  const moveY = dist * Math.sin(angle);
  stick.style.transform = `translate(calc(-50% + ${moveX}px), calc(-50% + ${moveY}px))`;

  joyMove.x = moveX / 40;
  joyMove.y = moveY / 40;
});

window.addEventListener('touchend', () => {
  joyActive = false;
  stick.style.transform = 'translate(-50%, -50%)';
  joyMove = { x: 0, y: 0 };
});

document.getElementById('restart-btn').addEventListener('click', () => {
  score = 0;
  scoreVal.textContent = score;
  enemies = [];
  particles = [];
  player.x = canvas.width / 2;
  player.y = canvas.height / 2;
  player.trail = [];
  player.hasShield = false;
  shieldItem.active = false;
  isGameOver = false;
  gameOverScreen.style.display = 'none';
  spawnOrb();
  spawnEnemy('normal');
  gameLoop();
});

function gameLoop() {
  if (isGameOver) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (player.hasShield) {
    player.shieldTime--;
    if (player.shieldTime <= 0) player.hasShield = false;
  }

  if (joyMove.x !== 0 || joyMove.y !== 0) {
    player.trail.push({ x: player.x, y: player.y });
    if (player.trail.length > 6) player.trail.shift();
  } else {
    if (player.trail.length > 0) player.trail.shift();
  }

  player.x += joyMove.x * player.speed;
  player.y += joyMove.y * player.speed;
  player.x = Math.max(player.radius + 15, Math.min(canvas.width - player.radius - 15, player.x));
  player.y = Math.max(player.radius, Math.min(canvas.height - player.radius, player.y));

  let distToOrb = Math.sqrt((player.x - orb.x) ** 2 + (player.y - orb.y) ** 2);
  if (distToOrb < player.radius + orb.radius + 4) {
    score += 10;
    scoreVal.textContent = score;
    createExplosion(orb.x, orb.y, '#00ffff');
    spawnOrb();
    spawnShieldItem();
    
    if (score % 20 === 0) spawnEnemy('normal');
    if (score % 30 === 0) spawnEnemy('fast');
  }

  if (shieldItem.active) {
    let distToShield = Math.sqrt((player.x - shieldItem.x) ** 2 + (player.y - shieldItem.y) ** 2);
    if (distToShield < player.radius + shieldItem.radius + 4) {
      player.hasShield = true;
      player.shieldTime = 300;
      shieldItem.active = false;
      createExplosion(shieldItem.x, shieldItem.y, '#bf55ec');
    }
  }

  player.trail.forEach((pos, index) => {
    let alpha = (index + 1) / player.trail.length * 0.12;
    ctx.fillStyle = player.hasShield ? `rgba(191, 85, 236, ${alpha})` : `rgba(255, 255, 255, ${alpha})`;
    ctx.beginPath();
    ctx.arc(pos.x - 7, pos.y, player.radius * 0.8, 0, Math.PI * 2);
    ctx.arc(pos.x + 7, pos.y, player.radius * 0.8, 0, Math.PI * 2);
    ctx.fill();
  });

  particles.forEach((p, index) => {
    p.x += p.vx;
    p.y += p.vy;
    p.alpha -= 0.02;
    if (p.alpha <= 0) {
      particles.splice(index, 1);
    } else {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  });

  ctx.shadowBlur = 15;
  ctx.shadowColor = '#00ffff';
  ctx.fillStyle = '#00ffff';
  ctx.beginPath();
  ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
  ctx.fill();

  if (shieldItem.active) {
    ctx.shadowColor = '#bf55ec';
    ctx.fillStyle = '#bf55ec';
    ctx.beginPath();
    ctx.arc(shieldItem.x, shieldItem.y, shieldItem.radius, 0, Math.PI * 2);
    ctx.fill();
  }

  enemies.forEach((enemy, index) => {
    if (enemy.type === 'fast') {
      enemy.x += enemy.vx;
      enemy.y += enemy.vy;
      if (enemy.x < -50 || enemy.x > canvas.width + 50 || enemy.y < -50 || enemy.y > canvas.height + 50) {
        enemies.splice(index, 1);
        return;
      }
      ctx.shadowColor = '#ffec3d';
      ctx.fillStyle = '#ffec3d';
    } else {
      let angle = Math.atan2(player.y - enemy.y, player.x - enemy.x);
      enemy.x += Math.cos(angle) * enemy.speed;
      enemy.y += Math.sin(angle) * enemy.speed;
      ctx.shadowColor = '#ff3333';
      ctx.fillStyle = '#ff3333';
    }

    ctx.beginPath();
    ctx.arc(enemy.x, enemy.y, enemy.radius, 0, Math.PI * 2);
    ctx.fill();

    let dist = Math.sqrt((player.x - enemy.x) ** 2 + (player.y - enemy.y) ** 2);
    if (dist < player.radius + enemy.radius) {
      if (player.hasShield) {
        createExplosion(enemy.x, enemy.y, enemy.type === 'fast' ? '#ffec3d' : '#ff3333');
        enemies.splice(index, 1);
      } else {
        isGameOver = true;
        finalScore.textContent = score;
        gameOverScreen.style.display = 'block';
      }
    }
  });

  ctx.shadowBlur = 25;
  ctx.shadowColor = player.hasShield ? '#bf55ec' : '#ffffff';
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(player.x - 7, player.y, player.radius, 0, Math.PI * 2);
  ctx.arc(player.x + 7, player.y, player.radius, 0, Math.PI * 2);
  ctx.fill();

  if (player.hasShield) {
    ctx.strokeStyle = '#bf55ec';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(player.x, player.y, player.radius + 14, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.shadowBlur = 0;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.arc(player.x - 7 + (joyMove.x * 2), player.y + (joyMove.y * 2), 2, 0, Math.PI * 2);
  ctx.arc(player.x + 7 + (joyMove.x * 2), player.y + (joyMove.y * 2), 2, 0, Math.PI * 2);
  ctx.fill();

  requestAnimationFrame(gameLoop);
}

spawnEnemy('normal');
gameLoop();
