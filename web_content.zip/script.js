const taskInput = document.getElementById("taskInput");
const priorityInput = document.getElementById("priorityInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const taskList = document.getElementById("taskList");
const totalTasks = document.getElementById("totalTasks");
const completedTasks = document.getElementById("completedTasks");
const pendingTasks = document.getElementById("pendingTasks");
const deadlineInput = document.getElementById("deadlineInput");
const reminderHourInput = document.getElementById("reminderHourInput");
const reminderMinuteInput = document.getElementById("reminderMinuteInput");
const reminderPeriodInput = document.getElementById("reminderPeriodInput");
const themeBtn = document.getElementById("themeBtn");
const alarmSound = document.getElementById("alarmSound");


// ==============================
// UPDATE STATISTICS
// ==============================

function updateStats() {

    const tasks = document.querySelectorAll(".task");
    const completed = document.querySelectorAll(".task.completed");

    totalTasks.textContent = tasks.length;
    completedTasks.textContent = completed.length;
    pendingTasks.textContent = tasks.length - completed.length;
}


// ==============================
// CHECK OVERDUE TASKS
// ==============================

function checkOverdueTasks() {

    const today = new Date().toISOString().split("T")[0];

    document.querySelectorAll(".task").forEach(function (task) {

        const deadlineElement = task.querySelector(".deadline");

        if (!deadlineElement) {
            return;
        }

        const deadline = deadlineElement.dataset.date;

        if (
            deadline &&
            deadline < today &&
            !task.classList.contains("completed")
        ) {

            deadlineElement.classList.add("overdue");
            deadlineElement.textContent =
                "⚠️ Overdue: " + deadline;

        } else {

            deadlineElement.classList.remove("overdue");

            if (deadline) {
                deadlineElement.textContent =
                    "📅 " + deadline;
            } else {
                deadlineElement.textContent =
                    "📅 No deadline";
            }
        }
    });
}


// ==============================
// SAVE TASKS
// ==============================

function saveTasks() {

    const tasks = [];

    document.querySelectorAll(".task").forEach(function (task) {

        const taskText =
            task.querySelector(".task-info strong").textContent;

        const priority =
            task.querySelector(".priority").classList[1];

        const deadlineElement =
            task.querySelector(".deadline");

        const reminderElement =
            task.querySelector(".reminder");

        const deadline =
            deadlineElement.dataset.date || "";

        const reminder =
            reminderElement.dataset.time || "";

        const completed =
            task.classList.contains("completed");

        tasks.push({
            text: taskText,
            priority: priority,
            deadline: deadline,
            reminder: reminder,
            completed: completed
        });
    });

    localStorage.setItem(
        "tasks",
        JSON.stringify(tasks)
    );
}


// ==============================
// CREATE TASK
// ==============================

function createTask(
    taskText,
    priority,
    deadline,
    reminder,
    completed = false
) {

    const task = document.createElement("div");

    task.className = "task";

    if (completed) {
        task.classList.add("completed");
    }

    task.innerHTML = `
        <div class="task-info">

            <strong>${taskText}</strong>

            <span class="priority ${priority}">
                ${priority.toUpperCase()} PRIORITY
            </span>

            <span class="deadline" data-date="${deadline}">
                📅 ${deadline || "No deadline"}
            </span>

            <span class="reminder" data-time="${reminder}">
                ⏰ ${reminder || "No reminder"}
            </span>

        </div>

        <div>
            <button class="complete-btn">
                ${completed ? "Undo" : "Complete"}
            </button>

            <button class="delete-btn">
                Delete
            </button>
        </div>
    `;

    taskList.appendChild(task);


    // COMPLETE / UNDO

    const completeBtn =
        task.querySelector(".complete-btn");

    completeBtn.addEventListener("click", function () {

        task.classList.toggle("completed");

        if (task.classList.contains("completed")) {
            completeBtn.textContent = "Undo";
        } else {
            completeBtn.textContent = "Complete";
        }

        updateStats();
        saveTasks();
        checkOverdueTasks();
    });


    // DELETE

    const deleteBtn =
        task.querySelector(".delete-btn");

    deleteBtn.addEventListener("click", function () {

        task.remove();

        updateStats();
        saveTasks();
        checkOverdueTasks();
    });
}


// ==============================
// ADD TASK
// ==============================

addTaskBtn.addEventListener("click", function () {

    const taskText = taskInput.value.trim();
    const priority = priorityInput.value;
    const deadline = deadlineInput.value;
  let reminder = "";

const hour = reminderHourInput.value;
const minute = reminderMinuteInput.value;
const period = reminderPeriodInput.value;

if (hour && minute && period) {
    let hour24 = parseInt(hour);

    if (period === "AM" && hour24 === 12) {
        hour24 = 0;
    }

    if (period === "PM" && hour24 !== 12) {
        hour24 += 12;
    }

    reminder =
        String(hour24).padStart(2, "0") +
        ":" +
        minute;
}

    if (taskText === "") {

        alert("Please enter a task!");

        return;
    }

    createTask(
        taskText,
        priority,
        deadline,
        reminder,
        false
    );

    updateStats();
    saveTasks();
    checkOverdueTasks();

    taskInput.value = "";
    deadlineInput.value = "";
    reminderInput.value = "";
});


// ==============================
// FILTER TASKS
// ==============================

const filterButtons =
    document.querySelectorAll(".filter-btn");

filterButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        const filter = button.dataset.filter;

        filterButtons.forEach(function (btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");

        const tasks =
            document.querySelectorAll(".task");

        tasks.forEach(function (task) {

            const priorityElement =
                task.querySelector(".priority");

            if (filter === "all") {

                task.style.display = "flex";

            } else if (filter === "completed") {

                task.style.display =
                    task.classList.contains("completed")
                        ? "flex"
                        : "none";

            } else if (filter === "pending") {

                task.style.display =
                    !task.classList.contains("completed")
                        ? "flex"
                        : "none";

            } else {

                task.style.display =
                    priorityElement.classList.contains(filter)
                        ? "flex"
                        : "none";
            }
        });
    });
});


// ==============================
// LOAD SAVED TASKS
// ==============================

function loadTasks() {

    const savedTasks =
        JSON.parse(localStorage.getItem("tasks")) || [];

    savedTasks.forEach(function (savedTask) {

        createTask(
            savedTask.text,
            savedTask.priority,
            savedTask.deadline || "",
            savedTask.reminder || "",
            savedTask.completed
        );
    });

    updateStats();
    checkOverdueTasks();
}


// ==============================
// NOTIFICATION PERMISSION
// ==============================

if ("Notification" in window) {

    if (Notification.permission === "default") {
        Notification.requestPermission();
    }
}


// ==============================
// TASK REMINDER
// ==============================

function checkReminders() {

    const now = new Date();

    const currentDate =
        now.getFullYear() +
        "-" +
        String(now.getMonth() + 1).padStart(2, "0") +
        "-" +
        String(now.getDate()).padStart(2, "0");

    const currentTime =
        String(now.getHours()).padStart(2, "0") +
        ":" +
        String(now.getMinutes()).padStart(2, "0");


    document.querySelectorAll(".task").forEach(function (task) {

        if (task.classList.contains("completed")) {
            return;
        }

        const deadlineElement =
            task.querySelector(".deadline");

        const reminderElement =
            task.querySelector(".reminder");

        if (!deadlineElement || !reminderElement) {
            return;
        }

        const deadline =
            deadlineElement.dataset.date;

        const reminder =
            reminderElement.dataset.time;

        const taskName =
            task.querySelector(
                ".task-info strong"
            ).textContent;


        if (
            deadline === currentDate &&
            reminder === currentTime
        ) {

            const reminderKey =
                deadline + "_" +
                reminder + "_" +
                taskName;

            const notified =
                JSON.parse(
                    localStorage.getItem(
                        "notifiedReminders"
                    )
                ) || [];


            if (!notified.includes(reminderKey)) {

                // Browser notification

                if (
                    "Notification" in window &&
                    Notification.permission === "granted"
                ) {

                    new Notification(
                        "⏰ Task Reminder",
                        {
                            body: taskName
                        }
                    );
                }


                // Alarm sound

                alarmSound.currentTime = 0;

                alarmSound.play().catch(function () {
                    console.log(
                        "Browser blocked automatic audio."
                    );
                });


                // On-screen alert

                alert(
                    "⏰ Reminder!\n\n" +
                    taskName
                );


                // Remember notification

                notified.push(reminderKey);

                localStorage.setItem(
                    "notifiedReminders",
                    JSON.stringify(notified)
                );
            }
        }
    });
}


// Check every 10 seconds

setInterval(checkReminders, 10000);


// ==============================
// DARK MODE
// ==============================

themeBtn.addEventListener("click", function () {

    document.body.classList.toggle("dark-mode");

    if (
        document.body.classList.contains(
            "dark-mode"
        )
    ) {

        themeBtn.textContent =
            "☀️ Light Mode";

        localStorage.setItem(
            "theme",
            "dark"
        );

    } else {

        themeBtn.textContent =
            "🌙 Dark Mode";

        localStorage.setItem(
            "theme",
            "light"
        );
    }
});


// LOAD SAVED THEME

const savedTheme =
    localStorage.getItem("theme");

if (savedTheme === "dark") {

    document.body.classList.add(
        "dark-mode"
    );

    themeBtn.textContent =
        "☀️ Light Mode";
}


// ==============================
// START APPLICATION
// ==============================

loadTasks();
checkReminders();