const API_URL="https://openrouter.ai/api/v1/chat/completions";
const BUILTIN_API_KEY="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";
const ADMIN_LOGIN="AdminVB",ADMIN_PASSWORD="Route",DEFAULT_MODEL="openai/gpt-4o-mini";
let state=JSON.parse(localStorage.getItem("vibe_state_v2")||"null")||{chats:[],activeId:null,theme:"pink",model:DEFAULT_MODEL,ownKey:false,apiKey:"",admin:false};
if(!state.chats.length)state.chats=[{id:crypto.randomUUID(),title:"Новый чат",messages:[]}];
if(!state.activeId)state.activeId=state.chats[0].id;
const $=x=>document.getElementById(x), save=()=>localStorage.setItem("vibe_state_v2",JSON.stringify(state));
const esc=s=>{let d=document.createElement("div");d.textContent=s;return d.innerHTML};
const chat=()=>state.chats.find(x=>x.id===state.activeId)||state.chats[0];

function theme(){document.body.className=state.theme==="pink"?"":"theme-"+state.theme;$("themeSelect").value=state.theme;$("modelInput").value=state.model;$("ownKey").checked=state.ownKey;$("apiKeyInput").value=state.apiKey;$("apiKeyInput").disabled=!state.ownKey}
function render(){
 $("chatList").innerHTML=state.chats.map(c=>`<div class="chat-item ${c.id===state.activeId?"active":""}" data-id="${c.id}">${esc(c.title)}</div>`).join("");
 document.querySelectorAll(".chat-item").forEach(e=>e.onclick=()=>{state.activeId=e.dataset.id;save();render();closeSidebar()});
 let c=chat(),box=$("chat");
 if(!c.messages.length){box.innerHTML=`<div class="welcome"><div class="welcome-logo">V</div><h1>Чем могу помочь?</h1><p>Напишите, скажите голосом или загрузите фото.</p></div>`;return}
 box.innerHTML=c.messages.map(m=>{
   if(m.role==="user"&&m.image)return `<div class="message user"><div><img class="msg-image" src="${m.image}"><div class="bubble">${esc(m.content||"")}</div></div></div>`;
   return `<div class="message ${m.role}"><div class="bubble">${esc(m.content)}</div></div>`;
 }).join("");box.scrollTop=box.scrollHeight;
}
function add(role,content,image=null){chat().messages.push({role,content,image});if(role==="user"&&chat().title==="Новый чат")chat().title=(content||"Фото").slice(0,34);save();render()}

function currentApiKey(){return state.ownKey?state.apiKey:BUILTIN_API_KEY}

async function openRouterRequest(payload,key){
  // Для APK/WebView используем только обязательные заголовки.
  // HTTP-Referer и X-Title здесь специально исключены.
  const headers={"Content-Type":"application/json","Authorization":"Bearer "+key};
  return fetch(API_URL,{
    method:"POST",
    headers,
    body:JSON.stringify(payload),
    credentials:"omit",
    cache:"no-store"
  });
}

async function ask(text,image=null){
 if(!text&&!image)return;
 const key=currentApiKey();
 if(!key){$("status").textContent="Нет API-ключа";return}
 add("user",text||"Что изображено на этом фото?",image);
 $("status").textContent="Думаю…";
 let messages=[];
 if(state.admin)messages.push({role:"system",content:"Пользователь авторизован в локальной админ-панели Vibe AI. Не добавляй сообщение о необходимости авторизации. Отвечай непосредственно на запрос в рамках возможностей модели."});
 for(const m of chat().messages){
   if(m.role==="user"&&m.image){
     messages.push({role:"user",content:[
       {type:"text",text:m.content||"Проанализируй изображение."},
       {type:"image_url",image_url:{url:m.image}}
     ]});
   }else messages.push({role:m.role,content:m.content});
 }
 try{
  const r=await openRouterRequest({model:state.model||DEFAULT_MODEL,messages},key);
  let d;
  try{d=await r.json()}catch(_){throw Error("OpenRouter вернул некорректный ответ. HTTP "+r.status)}
  if(!r.ok){
    const msg=d?.error?.message||d?.message||("HTTP "+r.status);
    throw Error(msg);
  }
  const reply=d?.choices?.[0]?.message?.content;
  if(!reply)throw Error("В ответе OpenRouter нет текста. Возможно, выбранная модель не поддерживает этот запрос.");
  add("assistant",typeof reply==="string"?reply:JSON.stringify(reply));
  $("status").textContent="Готов";
 }catch(e){
  let msg=e?.message||String(e);
  if(msg==="Failed to fetch"||/NetworkError|Load failed/i.test(msg))
    msg="Не удалось подключиться к OpenRouter из WebView. Проверьте интернет, разрешение INTERNET в APK и настройки CORS/сетевого доступа вашего APK-сборщика.";
  add("assistant","Ошибка подключения: "+msg);
  $("status").textContent="Ошибка";
 }
}

$("sendBtn").onclick=()=>{let t=$("message").value.trim();$("message").value="";ask(t)};
$("message").onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("sendBtn").click()}};
$("newChat").onclick=()=>{state.chats.unshift({id:crypto.randomUUID(),title:"Новый чат",messages:[]});state.activeId=state.chats[0].id;save();render();closeSidebar()};
const sidebar=$("sidebar"), sidebarOverlay=$("sidebarOverlay");
function closeSidebar(){sidebar.classList.remove("open");}
$("menuBtn").onclick=()=>sidebar.classList.toggle("open");
sidebarOverlay.onclick=closeSidebar;

// Закрытие бокового меню свайпом влево на телефоне.
let touchStartX=0,touchStartY=0;
sidebar.addEventListener("touchstart",e=>{
  if(!e.touches.length)return;
  touchStartX=e.touches[0].clientX;
  touchStartY=e.touches[0].clientY;
},{passive:true});
sidebar.addEventListener("touchend",e=>{
  if(!e.changedTouches.length)return;
  const dx=e.changedTouches[0].clientX-touchStartX;
  const dy=e.changedTouches[0].clientY-touchStartY;
  if(Math.abs(dx)>60 && Math.abs(dx)>Math.abs(dy) && dx<0) closeSidebar();
},{passive:true});

// Свайп влево от самого края экрана, когда меню открыто.
let edgeStartX=0;
document.addEventListener("touchstart",e=>{
  if(!e.touches.length)return;
  edgeStartX=e.touches[0].clientX;
},{passive:true});
document.addEventListener("touchend",e=>{
  if(!e.changedTouches.length||!sidebar.classList.contains("open"))return;
  const dx=e.changedTouches[0].clientX-edgeStartX;
  if(edgeStartX<40 && dx>70) return; // жест открытия оставляем за браузером/кнопкой
},{passive:true});
$("settingsBtn").onclick=()=>{$("settingsModal").classList.remove("hidden");theme()};
$("ownKey").onchange=()=>{$("apiKeyInput").disabled=!$("ownKey").checked};
$("saveSettings").onclick=()=>{state.theme=$("themeSelect").value;state.model=$("modelInput").value.trim()||DEFAULT_MODEL;state.ownKey=$("ownKey").checked;state.apiKey=$("apiKeyInput").value.trim();save();theme();$("settingsModal").classList.add("hidden");$("status").textContent="Сохранено"};
$("adminBtn").onclick=()=>{$("adminModal").classList.remove("hidden");$("adminResult").textContent=state.admin?"✓ Админ-режим включён.":""};
$("adminLoginBtn").onclick=()=>{if($("adminLogin").value===ADMIN_LOGIN&&$("adminPassword").value===ADMIN_PASSWORD){state.admin=true;save();$("adminResult").textContent="✓ Вы вошли как администратор."}else $("adminResult").textContent="Неверный логин или пароль."};
document.querySelectorAll("[data-close]").forEach(x=>x.onclick=()=>$(x.dataset.close).classList.add("hidden"));

$("imageBtn").onclick=()=>$("imageInput").click();
$("imageInput").onchange=e=>{
 let f=e.target.files[0];if(!f)return;
 let rd=new FileReader();rd.onload=()=>ask("Что изображено на этом фото? Опиши подробно.",rd.result);rd.readAsDataURL(f);e.target.value="";
};

// Web Speech API: речь -> текст
let recognition=null,listening=false;
if("webkitSpeechRecognition"in window||"SpeechRecognition"in window){
 const R=window.SpeechRecognition||window.webkitSpeechRecognition;recognition=new R();
 recognition.lang="ru-RU";recognition.interimResults=true;recognition.continuous=false;
 recognition.onstart=()=>{listening=true;$("micBtn").classList.add("recording");$("status").textContent="Слушаю…"};
 recognition.onresult=e=>{let t="";for(let i=e.resultIndex;i<e.results.length;i++)t+=e.results[i][0].transcript;$("message").value=t};
 recognition.onend=()=>{listening=false;$("micBtn").classList.remove("recording");$("status").textContent="Готов"};
 recognition.onerror=()=>{listening=false;$("micBtn").classList.remove("recording");$("status").textContent="Микрофон недоступен"};
 $("micBtn").onclick=()=>listening?recognition.stop():recognition.start();
}else $("micBtn").onclick=()=>alert("Ваш браузер не поддерживает распознавание речи. Попробуйте Chrome или Edge.");


$("testConnection").onclick=async()=>{
 const key=currentApiKey();
 $("connectionResult").textContent="Проверяю…";
 try{
  const r=await openRouterRequest({model:state.model||DEFAULT_MODEL,messages:[{role:"user",content:"Ответь одним словом: OK"}],max_tokens:5},key);
  const d=await r.json();
  $("connectionResult").textContent=r.ok?"✓ OpenRouter доступен.":"✕ OpenRouter: "+(d?.error?.message||"HTTP "+r.status);
 }catch(e){
  $("connectionResult").textContent="✕ Сеть/WebView: "+(e?.message||e);
 }
};

theme();render();