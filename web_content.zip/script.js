(() => {
  'use strict';
  const STORAGE_KEY = 'lifepilot.phase1.v1';
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const today = () => localDateKey(new Date());
  const localDateKey = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
  const parseDate = value => { const [y,m,d] = value.split('-').map(Number); return new Date(y,m-1,d); };
  const emptyData = () => ({version:1,tasks:[],habits:[],sessions:[],sleepEntries:[],settings:{gamingLimit:120,bedtime:'22:30',wakeTime:'07:00',winddown:''},timer:null});
  let storageFailed = false;
  let data = loadData();
  let editingTaskId = null;
  let editingHabitId = null;
  let toastHandle;
  let timerInterval;

  function loadData(){
    try { const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)); return saved && saved.version === 1 ? {...emptyData(),...saved,settings:{...emptyData().settings,...saved.settings}} : emptyData(); }
    catch(error){ storageFailed=true; console.warn('LifePilot data could not be read:', error); return emptyData(); }
  }
  function saveData(){
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); storageFailed=false; return true; }
    catch(error){ storageFailed=true; console.error('LifePilot data could not be saved:', error); showToast('Could not save. Browser storage may be full or disabled.'); return false; }
  }
  function showToast(message){ if(storageFailed)message='Changes could not be saved to browser storage.'; const node=document.getElementById('toast'); node.textContent=message; node.classList.add('show'); clearTimeout(toastHandle); toastHandle=setTimeout(()=>node.classList.remove('show'),2800); }
  function escapeText(value){ return String(value ?? '').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
  function formatDate(value, options={weekday:'short',month:'short',day:'numeric'}){ if(!value)return ''; return new Intl.DateTimeFormat(undefined,options).format(parseDate(value)); }
  function isDue(task, date=today()){
    if(task.repeat==='none') return task.date===date;
    if(date<task.date) return false;
    const weekday=parseDate(date).getDay();
    if(task.repeat==='daily') return true;
    if(task.repeat==='weekly') return weekday===parseDate(task.date).getDay();
    if(task.repeat==='custom') return Array.isArray(task.days) && task.days.includes(weekday);
    return false;
  }
  function taskIsDone(task,date=today()){ return Boolean(task.completions && task.completions[date]); }
  function activeTasks(date=today()){ return data.tasks.filter(task=>isDue(task,date)).sort((a,b)=>(a.order||0)-(b.order||0)||(a.time||'99:99').localeCompare(b.time||'99:99')); }
  function currentDateTime(){
    const now=new Date();
    document.getElementById('dateLabel').textContent=new Intl.DateTimeFormat(undefined,{weekday:'long',month:'long',day:'numeric',year:'numeric'}).format(now).toUpperCase();
    document.getElementById('routineDayLabel').textContent=formatDate(today(),{weekday:'long',month:'long',day:'numeric'});
  }
  function taskMarkup(task, controls=false){
    const done=taskIsDone(task);
    const meta=[task.repeat==='none'?'':task.repeat==='daily'?'Daily':task.repeat==='weekly'?'Weekly':task.repeat==='custom'?'Custom days':'',task.priority&&task.priority!=='normal'?`<span class="priority ${escapeText(task.priority)}">${escapeText(task.priority)}</span>`:''].filter(Boolean).join(' · ');
    return `<article class="task-item" data-task-id="${escapeText(task.id)}"><div class="task-row"><input class="task-check" type="checkbox" aria-label="Mark ${escapeText(task.title)} ${done?'not complete':'complete'}" ${done?'checked':''} data-task-action="toggle"><div class="task-info"><span class="task-title ${done?'done':''}">${escapeText(task.title)}</span><span class="task-meta">${escapeText(task.category||'Personal')}${meta?` · ${meta}`:''}</span></div>${task.time?`<span class="task-time">${escapeText(task.time)}</span>`:''}${controls?`<div class="task-buttons"><button class="icon-button" type="button" data-task-action="up" aria-label="Move ${escapeText(task.title)} earlier">↑</button><button class="icon-button" type="button" data-task-action="down" aria-label="Move ${escapeText(task.title)} later">↓</button><button class="icon-button" type="button" data-task-action="edit" aria-label="Edit ${escapeText(task.title)}">✎</button><button class="icon-button delete" type="button" data-task-action="delete" aria-label="Delete ${escapeText(task.title)}">×</button></div>`:''}</div>${controls&&task.notes?`<p class="task-notes">${escapeText(task.notes)}</p>`:''}</article>`;
  }
  function renderDashboard(){
    const tasks=activeTasks(); const completed=tasks.filter(t=>taskIsDone(t)).length; const left=tasks.length-completed; const percentage=tasks.length?Math.round(completed/tasks.length*100):0;
    document.getElementById('progressBar').style.width=`${percentage}%`; document.getElementById('progressPercent').textContent=`${percentage}%`; document.getElementById('doneCount').textContent=`${completed} completed`; document.getElementById('remainingCount').textContent=`${left} remaining`; document.getElementById('todayCount').textContent=String(tasks.length);
    document.getElementById('progressTitle').textContent=tasks.length?'Your daily progress':'Start with one small step';
    const overdue=data.tasks.filter(t=>t.repeat==='none'&&t.date<today()&&!taskIsDone(t,t.date)).length; document.getElementById('overdueCount').textContent=String(overdue);
    const display=tasks.slice(0,4); document.getElementById('dashboardTasks').innerHTML=display.length?display.map(t=>`<div class="task-row"><input class="task-check" type="checkbox" aria-label="Mark ${escapeText(t.title)} ${taskIsDone(t)?'not complete':'complete'}" data-dashboard-toggle="${escapeText(t.id)}" ${taskIsDone(t)?'checked':''}><div class="task-info"><span class="task-title ${taskIsDone(t)?'done':''}">${escapeText(t.title)}</span><span class="task-meta">${escapeText(t.category||'Personal')}</span></div>${t.time?`<span class="task-time">${escapeText(t.time)}</span>`:''}<span class="task-category">${escapeText(t.category||'Personal')}</span></div>`).join(''):`<div class="empty-inline">No tasks planned for today. Add one if it would help.</div>`;
    const upcoming=tasks.find(t=>!taskIsDone(t)&&t.time&&t.time>=new Date().toTimeString().slice(0,5)); const next=document.getElementById('nextTask'); const detail=document.getElementById('nextTaskDetail');
    if(upcoming){next.textContent=upcoming.title;detail.textContent=`${upcoming.time} · ${upcoming.category||'Personal'}`;}else{next.textContent=tasks.length?'No timed task coming up':'Nothing scheduled yet';detail.textContent=tasks.length?'You can add a time to a task whenever it helps.':'Add a task with a time to see it here.';}
  }
  function renderTasks(){
    const tasks=activeTasks(); document.getElementById('routineTasks').innerHTML=tasks.map(t=>taskMarkup(t,true)).join('');
    document.getElementById('routineEmpty').classList.toggle('hidden',tasks.length>0);
    document.getElementById('routineSummaryCount').textContent=`${tasks.length} ${tasks.length===1?'task':'tasks'} planned · ${tasks.filter(taskIsDone).length} complete`;
    const overdue=data.tasks.filter(t=>t.repeat==='none'&&t.date<today()&&!taskIsDone(t,t.date)).sort((a,b)=>a.date.localeCompare(b.date));
    document.getElementById('overdueTasks').innerHTML=overdue.map(task=>`<article class="task-item" data-task-id="${escapeText(task.id)}"><div class="task-row"><div class="task-info"><span class="task-title">${escapeText(task.title)}</span><span class="task-meta">${escapeText(task.category||'Personal')} · Was planned ${escapeText(formatDate(task.date))}</span></div><button class="secondary-button" type="button" data-task-action="reschedule" style="padding:7px 10px;font-size:10px">Move to today</button><button class="icon-button" type="button" data-task-action="delete" aria-label="Delete ${escapeText(task.title)}">×</button></div></article>`).join('');
    document.getElementById('noOverdue').classList.toggle('hidden',overdue.length>0);
  }
  function renderHabits(){
    const root=document.getElementById('habitLog'); const logs=[...data.habits].sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
    document.getElementById('habitCount').textContent=`${logs.length} ${logs.length===1?'entry':'entries'}`; document.getElementById('habitEmpty').classList.toggle('hidden',logs.length>0);
    root.innerHTML=logs.map(item=>`<article class="log-card"><button class="icon-button delete" type="button" data-habit-delete="${escapeText(item.id)}" aria-label="Delete check-in from ${escapeText(formatDate(item.date))}">×</button><button class="icon-button" type="button" data-habit-edit="${escapeText(item.id)}" aria-label="Edit check-in from ${escapeText(formatDate(item.date))}">✎</button><span class="log-date">${escapeText(formatDate(item.date,{weekday:'short',month:'short',day:'numeric',year:'numeric'}))}</span>${item.trigger?`<p><strong>Situation:</strong> ${escapeText(item.trigger)}</p>`:''}${item.alternative?`<p><strong>Tried:</strong> ${escapeText(item.alternative)}</p>`:''}${item.reflection?`<p>${escapeText(item.reflection)}</p>`:''}${!item.trigger&&!item.alternative&&!item.reflection?'<p>Check-in saved — no details recorded.</p>':''}</article>`).join('');
  }
  function renderSleep(){
    document.getElementById('bedtimeInput').value=data.settings.bedtime||'';document.getElementById('wakeInput').value=data.settings.wakeTime||'';document.getElementById('winddownInput').value=data.settings.winddown||'';
    const logs=[...data.sleepEntries].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,14);document.getElementById('sleepLogEmpty').classList.toggle('hidden',logs.length>0);
    document.getElementById('sleepLog').innerHTML=logs.map(item=>`<article class="sleep-log-card"><strong>${escapeText(formatDate(item.date,{weekday:'short',month:'short',day:'numeric'}))}${item.quality?` · ${escapeText(item.quality)}`:''}</strong>${item.energy?`<p>Energy: ${escapeText(item.energy)}</p>`:''}${item.note?`<p>${escapeText(item.note)}</p>`:''}</article>`).join('');
  }
  function elapsedMs(timer){return timer.elapsedMs+(timer.running?Math.max(0,Date.now()-timer.startedAt):0);}
  function formatClock(ms){const seconds=Math.max(0,Math.floor(ms/1000));return `${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;}
  function gameMinutesToday(){const saved=data.sessions.filter(s=>s.kind==='game'&&s.date===today()).reduce((sum,s)=>sum+s.durationMs,0);const active=data.timer&&data.timer.kind==='game'&&data.timer.date===today()?elapsedMs(data.timer):0;return saved+active;}
  function renderTimers(){
    const timer=data.timer;const focus=timer?.kind==='focus';const game=timer?.kind==='game';const focusInput=document.getElementById('focusDuration');const gameInput=document.getElementById('gamingLimit');
    if(!timer){document.getElementById('focusDisplay').textContent=`${String(Number(focusInput.value)||25).padStart(2,'0')}:00`;document.getElementById('gameDisplay').textContent='00:00';document.getElementById('focusStatus').textContent='Ready when you are';document.getElementById('gameStatus').textContent='No session running';}
    else if(focus){const remain=Math.max(0,timer.limitMs-elapsedMs(timer));document.getElementById('focusDisplay').textContent=formatClock(remain);document.getElementById('focusStatus').textContent=timer.running?'Session in progress':`Paused · ${formatClock(remain)} left`;}
    else{document.getElementById('gameDisplay').textContent=formatClock(elapsedMs(timer));document.getElementById('gameStatus').textContent=timer.warned?'Daily limit reached — pause or finish when you choose.':(timer.running?'Session in progress':`Paused · ${formatClock(elapsedMs(timer))} elapsed`);}
    for(const [kind,isCurrent] of [['focus',focus],['game',game]]){
      const prefix=kind==='focus'?'focus':'game';document.getElementById(`${prefix}Start`).classList.toggle('hidden',Boolean(timer));document.getElementById(`${prefix}Pause`).classList.toggle('hidden',!isCurrent||!timer.running);document.getElementById(`${prefix}Resume`).classList.toggle('hidden',!isCurrent||timer.running);document.getElementById(`${prefix}Stop`).classList.toggle('hidden',!isCurrent);
    }
    focusInput.disabled=Boolean(timer);gameInput.disabled=Boolean(timer);
    const limit=Math.max(1,Number(data.settings.gamingLimit)||120);gameInput.value=limit;const used=gameMinutesToday();document.getElementById('gamingToday').textContent=`${Math.floor(used/60000)} min`;document.getElementById('gamingBar').style.width=`${Math.min(100,used/(limit*60000)*100)}%`;
    const sessions=[...data.sessions].sort((a,b)=>b.endedAt-a.endedAt).slice(0,6);document.getElementById('sessionEmpty').classList.toggle('hidden',sessions.length>0);
    document.getElementById('sessionList').innerHTML=sessions.map(s=>`<div class="session-row"><span>${s.kind==='focus'?'◎ Focus':'◈ Gaming'} · ${escapeText(formatDate(s.date,{month:'short',day:'numeric'}))}</span><small>${escapeText(formatClock(s.durationMs))}</small></div>`).join('');
  }
  function renderAll(){currentDateTime();renderDashboard();renderTasks();renderHabits();renderSleep();renderTimers();}
  function navigate(view){
    if(!document.getElementById(`view-${view}`))return;
    document.querySelectorAll('.view').forEach(el=>el.classList.toggle('active',el.id===`view-${view}`));
    document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===view));
    window.scrollTo({top:0,behavior:'smooth'});
  }
  function clearTaskForm(){editingTaskId=null;document.getElementById('taskForm').reset();document.getElementById('taskDate').value=today();document.getElementById('customCategoryLabel').classList.add('hidden');document.getElementById('taskFormTitle').textContent='Create a task';document.getElementById('formMode').textContent='ADD TO YOUR PLAN';document.getElementById('saveTaskBtn').textContent='Add task';document.getElementById('cancelEdit').classList.add('hidden');document.getElementById('weekdayField').classList.remove('show');}
  function beginEdit(task){
    editingTaskId=task.id;document.getElementById('taskTitle').value=task.title;document.getElementById('taskNotes').value=task.notes||'';const knownCategories=['Personal','Prayer','Quran','Study','Work','Exercise','Sleep','Gaming','Personal development'];const isCustom=!knownCategories.includes(task.category);document.getElementById('taskCategory').value=isCustom?'Custom':(task.category||'Personal');document.getElementById('customCategory').value=isCustom?task.category:'';document.getElementById('customCategoryLabel').classList.toggle('hidden',!isCustom);document.getElementById('taskPriority').value=task.priority||'normal';document.getElementById('taskDate').value=task.date;document.getElementById('taskTime').value=task.time||'';document.getElementById('taskRepeat').value=task.repeat||'none';
    document.querySelectorAll('#weekdayOptions input').forEach(input=>input.checked=(task.days||[]).includes(Number(input.value)));document.getElementById('weekdayField').classList.toggle('show',task.repeat==='custom');document.getElementById('taskFormTitle').textContent='Edit task';document.getElementById('formMode').textContent='UPDATE YOUR PLAN';document.getElementById('saveTaskBtn').textContent='Save changes';document.getElementById('cancelEdit').classList.remove('hidden');document.getElementById('taskTitle').focus();document.getElementById('taskForm').scrollIntoView({behavior:'smooth',block:'start'});
  }
  function toggleTask(id){const task=data.tasks.find(t=>t.id===id);if(!task)return;task.completions=task.completions||{};task.completions[today()]=!task.completions[today()];saveData();renderAll();}
  function handleTaskAction(event){
    const item=event.target.closest('[data-task-id]');
    if(event.target.matches('.task-check')){if(event.type!=='change')return;const checkbox=event.target;const task=data.tasks.find(t=>t.id===item?.dataset.taskId);if(!task)return;task.completions=task.completions||{};task.completions[today()]=checkbox.checked;saveData();renderAll();return;}
    const button=event.target.closest('[data-task-action]');if(!button)return;const task=data.tasks.find(t=>t.id===item?.dataset.taskId);if(!task)return;const action=button.dataset.taskAction;
    if(action==='toggle'){task.completions=task.completions||{};task.completions[today()]=button.checked;saveData();renderAll();return;}
    if(action==='edit'){beginEdit(task);return;}
    if(action==='delete'){if(!window.confirm(`Delete “${task.title}” and its completion history?`))return;data.tasks=data.tasks.filter(t=>t.id!==task.id);if(editingTaskId===task.id)clearTaskForm();saveData();renderAll();showToast('Task deleted.');return;}
    if(action==='reschedule'){task.date=today();task.completions=task.completions||{};saveData();renderAll();showToast('Moved to today. Your plan is refreshed.');return;}
    if(action==='up'||action==='down'){
      const due=activeTasks();const index=due.findIndex(t=>t.id===task.id);const other=due[index+(action==='up'?-1:1)];if(!other)return;
      const left=Number(task.order)||0,right=Number(other.order)||0;task.order=right;other.order=left;if(task.order===other.order){task.order=Date.now();other.order=task.order-1;}saveData();renderAll();
    }
  }
  function startTimer(kind){
    if(data.timer){showToast('Finish the current session before starting another.');return;}
    const minutes=kind==='focus'?Math.min(240,Math.max(1,Number(document.getElementById('focusDuration').value)||25)):0;
    data.timer={kind,startedAt:Date.now(),elapsedMs:0,running:true,limitMs:minutes*60000,date:today()};saveData();renderTimers();
  }
  function pauseTimer(){if(!data.timer||!data.timer.running)return;data.timer.elapsedMs=elapsedMs(data.timer);data.timer.running=false;saveData();renderTimers();}
  function resumeTimer(){if(!data.timer||data.timer.running)return;data.timer.startedAt=Date.now();data.timer.running=true;saveData();renderTimers();}
  function stopTimer(){
    if(!data.timer)return;const timer=data.timer;const duration=elapsedMs(timer);
    if(duration>0)data.sessions.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),kind:timer.kind,date:timer.date,durationMs:duration,endedAt:Date.now()});
    data.timer=null;saveData();renderTimers();showToast(duration?'Session saved.':'Session ended.');
  }
  function tickTimer(){
    if(data.timer?.running){
      if(data.timer.kind==='focus'&&elapsedMs(data.timer)>=data.timer.limitMs){const timer=data.timer;data.sessions.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),kind:timer.kind,date:timer.date,durationMs:timer.limitMs,endedAt:Date.now()});data.timer=null;saveData();renderTimers();showToast('Focus time reached. Your session was saved.');return;}
      renderTimers();
      const limit=Number(data.settings.gamingLimit)||120;if(data.timer.kind==='game'&&gameMinutesToday()>=limit*60000&&!data.timer.warned){data.timer.warned=true;saveData();document.getElementById('gameStatus').textContent='Your daily limit is reached — pause or finish when you choose.';showToast('Your chosen gaming limit is reached. You are in control of what happens next.');}
    }
  }
  function coachReply(message){
    const text=message.toLowerCase();
    if(/sleep|bed|tired|scroll/.test(text))return 'Try one small wind-down cue tonight: put your phone out of reach, dim the room, and choose a calm activity for ten minutes. A regular schedule can help, but a difficult night is not a failure.';
    if(/stress|angry|anger|irritat|overwhelm/.test(text))return 'Pause before solving everything: step away if it is safe, take a few slow breaths, and name the one thing that needs attention first. If you feel at risk of harming yourself or someone else, reach a trusted person or local emergency support now.';
    if(/game|gaming|pubg|play/.test(text))return 'Before starting, choose an end time and one activity to do afterward. A timer here only tracks a session you start in LifePilot; it cannot see or stop another game.';
    if(/procrast|focus|study|work|motivat|habit/.test(text))return 'Make the first step smaller: choose one task you can start in five minutes, put away one distraction, and focus only until your next short break. You can adjust the plan afterward.';
    if(/urdu|roman/.test(text))return 'Chhota qadam choose karein: aglay 5 minute mein sirf ek kaam shuru karein, phone ko door rakhein, phir break lein. Plan badalna bilkul theek hai.';
    return 'Let’s make it concrete: what is one small action you could take in the next ten minutes? Keep it realistic, and give yourself permission to adjust the plan.';
  }
  function appendChat(text,kind){const message=document.createElement('div');message.className=`chat-message ${kind}`;message.textContent=text;const area=document.getElementById('chatArea');area.appendChild(message);area.scrollTop=area.scrollHeight;}
  function exportData(){
    const blob=new Blob([JSON.stringify({...data,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download=`lifepilot-backup-${today()}.json`;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(link.href),1000);showToast('Your local backup was downloaded.');
  }
  function resetData(){if(!window.confirm('Permanently delete all LifePilot data saved in this browser? Consider exporting a backup first.'))return;localStorage.removeItem(STORAGE_KEY);data=emptyData();clearTaskForm();renderAll();showToast('Local LifePilot data was reset.');}

  document.querySelectorAll('[data-view]').forEach(button=>button.addEventListener('click',()=>navigate(button.dataset.view)));
  document.querySelectorAll('[data-action="add-task"]').forEach(button=>button.addEventListener('click',()=>{navigate('routine');document.getElementById('taskTitle').focus();}));
  document.getElementById('weekdayOptions').innerHTML=dayNames.map((name,index)=>`<label class="day-option"><input type="checkbox" value="${index}"> ${name}</label>`).join('');
  document.getElementById('taskDate').value=today();
  document.getElementById('taskRepeat').addEventListener('change',event=>document.getElementById('weekdayField').classList.toggle('show',event.target.value==='custom'));
  document.getElementById('taskCategory').addEventListener('change',event=>document.getElementById('customCategoryLabel').classList.toggle('hidden',event.target.value!=='Custom'));
  document.getElementById('cancelEdit').addEventListener('click',clearTaskForm);
  document.getElementById('taskForm').addEventListener('submit',event=>{
    event.preventDefault();const title=document.getElementById('taskTitle').value.trim();if(!title){showToast('Add a task title first.');return;}
    const repeat=document.getElementById('taskRepeat').value;const days=[...document.querySelectorAll('#weekdayOptions input:checked')].map(input=>Number(input.value));if(repeat==='custom'&&!days.length){showToast('Choose at least one repeat day.');return;}const selectedCategory=document.getElementById('taskCategory').value;const category=selectedCategory==='Custom'?document.getElementById('customCategory').value.trim():selectedCategory;if(selectedCategory==='Custom'&&!category){showToast('Enter a name for your custom category.');return;}
    const previous=editingTaskId?data.tasks.find(t=>t.id===editingTaskId):null;const task={id:previous?.id||(`task-${Date.now()}-${Math.random().toString(36).slice(2,7)}`),title,notes:document.getElementById('taskNotes').value.trim(),category,priority:document.getElementById('taskPriority').value,date:document.getElementById('taskDate').value,time:document.getElementById('taskTime').value,repeat,days:repeat==='custom'?days:[],order:previous?.order??Date.now(),completions:previous?.completions||{}};
    if(previous)data.tasks=data.tasks.map(t=>t.id===previous.id?task:t);else data.tasks.push(task);saveData();clearTaskForm();renderAll();showToast(previous?'Task updated.':'Task added to your plan.');
  });
  document.getElementById('routineTasks').addEventListener('click',handleTaskAction);document.getElementById('routineTasks').addEventListener('change',handleTaskAction);document.getElementById('overdueTasks').addEventListener('click',handleTaskAction);
  document.getElementById('dashboardTasks').addEventListener('change',event=>{const id=event.target.dataset.dashboardToggle;if(id)toggleTask(id);});
  document.getElementById('habitForm').addEventListener('submit',event=>{event.preventDefault();const values={trigger:document.getElementById('habitTrigger').value.trim(),alternative:document.getElementById('habitAlternative').value.trim(),reflection:document.getElementById('habitReflection').value.trim()};if(editingHabitId){data.habits=data.habits.map(item=>item.id===editingHabitId?{...item,...values}:item);}else{data.habits.push({id:`habit-${Date.now()}`,date:today(),createdAt:new Date().toISOString(),...values});}editingHabitId=null;event.target.reset();document.getElementById('habitSaveButton').textContent='Save private check-in';document.getElementById('habitCancelEdit').classList.add('hidden');saveData();renderHabits();const saved=document.getElementById('habitSaved');saved.textContent=storageFailed?'Could not save in this browser; it may be lost when closed.':'Saved privately on this device.';setTimeout(()=>saved.textContent='',3500);});
  document.getElementById('habitCancelEdit').addEventListener('click',()=>{editingHabitId=null;document.getElementById('habitForm').reset();document.getElementById('habitSaveButton').textContent='Save private check-in';document.getElementById('habitCancelEdit').classList.add('hidden');});
  document.getElementById('habitLog').addEventListener('click',event=>{const edit=event.target.closest('[data-habit-edit]');if(edit){const item=data.habits.find(entry=>entry.id===edit.dataset.habitEdit);if(!item)return;editingHabitId=item.id;document.getElementById('habitTrigger').value=item.trigger||'';document.getElementById('habitAlternative').value=item.alternative||'';document.getElementById('habitReflection').value=item.reflection||'';document.getElementById('habitSaveButton').textContent='Update check-in';document.getElementById('habitCancelEdit').classList.remove('hidden');document.getElementById('habitForm').scrollIntoView({behavior:'smooth',block:'start'});return;}const button=event.target.closest('[data-habit-delete]');if(!button)return;data.habits=data.habits.filter(item=>item.id!==button.dataset.habitDelete);saveData();renderHabits();showToast('Check-in deleted.');});
  document.getElementById('gamingLimit').addEventListener('change',event=>{data.settings.gamingLimit=Math.min(1440,Math.max(1,Number(event.target.value)||120));saveData();renderTimers();});
  document.getElementById('focusDuration').addEventListener('input',()=>{if(!data.timer)renderTimers();});
  document.getElementById('focusStart').addEventListener('click',()=>startTimer('focus'));document.getElementById('gameStart').addEventListener('click',()=>startTimer('game'));
  document.getElementById('focusPause').addEventListener('click',pauseTimer);document.getElementById('gamePause').addEventListener('click',pauseTimer);document.getElementById('focusResume').addEventListener('click',resumeTimer);document.getElementById('gameResume').addEventListener('click',resumeTimer);document.getElementById('focusStop').addEventListener('click',stopTimer);document.getElementById('gameStop').addEventListener('click',stopTimer);
  document.getElementById('sleepForm').addEventListener('submit',event=>{event.preventDefault();data.settings.bedtime=document.getElementById('bedtimeInput').value;data.settings.wakeTime=document.getElementById('wakeInput').value;data.settings.winddown=document.getElementById('winddownInput').value.trim();saveData();document.getElementById('sleepSaved').textContent=storageFailed?'Could not save in this browser; it may be lost when closed.':'Preferences saved on this device.';setTimeout(()=>document.getElementById('sleepSaved').textContent='',3500);});
  document.getElementById('sleepDiaryForm').addEventListener('submit',event=>{event.preventDefault();const quality=document.getElementById('sleepQuality').value;const energy=document.getElementById('sleepEnergy').value;const note=document.getElementById('sleepNote').value.trim();if(!quality&&!energy&&!note){showToast('Add at least one sleep detail to save.');return;}const entry={date:today(),quality,energy,note};const existing=data.sleepEntries.findIndex(item=>item.date===today());if(existing>=0)data.sleepEntries[existing]=entry;else data.sleepEntries.push(entry);saveData();renderSleep();event.target.reset();document.getElementById('sleepDiarySaved').textContent=storageFailed?'Could not save in this browser; it may be lost when closed.':'Sleep note saved.';setTimeout(()=>document.getElementById('sleepDiarySaved').textContent='',3500);});
  document.getElementById('coachForm').addEventListener('submit',event=>{event.preventDefault();const input=document.getElementById('coachInput');const message=input.value.trim();if(!message)return;appendChat(message,'user');appendChat(coachReply(message),'assistant');input.value='';});
  document.querySelectorAll('[data-prompt]').forEach(button=>button.addEventListener('click',()=>{document.getElementById('coachInput').value=button.dataset.prompt;document.getElementById('coachInput').focus();}));
  document.getElementById('exportBtn').addEventListener('click',exportData);document.getElementById('resetBtn').addEventListener('click',resetData);
  document.getElementById('taskForm').addEventListener('keydown',event=>{if(event.key==='Escape'&&editingTaskId)clearTaskForm();});
  document.getElementById('bedtimeInput').value=data.settings.bedtime;document.getElementById('wakeInput').value=data.settings.wakeTime;document.getElementById('winddownInput').value=data.settings.winddown;
  renderAll();timerInterval=setInterval(tickTimer,1000);
})();
