class SoundFX {
    constructor() {
        this.ctx = null;
        this.enabled = true;

        this.clickSound = new Audio("sounds/jump-sound.wav");
        this.victorySound = new Audio("sounds/win-sound2.wav");
        this.actionSound = new Audio("sounds/handgun-click.mp3");

        this.clickSound.preload = "auto";
        this.victorySound.preload = "auto";
        this.actionSound.preload = "auto";
    }

    init() {
        if (this.ctx) return;

        const AudioContext = window.AudioContext || window.webkitAudioContext;

        if (AudioContext) {
            this.ctx = new AudioContext();
        }
    }

    playSlide() {
        if (!this.enabled) return;

        if (this.playFile(this.clickSound)) return;

        this.init();

        if (!this.ctx) return;

        const oscillator = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const now = this.ctx.currentTime;

        oscillator.type = "sine";
        oscillator.frequency.setValueAtTime(220, now);
        oscillator.frequency.exponentialRampToValueAtTime(110, now + 0.08);

        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.08);

        oscillator.connect(gain);
        gain.connect(this.ctx.destination);

        oscillator.start(now);
        oscillator.stop(now + 0.08);
    }

    playWin() {
        if (!this.enabled) return;

        if (this.playFile(this.victorySound)) return;

        this.init();

        if (!this.ctx) return;

        const notes = [261.63, 329.63, 392, 523.25];
        const now = this.ctx.currentTime;

        notes.forEach((frequency, index) => {
            const oscillator = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const startTime = now + index * 0.1;

            oscillator.type = "triangle";
            oscillator.frequency.setValueAtTime(frequency, startTime);

            gain.gain.setValueAtTime(0.2, startTime);
            gain.gain.exponentialRampToValueAtTime(
                0.001,
                startTime + 0.3
            );

            oscillator.connect(gain);
            gain.connect(this.ctx.destination);

            oscillator.start(startTime);
            oscillator.stop(startTime + 0.3);
        });
    }

    playAction() {
        if (!this.enabled) return;

        this.playFile(this.actionSound);
    }

    playFile(sound) {
        if (!sound || !sound.src || sound.readyState < 2) {
            return false;
        }

        sound.currentTime = 0;
        sound.play().catch(() => {});

        return true;
    }
}

const audio = new SoundFX();


class BackgroundParticles {
    constructor() {
        this.canvas = document.getElementById("bg-canvas");
        this.ctx = this.canvas.getContext("2d");
        this.particles = [];

        this.resize();
        this.createParticles();

        window.addEventListener("resize", () => this.resize());

        this.animate();
    }

    resize() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);

        this.width = window.innerWidth;
        this.height = window.innerHeight;

        this.canvas.width = this.width * dpr;
        this.canvas.height = this.height * dpr;

        this.canvas.style.width = `${this.width}px`;
        this.canvas.style.height = `${this.height}px`;

        this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    createParticles() {
        const count = Math.min(
            70,
            Math.max(35, Math.floor((window.innerWidth * window.innerHeight) / 18000))
        );

        this.particles = Array.from(
            { length: count },
            () => new Particle(this)
        );
    }

    animate() {
        this.ctx.clearRect(0, 0, this.width, this.height);

        this.particles.forEach(particle => {
            particle.update();
            particle.draw(this.ctx);
        });

        requestAnimationFrame(() => this.animate());
    }
}


class Particle {
    constructor(background) {
        this.background = background;
        this.reset(true);
    }

    reset(initial = false) {
        const { width, height } = this.background;

        this.x = Math.random() * width;
        this.y = initial
            ? Math.random() * height
            : Math.random() < 0.5
                ? -5
                : height + 5;

        this.size = Math.random() * 1.8 + 0.6;
        this.vx = (Math.random() - 0.5) * 0.35;
        this.vy = (Math.random() - 0.5) * 0.35;
        this.alpha = Math.random() * 0.35 + 0.12;
    }

    update() {
        const { width, height } = this.background;

        this.x += this.vx;
        this.y += this.vy;

        if (
            this.x < -10 ||
            this.x > width + 10 ||
            this.y < -10 ||
            this.y > height + 10
        ) {
            this.reset();
        }
    }

    draw(ctx) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 242, 254, ${this.alpha})`;
        ctx.fill();
    }
}


class SlidingPuzzle {
    constructor() {
        this.size = 4;
        this.grid = [];
        this.emptyPos = { r: 0, c: 0 };

        this.moves = 0;
        this.timer = 0;
        this.timerInterval = null;
        this.isPlaying = false;

        this.gridEl = document.getElementById("game-grid");
        this.moveEl = document.getElementById("move-counter");
        this.timerEl = document.getElementById("timer");
        this.difficultySelect = document.getElementById("difficulty-selector");

        this.bindEvents();
        this.loadBestStats();
    }

    bindEvents() {
        this.difficultySelect.addEventListener("change", event => {
            this.size = Number(event.target.value);
            this.resetGame();
        });

        document
            .getElementById("btn-reset")
            .addEventListener("click", () => {
                audio.playAction();
                this.resetGame();
            });
    }

    initGrid() {
        const numbers = Array.from(
            { length: this.size * this.size - 1 },
            (_, index) => index + 1
        );

        numbers.push(null);

        do {
            this.shuffleArray(numbers);
        } while (!this.isSolvable(numbers));

        this.grid = [];

        for (let r = 0; r < this.size; r++) {
            const row = [];

            for (let c = 0; c < this.size; c++) {
                const value = numbers[r * this.size + c];

                row.push(value);

                if (value === null) {
                    this.emptyPos = { r, c };
                }
            }

            this.grid.push(row);
        }
    }

    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    isSolvable(array) {
        let inversions = 0;

        const flat = array.filter(value => value !== null);

        for (let i = 0; i < flat.length; i++) {
            for (let j = i + 1; j < flat.length; j++) {
                if (flat[i] > flat[j]) {
                    inversions++;
                }
            }
        }

        if (this.size % 2 !== 0) {
            return inversions % 2 === 0;
        }

        const emptyIndex = array.indexOf(null);
        const emptyRowFromBottom =
            this.size - Math.floor(emptyIndex / this.size);

        return (inversions + emptyRowFromBottom) % 2 === 0;
    }

    renderGrid() {
        this.gridEl.innerHTML = "";

        this.gridEl.style.gridTemplateColumns =
            `repeat(${this.size}, 1fr)`;

        this.gridEl.style.gridTemplateRows =
            `repeat(${this.size}, 1fr)`;

        for (let r = 0; r < this.size; r++) {
            for (let c = 0; c < this.size; c++) {
                const value = this.grid[r][c];

                const tile = document.createElement("div");

                tile.className = "puzzle-tile";

                if (value === null) {
                    tile.classList.add("empty-tile");
                } else {
                    tile.textContent = value;

                    const targetValue = r * this.size + c + 1;

                    if (value === targetValue) {
                        tile.classList.add("correct-position");
                    }

                    tile.addEventListener("click", () => {
                        this.handleTileClick(r, c);
                    });
                }

                this.gridEl.appendChild(tile);
            }
        }
    }

    handleTileClick(r, c) {
        if (!this.isPlaying) return;

        const isAdjacent =
            Math.abs(r - this.emptyPos.r) +
            Math.abs(c - this.emptyPos.c) === 1;

        if (!isAdjacent) return;

        if (!this.timerInterval) {
            this.startTimer();
        }

        audio.playSlide();

        this.grid[this.emptyPos.r][this.emptyPos.c] = this.grid[r][c];
        this.grid[r][c] = null;

        this.emptyPos = { r, c };

        this.moves++;

        this.moveEl.textContent = this.moves;

        this.renderGrid();
        this.checkVictory();
    }

    startTimer() {
        clearInterval(this.timerInterval);

        this.timerInterval = setInterval(() => {
            this.timer++;

            this.timerEl.textContent = this.formatTime(this.timer);
        }, 1000);
    }

    stopTimer() {
        clearInterval(this.timerInterval);
        this.timerInterval = null;
    }

    formatTime(seconds) {
        const minutes = String(Math.floor(seconds / 60)).padStart(2, "0");
        const remainingSeconds = String(seconds % 60).padStart(2, "0");

        return `${minutes}:${remainingSeconds}`;
    }

    resetGame() {
        this.stopTimer();

        this.moves = 0;
        this.timer = 0;

        this.moveEl.textContent = "0";
        this.timerEl.textContent = "00:00";

        this.initGrid();
        this.renderGrid();

        this.isPlaying = true;
    }

    checkVictory() {
        let expected = 1;

        for (let r = 0; r < this.size; r++) {
            for (let c = 0; c < this.size; c++) {

                if (
                    r === this.size - 1 &&
                    c === this.size - 1
                ) {
                    if (this.grid[r][c] !== null) {
                        return;
                    }
                } else {
                    if (this.grid[r][c] !== expected++) {
                        return;
                    }
                }
            }
        }

        this.stopTimer();
        this.isPlaying = false;

        audio.playWin();

        if (typeof confetti === "function") {
            confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 }
            });
        }

        this.saveBestStats();

        document.getElementById("victory-time").textContent =
            this.timerEl.textContent;

        document.getElementById("victory-moves").textContent =
            this.moves;

        showModal("victory-modal");
    }

    saveBestStats() {
        const timeKey = `best_time_${this.size}`;
        const movesKey = `best_moves_${this.size}`;

        const currentBestTime = localStorage.getItem(timeKey);
        const currentBestMoves = localStorage.getItem(movesKey);

        if (
            !currentBestTime ||
            this.timer < Number(currentBestTime)
        ) {
            localStorage.setItem(timeKey, this.timer);
        }

        if (
            !currentBestMoves ||
            this.moves < Number(currentBestMoves)
        ) {
            localStorage.setItem(movesKey, this.moves);
        }

        this.loadBestStats();
    }

    loadBestStats() {
        const bestTime = localStorage.getItem(
            `best_time_${this.size}`
        );

        const bestMoves = localStorage.getItem(
            `best_moves_${this.size}`
        );

        const bestTimeEl =
            document.getElementById("home-best-time");

        const bestMovesEl =
            document.getElementById("home-best-moves");

        bestTimeEl.textContent = bestTime
            ? this.formatTime(Number(bestTime))
            : "--:--";

        bestMovesEl.textContent =
            bestMoves || "--";
    }
}


function showModal(id) {
    const modal = document.getElementById(id);

    modal.classList.add("active");
}


function hideModal(id) {
    const modal = document.getElementById(id);

    modal.classList.remove("active");
}


const background = new BackgroundParticles();
const game = new SlidingPuzzle();

const homeScreen = document.getElementById("home-screen");
const gameScreen = document.getElementById("game-screen");

document
    .getElementById("btn-start")
    .addEventListener("click", () => {
        audio.playAction();
        homeScreen.classList.add("hidden");
        gameScreen.classList.remove("hidden");

        game.resetGame();
    });


document
    .getElementById("btn-back")
    .addEventListener("click", () => {
        game.stopTimer();

        gameScreen.classList.add("hidden");
        homeScreen.classList.remove("hidden");

        game.loadBestStats();
    });


const soundButton =
    document.getElementById("btn-sound-toggle");

soundButton.addEventListener("click", () => {
    audio.playAction();
    audio.enabled = !audio.enabled;

    soundButton.innerHTML = audio.enabled
        ? "<span>🔊</span><span>Sound: ON</span>"
        : "<span>🔇</span><span>Sound: OFF</span>";
});


document
    .getElementById("btn-instructions")
    .addEventListener("click", () => {
        audio.playAction();
        showModal("instructions-modal");
    });


document
    .getElementById("btn-close-instructions")
    .addEventListener("click", () => {
        hideModal("instructions-modal");
    });


document
    .getElementById("btn-play-again")
    .addEventListener("click", () => {
        audio.playAction();
        hideModal("victory-modal");
        game.resetGame();
    });


document.querySelectorAll(".modal").forEach(modal => {
    modal.addEventListener("click", event => {
        if (event.target === modal) {
            hideModal(modal.id);
        }
    });
});


document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
        hideModal("instructions-modal");
        hideModal("victory-modal");
    }
});

