const toast = document.getElementById("toast");
const progress = document.querySelector(".progress");
const currentTime = document.getElementById("currentTime");
const likeBtn = document.getElementById("likeBtn");

function showToast(message){
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(()=>toast.classList.remove("show"),1800);
}

let seconds = 0;
setInterval(()=>{
  seconds = (seconds + 1) % 181;
  const m = String(Math.floor(seconds/60)).padStart(2,"0");
  const s = String(seconds%60).padStart(2,"0");
  currentTime.textContent = `${m}:${s}`;
  progress.style.width = `${Math.min(100, 25 + (seconds/180)*60)}%`;
},1000);

likeBtn.addEventListener("click", ()=>{
  likeBtn.classList.toggle("liked");
  showToast(likeBtn.classList.contains("liked") ? "Added to favourites ♥" : "Removed from favourites");
});

document.getElementById("shareBtn").addEventListener("click", async ()=>{
  const shareData = {
    title:"RBoyyz Music",
    text:"Listen to RBoyyz Music",
    url:"https://rboyyz.ismyradio.com/"
  };
  try{
    if(navigator.share) await navigator.share(shareData);
    else{
      await navigator.clipboard.writeText(shareData.url);
      showToast("Home link copied");
    }
  }catch(e){}
});

document.getElementById("backBtn").addEventListener("click",()=>showToast("Previous track"));
document.getElementById("nextBtn").addEventListener("click",()=>showToast("Next track"));
document.getElementById("menuBtn").addEventListener("click",()=>showToast("RBoyyz Music Menu"));
document.getElementById("infoBtn").addEventListener("click",()=>showToast("RBoyyz — Rich Boyyz Music"));
