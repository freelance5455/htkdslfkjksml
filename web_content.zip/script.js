const GUARDIAN_PROMPT = `
You are GuardianPK, the official AI assistant for PeaceGuard SMP.

You are primarily a Minecraft-focused AI and a friendly community assistant.


MINECRAFT TOPICS

You can help with:

- Minecraft Java Edition
- Minecraft Bedrock Edition
- Survival
- Building
- Redstone
- Commands
- Blocks
- Items
- Crafting
- Enchantments
- Potions
- Mobs
- Villagers
- Biomes
- Structures
- Farms
- Minecraft mechanics
- Server administration
- Paper
- Spigot
- Bukkit
- Skript
- Minecraft plugins
- Datapacks
- Resource packs
- Mods


PEACEGUARD SMP

PeaceGuard SMP is a peaceful and friendly Minecraft server.

The server is focused on:

- Friendly gameplay
- Survival
- Building
- Cooperation
- Community
- Having fun
- A peaceful environment

Do not describe PeaceGuard SMP as competitive, toxic, or hostile unless the user provides information that says otherwise.

Do not invent PeaceGuard SMP rules.

Do not invent PeaceGuard SMP commands.

Do not invent plugins.

Do not invent ranks.

Do not invent events.

Do not invent server features.

If you do not know something about PeaceGuard SMP, say that you do not have that information.


SERVER MEMBERS

There are special members of PeaceGuard SMP:

- vtoxvoid
- beebuyog
- kolfox
- bobablade
- kinetixrogu

These usernames are SPECIAL MEMBERS only.

Do NOT automatically call them:

- owner
- co-owner
- admin
- moderator
- staff
- developer

unless the user specifically provides that information.

Their only known designation from this information is SPECIAL MEMBER.


CO-OWNERS

The known co-owners of PeaceGuard SMP are:

- markyjusher
- den

If the user asks who the co-owners are, identify:

markyjusher and den

as the co-owners.

Do not assign co-owner status to the special members.


CURRENT USER

The current user is recognized as one of the co-owners of PeaceGuard SMP.

The current user's Minecraft identity is markyjusher.

If the user asks:

"Who am I?"

"What is my role?"

"Who owns the server?"

or similar questions about their server role,

you may identify the current user as:

markyjusher, a co-owner of PeaceGuard SMP.

Do not reveal private information that was not provided.


TOPIC SEPARATION

Keep two types of information separate:

1. General Minecraft
2. PeaceGuard SMP

For general Minecraft questions, answer using normal Minecraft knowledge.

For PeaceGuard SMP questions, only use information that is actually known.

Never turn general Minecraft behavior into a claimed PeaceGuard SMP feature.


JOKE TIME

GuardianPK has a fun topic called "Joke Time".

Joke Time is for:

- Minecraft jokes
- Gaming jokes
- Light server jokes
- Friendly community humor
- Short funny situations
- Minecraft-style dad jokes
- Funny fictional Minecraft scenarios

Keep jokes harmless and friendly.

Do not make jokes about serious harm, self-harm, sexual content, hateful content, or dangerous activities.

When the user explicitly asks for a joke, give them one.

GuardianPK may also occasionally include a short Minecraft-related joke when it naturally fits the conversation.

Do not force a joke into every answer.

If the conversation becomes casual or slightly off-topic, a short harmless joke can sometimes be used to keep the conversation fun.

Example style:

"That creeper really said: I just wanted to say hello. 💥"

Keep jokes short unless the user asks for more.


OFF-TOPIC QUESTIONS

GuardianPK is mainly focused on Minecraft and PeaceGuard SMP.

If the user asks something completely unrelated, politely explain that GuardianPK is mainly a Minecraft and PeaceGuard SMP assistant.

However, GuardianPK can still have a short casual interaction when appropriate.

For casual or off-topic conversations, you may:

- Give a short friendly response
- Make a harmless joke
- Redirect the conversation back toward Minecraft

Do not suddenly give a huge Minecraft lecture for a simple casual message.


ACCURACY

Never pretend to know information that was never provided.

If a Minecraft version changes something, mention that the exact behavior can depend on the Minecraft version.

Do not invent commands, mechanics, plugin behavior, server features, or player roles.

If the user gives new PeaceGuard SMP information during the conversation, use that information appropriately.


STYLE

Be friendly.

Be natural.

Be helpful.

Do not sound like a corporate chatbot.

Keep simple questions simple.

Give detailed answers when the question actually needs them.

Use Markdown when useful.

Use code blocks for:

- Minecraft commands
- Skript
- Configuration
- Programming code


IDENTITY

Your name is GuardianPK.

You are the AI assistant for PeaceGuard SMP.

You are not affiliated with Mojang or Microsoft.

You should describe PeaceGuard SMP as a peaceful and friendly community.


IMPORTANT ROLE SUMMARY

Co-owners:
- markyjusher
- den

Special members:
- vtoxvoid
- beebuyog
- kolfox
- bobablade
- kinetixrogu

Do not mix these roles.

discord server link: https://discord.gg/jVfnh62UJ
`;


/* =========================
   ELEMENTS
========================= */

const chatArea =
    document.getElementById("chatArea");

const chatForm =
    document.getElementById("chatForm");

const messageInput =
    document.getElementById("messageInput");

const sendButton =
    document.getElementById("sendButton");

const typing =
    document.getElementById("typing");


/* =========================
   CHAT HISTORY
========================= */

let conversation = [];

let isGenerating = false;


/* =========================
   ESCAPE HTML
========================= */

function escapeHTML(text) {

    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/* =========================
   MARKDOWN
========================= */

function renderMarkdown(text) {

    let html =
        escapeHTML(text);

    const codeBlocks = [];

    html = html.replace(
        /```([\s\S]*?)```/g,
        function(_, code) {

            const index =
                codeBlocks.length;

            const cleanCode =
                code.replace(/^\w+\n/, "");

            codeBlocks.push(
                cleanCode
            );

            return `___CODE_${index}___`;
        }
    );


    html = html.replace(
        /\*\*(.*?)\*\*/g,
        "<strong>$1</strong>"
    );


    html = html.replace(
        /`([^`]+)`/g,
        "<code>$1</code>"
    );


    html = html.replace(
        /^### (.*)$/gm,
        "<strong>$1</strong>"
    );


    html = html.replace(
        /^## (.*)$/gm,
        "<strong>$1</strong>"
    );


    html = html.replace(
        /^# (.*)$/gm,
        "<strong>$1</strong>"
    );


    html = html.replace(
        /^\s*[-*] (.*)$/gm,
        "<li>$1</li>"
    );


    html = html.replace(
        /(<li>.*<\/li>)/gs,
        "<ul>$1</ul>"
    );


    html =
        "<p>" +
        html +
        "</p>";


    html = html.replace(
        /\n\n/g,
        "</p><p>"
    );


    html = html.replace(
        /\n/g,
        "<br>"
    );


    codeBlocks.forEach(
        function(code, index) {

            const safeCode =
                escapeHTML(code);

            const block = `
                <div class="code-block">

                    <div class="code-header">

                        <span>CODE</span>

                        <button
                            class="copy-code"
                            data-code="${encodeURIComponent(code)}"
                        >
                            Copy
                        </button>

                    </div>

                    <pre><code>${safeCode}</code></pre>

                </div>
            `;

            html =
                html.replace(
                    `___CODE_${index}___`,
                    block
                );
        }
    );


    return html;
}


/* =========================
   ADD MESSAGE
========================= */

function addMessage(
    role,
    text
) {

    const message =
        document.createElement("div");


    message.className =
        `message ${role}`;


    const avatar =
        document.createElement("div");


    avatar.className =
        "message-avatar";


    avatar.textContent =
        role === "user"
            ? "U"
            : "G";


    const content =
        document.createElement("div");


    content.className =
        "message-content";


    if (role === "user") {

        content.textContent =
            text;

    } else {

        content.innerHTML =
            renderMarkdown(text);
    }


    message.appendChild(
        avatar
    );


    message.appendChild(
        content
    );


    chatArea.appendChild(
        message
    );


    scrollToBottom();


    if (role === "assistant") {
        setupCopyButtons(message);
    }


    return message;
}


/* =========================
   SCROLL
========================= */

function scrollToBottom() {

    chatArea.scrollTop =
        chatArea.scrollHeight;
}


/* =========================
   TYPING
========================= */

function setTyping(value) {

    typing.classList.toggle(
        "show",
        value
    );
}


/* =========================
   INPUT HEIGHT
========================= */

function resizeInput() {

    messageInput.style.height =
        "auto";

    messageInput.style.height =
        Math.min(
            messageInput.scrollHeight,
            150
        ) + "px";
}


messageInput.addEventListener(
    "input",
    resizeInput
);


/* =========================
   SEND MESSAGE
========================= */

async function sendMessage(message) {

    if (
        isGenerating ||
        !message.trim()
    ) {
        return;
    }


    message =
        message.trim();


    addMessage(
        "user",
        message
    );


    conversation.push({

        role: "user",

        parts: [
            {
                text: message
            }
        ]

    });


    messageInput.value =
        "";

    resizeInput();


    isGenerating =
        true;

    sendButton.disabled =
        true;


    setTyping(true);


    try {

        let reply =
            null;

        let lastError =
            null;


        for (
            const model of GEMINI_MODELS
        ) {

            try {

                reply =
                    await callGemini(
                        model,
                        GUARDIAN_PROMPT,
                        conversation
                    );

                break;

            } catch (error) {

                lastError =
                    error;


                console.warn(
                    `Gemini model ${model} failed:`,
                    error
                );


                const shouldTryNext =
                    error.status === 429 ||
                    error.status === 500 ||
                    error.status === 502 ||
                    error.status === 503 ||
                    error.status === 504;


                if (!shouldTryNext) {
                    break;
                }
            }
        }


        if (!reply) {

            throw (
                lastError ||
                new Error(
                    "Gemini could not generate a response."
                )
            );
        }


        conversation.push({

            role: "model",

            parts: [
                {
                    text: reply
                }
            ]

        });


        setTyping(false);


        addMessage(
            "assistant",
            reply
        );

    } catch (error) {

        console.error(error);


        setTyping(false);


        let errorMessage =
            "I couldn't connect to Gemini right now.";


        if (error.message) {

            errorMessage +=
                `\n\nError: ${error.message}`;
        }


        addMessage(
            "assistant",
            errorMessage
        );

    } finally {

        isGenerating =
            false;

        sendButton.disabled =
            false;

        messageInput.focus();
    }
}


/* =========================
   FORM
========================= */

chatForm.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();

        sendMessage(
            messageInput.value
        );
    }
);


/* =========================
   ENTER KEY
========================= */

messageInput.addEventListener(
    "keydown",
    function(event) {

        if (
            event.key === "Enter" &&
            !event.shiftKey
        ) {

            event.preventDefault();

            chatForm.requestSubmit();
        }
    }
);


/* =========================
   SUGGESTIONS
========================= */

document
    .querySelectorAll(".suggestion")
    .forEach(button => {

        button.addEventListener(
            "click",
            function() {

                const prompt =
                    button.dataset.prompt;


                messageInput.value =
                    prompt;


                resizeInput();

                messageInput.focus();
            }
        );

    });


/* =========================
   SIDEBAR TOPICS
========================= */

document
    .querySelectorAll(".topic-button")
    .forEach(button => {

        button.addEventListener(
            "click",
            function() {

                const prompt =
                    button.dataset.prompt;


                messageInput.value =
                    prompt;


                resizeInput();

                messageInput.focus();
            }
        );

    });


/* =========================
   COPY CODE
========================= */

function setupCopyButtons(container) {

    container
        .querySelectorAll(".copy-code")
        .forEach(button => {

            button.addEventListener(
                "click",
                async function() {

                    const code =
                        decodeURIComponent(
                            button.dataset.code
                        );


                    try {

                        await navigator
                            .clipboard
                            .writeText(code);


                        button.textContent =
                            "Copied!";


                        setTimeout(
                            () => {

                                button.textContent =
                                    "Copy";

                            },
                            1500
                        );

                    } catch {

                        button.textContent =
                            "Failed";
                    }

                }
            );

        });
}


/* =========================
   STARTUP
========================= */

messageInput.focus();