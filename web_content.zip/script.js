const defaultProducts=[
{id:1,name:"মেয়েদের সুন্দর ড্রেস",price:580,emoji:"👗"},
{id:2,name:"ফ্যাশন ব্যাগ",price:450,emoji:"👜"},
{id:3,name:"জুয়েলারি সেট",price:280,emoji:"💍"},
{id:4,name:"হ্যান্ডব্যাগ",price:650,emoji:"🎒"},
{id:5,name:"ফ্যাশন স্কার্ফ",price:220,emoji:"🧣"},
{id:6,name:"কসমেটিক্স সেট",price:390,emoji:"💄"}
];
let products=JSON.parse(localStorage.getItem("mayaProducts")||"null")||defaultProducts;
let cart=JSON.parse(localStorage.getItem("mayaCart")||"[]");
function money(n){return "৳"+Number(n).toLocaleString("bn-BD")}
function renderProducts(){
 const q=(document.getElementById("search").value||"").toLowerCase();
 const list=products.filter(p=>p.name.toLowerCase().includes(q));
 document.getElementById("productsGrid").innerHTML=list.map(p=>`
 <article class="product"><div class="product-img">${p.emoji||"🛍️"}</div>
 <div class="product-body"><h3>${p.name}</h3><div class="price">${money(p.price)}</div>
 <button class="add" onclick="addToCart(${p.id})">কার্টে যোগ করুন</button></div></article>`).join("")||'<div class="empty">কোনো পণ্য পাওয়া যায়নি।</div>';
}
function addToCart(id){let x=cart.find(i=>i.id===id);x?x.qty++:cart.push({id,qty:1});save();openCart()}
function save(){localStorage.setItem("mayaCart",JSON.stringify(cart));updateCount()}
function updateCount(){document.getElementById("cartCount").textContent=cart.reduce((s,i)=>s+i.qty,0)}
function openCart(){renderCart();document.getElementById("cartModal").classList.add("show")}
function closeCart(){document.getElementById("cartModal").classList.remove("show")}
function renderCart(){
 let total=0; const el=document.getElementById("cartItems");
 if(!cart.length){el.innerHTML='<div class="empty">কার্ট খালি।</div>';document.getElementById("cartTotal").textContent=money(0);return}
 el.innerHTML=cart.map(i=>{let p=products.find(x=>x.id===i.id);total+=p.price*i.qty;return `<div class="cart-row"><div>${p.emoji} ${p.name}<br><b>${money(p.price)}</b></div><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button>${i.qty}<button onclick="changeQty(${p.id},1)">+</button><button onclick="removeItem(${p.id})">🗑️</button></div></div>`}).join("");
 document.getElementById("cartTotal").textContent=money(total)
}
function changeQty(id,n){let x=cart.find(i=>i.id===id);x.qty+=n;if(x.qty<=0)cart=cart.filter(i=>i.id!==id);save();renderCart()}
function removeItem(id){cart=cart.filter(i=>i.id!==id);save();renderCart()}
function showCheckout(){if(!cart.length){alert("আগে একটি পণ্য কার্টে যোগ করুন।");return}closeCart();document.getElementById("checkoutModal").classList.add("show");document.getElementById("checkoutSummary").innerHTML="<b>অর্ডারের মোট: "+money(cart.reduce((s,i)=>s+(products.find(p=>p.id===i.id).price*i.qty),0))+"</b>"}
function closeCheckout(){document.getElementById("checkoutModal").classList.remove("show")}
function placeOrder(e){
 e.preventDefault();
 const name=document.getElementById("customerName").value,phone=document.getElementById("customerPhone").value,address=document.getElementById("customerAddress").value;
 const order={id:Date.now(),name,phone,address,items:cart,total:cart.reduce((s,i)=>s+(products.find(p=>p.id===i.id).price*i.qty),0),date:new Date().toLocaleString("bn-BD")};
 let orders=JSON.parse(localStorage.getItem("mayaOrders")||"[]");orders.push(order);localStorage.setItem("mayaOrders",JSON.stringify(orders));
 alert("ধন্যবাদ! আপনার অর্ডারটি গ্রহণ করা হয়েছে।");
 cart=[];save();closeCheckout();document.getElementById("customerName").value="";document.getElementById("customerPhone").value="";document.getElementById("customerAddress").value="";
}
renderProducts();updateCount();
