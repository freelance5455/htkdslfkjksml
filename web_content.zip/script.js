// ===========================
// Elements
// ===========================

const tableBody = document.getElementById("tableBody");
const dateInput = document.getElementById("dateInput");

const themeBtn = document.getElementById("themeBtn");

const newSheetBtn = document.getElementById("newSheetBtn");
const saveImageBtn = document.getElementById("saveImageBtn");

const dialogOverlay = document.getElementById("dialogOverlay");
const cancelBtn = document.getElementById("cancelBtn");
const confirmBtn = document.getElementById("confirmBtn");

const loadingOverlay = document.getElementById("loadingOverlay");


// ===========================
// Create 100 Rows
// ===========================

function createRows(){

    tableBody.innerHTML="";

    for(let i=1;i<=100;i++){

        const tr=document.createElement("tr");

        tr.innerHTML=`

            <td>${i}</td>

            <td><input type="text"></td>

            <td><input type="number"></td>

            <td><input type="number"></td>

            <td><input type="number"></td>

        `;

        tableBody.appendChild(tr);

    }

}

createRows();


// ===========================
// Save
// ===========================

function saveData(){

    let rows=[];

    document.querySelectorAll("#tableBody tr").forEach(row=>{

        const values=[];

        row.querySelectorAll("input").forEach(input=>{

            values.push(input.value);

        });

        rows.push(values);

    });

    localStorage.setItem("rows",JSON.stringify(rows));

    localStorage.setItem("date",dateInput.value);

}

document.addEventListener("input",saveData);


// ===========================
// Load
// ===========================

function loadData(){

    const rows=JSON.parse(localStorage.getItem("rows"));

    const date=localStorage.getItem("date");

    if(date){

        dateInput.value=date;

    }

    if(rows){

        document.querySelectorAll("#tableBody tr").forEach((row,index)=>{

            const inputs=row.querySelectorAll("input");

            rows[index].forEach((value,i)=>{

                inputs[i].value=value;

            });

        });

    }

}

loadData();


// ===========================
// Theme
// ===========================

const savedTheme=localStorage.getItem("theme");

if(savedTheme==="light"){

    document.body.classList.remove("dark");

    themeBtn.innerHTML="☀️";

}else{

    document.body.classList.add("dark");

    themeBtn.innerHTML="🌙";

}

themeBtn.onclick=()=>{

    document.body.classList.toggle("dark");

    if(document.body.classList.contains("dark")){

        localStorage.setItem("theme","dark");

        themeBtn.innerHTML="🌙";

    }else{

        localStorage.setItem("theme","light");

        themeBtn.innerHTML="☀️";

    }

};


// ===========================
// New Sheet
// ===========================

newSheetBtn.onclick=()=>{

    dialogOverlay.style.display="flex";

};

cancelBtn.onclick=()=>{

    dialogOverlay.style.display="none";

};

dialogOverlay.onclick=(e)=>{

    if(e.target===dialogOverlay){

        dialogOverlay.style.display="none";

    }

};

confirmBtn.onclick=()=>{

    document.querySelectorAll("#tableBody input").forEach(input=>{

        input.value="";

    });

    dateInput.value="";

    saveData();

    dialogOverlay.style.display="none";

    dateInput.focus();

};


// ===========================
// Save Image
// ===========================

saveImageBtn.onclick=async()=>{

    loadingOverlay.style.display="flex";

    const rows=[...document.querySelectorAll("#tableBody tr")];

    const hidden=[];

    let last=-1;

    rows.forEach((row,index)=>{

        const inputs=row.querySelectorAll("input");

        const hasData=[...inputs].some(input=>input.value.trim()!="");

        if(hasData){

            last=index;

        }

    });

    rows.forEach((row,index)=>{

        if(index>last){

            row.style.display="none";

            hidden.push(row);

        }

    });

    saveImageBtn.style.display="none";

    newSheetBtn.style.display="none";

    await new Promise(r=>setTimeout(r,300));

    const canvas=await html2canvas(document.getElementById("captureArea"),{

        scale:2,

        backgroundColor:null

    });

    saveImageBtn.style.display="";

    newSheetBtn.style.display="";

    hidden.forEach(row=>{

        row.style.display="";

    });

    const link=document.createElement("a");

    const fileName=dateInput.value.trim()===""
    ? "كشف حساب أبشواي.png"
    : `كشف حساب أبشواي - ${dateInput.value}.png`;

    link.download=fileName;

    link.href=canvas.toDataURL("image/png");

    link.click();

    loadingOverlay.style.display="none";

};