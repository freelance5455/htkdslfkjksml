document.addEventListener('DOMContentLoaded', () => {
  const PRESET_NGROK = "https://tinderbox-spherical-defensive.ngrok-free.dev";
  const PRESET_LAN = "http://10.181.205.95:52257";
  const STORAGE_KEY = "pressholder_server_url";

  const statusText = document.getElementById('status-text');
  const loaderBar = document.getElementById('loader-bar');
  const inputUrl = document.getElementById('server-url-input');
  const btnConnect = document.getElementById('btn-connect');
  const btnForce = document.getElementById('btn-force');
  const btnPresetNgrok = document.getElementById('btn-preset-ngrok');
  const btnPresetLan = document.getElementById('btn-preset-lan');
  const errorMsg = document.getElementById('error-message');

  // Cargar URL guardada o por defecto
  let currentServer = localStorage.getItem(STORAGE_KEY) || PRESET_NGROK;
  inputUrl.value = currentServer;

  btnPresetNgrok.addEventListener('click', () => {
    inputUrl.value = PRESET_NGROK;
    testAndConnect(PRESET_NGROK);
  });

  btnPresetLan.addEventListener('click', () => {
    inputUrl.value = PRESET_LAN;
    testAndConnect(PRESET_LAN);
  });

  btnConnect.addEventListener('click', () => {
    let url = inputUrl.value.trim();
    if (!url) return;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
      inputUrl.value = url;
    }
    testAndConnect(url);
  });

  btnForce.addEventListener('click', () => {
    let url = inputUrl.value.trim() || currentServer;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    localStorage.setItem(STORAGE_KEY, url);
    window.location.href = url;
  });

  async function testAndConnect(url) {
    // Normalizar URL (quitar barra final si la tiene)
    if (url.endsWith('/')) {
      url = url.slice(0, -1);
    }

    statusText.textContent = "Verificando conexión con Windows...";
    statusText.className = "status-badge connecting";
    loaderBar.style.display = "block";
    errorMsg.textContent = "";

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      // Usamos el endpoint /health que ya existe en tu backend
      const response = await fetch(`${url}/health`, {
        method: 'GET',
        signal: controller.signal,
        headers: { 'ngrok-skip-browser-warning': 'true' }
      });
      clearTimeout(timeoutId);

      if (response.ok) {
        statusText.textContent = "¡Conectado! Abriendo Pressholder...";
        statusText.className = "status-badge online";
        localStorage.setItem(STORAGE_KEY, url);
        setTimeout(() => {
          window.location.replace(url);
        }, 400);
        return;
      }
      throw new Error(`Servidor respondió con código ${response.status}`);
    } catch (err) {
      loaderBar.style.display = "none";
      statusText.textContent = "Servidor no responde";
      statusText.className = "status-badge offline";
      errorMsg.textContent = "Asegúrate de tener abierto INICIAR_SERVIDOR.bat en tu PC con Windows.";
    }
  }

  // Intento de conexión inicial automático
  testAndConnect(currentServer);
});
