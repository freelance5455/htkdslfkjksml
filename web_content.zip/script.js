
"use strict";

/* ==========================================
   ARROW PUZZLE — INFINITE LEVELS
   QuickEdit Android | HTML / CSS / JS
   Audio: arrow.mp3, complete.mp3, gameover.mp3
   ========================================== */

const $ = id => document.getElementById(id);
const SIZE = 7;
const NS = "http://www.w3.org/2000/svg";
const SAVE_KEY = "arrowPuzzleSave_v2";

const DIRS = {
  up:    { x: 0, y: -1 },
  down:  { x: 0, y: 1 },
  left:  { x: -1, y: 0 },
  right: { x: 1, y: 0 }
};

let level = 1;
let score = 0;
let hp = 3;
let hintCount = 3;

let arrows = [];
let nextId = 1;
let history = [];

let busy = false;
let paused = false;
let soundOn = true;
let gameEnded = false;
let levelStartCount = 0;
let toastTimer = null;
let transitionTimer = null;
let audioUnlocked = false;

/* ---------- AUDIO MP3 ---------- */

const sounds = {
  arrow: new Audio("./arrow.mp3"),
  complete: new Audio("./complete.mp3"),
  gameover: new Audio("./gameover.mp3")
};

Object.values(sounds).forEach(audio => {
  audio.preload = "auto";
  audio.volume = 0.75;
});

function playMP3(name) {
  if (!soundOn || !sounds[name]) return;

  const audio = sounds[name];

  try {
    audio.pause();
    audio.currentTime = 0;

    const result = audio.play();

    if (result && typeof result.catch === "function") {
      result.catch(() => {});
    }
  } catch (e) {}
}

function unlockAudio() {
  if (audioUnlocked) return;
  audioUnlocked = true;

  // Browser HP biasanya mengizinkan audio setelah interaksi pemain.
  Object.values(sounds).forEach(audio => {
    audio.load();
  });
}

/* ---------- UTILITIES ---------- */

const key = p => `${p.x},${p.y}`;

const inside = p =>
  p.x >= 0 && p.x < SIZE &&
  p.y >= 0 && p.y < SIZE;

function add(p, d) {
  return { x: p.x + d.x, y: p.y + d.y };
}

function sameDirection(a, b) {
  return a.x === b.x && a.y === b.y;
}

function opposite(d) {
  return { x: -d.x, y: -d.y };
}

function toast(message) {
  const el = $("toast");
  if (!el) return;

  el.textContent = message;
  el.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    el.classList.remove("show");
  }, 1800);
}

/* ---------- SAVE / LOAD ---------- */

function saveProgress() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify({
      level,
      score
    }));
  } catch (e) {}
}

function loadProgress() {
  try {
    const data = JSON.parse(
      localStorage.getItem(SAVE_KEY) || "null"
    );

    if (!data) return;

    if (Number.isFinite(data.level)) {
      level = Math.max(1, Math.floor(data.level));
    }

    if (Number.isFinite(data.score)) {
      score = Math.max(0, Math.floor(data.score));
    }
  } catch (e) {}
}

/* ---------- BOARD COLLISION ---------- */

function occupancyMap(source = arrows) {
  const map = new Map();

  for (const arrow of source) {
    for (const cell of arrow.path) {
      map.set(key(cell), arrow.id);
    }
  }

  return map;
}

function canExit(arrow) {
  const map = occupancyMap();
  const direction = DIRS[arrow.dir];

  let cell = add(arrow.head, direction);

  while (inside(cell)) {
    if (map.has(key(cell))) return false;
    cell = add(cell, direction);
  }

  return true;
}

function rayClear(arrow, map) {
  const direction = DIRS[arrow.dir];
  let cell = add(arrow.head, direction);

  while (inside(cell)) {
    if (map.has(key(cell))) return false;
    cell = add(cell, direction);
  }

  return true;
}

/* ---------- PUZZLE GENERATOR ---------- */

/*
  Jalur disimpan dari EKOR ke KEPALA.
  Arah panah selalu mengikuti segmen terakhir.

  Tidak memakai kurva Bezier.
  Semua belokan adalah sudut 90 derajat.
*/

function createPath(tail, length, curved, map) {
  const path = [{ ...tail }];
  const used = new Set([key(tail)]);

  let previous = null;
  let turns = 0;

  for (let i = 1; i < length; i++) {
    let options = Object.values(DIRS).map(d => ({ ...d }));

    // Hindari berbalik ke sel sebelumnya.
    if (previous) {
      options = options.filter(d =>
        !(d.x === -previous.x && d.y === -previous.y)
      );
    }

    // Jalur lurus harus terus ke arah yang sama.
    if (!curved && previous) {
      options = options.filter(d =>
        sameDirection(d, previous)
      );
    }

    // Jalur bengkok sesekali memilih belokan.
    if (curved && previous && Math.random() < 0.7) {
      const turnsOnly = options.filter(d =>
        d.x !== previous.x && d.y !== previous.y
      );

      if (turnsOnly.length) options = turnsOnly;
    }

    // Acak urutan tanpa sort acak yang tidak stabil.
    for (let j = options.length - 1; j > 0; j--) {
      const k = Math.floor(Math.random() * (j + 1));
      [options[j], options[k]] = [options[k], options[j]];
    }

    let chosen = null;

    for (const direction of options) {
      const next = add(path[path.length - 1], direction);

      if (!inside(next)) continue;
      if (used.has(key(next))) continue;
      if (map.has(key(next))) continue;

      chosen = direction;
      break;
    }

    if (!chosen) return null;

    if (
      previous &&
      !sameDirection(chosen, previous)
    ) {
      turns++;
    }

    const next = add(path[path.length - 1], chosen);

    path.push(next);
    used.add(key(next));
    previous = chosen;
  }

  if (curved && turns === 0) return null;

  return path;
}

function generatePuzzle() {
  arrows = [];
  nextId = 1;

  // Tingkat kesulitan bertambah, tetapi papan tetap 7x7.
  const target = Math.min(9 + level * 2, 20);

  let curvedChance;

  if (level < 5) {
    curvedChance = 0.15;
  } else if (level < 15) {
    curvedChance = 0.55;
  } else if (level < 40) {
    curvedChance = 0.72;
  } else {
    curvedChance = 0.82;
  }

  const maxLength = Math.min(
    6,
    3 + Math.floor(level / 20)
  );

  for (let n = 0; n < target; n++) {
    let candidate = null;

    for (let attempt = 0; attempt < 1800; attempt++) {
      const map = occupancyMap();

      const tail = {
        x: Math.floor(Math.random() * SIZE),
        y: Math.floor(Math.random() * SIZE)
      };

      if (map.has(key(tail))) continue;

      const length =
        2 + Math.floor(Math.random() * (maxLength - 1));

      const curved = Math.random() < curvedChance;

      const path = createPath(
        tail,
        length,
        curved,
        map
      );

      if (!path || path.length < 2) continue;

      const head = path[path.length - 1];
      const previous = path[path.length - 2];

      const dx = head.x - previous.x;
      const dy = head.y - previous.y;

      const dir = Object.keys(DIRS).find(name =>
        DIRS[name].x === dx &&
        DIRS[name].y === dy
      );

      if (!dir) continue;

      const arrow = {
        id: nextId,
        path,
        head: { ...head },
        dir,
        curved
      };

      if (path.some(p => map.has(key(p)))) continue;
      if (!rayClear(arrow, map)) continue;

      candidate = arrow;
      break;
    }

    if (!candidate) continue;

    arrows.push(candidate);
    nextId++;
  }

  levelStartCount = arrows.length;
  gameEnded = false;
}

/* ---------- SVG DRAWING ---------- */

function svg(tag, attrs = {}) {
  const el = document.createElementNS(NS, tag);

  for (const [name, value] of Object.entries(attrs)) {
    el.setAttribute(name, value);
  }

  return el;
}

function pathToSVG(points, stopBeforeHead = false) {
  const coordinates = points.map(p => ({
    x: (p.x + 0.5) * 100,
    y: (p.y + 0.5) * 100
  }));

  if (stopBeforeHead && coordinates.length >= 2) {
    const last = coordinates.length - 1;
    const previous = coordinates[last - 1];

    const dx = coordinates[last].x - previous.x;
    const dy = coordinates[last].y - previous.y;

    coordinates[last] = {
      x: coordinates[last].x - dx * 0.16,
      y: coordinates[last].y - dy * 0.16
    };
  }

  // Garis lurus dari titik ke titik.
  // Tidak ada Q, C, atau kurva lengkung.
  return coordinates.map((p, i) =>
    `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`
  ).join(" ");
}

function makeArrow(arrow) {
  const group = svg("g", {
    class: "arrow-group",
    "data-arrow-id": arrow.id,
    tabindex: "0",
    role: "button",
    "aria-label": `Panah ${arrow.dir}`
  });

  const direction = DIRS[arrow.dir];

  const headX = (arrow.head.x + 0.5) * 100;
  const headY = (arrow.head.y + 0.5) * 100;

  const shaft = svg("path", {
    class: "arrow-shaft",
    d: pathToSVG(arrow.path, true),
    fill: "none",
    stroke: "#111111",
    "stroke-width": "29",
    "stroke-linecap": "round",
    "stroke-linejoin": "round"
  });

  const tipX = headX + direction.x * 34;
  const tipY = headY + direction.y * 34;

  const baseX = headX - direction.x * 9;
  const baseY = headY - direction.y * 9;

  const halfWidth = 16;
  const px = -direction.y * halfWidth;
  const py = direction.x * halfWidth;

  const head = svg("polygon", {
    class: "arrow-head-shape",
    points: [
      `${tipX},${tipY}`,
      `${baseX + px},${baseY + py}`,
      `${baseX - px},${baseY - py}`
    ].join(" "),
    fill: "#111111"
  });

  group.append(shaft, head);

  group.addEventListener("click", () => {
    unlockAudio();
    tapArrow(arrow.id);
  });

  group.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      unlockAudio();
      tapArrow(arrow.id);
    }
  });

  return group;
}

function render() {
  const board = $("board");
  if (!board) return;

  board.innerHTML = "";
  board.classList.add("arrow-canvas");

  const layer = svg("svg", {
    id: "arrowLayer",
    viewBox: "0 0 700 700",
    preserveAspectRatio: "none",
    width: "100%",
    height: "100%",
    "aria-label": "Papan Arrow Puzzle"
  });

  layer.style.display = "block";
  layer.style.width = "100%";
  layer.style.height = "100%";
  layer.style.overflow = "visible";

  for (const arrow of arrows) {
    layer.appendChild(makeArrow(arrow));
  }

  board.appendChild(layer);
  updateUI();
}

/* ---------- UI ---------- */

function updateUI() {
  if ($("level")) $("level").textContent = level;

  if ($("footerLevel")) {
    $("footerLevel").textContent = "LV. " + level;
  }

  if ($("score")) {
    $("score").textContent = String(score).padStart(4, "0");
  }

  if ($("remaining")) {
    $("remaining").textContent = arrows.length;
  }

  const cleared = Math.max(0, levelStartCount - arrows.length);

  if ($("progressText")) {
    $("progressText").textContent =
      `${cleared} / ${levelStartCount} panah`;
  }

  if ($("levelProgress")) {
    $("levelProgress").style.width =
      (levelStartCount
        ? cleared / levelStartCount * 100
        : 0) + "%";
  }

  if ($("hearts")) {
    [...$("hearts").children].forEach((heart, index) => {
      heart.classList.toggle("active", index < hp);
    });
  }

  if ($("healthNote")) {
    $("healthNote").textContent = hp + " tersisa";
  }

  if ($("hintCount")) {
    $("hintCount").textContent = hintCount;
  }

  if ($("hintBtn")) {
    $("hintBtn").disabled =
      busy || paused || gameEnded || hintCount <= 0;
  }

  if ($("undoBtn")) {
    $("undoBtn").disabled =
      busy || paused || gameEnded || !history.length;
  }

  if ($("restartBtn")) {
    $("restartBtn").disabled = busy;
  }

  saveProgress();
}

/* ---------- UNDO ---------- */

function saveHistory() {
  history.push({
    arrows: JSON.parse(JSON.stringify(arrows)),
    score,
    hp,
    hintCount,
    nextId,
    levelStartCount
  });

  if (history.length > 50) history.shift();
}

function undo() {
  if (busy || paused || gameEnded) return;

  if (!history.length) {
    return toast("Belum ada langkah yang bisa dibatalkan.");
  }

  const old = history.pop();

  arrows = old.arrows;
  score = old.score;
  hp = old.hp;
  hintCount = old.hintCount;
  nextId = old.nextId;
  levelStartCount = old.levelStartCount;

  render();
  toast("Langkah dikembalikan.");
}

/* ---------- ARROW MOVEMENT ---------- */

function animateArrowExit(group, direction, done) {
  if (!group) {
    done();
    return;
  }

  const shaft = group.querySelector(".arrow-shaft");
  const head = group.querySelector(".arrow-head-shape");
  const arrow = arrows.find(
    a => String(a.id) === group.dataset.arrowId
  );

  if (!shaft || !head || !arrow) {
    done();
    return;
  }

  // Jalur asli dalam koordinat SVG.
  const route = arrow.path.map(p => ({
    x: (p.x + 0.5) * 100,
    y: (p.y + 0.5) * 100
  }));

  if (route.length < 2) {
    done();
    return;
  }

  // Panjang setiap segmen dan jarak kumulatif.
  const cumulative = [0];

  for (let i = 1; i < route.length; i++) {
    const dx = route[i].x - route[i - 1].x;
    const dy = route[i].y - route[i - 1].y;

    cumulative[i] =
      cumulative[i - 1] + Math.hypot(dx, dy);
  }

  const bodyLength = cumulative[cumulative.length - 1];
  const headStart = cumulative[cumulative.length - 1];

  // Perpanjang jalur lurus melewati kepala panah.
  const extraDistance = 1800;

  const stepX = direction.x * 100;
  const stepY = direction.y * 100;

  const extraSteps = Math.ceil(extraDistance / 100);

  for (let i = 1; i <= extraSteps; i++) {
    const previous = route[route.length - 1];

    route.push({
      x: previous.x + stepX,
      y: previous.y + stepY
    });

    cumulative.push(
      cumulative[cumulative.length - 1] + 100
    );
  }

  // Ambil titik pada jalur berdasarkan jarak.
  function pointAt(distance) {
    distance = Math.max(
      0,
      Math.min(distance, cumulative[cumulative.length - 1])
    );

    for (let i = 1; i < cumulative.length; i++) {
      if (distance <= cumulative[i]) {
        const start = route[i - 1];
        const end = route[i];

        const segmentLength =
          cumulative[i] - cumulative[i - 1];

        const t = segmentLength
          ? (distance - cumulative[i - 1]) / segmentLength
          : 0;

        return {
          x: start.x + (end.x - start.x) * t,
          y: start.y + (end.y - start.y) * t
        };
      }
    }

    return { ...route[route.length - 1] };
  }

  // Gambar badan sebagai bagian jalur di belakang kepala.
  function makeBodyPath(startDistance, endDistance) {
    const points = [pointAt(startDistance)];

    for (let i = 1; i < route.length - 1; i++) {
      if (
        cumulative[i] > startDistance + 0.01 &&
        cumulative[i] < endDistance - 0.01
      ) {
        points.push(route[i]);
      }
    }

    points.push(pointAt(endDistance));

    return points.map((p, i) =>
      `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`
    ).join(" ");
  }

  const halfWidth = 16;
  const px = -direction.y * halfWidth;
  const py = direction.x * halfWidth;

  const duration = 850;
  const travelDistance = 900 + bodyLength;
  const startTime = performance.now();

  group.style.pointerEvents = "none";
  group.classList.remove("hint", "blocked");

  function frame(now) {
    const t = Math.min(1, (now - startTime) / duration);

    // Gerakan cepat di awal, lalu melambat.
    const eased = 1 - Math.pow(1 - t, 2);

    const headDistance =
      headStart + travelDistance * eased;

    const bodyStart = Math.max(
      0,
      headDistance - bodyLength
    );

    // Badan mengikuti jalur asli, termasuk setiap belokan.
    shaft.setAttribute(
      "d",
      makeBodyPath(bodyStart, headDistance)
    );

    // Kepala terus bergerak lurus ke arah keluar.
    const p = pointAt(headDistance);

    head.setAttribute("points", [
      `${p.x + direction.x * 34},${p.y + direction.y * 34}`,
      `${p.x - direction.x * 9 + px},${p.y - direction.y * 9 + py}`,
      `${p.x - direction.x * 9 - px},${p.y - direction.y * 9 - py}`
    ].join(" "));

    // Hilangkan panah hanya saat animasi hampir selesai.
    group.style.opacity = String(
      t < 0.82 ? 1 : Math.max(0, (1 - t) / 0.18)
    );

    if (t < 1) {
      requestAnimationFrame(frame);
    } else {
      done();
    }
  }

  requestAnimationFrame(frame);
}

function tapArrow(id) {
  if (busy || paused || gameEnded) return;

  const arrow = arrows.find(a => a.id === id);
  if (!arrow) return;

  const group = document.querySelector(
    `.arrow-group[data-arrow-id="${id}"]`
  );

  if (!canExit(arrow)) {
    blockedEffect(group);
    return;
  }

  saveHistory();
  busy = true;
  updateUI();
  playMP3("arrow");

  const oldHead = { ...arrow.head };
  const direction = DIRS[arrow.dir];

  clearTimeout(transitionTimer);

  animateArrowExit(group, direction, () => {
    arrows = arrows.filter(a => a.id !== id);

    score += 100 + level * 10;

    createParticles(oldHead.x, oldHead.y);

    busy = false;
    render();

    if (arrows.length === 0) {
      levelComplete();
    }
  });
}


/* ---------- BLOCKED / HP ---------- */

function blockedEffect(group) {
  if (busy || paused || gameEnded) return;

  if (group) {
    group.classList.remove("blocked");
    void group.getBoundingClientRect();
    group.classList.add("blocked");

    setTimeout(() => {
      group.classList.remove("blocked");
    }, 420);
  }

  const wrap = $("boardWrap");
  const flash = $("boardFlash");

  if (wrap) {
    wrap.classList.remove("shake");
    void wrap.offsetWidth;
    wrap.classList.add("shake");

    setTimeout(() => wrap.classList.remove("shake"), 420);
  }

  if (flash) {
    flash.classList.remove("flash");
    void flash.offsetWidth;
    flash.classList.add("flash");

    setTimeout(() => flash.classList.remove("flash"), 420);
  }

  hp = Math.max(0, hp - 1);

  const heart = $("hearts")?.children[hp];

  if (heart) {
    heart.classList.remove("lost");
    void heart.offsetWidth;
    heart.classList.add("lost");
  }

  updateUI();
  toast("Terhalang! HP berkurang.");

  if (hp <= 0) {
    gameEnded = true;

    setTimeout(() => {
      gameOver();
    }, 350);
  }
}

/* ---------- PARTICLES ---------- */

function createParticles(x, y) {
  const layer = $("particles");
  const board = $("board");

  if (!layer || !board) return;

  const cellSize = board.clientWidth / SIZE;

  for (let i = 0; i < 9; i++) {
    const particle = document.createElement("span");

    particle.className = "particle";
    particle.style.left = (x + 0.5) * cellSize + "px";
    particle.style.top = (y + 0.5) * cellSize + "px";

    particle.style.setProperty(
      "--px",
      (Math.random() * 70 - 35) + "px"
    );

    particle.style.setProperty(
      "--py",
      (Math.random() * 70 - 35) + "px"
    );

    layer.appendChild(particle);

    setTimeout(() => particle.remove(), 700);
  }
}

/* ---------- HINT ---------- */

function useHint() {
  if (busy || paused || gameEnded) return;

  if (hintCount <= 0) {
    return toast("Hint sudah habis.");
  }

  const arrow = arrows.find(canExit);

  if (!arrow) {
    return toast("Tidak ditemukan jalur aman.");
  }

  hintCount--;

  const group = document.querySelector(
    `.arrow-group[data-arrow-id="${arrow.id}"]`
  );

  if (group) {
    group.classList.add("hint");

    setTimeout(() => {
      group.classList.remove("hint");
    }, 1800);
  }

  updateUI();
  toast("Tap panah yang menyala.");
}

/* ---------- RESTART ---------- */

function restartLevel() {
  if (busy) return;

  clearTimeout(transitionTimer);

  $("menuOverlay")?.classList.add("hidden");
  $("messageOverlay")?.classList.add("hidden");

  hp = 3;
  hintCount = 3;
  history = [];
  busy = false;
  paused = false;
  gameEnded = false;

  generatePuzzle();
  render();

  toast("Level dimulai ulang.");
}

/* ---------- LEVEL COMPLETE ---------- */

function levelComplete() {
  busy = false;
  gameEnded = true;

  const bonus = 200 + level * 50;

  score += bonus;
  saveProgress();

  playMP3("complete");

  if ($("resultIcon")) $("resultIcon").textContent = "🏆";
  if ($("resultTitle")) $("resultTitle").textContent = "LEVEL COMPLETE!";

  if ($("resultDesc")) {
    $("resultDesc").textContent =
      "Semua panah berhasil dikeluarkan.";
  }

  if ($("resultScore")) {
    $("resultScore").textContent = "+" + bonus;
  }

  $("nextBtn")?.classList.remove("hidden");
  $("retryBtn")?.classList.add("hidden");
  $("messageOverlay")?.classList.remove("hidden");

  updateUI();
}

/* ---------- GAME OVER ---------- */

function gameOver() {
  busy = false;
  gameEnded = true;

  playMP3("gameover");

  if ($("resultIcon")) $("resultIcon").textContent = "💔";
  if ($("resultTitle")) $("resultTitle").textContent = "GAME OVER";

  if ($("resultDesc")) {
    $("resultDesc").textContent =
      "Nyawamu habis. Coba lagi!";
  }

  if ($("resultScore")) {
    $("resultScore").textContent = score;
  }

  $("nextBtn")?.classList.add("hidden");
  $("retryBtn")?.classList.remove("hidden");
  $("messageOverlay")?.classList.remove("hidden");

  updateUI();
}

/* ---------- INFINITE LEVEL ---------- */

function nextLevel() {
  if (busy) return;

  level++;

  hp = 3;
  hintCount = 3;
  history = [];
  paused = false;
  gameEnded = false;

  $("messageOverlay")?.classList.add("hidden");

  generatePuzzle();
  render();
  saveProgress();

  toast("Level " + level + " dimulai!");
}

/* ---------- MENU ---------- */

function showMenu() {
  if (busy || gameEnded) return;

  paused = true;

  $("menuOverlay")?.classList.remove("hidden");

  updateUI();
}

function closeMenu() {
  paused = false;

  $("menuOverlay")?.classList.add("hidden");

  updateUI();
}

/* ---------- BUTTONS ---------- */

function bind(id, event, callback) {
  const element = $(id);
  if (element) element.addEventListener(event, callback);
}

bind("hintBtn", "click", () => {
  unlockAudio();
  useHint();
});

bind("undoBtn", "click", undo);
bind("restartBtn", "click", restartLevel);
bind("menuBtn", "click", showMenu);
bind("closeMenu", "click", closeMenu);
bind("continueBtn", "click", closeMenu);
bind("menuRestartBtn", "click", restartLevel);
bind("nextBtn", "click", nextLevel);
bind("retryBtn", "click", restartLevel);

bind("howBtn", "click", () => {
  toast("Keluarkan panah yang jalurnya kosong.");
});

bind("soundBtn", "click", () => {
  soundOn = !soundOn;

  $("soundBtn").textContent = soundOn ? "♫" : "♪";

  toast(soundOn ? "Suara aktif" : "Suara nonaktif");

  if (soundOn) {
    unlockAudio();
    playMP3("arrow");
  }
});

/* ---------- START ---------- */

loadProgress();
generatePuzzle();
render();
