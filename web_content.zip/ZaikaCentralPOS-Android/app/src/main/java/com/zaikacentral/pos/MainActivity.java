package com.zaikacentral.pos;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setSupportMultipleWindows(true);
        webView.addJavascriptInterface(new AndroidPrinter(this), "AndroidPrinter");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public static class AndroidPrinter {
        private final Activity activity;
        AndroidPrinter(Activity activity) { this.activity = activity; }

        @JavascriptInterface public void printHtml(String title, String html) {
            activity.runOnUiThread(() -> {
                WebView printView = new WebView(activity);
                printView.getSettings().setJavaScriptEnabled(false);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                        String jobName = (title == null || title.trim().isEmpty()) ? "Zaika Central receipt" : title;
                        manager.print(jobName, view.createPrintDocumentAdapter(jobName),
                                new PrintAttributes.Builder()
                                        .setMediaSize(new PrintAttributes.MediaSize("thermal80", "80mm Thermal", 3150, 11000))
                                        .setResolution(new android.print.PrintAttributes.Resolution("thermal", "Thermal", 203, 203))
                                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                        .build());
                        Toast.makeText(activity, "Print job ready: " + jobName, Toast.LENGTH_SHORT).show();
                    }
                });
                String page = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'><style>body{font:14px monospace;padding:8px;color:#000;background:#fff}h2{text-align:center}hr{border:0;border-top:1px dashed #333}table{width:100%}td{padding:4px 0}.r{text-align:right}.c{text-align:center}</style></head><body>" + (html == null ? "" : html) + "</body></html>";
                printView.loadDataWithBaseURL("file:///android_asset/", page, "text/html", "UTF-8", null);
            });
        }
    }
}
