ZAIKA CENTRAL POS — FREE ANDROID STUDIO PROJECT

This is a free Android WebView project containing your supplied Zaika Central POS HTML.
It includes a native Android print bridge so KOT PRINT and BILL PRINT create separate Android print jobs.

BUILD THE APK FOR FREE
1. Install Android Studio (free) on a Windows, Mac, or Linux computer.
2. Open this folder: ZaikaCentralPOS-Android
3. Allow Android Studio to install the Android SDK Platform 35 and Gradle dependencies if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will create the APK at:
   app/build/outputs/apk/debug/app-debug.apk
6. Copy that APK to your Android phone and install it. If Android asks, allow installation from that file manager.

NOTES
- The app stores POS data in WebView local storage on the device.
- Android's print screen lets you choose an installed printer/service. Actual printer availability depends on your phone and printer connection (Wi-Fi, Bluetooth print service, or USB support).
- The print bridge sends KOT and bill as separate print jobs; it does not silently select a printer by name.
- Keep a backup/export of business data. This is a starter WebView app, not a cloud-synced multi-device POS.
