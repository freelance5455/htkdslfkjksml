const fs = require('fs');
let code = fs.readFileSync('src/components/OwnerUpdateView.tsx', 'utf8');

const target = `  const handlePromptInstallWallet = (walletName: string) => {
    window.open("https://play.google.com/store/search?q=crypto+wallet&c=apps", "_blank");
    alert(\`Prompting Google Play Store & Apple App Store to install \${walletName} for juhnkrix@gmail.com. Once installed, it will automatically link to JUHNKRIX MUSIKA.\`);
  };
        <div className="space-y-3 z-10 text-center md:text-left">`;

const replacement = `  const handlePromptInstallWallet = (walletName: string) => {
    window.open("https://play.google.com/store/search?q=crypto+wallet&c=apps", "_blank");
    alert(\`Prompting Google Play Store & Apple App Store to install \${walletName} for juhnkrix@gmail.com. Once installed, it will automatically link to JUHNKRIX MUSIKA.\`);
  };

  return (
    <div className="space-y-10 animate-fadeIn">
      <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-950 p-6 sm:p-10 rounded-3xl border border-amber-500/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-3 z-10 text-center md:text-left">`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/OwnerUpdateView.tsx', code);
  console.log("Patched start");
} else {
  console.log("Target not found");
}
