
(function () {
    "use strict";

    var API_URL = "http://127.0.0.1:9931/v1/chat/completions";
    var MODEL_NAME = "Qwen2.5-1.5B-Instruct";

    var form = document.getElementById("messageForm");
    var input = document.getElementById("messageInput");
    var sendButton = document.getElementById("sendButton");
    var messages = document.getElementById("chatMessages");
    var status = document.getElementById("connectionStatus");

    var settingsButton = document.getElementById("settingsButton");
    var settingsPanel = document.getElementById("settingsPanel");
    var chatPanel = document.getElementById("chatPanel");
    var closeSettingsButton = document.getElementById("closeSettingsButton");
    var settingsContent = document.getElementById("settingsContent");

    var history = [];
    var evaMemory = [];
    var trainingExamples = [];
    var busy = false;

    var baseInstructions =
        "Тебя зовут Ева. Ты виртуальная помощница женского пола. " +
        "Говори о себе в женском роде: рада, готова, поняла. " +
        "Обращайся к пользователю на ты. Его зовут Денис, он твой создатель. " +
        "Отвечай естественно, грамотно и по-русски. " +
        "Не выдумывай факты и воспоминания. " +
        "Если не знаешь ответа, честно скажи об этом. " +
        "Учитывай сохранённую память и примеры обучения.";

    function setStatus(text) {
        status.textContent = text;
    }

    function readStorage(key) {
        try {
            return localStorage.getItem(key);
        } catch (error) {
            return null;
        }
    }

    function writeStorage(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            setStatus("Не удалось сохранить данные");
            return false;
        }
    }

    function saveHistory() {
        writeStorage("eva_chat_history", history);
    }

    function saveEvaMemory() {
        writeStorage("eva_memory", evaMemory);
    }

    function saveTraining() {
        writeStorage("eva_training_examples", trainingExamples);
    }

    function loadData() {
        var saved;
        var i;
        var item;

        saved = readStorage("eva_chat_history");

        try {
            if (saved) {
                saved = JSON.parse(saved);
                if (Array.isArray(saved)) {
                    history = saved;
                }
            }
        } catch (error) {
            history = [];
        }

        saved = readStorage("eva_memory");

        try {
            if (saved) {
                saved = JSON.parse(saved);
                if (Array.isArray(saved)) {
                    evaMemory = saved;
                }
            }
        } catch (error) {
            evaMemory = [];
        }

        saved = readStorage("eva_training_examples");

        try {
            if (saved) {
                saved = JSON.parse(saved);
                if (Array.isArray(saved)) {
                    trainingExamples = saved;
                }
            }
        } catch (error) {
            trainingExamples = [];
        }

        for (i = 0; i < history.length; i++) {
            item = history[i];

            if (
                item &&
                (item.role === "user" || item.role === "assistant") &&
                typeof item.content === "string"
            ) {
                renderMessage(item.role, item.content);
            }
        }

        if (history.length > 0) {
            messages.scrollTop = messages.scrollHeight;
        }
    }

    function renderMessage(role, text) {
        var wrapper = document.createElement("div");
        var name = document.createElement("strong");
        var paragraph = document.createElement("p");

        wrapper.className = "message " +
            (role === "user" ? "user-message" : "eva-message");

        name.textContent = role === "user" ? "Ты" : "Ева";
        paragraph.textContent = text;

        wrapper.appendChild(name);
        wrapper.appendChild(paragraph);
        messages.appendChild(wrapper);

        messages.scrollTop = messages.scrollHeight;
    }

    function addMessage(role, text, save) {
        renderMessage(role, text);

        if (save) {
            history.push({
                role: role,
                content: text
            });

            saveHistory();
        }
    }

    function rememberFact(question, answer) {
        question = String(question || "").trim();
        answer = String(answer || "").trim();

        if (!question || !answer) {
            return false;
        }

        evaMemory.push({
            question: question,
            answer: answer
        });

        saveEvaMemory();
        return true;
    }

    function addTrainingExample(question, answer) {
        question = String(question || "").trim();
        answer = String(answer || "").trim();

        if (!question || !answer) {
            return false;
        }

        trainingExamples.push({
            question: question,
            answer: answer
        });

        saveTraining();
        return true;
    }

    function buildSystemPrompt() {
        var prompt = baseInstructions;
        var i;
        var fact;
        var example;

        if (evaMemory.length > 0) {
            prompt += "\n\nСОХРАНЁННЫЕ ФАКТЫ:\n";

            for (i = 0; i < evaMemory.length; i++) {
                fact = evaMemory[i];

                if (fact && fact.question && fact.answer) {
                    prompt += "Вопрос: " + fact.question +
                        "\nФакт: " + fact.answer + "\n";
                }
            }
        }

        if (trainingExamples.length > 0) {
            prompt += "\nПРИМЕРЫ ПРАВИЛЬНЫХ ОТВЕТОВ:\n";

            for (i = Math.max(0, trainingExamples.length - 8);
                i < trainingExamples.length; i++) {
                example = trainingExamples[i];

                if (example && example.question && example.answer) {
                    prompt += "Ситуация: " + example.question +
                        "\nПравильный ответ: " + example.answer + "\n";
                }
            }

            prompt +=
                "Используй примеры как образцы поведения, " +
                "но отвечай по смыслу текущего вопроса.\n";
        }

        return prompt;
    }

    function finishRequest() {
        busy = false;
        sendButton.disabled = false;
        sendButton.textContent = "➤";
    }

    function sendMessage(event) {
        var text;
        var xhr;
        var requestMessages;
        var i;
        var item;
        var response;
        var answer;

        if (event) {
            event.preventDefault();
        }

        if (busy) {
            return;
        }

        text = input.value.replace(/^\s+|\s+$/g, "");

        if (!text) {
            return;
        }

        addMessage("user", text, true);
        input.value = "";

        busy = true;
        sendButton.disabled = true;
        sendButton.textContent = "...";
        setStatus("Ева думает...");

        requestMessages = [{
            role: "system",
            content: buildSystemPrompt()
        }];

        for (i = Math.max(0, history.length - 12);
            i < history.length; i++) {
            item = history[i];

            if (
                item &&
                (item.role === "user" || item.role === "assistant") &&
                typeof item.content === "string"
            ) {
                requestMessages.push({
                    role: item.role,
                    content: item.content
                });
            }
        }

        xhr = new XMLHttpRequest();

        xhr.open("POST", API_URL, true);
        xhr.timeout = 120000;
        xhr.setRequestHeader("Content-Type", "application/json");

        xhr.onreadystatechange = function () {
            if (xhr.readyState !== 4) {
                return;
            }

            finishRequest();

            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    response = JSON.parse(xhr.responseText);

                    if (
                        response.choices &&
                        response.choices[0] &&
                        response.choices[0].message
                    ) {
                        answer = response.choices[0].message.content;
                    } else {
                        answer = "";
                    }

                    if (typeof answer === "string" && answer.length > 0) {
                        addMessage("assistant", answer, true);
                        setStatus("Qwen подключён");
                    } else {
                        setStatus("Пустой ответ модели");
                        addMessage(
                            "assistant",
                            "Модель вернула пустой ответ. Попробуй ещё раз.",
                            false
                        );
                    }
                } catch (error) {
                    setStatus("Ошибка чтения ответа");
                    addMessage(
                        "assistant",
                        "Не удалось прочитать ответ сервера.",
                        false
                    );
                }
            } else {
                setStatus("Ошибка сервера: " + xhr.status);
                addMessage(
                    "assistant",
                    "Ошибка сервера " + xhr.status + ". Проверь Termux.",
                    false
                );
            }
        };

        xhr.onerror = function () {
            finishRequest();
            setStatus("Нет соединения с Qwen");

            addMessage(
                "assistant",
                "Не удалось связаться с Qwen. Проверь, запущен ли сервер.",
                false
            );
        };

        xhr.ontimeout = function () {
            finishRequest();
            setStatus("Истекло время ожидания");

            addMessage(
                "assistant",
                "Ответ не пришёл вовремя. Попробуй ещё раз.",
                false
            );
        };

        try {
            xhr.send(JSON.stringify({
                model: MODEL_NAME,
                messages: requestMessages,
                temperature: 0.5,
                max_tokens: 400,
                stream: false
            }));
        } catch (error) {
            finishRequest();
            setStatus("Не удалось отправить запрос");
        }
    }

    function showSettings(section) {
        var content;
        var i;
        var fact;
        var example;
        var button;
        var questionInput;
        var answerInput;
        var saveButton;
        var clearButton;

        settingsContent.textContent = "";

        if (section === "memory") {
            content = document.createElement("div");

            var memoryTitle = document.createElement("h3");
            memoryTitle.textContent = "Постоянная память";
            content.appendChild(memoryTitle);

            var memoryInfo = document.createElement("p");
            memoryInfo.textContent =
                "Сохранённых фактов: " + evaMemory.length;
            content.appendChild(memoryInfo);

            for (i = 0; i < evaMemory.length; i++) {
                fact = evaMemory[i];

                var factBox = document.createElement("p");
                factBox.textContent =
                    "Вопрос: " + fact.question +
                    "\nОтвет: " + fact.answer;

                content.appendChild(factBox);

                var deleteFactButton = document.createElement("button");
                deleteFactButton.textContent = "Удалить факт " + (i + 1);
                deleteFactButton.setAttribute("data-delete-fact", String(i));
                content.appendChild(deleteFactButton);
            }

            questionInput = document.createElement("input");
            questionInput.placeholder = "Что нужно запомнить?";

            answerInput = document.createElement("input");
            answerInput.placeholder = "Правильный факт";

            saveButton = document.createElement("button");
            saveButton.textContent = "Сохранить факт";

            saveButton.addEventListener("click", function () {
                if (rememberFact(questionInput.value, answerInput.value)) {
                    showSettings("memory");
                    setStatus("Факт сохранён");
                }
            });

            content.appendChild(questionInput);
            content.appendChild(answerInput);
            content.appendChild(saveButton);

            clearButton = document.createElement("button");
            clearButton.textContent = "Очистить всю память";

            clearButton.addEventListener("click", function () {
                if (window.confirm("Удалить все сохранённые факты?")) {
                    evaMemory = [];
                    saveEvaMemory();
                    showSettings("memory");
                }
            });

            content.appendChild(clearButton);
            settingsContent.appendChild(content);

            var deleteButtons = content.querySelectorAll("[data-delete-fact]");

            for (i = 0; i < deleteButtons.length; i++) {
                deleteButtons[i].addEventListener("click", function () {
                    var index = Number(this.getAttribute("data-delete-fact"));
                    evaMemory.splice(index, 1);
                    saveEvaMemory();
                    showSettings("memory");
                });
            }

            return;
        }

        if (section === "training") {
            content = document.createElement("div");

            var trainingTitle = document.createElement("h3");
            trainingTitle.textContent = "Обучение на примерах";
            content.appendChild(trainingTitle);

            var trainingInfo = document.createElement("p");
            trainingInfo.textContent =
                "Сохранённых примеров: " + trainingExamples.length;
            content.appendChild(trainingInfo);

            for (i = 0; i < trainingExamples.length; i++) {
                example = trainingExamples[i];

                var exampleBox = document.createElement("p");
                exampleBox.textContent =
                    "Ситуация: " + example.question +
                    "\nПравильный ответ: " + example.answer;

                content.appendChild(exampleBox);

                var deleteExampleButton = document.createElement("button");
                deleteExampleButton.textContent =
                    "Удалить пример " + (i + 1);
                deleteExampleButton.setAttribute(
                    "data-delete-example",
                    String(i)
                );
                content.appendChild(deleteExampleButton);
            }

            questionInput = document.createElement("input");
            questionInput.placeholder = "Ситуация или вопрос";

            answerInput = document.createElement("input");
            answerInput.placeholder = "Как Ева должна ответить";

            saveButton = document.createElement("button");
            saveButton.textContent = "Сохранить пример";

            saveButton.addEventListener("click", function () {
                if (addTrainingExample(
                    questionInput.value,
                    answerInput.value
                )) {
                    showSettings("training");
                    setStatus("Пример сохранён");
                }
            });

            content.appendChild(questionInput);
            content.appendChild(answerInput);
            content.appendChild(saveButton);

            clearButton = document.createElement("button");
            clearButton.textContent = "Очистить обучение";

            clearButton.addEventListener("click", function () {
                if (window.confirm("Удалить все примеры обучения?")) {
                    trainingExamples = [];
                    saveTraining();
                    showSettings("training");
                }
            });

            content.appendChild(clearButton);
            settingsContent.appendChild(content);

            var exampleButtons = content.querySelectorAll(
                "[data-delete-example]"
            );

            for (i = 0; i < exampleButtons.length; i++) {
                exampleButtons[i].addEventListener("click", function () {
                    var index = Number(
                        this.getAttribute("data-delete-example")
                    );

                    trainingExamples.splice(index, 1);
                    saveTraining();
                    showSettings("training");
                });
            }

            return;
        }

        var descriptions = {
            voice: "Голосовое озвучивание добавим отдельным этапом.",
            character:
                "Ева использует женский род и русскоязычный стиль общения. " +
                "Портрет находится в файле Ева.jpg.",
            system:
                "Адрес Qwen: " + API_URL +
                "\nМодель: " + MODEL_NAME +
                "\nФакты памяти: " + evaMemory.length +
                "\nПримеры обучения: " + trainingExamples.length
        };

        settingsContent.textContent =
            descriptions[section] || "Выбери раздел настроек.";
    }

    form.addEventListener("submit", sendMessage);

    input.addEventListener("keydown", function (event) {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();

            if (form.requestSubmit) {
                form.requestSubmit();
            } else {
                sendMessage(event);
            }
        }
    });

    settingsButton.addEventListener("click", function () {
        chatPanel.hidden = true;
        settingsPanel.hidden = false;
    });

    closeSettingsButton.addEventListener("click", function () {
        settingsPanel.hidden = true;
        chatPanel.hidden = false;
    });

    var menuButtons = document.querySelectorAll("[data-section]");
    var i;

    for (i = 0; i < menuButtons.length; i++) {
        menuButtons[i].addEventListener("click", function () {
            showSettings(this.getAttribute("data-section"));
        });
    }

    loadData();
    setStatus("Ожидание подключения к Qwen");

    window.addEventListener("error", function () {
        setStatus("Ошибка JavaScript");
    });
})();
