LUMORA STUDY 5.5 — ONLINE/OFFLINE PACKAGE
========================================

CONTENTS
- index.html, app.js, data.js, style.css: the study app
- sw.js, manifest.json, icon.svg: install/offline support
- questions.json: online question-update feed

STARTING THE APP
1. Extract this ZIP.
2. For full install/offline support, upload the lumora-study-app folder to an HTTPS static host.
3. Open the HTTPS address once while online, then use your browser's Add to Home Screen / Install option.
4. After the first successful load, the app shell and question feed are cached for offline use.

QUESTION UPDATES
- Keep existing course questions in data.js. The app does not generate questions from notes.
- To publish new questions, update questions.json on the same HTTPS host.
- The JSON format is:
  {
    "version": 1,
    "updated": "YYYY-MM-DD",
    "questions": [
      {"q":"Question text","a":"Answer text","c":"COS 101","p":1}
    ]
  }
- c is the course code. p: 1 marks a past-question-style item; omit or use 0 for general practice.
- The app checks this feed when it starts online and when the connection returns.
- New questions are deduplicated by question text, stored on the device, and remain available offline.
- This ZIP contains an empty feed template because no external question-feed URL or question provider was supplied. Publishing a populated questions.json file on the same host enables automatic downloads.

NOTES
- The old built-in course-note collection has been removed from this package.
- Existing course practice questions and CBT multiple-choice questions remain.
- The old course-note-derived question generator has been removed.
- The personal notepad remains separate. Course materials are now uploaded and managed as PDF documents inside each course.
- On first launch after upgrading, the app clears the old course-note collection and related note progress once. The personal notepad is preserved.

PRIVACY / STORAGE
Study progress, personal notepad content, added questions, downloaded question updates and uploaded course files are stored locally in the browser on the device. Clearing browser site data may remove local records.

COURSE PDF LIBRARY
- Open Library and choose a course.
- Use Add PDF documents to select one or more PDF files from your phone.
- Open or remove uploaded PDFs from that course.
- PDFs are stored in this browser on this device and remain available offline after upload.
