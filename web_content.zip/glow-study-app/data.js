// ===== TIMETABLE (from your 100L timetable). d: 1=Mon..5=Fri, s/e = 24h hours =====
const TT=[
{d:1,c:'COS 101',s:15,e:16,v:'MPH'},{d:1,c:'LMU-ADC 111',s:16,e:18,v:'Eng. Workshop'},
{d:2,c:'LMU-COS 111',s:8,e:10,v:'LT 1'},{d:2,c:'STA 111',s:10,e:12,v:'LT 2'},{d:2,c:'LMU-TMC 111',s:15,e:16,v:'MPH'},
{d:3,c:'PHY 101',s:8,e:10,v:'MPH'},{d:3,c:'GST 111',s:10,e:12,v:'MPH'},{d:3,c:'LMU-EDS 111',s:13,e:14,v:'MPH'},{d:3,c:'PHY 107',s:15,e:18,v:'PHY Lab G'},
{d:4,c:'MTH 101',s:10,e:12,v:'MPH'},{d:4,c:'LMU-CST 111',s:16,e:18,v:'MPH'},
{d:5,c:'COS 101',s:10,e:12,v:'MPH'}];
// ===== COURSE LIBRARY. Edit titles/add content freely. p:1 = past-question style =====
const COURSES=[
{code:'COS 101',title:'Introduction to Computer Science',sem:1,units:3,

mcq:[
{q:'Which generation of computers used vacuum tubes?',o:['First','Second','Third','Fourth'],a:0},
{q:'The "brain" of the computer is the:',o:['RAM','CPU','Hard disk','Monitor'],a:1},
{q:'Who is regarded as the first computer programmer?',o:['Alan Turing','Charles Babbage','Ada Lovelace','Pascal'],a:2},
{q:'1011 in binary equals what in decimal?',o:['9','10','11','12'],a:2},
{q:'Which memory is volatile?',o:['ROM','RAM','Hard disk','Flash drive'],a:1},
{q:'Which translator converts the whole program at once?',o:['Interpreter','Compiler','Assembler','Linker'],a:1},
{q:'Which converts domain names to IP addresses?',o:['HTTP','DNS','FTP','SMTP'],a:1},
{q:'Hexadecimal F equals what in decimal?',o:['14','15','16','17'],a:1},
{q:'The smallest unit of data is the:',o:['Byte','Nibble','Bit','Word'],a:2},
{q:'Which component performs arithmetic and logic operations?',o:['CU','ALU','Cache','Register'],a:1}],
qs:[
{q:'Distinguish between a compiler and an interpreter.',a:'A compiler translates the entire source program into machine code before execution; an interpreter translates and executes one statement at a time. Compiled programs run faster; interpreters give easier debugging.',p:1},
{q:'Convert 25 (decimal) to binary.',a:'11001'},
{q:'List four generations of computers with their key technology.',a:'1st vacuum tubes; 2nd transistors; 3rd integrated circuits; 4th microprocessors.',p:1},
{q:'State the functions of the ALU and the Control Unit.',a:'ALU performs arithmetic and logical operations; the Control Unit fetches, decodes and coordinates execution of instructions.'},
{q:'Differentiate between RAM and ROM.',a:'RAM is volatile read/write working memory; ROM is non-volatile and holds permanent start-up instructions.',p:1}]},
{code:'LMU-COS 111',title:'Introduction to Problem Solving & Programming',sem:1,units:3,

mcq:[
{q:'A step-by-step procedure for solving a problem is a(n):',o:['Program','Algorithm','Compiler','Variable'],a:1},
{q:'Which flowchart symbol represents a decision?',o:['Rectangle','Oval','Diamond','Parallelogram'],a:2},
{q:'Which loop always runs at least once?',o:['for','while','do-while','if'],a:2},
{q:'Which of these is NOT a data type?',o:['Integer','Float','String','Loop'],a:3},
{q:'The value of 7 % 3 is:',o:['2','1','0','3'],a:1},
{q:'In most languages the first array index is:',o:['0','1','-1','2'],a:0},
{q:'The parallelogram in a flowchart stands for:',o:['Process','Decision','Input/Output','Start'],a:2},
{q:'Pseudocode is:',o:['Machine code','An informal description of an algorithm','A compiler','A language'],a:1}],
qs:[
{q:'Write an algorithm to find the sum of the first 10 natural numbers.',a:'1. sum=0  2. for i from 1 to 10: sum=sum+i  3. print sum (answer 55).',p:1},
{q:'State three advantages of using functions.',a:'Code reuse, easier debugging/maintenance, improved readability and modular design.'},
{q:'Differentiate between while and do-while loops.',a:'while tests the condition first (may never run); do-while runs the body first, then tests (at least once).',p:1}]},
{code:'MTH 101',title:'General Mathematics I (Algebra & Trigonometry)',sem:1,units:3,

mcq:[
{q:'log10(1000) =',o:['2','3','4','10'],a:1},
{q:'Roots of x^2-5x+6=0 are:',o:['1 and 6','2 and 3','-2 and -3','5 and 1'],a:1},
{q:'a^m x a^n =',o:['a^(mn)','a^(m+n)','a^(m-n)','2a^m'],a:1},
{q:'sin^2(t)+cos^2(t) =',o:['0','1','2','tan t'],a:1},
{q:'Sum of roots of ax^2+bx+c=0 is:',o:['b/a','-b/a','c/a','-c/a'],a:1},
{q:'If U={1,...,10} and A={2,4,6}, n(A\') is:',o:['3','7','10','6'],a:1},
{q:'x^0 (x not 0) equals:',o:['0','x','1','undefined'],a:2},
{q:'sin 30 degrees =',o:['1','1/2','0','root3/2'],a:1}],
qs:[
{q:'Solve 2x^2 - 7x + 3 = 0.',a:'(2x-1)(x-3)=0 so x=1/2 or x=3.',p:1},
{q:'Simplify log 8 + log 125.',a:'log(8x125)=log 1000=3 (base 10).'},
{q:'In a class of 40, 25 take Maths, 20 take Physics, 5 take neither. How many take both?',a:'n(M or P)=35; both=25+20-35=10.',p:1}]},
{code:'PHY 101',title:'General Physics I (Mechanics)',sem:1,units:3,

mcq:[
{q:'SI unit of force is the:',o:['Joule','Newton','Watt','Pascal'],a:1},
{q:'Dimension of velocity is:',o:['LT','LT^-1','L^2T^-1','MLT^-2'],a:1},
{q:'Newton\'s second law states:',o:['F=mv','F=ma','F=m/a','F=a/m'],a:1},
{q:'A body from rest with a=2 m/s^2 travels how far in 5 s?',o:['10 m','25 m','50 m','5 m'],a:1},
{q:'SI unit of work is the:',o:['Watt','Newton','Joule','Hertz'],a:2},
{q:'Angle for maximum projectile range:',o:['30','45','60','90'],a:1},
{q:'Power equals:',o:['Work x time','Work / time','Force x time','Mass x g'],a:1},
{q:'Kinetic energy formula:',o:['mgh','1/2 mv^2','mv','Fs'],a:1}],
qs:[
{q:'A car accelerates from 10 m/s to 30 m/s in 5 s. Find acceleration and distance.',a:'a=(30-10)/5=4 m/s^2; s=(10+30)/2 x 5 = 100 m.',p:1},
{q:'Derive the dimension of force.',a:'F=ma gives M x LT^-2 = MLT^-2.'},
{q:'A 2 kg mass is lifted 5 m. Find the potential energy (g=10).',a:'PE=mgh=2x10x5=100 J.',p:1}]},
{code:'STA 111',title:'Descriptive Statistics & Probability',sem:1,units:3,

mcq:[
{q:'Mean of 2,4,6,8 is:',o:['4','5','6','20'],a:1},
{q:'Median of 3,1,4,2,5 is:',o:['2','3','4','5'],a:1},
{q:'The mode is the:',o:['Middle value','Average','Most frequent value','Range'],a:2},
{q:'Range of 3,9,5,12 is:',o:['9','12','3','7'],a:0},
{q:'Probability of a certain event:',o:['0','0.5','1','2'],a:2},
{q:'P(head) for a fair coin:',o:['1','1/2','1/4','0'],a:1},
{q:'Which measure is most affected by outliers?',o:['Mean','Median','Mode','None'],a:0}],
qs:[
{q:'Find the mean, median and mode of 2,3,3,5,7.',a:'Mean=20/5=4; median=3; mode=3.',p:1},
{q:'A die is thrown once. Find P(even number).',a:'3/6 = 1/2.'}]},
{code:'GST 111',title:'Communication in English',sem:1,units:2,

mcq:[
{q:'A noun is the name of a:',o:['Action','Person, place or thing','Quality','Joining word'],a:1},
{q:'Which is a conjunction?',o:['Quickly','But','Beautiful','Under'],a:1},
{q:'Choose the correct sentence:',o:['She sing well','She sings well','She singing well','She sang good'],a:1},
{q:'A topic sentence states a paragraph\'s:',o:['Ending','Main idea','Example','Title'],a:1},
{q:'Antonym of "ancient":',o:['Old','Modern','Huge','Weak'],a:1}],
qs:[{q:'Explain the process of communication.',a:'Sender encodes a message, sends it through a channel, receiver decodes it and gives feedback; noise can disrupt it.',p:1}]},
{code:'PHY 107',title:'Practical Physics I',sem:1,units:1,

mcq:[{q:'Closeness of repeated readings to each other is:',o:['Accuracy','Precision','Error','Mean'],a:1},{q:'Slope of a graph is:',o:['(x2-x1)/(y2-y1)','(y2-y1)/(x2-x1)','y x x','y + x'],a:1}],qs:[]},
{code:'LMU-ADC 111',title:'LMU-ADC 111 (Engineering Workshop)',sem:1,units:2,mcq:[],qs:[]},
{code:'LMU-TMC 111',title:'LMU-TMC 111',sem:1,units:2,mcq:[],qs:[]},
{code:'LMU-EDS 111',title:'LMU-EDS 111',sem:1,units:2,mcq:[],qs:[]},
{code:'LMU-CST 111',title:'LMU-CST 111',sem:1,units:2,mcq:[],qs:[]}
];

// Built-in course notes were intentionally removed. Existing question banks remain intact.
COURSES.forEach(c => { c.notes = []; });
