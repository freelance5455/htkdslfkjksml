const CACHE='lumora-study-shell-v8';
const APP_FILES=['./','./index.html','./style.css','./app.js','./data.js','./manifest.json','./icon.svg','./questions.json'];
self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    await cache.addAll(APP_FILES);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const names=await caches.keys();
    await Promise.all(names.filter(name=>(name.startsWith('glow-study-')||name.startsWith('lumora-study-'))&&name!==CACHE).map(name=>caches.delete(name)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET') return;
  const url=new URL(request.url);
  if(url.origin!==self.location.origin) return;
  if(url.pathname.endsWith('/questions.json')){
    event.respondWith((async()=>{
      const cache=await caches.open(CACHE);
      try{const fresh=await fetch(request,{cache:'no-store'});if(fresh&&fresh.ok)await cache.put('./questions.json',fresh.clone());return fresh;}
      catch(error){return (await cache.match('./questions.json'))||new Response('{\"version\":1,\"questions\":[]}',{headers:{'Content-Type':'application/json'}});}
    })());
    return;
  }
  if(request.mode==='navigate'){
    event.respondWith((async()=>{
      const cache=await caches.open(CACHE);
      try{
        const fresh=await fetch(request);
        if(fresh&&fresh.ok) await cache.put('./index.html',fresh.clone());
        return fresh;
      }catch(error){
        return (await cache.match(request))||(await cache.match('./index.html'))||new Response('Lumora Study is not available offline yet. Open it once while connected to the internet.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});
      }
    })());
    return;
  }
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const cached=await cache.match(request);
    const update=fetch(request).then(response=>{
      if(response&&response.ok) cache.put(request,response.clone());
      return response;
    }).catch(()=>null);
    if(cached){event.waitUntil(update);return cached;}
    const fresh=await update;
    return fresh||new Response('This resource is not available offline.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});
  })());
});
