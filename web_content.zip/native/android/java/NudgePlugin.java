package app.detox.quit;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.text.TextUtils;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.List;

/** The bridge between the Detox screens (JavaScript) and the watching service. */
@CapacitorPlugin(name = "Nudge")
public class NudgePlugin extends Plugin {

    private boolean serviceOn() {
        Context c = getContext();
        try {
            if (Settings.Secure.getInt(c.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) return false;
            String list = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(list)) return false;
            ComponentName me = new ComponentName(c, NudgeService.class);
            String a = me.flattenToString(), b = me.flattenToShortString();
            for (String s : list.split(":")) if (s.equalsIgnoreCase(a) || s.equalsIgnoreCase(b)) return true;
        } catch (Exception e) { /* treat as off */ }
        return false;
    }

    private JSObject snapshot() {
        NudgeEngine e = NudgeEngine.get(getContext());
        JSObject o = new JSObject();
        o.put("accessibility", serviceOn());
        o.put("enabled", e.enabled());
        o.put("builtIn", e.builtIn());
        o.put("taps", e.taps());
        JSArray arr = new JSArray();
        for (String d : e.customList()) arr.put(d);
        o.put("custom", arr);
        return o;
    }

    @PluginMethod
    public void status(PluginCall call) { call.resolve(snapshot()); }

    @PluginMethod
    public void openAccessibility(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("Could not open settings"); }
    }

    @PluginMethod
    public void openAppInfo(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("Could not open settings"); }
    }

    @PluginMethod
    public void setEnabled(PluginCall call) {
        NudgeEngine.get(getContext()).setEnabled(Boolean.TRUE.equals(call.getBoolean("enabled", false)));
        call.resolve(snapshot());
    }

    @PluginMethod
    public void setCustom(PluginCall call) {
        List<String> wanted = new ArrayList<>();
        JSArray arr = call.getArray("domains");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                try { wanted.add(arr.getString(i)); } catch (Exception ignored) { }
            }
        }
        NudgeEngine.get(getContext()).setCustom(wanted);
        call.resolve(snapshot());
    }
}
