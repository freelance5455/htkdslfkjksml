package app.detox.quit;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Shared by the setup screens (plugin) and the watching service: settings, the user's own sites, the packed list. */
final class NudgeEngine {
    private static NudgeEngine inst;

    private final Context app;
    private final SharedPreferences sp;
    final NudgeCore core = new NudgeCore();
    private boolean loaded;

    static synchronized NudgeEngine get(Context c) {
        if (inst == null) inst = new NudgeEngine(c.getApplicationContext());
        return inst;
    }

    private NudgeEngine(Context c) {
        app = c;
        sp = c.getSharedPreferences("detox_nudge", Context.MODE_PRIVATE);
        core.setCustom(customList());
    }

    synchronized void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        try {
            InputStream in = app.getAssets().open("nudge/sites.bin");
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(1024, in.available()));
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                core.loadList(out.toByteArray());
            } finally {
                in.close();
            }
        } catch (Exception e) {
            core.loadList(null);
        }
    }

    int builtIn() { ensureLoaded(); return core.builtInCount(); }

    boolean enabled() { return sp.getBoolean("enabled", false); }
    void setEnabled(boolean v) { sp.edit().putBoolean("enabled", v).apply(); }

    List<String> customList() {
        List<String> out = new ArrayList<>();
        String raw = sp.getString("custom", "");
        if (raw != null && raw.length() > 0) for (String s : raw.split("\n")) if (s.length() > 0) out.add(s);
        return out;
    }

    /** Stores what could be understood as a website address and returns exactly that. */
    List<String> setCustom(List<String> wanted) {
        List<String> clean = new ArrayList<>();
        for (String w : wanted) {
            String h = NudgeCore.hostFromBar(w);
            if (h != null && !clean.contains(h)) clean.add(h);
        }
        StringBuilder sb = new StringBuilder();
        for (String s : clean) sb.append(s).append('\n');
        sp.edit().putString("custom", sb.toString()).apply();
        core.setCustom(clean);
        return clean;
    }

    int taps() { return sp.getInt("taps", 0); }
    void addTap() { sp.edit().putInt("taps", taps() + 1).apply(); }
}
