package app.detox.quit;

import java.net.IDN;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * The thinking part of the nudge. No Android classes in here, so it can be tested anywhere.
 *
 * The built-in list is a sorted array of 64-bit FNV-1a hashes (big endian), made by scripts/build-blocklist.js.
 * Hashes keep the list small (8 bytes a site) and fast to search without loading half a million strings.
 */
public final class NudgeCore {
    private LongBuffer list;
    private int count;
    private final Set<String> custom = new HashSet<>();

    /** Load the packed list. Null or empty means "no built-in list". */
    public synchronized void loadList(byte[] bytes) {
        if (bytes == null || bytes.length < 8) { list = null; count = 0; return; }
        list = ByteBuffer.wrap(bytes).asLongBuffer();
        count = bytes.length / 8;
    }

    public synchronized int builtInCount() { return count; }

    /** Replace the user's own sites. Anything that is not a plausible address is dropped. */
    public synchronized void setCustom(Collection<String> domains) {
        custom.clear();
        if (domains == null) return;
        for (String d : domains) {
            String h = hostFromBar(d);
            if (h != null) custom.add(h);
        }
    }

    public static long hash(String s) {
        long h = 0xcbf29ce484222325L;
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        for (byte x : b) { h ^= (x & 0xff); h *= 0x100000001b3L; }
        return h;
    }

    private boolean inList(String domain) {
        if (list == null || count == 0) return false;
        long key = hash(domain);
        int lo = 0, hi = count - 1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            long v = list.get(mid);
            if (v < key) lo = mid + 1; else if (v > key) hi = mid - 1; else return true;
        }
        return false;
    }

    /** True when the host, or any parent domain of it, is on the built-in list or on the user's list. */
    public synchronized boolean matchesHost(String host) {
        if (host == null) return false;
        String h = host;
        while (true) {
            if (custom.contains(h) || inList(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0) return false;
            String rest = h.substring(dot + 1);
            if (rest.indexOf('.') < 0) return false; // never test a bare top-level domain
            h = rest;
        }
    }

    private static boolean allDigits(String s) {
        for (int i = 0; i < s.length(); i++) if (!Character.isDigit(s.charAt(i))) return false;
        return true;
    }

    public boolean matchesBar(String text) { return matchesHost(hostFromBar(text)); }

    /**
     * Turn what a browser shows in its address bar into a host name, or null if it is not an address
     * (search words, empty, "Search or type URL" and so on).
     */
    public static String hostFromBar(String text) {
        if (text == null) return null;
        String t = text.trim().toLowerCase(Locale.ROOT);
        if (t.isEmpty() || t.length() > 300) return null;
        for (int i = 0; i < t.length(); i++) if (Character.isWhitespace(t.charAt(i))) return null;
        int scheme = t.indexOf("://");
        if (scheme > 0 && scheme < 12) t = t.substring(scheme + 3);
        int end = t.length();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c == '/' || c == '?' || c == '#') { end = i; break; }
        }
        t = t.substring(0, end);
        int at = t.lastIndexOf('@');
        if (at >= 0) t = t.substring(at + 1);
        int colon = t.lastIndexOf(':');
        if (colon >= 0) {
            String port = t.substring(colon + 1);
            if (port.isEmpty() || !allDigits(port)) return null;
            t = t.substring(0, colon);
        }
        while (t.endsWith(".")) t = t.substring(0, t.length() - 1);
        if (t.isEmpty() || t.indexOf('.') < 0 || t.startsWith(".") || t.contains("..")) return null;
        boolean ascii = true;
        for (int i = 0; i < t.length(); i++) if (t.charAt(i) > 127) { ascii = false; break; }
        if (!ascii) {
            try { t = IDN.toASCII(t); } catch (Exception e) { return null; }
        }
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '.')) return null;
        }
        String tld = t.substring(t.lastIndexOf('.') + 1);
        if (tld.length() < 2 || allDigits(tld)) return null; // bare IP addresses
        return t;
    }
}
