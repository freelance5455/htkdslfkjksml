package app.detox.quit;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

/**
 * Watches the address bar of web browsers. When you are on a site from your list, it starts a quiet session,
 * waits 90 to 180 seconds, and then (70 percent of the time) lets a slow ball drift across the screen.
 * It never blocks anything and keeps no record of where you went.
 */
public class NudgeService extends AccessibilityService {
    private static final int IDLE = 0, WAITING = 1, CONSUMED = 2;
    private static final int MIN_SECONDS = 90, MAX_SECONDS = 180;
    private static final float SHOW_CHANCE = 0.70f;
    private static final long REARM_AFTER_MS = 5 * 60 * 1000L;
    private static final String[] URL_BAR_IDS = {
            "url_bar", "mozac_browser_toolbar_url_view", "location_bar_edit_text", "url_field", "omnibarTextInput",
            "bro_omnibar_address_title_text", "address_bar_text", "display_url", "urlbar_text", "search_box_text", "toolbar_title", "url"
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Set<String> browsers = new HashSet<>();
    private NudgeEngine engine;
    private int state = IDLE;
    private long lastMatchAt;
    private boolean queued;
    private BallOverlay ball;

    private final Runnable evaluate = new Runnable() {
        @Override public void run() { queued = false; evaluateNow(); }
    };
    private final Runnable fire = new Runnable() {
        @Override public void run() { onTimer(); }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        engine = NudgeEngine.get(this);
        engine.ensureLoaded();
        AccessibilityServiceInfo info = getServiceInfo();
        browsers.clear();
        if (info != null && info.packageNames != null) browsers.addAll(Arrays.asList(info.packageNames));
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (engine == null || event == null || !engine.enabled()) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !browsers.contains(pkg.toString())) return;
        if (!queued) { queued = true; handler.postDelayed(evaluate, 700); }
    }

    @Override public void onInterrupt() { reset(); }

    @Override
    public void onDestroy() {
        reset();
        super.onDestroy();
    }

    private void reset() {
        handler.removeCallbacks(evaluate);
        handler.removeCallbacks(fire);
        queued = false;
        state = IDLE;
        if (ball != null) { ball.remove(); ball = null; }
    }

    /** What the browser in front is showing in its address bar, or null. */
    private String currentAddress() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        CharSequence pkg = root.getPackageName();
        if (pkg == null || !browsers.contains(pkg.toString())) return null;
        String p = pkg.toString();
        for (String id : URL_BAR_IDS) {
            List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByViewId(p + ":id/" + id);
            if (found == null) continue;
            for (AccessibilityNodeInfo n : found) {
                CharSequence t = n.getText();
                if (t != null && NudgeCore.hostFromBar(t.toString()) != null) return t.toString();
            }
        }
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int seen = 0;
        while (!queue.isEmpty() && seen < 500) {
            AccessibilityNodeInfo n = queue.poll();
            seen++;
            String id = n.getViewIdResourceName();
            CharSequence t = n.getText();
            if (id != null && t != null) {
                String low = id.toLowerCase(Locale.ROOT);
                if ((low.contains("url") || low.contains("omnibox") || low.contains("location_bar") || low.contains("address"))
                        && NudgeCore.hostFromBar(t.toString()) != null) return t.toString();
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) queue.add(c);
            }
        }
        return null;
    }

    private void evaluateNow() {
        if (!engine.enabled()) { reset(); return; }
        String bar = currentAddress();
        if (bar == null) return;                       // cannot tell: change nothing
        long now = SystemClock.elapsedRealtime();
        if (engine.core.matchesBar(bar)) {
            if (state == CONSUMED && now - lastMatchAt > REARM_AFTER_MS) state = IDLE;
            lastMatchAt = now;
            if (state == IDLE) {
                state = WAITING;
                long wait = (MIN_SECONDS + rnd.nextInt(MAX_SECONDS - MIN_SECONDS + 1)) * 1000L;
                handler.postDelayed(fire, wait);
            }
        } else if (state != IDLE) {                    // a readable address that is not on the list: the visit is over
            handler.removeCallbacks(fire);
            state = IDLE;
        }
    }

    private void onTimer() {
        if (!engine.enabled()) { state = IDLE; return; }
        String bar = currentAddress();
        if (bar == null || !engine.core.matchesBar(bar)) { state = IDLE; return; }   // they left: nothing happens
        state = CONSUMED;
        if (rnd.nextFloat() < SHOW_CHANCE) showBall();                                // otherwise: nothing, no trace
    }

    private void showBall() {
        if (ball != null) ball.remove();
        ball = new BallOverlay(this, new BallOverlay.Listener() {
            @Override public void onTap() {
                engine.addTap();
                performGlobalAction(GLOBAL_ACTION_HOME);
            }
            @Override public void onGone() { ball = null; }
        });
        ball.show(rnd);
    }
}
