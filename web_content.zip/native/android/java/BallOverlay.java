package app.detox.quit;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;

import java.util.Random;

/** The ball: drawn in code, floated across the screen in its own tiny window, gone when it leaves. */
final class BallOverlay {
    interface Listener { void onTap(); void onGone(); }

    private final Context ctx;
    private final Listener listener;
    private final WindowManager wm;
    private final float dp;
    private View view;
    private ValueAnimator anim;
    private boolean gone;

    BallOverlay(Context ctx, Listener listener) {
        this.ctx = ctx;
        this.listener = listener;
        this.wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        this.dp = ctx.getResources().getDisplayMetrics().density;
    }

    void show(Random rnd) {
        final DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        final int sw = dm.widthPixels, sh = dm.heightPixels;
        final int w = (int) (200 * dp), h = (int) (140 * dp);

        view = new BallView(ctx, dp);
        view.setClickable(true);
        view.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { listener.onTap(); remove(); }
        });

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        /* mostly from above, sometimes from a side; always slow, with a gentle sway */
        final boolean fromTop = rnd.nextFloat() < 0.70f;
        final float x0, y0, x1, y1;
        final float sway = 26 * dp;
        if (fromTop) {
            x0 = (0.12f + rnd.nextFloat() * 0.76f) * sw - w / 2f;
            y0 = -h;
            x1 = clamp(x0 + (rnd.nextFloat() - 0.5f) * 0.7f * sw, -w * 0.2f, sw - w * 0.8f);
            y1 = sh + h * 0.2f;
        } else {
            boolean left = rnd.nextBoolean();
            x0 = left ? -w : sw;
            x1 = left ? sw : -w;
            y0 = (0.12f + rnd.nextFloat() * 0.43f) * sh;
            y1 = y0 + (0.1f + rnd.nextFloat() * 0.2f) * sh;
        }
        final float cycles = 2.0f + rnd.nextFloat() * 0.8f;
        final long duration = 13000L + rnd.nextInt(4000);

        lp.x = (int) x0; lp.y = (int) y0;
        try { wm.addView(view, lp); } catch (Exception e) { gone = true; listener.onGone(); return; }

        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(duration);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                if (gone) return;
                float t = (Float) a.getAnimatedValue();
                double wob = Math.sin(t * cycles * 2 * Math.PI) * sway;
                lp.x = (int) (x0 + (x1 - x0) * t + (fromTop ? wob : 0));
                lp.y = (int) (y0 + (y1 - y0) * t + (fromTop ? 0 : wob));
                view.setAlpha(Math.min(1f, Math.min(t / 0.10f, (1f - t) / 0.10f)));
                try { wm.updateViewLayout(view, lp); } catch (Exception e) { remove(); }
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) { remove(); }
        });
        anim.start();
    }

    void remove() {
        if (gone && view == null) return;
        gone = true;
        if (anim != null) { anim.removeAllListeners(); anim.cancel(); anim = null; }
        if (view != null) {
            try { wm.removeViewImmediate(view); } catch (Exception ignored) { }
            view = null;
        }
        listener.onGone();
    }

    private static float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }

    /** A glossy blue ball with "Please don't" written under it by hand. */
    private static final class BallView extends View {
        private final float dp;
        private final Paint ball = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

        BallView(Context c, float dp) {
            super(c);
            this.dp = dp;
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            text.setColor(0xFFFFFFFF);
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(28 * dp);
            text.setTypeface(Typeface.create("cursive", Typeface.NORMAL));
            text.setShadowLayer(7 * dp, 0, 2 * dp, 0xCC050A28);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), cx = w / 2f, r = 42 * dp, cy = 8 * dp + r;
            ball.setShader(new RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 1.25f,
                    new int[]{0xFFA8D4FF, 0xFF3F7CFF, 0xFF1A3ED6}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            ball.setShadowLayer(16 * dp, 0, 8 * dp, 0x773F7CFF);
            canvas.drawCircle(cx, cy, r, ball);
            canvas.save();
            canvas.rotate(-28f, cx - r * 0.34f, cy - r * 0.58f);
            RectF e = new RectF(cx - r * 0.66f, cy - r * 0.78f, cx - r * 0.02f, cy - r * 0.38f);
            shine.setShader(new RadialGradient(e.centerX(), e.centerY(), e.width() * 0.6f, 0xF2FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            canvas.drawOval(e, shine);
            canvas.restore();
            canvas.save();
            canvas.rotate(-4f, cx, cy + r + 30 * dp);
            canvas.drawText("Please don't", cx, cy + r + 34 * dp, text);
            canvas.restore();
        }
    }
}
