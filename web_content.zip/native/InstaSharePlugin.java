package com.ktiba.app;

import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;

@CapacitorPlugin(name = "InstaShare")
public class InstaSharePlugin extends Plugin {
    @PluginMethod
    public void share(PluginCall call) {
        String path = call.getString("path");
        String mime = call.getString("mime", "image/*");
        String pkg = call.getString("pkg", "com.instagram.android");
        String target = call.getString("target", "feed");
        try {
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", new File(path));
            Intent i;
            if ("story".equals(target)) {
                i = new Intent("com.instagram.share.ADD_TO_STORY");
                i.setDataAndType(uri, mime);
            } else {
                i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, uri);
            }
            i.setPackage(pkg);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getContext().startActivity(i);
            call.resolve(new JSObject().put("ok", true));
        } catch (Exception e) {
            call.reject("Could not open " + pkg + ": " + e.getMessage());
        }
    }
}
