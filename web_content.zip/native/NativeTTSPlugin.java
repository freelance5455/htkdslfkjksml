package com.castreader.app;

import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.Set;

@CapacitorPlugin(name = "NativeTTS")
public class NativeTTSPlugin extends Plugin {
    private TextToSpeech tts;
    private TextToSpeech probe;

    // Lists every text-to-speech engine installed on the phone.
    @PluginMethod
    public void getEngines(final PluginCall call) {
        try {
            probe = new TextToSpeech(getContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    JSArray arr = new JSArray();
                    try {
                        String def = probe.getDefaultEngine();
                        for (TextToSpeech.EngineInfo e : probe.getEngines()) {
                            JSObject o = new JSObject();
                            o.put("name", e.name);
                            o.put("label", e.label);
                            o.put("default", e.name.equals(def));
                            arr.put(o);
                        }
                    } catch (Exception ex) {
                        // return whatever was found
                    }
                    try { probe.shutdown(); } catch (Exception ex) { }
                    JSObject r = new JSObject();
                    r.put("engines", arr);
                    call.resolve(r);
                }
            });
        } catch (Exception e) {
            call.reject("Could not query TTS engines: " + e.getMessage());
        }
    }

    // Starts the chosen engine and returns its voices.
    @PluginMethod
    public void selectEngine(final PluginCall call) {
        String eng = call.getString("engine");
        try {
            if (tts != null) { tts.stop(); tts.shutdown(); }
        } catch (Exception ex) { }
        tts = null;
        try {
            tts = new TextToSpeech(getContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status != TextToSpeech.SUCCESS || tts == null) {
                        call.reject("That engine failed to start");
                        return;
                    }
                    JSArray arr = new JSArray();
                    try {
                        Set<Voice> vs = tts.getVoices();
                        if (vs != null) {
                            for (Voice v : vs) {
                                JSObject o = new JSObject();
                                o.put("name", v.getName());
                                o.put("lang", v.getLocale().toLanguageTag());
                                o.put("local", !v.isNetworkConnectionRequired());
                                arr.put(o);
                            }
                        }
                    } catch (Exception ex) { }
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override public void onStart(String id) { }
                        @Override public void onDone(String id) {
                            JSObject d = new JSObject();
                            d.put("id", id);
                            notifyListeners("done", d);
                        }
                        @Override public void onError(String id) {
                            JSObject d = new JSObject();
                            d.put("id", id);
                            d.put("error", true);
                            notifyListeners("done", d);
                        }
                    });
                    JSObject r = new JSObject();
                    r.put("voices", arr);
                    call.resolve(r);
                }
            }, eng);
        } catch (Exception e) {
            call.reject("Could not start engine: " + e.getMessage());
        }
    }

    @PluginMethod
    public void speak(PluginCall call) {
        if (tts == null) { call.reject("No engine selected"); return; }
        String text = call.getString("text", "");
        String voice = call.getString("voice");
        String id = call.getString("id", "u");
        Float rate = call.getFloat("rate", 1f);
        Float pitch = call.getFloat("pitch", 1f);
        try {
            if (voice != null) {
                Set<Voice> vs = tts.getVoices();
                if (vs != null) {
                    for (Voice v : vs) {
                        if (v.getName().equals(voice)) { tts.setVoice(v); break; }
                    }
                }
            }
            tts.setSpeechRate(rate);
            tts.setPitch(pitch);
            int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
            if (r != TextToSpeech.SUCCESS) { call.reject("Speak failed"); return; }
            call.resolve();
        } catch (Exception e) {
            call.reject("Speak error: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try { if (tts != null) tts.stop(); } catch (Exception e) { }
        call.resolve();
    }

    @Override
    protected void handleOnDestroy() {
        try { if (tts != null) tts.shutdown(); } catch (Exception e) { }
        super.handleOnDestroy();
    }
}
