package com.amino.hesab;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AminoPrintPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
