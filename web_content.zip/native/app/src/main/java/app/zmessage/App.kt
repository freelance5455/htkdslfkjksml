package app.zmessage

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.room.Room
import app.zmessage.data.*
import app.zmessage.ui.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class ZApp : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val repo by lazy {
        val dao = Room.databaseBuilder(this, ZDb::class.java, "zmessage.db").build().dao()
        ChatRepository(dao, FakeGateway(scope), scope) // swap FakeGateway for the real backend
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZTheme {
                val vm = vmFor()
                val prefs = getSharedPreferences("zmessage", MODE_PRIVATE)
                var name by remember { mutableStateOf(prefs.getString("name", null)) }
                var open by rememberSaveable { mutableStateOf<String?>(null) }
                BackHandler(open != null) { open = null }
                if (name == null) Onboarding { prefs.edit().putString("name", it).apply(); name = it }
                else open?.let { ChatScreen(vm, it) { open = null } } ?: ConversationList(vm) { open = it }
            }
        }
    }
}
