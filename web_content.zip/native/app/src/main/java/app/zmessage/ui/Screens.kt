@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
package app.zmessage.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.zmessage.ZApp
import app.zmessage.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import kotlinx.coroutines.flow.flowOf

val Blue = Color(0xFF0A84FF)
val QUICK = listOf("❤️", "👍", "😂", "😮", "😢", "🙏")

@Composable
fun ZTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(primary = Blue) else lightColorScheme(primary = Blue)
    MaterialTheme(colorScheme = scheme, content = content)
}

class ChatVM(val repo: ChatRepository) : ViewModel() {
    fun run(block: suspend ChatRepository.() -> Unit) { viewModelScope.launch { repo.block() } }
}

@Composable
fun vmFor(): ChatVM = viewModel(factory = viewModelFactory { initializer { ChatVM((this[APPLICATION_KEY] as ZApp).repo) } })

fun smartReplies(t: String) = if (t.trim().endsWith("?")) listOf("Yes", "No", "Maybe later") else listOf("👍", "Thanks!", "Got it")

@Composable
fun ConversationList(vm: ChatVM, onOpen: (String) -> Unit) {
    val repo = vm.repo
    var showArchived by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var newGroup by remember { mutableStateOf(false) }
    val convs by remember(showArchived) { if (showArchived) repo.archived() else repo.conversations() }.collectAsStateWithLifecycle(emptyList())
    val hits by remember(q) { if (q.isBlank()) flowOf(emptyList<String>()) else repo.hits(q) }.collectAsStateWithLifecycle(emptyList())
    val shown = if (q.isBlank()) convs else convs.filter { it.title.contains(q, true) || it.id in hits }
    Scaffold(topBar = {
        LargeTopAppBar(title = { Text(if (showArchived) "Archived" else "Messages") }, actions = {
            TextButton(onClick = { showArchived = !showArchived }) { Text(if (showArchived) "Inbox" else "Archived") }
            TextButton(onClick = { newGroup = true }) { Text("New group") }
        })
    }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), placeholder = { Text("Search chats and messages") }, singleLine = true, shape = RoundedCornerShape(24.dp))
            LazyColumn { items(shown, key = { it.id }) { c -> ConvRow(c, vm, onOpen) } }
        }
    }
    if (newGroup) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newGroup = false }, title = { Text("New group") },
            text = { OutlinedTextField(name, { name = it }, placeholder = { Text("Group name") }, singleLine = true) },
            confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { val n = name; vm.run { createGroup(n) }; newGroup = false }) { Text("Create") } },
            dismissButton = { TextButton(onClick = { newGroup = false }) { Text("Cancel") } },
        )
    }
}

@Composable
fun ConvRow(c: Conversation, vm: ChatVM, onOpen: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        ListItem(
            modifier = Modifier.combinedClickable(onClick = { onOpen(c.id) }, onLongClick = { menu = true }),
            leadingContent = { Box(Modifier.size(48.dp).clip(CircleShape).background(Blue), Alignment.Center) { Text(c.title.take(1), color = Color.White) } },
            headlineContent = { Text((if (c.pinned) "📌 " else "") + c.title + (if (c.muted) " 🔕" else ""), fontWeight = if (c.unread > 0) FontWeight.Bold else null) },
            supportingContent = { Text(if (c.draft.isNotEmpty()) "Draft: ${c.draft}" else c.lastMessage, maxLines = 1) },
            trailingContent = { if (c.unread > 0) Badge { Text("${c.unread}") } },
        )
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem({ Text(if (c.pinned) "Unpin" else "Pin") }, { menu = false; vm.run { togglePin(c.id) } })
            DropdownMenuItem({ Text(if (c.muted) "Unmute" else "Mute") }, { menu = false; vm.run { toggleMute(c.id) } })
            DropdownMenuItem({ Text(if (c.archived) "Unarchive" else "Archive") }, { menu = false; vm.run { toggleArchive(c.id) } })
        }
    }
}

@Composable
fun ChatScreen(vm: ChatVM, cid: String, onBack: () -> Unit) {
    val repo = vm.repo
    val title by remember(cid) { repo.title(cid) }.collectAsStateWithLifecycle("")
    val msgs by remember(cid) { repo.messages(cid) }.collectAsStateWithLifecycle(emptyList())
    val reacts by remember(cid) { repo.reactions(cid) }.collectAsStateWithLifecycle(emptyList())
    val typing by repo.typing.collectAsStateWithLifecycle()
    var text by remember(cid) { mutableStateOf("") }
    var loaded by remember(cid) { mutableStateOf(false) }
    var replyTo by remember(cid) { mutableStateOf<Message?>(null) }
    var editing by remember(cid) { mutableStateOf<Message?>(null) }
    var q by remember(cid) { mutableStateOf<String?>(null) }
    val list = rememberLazyListState()

    LaunchedEffect(cid) { text = repo.draft(cid); loaded = true }                       // draft restore
    LaunchedEffect(text, loaded) { if (loaded && editing == null) { delay(300); repo.saveDraft(cid, text) } }
    LaunchedEffect(msgs.size) { repo.markRead(cid); if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.lastIndex) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    val s = q
                    if (s != null) OutlinedTextField(s, { q = it }, placeholder = { Text("Search this chat") }, singleLine = true)
                    else Column { Text(title, fontWeight = FontWeight.SemiBold); if (cid in typing) Text("typing…", style = MaterialTheme.typography.labelSmall) }
                },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
                actions = { TextButton(onClick = { q = if (q == null) "" else null }) { Text("🔍") } },
            )
        },
        bottomBar = {
            Column(Modifier.navigationBarsPadding().imePadding()) {
                val last = msgs.lastOrNull()
                if (last != null && last.senderId != ME && !last.deletedForAll) {
                    Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        smartReplies(last.body).forEach { s -> AssistChip(onClick = { vm.run { send(cid, s) } }, label = { Text(s) }) }
                    }
                }
                (editing ?: replyTo)?.let { m ->
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text((if (editing != null) "Editing: " else "Replying: ") + m.body, Modifier.weight(1f), maxLines = 1)
                        TextButton(onClick = { if (editing != null) text = ""; editing = null; replyTo = null }) { Text("✕") }
                    }
                }
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Message") }, shape = RoundedCornerShape(24.dp), maxLines = 5)
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(enabled = text.isNotBlank(), onClick = {
                        val t = text; val e = editing; val r = replyTo?.id
                        if (e != null) vm.run { edit(e.id, t) } else vm.run { send(cid, t, r) }
                        text = ""; editing = null; replyTo = null
                    }) { Text("↑") }
                }
            }
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(), state = list,
            contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(msgs.filter { q.isNullOrBlank() || it.body.contains(q!!, true) }, key = { it.id }) { m ->
                Bubble(
                    m, msgs.firstOrNull { it.id == m.replyToId }, reacts.filter { it.messageId == m.id }, vm,
                    onReply = { replyTo = m; editing = null },
                    onEdit = { editing = m; replyTo = null; text = m.body },
                )
            }
            if (cid in typing) item {
                Text("•••", Modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp, 8.dp))
            }
        }
    }
}

@Composable
fun Bubble(m: Message, quoted: Message?, reacts: List<Reaction>, vm: ChatVM, onReply: () -> Unit, onEdit: () -> Unit) {
    val mine = m.senderId == ME
    val clip = LocalClipboardManager.current
    var menu by remember { mutableStateOf(false) }
    val fg = if (mine) Color.White else MaterialTheme.colorScheme.onSurface
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        Box {
            Column(
                Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp))
                    .background(if (mine) Blue else MaterialTheme.colorScheme.surfaceVariant)
                    .pointerInput(m.id) {                                   // swipe right to reply
                        var dx = 0f
                        detectHorizontalDragGestures(onDragEnd = { if (dx > 120f) onReply(); dx = 0f }, onDragCancel = { dx = 0f }) { _, d -> dx += d }
                    }
                    .combinedClickable(onClick = {}, onLongClick = { menu = true })
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                quoted?.let { Text(if (it.deletedForAll) "Deleted message" else it.body, color = fg.copy(alpha = .7f), maxLines = 1, style = MaterialTheme.typography.labelMedium) }
                if (m.deletedForAll) Text("This message was deleted", fontStyle = FontStyle.Italic, color = fg.copy(alpha = .7f)) else Text(m.body, color = fg)
                val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(m.createdAt))
                Text((if (m.starred) "⭐ " else "") + time + if (m.editedAt != null) " · Edited" else "", style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = .7f))
            }
            DropdownMenu(menu, { menu = false }) {
                if (!m.deletedForAll) {
                    Row { QUICK.forEach { e -> TextButton(onClick = { menu = false; vm.run { react(m.id, e) } }) { Text(e) } } }
                    DropdownMenuItem({ Text("Reply") }, { menu = false; onReply() })
                    DropdownMenuItem({ Text("Copy") }, { menu = false; clip.setText(AnnotatedString(m.body)) })
                    DropdownMenuItem({ Text(if (m.starred) "Unstar" else "Star") }, { menu = false; vm.run { toggleStar(m.id) } })
                    if (vm.repo.canEdit(m)) DropdownMenuItem({ Text("Edit") }, { menu = false; onEdit() })
                    if (mine) DropdownMenuItem({ Text("Delete for everyone") }, { menu = false; vm.run { deleteForAll(m.id) } })
                }
                DropdownMenuItem({ Text("Delete for me") }, { menu = false; vm.run { deleteForMe(m.id) } })
            }
        }
        if (reacts.isNotEmpty()) {
            Text(reacts.groupBy { it.emoji }.map { (e, l) -> if (l.size > 1) "$e${l.size}" else e }.joinToString(" "), style = MaterialTheme.typography.bodySmall)
        }
        if (mine) {
            val label = when (m.status) {
                Status.FAILED -> "Not delivered · Tap to retry"; Status.SENDING -> "Sending…"
                Status.SENT -> "Sent"; Status.DELIVERED -> "Delivered"; Status.READ -> "Read"
            }
            Text(label, Modifier.clickable(enabled = m.status == Status.FAILED) { vm.run { flushOutbox() } },
                style = MaterialTheme.typography.labelSmall, color = if (m.status == Status.READ) Blue else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
