package app.zmessage.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

/** Demo flow: replace the code check with a server-side SMS OTP verification. */
@Composable
fun Onboarding(onDone: (String) -> Unit) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    var phone by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    val phoneKb = KeyboardOptions(keyboardType = KeyboardType.Phone)
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Zmessage", style = MaterialTheme.typography.displaySmall, color = Blue, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        when (step) {
            0 -> { Text("Enter your phone number"); OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, Modifier.fillMaxWidth(), keyboardOptions = phoneKb, singleLine = true) }
            1 -> { Text("Enter the 6-digit code sent to $phone"); OutlinedTextField(code, { code = it.take(6); err = false }, Modifier.fillMaxWidth(), isError = err, keyboardOptions = phoneKb, singleLine = true, supportingText = { Text(if (err) "Wrong code" else "Demo build: use 123456") }) }
            else -> { Text("What should we call you?"); OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true) }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = when (step) { 0 -> phone.length >= 7; 1 -> code.length == 6; else -> name.isNotBlank() },
            onClick = { if (step == 0) step = 1 else if (step == 1) { if (code == "123456") step = 2 else err = true } else onDone(name.trim()) },
        ) { Text(if (step == 2) "Done" else "Continue") }
    }
}
