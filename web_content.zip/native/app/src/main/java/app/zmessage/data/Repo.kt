package app.zmessage.data

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

const val ME = "me"

sealed interface Event {
    data class Ack(val id: String, val status: Status) : Event
    data class Typing(val cid: String, val on: Boolean) : Event
    data class Incoming(val m: Message) : Event
}

/** Transport boundary: implement over WebSocket/gRPC + FCM; nothing else in the app changes. */
interface Gateway {
    val events: Flow<Event>
    suspend fun send(m: Message): Result<Unit>
    suspend fun edit(id: String, body: String): Result<Unit>
    suspend fun deleteForAll(id: String): Result<Unit>
}

/** Simulates delivery, read receipts, typing and a reply so the app runs with no backend. */
class FakeGateway(private val scope: CoroutineScope) : Gateway {
    private val bus = MutableSharedFlow<Event>(extraBufferCapacity = 64)
    override val events: Flow<Event> = bus
    override suspend fun send(m: Message): Result<Unit> {
        delay(300)
        scope.launch {
            delay(500); bus.emit(Event.Ack(m.id, Status.DELIVERED))
            delay(700); bus.emit(Event.Ack(m.id, Status.READ))
            bus.emit(Event.Typing(m.conversationId, true)); delay(1500)
            bus.emit(Event.Typing(m.conversationId, false))
            val reply = Message(UUID.randomUUID().toString(), m.conversationId, "ava", "Got it 👍", System.currentTimeMillis(), Status.READ)
            bus.emit(Event.Incoming(reply))
        }
        return Result.success(Unit)
    }
    override suspend fun edit(id: String, body: String) = Result.success(Unit)
    override suspend fun deleteForAll(id: String) = Result.success(Unit)
}

class ChatRepository(
    private val dao: ChatDao, private val gw: Gateway, scope: CoroutineScope,
    private val editWindowMs: Long = 15 * 60_000L,
) {
    private val lock = Mutex()
    val typing = MutableStateFlow(emptySet<String>())

    init { scope.launch { seed(); gw.events.collect { onEvent(it) } } }

    fun conversations() = dao.conversations()
    fun messages(cid: String) = dao.messages(cid)
    fun reactions(cid: String) = dao.reactions(cid)
    fun title(cid: String) = dao.title(cid)
    fun archived() = dao.archived()
    fun hits(q: String) = dao.hits(q)
    suspend fun togglePin(cid: String) = dao.togglePin(cid)
    suspend fun toggleMute(cid: String) = dao.toggleMute(cid)
    suspend fun toggleArchive(cid: String) = dao.toggleArchive(cid)
    suspend fun toggleStar(id: String) = dao.toggleStar(id)
    suspend fun createGroup(name: String) {
        val n = name.trim(); if (n.isEmpty()) return
        dao.upsertConversation(Conversation(UUID.randomUUID().toString(), n, isGroup = true, lastMessage = "Group created", lastAt = System.currentTimeMillis()))
    }
    suspend fun draft(cid: String) = dao.draft(cid) ?: ""
    suspend fun saveDraft(cid: String, d: String) = dao.setDraft(cid, d)
    suspend fun markRead(cid: String) = dao.markRead(cid)
    fun canEdit(m: Message) = m.senderId == ME && !m.deletedForAll && System.currentTimeMillis() - m.createdAt <= editWindowMs

    /** Offline-first: persist first (optimistic UI), then flush the outbox. */
    suspend fun send(cid: String, body: String, replyTo: String? = null) {
        val t = body.trim(); if (t.isEmpty()) return
        val m = Message(UUID.randomUUID().toString(), cid, ME, t, System.currentTimeMillis(), replyToId = replyTo)
        dao.upsertMessage(m); dao.setDraft(cid, ""); dao.touch(cid, t, m.createdAt, 0)
        flushOutbox()
    }

    /** Call on send, on tap-to-retry, and when connectivity returns. */
    suspend fun flushOutbox() {
        lock.withLock {
            for (m in dao.outbox()) {
                if (gw.send(m).isSuccess) advance(m.id, Status.SENT)
                else { dao.setStatus(m.id, Status.FAILED); break }
            }
        }
    }

    suspend fun edit(id: String, body: String) {
        val m = dao.message(id)?.takeIf { canEdit(it) } ?: return
        val t = body.trim(); if (t.isEmpty()) return
        dao.upsertMessage(m.copy(body = t, editedAt = System.currentTimeMillis())); gw.edit(id, t)
    }

    suspend fun react(mid: String, emoji: String) {
        if (dao.myReaction(mid, ME) == emoji) dao.removeReaction(mid, ME) else dao.upsertReaction(Reaction(mid, ME, emoji))
    }

    suspend fun deleteForMe(id: String) { dao.message(id)?.let { dao.upsertMessage(it.copy(hiddenForMe = true)) } }

    suspend fun deleteForAll(id: String) {
        val m = dao.message(id)?.takeIf { it.senderId == ME } ?: return
        dao.upsertMessage(m.copy(deletedForAll = true, body = "")); gw.deleteForAll(id) // tombstone
    }

    private suspend fun advance(id: String, s: Status) {
        dao.message(id)?.let { if (s > it.status) dao.setStatus(id, s) }
    }

    private suspend fun onEvent(e: Event) {
        when (e) {
            is Event.Ack -> advance(e.id, e.status)
            is Event.Typing -> typing.update { if (e.on) it + e.cid else it - e.cid }
            is Event.Incoming -> { dao.upsertMessage(e.m); dao.touch(e.m.conversationId, e.m.body, e.m.createdAt, 1) }
        }
    }

    private suspend fun seed() {
        if (dao.count() > 0) return
        val now = System.currentTimeMillis()
        dao.upsertConversation(Conversation("c1", "Ava Chen", unread = 1, lastMessage = "Welcome to Zmessage 👋", lastAt = now))
        dao.upsertConversation(Conversation("c2", "Weekend Crew", isGroup = true, pinned = true, lastMessage = "Who's driving?", lastAt = now - 60_000))
        dao.upsertMessage(Message("m1", "c1", "ava", "Welcome to Zmessage 👋", now, Status.READ))
    }
}
