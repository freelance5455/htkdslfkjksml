package app.zmessage.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** Ordered so a status can only move forward (FAILED -> SENDING -> ... -> READ). */
enum class Status { FAILED, SENDING, SENT, DELIVERED, READ }

@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey val id: String, val title: String, val isGroup: Boolean = false,
    val pinned: Boolean = false, val muted: Boolean = false, val archived: Boolean = false,
    val unread: Int = 0, val draft: String = "", val lastMessage: String = "", val lastAt: Long = 0,
)

/** id is a client-generated UUID, so retries are idempotent on the server. */
@Entity(tableName = "messages", indices = [Index("conversationId", "createdAt")])
data class Message(
    @PrimaryKey val id: String, val conversationId: String, val senderId: String,
    val body: String, val createdAt: Long, val status: Status = Status.SENDING,
    val replyToId: String? = null, val editedAt: Long? = null,
    val deletedForAll: Boolean = false, val hiddenForMe: Boolean = false, val starred: Boolean = false,
)

@Entity(tableName = "reactions", primaryKeys = ["messageId", "userId"])
data class Reaction(val messageId: String, val userId: String, val emoji: String)

@Dao
interface ChatDao {
    @Query("SELECT * FROM conversations WHERE archived = 0 ORDER BY pinned DESC, lastAt DESC")
    fun conversations(): Flow<List<Conversation>>
    @Query("SELECT title FROM conversations WHERE id = :cid") fun title(cid: String): Flow<String>
    @Query("SELECT draft FROM conversations WHERE id = :cid") suspend fun draft(cid: String): String?
    @Query("SELECT COUNT(*) FROM conversations") suspend fun count(): Int
    @Query("SELECT * FROM messages WHERE conversationId = :cid AND hiddenForMe = 0 ORDER BY createdAt")
    fun messages(cid: String): Flow<List<Message>>
    @Query("SELECT * FROM reactions WHERE messageId IN (SELECT id FROM messages WHERE conversationId = :cid)")
    fun reactions(cid: String): Flow<List<Reaction>>
    @Query("SELECT * FROM messages WHERE status IN ('SENDING','FAILED') ORDER BY createdAt")
    suspend fun outbox(): List<Message>
    @Query("SELECT * FROM messages WHERE id = :id") suspend fun message(id: String): Message?
    @Query("SELECT emoji FROM reactions WHERE messageId = :mid AND userId = :uid")
    suspend fun myReaction(mid: String, uid: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertMessage(m: Message)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertConversation(c: Conversation)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertReaction(r: Reaction)
    @Query("DELETE FROM reactions WHERE messageId = :mid AND userId = :uid") suspend fun removeReaction(mid: String, uid: String)
    @Query("UPDATE messages SET status = :s WHERE id = :id") suspend fun setStatus(id: String, s: Status)
    @Query("UPDATE conversations SET draft = :d WHERE id = :cid") suspend fun setDraft(cid: String, d: String)
    @Query("UPDATE conversations SET unread = 0 WHERE id = :cid") suspend fun markRead(cid: String)
    @Query("SELECT * FROM conversations WHERE archived = 1 ORDER BY lastAt DESC") fun archived(): Flow<List<Conversation>>
    @Query("SELECT DISTINCT conversationId FROM messages WHERE deletedForAll = 0 AND hiddenForMe = 0 AND body LIKE '%' || :q || '%'")
    fun hits(q: String): Flow<List<String>>
    @Query("UPDATE conversations SET pinned = NOT pinned WHERE id = :cid") suspend fun togglePin(cid: String)
    @Query("UPDATE conversations SET muted = NOT muted WHERE id = :cid") suspend fun toggleMute(cid: String)
    @Query("UPDATE conversations SET archived = NOT archived WHERE id = :cid") suspend fun toggleArchive(cid: String)
    @Query("UPDATE messages SET starred = NOT starred WHERE id = :id") suspend fun toggleStar(id: String)
    @Query("UPDATE conversations SET lastMessage = :t, lastAt = :at, unread = unread + :inc WHERE id = :cid")
    suspend fun touch(cid: String, t: String, at: Long, inc: Int)
}

@Database(entities = [Conversation::class, Message::class, Reaction::class], version = 1, exportSchema = false)
abstract class ZDb : RoomDatabase() { abstract fun dao(): ChatDao }
