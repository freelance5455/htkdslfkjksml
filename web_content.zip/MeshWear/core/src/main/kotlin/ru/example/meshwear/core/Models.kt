package ru.example.meshwear.core

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class Lesson(
    val start: String,              // "HH:mm"
    val end: String,                // "HH:mm"
    val subject: String,
    val room: String = "",
    val topic: String = "",
    val absence: String = "",       // "н" — не был, "б" — больничный, "" — нет отметки
    val control: Boolean = false,   // «кр» — контрольная работа
)

@Serializable
data class Mark(
    val subject: String,
    val value: String,
    val weight: Int = 1,
    val date: String = "",
    val comment: String = "",
    val control: Boolean = false,   // «кр»
)

@Serializable
data class Homework(
    val subject: String,
    val text: String,
    val due: String = "",
    val done: Boolean = false,
)

/** «В школе»: in — вошёл, out — вышел, none — отметок сегодня нет, unknown — данных нет. */
@Serializable
data class Presence(val state: String = "unknown", val time: String = "")

/** Всё, что часы показывают. Телефон собирает и шлёт; часам токен не нужен. */
@Serializable
data class Snapshot(
    val status: String = "login",   // "ok" | "login" | "error"
    val updatedAt: Long = 0,
    val student: String = "",
    val today: String = "",         // yyyy-MM-dd, дата, к которой относится lessons
    val lessons: List<Lesson> = emptyList(),
    val tomorrow: List<Lesson> = emptyList(),
    val marks: List<Mark> = emptyList(),
    val homework: List<Homework> = emptyList(),
    val presence: Presence = Presence(),
    val message: String = "",
)

object WearPaths {
    const val SNAPSHOT = "/mesh/snapshot"   // телефон -> часы (DataClient)
    const val REFRESH = "/mesh/refresh"     // часы -> телефон (MessageClient)
}

val MeshJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

fun Snapshot.toBytes(): ByteArray = MeshJson.encodeToString(Snapshot.serializer(), this).toByteArray()

fun Presence.label(): String = when (state) {
    "in" -> "В школе с $time"
    "out" -> "Вышел из школы в $time"
    "none" -> "Ещё не в школе"
    else -> "Школа: нет данных"
}

/** Пометки урока: "н", "б", "кр" или "н · кр". Пусто, если помечать нечего. */
fun Lesson.tags(): String =
    listOfNotNull(absence.ifEmpty { null }, if (control) "кр" else null).joinToString(" · ")
