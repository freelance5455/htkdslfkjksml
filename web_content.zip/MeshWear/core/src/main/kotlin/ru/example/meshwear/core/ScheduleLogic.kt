package ru.example.meshwear.core

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

enum class Kind { NO_DATA, NO_LESSONS, BEFORE, IN_LESSON, DONE }

data class LessonStatus(
    val kind: Kind,
    val current: Lesson? = null,
    val next: Lesson? = null,
    val tomorrowFirst: Lesson? = null,
)

private fun Snapshot.ms(l: Lesson, end: Boolean): Long =
    LocalDate.parse(today).atTime(LocalTime.parse(if (end) l.end else l.start))
        .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

/** Снимок на дату d. Если снимок вчерашний, сегодняшние уроки берутся из tomorrow. null — данные устарели. */
fun Snapshot.forDate(d: LocalDate): Snapshot? {
    val t = runCatching { LocalDate.parse(today) }.getOrNull() ?: return null
    return when (d) {
        t -> this
        t.plusDays(1) -> copy(today = d.toString(), lessons = tomorrow, tomorrow = emptyList(), presence = Presence())
        else -> null
    }
}

/** Моменты начала/конца уроков (epoch millis) — в эти моменты тайл должен сменить картинку. */
fun Snapshot.boundaries(): List<Long> =
    runCatching { lessons.flatMap { listOf(ms(it, false), ms(it, true)) }.distinct().sorted() }
        .getOrDefault(emptyList())

fun Snapshot.statusAt(now: Long): LessonStatus = try {
    val date = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault()).toLocalDate()
    val s = if (status == "ok") forDate(date) else null
    when {
        s == null -> LessonStatus(Kind.NO_DATA)
        s.lessons.isEmpty() -> LessonStatus(Kind.NO_LESSONS, tomorrowFirst = s.tomorrow.firstOrNull())
        else -> {
            val cur = s.lessons.firstOrNull { now >= s.ms(it, false) && now < s.ms(it, true) }
            val next = s.lessons.firstOrNull { s.ms(it, false) > now }
            when {
                cur != null -> LessonStatus(Kind.IN_LESSON, current = cur, next = next)
                next != null -> LessonStatus(Kind.BEFORE, next = next)
                else -> LessonStatus(Kind.DONE, tomorrowFirst = s.tomorrow.firstOrNull())
            }
        }
    }
} catch (e: Exception) {
    LessonStatus(Kind.NO_DATA)
}

/** Сегодня все уроки помечены «б» или «н». */
fun Snapshot.dayAbsence(): String? {
    if (lessons.isEmpty() || lessons.any { it.absence.isEmpty() }) return null
    return if (lessons.all { it.absence == "б" }) "Больничный (б)" else "Не был (н)"
}

/** Строка про школу: больничный / не был / в школе / ещё не в школе / нет данных. */
fun Snapshot.schoolLine(): String {
    if (status != "ok" || today != LocalDate.now().toString()) return "Школа: нет данных"
    return dayAbsence() ?: presence.label()
}
