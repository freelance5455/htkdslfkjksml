package ru.example.meshwear.wear.complication

import android.app.PendingIntent
import android.content.Intent
import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.LongTextComplicationData
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.ShortTextComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService
import ru.example.meshwear.core.Kind
import ru.example.meshwear.core.LessonStatus
import ru.example.meshwear.core.forDate
import ru.example.meshwear.core.statusAt
import ru.example.meshwear.wear.MainActivity
import ru.example.meshwear.wear.SnapshotStore
import java.time.LocalDate

/** Данные для циферблата: время ближайшего урока и предмет. */
class NextLessonComplication : SuspendingComplicationDataSourceService() {

    override fun getPreviewData(type: ComplicationType): ComplicationData? =
        build(type, "08:30", "Алгебра", "08:30 Алгебра · каб. 315")

    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        val snap = SnapshotStore.read(this)?.forDate(LocalDate.now())
        val st = snap?.statusAt(System.currentTimeMillis()) ?: LessonStatus(Kind.NO_DATA)

        val (main, title, long) = when (st.kind) {
            Kind.IN_LESSON -> {
                val c = st.current!!
                Triple("до ${c.end}", c.subject, "Идёт: ${c.subject} до ${c.end}")
            }
            Kind.BEFORE -> {
                val n = st.next!!
                val room = if (n.room.isEmpty()) "" else " · каб. ${n.room}"
                Triple(n.start, n.subject, "${n.start} ${n.subject}$room")
            }
            Kind.NO_LESSONS, Kind.DONE -> {
                val t = st.tomorrowFirst
                if (t != null) Triple(t.start, "завтра", "Завтра: ${t.start} ${t.subject}")
                else Triple("—", "уроков нет", "Уроков больше нет")
            }
            Kind.NO_DATA -> Triple("—", "Мэш", "Войдите на телефоне")
        }
        return build(request.complicationType, main, title, long)
    }

    private fun build(type: ComplicationType, main: String, title: String, long: String): ComplicationData? {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val desc = PlainComplicationText.Builder(long).build()
        return when (type) {
            ComplicationType.SHORT_TEXT ->
                ShortTextComplicationData.Builder(PlainComplicationText.Builder(main.take(7)).build(), desc)
                    .setTitle(PlainComplicationText.Builder(title.take(7)).build())
                    .setTapAction(open)
                    .build()
            ComplicationType.LONG_TEXT ->
                LongTextComplicationData.Builder(PlainComplicationText.Builder(long).build(), desc)
                    .setTitle(PlainComplicationText.Builder(title).build())
                    .setTapAction(open)
                    .build()
            else -> null
        }
    }
}
