package ru.example.meshwear.wear

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import ru.example.meshwear.core.MeshJson
import ru.example.meshwear.core.Snapshot
import java.io.File

object SnapshotStore {
    val state = MutableStateFlow<Snapshot?>(null)

    private fun file(c: Context) = File(c.filesDir, "snapshot.json")

    fun read(c: Context): Snapshot? =
        runCatching { MeshJson.decodeFromString(Snapshot.serializer(), file(c).readText()) }.getOrNull()

    fun load(c: Context) {
        if (state.value == null) state.value = read(c)
    }

    fun write(c: Context, bytes: ByteArray) {
        val tmp = File(c.filesDir, "snapshot.tmp")
        tmp.writeBytes(bytes)
        tmp.renameTo(file(c))
        state.value = read(c)
    }
}
