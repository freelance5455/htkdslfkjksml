package ru.example.meshwear.wear

import android.content.ComponentName
import android.content.Context
import androidx.wear.tiles.TileService
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import kotlinx.coroutines.tasks.await
import ru.example.meshwear.core.WearPaths
import ru.example.meshwear.wear.complication.NextLessonComplication
import ru.example.meshwear.wear.tile.MeshTileService

/** Новые данные пришли — просим систему перерисовать тайл и компликацию. */
fun refreshSurfaces(c: Context) {
    TileService.getUpdater(c).requestUpdate(MeshTileService::class.java)
    ComplicationDataSourceUpdateRequester
        .create(c, ComponentName(c, NextLessonComplication::class.java))
        .requestUpdateAll()
}

/** Просим телефон обновить данные. */
suspend fun requestRefresh(c: Context) {
    val nodes = Wearable.getNodeClient(c).connectedNodes.await()
    for (n in nodes) {
        Wearable.getMessageClient(c).sendMessage(n.id, WearPaths.REFRESH, ByteArray(0)).await()
    }
}

class SnapshotListenerService : WearableListenerService() {
    override fun onDataChanged(events: DataEventBuffer) {
        for (e in events) {
            if (e.type == DataEvent.TYPE_CHANGED && e.dataItem.uri.path == WearPaths.SNAPSHOT) {
                val bytes = e.dataItem.data ?: continue
                SnapshotStore.write(this, bytes)
                refreshSurfaces(this)
            }
        }
    }
}
