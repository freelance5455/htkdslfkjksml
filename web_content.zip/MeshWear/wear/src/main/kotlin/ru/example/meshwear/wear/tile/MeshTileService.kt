package ru.example.meshwear.wear.tile

import androidx.wear.protolayout.ActionBuilders
import androidx.wear.protolayout.ColorBuilders.argb
import androidx.wear.protolayout.DimensionBuilders.dp
import androidx.wear.protolayout.DimensionBuilders.expand
import androidx.wear.protolayout.DimensionBuilders.sp
import androidx.wear.protolayout.LayoutElementBuilders
import androidx.wear.protolayout.LayoutElementBuilders.Box
import androidx.wear.protolayout.LayoutElementBuilders.Column
import androidx.wear.protolayout.LayoutElementBuilders.FontStyle
import androidx.wear.protolayout.LayoutElementBuilders.Text
import androidx.wear.protolayout.ModifiersBuilders
import androidx.wear.protolayout.ResourceBuilders
import androidx.wear.protolayout.TimelineBuilders
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileBuilders
import androidx.wear.tiles.TileService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import ru.example.meshwear.core.Kind
import ru.example.meshwear.core.LessonStatus
import ru.example.meshwear.core.Snapshot
import ru.example.meshwear.core.boundaries
import ru.example.meshwear.core.forDate
import ru.example.meshwear.core.schoolLine
import ru.example.meshwear.core.statusAt
import ru.example.meshwear.wear.SnapshotStore
import java.time.LocalDate

private const val RES_VERSION = "1"
private val WHITE = 0xFFFFFFFF.toInt()
private val GRAY = 0xFFB0B7C3.toInt()
private val ACCENT = 0xFF7DD3FC.toInt()

/**
 * Карточка: «следующий урок / идёт урок / уроки закончились».
 * Таймлайн заранее содержит по картинке на каждый интервал между границами уроков,
 * поэтому карточка сама меняется в нужные минуты без пробуждения приложения.
 */
class MeshTileService : TileService() {

    override fun onTileRequest(requestParams: RequestBuilders.TileRequest): ListenableFuture<TileBuilders.Tile> {
        val now = System.currentTimeMillis()
        val snap = SnapshotStore.read(this)?.forDate(LocalDate.now())
        val points = listOf(now) + (snap?.boundaries().orEmpty().filter { it > now })

        val timeline = TimelineBuilders.Timeline.Builder()
        for (i in 0 until points.size - 1) {
            timeline.addTimelineEntry(
                TimelineBuilders.TimelineEntry.Builder()
                    .setLayout(LayoutElementBuilders.Layout.Builder().setRoot(root(snap, points[i])).build())
                    .setValidity(
                        TimelineBuilders.TimeInterval.Builder()
                            .setStartMillis(points[i]).setEndMillis(points[i + 1]).build()
                    )
                    .build()
            )
        }
        // запасной вариант без интервала — состояние после последней границы
        timeline.addTimelineEntry(
            TimelineBuilders.TimelineEntry.Builder()
                .setLayout(LayoutElementBuilders.Layout.Builder().setRoot(root(snap, points.last())).build())
                .build()
        )

        return Futures.immediateFuture(
            TileBuilders.Tile.Builder()
                .setResourcesVersion(RES_VERSION)
                .setTileTimeline(timeline.build())
                .setFreshnessIntervalMillis(30 * 60_000L)
                .build()
        )
    }

    override fun onTileResourcesRequest(
        requestParams: RequestBuilders.ResourcesRequest
    ): ListenableFuture<ResourceBuilders.Resources> =
        Futures.immediateFuture(ResourceBuilders.Resources.Builder().setVersion(RES_VERSION).build())

    private fun text(s: String, size: Float, color: Int, bold: Boolean): LayoutElementBuilders.LayoutElement =
        Text.Builder()
            .setText(s)
            .setMaxLines(1)
            .setOverflow(LayoutElementBuilders.TEXT_OVERFLOW_ELLIPSIZE_END)
            .setFontStyle(
                FontStyle.Builder()
                    .setSize(sp(size))
                    .setColor(argb(color))
                    .setWeight(if (bold) LayoutElementBuilders.FONT_WEIGHT_BOLD else LayoutElementBuilders.FONT_WEIGHT_NORMAL)
                    .build()
            )
            .build()

    private fun openApp(): ModifiersBuilders.Clickable =
        ModifiersBuilders.Clickable.Builder()
            .setId("open")
            .setOnClick(
                ActionBuilders.LaunchAction.Builder()
                    .setAndroidActivity(
                        ActionBuilders.AndroidActivity.Builder()
                            .setPackageName(packageName)
                            .setClassName("ru.example.meshwear.wear.MainActivity")
                            .build()
                    ).build()
            ).build()

    private fun root(snap: Snapshot?, t: Long): LayoutElementBuilders.LayoutElement {
        val st = snap?.statusAt(t) ?: LessonStatus(Kind.NO_DATA)
        val col = Column.Builder().setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
        fun line(s: String, size: Float, color: Int, bold: Boolean = false) {
            col.addContent(text(s, size, color, bold))
        }

        when (st.kind) {
            Kind.NO_DATA -> {
                line("Мэш", 16f, ACCENT, true)
                line("Войдите на телефоне", 13f, GRAY)
            }
            Kind.NO_LESSONS -> {
                line("Сегодня уроков нет", 15f, WHITE, true)
                st.tomorrowFirst?.let { line("Завтра: ${it.start} ${it.subject}", 12f, GRAY) }
            }
            Kind.BEFORE -> {
                val n = st.next!!
                line("Следующий урок", 12f, GRAY)
                line(n.start, 26f, ACCENT, true)
                line(n.subject, 16f, WHITE, true)
                if (n.room.isNotEmpty()) line("каб. ${n.room}", 12f, GRAY)
            }
            Kind.IN_LESSON -> {
                val c = st.current!!
                line("Идёт · до ${c.end}", 12f, ACCENT)
                line(c.subject, 18f, WHITE, true)
                st.next?.let { line("Далее: ${it.start} ${it.subject}", 12f, GRAY) }
            }
            Kind.DONE -> {
                line("Уроки закончились", 15f, WHITE, true)
                st.tomorrowFirst?.let { line("Завтра: ${it.start} ${it.subject}", 12f, GRAY) }
            }
        }
        if (st.kind != Kind.NO_DATA) snap?.let { line(it.schoolLine(), 11f, ACCENT) }

        return Box.Builder()
            .setWidth(expand())
            .setHeight(expand())
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .setModifiers(
                ModifiersBuilders.Modifiers.Builder()
                    .setClickable(openApp())
                    .setPadding(ModifiersBuilders.Padding.Builder().setAll(dp(14f)).build())
                    .build()
            )
            .addContent(col.build())
            .build()
    }
}
