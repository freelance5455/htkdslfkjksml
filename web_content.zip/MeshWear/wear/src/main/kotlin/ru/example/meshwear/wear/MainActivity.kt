package ru.example.meshwear.wear

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.*
import kotlinx.coroutines.launch
import ru.example.meshwear.core.forDate
import ru.example.meshwear.core.schoolLine
import ru.example.meshwear.core.tags
import ru.example.meshwear.core.statusAt
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SnapshotStore.load(this)
        setContent { WatchApp() }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
}

@Composable
fun WatchApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snap by SnapshotStore.state.collectAsState()
    val list = rememberScalingLazyListState()
    val s = snap
    val now = remember(s) { System.currentTimeMillis() }

    MaterialTheme {
        Scaffold(
            timeText = { TimeText() },
            positionIndicator = { PositionIndicator(scalingLazyListState = list) },
        ) {
            ScalingLazyColumn(Modifier.fillMaxSize(), state = list) {
                val view = if (s != null && s.status == "ok") s.forDate(LocalDate.now()) else null
                when {
                    s == null -> item { Note("Данных нет. Откройте Мэш на телефоне и войдите.") }
                    s.status == "login" -> item { Note("Войдите в Мэш на телефоне") }
                    view == null -> item { Note("Данные устарели. Нажмите «Обновить».") }
                    else -> {
                        val cur = s.statusAt(now).current
                        item {
                            Chip(
                                onClick = {},
                                modifier = Modifier.fillMaxWidth(),
                                colors = ChipDefaults.primaryChipColors(),
                                label = { Text(s.schoolLine(), maxLines = 2) },
                            )
                        }
                        item { ListHeader { Text("Сегодня") } }
                        if (view.lessons.isEmpty()) item { Note("Уроков нет") }
                        items(view.lessons) { l ->
                            Chip(
                                onClick = {},
                                modifier = Modifier.fillMaxWidth(),
                                colors = if (l == cur) ChipDefaults.primaryChipColors() else ChipDefaults.secondaryChipColors(),
                                label = { Text("${l.start} ${l.subject}", maxLines = 1) },
                                secondaryLabel = { Text("до ${l.end}" + (if (l.room.isNotEmpty()) " · каб. ${l.room}" else "") + l.tags().let { if (it.isEmpty()) "" else " · $it" }, maxLines = 1) },
                            )
                        }
                        item { ListHeader { Text("Оценки") } }
                        if (s.marks.isEmpty()) item { Note("Нет данных") }
                        items(s.marks.take(8)) { m ->
                            Chip(
                                onClick = {},
                                modifier = Modifier.fillMaxWidth(),
                                colors = ChipDefaults.secondaryChipColors(),
                                label = { Text("${m.subject}: ${m.value}" + (if (m.control) " · кр" else ""), maxLines = 1) },
                                secondaryLabel = { Text(m.date, maxLines = 1) },
                            )
                        }
                        item { ListHeader { Text("ДЗ") } }
                        val open = s.homework.filter { !it.done }.take(6)
                        if (open.isEmpty()) item { Note("Нет заданий") }
                        items(open) { h ->
                            Chip(
                                onClick = {},
                                modifier = Modifier.fillMaxWidth(),
                                colors = ChipDefaults.secondaryChipColors(),
                                label = { Text(h.subject, maxLines = 1) },
                                secondaryLabel = { Text(h.text, maxLines = 2) },
                            )
                        }
                        if (s.message.isNotEmpty()) item { Note(s.message) }
                    }
                }
                item {
                    Chip(
                        onClick = { scope.launch { runCatching { requestRefresh(ctx) } } },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ChipDefaults.secondaryChipColors(),
                        label = { Text("Обновить") },
                    )
                }
            }
        }
    }
}
