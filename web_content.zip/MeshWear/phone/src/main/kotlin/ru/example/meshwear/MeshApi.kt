package ru.example.meshwear

import kotlinx.serialization.json.*
import okhttp3.OkHttpClient
import okhttp3.Request
import ru.example.meshwear.core.Homework
import ru.example.meshwear.core.Lesson
import ru.example.meshwear.core.Mark
import ru.example.meshwear.core.Presence
import java.io.IOException

class AuthException : Exception("Нужен вход")

data class Student(val id: String, val name: String)

/**
 * ВСЕ адреса МЭШ — только здесь. Официального публичного API нет, это адреса, которые
 * используют неофициальные клиенты. PROFILE сверен с публичным репозиторием mesh_expressive.
 * LOGIN, SCHEDULE, MARKS, HOMEWORK я не смог проверить — если приложение пишет «HTTP 404»,
 * правьте строки ниже (смотрите запросы официального сайта school.mos.ru в DevTools).
 */
object Endpoints {
    const val LOGIN = "https://school.mos.ru/v3/auth/sudir/login"        // НЕ ПРОВЕРЕНО
    private const val B = "https://school.mos.ru/api/family/web/v1"
    const val PROFILE = "$B/profile"                                     // сверено
    fun schedule(s: String, date: String) = "$B/schedule?student_id=$s&date=$date"                 // НЕ ПРОВЕРЕНО
    fun marks(s: String, from: String, to: String) = "$B/marks?student_id=$s&from=$from&to=$to"    // НЕ ПРОВЕРЕНО
    fun homework(s: String, from: String, to: String) = "$B/homeworks?student_id=$s&from=$from&to=$to" // НЕ ПРОВЕРЕНО
    // адрес есть в таблице репозитория mesh_expressive (там это «вход/выход через турникеты»); формат ответа НЕ ПРОВЕРЕН
    fun attendance(s: String, from: String, to: String) = "$B/attendance?student_id=$s&from=$from&to=$to"
}

// ---- терпимый разбор JSON: формат ответов мне неизвестен точно, поэтому пробуем несколько имён полей ----

fun JsonObject.str(vararg keys: String): String {
    for (k in keys) {
        val v = this[k]
        val s = when {
            v is JsonPrimitive && v !is JsonNull -> v.content
            v is JsonObject -> v.str("short_name", "name", "title")   // поле может быть объектом {id, name}
            else -> ""
        }
        if (s.isNotBlank()) return s
    }
    return ""
}

fun JsonElement.items(vararg keys: String): List<JsonObject> {
    val arr: JsonArray = when (this) {
        is JsonArray -> this
        is JsonObject -> keys.firstNotNullOfOrNull { this[it] as? JsonArray } ?: return emptyList()
        else -> return emptyList()
    }
    return arr.mapNotNull { it as? JsonObject }
}

fun JsonElement.hasList(vararg keys: String): Boolean = when (this) {
    is JsonArray -> true
    is JsonObject -> keys.any { this[it] is JsonArray }
    else -> false
}

private val CONTROL = Regex("""(?iu)контрольн|к/р|к\.р|(?<!\p{L})кр(?!\p{L})""")
private val IN_RE = Regex("""(?iu)(?<!\p{L})(in|enter|entry|entrance)(?!\p{L})|вход|зашел|зашёл|приход""")
private val OUT_RE = Regex("""(?iu)(?<!\p{L})(out|exit|leave)(?!\p{L})|выход|вышел|ушел|ушёл|уход""")
private val DATE = Regex("""\d{4}-\d{2}-\d{2}""")

/** «кр»: слова «контрольная», «к/р» в теме, типе урока или форме контроля. Имена полей — предположение. */
private fun isControl(o: JsonObject): Boolean =
    CONTROL.containsMatchIn(listOf("lesson_theme", "theme", "lesson_type", "control_form_name", "control_type", "title").joinToString(" ") { o.str(it) })

/** "б" / "н" / "" — по полям причины отсутствия. Имена полей — предположение, формат ответа мне неизвестен. */
private fun absenceOf(o: JsonObject): String {
    val t = listOf("absence_reason", "absence_reason_id", "nonattendance_reason", "nonattendance_reason_id", "is_absent", "absent")
        .map { o.str(it).trim().lowercase() }
        .firstOrNull { it.isNotEmpty() && it != "0" && it != "false" } ?: return ""
    return if (t == "б" || "болез" in t || "больн" in t || "sick" in t || "illness" in t) "б" else "н"
}

private val TIME = Regex("""(\d{1,2}):(\d{2})""")
private fun hhmm(s: String): String? =
    TIME.find(s)?.let { "%02d:%s".format(it.groupValues[1].toInt(), it.groupValues[2]) }

class MeshApi(private val session: Session) {
    private val http = OkHttpClient()

    private fun get(url: String, token: String? = session.token, profileId: String? = session.profileId): JsonElement {
        val t = token ?: throw AuthException()
        val b = Request.Builder().url(url)
            .header("Auth-Token", t)
            .header("Authorization", "Bearer $t")   // на случай, если сервер ждёт именно его
            .header("X-Mes-Subsystem", "familyweb")
            .header("Accept", "application/json")
        profileId?.takeIf { it.isNotEmpty() }?.let { b.header("Profile-Id", it) }
        http.newCall(b.build()).execute().use { r ->
            if (r.code == 401 || r.code == 403) throw AuthException()
            if (!r.isSuccessful) throw IOException("HTTP ${r.code} ${url.substringAfter("v1/").substringBefore("?")}")
            return Json.parseToJsonElement(r.body?.string().orEmpty())
        }
    }

    /** Проверка найденного токена запросом профиля. null — токен подошёл, иначе текст причины. */
    fun probe(token: String, profileId: String?): String? = try {
        get(Endpoints.PROFILE, token, profileId)
        null
    } catch (e: AuthException) {
        "сервер отклонил токен (401/403)"
    } catch (e: Exception) {
        e.message ?: "ошибка запроса"
    }

    fun profile(): Student {
        val root = get(Endpoints.PROFILE) as? JsonObject ?: throw IOException("profile: ответ не объект")
        val src = (root["children"] as? JsonArray)?.firstOrNull() as? JsonObject
            ?: root["profile"] as? JsonObject
            ?: root
        val name = listOf(src.str("first_name"), src.str("last_name")).filter { it.isNotEmpty() }.joinToString(" ")
        val id = src.str("id", "student_id", "person_id")
        if (id.isEmpty()) throw IOException("profile: нет id ученика")
        return Student(id, name)
    }

    fun schedule(student: String, date: String): List<Lesson> =
        get(Endpoints.schedule(student, date)).items("activities", "payload", "items", "events").mapNotNull {
            val subject = it.str("lesson_name", "subject_name", "name", "title")
            val start = hhmm(it.str("begin_time", "start_time", "start", "begin"))
            val end = hhmm(it.str("end_time", "finish_time", "end"))
            if (subject.isEmpty() || start == null || end == null) null
            else Lesson(start, end, subject, it.str("room_number", "room_name", "room"), it.str("lesson_theme", "theme"), absenceOf(it), isControl(it))
        }.sortedBy { it.start }

    fun marks(student: String, from: String, to: String): List<Mark> =
        get(Endpoints.marks(student, from, to)).items("payload", "items", "marks").map {
            val v = (it["values"] as? JsonArray)?.firstOrNull() as? JsonObject
            val value = it.str("value")
                .ifEmpty { v?.str("name").orEmpty() }
                .ifEmpty { (v?.get("grade") as? JsonObject)?.str("five", "origin").orEmpty() }
            Mark(
                subject = it.str("subject_name", "subject"),
                value = value,
                weight = it.str("weight").toIntOrNull() ?: 1,
                date = it.str("date", "created_at").take(10),
                comment = it.str("comment"),
                control = isControl(it),
            )
        }.filter { it.value.isNotEmpty() }

    /** Турникет: вошёл/вышел сегодня. Формат ответа мне неизвестен: разбор угадывающий, при сомнении возвращает unknown. */
    fun presence(student: String, today: String): Presence {
        val root = get(Endpoints.attendance(student, today, today))
        val keys = arrayOf("payload", "items", "visits", "passes", "events", "attendances")
        if (!root.hasList(*keys)) return Presence("unknown")
        val rows = root.items(*keys)
        if (rows.isEmpty()) return Presence("none")

        val events = mutableListOf<Pair<String, Boolean>>()   // HH:mm, true = вход
        fun add(raw: String, isIn: Boolean, rowDate: String) {
            val d = DATE.find(raw)?.value ?: DATE.find(rowDate)?.value
            if (d != null && d != today) return
            hhmm(raw)?.let { events.add(it to isIn) }
        }
        for (o in rows) {
            val date = o.str("date", "day")
            val inT = o.str("entry_time", "in_time", "enter_time", "time_in", "come_in")
            val outT = o.str("exit_time", "out_time", "leave_time", "time_out", "come_out")
            if (inT.isNotEmpty()) add(inT, true, date)
            if (outT.isNotEmpty()) add(outT, false, date)
            val dir = o.str("direction", "type", "event", "action", "passage_type")
            val time = o.str("time", "datetime", "date_time", "event_time", "timestamp")
            if (dir.isNotEmpty() && time.isNotEmpty()) {
                if (OUT_RE.containsMatchIn(dir)) add(time, false, date)
                else if (IN_RE.containsMatchIn(dir)) add(time, true, date)
            }
        }
        val last = events.maxByOrNull { it.first } ?: return Presence("unknown")
        return Presence(if (last.second) "in" else "out", last.first)
    }

    fun homework(student: String, from: String, to: String): List<Homework> =
        get(Endpoints.homework(student, from, to)).items("payload", "items", "homeworks").map {
            Homework(
                subject = it.str("subject_name", "subject"),
                text = it.str("description", "homework", "text"),
                due = it.str("date_prepared_for", "date", "due").take(10),
                done = it.str("is_done", "done") == "true",
            )
        }.filter { it.text.isNotEmpty() }
}
