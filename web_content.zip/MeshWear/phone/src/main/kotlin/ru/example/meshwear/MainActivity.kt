package ru.example.meshwear

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import ru.example.meshwear.core.Lesson
import ru.example.meshwear.core.Snapshot
import ru.example.meshwear.core.schoolLine
import ru.example.meshwear.core.tags
import java.text.SimpleDateFormat
import java.util.concurrent.atomic.AtomicReference
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val repo by lazy { SyncRepository(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SyncWorker.schedule(this)
        setContent { MaterialTheme { App(repo) } }
    }
}

@Composable
fun App(repo: SyncRepository) {
    val scope = rememberCoroutineScope()
    var snap by remember { mutableStateOf(repo.cached()) }
    var loggedIn by remember { mutableStateOf(repo.session.token != null && !repo.session.expired()) }
    var rejected by remember { mutableStateOf<String?>(null) }   // токен, который сервер не принял
    var busy by remember { mutableStateOf(false) }
    var loginNote by remember { mutableStateOf("") }
    val tried = remember { mutableSetOf<String>() }               // токены, которые уже проверяли

    fun refresh() {
        scope.launch {
            busy = true
            val s = repo.refresh()
            snap = s
            if (s.status == "login") {
                rejected = repo.session.token
                tried.clear()
                loggedIn = false
            }
            busy = false
        }
    }
    LaunchedEffect(loggedIn) { if (loggedIn) refresh() }

    if (!loggedIn) {
        LoginScreen(rejected, loginNote) { tokens, profileId ->
            val fresh = tokens.filter { it != rejected && tried.add(it) }
            if (fresh.isNotEmpty()) {
                scope.launch {
                    loginNote = "Проверяю найденный токен…"
                    val errors = mutableListOf<String>()
                    for (t in fresh) {
                        val err = withContext(Dispatchers.IO) { repo.probe(t, profileId) }
                        if (err == null) {
                            repo.session.token = t
                            repo.session.profileId = profileId
                            repo.session.studentId = null
                            loginNote = ""
                            loggedIn = true
                            return@launch
                        }
                        errors += err
                    }
                    loginNote = "Токен не подошёл: " + errors.distinct().joinToString("; ")
                }
            }
        }
    } else {
        MainScreen(
            snap = snap,
            busy = busy,
            onRefresh = { refresh() },
            onLogout = {
                repo.session.clear()
                CookieManager.getInstance().removeAllCookies(null)
                rejected = null
                tried.clear()
                loginNote = ""
                scope.launch { snap = repo.refresh(); loggedIn = false }   // часы получат статус «войдите»
            },
        )
    }
}

private const val START_PAGE = "file:///android_asset/index.html"
private val JWT = Regex("""eyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]*""")
private val COOKIE_URLS = listOf("https://school.mos.ru", "https://mos.ru", "https://www.mos.ru", "https://login.mos.ru")

// Выгружает значения localStorage/sessionStorage страницы, чтобы найти в них JWT
private const val STORAGE_JS = "(function(){var k=[],v=[];" +
    "try{for(var i=0;i<localStorage.length;i++){var n=localStorage.key(i);k.push(n);v.push(localStorage.getItem(n))}}catch(e){}" +
    "try{for(var j=0;j<sessionStorage.length;j++){var m=sessionStorage.key(j);k.push('s:'+m);v.push(sessionStorage.getItem(m))}}catch(e){}" +
    "return JSON.stringify({k:k,v:v})})()"

/**
 * Токен ищется тремя способами, потому что я не знаю, где именно сайт его хранит:
 * 1) заголовки запросов сайта к mos.ru (Auth-Token / Authorization), 2) cookie, 3) localStorage/sessionStorage.
 * Каждый найденный JWT проверяется запросом профиля; первый подошедший принимается.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(rejected: String?, note: String, onCandidates: (tokens: List<String>, profileId: String?) -> Unit) {
    val ref = remember { arrayOfNulls<WebView>(1) }
    val currentOnCandidates by rememberUpdatedState(onCandidates)
    var info by remember { mutableStateOf("Загрузка…") }
    var diag by remember { mutableStateOf("") }
    val capturedToken = remember { AtomicReference<String?>(null) }
    val capturedProfile = remember { AtomicReference<String?>(null) }

    fun scan(view: WebView) {
        val cm = CookieManager.getInstance()
        val cookies = linkedMapOf<String, String>()
        for (u in COOKIE_URLS) {
            cm.getCookie(u)?.split(";")?.map { it.trim() }?.filter { "=" in it }
                ?.forEach { cookies[it.substringBefore("=")] = it.substringAfter("=") }
        }
        val profileId = capturedProfile.get() ?: cookies["profile_id"]
        view.evaluateJavascript(STORAGE_JS) { raw ->
            val obj = try {
                Json.parseToJsonElement(Json.parseToJsonElement(raw).jsonPrimitive.content).jsonObject
            } catch (e: Exception) {
                null
            }
            val names = (obj?.get("k") as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.orEmpty()
            val values = (obj?.get("v") as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }.orEmpty()
            diag = "cookie: ${cookies.keys.joinToString().ifEmpty { "нет" }} | storage: ${names.joinToString().ifEmpty { "нет" }}"
            val found = listOfNotNull(capturedToken.get(), cookies["aupd_token"]) +
                cookies.values.flatMap { v -> JWT.findAll(v).map { it.value }.toList() } +
                values.flatMap { v -> JWT.findAll(v).map { it.value }.toList() }
            if (found.isNotEmpty()) currentOnCandidates(found.distinct(), profileId)
        }
    }

    LaunchedEffect(Unit) {      // SPA-сайт не всегда вызывает onPageFinished, поэтому ещё и по таймеру
        while (true) {
            delay(2500)
            ref[0]?.let { scan(it) }
        }
    }

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Text(
            "Вход через mos.ru",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(start = 12.dp, top = 8.dp),
        )
        // Кнопки нативные: даже если страница ниже окажется пустой, вход можно запустить
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { ref[0]?.loadUrl(Endpoints.LOGIN) }) { Text("Войти") }
            Button(onClick = { ref[0]?.let { scan(it) } }) { Text("Я вошёл") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { ref[0]?.loadUrl("https://school.mos.ru/") }) { Text("school.mos.ru") }
            TextButton(onClick = {
                CookieManager.getInstance().removeAllCookies { ref[0]?.loadUrl(START_PAGE) }
            }) { Text("Сброс") }
        }
        if (note.isNotEmpty()) {
            Text(note, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
        }
        Text(info, style = MaterialTheme.typography.bodySmall, maxLines = 2,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
        if (diag.isNotEmpty()) {
            Text(diag, style = MaterialTheme.typography.bodySmall, maxLines = 4,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    // часть сайтов отдаёт пустую страницу встроенному WebView («; wv» в User-Agent)
                    settings.userAgentString = settings.userAgentString.replace("; wv", "")
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            info = "Открываю: ${url.orEmpty().take(90)}"
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            info = "Открыто: ${url.orEmpty().take(90)}"
                            view?.let { scan(it) }
                        }

                        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                            view?.let { scan(it) }     // переходы внутри SPA без загрузки страницы
                        }

                        // Подсматриваем заголовки запросов самого сайта к mos.ru: там обычно лежит рабочий токен
                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                            val h = request?.requestHeaders ?: return null
                            if (request.url?.host?.endsWith("mos.ru") != true) return null
                            val tok = h.entries.firstOrNull { it.key.equals("Auth-Token", true) }?.value
                                ?: h.entries.firstOrNull { it.key.equals("Authorization", true) }?.value
                                    ?.removePrefix("Bearer ")?.trim()
                            val pid = h.entries.firstOrNull { it.key.equals("Profile-Id", true) }?.value
                            if (pid != null) capturedProfile.set(pid)
                            if (!tok.isNullOrEmpty() && tok != capturedToken.get()) {
                                capturedToken.set(tok)
                                view?.post { currentOnCandidates(listOf(tok), capturedProfile.get()) }
                            }
                            return null    // запрос идёт как обычно
                        }

                        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                            if (request?.isForMainFrame == true) info = "Ошибка: ${error?.description} — ${request.url}"
                        }

                        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                            if (request?.isForMainFrame == true) info = "HTTP ${errorResponse?.statusCode}: ${request.url}"
                        }
                    }
                    ref[0] = this
                    loadUrl(START_PAGE)
                }
            },
        )
    }
}

@Composable
fun MainScreen(snap: Snapshot?, busy: Boolean, onRefresh: () -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Расписание", "Оценки", "ДЗ")
    val time = snap?.updatedAt?.takeIf { it > 0 }?.let { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it)) }

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(snap?.student.orEmpty().ifEmpty { "Мэш" }, style = MaterialTheme.typography.titleLarge)
                if (time != null) Text("обновлено $time", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onRefresh, enabled = !busy) { Text(if (busy) "…" else "Обновить") }
            TextButton(onClick = onLogout) { Text("Выйти") }
        }
        snap?.message?.takeIf { it.isNotEmpty() }?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 12.dp))
        }
        TabRow(selectedTabIndex = tab) {
            titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val s = snap
            if (s == null) {
                item { Text("Данных пока нет") }
            } else when (tab) {
                0 -> {
                    item { Row1(s.schoolLine(), "") }
                    item { Text("Сегодня", style = MaterialTheme.typography.titleMedium) }
                    if (s.lessons.isEmpty()) item { Text("Уроков нет") }
                    items(s.lessons) { l -> Row1("${l.start}–${l.end}  ${l.subject}" + tagText(l), listOf(l.room.takeIf { it.isNotEmpty() }?.let { "каб. $it" }, l.topic.takeIf { it.isNotEmpty() }).filterNotNull().joinToString(" · ")) }
                    item { Text("Завтра", style = MaterialTheme.typography.titleMedium) }
                    if (s.tomorrow.isEmpty()) item { Text("Уроков нет") }
                    items(s.tomorrow) { l -> Row1("${l.start}–${l.end}  ${l.subject}" + tagText(l), l.room.takeIf { it.isNotEmpty() }?.let { "каб. $it" }.orEmpty()) }
                }
                1 -> {
                    if (s.marks.isEmpty()) item { Text("Оценок нет") }
                    items(s.marks) { m -> Row1("${m.subject}: ${m.value}" + (if (m.control) "  [кр]" else ""), listOf(m.date, m.comment).filter { it.isNotEmpty() }.joinToString(" · ")) }
                }
                else -> {
                    if (s.homework.isEmpty()) item { Text("Заданий нет") }
                    items(s.homework) { h -> Row1((if (h.done) "✓ " else "") + h.subject, h.text + if (h.due.isNotEmpty()) "\nк ${h.due}" else "") }
                }
            }
        }
    }
}

private fun tagText(l: Lesson): String = l.tags().let { if (it.isEmpty()) "" else "  [$it]" }

@Composable
private fun Row1(title: String, sub: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall)
        }
    }
}
