package ru.example.meshwear

import android.content.Context
import android.util.Base64
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.long

class Session(ctx: Context) {
    private val s = SecureStore(ctx)

    var token: String?
        get() = s.get("token")
        set(v) = s.put("token", v)

    var profileId: String?
        get() = s.get("profile")
        set(v) = s.put("profile", v)

    var studentId: String?
        get() = s.get("student")
        set(v) = s.put("student", v)

    var studentName: String?
        get() = s.get("name")
        set(v) = s.put("name", v)

    /** Читает exp из JWT. Если не получилось разобрать — считаем токен живым, пусть решит сервер (401). */
    fun expired(): Boolean = try {
        val payload = token!!.split(".")[1]
        val body = String(Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP))
        val exp = Json.parseToJsonElement(body).jsonObject["exp"]?.jsonPrimitive?.long ?: Long.MAX_VALUE / 1000
        exp * 1000 < System.currentTimeMillis()
    } catch (e: Exception) {
        false
    }

    fun clear() {
        token = null; profileId = null; studentId = null; studentName = null
    }
}
