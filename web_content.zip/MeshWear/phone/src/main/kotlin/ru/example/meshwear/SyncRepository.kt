package ru.example.meshwear

import android.content.Context
import com.google.android.gms.wearable.PutDataRequest
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import ru.example.meshwear.core.MeshJson
import ru.example.meshwear.core.Presence
import ru.example.meshwear.core.Snapshot
import ru.example.meshwear.core.WearPaths
import ru.example.meshwear.core.toBytes
import java.io.File
import java.time.LocalDate

class SyncRepository(private val ctx: Context) {
    val session = Session(ctx)
    private val api = MeshApi(session)
    private val file = File(ctx.filesDir, "snapshot.json")

    fun probe(token: String, profileId: String?): String? = api.probe(token, profileId)

    fun cached(): Snapshot? =
        runCatching { MeshJson.decodeFromString(Snapshot.serializer(), file.readText()) }.getOrNull()

    /** Тянет данные из МЭШ, сохраняет локально и отправляет на часы. Никогда не бросает исключений. */
    suspend fun refresh(): Snapshot = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val old = cached()
        val snap = try {
            if (session.token == null || session.expired()) throw AuthException()
            build(now)
        } catch (e: AuthException) {
            Snapshot(status = "login", updatedAt = now, message = "Нужен вход")
        } catch (e: Exception) {
            (old ?: Snapshot(status = "error")).copy(updatedAt = now, message = "Ошибка: ${e.message}")
        }
        runCatching { file.writeText(MeshJson.encodeToString(Snapshot.serializer(), snap)) }
        runCatching { push(snap) }   // часов может не быть рядом — это не ошибка
        snap
    }

    private suspend fun push(snap: Snapshot) {
        val req = PutDataRequest.create(WearPaths.SNAPSHOT).setData(snap.toBytes()).setUrgent()
        Wearable.getDataClient(ctx).putDataItem(req).await()
    }

    private fun build(now: Long): Snapshot {
        val sid = session.studentId.takeUnless { it.isNullOrEmpty() }
            ?: api.profile().also { session.studentId = it.id; session.studentName = it.name }.id
        val today = LocalDate.now()
        val notes = mutableListOf<String>()

        // Если упала одна часть (например, оценки), остальное всё равно показываем.
        fun <T> part(name: String, def: T, f: () -> T): T = try {
            f()
        } catch (e: AuthException) {
            throw e
        } catch (e: Exception) {
            notes += "$name: ${e.message}"
            def
        }

        val lessons = part("расписание", emptyList()) { api.schedule(sid, today.toString()) }
        val tomorrow = part("завтра", emptyList()) { api.schedule(sid, today.plusDays(1).toString()) }
        val marks = part("оценки", emptyList()) { api.marks(sid, today.minusDays(30).toString(), today.toString()) }
        val hw = part("ДЗ", emptyList()) { api.homework(sid, today.toString(), today.plusDays(7).toString()) }

        val presence = part("школа", Presence()) { api.presence(sid, today.toString()) }

        return Snapshot(
            status = "ok",
            updatedAt = now,
            student = session.studentName.orEmpty(),
            today = today.toString(),
            lessons = lessons,
            tomorrow = tomorrow,
            marks = marks.sortedByDescending { it.date }.take(30),
            homework = hw.sortedBy { it.due },
            presence = presence,
            message = notes.joinToString("; "),
        )
    }
}
