const KEY='ahmed_private_manager_v1';
const defaults={
  profile:{name:'أحمد أبو الحجاج',service:'المهندس أحمد أبو الحجاج',photo:'assets/ahmed-profile.jpg'},
  settings:{examRate:10,consultRate:5},
  ratio:[], tickets:[], expenses:[], credentials:[]
};
let db=load();
let current='home';
let editing=null;

function load(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(e){return structuredClone(defaults)}}
function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function money(n){return Number(n||0).toLocaleString('ar-EG',{minimumFractionDigits:0,maximumFractionDigits:2})+' جنيه'}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function toast(t){const el=document.getElementById('toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1800)}
function today(){return new Date().toISOString().slice(0,10)}
function dateAr(d){if(!d)return ''; return new Date(d+'T00:00:00').toLocaleDateString('ar-EG',{year:'numeric',month:'long',day:'numeric'})}
function sum(a,fn){return a.reduce((x,v)=>x+Number(fn(v)||0),0)}

function nav(){
 document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===current));
 const titles={home:['الرئيسية','إدارتي الخاصة'],ratio:['حساب النسبة','الكشوفات والاستشارات'],tickets:['حجز التذاكر','متابعة حجوزات القطارات'],expenses:['المصاريف','الرصيد والمصروفات'],privacy:['خصوصيتي','البيانات المحفوظة']};
 document.getElementById('topTitle').textContent=titles[current][0];
 document.getElementById('topSubtitle').textContent=titles[current][1];
 document.getElementById('backBtn').style.visibility=current==='home'?'hidden':'visible';
}
function render(){nav(); const page=document.getElementById('page'); page.innerHTML=pages[current](); bind()}
const pages={
home:()=>`<section class="hero home-only">
  <div class="welcome-badge">أهلاً وسهلاً بك</div>
  <div class="welcome-title">مرحباً بك في مساحتك الخاصة</div>
  <img class="profile-photo" src="${esc(db.profile.photo||'assets/profile-placeholder.svg')}" onerror="this.src='assets/profile-placeholder.svg'">
  <h1 class="home-name">${esc(db.profile.name)}</h1>
  <div class="home-service">${esc(db.profile.service)}</div>
  <div class="services-title">خدماتي</div>
  <div class="service-list">
    <div class="service-pill"><span>🚆</span><div><b>حجز تذاكر القطارات</b><small>حجز ومتابعة أسعار وتواريخ السفر</small></div></div>
    <div class="service-pill"><span>🩺</span><div><b>خدمات الكشف</b><small>تسجيل عدد الكشوفات وحساب إجمالي اليوم</small></div></div>
    <div class="service-pill"><span>💬</span><div><b>خدمات الاستشارات</b><small>تسجيل الاستشارات وحساب قيمتها تلقائياً</small></div></div>
  </div>
</section>`,
ratio:()=>{const exRate=Number(db.settings.examRate||10), coRate=Number(db.settings.consultRate||5);
 const totalEx=sum(db.ratio,x=>x.examTotal), totalCo=sum(db.ratio,x=>x.consultTotal);
 return `<div class="card"><div class="section-title"><h2>${editing?'تعديل يوم':'إضافة يوم'}</h2></div>
 <form id="ratioForm" class="form">
 <div class="row"><div><label>اليوم</label><input id="rdate" type="date" value="${editing?esc(editing.date):today()}"></div><div><label>عدد الكشوفات</label><input id="rex" type="number" min="0" value="${editing?editing.exams:0}"></div></div>
 <div class="row"><div><label>سعر الكشف</label><input id="rerate" type="number" min="0" step="0.01" value="${editing?editing.examRate:exRate}"></div><div><label>إجمالي الكشوفات</label><input id="retotal" disabled value="${money((editing?editing.exams:0)*(editing?editing.examRate:exRate))}"></div></div>
 <div class="row"><div><label>عدد الاستشارات</label><input id="rco" type="number" min="0" value="${editing?editing.consults:0}"></div><div><label>سعر الاستشارة</label><input id="rcorate" type="number" min="0" step="0.01" value="${editing?editing.consultRate:coRate}"></div></div>
 <div class="row"><div><label>إجمالي الاستشارات</label><input id="rcototal" disabled value="${money((editing?editing.consults:0)*(editing?editing.consultRate:coRate))}"></div><div><label>إجمالي اليوم</label><input id="rdaytotal" disabled value="${money(0)}"></div></div>
 <button class="btn" type="submit">${editing?'حفظ التعديل':'حفظ اليوم'}</button>
 ${editing?'<button class="btn secondary" type="button" onclick="cancelEdit()">إلغاء التعديل</button>':''}
 </form></div>
 <div class="section-title"><h2>إجمالي كل الأيام</h2></div>
 <div class="stat-grid"><div class="stat"><div class="muted">الأيام</div><div class="num">${db.ratio.length}</div></div><div class="stat"><div class="muted">الكشوفات</div><div class="num">${sum(db.ratio,x=>x.exams)}</div></div><div class="stat"><div class="muted">مبلغ الكشف</div><div class="num">${money(totalEx)}</div></div><div class="stat"><div class="muted">مبلغ الاستشارة</div><div class="num">${money(totalCo)}</div></div></div>
 <div class="total-box"><div>الإجمالي الكلي</div><div class="big">${money(totalEx+totalCo)}</div></div>
 <div class="section-title"><h2>البيانات المحفوظة حسب اليوم</h2></div>
 <div class="list">${db.ratio.length?db.ratio.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<div class="item"><div class="item-head"><span>${dateAr(x.date)}</span><span>${money(x.examTotal+x.consultTotal)}</span></div><div class="item-meta">الكشوفات: ${x.exams} × ${money(x.examRate)} = ${money(x.examTotal)}<br>الاستشارات: ${x.consults} × ${money(x.consultRate)} = ${money(x.consultTotal)}</div><div class="item-actions"><button class="mini" onclick="editRatio('${x.id}')">تعديل</button><button class="mini danger" onclick="delRatio('${x.id}')">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد أيام محفوظة حتى الآن.</div>'}</div>`;
},
tickets:()=>{const profit=sum(db.tickets,x=>x.myPrice);
 return `<div class="card"><div class="section-title"><h2>${editing?'تعديل حجز':'إضافة حجز'}</h2></div><form id="ticketForm" class="form">
 <div class="row"><div><label>تاريخ الحجز</label><input id="tbook" type="date" value="${editing?editing.bookDate:today()}"></div><div><label>تاريخ السفر</label><input id="ttravel" type="date" value="${editing?editing.travelDate:today()}"></div></div>
 <div class="row"><div><label>سعر التذكرة</label><input id="tprice" type="number" min="0" step="0.01" value="${editing?editing.ticketPrice:0}"></div><div><label>السعر الذي أخذته</label><input id="tmy" type="number" min="0" step="0.01" value="${editing?editing.myPrice:0}"></div></div>
 <div class="row"><div><label>اسم الراكب (اختياري)</label><input id="tname" value="${editing?esc(editing.name):''}"></div><div><label>ملاحظة (اختياري)</label><input id="tnote" value="${editing?esc(editing.note):''}"></div></div>
 <button class="btn" type="submit">${editing?'حفظ التعديل':'حفظ الحجز'}</button>${editing?'<button class="btn secondary" type="button" onclick="cancelEdit()">إلغاء التعديل</button>':''}</form></div>
 <div class="section-title"><h2>الإجماليات</h2></div><div class="stat-grid"><div class="stat"><div class="muted">عدد الحجوزات</div><div class="num">${db.tickets.length}</div></div><div class="stat"><div class="muted">إجمالي التذاكر</div><div class="num">${money(sum(db.tickets,x=>x.ticketPrice))}</div></div><div class="stat"><div class="muted">إجمالي ما أخذته</div><div class="num">${money(profit)}</div></div><div class="stat"><div class="muted">الفرق</div><div class="num">${money(profit-sum(db.tickets,x=>x.ticketPrice))}</div></div></div>
 <div class="section-title"><h2>الحجوزات حسب تاريخ الحجز</h2></div><div class="list">${db.tickets.length?db.tickets.slice().sort((a,b)=>b.bookDate.localeCompare(a.bookDate)).map(x=>`<div class="item"><div class="item-head"><span>${dateAr(x.bookDate)}</span><span>${money(x.myPrice)}</span></div><div class="item-meta">السفر: ${dateAr(x.travelDate)}<br>سعر التذكرة: ${money(x.ticketPrice)} — أخذت: ${money(x.myPrice)}${x.name?'<br>الراكب: '+esc(x.name):''}${x.note?'<br>ملاحظة: '+esc(x.note):''}</div><div class="item-actions"><button class="mini" onclick="editTicket('${x.id}')">تعديل</button><button class="mini danger" onclick="delTicket('${x.id}')">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد حجوزات محفوظة.</div>'}</div>`;
},
expenses:()=>{const inc=sum(db.expenses,x=>x.type==='income'?x.amount:0), out=sum(db.expenses,x=>x.type==='expense'?x.amount:0);
 return `<div class="card"><div class="section-title"><h2>${editing?'تعديل حركة':'إضافة حركة مالية'}</h2></div><form id="expenseForm" class="form">
 <div class="row"><div><label>اليوم والتاريخ</label><input id="edate" type="date" value="${editing?editing.date:today()}"></div><div><label>نوع الحركة</label><select id="etype"><option value="income" ${editing?.type==='income'?'selected':''}>مبلغ داخل</option><option value="expense" ${editing?.type==='expense'?'selected':''}>مصروف</option></select></div></div>
 <div class="row"><div><label>نوع المصروف / وصف الحركة</label><input id="edesc" placeholder="مثال: مواصلات، طعام، دخل إضافي" value="${editing?esc(editing.desc):''}"></div><div><label>القيمة</label><input id="eamount" type="number" min="0" step="0.01" value="${editing?editing.amount:0}"></div></div>
 <button class="btn" type="submit">${editing?'حفظ التعديل':'حفظ الحركة'}</button>${editing?'<button class="btn secondary" type="button" onclick="cancelEdit()">إلغاء التعديل</button>':''}</form></div>
 <div class="stat-grid"><div class="stat"><div class="muted">إجمالي الداخل</div><div class="num positive">${money(inc)}</div></div><div class="stat"><div class="muted">إجمالي المصروف</div><div class="num negative">${money(out)}</div></div><div class="stat"><div class="muted">الرصيد الحالي</div><div class="num">${money(inc-out)}</div></div><div class="stat"><div class="muted">عدد الحركات</div><div class="num">${db.expenses.length}</div></div></div>
 <div class="total-box"><div>المتاح حاليًا</div><div class="big">${money(inc-out)}</div></div>
 <div class="section-title"><h2>الحركات حسب اليوم</h2></div><div class="list">${db.expenses.length?db.expenses.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<div class="item"><div class="item-head"><span>${dateAr(x.date)}</span><span class="${x.type==='expense'?'negative':'positive'}">${x.type==='expense'?'-':'+'}${money(x.amount)}</span></div><div class="item-meta">${esc(x.desc||'بدون وصف')}</div><div class="item-actions"><button class="mini" onclick="editExpense('${x.id}')">تعديل</button><button class="mini danger" onclick="delExpense('${x.id}')">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد حركات مالية محفوظة.</div>'}</div>`;
},
privacy:()=>`<div class="card"><div class="section-title"><h2>بياناتي الشخصية</h2></div><form id="profileForm" class="form">
 <div><label>اسمك</label><input id="pname" value="${esc(db.profile.name)}"></div>
 <div><label>اسم الخدمة</label><input id="pservice" value="${esc(db.profile.service)}"></div>
 <div><label>رابط/مسار صورة شخصية (اختياري)</label><input id="pphoto" value="${esc(db.profile.photo)}" placeholder="اتركها كما هي أو ضع مسار صورة داخل www/assets"></div>
 <div class="note">لإضافة صورتك داخل المشروع، ضع ملف الصورة في مجلد <b>www/assets</b> ثم اكتب اسمه هنا مثل: assets/my-photo.jpg</div>
 <button class="btn" type="submit">حفظ بياناتي</button></form></div>
 <div class="card" style="margin-top:14px"><div class="section-title"><h2>الأشياء التي لا أريد نسيانها</h2><button class="mini" onclick="newCredential()">+ إضافة</button></div>
 <div class="note">هذه البيانات تُحفظ محليًا على جهازك. لا تستخدمها كخزنة كلمات مرور عالية الحساسية دون حماية إضافية.</div>
 <div id="credList" class="list" style="margin-top:10px">${credentialsHtml()}</div></div>
 <div class="card" style="margin-top:14px"><div class="section-title"><h2>أسعار النسبة الافتراضية</h2></div><form id="ratesForm" class="row"><div><label>سعر الكشف</label><input id="setExam" type="number" min="0" step="0.01" value="${db.settings.examRate}"></div><div><label>سعر الاستشارة</label><input id="setConsult" type="number" min="0" step="0.01" value="${db.settings.consultRate}"></div><button class="btn" style="grid-column:1/-1">حفظ الأسعار</button></form></div>
 <div class="actions"><button class="btn secondary" onclick="exportData()">نسخ احتياطي للبيانات</button><button class="btn danger" onclick="clearAll()">مسح كل البيانات</button></div>`,
};
function credentialsHtml(){return db.credentials.length?db.credentials.map(x=>`<div class="item"><div class="item-head"><span>${esc(x.title)}</span><span>${x.password?'••••••':'—'}</span></div><div class="item-meta">اسم المستخدم/الحساب: ${esc(x.username||'—')}<br><span id="pw-${x.id}">كلمة المرور: ••••••</span></div><div class="item-actions"><button class="mini" onclick="togglePw('${x.id}')">إظهار</button><button class="mini" onclick="editCredential('${x.id}')">تعديل</button><button class="mini danger" onclick="delCredential('${x.id}')">حذف</button></div></div>`).join(''):'<div class="empty">لم تضف أي بيانات بعد. اضغط + إضافة لإنشاء خانة جديدة.</div>'}
function bind(){
 document.querySelectorAll('.bottom-nav button').forEach(b=>b.onclick=()=>go(b.dataset.page));
 document.getElementById('menuBtn').onclick=()=>toast('استخدم الأزرار السفلية للتنقل');
 document.getElementById('backBtn').onclick=()=>go('home');
 const rf=document.getElementById('ratioForm'); if(rf){const calc=()=>{const a=+rex.value||0,b=+rerate.value||0,c=+rco.value||0,d=+rcorate.value||0;retotal.value=money(a*b);rcototal.value=money(c*d);rdaytotal.value=money(a*b+c*d)}; rf.querySelectorAll('input').forEach(i=>i.oninput=calc);calc();rf.onsubmit=e=>{e.preventDefault();const obj={id:editing?.id||uid(),date:rdate.value,exams:+rex.value||0,examRate:+rerate.value||0,examTotal:(+rex.value||0)*(+rerate.value||0),consults:+rco.value||0,consultRate:+rcorate.value||0,consultTotal:(+rco.value||0)*(+rcorate.value||0)}; if(editing){db.ratio=db.ratio.map(x=>x.id===obj.id?obj:x)}else db.ratio.push(obj);save();editing=null;toast('تم حفظ اليوم');render()}}
 const tf=document.getElementById('ticketForm'); if(tf)tf.onsubmit=e=>{e.preventDefault();const obj={id:editing?.id||uid(),bookDate:tbook.value,travelDate:ttravel.value,ticketPrice:+tprice.value||0,myPrice:+tmy.value||0,name:tname.value,note:tnote.value};if(editing)db.tickets=db.tickets.map(x=>x.id===obj.id?obj:x);else db.tickets.push(obj);save();editing=null;toast('تم حفظ الحجز');render()}
 const ef=document.getElementById('expenseForm'); if(ef)ef.onsubmit=e=>{e.preventDefault();const obj={id:editing?.id||uid(),date:edate.value,type:etype.value,desc:edesc.value,amount:+eamount.value||0};if(editing)db.expenses=db.expenses.map(x=>x.id===obj.id?obj:x);else db.expenses.push(obj);save();editing=null;toast('تم حفظ الحركة');render()}
 const pf=document.getElementById('profileForm'); if(pf)pf.onsubmit=e=>{e.preventDefault();db.profile={name:pname.value||'اسمي',service:pservice.value||'خدماتي الخاصة',photo:pphoto.value||'assets/profile-placeholder.svg'};save();toast('تم حفظ بياناتي');render()}
 const sf=document.getElementById('ratesForm'); if(sf)sf.onsubmit=e=>{e.preventDefault();db.settings.examRate=+setExam.value||0;db.settings.consultRate=+setConsult.value||0;save();toast('تم حفظ الأسعار');render()}
}
function go(p){editing=null;current=p;render();scrollTo(0,0)}
function cancelEdit(){editing=null;render()}
function editRatio(id){editing=db.ratio.find(x=>x.id===id);current='ratio';render()}
function delRatio(id){if(confirm('حذف هذا اليوم؟')){db.ratio=db.ratio.filter(x=>x.id!==id);save();render()}}
function editTicket(id){editing=db.tickets.find(x=>x.id===id);current='tickets';render()}
function delTicket(id){if(confirm('حذف هذا الحجز؟')){db.tickets=db.tickets.filter(x=>x.id!==id);save();render()}}
function editExpense(id){editing=db.expenses.find(x=>x.id===id);current='expenses';render()}
function delExpense(id){if(confirm('حذف هذه الحركة؟')){db.expenses=db.expenses.filter(x=>x.id!==id);save();render()}}
function newCredential(){editing={id:null,title:'',username:'',password:''};showCredentialEditor()}
function showCredentialEditor(){
 const x=editing; const title=prompt('اسم البيانات (مثال: فيسبوك أو فيزا)',x.title||''); if(title===null)return;
 const username=prompt('اسم المستخدم / رقم الحساب',x.username||''); if(username===null)return;
 const password=prompt('كلمة المرور / الرقم السري',x.password||''); if(password===null)return;
 const obj={id:x.id||uid(),title,username,password};
 if(x.id)db.credentials=db.credentials.map(v=>v.id===x.id?obj:v);else db.credentials.push(obj);
 save();editing=null;render();toast('تم حفظ البيانات');
}
function editCredential(id){editing=db.credentials.find(x=>x.id===id);showCredentialEditor()}
function delCredential(id){if(confirm('حذف هذه البيانات؟')){db.credentials=db.credentials.filter(x=>x.id!==id);save();render()}}
function togglePw(id){const x=db.credentials.find(v=>v.id===id); if(x)alert('كلمة المرور: '+(x.password||'—'))}
function balance(){return sum(db.expenses,x=>x.type==='income'?x.amount:-x.amount)}
function exportData(){const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ahmed-private-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)}
function clearAll(){if(confirm('سيتم حذف كل البيانات من هذا الجهاز. هل أنت متأكد؟')){localStorage.removeItem(KEY);db=load();render();toast('تم مسح البيانات')}}
render();
