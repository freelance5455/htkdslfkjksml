const { CapacitorConfig } = require('@capacitor/cli');

const config = {
  appId: 'com.ahmed.private.manager',
  appName: 'Ahmed Private Manager',
  webDir: 'www',
  bundledWebRuntime: false
};

module.exports = config;
