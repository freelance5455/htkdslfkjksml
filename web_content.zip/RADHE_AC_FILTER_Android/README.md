# RADHE A/C FILTER — Android project

This Android Studio project wraps the supplied `RADHE_AC_FILTER.html` feature set in an Android WebView and adds native biometric authentication and encrypted local persistence.

## Included
- Android biometric prompt (fingerprint where available), with secure device credential fallback.
- Offline RPT import through Android's document picker.
- Existing account, name, and mobile search; full CIF search is also supported.
- CIF-linked accounts, balance summaries, sorting, customer detail sheet, copy-to-clipboard.
- CSV export through Android's Save dialog.
- PDF printing / Save as PDF through Android's system print dialog.
- Encrypted dataset file using AES-256-GCM with an Android Keystore key.
- Screenshot/Recents protection via `FLAG_SECURE`.
- No internet permission; no cloud sync.

## Build an installable APK

1. Install Android Studio on a computer and install Android SDK Platform 35 (or update `compileSdk` and install the matching SDK platform).
2. Open the `RADHE_AC_FILTER_Android` folder in Android Studio.
3. Allow Gradle to sync and download dependencies.
4. Connect an Android phone or use an emulator. Set up a fingerprint or secure device screen lock.
5. Run the `app` configuration to test.
6. For an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

Command line from this folder after Android SDK and Gradle dependencies are available:

```bash
gradle assembleDebug
```

## Security notes

- Imported customer rows are stored in the app's private internal storage, encrypted with AES-GCM. The AES key is held in Android Keystore and is not stored alongside the data file.
- The app requires biometric or device-credential authentication before exposing the WebView. This is an app access gate; the encryption key is Keystore-backed but is not configured as a per-operation biometric-authentication key.
- Android's system Save/Print UI is used for exported files. Exports intentionally leave the encrypted app-private store when the user selects a destination.
- Test with dummy RPT data first and follow your bank's rules before storing customer information on a personal device.

## Build environment limitation

The source project is provided, but an APK has not been generated in this workspace because the Android SDK/build tools are not installed here and the environment cannot download them. Build it in Android Studio using the steps above before installing it on a phone.
