package com.radhe.acfilter

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var root: FrameLayout
    private var authenticated = false
    private var authInProgress = false
    private var needsAuthentication = true
    private var pageLoaded = false
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingExportBytes: ByteArray? = null
    private var pendingExportMime: String = "text/csv"
    private var pendingExportName: String = "export.csv"

    private val openDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        fileChooserCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        fileChooserCallback = null
    }
    private val createDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val bytes = pendingExportBytes
        pendingExportBytes = null
        if (uri != null && bytes != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                toast("File saved")
            } catch (e: Exception) { toast("Could not save file: ${e.message}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(0x00002000, 0x00002000) // FLAG_SECURE: prevent screenshots and recents thumbnails
        root = FrameLayout(this)
        webView = WebView(this)
        webView.visibility = View.GONE
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        configureWebView()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.visibility == View.VISIBLE && webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        if (needsAuthentication && !authInProgress) authenticateUser()
    }

    override fun onStop() {
        super.onStop()
        if (authenticated && !isChangingConfigurations) {
            needsAuthentication = true
            authenticated = false
            webView.visibility = View.GONE
        }
    }

    private fun configureWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.setSupportMultipleWindows(false)
        webView.addJavascriptInterface(SecureBridge(), "AndroidSecureStorage")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                return try { openDocument.launch(arrayOf("*/*")); true }
                catch (e: Exception) { fileChooserCallback = null; callback?.onReceiveValue(null); false }
            }
        }
    }

    private fun authenticateUser() {
        val allowed = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
            toast("Set up a fingerprint or secure screen lock in Android Settings first.")
            return
        }
        authInProgress = true
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                authInProgress = false
                authenticated = true
                needsAuthentication = false
                webView.visibility = View.VISIBLE
                if (!pageLoaded) {
                    pageLoaded = true
                    webView.loadUrl("file:///android_asset/index.html")
                } else {
                    webView.evaluateJavascript("document.getElementById('loginOverlay').style.display='none';", null)
                }
            }
            override fun onAuthenticationFailed() { toast("Fingerprint not recognized. Try again.") }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                authInProgress = false
                authenticated = false
                needsAuthentication = true
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED && errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) toast(errString.toString())
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("RADHE A/C FILTER")
            .setSubtitle("Authenticate to access customer data")
            .setAllowedAuthenticators(allowed)
            .build()
        prompt.authenticate(info)
    }

    private fun toast(message: String) = runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }

    inner class SecureBridge {
        @JavascriptInterface fun saveDataset(json: String): Boolean = try {
            encryptedStore().write(json.toByteArray(Charsets.UTF_8)); true
        } catch (e: Exception) { false }

        @JavascriptInterface fun loadDataset(): String? {
            return try {
                val bytes = encryptedStore().read()
                if (bytes == null) null else String(bytes, Charsets.UTF_8)
            } catch (e: Exception) { null }
        }

        @JavascriptInterface fun saveFile(name: String, base64: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                runOnUiThread {
                    pendingExportBytes = bytes
                    pendingExportName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "export.csv" }
                    pendingExportMime = if (pendingExportName.endsWith(".csv", true)) "text/csv" else "application/octet-stream"
                    createDocument.launch(pendingExportName)
                }
            } catch (e: Exception) { toast("Could not prepare export: ${e.message}") }
        }

        @JavascriptInterface fun printHtml(html: String) {
            runOnUiThread {
                try {
                    val printView = WebView(this@MainActivity)
                    printView.settings.javaScriptEnabled = false
                    printView.visibility = View.INVISIBLE
                    root.addView(printView, FrameLayout.LayoutParams(-1, -1))
                    printView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String?) {
                            val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                            val adapter = view.createPrintDocumentAdapter("RADHE_AC_FILTER")
                            manager.print("RADHE A-C FILTER", adapter,
                                PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR).build())
                        }
                    }
                    printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
                } catch (e: Exception) { toast("Unable to open PDF/print: ${e.message}") }
            }
        }
    }

    private fun encryptedStore() = EncryptedDatasetStore(this)
}

private class EncryptedDatasetStore(context: Context) {
    private val file = File(context.filesDir, "radhe_customer_dataset.enc")
    private val alias = "radhe_ac_filter_dataset_key_v1"

    @Synchronized fun write(plain: ByteArray) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(plain)
        val iv = cipher.iv
        FileOutputStream(file).use { out -> out.write(iv.size); out.write(iv); out.write(encrypted); out.fd.sync() }
    }

    @Synchronized fun read(): ByteArray? {
        if (!file.exists()) return null
        val all = FileInputStream(file).use { it.readBytes() }
        require(all.isNotEmpty()) { "Encrypted dataset is empty" }
        val ivLength = all[0].toInt() and 0xff
        require(ivLength in 12..16 && all.size > 1 + ivLength) { "Encrypted dataset is damaged" }
        val iv = all.copyOfRange(1, 1 + ivLength)
        val encrypted = all.copyOfRange(1 + ivLength, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(encrypted)
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .setKeySize(256)
            .build())
        return generator.generateKey()
    }
}
