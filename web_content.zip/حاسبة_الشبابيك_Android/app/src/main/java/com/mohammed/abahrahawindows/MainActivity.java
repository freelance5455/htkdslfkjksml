package com.mohammed.abahrahawindows;

import android.app.*;
import android.os.*;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.*;
import android.view.*;
import android.widget.Toast;
import android.content.*;
import android.net.Uri;
import java.util.*;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){ super.onCreate(b);
    web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
    web.setWebViewClient(new WebViewClient());
    web.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{
      Toast.makeText(this,"تم إنشاء ملف النتائج. إذا لم يظهر في الاستوديو افتحه من مجلد التنزيلات.",Toast.LENGTH_LONG).show();
      Intent i=new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse(url)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try{startActivity(i);}catch(Exception e){}
    });
    web.addJavascriptInterface(new Object(){ @JavascriptInterface public void print(){ printPage(); } }, "AndroidPrint");
    web.loadUrl("file:///android_asset/index.html");
  }
  public void printPage(){
    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
    pm.print("حاسبة الشبابيك 7000", web.createPrintDocumentAdapter("حاسبة الشبابيك 7000"), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
  }
  @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
