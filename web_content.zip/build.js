// Uso: node build.js "planilha.xlsm"  -> gera www/dados.js e dist/anomalias.html (arquivo único, abre em qualquer navegador)
const fs=require('fs'),path=require('path');
require('./www/reader.js');
(async()=>{
  const f=process.argv[2];if(!f){console.log('Uso: node build.js planilha.xlsm');process.exit(1)}
  const b=fs.readFileSync(f),d=await lerExcel(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength));
  fs.writeFileSync('www/dados.js','window.DADOS='+JSON.stringify(d)+';');
  let h=fs.readFileSync('www/index.html','utf8');
  h=h.replace(/<link rel="stylesheet" href="([^"]+)">/,(_,p)=>'<style>'+fs.readFileSync('www/'+p,'utf8')+'</style>')
     .replace(/<script src="([^"]+)"><\/script>/g,(_,p)=>'<script>'+fs.readFileSync('www/'+p,'utf8')+'</script>');
  fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/anomalias.html',h);
  console.log(d.rows.length+' etiquetas | atualizado até '+d.atualizado+' | dist/anomalias.html gerado');
})().catch(e=>{console.error(e.message);process.exit(1)});
