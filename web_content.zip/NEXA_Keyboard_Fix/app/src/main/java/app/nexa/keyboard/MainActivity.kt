package app.nexa.keyboard

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Pantalla de configuración y diagnóstico de NEXA Keyboard. */
class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(0xFF080D18.toInt())
        }

        val title = TextView(this).apply {
            text = "NEXA KEYBOARD"
            textSize = 24f
            setTextColor(0xFF45E5FF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Configuración del teclado octagonal"
            textSize = 14f
            setTextColor(0xFFDCE7F5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }
        root.addView(subtitle, matchWrap())

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFF172235.toInt())
        }
        root.addView(status, matchWrap())

        root.addView(actionButton("1 · ACTIVAR NEXA") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, buttonParams())

        root.addView(actionButton("2 · ELEGIR NEXA COMO TECLADO") {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }, buttonParams())

        root.addView(actionButton("ACTUALIZAR ESTADO") { refreshStatus() }, buttonParams())

        val note = TextView(this).apply {
            text = "Android no permite que una aplicación active un teclado por sí sola. Actívalo en Ajustes y luego selecciónalo en el selector del sistema."
            textSize = 13f
            setTextColor(0xFF9EADC4.toInt())
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun refreshStatus() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val component = ComponentName(this, NexaIME::class.java)
        val registered = packageManager.getServiceInfo(component, 0) != null
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val selectedSetting = Settings.Secure.getString(
            contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD
        )
        val selected = selectedSetting?.substringBefore('/') == packageName &&
            selectedSetting.substringAfter('/', "").endsWith("NexaIME")

        status.text = buildString {
            append(if (registered) "✓ Servicio de teclado registrado" else "✗ Servicio no registrado")
            append("\n")
            append(if (enabled) "✓ NEXA está activado" else "○ NEXA todavía no está activado")
            append("\n")
            append(if (selected) "✓ NEXA es el teclado seleccionado" else "○ NEXA no es el teclado actual")
        }
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
    private fun buttonParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(12) }
}
