# Changelog

## 1.0.0
- First functional local-first release scaffold.
- Arabic RTL interface, POS, inventory, invoices, customers, supplier purchases, expenses, summary reports, themes and JSON backup.
- Capacitor Android wrapper configuration and GitHub Actions debug APK workflow.
