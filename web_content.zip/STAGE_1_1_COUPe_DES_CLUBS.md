# CGD V117 — Socle 1.1 : Coupe des Clubs

## Règlement historique repris
- 36 clubs issus de Super League, Ligue A et Ligue B (12 par division).
- Entrée progressive : Ligue B au 1er tour ; Ligue A au 2e ; Super League au 3e.
- Sept étapes affichées : 1er tour, 2e tour, 3e tour, 4e tour, 5e tour, 6e tour, finale.
- Match unique, tirage sans têtes de série, exemption automatique si tableau impair.
- Prolongation puis tirs au but.
- Fenêtre : mois 8, jours 6 à 30.

## Arithmétique du tableau
12 → 6 qualifiés ; +12 → 18 → 9 ; +12 → 21 → 10 matchs + 1 exempt = 11 ; 11 → 5 matchs + 1 exempt = 6 ; 6 → 3 ; 3 → 1 match + 1 exempt = 2 ; finale : 1 champion. Total : 35 matchs.

## Connexion V117
- Module `src/club-cup.js` dédié.
- Enregistrement des rencontres dans le calendrier central avec `competitionId` propre.
- Simulation automatique par `simulateBoardMatch` ; le match du club dirigé peut rester en attente et être joué manuellement.
- Progression automatique du tableau après homologation ; garde anti-doublon via `recordResult`.
- Statistiques de coupe séparées des statistiques de championnat.

## Tests et limites
- 77 tests automatisés réussis ; syntaxe de tous les fichiers `src/*.js` vérifiée.
- Tests couvrant les entrées progressives, les exemptions, les 7 tours, le total de 35 matchs, le calendrier, les stats séparées, la simulation IA et le résultat manuel.
- Pas encore de validation navigateur réelle.
- Le calendrier mensuel global n'est pas encore implémenté : les métadonnées mois/jours sont portées sur les rencontres, mais l'automatisation de l'ouverture de fenêtre attend ce calendrier annuel.

## Mise à jour de calendrier (socle 1.2)
La fenêtre « mois 8, jours 6 à 30 » décrite dans le premier état de ce document est **remplacée** par la règle confirmée : chaque jeudi du mois lunaire pendant la saison régulière jusqu'à la finale. Voir `STAGE_1_2_CALENDRIER_COMPETITIONS.md`.
