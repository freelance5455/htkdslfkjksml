FOCUS BLOCKER - ANDROID STUDIO SOURCE PROJECT

This ZIP is a starter Android project containing the HTML user interface and an Android Accessibility Service.
It is NOT a ready-to-install APK. Build it using Android Studio with Android SDK 35 and Gradle.

HOW TO BUILD
1. Install Android Studio on a computer.
2. Open this FocusBlocker folder as a project.
3. Allow Gradle sync; install SDK 35 if prompted.
4. Build > Build APK(s).
5. Install the resulting APK on your Android phone.
6. Open Focus Blocker, switch on the desired apps, and tap Enable Accessibility.
7. In Android Accessibility settings, enable Focus Blocker.

IMPORTANT
- Accessibility access is powerful. This app uses it to read visible interface text and press Back when configured markers are detected. No data is sent off-device.
- Detection is heuristic and can be inaccurate, especially across app versions/languages. A marker like "Reels" may occur outside the feed and cause a false block; testing and refinement are needed.
- This is an educational starter, not a polished/production-ready app. YouTube/Instagram/Facebook may change their UI at any time.
