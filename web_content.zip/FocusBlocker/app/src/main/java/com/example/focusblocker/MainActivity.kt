package com.example.focusblocker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(Bridge(), "Android")
        }

        // Native fallback button: works even if the HTML button/JS bridge fails.
        val accessibilityButton = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { openAccessibilitySettings() }
        }

        layout.addView(accessibilityButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        layout.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(layout)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                // Android may restrict settings launch on some devices.
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread { this@MainActivity.openAccessibilitySettings() }
        }

        @JavascriptInterface
        fun setBlocked(app: String, enabled: Boolean) {
            getSharedPreferences("focus", MODE_PRIVATE).edit().putBoolean(app, enabled).apply()
        }
    }
}
