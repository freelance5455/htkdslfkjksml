package com.example.focusblocker

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class FocusAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        val prefs = getSharedPreferences("focus", MODE_PRIVATE)
        val enabled = when (pkg) {
            "com.google.android.youtube" -> prefs.getBoolean("youtube", false)
            "com.instagram.android" -> prefs.getBoolean("instagram", false)
            "com.facebook.katana", "com.facebook.lite" -> prefs.getBoolean("facebook", false)
            else -> false
        }
        if (!enabled) return
        val root = rootInActiveWindow ?: return
        val text = collectText(root).lowercase()
        // Heuristic matching: app UI text varies by release and language; false positives are possible.
        val markers = when (pkg) {
            "com.google.android.youtube" -> listOf("shorts", "create a short")
            "com.instagram.android" -> listOf("reels", "reel")
            else -> listOf("reels", "reel")
        }
        if (markers.any { text.contains(it) }) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun collectText(node: AccessibilityNodeInfo): String {
        val out = StringBuilder()
        node.text?.let { out.append(it).append(' ') }
        node.contentDescription?.let { out.append(it).append(' ') }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                out.append(collectText(child))
                child.recycle()
            }
        }
        return out.toString()
    }

    override fun onInterrupt() {}
}
