# FamilyClinic — Complete Production Deployment Checklist

This package combines the security, billing, clinical-document, pharmacy/laboratory, partner, referral, notification and operational foundations built through the current development phases.

## Before real patients
- Set `NODE_ENV=production`.
- Generate strong values for `FAMILYCLINIC_SESSION_SECRET` and all other secrets.
- Set the real Paystack secret key only in the server environment; never put it in HTML/JavaScript.
- Configure Paystack callback/webhook URL and verify webhook signatures server-side.
- Replace all demo admin/partner credentials and disable demo accounts.
- Move SQLite to a managed production database with encryption, backups and point-in-time recovery.
- Put the application behind HTTPS/TLS and a reverse proxy/WAF.
- Use secure object storage for medical files; do not store sensitive files in public web directories.
- Implement verified professional onboarding for doctors, pharmacists and laboratory scientists.
- Replace signature placeholders with an approved professional digital-signature/authorization workflow.
- Configure actual affiliated pharmacies/laboratories and remove placeholder facilities.
- Complete NDPR/privacy, consent, retention, breach-response and clinical governance review with appropriate Nigerian counsel/healthcare compliance advisers.
- Run vulnerability scanning, dependency updates, penetration testing and backup-restore testing.

## Partner portal
Open `/partner-dashboard.html`. Demo credentials are provided only for local testing and must be replaced before deployment.

## Payment flow
Patient starts a subscription payment → server initializes Paystack transaction → Paystack checkout → callback/webhook → server verifies transaction → subscription becomes active. Never activate access merely because a browser says payment succeeded.

## Clinical workflow
Doctor creates prescription/investigation → patient views/downloads sheet → patient selects affiliated pharmacy/laboratory → fulfilment request is assigned → partner processes it → patient receives status/result notification.

## PWA/mobile readiness
`manifest.webmanifest` and `service-worker.js` provide the foundation for installable mobile web use. A full native Android/iOS app can consume the same secured API later.

## Emergency plan
The emergency subscription is intentionally short-lived. Production clinical governance should additionally define what emergency cases can safely be handled through telemedicine and when immediate physical emergency care is mandatory.
