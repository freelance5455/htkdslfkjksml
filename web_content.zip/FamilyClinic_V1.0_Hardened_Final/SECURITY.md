# FamilyClinic Phase 8 — Security & Production Checklist

## Added in this phase
- Database-backed hashed session tokens with expiry
- Separate patient, doctor and admin sessions
- HttpOnly SameSite cookies; Secure + __Host- cookies in production
- Role/ownership checks for patient subscription and protected clinical endpoints
- Password reset token flow (development token is returned only outside production)
- Audit log table for authentication/security events
- Expired-session cleanup
- Development payment/subscription activation disabled in production
- Privacy notice page
- Dashboard identity now comes from authenticated `/api/me`, not browser localStorage
- Security headers and rate limiting retained

## Before real patient data or real payments
1. Deploy only behind HTTPS.
2. Set strong production environment secrets; never commit `.env`.
3. Use bcrypt password hashes for doctor/admin credentials.
4. Replace SQLite with a managed production database and encrypted backups.
5. Integrate Paystack server-side with verified webhooks; never trust browser payment status.
6. Add secure encrypted medical-document storage with signed/expiring access URLs.
7. Implement verified professional accounts and authorization for doctors, pharmacists and laboratories.
8. Implement real digital-signature/approval workflow; blank signature fields are not authorization.
9. Complete Nigerian NDPR/privacy review, consent wording, retention/deletion policy and data-subject request process.
10. Add monitoring, incident response, vulnerability scanning and recovery drills.
11. Configure CORS only if a separate frontend domain is used; keep same-origin deployment where possible.
12. Rotate all development/demo credentials before launch.

## Development
`npm install` then `npm start`

## Important
This package is a security-focused development build. It is **not a certification of regulatory compliance or clinical production readiness**.
