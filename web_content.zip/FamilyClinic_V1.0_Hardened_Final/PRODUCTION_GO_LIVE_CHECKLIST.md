# FamilyClinic V1.0 — Go-Live Gate

Do not switch to live patient care until every required gate is checked.

## Infrastructure
- [ ] HTTPS certificate active
- [ ] Managed production database configured
- [ ] Encrypted backups tested
- [ ] Monitoring and alerting active
- [ ] Disaster recovery tested
- [ ] Production secrets stored in platform secret manager

## Security
- [ ] Unique admin account
- [ ] Unique doctor accounts
- [ ] Unique pharmacy/lab accounts
- [ ] MFA enabled where supported
- [ ] Password reset delivery configured
- [ ] Penetration test completed
- [ ] Dependency/security scan completed
- [ ] No secrets in Git history

## Payments
- [ ] Paystack live secret configured server-side
- [ ] Webhook endpoint configured
- [ ] Webhook signature verification tested
- [ ] Successful/failed/refunded payment paths tested
- [ ] Subscription expiry tested

## Clinical
- [ ] Professional registration/identity verification completed
- [ ] Role permissions tested
- [ ] Clinical record access reviewed
- [ ] Prescription authorization/signature process approved
- [ ] Laboratory result verification process approved
- [ ] Referral workflow approved
- [ ] Emergency escalation process documented

## Privacy / governance
- [ ] Privacy notice approved
- [ ] Consent flow approved
- [ ] Data retention/deletion policy approved
- [ ] Breach response procedure approved
- [ ] NDPR/legal review completed
