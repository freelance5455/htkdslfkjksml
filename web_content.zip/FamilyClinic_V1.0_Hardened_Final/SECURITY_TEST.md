# FamilyClinic V1.0 — Security Smoke Test

After deployment, test these cases from a browser and from an API client:

1. `/server.js` returns 404.
2. `/.env` returns 404.
3. `/data/familyclinic.db` returns 404.
4. Wrong patient cannot read another patient's records, subscriptions, prescriptions, investigations, pharmacy orders or lab requests.
5. Wrong doctor cannot use a patient session.
6. Wrong partner role cannot access the other partner portal.
7. Replaying a Paystack webhook does not create a second active subscription.
8. Invalid Paystack signature returns 401.
9. Development payment activation is unavailable in production.
10. More than the login rate limit is rejected temporarily.
11. Logout invalidates the server session.
12. Password reset invalidates existing patient sessions.
13. Expired subscriptions return 403 for subscription-protected services.
14. Browser requests from an unexpected Origin are rejected for state-changing API calls.
15. Verify the HTTPS response contains HSTS and the security headers.

For a healthcare production launch, these smoke tests are not a substitute for an independent penetration test and clinical/privacy review.
