FAMILYCLINIC PHASE 2 — WORKING ACCOUNT & APPOINTMENT MVP

What is included
- Approved FamilyClinic mobile design
- Correct logo and supplied doctor photos
- Clean homepage + mobile ☰ menu
- Patient registration with full clerking fields
- Automatic Patient IDs: FC001, FC002, FC003...
- Login using Patient ID OR email OR phone number
- Password hashing with bcrypt
- Patient dashboard
- Appointment request API and appointment references
- SQLite database for development
- Helmet and rate limiting

Run on a computer/server
1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run: npm install
4. Run: npm start
5. Open http://localhost:3000

IMPORTANT FOR PRODUCTION
This is a development MVP, not yet suitable for real patient data.
Before launch, move the database to managed PostgreSQL, use persistent secure sessions, HTTPS, encrypted backups, audit logging, role-based access control, secure document storage, email/SMS/WhatsApp verification, proper password reset, consent/privacy controls, and healthcare/NDPR compliance review.

For the Samsung phone, the existing phone-ready ZIP remains the easiest way to preview the interface. The Phase 2 package is intended to be deployed to a server/cloud host.


PHASE 3 ADDITIONS
- Doctor portal: /doctor-dashboard.html
- Development doctor login: doctor@familyclinic.com / ChangeMe123!
- Doctor can list/search patients, open full patient history, and create consultation notes.
- Backend tables added for consultations, prescriptions, investigations and referrals.
- APIs added for saving prescriptions, investigation requests and referrals.
- This is still development software; do not enter real patient data until production security/deployment is completed.


## Phase 4 — Payment + Appointment Workflow

Added:
- Payment request creation endpoint
- Payment reference generation
- Payment status lookup
- Development payment confirmation endpoint
- Frontend payment screen
- Paystack integration point for production

### Production payment setup
Set up a Paystack account and server-side secret key, then replace the development initialization with Paystack's official transaction initialization and server-side verification/webhook handling. Never expose the secret key in browser code and never trust a browser-only "paid" response.

This Phase 4 package is still a development MVP and must not be used to process real patient payments or store real clinical data until production security, provider verification, privacy/compliance, and deployment controls are completed.


## Phase 5 — WhatsApp Consultation

Added:
- Paid appointment → WhatsApp consultation gate
- Payment-status verification before WhatsApp access
- Consultation reference generation
- Pre-filled WhatsApp message containing appointment/payment/doctor/service details
- FamilyClinic WhatsApp number configurable with `FAMILYCLINIC_WHATSAPP`
- Patient-facing WhatsApp consultation form

### Production requirement
The WhatsApp link is a workflow bridge, not a substitute for secure clinical infrastructure. Before real patient use, implement authenticated sessions, provider-side payment verification/webhooks, access controls, consent/privacy notices, audit logging, secure clinical record storage, and an approved WhatsApp Business/API integration where appropriate.


## Phase 6 — Admin Dashboard

Added:
- Admin authentication
- Overview counts
- Patient search/list
- Appointment list
- Payment list
- Consultation list
- Doctor roster
- Doctor availability management
- Availability removal

Development admin:
- Email: `admin@familyclinic.com`
- Password: `AdminChangeMe123!`

Change these credentials through environment variables before any deployment. This remains a development MVP; production needs persistent secure authentication, RBAC, audit logs, CSRF/session protections, secure secrets, encryption, backups and compliance controls.


## Subscription Billing Update

FamilyClinic now uses subscription-based access instead of a single generic consultation payment.

Plans configured in this development build:
- 1 month: ₦10,000
- 2 months: ₦18,000
- 3 months: ₦25,000
- Emergency: ₦15,000 with a 24-hour emergency access window

The exact prices are configuration values and can be changed before launch.

### Access rule
The backend checks the patient's active subscription and expiry time. When `expires_at` has passed, access is blocked until a new subscription is purchased.

### Production payment requirement
The current activation endpoint is DEVELOPMENT ONLY. In production, Paystack (or another approved provider) must verify the transaction server-side/webhook before a subscription is activated. Never activate subscriptions based solely on a browser response.

Recommended production model:
- One subscription gives access to FamilyClinic telemedicine services for its active period.
- Emergency is a separate, higher-priced short-term access option.
- Expired subscriptions automatically lose access.
- Keep clinical records after expiry, but restrict new consultation/service access until renewed.
- Add receipts, renewal notifications, grace-period policy (if desired), refunds and payment reconciliation before launch.


## Phase 7 — Pharmacy + Laboratory

Added:
- Patient pharmacy orders
- Pickup or delivery selection
- Pharmacy order status workflow
- Patient laboratory requests
- Laboratory result storage/display
- Admin pharmacy order view
- Admin laboratory request/result view
- Subscription gate on patient pharmacy/lab access

Production requirements include verified prescriptions, pharmacist/laboratory role accounts, secure file storage for lab reports, access control, audit logs, delivery/payment integration and full privacy/security hardening.


## Prescription & Investigation Document Module

Patients now have a dedicated dashboard area for:
- Prescription sheets
- Download/print prescription sheet
- Doctor name and signature field
- Pharmacist name: Pharmacist Victor Quara
- Pharmacist signature field
- Investigation request sheets
- Doctor name and signature field
- Download/print investigation sheet
- Affiliated pharmacy directory
- Affiliated laboratory/diagnostic directory
- Location links

Important: the sample affiliate names are placeholders and must be replaced by FamilyClinic's real partner facilities before launch. Prescription/pharmacy and laboratory workflows should be role-authenticated and clinically verified in production.

## Phase 9 — Paystack production payment flow
This build adds server-side Paystack transaction initialization, amount/currency validation, verification, signed webhook handling, idempotent subscription activation, and a payment callback page. The Paystack secret key is never sent to the browser.

Before going live:
1. Set `PAYSTACK_SECRET_KEY` on the server (test key first, then live key).
2. Set `PAYSTACK_CALLBACK_URL` to your HTTPS callback URL.
3. Configure Paystack's webhook URL as `https://YOUR-DOMAIN/api/paystack/webhook`.
4. Test successful, failed, abandoned and bank-transfer payments with Paystack test mode.
5. Confirm the amount and subscription plan before granting access.
6. Use HTTPS in production and keep `ALLOW_DEV_PAYMENT=false`.

Paystack's current documentation requires backend transaction initialization, server-side verification, and recommends signed webhooks for reliable fulfilment.

## Complete platform extensions
- Partner portal: `partner-dashboard.html`
- Partner APIs for pharmacy order fulfilment and laboratory result entry
- Patient notifications
- Extended referral tracking
- Admin partner/audit/referral endpoints
- PWA manifest/service worker foundation
- Production deployment checklist: `PRODUCTION_DEPLOYMENT.md`
