
// ---------------- PRESCRIPTION + INVESTIGATION SHEETS + AFFILIATES ----------------
db.exec(`
CREATE TABLE IF NOT EXISTS prescription_sheets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  prescription_ref TEXT UNIQUE NOT NULL,
  patient_id TEXT NOT NULL,
  consultation_id INTEGER,
  doctor_name TEXT NOT NULL,
  doctor_signature TEXT,
  pharmacist_name TEXT DEFAULT 'Pharmacist Victor Quara',
  pharmacist_signature TEXT,
  medicines TEXT NOT NULL,
  instructions TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS investigation_sheets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  investigation_ref TEXT UNIQUE NOT NULL,
  patient_id TEXT NOT NULL,
  consultation_id INTEGER,
  doctor_name TEXT NOT NULL,
  doctor_signature TEXT,
  investigations TEXT NOT NULL,
  clinical_note TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS affiliated_pharmacies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  phone TEXT,
  city TEXT DEFAULT 'Enugu',
  active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS affiliated_laboratories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  phone TEXT,
  city TEXT DEFAULT 'Enugu',
  services TEXT,
  active INTEGER DEFAULT 1
);
`);


// ---------------- PHASE 7: PHARMACY + LABORATORY ----------------
db.exec(`
CREATE TABLE IF NOT EXISTS pharmacy_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_ref TEXT UNIQUE NOT NULL,
  patient_id TEXT NOT NULL,
  consultation_id INTEGER,
  prescription_id INTEGER,
  medication TEXT NOT NULL,
  quantity TEXT,
  instructions TEXT,
  status TEXT DEFAULT 'pending',
  fulfillment_method TEXT DEFAULT 'pickup',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS lab_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_ref TEXT UNIQUE NOT NULL,
  patient_id TEXT NOT NULL,
  consultation_id INTEGER,
  investigation TEXT NOT NULL,
  clinical_note TEXT,
  status TEXT DEFAULT 'requested',
  result_text TEXT,
  result_file TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  completed_at TEXT
);
`);


// ---------------- SUBSCRIPTION BILLING ----------------
db.exec(`
CREATE TABLE IF NOT EXISTS subscriptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subscription_ref TEXT UNIQUE NOT NULL,
  patient_id TEXT NOT NULL,
  plan TEXT NOT NULL,
  amount INTEGER NOT NULL,
  currency TEXT DEFAULT 'NGN',
  status TEXT DEFAULT 'pending',
  starts_at TEXT,
  expires_at TEXT,
  payment_ref TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);


// ---------------- PHASE 6: ADMIN DATA ----------------
db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS doctor_availability (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  doctor TEXT NOT NULL,
  day TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  active INTEGER DEFAULT 1
);
`);


db.exec(`
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_ref TEXT UNIQUE NOT NULL,
  appointment_ref TEXT,
  patient_id TEXT,
  amount INTEGER NOT NULL,
  currency TEXT DEFAULT 'NGN',
  method TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  provider_ref TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  paid_at TEXT
);
`);

const express=require("express");
const path=require("path");
const fs=require("fs");
const bcrypt=require("bcryptjs");
const Database=require("better-sqlite3");
const helmet=require("helmet");
const rateLimit=require("express-rate-limit");
const crypto=require("crypto");

const IS_PRODUCTION = process.env.NODE_ENV === "production";
const SESSION_TTL_MS = 1000*60*60*8;
const SESSION_COOKIE = IS_PRODUCTION ? "__Host-familyclinic_session" : "familyclinic_session";
const DOCTOR_COOKIE = IS_PRODUCTION ? "__Host-familyclinic_doctor" : "familyclinic_doctor";
if(process.env.TRUST_PROXY === "true") app.set("trust proxy",1);
const ADMIN_COOKIE = IS_PRODUCTION ? "__Host-familyclinic_admin" : "familyclinic_admin";

if(IS_PRODUCTION){
  const requiredEnv=["FAMILYCLINIC_ADMIN_EMAIL","FAMILYCLINIC_ADMIN_PASSWORD_HASH","DOCTOR_EMAIL","DOCTOR_PASSWORD_HASH","SESSION_SECRET","PAYSTACK_SECRET_KEY","PAYSTACK_CALLBACK_URL"];
  const missing=requiredEnv.filter(k=>!process.env[k]);
  if(missing.length) throw new Error(`Missing required production environment variables: ${missing.join(", ")}`);
  if(process.env.SESSION_SECRET.length < 64) throw new Error("SESSION_SECRET must be at least 64 characters in production.");
  if(process.env.ALLOW_DEV_PAYMENT === "true") throw new Error("ALLOW_DEV_PAYMENT must be false in production.");
}

const app=express();
const PORT=process.env.PORT||3000;
const dataDir=path.join(__dirname,"data");fs.mkdirSync(dataDir,{recursive:true});
const db=new Database(path.join(dataDir,"familyclinic.db"));
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS patients(
 id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id TEXT UNIQUE NOT NULL,
 first_name TEXT NOT NULL, middle_name TEXT, last_name TEXT NOT NULL, dob TEXT,
 sex TEXT, marital_status TEXT, occupation TEXT, nationality TEXT,
 state_of_origin TEXT, lga TEXT, city TEXT, address TEXT,
 phone TEXT UNIQUE NOT NULL, whatsapp TEXT, email TEXT UNIQUE,
 password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS patient_history(
 patient_id TEXT PRIMARY KEY REFERENCES patients(patient_id),
 emergency_name TEXT, emergency_relationship TEXT, emergency_phone TEXT, emergency_alt_phone TEXT, emergency_address TEXT,
 presenting_complaint TEXT, hpc TEXT, allergies TEXT, medical_conditions TEXT, current_medications TEXT,
 surgeries TEXT, admissions TEXT, blood_group TEXT, genotype TEXT, height TEXT, weight TEXT,
 blood_pressure TEXT, pulse TEXT, respiratory_rate TEXT, temperature TEXT, spo2 TEXT, immunization TEXT,
 family_history TEXT, smoking TEXT, alcohol TEXT, social_history TEXT, consultation_method TEXT,
 lmp TEXT, pregnancy_status TEXT, gravida TEXT, para TEXT, obstetric_history TEXT, gyn_history TEXT
);
CREATE TABLE IF NOT EXISTS consultations(
 id INTEGER PRIMARY KEY AUTOINCREMENT, reference TEXT UNIQUE NOT NULL, patient_id TEXT NOT NULL,
 doctor_name TEXT NOT NULL, complaint TEXT, history TEXT, examination TEXT, diagnosis TEXT,
 treatment_plan TEXT, follow_up_date TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS prescriptions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, consultation_reference TEXT NOT NULL, patient_id TEXT NOT NULL,
 medication TEXT NOT NULL, instructions TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS investigations(
 id INTEGER PRIMARY KEY AUTOINCREMENT, consultation_reference TEXT NOT NULL, patient_id TEXT NOT NULL,
 investigation TEXT NOT NULL, clinical_note TEXT, result TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS referrals(
 id INTEGER PRIMARY KEY AUTOINCREMENT, consultation_reference TEXT NOT NULL, patient_id TEXT NOT NULL,
 destination TEXT NOT NULL, reason TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS appointments(
 id INTEGER PRIMARY KEY AUTOINCREMENT, reference TEXT UNIQUE NOT NULL, patient_id TEXT,
 first_name TEXT NOT NULL, last_name TEXT NOT NULL, phone TEXT NOT NULL, service TEXT,
 method TEXT, preferred_date TEXT, preferred_time TEXT, complaint TEXT,
 status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

// ---------------- PHASE 8: SECURITY / SESSIONS / AUDIT ----------------
db.exec(`
CREATE TABLE IF NOT EXISTS sessions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 token_hash TEXT UNIQUE NOT NULL,
 actor_type TEXT NOT NULL,
 actor_id TEXT NOT NULL,
 expires_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS audit_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor_type TEXT NOT NULL,
 actor_id TEXT,
 action TEXT NOT NULL,
 target_type TEXT,
 target_id TEXT,
 ip_address TEXT,
 user_agent TEXT,
 details TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE TABLE IF NOT EXISTS password_reset_tokens (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 patient_id TEXT NOT NULL,
 token_hash TEXT UNIQUE NOT NULL,
 expires_at TEXT NOT NULL,
 used_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

app.disable("x-powered-by");
app.use(helmet({contentSecurityPolicy:false,referrerPolicy:{policy:"no-referrer"},crossOriginOpenerPolicy:{policy:"same-origin"}}));
app.use((req,res,next)=>{
  res.setHeader("Content-Security-Policy", "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline' https:; script-src 'self' 'unsafe-inline' https://js.paystack.co; connect-src 'self' https://api.paystack.co https://*.paystack.co wss:; font-src 'self' data: https:; media-src 'self' blob: https:;");
  next();
});
app.use((req,res,next)=>{
  res.setHeader("Permissions-Policy","camera=(self), microphone=(self), geolocation=(), payment=(self)");
  if(IS_PRODUCTION) res.setHeader("Strict-Transport-Security","max-age=31536000; includeSubDomains");
  next();
});
const apiLimiter=rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false,message:{error:"Too many requests. Please try again later."}});
const authLimiter=rateLimit({windowMs:15*60*1000,max:8,standardHeaders:true,legacyHeaders:false,message:{error:"Too many login attempts. Please wait and try again."}});
app.use(express.json({limit:"512kb", verify:(req,res,buf)=>{req.rawBody=Buffer.from(buf);}}));
app.use(express.urlencoded({extended:false,limit:"128kb"}));
app.use("/api",apiLimiter);
// Block direct access to server code, environment files, databases and working directories.
app.use((req,res,next)=>{
  const pathName=decodeURIComponent(req.path||"");
  if(/^\/(?:server(?:\.v0)?\.js|package(?:-lock)?\.json|\.env(?:\..*)?|data(?:\/|$)|node_modules(?:\/|$)|SECURITY(?:\.md)?|PRODUCTION_.*|README(?:\.md)?)/i.test(pathName)) return res.status(404).send("Not found");
  next();
});
app.use(express.static(__dirname,{dotfiles:"deny",index:"index.html",extensions:["html"]}));
function sameOriginMutation(req,res,next){
  if(req.method==="GET" || req.path==="/api/paystack/webhook") return next();
  const origin=req.get("origin");
  if(!origin) return next(); // non-browser clients; authentication/payment signatures still apply
  const host=`${req.protocol}://${req.get("host")}`;
  if(origin!==host) return res.status(403).json({error:"Cross-origin request blocked."});
  next();
}
app.use(sameOriginMutation);

const TOKEN_PEPPER = process.env.SESSION_SECRET || "development-only-token-pepper";
function hashToken(token){return crypto.createHmac("sha256",TOKEN_PEPPER).update(token).digest("hex");}
function createSession(actorType,actorId){
  const token=crypto.randomBytes(48).toString("base64url");
  const expires=new Date(Date.now()+SESSION_TTL_MS).toISOString();
  db.prepare(`INSERT INTO sessions(token_hash,actor_type,actor_id,expires_at) VALUES(?,?,?,?)`).run(hashToken(token),actorType,String(actorId),expires);
  return {token,expires};
}
function clearExpiredSessions(){db.prepare("DELETE FROM sessions WHERE expires_at<=?").run(new Date().toISOString());}
setInterval(clearExpiredSessions,60*60*1000).unref();
function cookieValue(req,name){
 const c=req.headers.cookie||""; const m=c.match(new RegExp("(?:^|;\\s*)"+name.replace(/[.*+?^${}()|[\\]\\]/g,"\\$&")+"=([^;]+)"));
 return m?decodeURIComponent(m[1]):null;
}
function setSessionCookie(res,name,token,maxAge=Math.floor(SESSION_TTL_MS/1000)){
 const secure=IS_PRODUCTION?"; Secure":"";
 const host=IS_PRODUCTION && name.startsWith("__Host-")?"":"; Domain=";
 res.setHeader("Set-Cookie",`${name}=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure}`);
}
function deleteCookie(res,name){res.setHeader("Set-Cookie",`${name}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${IS_PRODUCTION?"; Secure":""}`);}
function getSession(req,name){
 const token=cookieValue(req,name); if(!token)return null;
 const row=db.prepare("SELECT * FROM sessions WHERE token_hash=? AND expires_at>?").get(hashToken(token),new Date().toISOString());
 return row||null;
}
function audit(req,actorType,actorId,action,targetType="",targetId="",details=""){
 try{db.prepare(`INSERT INTO audit_logs(actor_type,actor_id,action,target_type,target_id,ip_address,user_agent,details) VALUES(?,?,?,?,?,?,?,?)`).run(actorType,actorId||null,action,targetType||null,targetId||null,req.ip||null,req.get("user-agent")||null,details||null);}catch(e){console.error("audit log failed",e.message)}
}
function auth(req,res,next){
 const s=getSession(req,SESSION_COOKIE);
 if(!s || s.actor_type!=="patient")return res.status(401).json({error:"Please log in."});
 db.prepare("UPDATE sessions SET last_seen_at=CURRENT_TIMESTAMP WHERE id=?").run(s.id);
 req.patientId=s.actor_id; req.sessionId=s.id; next();
}
function patientOwner(req,res,next){
 const id=req.params.patient_id || req.body.patient_id || req.query.patient_id;
 if(!id)return res.status(400).json({error:"patient_id is required"});
 if(id!==req.patientId)return res.status(403).json({error:"You are not authorized to access this patient record."});
 next();
}

function clean(v){return typeof v==="string"?v.trim():"";}
function strongPassword(v){ return typeof v==="string" && v.length>=12 && v.length<=128 && /[a-z]/.test(v) && /[A-Z]/.test(v) && /\d/.test(v) && /[^A-Za-z0-9]/.test(v); }
function authPasswordError(){ return "Password must be 12–128 characters and include uppercase, lowercase, number and special character."; }

app.post("/api/register",async(req,res)=>{
 const b=req.body;
 const required=["firstName","lastName","phone","password"];
 if(required.some(k=>!clean(b[k])))return res.status(400).json({error:"Please complete all required fields."});
 if(!strongPassword(b.password))return res.status(400).json({error:authPasswordError()});
 if(db.prepare("SELECT 1 FROM patients WHERE phone=?").get(clean(b.phone)))return res.status(409).json({error:"This phone number is already registered."});
 if(clean(b.email)&&db.prepare("SELECT 1 FROM patients WHERE email=?").get(clean(b.email)))return res.status(409).json({error:"This email is already registered."});
 const pid=newPatientId(), hash=await bcrypt.hash(b.password,12);
 const tx=db.transaction(()=>{
  db.prepare(`INSERT INTO patients(patient_id,first_name,middle_name,last_name,dob,sex,marital_status,occupation,nationality,state_of_origin,lga,city,address,phone,whatsapp,email,password_hash)
  VALUES(@patient_id,@firstName,@middleName,@lastName,@dob,@sex,@maritalStatus,@occupation,@nationality,@stateOfOrigin,@lga,@city,@address,@phone,@whatsapp,@email,@password_hash)`).run({
   patient_id:pid,firstName:clean(b.firstName),middleName:clean(b.middleName),lastName:clean(b.lastName),dob:clean(b.dob),sex:clean(b.sex),maritalStatus:clean(b.maritalStatus),
   occupation:clean(b.occupation),nationality:clean(b.nationality),stateOfOrigin:clean(b.stateOfOrigin),lga:clean(b.lga),city:clean(b.city),address:clean(b.address),
   phone:clean(b.phone),whatsapp:clean(b.whatsapp),email:clean(b.email)||null,password_hash:hash});
  db.prepare(`INSERT INTO patient_history(patient_id,emergency_name,emergency_relationship,emergency_phone,emergency_alt_phone,emergency_address,presenting_complaint,hpc,allergies,medical_conditions,current_medications,surgeries,admissions,blood_group,genotype,height,weight,blood_pressure,pulse,respiratory_rate,temperature,spo2,immunization,family_history,smoking,alcohol,social_history,consultation_method,lmp,pregnancy_status,gravida,para,obstetric_history,gyn_history)
  VALUES(@patient_id,@emergencyName,@emergencyRelationship,@emergencyPhone,@emergencyAltPhone,@emergencyAddress,@presentingComplaint,@hpc,@allergies,@medicalConditions,@currentMedications,@surgeries,@admissions,@bloodGroup,@genotype,@height,@weight,@bloodPressure,@pulse,@respiratoryRate,@temperature,@spo2,@immunization,@familyHistory,@smoking,@alcohol,@socialHistory,@consultationMethod,@lmp,@pregnancyStatus,@gravida,@para,@obstetricHistory,@gynHistory)`).run({...b,patient_id:pid});
 });
 try{tx();res.json({patientId:pid});}catch(e){console.error(e);res.status(500).json({error:"Unable to create the account."})}
});

app.post("/api/login",authLimiter,async(req,res)=>{
 const id=clean(req.body.identifier), pw=clean(req.body.password);
 const p=db.prepare("SELECT * FROM patients WHERE patient_id=? OR email=? OR phone=?").get(id,id,id);
 if(!p||!(await bcrypt.compare(pw,p.password_hash)))return res.status(401).json({error:"Invalid login details."});
 const {token}=createSession("patient",p.patient_id);
 setSessionCookie(res,SESSION_COOKIE,token);
 audit(req,"patient",p.patient_id,"login");
 res.json({ok:true,patientId:p.patient_id});
});
app.post("/api/logout",auth,(req,res)=>{db.prepare("DELETE FROM sessions WHERE id=?").run(req.sessionId);audit(req,"patient",req.patientId,"logout");deleteCookie(res,SESSION_COOKIE);res.json({ok:true})});
app.get("/api/me",auth,(req,res)=>{
 const p=db.prepare("SELECT patient_id patientId,first_name firstName,middle_name middleName,last_name lastName,dob,sex,phone,email FROM patients WHERE patient_id=?").get(req.patientId);
 res.json({patient:p});
});
app.post("/api/appointments",(req,res)=>{
 const b=req.body;
 if(!clean(b.firstName)||!clean(b.lastName)||!clean(b.phone)||!clean(b.service)||!clean(b.preferredDate)||!clean(b.preferredTime))return res.status(400).json({error:"Please complete the appointment details."});
 const ref="APT-"+crypto.randomBytes(4).toString("hex").toUpperCase();
 db.prepare(`INSERT INTO appointments(reference,patient_id,first_name,last_name,phone,service,method,preferred_date,preferred_time,complaint)
 VALUES(?,?,?,?,?,?,?,?,?,?)`).run(ref,clean(b.patientId)||null,clean(b.firstName),clean(b.lastName),clean(b.phone),clean(b.service),clean(b.method),clean(b.preferredDate),clean(b.preferredTime),clean(b.complaint));
 res.json({reference:ref});
});

app.get('/api/doctor/me',doctorAuth,(req,res)=>res.json({id:req.doctorId}));
app.post("/api/doctor/login",authLimiter,async(req,res)=>{
 const email=clean(req.body.email), password=clean(req.body.password);
 const demoEmail=process.env.DOCTOR_EMAIL;
 const validDoctor = !!demoEmail && !!process.env.DOCTOR_PASSWORD_HASH && email===demoEmail.toLowerCase() && await bcrypt.compare(password,process.env.DOCTOR_PASSWORD_HASH);
 if(!validDoctor)return res.status(401).json({error:"Invalid doctor login details."});
 const {token}=createSession("doctor",email);
 setSessionCookie(res,DOCTOR_COOKIE,token);
 audit(req,"doctor",email,"login");
 res.json({ok:true});
});
function doctorAuth(req,res,next){const s=getSession(req,DOCTOR_COOKIE);if(!s||s.actor_type!=="doctor")return res.status(401).json({error:"Doctor login required."});req.doctorId=s.actor_id;req.sessionId=s.id;next();}
app.get("/api/doctor/patients",doctorAuth,(req,res)=>{
 const patients=db.prepare(`SELECT patient_id patientId,first_name firstName,middle_name middleName,last_name lastName,dob,sex,phone,email,created_at createdAt FROM patients ORDER BY created_at DESC`).all();
 res.json({patients});
});
app.get("/api/doctor/patient/:id",doctorAuth,(req,res)=>{
 const p=db.prepare(`SELECT patient_id patientId,first_name firstName,middle_name middleName,last_name lastName,dob,sex,marital_status maritalStatus,occupation,nationality,state_of_origin stateOfOrigin,lga,city,address,phone,whatsapp,email,created_at createdAt FROM patients WHERE patient_id=?`).get(req.params.id);
 if(!p)return res.status(404).json({error:"Patient not found."});
 const h=db.prepare("SELECT * FROM patient_history WHERE patient_id=?").get(req.params.id);
 const c=db.prepare("SELECT * FROM consultations WHERE patient_id=? ORDER BY created_at DESC").all(req.params.id);
 const rx=db.prepare("SELECT * FROM prescriptions WHERE patient_id=? ORDER BY created_at DESC").all(req.params.id);
 const labs=db.prepare("SELECT * FROM investigations WHERE patient_id=? ORDER BY created_at DESC").all(req.params.id);
 const refs=db.prepare("SELECT * FROM referrals WHERE patient_id=? ORDER BY created_at DESC").all(req.params.id);
 const ap=db.prepare("SELECT * FROM appointments WHERE patient_id=? ORDER BY created_at DESC").all(req.params.id);
 res.json({patient:p,history:h,consultations:c,prescriptions:rx,investigations:labs,referrals:refs,appointments:ap});
});
app.post("/api/doctor/consultation",doctorAuth,(req,res)=>{
 const b=req.body;if(!clean(b.patientId)||!clean(b.doctorName)||!clean(b.diagnosis))
   return res.status(400).json({error:"Patient, doctor and diagnosis are required."});
 const ref="CONS-"+crypto.randomBytes(4).toString("hex").toUpperCase();
 db.prepare(`INSERT INTO consultations(reference,patient_id,doctor_name,complaint,history,examination,diagnosis,treatment_plan,follow_up_date)
 VALUES(?,?,?,?,?,?,?,?,?)`).run(ref,clean(b.patientId),clean(b.doctorName),clean(b.complaint),clean(b.history),clean(b.examination),clean(b.diagnosis),clean(b.treatmentPlan),clean(b.followUpDate));
 res.json({reference:ref});
});
app.post("/api/doctor/prescription",doctorAuth,(req,res)=>{
 const b=req.body;if(!clean(b.patientId)||!clean(b.consultationReference)||!clean(b.medication))return res.status(400).json({error:"Patient, consultation and medication are required."});
 db.prepare("INSERT INTO prescriptions(consultation_reference,patient_id,medication,instructions) VALUES(?,?,?,?)").run(b.consultationReference,b.patientId,b.medication,b.instructions||"");
 res.json({ok:true});
});
app.post("/api/doctor/investigation",doctorAuth,(req,res)=>{
 const b=req.body;if(!clean(b.patientId)||!clean(b.consultationReference)||!clean(b.investigation))return res.status(400).json({error:"Patient, consultation and investigation are required."});
 db.prepare("INSERT INTO investigations(consultation_reference,patient_id,investigation,clinical_note) VALUES(?,?,?,?)").run(b.consultationReference,b.patientId,b.investigation,b.clinicalNote||"");
 res.json({ok:true});
});
app.post("/api/doctor/referral",doctorAuth,(req,res)=>{
 const b=req.body;if(!clean(b.patientId)||!clean(b.consultationReference)||!clean(b.destination))return res.status(400).json({error:"Patient, consultation and destination are required."});
 db.prepare("INSERT INTO referrals(consultation_reference,patient_id,destination,reason) VALUES(?,?,?,?)").run(b.consultationReference,b.patientId,b.destination,b.reason||"");
 res.json({ok:true});
});
app.post("/api/doctor/logout",doctorAuth,(req,res)=>{db.prepare("DELETE FROM sessions WHERE id=?").run(req.sessionId);audit(req,"doctor",req.doctorId,"logout");deleteCookie(res,DOCTOR_COOKIE);res.json({ok:true});});


// ---------------- PHASE 4: PAYMENTS ----------------
app.post('/api/payments/initialize', auth, patientOwner, (req,res)=>{
  const {appointment_ref, amount, method} = req.body || {};
  if(!appointment_ref || !amount || !method) return res.status(400).json({error:'appointment_ref, amount and method are required'});
  const payment_ref = 'FCPAY-' + Date.now().toString(36).toUpperCase();
  try {
    db.prepare(`INSERT INTO payments(payment_ref,appointment_ref,amount,method) VALUES(?,?,?,?)`)
      .run(payment_ref, appointment_ref, Number(amount), method);
    // Provider integration point. In production, initialize Paystack here using secret key.
    res.json({
      payment_ref,
      status:'pending',
      message:'Payment request created. Connect Paystack secret key in production to return an authorization URL.'
    });
  } catch(e) {
    res.status(500).json({error:'Could not create payment request'});
  }
});

app.get('/api/payments/:payment_ref', auth, (req,res)=>{
  const row = db.prepare(`SELECT payment_ref,appointment_ref,patient_id,amount,currency,method,status,provider_ref,created_at,paid_at
                          FROM payments WHERE payment_ref=?`).get(req.params.payment_ref);
  if(!row) return res.status(404).json({error:'Payment not found'});
  if(row.patient_id!==req.patientId) return res.status(403).json({error:'Forbidden'});
  res.json(row);
});

app.post('/api/payments/:payment_ref/mark-paid', (req,res)=>{
  if(IS_PRODUCTION || process.env.ALLOW_DEV_PAYMENT !== 'true') return res.status(404).json({error:'Development payment activation is disabled.'});
  // DEVELOPMENT ONLY. Production must verify payment directly with the payment provider.
  const row = db.prepare(`SELECT * FROM payments WHERE payment_ref=?`).get(req.params.payment_ref);
  if(!row) return res.status(404).json({error:'Payment not found'});
  db.prepare(`UPDATE payments SET status='paid', paid_at=CURRENT_TIMESTAMP WHERE payment_ref=?`).run(req.params.payment_ref);
  res.json({message:'Payment marked paid (development mode)', payment_ref:req.params.payment_ref, status:'paid'});
});


// ---------------- PHASE 5: WHATSAPP CONSULTATION ----------------
const WHATSAPP_NUMBER = process.env.FAMILYCLINIC_WHATSAPP || '2349075752501';

app.post('/api/whatsapp/session', auth, patientOwner, (req,res)=>{
  const {patient_id, appointment_ref, payment_ref, doctor, service, reason} = req.body || {};
  if(!appointment_ref || !payment_ref) {
    return res.status(400).json({error:'appointment_ref and payment_ref are required'});
  }

  const payment = db.prepare(`SELECT * FROM payments WHERE payment_ref=?`).get(payment_ref);
  if(!payment) return res.status(404).json({error:'Payment not found'});
  if(payment.status !== 'paid') return res.status(402).json({error:'Payment must be confirmed before starting WhatsApp consultation'});

  const consultation_ref = 'FCWC-' + Date.now().toString(36).toUpperCase();
  const message = `Hello FamilyClinic. I am requesting my paid consultation. Consultation Ref: ${consultation_ref}. Appointment: ${appointment_ref}. Doctor: ${doctor || 'Doctor on duty'}. Service: ${service || 'Medical consultation'}. Patient ID: ${patient_id || 'Not supplied'}. Reason: ${reason || 'Medical consultation'}.`;

  res.json({
    consultation_ref,
    whatsapp_number: WHATSAPP_NUMBER,
    whatsapp_url: `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,
    message:'WhatsApp consultation session created'
  });
});

app.get('/api/whatsapp/session/:ref', (req,res)=>{
  res.json({consultation_ref:req.params.ref, status:'ready'});
});


// ---------------- PHASE 6: ADMIN DASHBOARD ----------------
const ADMIN_EMAIL = process.env.FAMILYCLINIC_ADMIN_EMAIL || 'admin@familyclinic.com';

app.post('/api/admin/login',authLimiter,async(req,res)=>{
  const email=clean(req.body?.email).toLowerCase(), password=clean(req.body?.password);
  const ok=!!process.env.FAMILYCLINIC_ADMIN_PASSWORD_HASH && email===ADMIN_EMAIL.toLowerCase() && await bcrypt.compare(password,process.env.FAMILYCLINIC_ADMIN_PASSWORD_HASH);
  if(!ok)return res.status(401).json({error:'Invalid admin credentials'});
  const {token}=createSession('admin',email); setSessionCookie(res,ADMIN_COOKIE,token); audit(req,'admin',email,'login');
  res.json({message:'Admin login successful'});
});

app.post('/api/admin/logout',(req,res)=>{const s=getSession(req,ADMIN_COOKIE);if(s){db.prepare('DELETE FROM sessions WHERE id=?').run(s.id);audit(req,'admin',s.actor_id,'logout');}deleteCookie(res,ADMIN_COOKIE);res.json({message:'Logged out'});});

function requireAdmin(req,res,next){const s=getSession(req,ADMIN_COOKIE);if(!s||s.actor_type!=='admin')return res.status(401).json({error:'Admin authentication required'});req.adminId=s.actor_id;req.sessionId=s.id;next();}

app.get('/api/admin/overview', requireAdmin, (req,res)=>{
  const tables = ['patients','appointments','payments','consultations','prescriptions','investigations','referrals'];
  const counts = {};
  for(const t of tables){
    try { counts[t] = db.prepare(`SELECT COUNT(*) AS count FROM ${t}`).get().count; }
    catch(e){ counts[t]=0; }
  }
  res.json(counts);
});

app.get('/api/admin/patients', requireAdmin, (req,res)=>{
  const q=(req.query.q||'').trim();
  let rows;
  if(q){
    rows=db.prepare(`SELECT patient_id, first_name, surname, email, phone, created_at FROM patients
                     WHERE patient_id LIKE ? OR first_name LIKE ? OR surname LIKE ? OR email LIKE ? OR phone LIKE ?
                     ORDER BY id DESC`).all(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`);
  } else {
    rows=db.prepare(`SELECT patient_id, first_name, surname, email, phone, created_at FROM patients ORDER BY id DESC LIMIT 200`).all();
  }
  res.json(rows);
});

app.get('/api/admin/appointments', requireAdmin, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM appointments ORDER BY id DESC LIMIT 300`).all());
});

app.get('/api/admin/payments', requireAdmin, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM payments ORDER BY id DESC LIMIT 300`).all());
});

app.get('/api/admin/consultations', requireAdmin, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM consultations ORDER BY id DESC LIMIT 300`).all());
});

app.get('/api/admin/doctors', requireAdmin, (req,res)=>{
  // Development roster; replace with a doctors table during production hardening.
  res.json([
    {name:'Dr. Gabriel Nwidenyi',status:'active'},
    {name:'Dr. Ezema David',status:'active'},
    {name:'Dr. Sochima Edeh',status:'active'},
    {name:'Dr. Kindness Joseph',status:'active'},
    {name:'Dr. Ifeoma Chijioke',status:'active'}
  ]);
});

app.get('/api/admin/availability', requireAdmin, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM doctor_availability ORDER BY doctor, day, start_time`).all());
});

app.post('/api/admin/availability', requireAdmin, (req,res)=>{
  const {doctor,day,start_time,end_time,active=1}=req.body||{};
  if(!doctor||!day||!start_time||!end_time) return res.status(400).json({error:'doctor, day, start_time and end_time are required'});
  const result=db.prepare(`INSERT INTO doctor_availability(doctor,day,start_time,end_time,active) VALUES(?,?,?,?,?)`)
    .run(doctor,day,start_time,end_time,active?1:0);
  res.json({id:result.lastInsertRowid,message:'Availability saved'});
});

app.delete('/api/admin/availability/:id', requireAdmin, (req,res)=>{
  db.prepare(`DELETE FROM doctor_availability WHERE id=?`).run(req.params.id);
  res.json({message:'Availability removed'});
});


// ---------------- SUBSCRIPTION API ----------------
const SUBSCRIPTION_PLANS = {
  one_month:  {label:'1 Month Subscription', months:1, amount:10000},
  two_months: {label:'2 Months Subscription', months:2, amount:18000},
  three_months:{label:'3 Months Subscription', months:3, amount:25000},
  emergency:  {label:'Emergency Consultation', months:0, amount:15000}
};

app.get('/api/subscriptions/plans',(req,res)=>{
  res.json(SUBSCRIPTION_PLANS);
});

app.post('/api/subscriptions/create',auth,patientOwner,async(req,res)=>{
  const {patient_id, plan}=req.body||{};
  const selected=SUBSCRIPTION_PLANS[plan];
  if(!patient_id || !selected) return res.status(400).json({error:'patient_id and a valid plan are required'});
  const patient=db.prepare(`SELECT patient_id,first_name,last_name,email FROM patients WHERE patient_id=?`).get(patient_id);
  if(!patient || !patient.email) return res.status(400).json({error:'A valid email address is required for online payment.'});
  if(!process.env.PAYSTACK_SECRET_KEY) return res.status(503).json({error:'Online payment is not configured yet. Set PAYSTACK_SECRET_KEY on the server.'});

  const subscription_ref='FCSUB-'+Date.now().toString(36).toUpperCase();
  const payment_ref='FCPAY-'+Date.now().toString(36).toUpperCase();
  const callback_url=process.env.PAYSTACK_CALLBACK_URL || `${req.protocol}://${req.get('host')}/paystack-callback.html`;

  db.prepare(`INSERT INTO subscriptions(subscription_ref,patient_id,plan,amount,status,payment_ref) VALUES(?,?,?,?,?,?)`)
    .run(subscription_ref,patient_id,plan,selected.amount,'pending',payment_ref);
  db.prepare(`INSERT INTO payments(payment_ref,patient_id,amount,currency,method,status) VALUES(?,?,?,?,?,?)`)
    .run(payment_ref,patient_id,selected.amount,'NGN','paystack','pending');

  try{
    const response=await fetch('https://api.paystack.co/transaction/initialize',{
      method:'POST',
      headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,'Content-Type':'application/json'},
      body:JSON.stringify({
        email:patient.email, amount:String(selected.amount*100), currency:'NGN', reference:payment_ref, callback_url,
        metadata:{patient_id,subscription_ref,plan,payment_ref},
        channels:['card','bank','ussd','qr','bank_transfer']
      })
    });
    const data=await response.json();
    if(!response.ok || !data.status) throw new Error(data.message||'Paystack initialization failed');
    db.prepare(`UPDATE payments SET provider_ref=? WHERE payment_ref=?`).run(data.data.reference,payment_ref);
    res.json({subscription_ref,payment_ref,plan,amount:selected.amount,currency:'NGN',status:'pending',authorization_url:data.data.authorization_url,access_code:data.data.access_code});
  }catch(e){
    db.prepare(`UPDATE subscriptions SET status='failed' WHERE subscription_ref=?`).run(subscription_ref);
    db.prepare(`UPDATE payments SET status='failed' WHERE payment_ref=?`).run(payment_ref);
    res.status(502).json({error:'Unable to initialize Paystack payment.',detail:IS_PRODUCTION?undefined:e.message});
  }
});

function activateVerifiedSubscription(sub, paymentData){
  const plan=SUBSCRIPTION_PLANS[sub.plan];
  if(!plan) throw new Error('Unknown subscription plan');
  const existing=db.prepare(`SELECT status FROM subscriptions WHERE subscription_ref=?`).get(sub.subscription_ref);
  if(existing && existing.status==='active') return;
  const start=new Date();
  const expiry=new Date(start);
  if(plan.months>0) expiry.setMonth(expiry.getMonth()+plan.months); else expiry.setHours(expiry.getHours()+24);
  const tx=db.transaction(()=>{
    db.prepare(`UPDATE subscriptions SET status='active',starts_at=?,expires_at=? WHERE subscription_ref=?`).run(start.toISOString(),expiry.toISOString(),sub.subscription_ref);
    db.prepare(`UPDATE payments SET status='paid',provider_ref=?,paid_at=CURRENT_TIMESTAMP WHERE payment_ref=?`).run(String(paymentData.reference||sub.payment_ref),sub.payment_ref);
  });
  tx();
}

app.get('/api/payments/verify/:reference',auth,async(req,res)=>{
  if(!process.env.PAYSTACK_SECRET_KEY) return res.status(503).json({error:'Online payment is not configured.'});
  const payment=db.prepare(`SELECT * FROM payments WHERE payment_ref=?`).get(req.params.reference);
  if(!payment || payment.patient_id!==req.patientId) return res.status(404).json({error:'Payment not found'});
  try{
    const response=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(req.params.reference)}`,{headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`}});
    const result=await response.json();
    if(!response.ok || !result.status) return res.status(502).json({error:'Unable to verify payment.'});
    const d=result.data;
    if(d.status==='success' && Number(d.amount)===Number(payment.amount)*100 && d.currency===payment.currency){
      const sub=db.prepare(`SELECT * FROM subscriptions WHERE payment_ref=?`).get(payment.payment_ref);
      if(sub) activateVerifiedSubscription(sub,d);
    }
    res.json({reference:req.params.reference,status:d.status,amount:d.amount,currency:d.currency,subscription_active:!!db.prepare(`SELECT 1 FROM subscriptions WHERE payment_ref=? AND status='active'`).get(payment.payment_ref)});
  }catch(e){res.status(502).json({error:'Payment verification failed.'});}
});

app.post('/api/paystack/webhook',(req,res)=>{
  const signature=req.get('x-paystack-signature')||'';
  if(!process.env.PAYSTACK_SECRET_KEY || !req.rawBody) return res.status(401).send('Unauthorized');
  const expected=crypto.createHmac('sha512',process.env.PAYSTACK_SECRET_KEY).update(req.rawBody).digest('hex');
  if(signature.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) return res.status(401).send('Invalid signature');
  res.sendStatus(200);
  setImmediate(()=>{
    try{
      const event=req.body;
      if(event.event!=='charge.success') return;
      const d=event.data||{};
      const ref=d.reference;
      const payment=db.prepare(`SELECT * FROM payments WHERE payment_ref=? OR provider_ref=?`).get(ref,ref);
      if(!payment || payment.status==='paid') return;
      if(d.currency!==payment.currency || Number(d.amount)!==Number(payment.amount)*100) return;
      const sub=db.prepare(`SELECT * FROM subscriptions WHERE payment_ref=?`).get(payment.payment_ref);
      if(sub) activateVerifiedSubscription(sub,d);
    }catch(e){console.error('Paystack webhook processing error:',e.message);}
  });
});


app.post('/api/subscriptions/:ref/activate',(req,res)=>{
  if(IS_PRODUCTION || process.env.ALLOW_DEV_PAYMENT !== 'true') return res.status(404).json({error:'Development subscription activation is disabled.'});
  // DEVELOPMENT ONLY. Production must verify payment server-side before activation.
  const sub=db.prepare(`SELECT * FROM subscriptions WHERE subscription_ref=?`).get(req.params.ref);
  if(!sub) return res.status(404).json({error:'Subscription not found'});

  const plan=SUBSCRIPTION_PLANS[sub.plan];
  const start=new Date();
  let expiry=new Date(start);
  if(plan.months>0) expiry.setMonth(expiry.getMonth()+plan.months);
  else expiry.setHours(expiry.getHours()+24); // emergency access window

  db.prepare(`UPDATE subscriptions SET status='active', starts_at=?, expires_at=? WHERE subscription_ref=?`)
    .run(start.toISOString(),expiry.toISOString(),sub.subscription_ref);

  // Link the payment record where available.
  try {
    db.prepare(`UPDATE payments SET status='paid', patient_id=?, paid_at=CURRENT_TIMESTAMP WHERE payment_ref=?`)
      .run(sub.patient_id,sub.payment_ref);
  } catch(e) {}

  res.json({subscription_ref:sub.subscription_ref,status:'active',starts_at:start.toISOString(),expires_at:expiry.toISOString()});
});

app.get('/api/subscriptions/status/:patient_id',auth,patientOwner,(req,res)=>{
  const now=new Date().toISOString();
  const sub=db.prepare(`SELECT * FROM subscriptions
                        WHERE patient_id=? AND status='active' AND expires_at>?
                        ORDER BY expires_at DESC LIMIT 1`).get(req.params.patient_id,now);
  if(!sub) return res.json({active:false,access:'blocked',message:'No active subscription. Please subscribe to continue.'});
  res.json({active:true,access:'allowed',subscription_ref:sub.subscription_ref,plan:sub.plan,expires_at:sub.expires_at});
});

app.get('/api/subscriptions/history/:patient_id',auth,patientOwner,(req,res)=>{
  const rows=db.prepare(`SELECT subscription_ref,plan,amount,currency,status,starts_at,expires_at,payment_ref,created_at
                         FROM subscriptions WHERE patient_id=? ORDER BY id DESC`).all(req.params.patient_id);
  res.json(rows);
});

function requireActiveSubscription(req,res,next){
  const patientId=req.body.patient_id || req.query.patient_id || req.params.patient_id;
  if(!patientId) return res.status(400).json({error:'patient_id is required'});
  const session=getSession(req,SESSION_COOKIE);
  if(!session || session.actor_type!=='patient' || session.actor_id!==String(patientId)) return res.status(401).json({error:'Patient authentication required.'});
  const now=new Date().toISOString();
  const sub=db.prepare(`SELECT * FROM subscriptions WHERE patient_id=? AND status='active' AND expires_at>? ORDER BY expires_at DESC LIMIT 1`)
             .get(patientId,now);
  if(!sub) return res.status(403).json({error:'Subscription expired or unavailable. Please subscribe to continue.'});
  req.activeSubscription=sub;
  next();
}

// Example protected service endpoint for the future consultation flow.
app.get('/api/patient/access/:patient_id',requireActiveSubscription,(req,res)=>{
  res.json({access:true,subscription_ref:req.activeSubscription.subscription_ref,expires_at:req.activeSubscription.expires_at});
});


// ---------------- PHASE 7 API ----------------
app.post('/api/pharmacy/orders', requireActiveSubscription, (req,res)=>{
  const {patient_id, consultation_id, prescription_id, medication, quantity, instructions, fulfillment_method='pickup'}=req.body||{};
  if(!medication) return res.status(400).json({error:'Medication is required'});
  const ref='FCMED-'+Date.now().toString(36).toUpperCase();
  db.prepare(`INSERT INTO pharmacy_orders(order_ref,patient_id,consultation_id,prescription_id,medication,quantity,instructions,fulfillment_method)
              VALUES(?,?,?,?,?,?,?,?)`)
    .run(ref,patient_id,consultation_id||null,prescription_id||null,medication,quantity||'',instructions||'',fulfillment_method);
  res.json({order_ref:ref,status:'pending',message:'Pharmacy order submitted'});
});

app.get('/api/pharmacy/orders/:patient_id', requireActiveSubscription, patientOwner, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM pharmacy_orders WHERE patient_id=? ORDER BY id DESC`).all(req.params.patient_id));
});

app.post('/api/pharmacy/orders/:ref/status', requireAdmin, (req,res)=>{
  const allowed=['pending','processing','ready','out_for_delivery','completed','cancelled'];
  const {status}=req.body||{};
  if(!allowed.includes(status)) return res.status(400).json({error:'Invalid pharmacy status'});
  db.prepare(`UPDATE pharmacy_orders SET status=?,updated_at=CURRENT_TIMESTAMP WHERE order_ref=?`).run(status,req.params.ref);
  res.json({message:'Pharmacy order updated',status});
});

app.post('/api/lab/requests', requireActiveSubscription, (req,res)=>{
  const {patient_id, consultation_id, investigation, clinical_note}=req.body||{};
  if(!investigation) return res.status(400).json({error:'Investigation is required'});
  const ref='FCLAB-'+Date.now().toString(36).toUpperCase();
  db.prepare(`INSERT INTO lab_requests(request_ref,patient_id,consultation_id,investigation,clinical_note)
              VALUES(?,?,?,?,?)`).run(ref,patient_id,consultation_id||null,investigation,clinical_note||'');
  res.json({request_ref:ref,status:'requested',message:'Laboratory request submitted'});
});

app.get('/api/lab/requests/:patient_id', requireActiveSubscription, patientOwner, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM lab_requests WHERE patient_id=? ORDER BY id DESC`).all(req.params.patient_id));
});

app.post('/api/lab/requests/:ref/result', requireAdmin, (req,res)=>{
  const {result_text,result_file}=req.body||{};
  if(!result_text && !result_file) return res.status(400).json({error:'Result text or result file is required'});
  db.prepare(`UPDATE lab_requests SET result_text=?,result_file=?,status='completed',completed_at=CURRENT_TIMESTAMP WHERE request_ref=?`)
    .run(result_text||'',result_file||'',req.params.ref);
  res.json({message:'Laboratory result uploaded',status:'completed'});
});


app.get('/api/admin/pharmacy-orders',requireAdmin,(req,res)=>{
  res.json(db.prepare(`SELECT * FROM pharmacy_orders ORDER BY id DESC LIMIT 500`).all());
});
app.get('/api/admin/lab-requests',requireAdmin,(req,res)=>{
  res.json(db.prepare(`SELECT * FROM lab_requests ORDER BY id DESC LIMIT 500`).all());
});


// ---------------- PRESCRIPTION / INVESTIGATION API ----------------
app.post('/api/prescriptions/create', doctorAuth, (req,res)=>{
  const {patient_id,consultation_id,doctor_name,medicines,instructions}=req.body||{};
  if(!doctor_name || !medicines) return res.status(400).json({error:'doctor_name and medicines are required'});
  const ref='FCRX-'+Date.now().toString(36).toUpperCase();
  db.prepare(`INSERT INTO prescription_sheets(prescription_ref,patient_id,consultation_id,doctor_name,medicines,instructions)
              VALUES(?,?,?,?,?,?)`).run(ref,patient_id,consultation_id||null,doctor_name,medicines,instructions||'');
  res.json({prescription_ref:ref,message:'Prescription sheet created'});
});

app.get('/api/prescriptions/:patient_id', requireActiveSubscription, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM prescription_sheets WHERE patient_id=? ORDER BY id DESC`).all(req.params.patient_id));
});

app.get('/api/prescription/:ref', auth, (req,res)=>{
  const row=db.prepare(`SELECT * FROM prescription_sheets WHERE prescription_ref=?`).get(req.params.ref);
  if(!row) return res.status(404).json({error:'Prescription not found'});
  if(row.patient_id!==req.patientId) return res.status(403).json({error:'Forbidden'});
  res.json(row);
});

app.post('/api/investigations/create', doctorAuth, (req,res)=>{
  const {patient_id,consultation_id,doctor_name,investigations,clinical_note}=req.body||{};
  if(!doctor_name || !investigations) return res.status(400).json({error:'doctor_name and investigations are required'});
  const ref='FCINV-'+Date.now().toString(36).toUpperCase();
  db.prepare(`INSERT INTO investigation_sheets(investigation_ref,patient_id,consultation_id,doctor_name,investigations,clinical_note)
              VALUES(?,?,?,?,?,?)`).run(ref,patient_id,consultation_id||null,doctor_name,investigations,clinical_note||'');
  res.json({investigation_ref:ref,message:'Investigation sheet created'});
});

app.get('/api/investigations/:patient_id', requireActiveSubscription, (req,res)=>{
  res.json(db.prepare(`SELECT * FROM investigation_sheets WHERE patient_id=? ORDER BY id DESC`).all(req.params.patient_id));
});

app.get('/api/investigation/:ref', auth, (req,res)=>{
  const row=db.prepare(`SELECT * FROM investigation_sheets WHERE investigation_ref=?`).get(req.params.ref);
  if(!row) return res.status(404).json({error:'Investigation sheet not found'});
  if(row.patient_id!==req.patientId) return res.status(403).json({error:'Forbidden'});
  res.json(row);
});

app.get('/api/affiliates/pharmacies',(req,res)=>{
  res.json(db.prepare(`SELECT id,name,address,phone,city FROM affiliated_pharmacies WHERE active=1 ORDER BY name`).all());
});
app.get('/api/affiliates/laboratories',(req,res)=>{
  res.json(db.prepare(`SELECT id,name,address,phone,city,services FROM affiliated_laboratories WHERE active=1 ORDER BY name`).all());
});


app.post('/api/admin/pharmacies',requireAdmin,(req,res)=>{
  const {name,address,phone,city='Enugu'}=req.body||{};
  if(!name||!address)return res.status(400).json({error:'name and address are required'});
  const r=db.prepare(`INSERT INTO affiliated_pharmacies(name,address,phone,city) VALUES(?,?,?,?)`).run(name,address,phone||'',city);
  res.json({id:r.lastInsertRowid,message:'Pharmacy added'});
});
app.post('/api/admin/laboratories',requireAdmin,(req,res)=>{
  const {name,address,phone,city='Enugu',services=''}=req.body||{};
  if(!name||!address)return res.status(400).json({error:'name and address are required'});
  const r=db.prepare(`INSERT INTO affiliated_laboratories(name,address,phone,services,city) VALUES(?,?,?,?,?)`).run(name,address,phone||'',services,city);
  res.json({id:r.lastInsertRowid,message:'Laboratory added'});
});


// ---------------- PHASE 8: PASSWORD RESET / PRIVACY ----------------
app.post('/api/password-reset/request', authLimiter, (req,res)=>{
  const identifier=clean(req.body?.identifier);
  const p=db.prepare('SELECT patient_id FROM patients WHERE email=? OR phone=?').get(identifier,identifier);
  // Always return the same response to prevent account enumeration. In production, send the token via an approved channel.
  if(p){
    const raw=crypto.randomBytes(32).toString('base64url');
    const expires=new Date(Date.now()+15*60*1000).toISOString();
    db.prepare('INSERT INTO password_reset_tokens(patient_id,token_hash,expires_at) VALUES(?,?,?)').run(p.patient_id,hashToken(raw),expires);
    audit(req,'patient',p.patient_id,'password_reset_requested');
    if(process.env.NODE_ENV!=='production') res.json({message:'If the account exists, reset instructions have been generated.',development_token:raw});
    else return res.json({message:'If the account exists, reset instructions have been sent.'});
  }
  res.json({message:'If the account exists, reset instructions have been sent.'});
});
app.post('/api/password-reset/confirm', authLimiter, async(req,res)=>{
  const token=clean(req.body?.token), password=clean(req.body?.password);
  if(token.length<20||!strongPassword(password))return res.status(400).json({error:authPasswordError()});
  const row=db.prepare('SELECT * FROM password_reset_tokens WHERE token_hash=? AND used_at IS NULL AND expires_at>?').get(hashToken(token),new Date().toISOString());
  if(!row)return res.status(400).json({error:'Invalid or expired reset token.'});
  const hash=await bcrypt.hash(password,12);
  const tx=db.transaction(()=>{
    db.prepare('UPDATE patients SET password_hash=? WHERE patient_id=?').run(hash,row.patient_id);
    db.prepare('UPDATE password_reset_tokens SET used_at=CURRENT_TIMESTAMP WHERE id=?').run(row.id);
    db.prepare('DELETE FROM sessions WHERE actor_type="patient" AND actor_id=?').run(row.patient_id);
  });
  tx(); audit(req,'patient',row.patient_id,'password_reset_completed');
  res.json({message:'Password reset successful. Please log in again.'});
});

app.get('/privacy.html',(req,res)=>res.sendFile(path.join(__dirname,'privacy.html')));



// ---------------- FAMILYCLINIC COMPLETE PLATFORM EXTENSIONS ----------------
// Partner portal, referrals, notifications, PWA metadata and operational workflow.
db.exec(`
CREATE TABLE IF NOT EXISTS partner_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('pharmacy','laboratory')),
  facility_id INTEGER NOT NULL,
  facility_name TEXT NOT NULL,
  active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id TEXT,
  actor_type TEXT,
  actor_id TEXT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read_at TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS referrals_extended (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  referral_ref TEXT UNIQUE NOT NULL,
  patient_id TEXT NOT NULL,
  doctor_name TEXT NOT NULL,
  facility_or_specialist TEXT NOT NULL,
  reason TEXT NOT NULL,
  clinical_note TEXT,
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS operational_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  actor_type TEXT,
  actor_id TEXT,
  reference TEXT,
  details TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

function ensureColumn(table,column,definition){
  try{ const cols=db.prepare(`PRAGMA table_info(${table})`).all().map(x=>x.name); if(!cols.includes(column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`); }catch(e){ console.error('schema extension',table,column,e.message); }
}
ensureColumn('pharmacy_orders','facility_id','INTEGER');
ensureColumn('pharmacy_orders','partner_note','TEXT');
ensureColumn('lab_requests','facility_id','INTEGER');
ensureColumn('lab_requests','partner_note','TEXT');

function partnerSession(req){ return getSession(req,'familyclinic_partner_session'); }
function requirePartner(role){ return (req,res,next)=>{ const s=partnerSession(req); if(!s||s.actor_type!=='partner')return res.status(401).json({error:'Partner login required.'}); const p=db.prepare('SELECT * FROM partner_accounts WHERE id=? AND active=1').get(s.actor_id); if(!p||p.role!==role)return res.status(403).json({error:'Partner role not authorized.'}); req.partner=p; next(); }; }

// Demo accounts are for testing only; replace/disable before production.
const demoPartnerPassword=process.env.FAMILYCLINIC_PARTNER_DEMO_PASSWORD||'PartnerChangeMe123!';
function seedPartner(email,role,facilityId,facilityName){
  const exists=db.prepare('SELECT id FROM partner_accounts WHERE email=?').get(email); if(!exists){
    db.prepare('INSERT INTO partner_accounts(email,password_hash,role,facility_id,facility_name) VALUES(?,?,?,?,?)').run(email,bcrypt.hashSync(demoPartnerPassword,12),role,facilityId,facilityName);
  }
}
try{
  if(IS_PRODUCTION) throw new Error('skip demo partner seeding in production');
  const ph=db.prepare('SELECT id,name FROM affiliated_pharmacies ORDER BY id LIMIT 1').get();
  const lb=db.prepare('SELECT id,name FROM affiliated_laboratories ORDER BY id LIMIT 1').get();
  if(ph) seedPartner('pharmacy@familyclinic.com','pharmacy',ph.id,ph.name);
  if(lb) seedPartner('laboratory@familyclinic.com','laboratory',lb.id,lb.name);
}catch(e){console.error('partner seed',e.message)}

app.post('/api/partner/login',authLimiter,async(req,res)=>{
  const email=clean(req.body?.email).toLowerCase(), password=clean(req.body?.password);
  const p=db.prepare('SELECT * FROM partner_accounts WHERE email=? AND active=1').get(email);
  if(!p || !(await bcrypt.compare(password,p.password_hash))) return res.status(401).json({error:'Invalid partner credentials'});
  const token=createSession('partner',p.id).token;
  setSessionCookie(res,'familyclinic_partner_session',token);
  audit(req,'partner',p.id,'login');
  res.json({message:'Partner login successful',role:p.role,facility_name:p.facility_name});
});
app.post('/api/partner/logout',(req,res)=>{const s=partnerSession(req);if(s){db.prepare('DELETE FROM sessions WHERE id=?').run(s.id);audit(req,'partner',s.actor_id,'logout');}deleteCookie(res,'familyclinic_partner_session');res.json({message:'Logged out'});});
app.get('/api/partner/me',(req,res)=>{const s=partnerSession(req);if(!s)return res.status(401).json({error:'Not logged in'});const p=db.prepare('SELECT id,email,role,facility_id,facility_name FROM partner_accounts WHERE id=? AND active=1').get(s.actor_id);if(!p)return res.status(401).json({error:'Partner account unavailable'});res.json(p);});

app.get('/api/partner/pharmacy/orders',requirePartner('pharmacy'),(req,res)=>{
  res.json(db.prepare(`SELECT * FROM pharmacy_orders WHERE facility_id=? ORDER BY id DESC LIMIT 500`).all(req.partner.facility_id));
});
app.post('/api/partner/pharmacy/orders/:ref/status',requirePartner('pharmacy'),(req,res)=>{
  const allowed=['pending','processing','ready','out_for_delivery','completed','cancelled'];
  const status=clean(req.body?.status); if(!allowed.includes(status))return res.status(400).json({error:'Invalid status'});
  const row=db.prepare('SELECT * FROM pharmacy_orders WHERE order_ref=? AND facility_id=?').get(req.params.ref,req.partner.facility_id);
  if(!row)return res.status(404).json({error:'Order not found for this pharmacy'});
  db.prepare('UPDATE pharmacy_orders SET status=?,partner_note=?,updated_at=CURRENT_TIMESTAMP WHERE order_ref=?').run(status,clean(req.body?.partner_note),req.params.ref);
  db.prepare('INSERT INTO notifications(patient_id,actor_type,actor_id,title,message) VALUES(?,?,?,?,?)').run(row.patient_id,'partner',String(req.partner.id),'Pharmacy order update',`Order ${row.order_ref} is now ${status.replaceAll('_',' ')}.`);
  audit(req,'partner',req.partner.id,'pharmacy_order_status','pharmacy_order',row.order_ref,status);res.json({message:'Updated',status});
});

app.get('/api/partner/laboratory/requests',requirePartner('laboratory'),(req,res)=>{
  res.json(db.prepare(`SELECT * FROM lab_requests WHERE facility_id=? ORDER BY id DESC LIMIT 500`).all(req.partner.facility_id));
});
app.post('/api/partner/laboratory/requests/:ref/result',requirePartner('laboratory'),(req,res)=>{
  const result_text=clean(req.body?.result_text), result_file=clean(req.body?.result_file); if(!result_text&&!result_file)return res.status(400).json({error:'Result text or secure result reference is required'});
  const row=db.prepare('SELECT * FROM lab_requests WHERE request_ref=? AND facility_id=?').get(req.params.ref,req.partner.facility_id); if(!row)return res.status(404).json({error:'Request not found for this laboratory'});
  db.prepare(`UPDATE lab_requests SET result_text=?,result_file=?,status='completed',completed_at=CURRENT_TIMESTAMP,partner_note=? WHERE request_ref=?`).run(result_text,result_file,clean(req.body?.partner_note),req.params.ref);
  db.prepare('INSERT INTO notifications(patient_id,actor_type,actor_id,title,message) VALUES(?,?,?,?,?)').run(row.patient_id,'partner',String(req.partner.id),'Laboratory result available',`Result for ${row.request_ref} has been completed.`);
  audit(req,'partner',req.partner.id,'lab_result_uploaded','lab_request',row.request_ref);res.json({message:'Laboratory result recorded',status:'completed'});
});

// Partner selection is stored against the fulfilment request.
app.post('/api/pharmacy/orders/assign',requireActiveSubscription,(req,res)=>{
  const {patient_id,facility_id,prescription_id,medication,quantity,instructions,fulfillment_method='pickup'}=req.body||{};
  const facility=db.prepare('SELECT * FROM affiliated_pharmacies WHERE id=? AND active=1').get(facility_id);
  if(!facility)return res.status(400).json({error:'Choose an active affiliated pharmacy.'});
  if(!medication)return res.status(400).json({error:'Medication is required'});
  const ref='FCMED-'+Date.now().toString(36).toUpperCase();
  db.prepare(`INSERT INTO pharmacy_orders(order_ref,patient_id,prescription_id,medication,quantity,instructions,fulfillment_method,facility_id) VALUES(?,?,?,?,?,?,?,?)`).run(ref,patient_id,prescription_id||null,medication,quantity||'',instructions||'',fulfillment_method,facility_id);
  db.prepare('INSERT INTO notifications(patient_id,actor_type,actor_id,title,message) VALUES(?,?,?,?,?)').run(patient_id,'system','familyclinic','Pharmacy order submitted',`Your order ${ref} was sent to ${facility.name}.`);
  res.json({order_ref:ref,facility:facility.name,status:'pending'});
});
app.post('/api/lab/requests/assign',requireActiveSubscription,(req,res)=>{
  const {patient_id,facility_id,consultation_id,investigation,clinical_note}=req.body||{};
  const facility=db.prepare('SELECT * FROM affiliated_laboratories WHERE id=? AND active=1').get(facility_id);
  if(!facility)return res.status(400).json({error:'Choose an active affiliated laboratory.'});
  if(!investigation)return res.status(400).json({error:'Investigation is required'});
  const ref='FCLAB-'+Date.now().toString(36).toUpperCase();
  db.prepare(`INSERT INTO lab_requests(request_ref,patient_id,consultation_id,investigation,clinical_note,facility_id) VALUES(?,?,?,?,?,?)`).run(ref,patient_id,consultation_id||null,investigation,clinical_note||'',facility_id);
  db.prepare('INSERT INTO notifications(patient_id,actor_type,actor_id,title,message) VALUES(?,?,?,?,?)').run(patient_id,'system','familyclinic','Laboratory request submitted',`Your request ${ref} was sent to ${facility.name}.`);
  res.json({request_ref:ref,facility:facility.name,status:'requested'});
});

app.get('/api/notifications/:patient_id',auth,patientOwner,(req,res)=>{
  res.json(db.prepare('SELECT * FROM notifications WHERE patient_id=? ORDER BY id DESC LIMIT 100').all(req.params.patient_id));
});
app.post('/api/notifications/:id/read',auth,(req,res)=>{
  const n=db.prepare('SELECT * FROM notifications WHERE id=? AND patient_id=?').get(req.params.id,req.patientId);if(!n)return res.status(404).json({error:'Notification not found'});
  db.prepare('UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=?').run(req.params.id);res.json({message:'Marked as read'});
});

app.post('/api/referrals/create',doctorAuth,(req,res)=>{
  const {patient_id,doctor_name,facility_or_specialist,reason,clinical_note}=req.body||{};
  if(!doctor_name||!facility_or_specialist||!reason)return res.status(400).json({error:'Doctor, destination and reason are required'});
  const ref='FCREF-'+Date.now().toString(36).toUpperCase();
  db.prepare(`INSERT INTO referrals_extended(referral_ref,patient_id,doctor_name,facility_or_specialist,reason,clinical_note) VALUES(?,?,?,?,?,?)`).run(ref,patient_id,doctor_name,facility_or_specialist,reason,clinical_note||'');
  db.prepare('INSERT INTO notifications(patient_id,actor_type,actor_id,title,message) VALUES(?,?,?,?,?)').run(patient_id,'system','familyclinic','Referral created',`Referral ${ref} has been created.`);
  res.json({referral_ref:ref,status:'pending'});
});
app.get('/api/referrals/:patient_id',auth,patientOwner,(req,res)=>res.json(db.prepare('SELECT * FROM referrals_extended WHERE patient_id=? ORDER BY id DESC').all(req.params.patient_id)));
app.post('/api/admin/referrals/:ref/status',requireAdmin,(req,res)=>{const allowed=['pending','accepted','scheduled','completed','cancelled'];const status=clean(req.body?.status);if(!allowed.includes(status))return res.status(400).json({error:'Invalid referral status'});const r=db.prepare('SELECT * FROM referrals_extended WHERE referral_ref=?').get(req.params.ref);if(!r)return res.status(404).json({error:'Referral not found'});db.prepare('UPDATE referrals_extended SET status=?,updated_at=CURRENT_TIMESTAMP WHERE referral_ref=?').run(status,req.params.ref);db.prepare('INSERT INTO notifications(patient_id,actor_type,actor_id,title,message) VALUES(?,?,?,?,?)').run(r.patient_id,'admin',req.adminId,'Referral update',`Referral ${r.referral_ref} is now ${status}.`);res.json({status});});
app.get('/api/admin/referrals',requireAdmin,(req,res)=>res.json(db.prepare('SELECT * FROM referrals_extended ORDER BY id DESC LIMIT 500').all()));
app.get('/api/admin/partners',requireAdmin,(req,res)=>res.json(db.prepare('SELECT id,email,role,facility_id,facility_name,active,created_at FROM partner_accounts ORDER BY id DESC').all()));
app.post('/api/admin/partners/:id/status',requireAdmin,(req,res)=>{const active=req.body?.active?1:0;db.prepare('UPDATE partner_accounts SET active=? WHERE id=?').run(active,req.params.id);res.json({active:!!active});});
app.get('/api/admin/audit-log',requireAdmin,(req,res)=>res.json(db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 500').all()));



// ================= FAMILYCLINIC V1.0 CORE MODULES =================
// Wallet, longitudinal records, teleconsultation rooms and appointment availability.
// These routes are designed for production deployment but require managed DB/storage,
// real professional accounts and a configured TURN service for robust WebRTC.

function patientOrDoctorRoom(req,res,next){
  const s=getSession(req,SESSION_COOKIE); if(s){ req.actorType='patient'; req.actorId=s.actor_id; return next(); }
  const d=getSession(req,DOCTOR_COOKIE); if(d){ req.actorType='doctor'; req.actorId=d.actor_id; return next(); }
  return res.status(401).json({error:'Authentication required'});
}

// Wallet tables
try {
  db.exec(`CREATE TABLE IF NOT EXISTS wallets(
    patient_id TEXT PRIMARY KEY, balance INTEGER NOT NULL DEFAULT 0,
    currency TEXT NOT NULL DEFAULT 'NGN', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS wallet_transactions(
    id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id TEXT NOT NULL,
    type TEXT NOT NULL, amount INTEGER NOT NULL, reference TEXT UNIQUE NOT NULL,
    description TEXT, status TEXT NOT NULL DEFAULT 'completed', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS teleconsult_rooms(
    id INTEGER PRIMARY KEY AUTOINCREMENT, room_ref TEXT UNIQUE NOT NULL,
    patient_id TEXT NOT NULL, doctor_id TEXT, appointment_id INTEGER,
    status TEXT NOT NULL DEFAULT 'waiting', offer TEXT, answer TEXT,
    patient_candidates TEXT DEFAULT '[]', doctor_candidates TEXT DEFAULT '[]',
    started_at TEXT, ended_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS care_events(
    id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id TEXT NOT NULL,
    event_type TEXT NOT NULL, title TEXT NOT NULL, details TEXT, source_id TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );`);
} catch(e){ console.error('V1 table init:',e.message); }

app.get('/api/v1/wallet',auth,patientOwner,(req,res)=>{
  const p=req.patientId; db.prepare('INSERT OR IGNORE INTO wallets(patient_id) VALUES(?)').run(p);
  const wallet=db.prepare('SELECT * FROM wallets WHERE patient_id=?').get(p);
  const tx=db.prepare('SELECT * FROM wallet_transactions WHERE patient_id=? ORDER BY id DESC LIMIT 100').all(p);
  res.json({wallet,transactions:tx});
});

app.post('/api/v1/wallet/fund',auth,patientOwner,(req,res)=>{
  const amount=Math.round(Number(req.body?.amount));
  if(!Number.isFinite(amount)||amount<100) return res.status(400).json({error:'Minimum wallet funding is ₦100'});
  // Funding must be completed by verified Paystack in production; this endpoint only creates a payment intent.
  const ref='FCWAL-'+Date.now().toString(36).toUpperCase();
  res.json({payment_ref:ref,amount,currency:'NGN',message:'Use the configured Paystack flow to complete funding.'});
});

app.get('/api/v1/records/me',auth,(req,res)=>res.redirect(307,'/api/v1/records/'+encodeURIComponent(req.patientId)));

app.get('/api/v1/records/:patient_id',auth,patientOwner,(req,res)=>{
  const p=req.patientId;
  const consultations=db.prepare('SELECT * FROM consultations WHERE patient_id=? ORDER BY id DESC').all(p);
  const prescriptions=db.prepare('SELECT * FROM prescription_sheets WHERE patient_id=? ORDER BY id DESC').all(p);
  const investigations=db.prepare('SELECT * FROM investigation_sheets WHERE patient_id=? ORDER BY id DESC').all(p);
  const labs=db.prepare('SELECT * FROM lab_requests WHERE patient_id=? ORDER BY id DESC').all(p);
  const pharmacy=db.prepare('SELECT * FROM pharmacy_orders WHERE patient_id=? ORDER BY id DESC').all(p);
  const referrals=db.prepare('SELECT * FROM referrals_extended WHERE patient_id=? ORDER BY id DESC').all(p);
  const events=db.prepare('SELECT * FROM care_events WHERE patient_id=? ORDER BY id DESC LIMIT 200').all(p);
  res.json({consultations,prescriptions,investigations,labs,pharmacy,referrals,events});
});

app.post('/api/v1/care-events',doctorAuth,(req,res)=>{
  const patient_id=clean(req.body?.patient_id), event_type=clean(req.body?.event_type), title=clean(req.body?.title), details=clean(req.body?.details), source_id=clean(req.body?.source_id);
  if(!patient_id||!event_type||!title) return res.status(400).json({error:'patient_id, event_type and title are required'});
  const r=db.prepare('INSERT INTO care_events(patient_id,event_type,title,details,source_id) VALUES(?,?,?,?,?)').run(patient_id,event_type,title,details,source_id);
  audit(req,'doctor',req.doctorId,'care_event_created','care_event',String(r.lastInsertRowid));
  res.json({id:r.lastInsertRowid});
});

app.post('/api/v1/teleconsult/rooms',auth,(req,res)=>{
  const patient_id=req.patientId;
  const doctor_id=clean(req.body?.doctor_id), appointment_id=req.body?.appointment_id||null;
  const ref='FCROOM-'+Date.now().toString(36).toUpperCase();
  db.prepare('INSERT INTO teleconsult_rooms(room_ref,patient_id,doctor_id,appointment_id) VALUES(?,?,?,?)').run(ref,patient_id,doctor_id,appointment_id);
  res.json({room_ref:ref,status:'waiting'});
});
app.get('/api/v1/teleconsult/rooms/:ref',patientOrDoctorRoom,(req,res)=>{
  const r=db.prepare('SELECT * FROM teleconsult_rooms WHERE room_ref=?').get(req.params.ref);
  if(!r)return res.status(404).json({error:'Room not found'});
  if(req.actorType==='patient' && r.patient_id!==req.actorId)return res.status(403).json({error:'Forbidden'});
  if(req.actorType==='doctor' && r.doctor_id && String(r.doctor_id)!==String(req.actorId))return res.status(403).json({error:'Forbidden'});
  res.json(r);
});
app.post('/api/v1/teleconsult/rooms/:ref/signal',patientOrDoctorRoom,(req,res)=>{
  const r=db.prepare('SELECT * FROM teleconsult_rooms WHERE room_ref=?').get(req.params.ref);
  if(!r)return res.status(404).json({error:'Room not found'});
  if(req.actorType==='patient' && r.patient_id!==req.actorId)return res.status(403).json({error:'Forbidden'});
  if(req.actorType==='doctor' && r.doctor_id && String(r.doctor_id)!==String(req.actorId))return res.status(403).json({error:'Forbidden'});
  const type=clean(req.body?.type); const data=req.body?.data;
  if(type==='offer' && req.actorType==='patient') db.prepare('UPDATE teleconsult_rooms SET offer=?,status="active",started_at=COALESCE(started_at,CURRENT_TIMESTAMP) WHERE room_ref=?').run(JSON.stringify(data),req.params.ref);
  else if(type==='answer' && req.actorType==='doctor') db.prepare('UPDATE teleconsult_rooms SET answer=?,status="active",started_at=COALESCE(started_at,CURRENT_TIMESTAMP) WHERE room_ref=?').run(JSON.stringify(data),req.params.ref);
  else if(type==='patient-candidate' || type==='doctor-candidate'){
    const col=type==='patient-candidate'?'patient_candidates':'doctor_candidates';
    const arr=JSON.parse(r[col]||'[]'); arr.push(data); db.prepare(`UPDATE teleconsult_rooms SET ${col}=? WHERE room_ref=?`).run(JSON.stringify(arr),req.params.ref);
  } else return res.status(400).json({error:'Unsupported signal'});
  res.json({ok:true});
});
app.post('/api/v1/teleconsult/rooms/:ref/end',patientOrDoctorRoom,(req,res)=>{
  const r=db.prepare('SELECT * FROM teleconsult_rooms WHERE room_ref=?').get(req.params.ref);
  if(!r)return res.status(404).json({error:'Room not found'});
  if(req.actorType==='patient' && r.patient_id!==req.actorId)return res.status(403).json({error:'Forbidden'});
  if(req.actorType==='doctor' && r.doctor_id && String(r.doctor_id)!==String(req.actorId))return res.status(403).json({error:'Forbidden'});
  db.prepare('UPDATE teleconsult_rooms SET status="ended",ended_at=CURRENT_TIMESTAMP WHERE room_ref=?').run(req.params.ref);
  res.json({status:'ended'});
});


app.listen(PORT,()=>console.log(`FamilyClinic secure server running on http://localhost:${PORT}`));


const demoPharmacies = [
  ['FamilyClinic Partner Pharmacy 1','Enugu','', 'Enugu'],
  ['FamilyClinic Partner Pharmacy 2','Enugu','', 'Enugu']
];
const demoLabs = [
  ['FamilyClinic Partner Laboratory 1','Enugu','', 'General laboratory services','Enugu'],
  ['FamilyClinic Partner Diagnostic Centre 1','Enugu','', 'Ultrasound and diagnostic services','Enugu']
];
const pharmCount = db.prepare(`SELECT COUNT(*) AS n FROM affiliated_pharmacies`).get().n;
if (pharmCount===0) {
  const ins=db.prepare(`INSERT INTO affiliated_pharmacies(name,address,phone,city) VALUES(?,?,?,?)`);
  demoPharmacies.forEach(x=>ins.run(x[0],x[1],x[2],x[3]));
}
const labCount = db.prepare(`SELECT COUNT(*) AS n FROM affiliated_laboratories`).get().n;
if (labCount===0) {
  const ins=db.prepare(`INSERT INTO affiliated_laboratories(name,address,phone,services,city) VALUES(?,?,?,?,?)`);
  demoLabs.forEach(x=>ins.run(x[0],x[1],x[2],x[3],x[4]));
}
