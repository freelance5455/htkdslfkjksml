# FamilyClinic V1.0 — Hardened Security Release

This package is hardened against common web-application mistakes, but no software can honestly be guaranteed "unhackable". Security is a continuous process.

## Protections included
- HttpOnly, SameSite cookies; Secure `__Host-` cookies in production.
- Cryptographically random session tokens stored only as SHA-256 hashes.
- Session expiration and server-side logout.
- Strict production startup checks for required secrets and live Paystack configuration.
- No default doctor/admin production passwords.
- Strong password policy for new registrations and password resets.
- Authentication-specific rate limiting plus API rate limiting.
- Security headers, HSTS in production, permissions policy and disabled `X-Powered-By`.
- Cross-origin browser mutation checks.
- Direct HTTP access blocked for server code, `.env`, SQLite database and dependency directories.
- Patient ownership checks on patient records, payments, subscriptions, prescriptions, investigations, laboratory requests and pharmacy orders.
- Paystack webhook signature verification with timing-safe comparison.
- Server-side payment amount/currency verification.
- Development payment activation disabled in production.
- Audit logging for important authentication and clinical/operational actions.
- Production demo partner-account seeding disabled.

## Before real patient use
1. Deploy behind HTTPS only.
2. Use a managed production database and encrypted backups; the bundled SQLite database is a single-instance development/candidate store.
3. Configure unique verified accounts for every doctor, pharmacist, laboratory professional and administrator; do not share credentials.
4. Store medical files in private object storage, never in the public web directory.
5. Configure real password-reset delivery through an approved email/SMS provider.
6. Configure Paystack live keys and webhook URL in the deployment secret manager.
7. Add a TURN service for reliable WebRTC audio/video across mobile networks.
8. Complete Nigerian privacy/NDPR, consent, retention, breach-response and clinical-governance review with qualified counsel/compliance professionals.
9. Run dependency scanning, SAST/DAST, penetration testing and an external security review before launch.
10. Configure monitoring, alerting, backups and tested disaster recovery.
11. Use least-privilege cloud/database credentials and rotate secrets periodically.

## Never do this
- Never commit `.env` or secret keys to GitHub.
- Never put a Paystack secret key in browser JavaScript.
- Never use demo credentials with real patient data.
- Never expose `data/familyclinic.db` publicly.
- Never store unencrypted clinical files in a public bucket.
- Never assume authentication alone means a user is authorized to view every clinical record.
