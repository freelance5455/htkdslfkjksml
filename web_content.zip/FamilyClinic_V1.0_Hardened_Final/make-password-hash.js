// Usage: node make-password-hash.js 'YOUR_STRONG_PASSWORD'
// Never commit the password or resulting hash to GitHub.
const bcrypt = require('bcryptjs');
const password = process.argv[2];
if (!password) throw new Error('Pass a password as the first argument.');
if (password.length < 12 || password.length > 128 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
  throw new Error('Password must be 12–128 chars and include uppercase, lowercase, number and special character.');
}
console.log(bcrypt.hashSync(password, 12));
