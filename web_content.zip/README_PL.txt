UNAI TiM SAFE — PAKIET INTEGRACYJNY

Zawartość:
- www/index.html — aktualny plik TiM z testem SAFE.
- android/app/src/main/java/com/unai/tim/MainActivity.java
- android/app/src/main/java/com/unai/tim/TiMSafeStorageBridge.java
- android/app/src/main/java/com/unai/tim/TiMFileChooserChromeClient.java

Uzgodnienie HTML ↔ Android:
- Obiekt JavaScript: window.TiMSafeStorage
- Metody: selectSafeFolder() i saveSafeFile(fileName, base64Data)
- Nazwa pliku: UNAI_TIM_SAFE.timsafe
- Folder na karcie: UNAI_SAFE
- Dane przekazywane przez HTML są Base64; Java dekoduje je przed zapisem.
- Zapis sprawdza dane przez odczyt kontrolny i zastępuje poprzedni plik.

WAŻNE:
To nie jest kompletny projekt Capacitor/Gradle ani gotowa APK. To komplet plików
TiM SAFE do włączenia do istniejącego projektu Android. Sam zestaw tych plików
nie może zostać samodzielnie skompilowany jako APK, ponieważ brakuje konfiguracji
projektu, plików Gradle, manifestu, konfiguracji Capacitor i pozostałych zasobów.

W projekcie Android wymagana jest zależność:
implementation "androidx.documentfile:documentfile:1.0.1"

Nie kompilowano tutaj APK ani nie testowano zapisu na fizycznej karcie SDHC.
Obecny SAFE jest testem nośnika, nie przelewem prawdziwych jednostek TiM.
