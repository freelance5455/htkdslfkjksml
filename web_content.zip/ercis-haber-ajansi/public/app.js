const $=id=>document.getElementById(id);
async function api(url,options={}){const r=await fetch(url,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});const d=await r.json().catch(()=>({}));if(r.status===401)showLogin();if(!r.ok)throw new Error(d.error||`İstek başarısız (${r.status})`);return d;}
function showLogin(){$('login').style.display='block';$('app').style.display='none';}
function showApp(){$('login').style.display='none';$('app').style.display='block';}
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function refresh(){
 const s=await api('/api/status');$('count').textContent=s.publishedCount;$('lastRun').textContent=s.lastRun?new Date(s.lastRun).toLocaleString('tr-TR'):'Henüz yok';$('lastError').textContent=s.lastError?`Son hata: ${s.lastError}`:'';
 $('statePill').innerHTML=`<i class="dot ${s.autoPublish?'on':''}"></i>${s.autoPublish?'Otomatik yayın açık':'Otomatik yayın kapalı'}`;$('toggle').textContent=s.autoPublish?'Otomasyonu kapat':'Otomasyonu aç';
 const history=await api('/api/history');$('history').innerHTML=history.length?history.map(x=>`<div class="item"><b>${esc(x.title)}</b><small>${esc(x.category)} · ${new Date(x.publishedAt).toLocaleString('tr-TR')}</small><br><a href="${esc(x.link)}" target="_blank" rel="noopener">Kaynak haberi aç</a></div>`).join(''):'Henüz paylaşım yok.';
 const events=await api('/api/events');$('events').innerHTML=events.length?events.slice(0,15).map(x=>`<div class="item"><small>${new Date(x.at).toLocaleString('tr-TR')} · ${esc(x.level)}</small><div>${esc(x.message)}</div></div>`).join(''):'Henüz olay yok.';
}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('loginMsg').textContent='Giriş yapılıyor…';try{await api('/api/login',{method:'POST',body:JSON.stringify({password:$('password').value})});$('password').value='';showApp();await refresh();}catch(e){$('loginMsg').textContent=e.message;}});
$('toggle').addEventListener('click',async()=>{try{const s=await api('/api/status');await api('/api/automation',{method:'POST',body:JSON.stringify({enabled:!s.autoPublish})});await refresh();}catch(e){$('msg').textContent=e.message;}});
$('run').addEventListener('click',async()=>{$('run').disabled=true;$('msg').textContent='Haber kaynakları taranıyor…';try{const r=await api('/api/run-now',{method:'POST',body:'{}'});$('msg').textContent=r.published?`Yayımlandı: ${r.title}`:(r.title?`${r.reason} ${r.title}`:r.reason);await refresh();}catch(e){$('msg').textContent=e.message;}finally{$('run').disabled=false;}});
$('upload').addEventListener('click',async()=>{$('msg').textContent='Upload-Post bağlantısı kontrol ediliyor…';try{const r=await api('/api/uploadpost-check');$('msg').textContent=r.ok?'Upload-Post API bağlantısı başarılı.':'Upload-Post kontrolü başarısız.';}catch(e){$('msg').textContent=e.message;}});
$('refresh').addEventListener('click',()=>refresh().catch(e=>$('msg').textContent=e.message));
$('logout').addEventListener('click',async()=>{try{await api('/api/logout',{method:'POST',body:'{}'});}finally{showLogin();}});
(async()=>{try{await refresh();showApp();}catch{showLogin();}})();