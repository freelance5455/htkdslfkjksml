const $ = id => document.getElementById(id);
async function api(url, options = {}) {
  const response = await fetch(url, { ...options, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `İstek başarısız (${response.status})`);
  return data;
}
const esc = value => String(value || '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
async function refresh() {
  const status = await api('/api/status');
  $('count').textContent = status.publishedCount;
  $('lastRun').textContent = status.lastRun ? new Date(status.lastRun).toLocaleString('tr-TR') : 'Henüz yok';
  $('lastError').textContent = status.lastError ? `Son hata: ${status.lastError}` : '';
  $('statePill').innerHTML = `<i class="dot ${status.autoPublish ? 'on' : ''}"></i>${status.autoPublish ? 'Otomatik yayın açık' : 'Otomatik yayın kapalı'}`;
  $('toggle').textContent = status.autoPublish ? 'Otomasyonu kapat' : 'Otomasyonu aç';
  const history = await api('/api/history');
  $('history').innerHTML = history.length ? history.map(item => `<div class="item"><b>${esc(item.title)}</b><small>${esc(item.category)} · ${new Date(item.publishedAt).toLocaleString('tr-TR')}</small><br><a href="${esc(item.link)}" target="_blank" rel="noopener noreferrer">Kaynak haberi aç</a></div>`).join('') : 'Henüz paylaşım yok.';
  const events = await api('/api/events');
  $('events').innerHTML = events.length ? events.slice(0, 15).map(item => `<div class="item"><small>${new Date(item.at).toLocaleString('tr-TR')} · ${esc(item.level)}</small><div>${esc(item.message)}</div></div>`).join('') : 'Henüz olay yok.';
}
async function loadPreviews() {
  $('previews').textContent = 'Haberler aranıyor…';
  try {
    const items = await api('/api/news-preview');
    $('previews').innerHTML = items.length ? items.map(item => `<div class="item"><b>${esc(item.title)}</b><small>${esc(item.category)} · ${new Date(item.publishedAt).toLocaleString('tr-TR')}</small><br><a href="${esc(item.link)}" target="_blank" rel="noopener noreferrer">Kaynağı aç</a></div>`).join('') : 'Uygun haber bulunamadı.';
  } catch (error) { $('previews').textContent = error.message; }
}
$('toggle').addEventListener('click', async () => {
  try { const status = await api('/api/status'); await api('/api/automation', { method: 'POST', body: JSON.stringify({ enabled: !status.autoPublish }) }); await refresh(); }
  catch (error) { $('msg').textContent = error.message; }
});
$('run').addEventListener('click', async () => {
  $('run').disabled = true; $('msg').textContent = 'Haber kaynakları taranıyor…';
  try { const result = await api('/api/run-now', { method: 'POST', body: '{}' }); $('msg').textContent = result.published ? `Yayımlandı: ${result.title}` : (result.title ? `${result.reason} ${result.title}` : result.reason); await refresh(); }
  catch (error) { $('msg').textContent = error.message; }
  finally { $('run').disabled = false; }
});
$('upload').addEventListener('click', async () => {
  $('msg').textContent = 'Upload-Post bağlantısı kontrol ediliyor…';
  try { const result = await api('/api/uploadpost-check'); $('msg').textContent = result.ok ? 'Upload-Post API bağlantısı başarılı.' : 'Upload-Post kontrolü başarısız.'; }
  catch (error) { $('msg').textContent = error.message; }
});
$('preview').addEventListener('click', loadPreviews);
$('refresh').addEventListener('click', () => refresh().catch(error => $('msg').textContent = error.message));
(async () => { try { await refresh(); } catch (error) { $('msg').textContent = error.message; } })();
