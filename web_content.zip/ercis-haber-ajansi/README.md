# Erciş Haber Ajansı — sıfırdan yönetim paneli

Bu ZIP, Türkiye gündemi ve Van/Erciş gündemini RSS üzerinden tarayan, OpenAI GPT Image ile temsili haber görseli oluşturan ve Upload-Post fotoğraf API'si ile Instagram'a gönderen Node.js uygulamasını içerir.

## Dürüst durum notu
Bu dosya seti bu çalışma ortamında oluşturulmuştur; burada senin OpenAI/Upload-Post hesaplarına erişimimiz olmadığı için canlı yayın uçtan uca test edilmedi. Ship.place'ın bu Node.js sunucusunu, kalıcı dosya saklamayı ve sürekli zamanlayıcıyı desteklediği de doğrulanmadı. Bu nedenle "hatasız/çalışır durumda yayında" iddiasında bulunmuyorum. Önce aşağıdaki kurulum ve test adımları gerekir.

## İhtiyaçlar
- Node.js 20 veya üstü, sürekli çalışan sunucu
- HTTPS alan adı
- Kalıcı disk (data/state.json korunmalı)
- OpenAI API anahtarı ve GPT Image modeline erişim/faturalandırma
- Upload-Post API anahtarı ve Upload-Post profil kullanıcı adı
- Instagram profesyonel hesabı Upload-Post profilinde bağlı olmalı

## Yerel kurulum
1. ZIP'i çıkar.
2. `.env.example` dosyasını `.env` adıyla kopyala.
3. `npm install` çalıştır.
4. Yönetici şifresi için bcrypt hash üret:
   `node -e "const b=require('bcryptjs'); console.log(b.hashSync('BURAYA_GUCLU_SIFRE',12))"`
5. `.env` içine hash'i, en az 32 karakterlik rastgele `SESSION_SECRET` değerini, OpenAI ve Upload-Post anahtarlarını yaz.
6. İlk denemede `AUTO_PUBLISH=false` bırak.
7. `npm start` çalıştır; HTTPS sunucuda paneli aç ve giriş yap.
8. Upload-Post testini ve manuel haber taramasını dene. Anahtarlar doğruysa `AUTO_PUBLISH=true` yapıp sunucuyu yeniden başlat veya panelden otomasyonu aç.

## Zamanlama
Varsayılan cron `*/30 * * * *` ile her yarım saatte bir çalışır. Her döngüde en fazla bir yeni haber yayımlar; uygun haber bulunamazsa paylaşım yapmaz. Günlük üst sınır varsayılan 12'dir. Tek instance çalıştırılmalıdır; çoklu instance için paylaşımlı kilit/veritabanı gerekir.

## Güvenlik
- API anahtarları sadece sunucu ortam değişkenlerindedir.
- Yönetici parolası bcrypt ile doğrulanır.
- Oturum imzalı, HttpOnly, Secure, SameSite=Strict çerezidir; 8 saatte sona erer.
- Helmet güvenlik başlıkları ve hız sınırlaması uygulanır.
- `.env` dosyasını paylaşma veya Git'e yükleme.
- HTTPS olmadan üretimde çalıştırma; Secure çerez nedeniyle yerel HTTP'de giriş çerezi çalışmayabilir.
- `data/` kalıcı disk üzerinde olmalı.
- Bu örnek tek yönetici ve tek sunucu örneği içindir.

## Haber doğruluğu ve görsel
RSS başlık/özetleri kullanılır, tam haber metni kopyalanmaz. Anahtar kelime tabanlı kapsam filtresi her haberi coğrafi olarak kusursuz doğrulayamaz; otomatik yayın öncesi kaynakları güvenilir tutmak önemlidir. GPT Image promptu gerçek olay fotoğrafı üretmeye çalışmaz, temsili editoryal illüstrasyon üretir ve açıklamada bu belirtilir.

## Upload-Post ve OpenAI API
- Upload-Post fotoğraf yükleme: `POST https://api.upload-post.com/api/upload_photos`
- Yetkilendirme: `Authorization: Apikey ...`
- OpenAI Images API: `POST https://api.openai.com/v1/images/generations`
- Model varsayılanı: `gpt-image-2.6-flare`

Kaynaklar:
- https://docs.upload-post.com/api/upload-photo/
- https://docs.upload-post.com/api/overview
- https://docs.upload-post.com/api/reference/
- https://developers.openai.com/api/docs/guides/image-generation
- https://developers.openai.com/api/reference/resources/images/methods/generate

## Sınırlamalar
- Ship.place'a özel dağıtım dosyası/ayarları eklenmedi; hostun Node.js ve cron desteği doğrulanmalı.
- RSS ve kelime filtreleri kapsamlı editoryal doğrulama yerine geçmez.
- Upload-Post ücretsiz planı belgelerine göre aylık 10 yükleme sınırı içerebilir; 30 dakikalık yayın planı bu sınırı aşabilir. Hesap planını kontrol et.
- Görsel üretimi ücretli olabilir. Her yarım saatte bir görsel üretmek maliyet doğurur.
- İlk kez yayına almadan önce otomasyonu kapalı tutup bağlantıları test et.
