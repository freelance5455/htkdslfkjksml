# Erciş Haber Ajansı — düzeltilmiş sürüm

Bu proje bir Node.js web sunucusu ve mobil uyumlu yönetim panelidir. Tek başına statik HTML/APK paketi olarak arka planda 30 dakikada bir haber tarayamaz. Sunucu sürekli çalışan, Node.js 20 destekleyen ve `data/` klasörü için kalıcı disk sağlayan bir platformda barındırılmalıdır. APKForge yalnızca APK/WebView paketliyorsa `server.js`, cron ve gizli API anahtarlarını çalıştırmaz; APK içinden bu sunucuya HTTPS adresiyle bağlanılmalıdır.

## Yönetici girişi
İlk yönetici şifresi: `Mami0306`

`.env.example` dosyasını sunucuda `.env` olarak kopyalayın. Dosyada bu şifrenin scrypt hash'i ve oturum gizli anahtarı hazırdır. `.env` dosyasını kimseyle paylaşmayın ve herkese açık depoya koymayın. Üretimde ilk girişten sonra yönetici parolasını değiştirmek için ayrı bir parola değiştirme uç noktası eklenmesi önerilir.

## Kurulum
1. Node.js 20 veya üzeri kurulu sunucuda proje dosyalarını açın.
2. `.env.example` dosyasını `.env` olarak kopyalayın.
3. `.env` içine `OPENAI_API_KEY`, `UPLOAD_POST_API_KEY` ve `UPLOAD_POST_USER` değerlerini ekleyin.
4. `npm install` çalıştırın.
5. `npm start` ile başlatın.
6. HTTPS üzerinden yönetim panelini açın ve `Mami0306` ile giriş yapın.
7. Önce Upload-Post bağlantı kontrolünü ve haber önizlemesini deneyin. İlk testte otomasyon kapalı kalsın.
8. Her şey doğruysa panelden otomasyonu açın.

Docker ile çalıştırma: `docker build -t ercis-haber-ajansi .` ardından uygun `.env` ve kalıcı `data` volume'u ile container başlatın. `npm ci` yerine `npm install` kullanılır; çünkü pakete lock dosyası eklenmedi.

## Düzeltilenler
- Boş bcrypt hash zorunluluğu kaldırıldı; hazır yönetici parolası scrypt ile doğrulanır.
- Haber önizleme artık haberi `seen` listesine yazıp otomatik yayın hakkını tüketmez.
- Başarısız yayınlar `failed` olarak kaydedilir ve sonraki taramada yeniden denenebilir.
- Eski `processing` kaydı 30 dakikadan eskiyse tekrar denenebilir.
- Tarama ve yayın aynı anda iki kez çalıştırılmaz.
- Panelde haber önizleme düğmesi ve durum mesajları eklendi.
- Docker kurulumunda lock dosyası olmadığı için `npm ci` yerine `npm install` kullanıldı.
- Cookie ayarları HTTPS için güvenli varsayılanla bırakıldı. Yerel HTTP testinde `.env` içinde `COOKIE_SECURE=false` kullanın; internete açık üretimde tekrar `true` yapın.

## Önemli sınırlar
- Bu paket, kullanıcının gerçek OpenAI ve Upload-Post hesaplarıyla canlı test edilmedi. API anahtarları ve Upload-Post profil bağlantısı olmadan yayın yapılamaz.
- OpenAI görsel üretimi ücretlendirmeye tabi olabilir. Model adı `OPENAI_IMAGE_MODEL` ile değiştirilebilir.
- Upload-Post hesabının API ve Instagram bağlantı izinleri hesabın planına bağlıdır.
- Haberler Google News RSS sonuçlarından alınır; anahtar kelime filtresi editoryal doğrulamanın yerini tutmaz. Otomatik yayın açılmadan önce test edin.
- Üretimde kalıcı disk gereklidir; aksi halde `data/state.json` sıfırlanabilir ve yayın geçmişi kaybolabilir.
- Uygulamanın güvenli kalması için `.env` içeriğini, API anahtarlarını veya oturum gizli anahtarını APK içine koymayın.
