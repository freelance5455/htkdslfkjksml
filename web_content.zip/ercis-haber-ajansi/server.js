import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cron from 'node-cron';
import Parser from 'rss-parser';
import OpenAI from 'openai';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'state.json');
const PORT = Number(process.env.PORT || 3000);
const app = express();
const parser = new Parser({ timeout: 18000, headers: { 'User-Agent': 'ErcisHaberAjansi/1.0 (+news aggregator)' } });

const isProduction = process.env.NODE_ENV === 'production';
const requiredForPublishing = ['OPENAI_API_KEY','UPLOAD_POST_API_KEY','UPLOAD_POST_USER'];
const hasAdmin = Boolean(process.env.ADMIN_PASSWORD_HASH && process.env.SESSION_SECRET);
if (!hasAdmin) console.warn('UYARI: ADMIN_PASSWORD_HASH ve SESSION_SECRET ayarlanmalı.');

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc:["'self'"], scriptSrc:["'self'"], styleSrc:["'self'","'unsafe-inline'"],
    imgSrc:["'self'","data:"], connectSrc:["'self'"], objectSrc:["'none'"],
    baseUri:["'self'"], frameAncestors:["'none'"], formAction:["'self'"],
    upgradeInsecureRequests: isProduction ? [] : null
  }}
}));
app.use(express.json({limit:'80kb'}));
app.use(express.static(path.join(ROOT,'public'), {index:'index.html'}));

const loginLimiter = rateLimit({windowMs:15*60*1000,limit:8,standardHeaders:true,legacyHeaders:false});
const apiLimiter = rateLimit({windowMs:60*1000,limit:50,standardHeaders:true,legacyHeaders:false});

const safeEq=(a,b)=>{const x=Buffer.from(String(a));const y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y);};
const hmac=s=>crypto.createHmac('sha256',process.env.SESSION_SECRET||'unset').update(s).digest('hex');
function sessionToken(){
  const payload=Buffer.from(JSON.stringify({exp:Date.now()+8*60*60*1000})).toString('base64url');
  return `${payload}.${hmac(payload)}`;
}
function getSession(req){
  const cookie=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('eha_session='));
  if(!cookie)return null;
  const [payload,sig]=cookie.slice('eha_session='.length).split('.');
  if(!payload||!sig||!safeEq(hmac(payload),sig))return null;
  try{const d=JSON.parse(Buffer.from(payload,'base64url').toString());return d.exp>Date.now()?d:null;}catch{return null;}
}
function auth(req,res,next){if(!getSession(req))return res.status(401).json({error:'Oturum süresi doldu. Yeniden giriş yapın.'});next();}
function needEnv(keys){const miss=keys.filter(k=>!process.env[k]);if(miss.length)throw new Error(`Sunucu ayarı eksik: ${miss.join(', ')}`);}
async function loadState(){
  await fs.mkdir(DATA_DIR,{recursive:true});
  try{return JSON.parse(await fs.readFile(DB_FILE,'utf8'));}
  catch{return {seen:{},published:[],lastRun:null,lastError:null,autoPublish:process.env.AUTO_PUBLISH==='true',events:[]};}
}
let state=await loadState(), locked=false;
async function saveState(){
  await fs.mkdir(DATA_DIR,{recursive:true});
  const tmp=DB_FILE+'.tmp';
  await fs.writeFile(tmp,JSON.stringify(state,null,2),{mode:0o600});
  await fs.rename(tmp,DB_FILE);
}
function logEvent(level,message){
  state.events.unshift({at:new Date().toISOString(),level,message:String(message).slice(0,450)});
  state.events=state.events.slice(0,100);
}
const clean=s=>String(s||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,900);
const norm=s=>String(s||'').toLocaleLowerCase('tr-TR').normalize('NFD').replace(/\p{Diacritic}/gu,'');
const idFor=(url,title)=>crypto.createHash('sha256').update(url||title||'').digest('hex');
const rssUrl=q=>`https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=tr&gl=TR&ceid=TR:tr`;
const sources=[
  {category:'Van & Erciş',url:rssUrl('(Van OR Erciş OR Ercis) (haber OR gündem OR son dakika OR belediye OR trafik OR eğitim OR sağlık)')},
  {category:'Türkiye',url:rssUrl('(Türkiye OR Ankara OR İstanbul OR İzmir) (gündem OR son dakika OR ekonomi OR siyaset OR afet OR eğitim OR sağlık)')}
];
const localKeywords=['van','erciş','ercis'];
const nationalKeywords=['turkiye','ankara','istanbul','izmir','meclis','bakanlik','bakan','cumhurbaskani','ekonomi','deprem','afet','egitim','saglik','mahkeme','spor','secim'];
function inScope(item,category){
  const text=norm(`${item.title||''} ${item.contentSnippet||''}`);
  return category==='Van & Erciş'
    ? localKeywords.some(k=>text.includes(norm(k)))
    : nationalKeywords.some(k=>text.includes(norm(k)));
}
async function getCandidates(){
  const all=[];
  for(const feed of sources){
    const parsed=await parser.parseURL(feed.url);
    for(const item of parsed.items||[]){
      const date=item.isoDate?new Date(item.isoDate):new Date();
      if(!item.title||!item.link||Number.isNaN(date.getTime()))continue;
      if(Date.now()-date.getTime()>Number(process.env.NEWS_LOOKBACK_HOURS||36)*3600000)continue;
      if(!inScope(item,feed.category))continue;
      all.push({...item,category:feed.category,publishedAt:date.toISOString()});
    }
  }
  const unique=new Map();
  for(const item of all)unique.set(idFor(item.link,item.title),item);
  return [...unique.entries()].sort((a,b)=>new Date(b[1].publishedAt)-new Date(a[1].publishedAt)).map(([id,item])=>({...item,id}));
}
function captionFor(item){
  const tags=item.category==='Van & Erciş'?'#Van #Erciş #VanHaber #ErcişHaberAjansı':'#Türkiye #Gündem #SonDakika #ErcişHaberAjansı';
  const summary=clean(item.contentSnippet||'');
  return `${clean(item.title)}\n\n${summary?summary+'\n\n':''}Kaynak: ${item.link}\n\nGörsel: Yapay zekâ ile oluşturulmuş temsili görseldir.\n\n${tags}`.slice(0,2100);
}
async function generateImage(item){
  needEnv(['OPENAI_API_KEY']);
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const prompt=[
    'Create a professional editorial illustration for a Turkish local news publisher.',
    `News headline: ${clean(item.title)}.`,
    `Coverage area: ${item.category}.`,
    'Make a relevant conceptual illustration, not a documentary photograph and not a claim to depict the real event.',
    'No words, no letters, no logos, no watermark. Respectful, neutral newsroom style, square image, strong clear composition.'
  ].join(' ');
  const result=await client.images.generate({
    model:process.env.OPENAI_IMAGE_MODEL||'gpt-image-2.6-flare',
    prompt,size:'1024x1024',n:1,output_format:'jpeg',quality:'medium',
    safety_identifier:crypto.createHash('sha256').update('ercis-haber-ajansi').digest('hex')
  });
  const encoded=result.data?.[0]?.b64_json;
  if(!encoded)throw new Error('Görsel üretiminden resim verisi dönmedi.');
  return Buffer.from(encoded,'base64');
}
async function uploadPhoto(buffer,item){
  needEnv(['UPLOAD_POST_API_KEY','UPLOAD_POST_USER']);
  const form=new FormData();
  form.append('photos[]',new Blob([buffer],{type:'image/jpeg'}),`${item.id}.jpg`);
  form.append('user',process.env.UPLOAD_POST_USER);
  form.append('platform[]','instagram');
  form.append('title',captionFor(item));
  form.append('description',captionFor(item));
  form.append('is_ai_generated','true');
  const response=await fetch('https://api.upload-post.com/api/upload_photos',{
    method:'POST',
    headers:{Authorization:`Apikey ${process.env.UPLOAD_POST_API_KEY}`,'Idempotency-Key':`eha-${item.id}`},
    body:form,signal:AbortSignal.timeout(65000)
  });
  const data=await response.json().catch(()=>({}));
  if(!response.ok||data.success===false)throw new Error(`Upload-Post ${response.status}: ${JSON.stringify(data).slice(0,500)}`);
  const insta=data.results?.instagram;
  if(insta?.success===false)throw new Error(`Instagram: ${insta.error||'Yayınlama başarısız'}`);
  return data;
}
async function runCycle(){
  if(locked)return {published:0,reason:'Önceki tarama hâlâ sürüyor.'};
  locked=true;
  state.lastRun=new Date().toISOString();
  state.lastError=null;
  try{
    const candidates=await getCandidates();
    const today=new Date().toLocaleDateString('en-CA',{timeZone:'Europe/Istanbul'});
    const todayCount=state.published.filter(x=>x.localDate===today).length;
    if(todayCount>=Number(process.env.MAX_POSTS_PER_DAY||12)){
      logEvent('info','Günlük yayın sınırına ulaşıldı.');return {published:0,reason:'Günlük yayın sınırına ulaşıldı.'};
    }
    for(const item of candidates){
      if(state.seen[item.id])continue;
      // Reserve ID before external calls to avoid duplicates after timeout/restart.
      state.seen[item.id]={title:clean(item.title),link:item.link,category:item.category,status:'processing',at:new Date().toISOString()};
      await saveState();
      if(!state.autoPublish){state.seen[item.id].status='previewed';await saveState();return {published:0,reason:'Otomatik yayın kapalı; yeni haber bulundu.',title:clean(item.title)};}
      const image=await generateImage(item);
      const result=await uploadPhoto(image,item);
      state.seen[item.id].status='published';
      state.published.unshift({id:item.id,title:clean(item.title),category:item.category,link:item.link,publishedAt:new Date().toISOString(),localDate:today,uploadPostResult:result});
      state.published=state.published.slice(0,400);
      logEvent('success',`Yayımlandı: ${clean(item.title)}`);
      await saveState();
      return {published:1,title:clean(item.title),category:item.category};
    }
    logEvent('info','Yeni ve kapsam dahilinde haber bulunamadı.');
    return {published:0,reason:'Yeni ve kapsam dahilinde haber bulunamadı.'};
  }catch(err){
    state.lastError=String(err?.message||err).slice(0,600);
    logEvent('error',state.lastError);
    throw err;
  }finally{await saveState();locked=false;}
}

app.post('/api/login',loginLimiter,async(req,res)=>{
  const password=String(req.body?.password||'');
  const hash=process.env.ADMIN_PASSWORD_HASH||'';
  if(!hash||!process.env.SESSION_SECRET||!(await bcrypt.compare(password,hash).catch(()=>false)))return res.status(401).json({error:'Şifre hatalı veya sunucu giriş ayarı eksik.'});
  res.setHeader('Set-Cookie',`eha_session=${sessionToken()}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`);
  res.json({ok:true});
});
app.post('/api/logout',auth,(req,res)=>{res.setHeader('Set-Cookie','eha_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0');res.json({ok:true});});
app.get('/api/health',(req,res)=>res.json({ok:true,time:new Date().toISOString()}));
app.use('/api',apiLimiter);
app.get('/api/status',auth,(req,res)=>res.json({
  autoPublish:state.autoPublish,lastRun:state.lastRun,lastError:state.lastError,
  publishedCount:state.published.length,recent:state.published.slice(0,10),
  configured:{openai:!!process.env.OPENAI_API_KEY,uploadPost:!!(process.env.UPLOAD_POST_API_KEY&&process.env.UPLOAD_POST_USER)}
}));
app.post('/api/automation',auth,async(req,res)=>{
  state.autoPublish=Boolean(req.body?.enabled);await saveState();res.json({ok:true,autoPublish:state.autoPublish});
});
app.post('/api/run-now',auth,async(req,res)=>{
  try{res.json(await runCycle());}catch(e){res.status(502).json({error:e.message});}
});
app.get('/api/uploadpost-check',auth,async(req,res)=>{
  try{
    needEnv(['UPLOAD_POST_API_KEY']);
    const r=await fetch('https://api.upload-post.com/api/uploadposts/me',{headers:{Authorization:`Apikey ${process.env.UPLOAD_POST_API_KEY}`},signal:AbortSignal.timeout(15000)});
    const d=await r.json().catch(()=>({}));
    res.status(r.ok?200:502).json({ok:r.ok,status:r.status,data:d});
  }catch(e){res.status(502).json({ok:false,error:e.message});}
});
app.get('/api/news-preview',auth,async(req,res)=>{
  try{const items=await getCandidates();res.json(items.slice(0,20).map(x=>({title:clean(x.title),category:x.category,link:x.link,publishedAt:x.publishedAt})));}catch(e){res.status(502).json({error:e.message});}
});
app.get('/api/events',auth,(req,res)=>res.json(state.events.slice(0,40)));
app.get('/api/history',auth,(req,res)=>res.json(state.published.slice(0,100)));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Sunucu hatası. Ayrıntı güvenlik için kaydedildi.'});});

if(process.env.CRON_SCHEDULE&&cron.validate(process.env.CRON_SCHEDULE)){
  cron.schedule(process.env.CRON_SCHEDULE,async()=>{
    try{const result=await runCycle();console.log('EHA otomasyon:',result);}
    catch(e){console.error('EHA otomasyon hatası:',e.message);}
  },{timezone:process.env.TZ||'Europe/Istanbul'});
  console.log('Zamanlayıcı kuruldu:',process.env.CRON_SCHEDULE);
}else console.warn('Zamanlayıcı kurulamadı: CRON_SCHEDULE değerini kontrol edin.');

app.listen(PORT,()=>console.log(`Erciş Haber Ajansı ${PORT} portunda çalışıyor.`));
