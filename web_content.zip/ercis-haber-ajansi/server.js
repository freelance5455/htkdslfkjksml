import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cron from 'node-cron';
import Parser from 'rss-parser';
import OpenAI from 'openai';
import crypto from 'node:crypto';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'state.json');
const PORT = Number(process.env.PORT || 3000);
const app = express();
const scrypt = promisify(crypto.scrypt);
const parser = new Parser({ timeout: 18000, headers: { 'User-Agent': 'ErcisHaberAjansi/1.1' } });
const isProduction = process.env.NODE_ENV === 'production';

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
  imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"],
  baseUri: ["'self'"], frameAncestors: ["'none'"], formAction: ["'self'"]
} }}));
app.use(express.json({ limit: '80kb' }));
app.use(express.static(path.join(ROOT, 'public'), { index: 'index.html' }));

const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false });

// PASSWORDLESS MODE: all panel/API routes are public. Anyone who knows the URL can control publishing.
function auth(req, res, next) { next(); }
function needEnv(keys) {
  const missing = keys.filter(key => !process.env[key]);
  if (missing.length) throw new Error(`Sunucu ayarı eksik: ${missing.join(', ')}`);
}
async function loadState() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    const parsed = JSON.parse(await fs.readFile(DB_FILE, 'utf8'));
    return { seen: {}, published: [], lastRun: null, lastError: null, autoPublish: process.env.AUTO_PUBLISH === 'true', events: [], ...parsed };
  } catch {
    return { seen: {}, published: [], lastRun: null, lastError: null, autoPublish: process.env.AUTO_PUBLISH === 'true', events: [] };
  }
}
let state = await loadState();
let locked = false;
async function saveState() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const temp = `${DB_FILE}.tmp`;
  await fs.writeFile(temp, JSON.stringify(state, null, 2), { mode: 0o600 });
  await fs.rename(temp, DB_FILE);
}
function logEvent(level, message) {
  state.events.unshift({ at: new Date().toISOString(), level, message: String(message).slice(0, 450) });
  state.events = state.events.slice(0, 100);
}
const clean = value => String(value || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 900);
const norm = value => String(value || '').toLocaleLowerCase('tr-TR').normalize('NFD').replace(/\p{Diacritic}/gu, '');
const idFor = (url, title) => crypto.createHash('sha256').update(url || title || '').digest('hex');
const rssUrl = query => `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=tr&gl=TR&ceid=TR:tr`;
const sources = [
  { category: 'Van & Erciş', url: rssUrl('(Van OR Erciş OR Ercis) (haber OR gündem OR son dakika OR belediye OR trafik OR eğitim OR sağlık)') },
  { category: 'Türkiye', url: rssUrl('(Türkiye OR Ankara OR İstanbul OR İzmir) (gündem OR son dakika OR ekonomi OR siyaset OR afet OR eğitim OR sağlık)') }
];
const localKeywords = ['van', 'erciş', 'ercis'];
const nationalKeywords = ['turkiye', 'ankara', 'istanbul', 'izmir', 'meclis', 'bakanlik', 'bakan', 'cumhurbaskani', 'ekonomi', 'deprem', 'afet', 'egitim', 'saglik', 'mahkeme', 'spor', 'secim'];
function inScope(item, category) {
  const text = norm(`${item.title || ''} ${item.contentSnippet || ''}`);
  return category === 'Van & Erciş' ? localKeywords.some(k => text.includes(norm(k))) : nationalKeywords.some(k => text.includes(norm(k)));
}
async function getCandidates() {
  const all = [];
  for (const feed of sources) {
    const parsed = await parser.parseURL(feed.url);
    for (const item of parsed.items || []) {
      const date = item.isoDate ? new Date(item.isoDate) : item.pubDate ? new Date(item.pubDate) : null;
      if (!item.title || !item.link || !date || Number.isNaN(date.getTime())) continue;
      if (Date.now() - date.getTime() > Number(process.env.NEWS_LOOKBACK_HOURS || 36) * 3600000) continue;
      if (!inScope(item, feed.category)) continue;
      all.push({ ...item, category: feed.category, publishedAt: date.toISOString() });
    }
  }
  const unique = new Map();
  for (const item of all) unique.set(idFor(item.link, item.title), item);
  return [...unique.entries()].sort((a, b) => new Date(b[1].publishedAt) - new Date(a[1].publishedAt)).map(([id, item]) => ({ ...item, id }));
}
function captionFor(item) {
  const tags = item.category === 'Van & Erciş' ? '#Van #Erciş #VanHaber #ErcişHaberAjansı' : '#Türkiye #Gündem #SonDakika #ErcişHaberAjansı';
  const summary = clean(item.contentSnippet || '');
  return `${clean(item.title)}\n\n${summary ? summary + '\n\n' : ''}Kaynak: ${item.link}\n\nGörsel: Yapay zekâ ile oluşturulmuş temsili görseldir.\n\n${tags}`.slice(0, 2100);
}
async function generateImage(item) {
  needEnv(['OPENAI_API_KEY']);
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const prompt = [
    'Create a professional editorial illustration for a Turkish local news publisher.',
    `News headline: ${clean(item.title)}.`, `Coverage area: ${item.category}.`,
    'Conceptual illustration only, not a documentary photograph and not a claim to depict the real event.',
    'No words, letters, logos or watermark. Respectful neutral newsroom style, square composition.'
  ].join(' ');
  const result = await client.images.generate({ model: process.env.OPENAI_IMAGE_MODEL || 'gpt-image-1', prompt, size: '1024x1024', n: 1 });
  const encoded = result.data?.[0]?.b64_json;
  if (!encoded) throw new Error('Görsel üretiminden resim verisi dönmedi.');
  return Buffer.from(encoded, 'base64');
}
async function uploadPhoto(buffer, item) {
  needEnv(['UPLOAD_POST_API_KEY', 'UPLOAD_POST_USER']);
  const form = new FormData();
  form.append('photos[]', new Blob([buffer], { type: 'image/png' }), `${item.id}.png`);
  form.append('user', process.env.UPLOAD_POST_USER);
  form.append('platform[]', 'instagram');
  form.append('title', captionFor(item));
  form.append('description', captionFor(item));
  form.append('is_ai_generated', 'true');
  const response = await fetch('https://api.upload-post.com/api/upload_photos', {
    method: 'POST', headers: { Authorization: `Apikey ${process.env.UPLOAD_POST_API_KEY}`, 'Idempotency-Key': `eha-${item.id}` },
    body: form, signal: AbortSignal.timeout(65000)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.success === false) throw new Error(`Upload-Post ${response.status}: ${JSON.stringify(data).slice(0, 500)}`);
  if (data.results?.instagram?.success === false) throw new Error(`Instagram: ${data.results.instagram.error || 'Yayınlama başarısız'}`);
  return data;
}
async function runCycle() {
  if (locked) return { published: 0, reason: 'Önceki tarama hâlâ sürüyor.' };
  locked = true;
  state.lastRun = new Date().toISOString();
  state.lastError = null;
  try {
    const candidates = await getCandidates();
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });
    const dailyCount = state.published.filter(x => x.localDate === today).length;
    if (dailyCount >= Number(process.env.MAX_POSTS_PER_DAY || 12)) return { published: 0, reason: 'Günlük yayın sınırına ulaşıldı.' };
    const candidate = candidates.find(item => {
      const record = state.seen[item.id];
      if (!record) return true;
      if (record.status === 'published') return false;
      if (record.status === 'processing' && Date.now() - new Date(record.at).getTime() < 30 * 60 * 1000) return false;
      return record.status === 'failed' || record.status === 'previewed' || record.status === 'processing';
    });
    if (!candidate) {
      logEvent('info', 'Yeni ve kapsam dahilinde haber bulunamadı.');
      return { published: 0, reason: 'Yeni ve kapsam dahilinde haber bulunamadı.' };
    }
    // Önizleme hiçbir haberi seen listesine kilitlemez; otomasyon açılınca haber kaybolmaz.
    if (!state.autoPublish) return { published: 0, reason: 'Otomatik yayın kapalı; haber önizlemesi hazır.', title: clean(candidate.title), category: candidate.category, link: candidate.link };
    state.seen[candidate.id] = { title: clean(candidate.title), link: candidate.link, category: candidate.category, status: 'processing', at: new Date().toISOString() };
    await saveState();
    try {
      const image = await generateImage(candidate);
      const result = await uploadPhoto(image, candidate);
      state.seen[candidate.id].status = 'published';
      state.published.unshift({ id: candidate.id, title: clean(candidate.title), category: candidate.category, link: candidate.link, publishedAt: new Date().toISOString(), localDate: today, uploadPostResult: result });
      state.published = state.published.slice(0, 400);
      logEvent('success', `Yayımlandı: ${clean(candidate.title)}`);
      await saveState();
      return { published: 1, title: clean(candidate.title), category: candidate.category };
    } catch (error) {
      state.seen[candidate.id].status = 'failed';
      state.seen[candidate.id].error = String(error?.message || error).slice(0, 500);
      state.seen[candidate.id].at = new Date().toISOString();
      throw error;
    }
  } catch (error) {
    state.lastError = String(error?.message || error).slice(0, 600);
    logEvent('error', state.lastError);
    throw error;
  } finally {
    await saveState();
    locked = false;
  }
}

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));
app.use('/api', apiLimiter);
app.get('/api/status', auth, (req, res) => res.json({
  autoPublish: state.autoPublish, lastRun: state.lastRun, lastError: state.lastError,
  publishedCount: state.published.length, recent: state.published.slice(0, 10),
  configured: { openai: !!process.env.OPENAI_API_KEY, uploadPost: !!(process.env.UPLOAD_POST_API_KEY && process.env.UPLOAD_POST_USER) }
}));
app.post('/api/automation', auth, async (req, res) => { state.autoPublish = Boolean(req.body?.enabled); await saveState(); res.json({ ok: true, autoPublish: state.autoPublish }); });
app.post('/api/run-now', auth, async (req, res) => { try { res.json(await runCycle()); } catch (error) { res.status(502).json({ error: error.message }); } });
app.get('/api/uploadpost-check', auth, async (req, res) => {
  try {
    needEnv(['UPLOAD_POST_API_KEY']);
    const response = await fetch('https://api.upload-post.com/api/uploadposts/me', { headers: { Authorization: `Apikey ${process.env.UPLOAD_POST_API_KEY}` }, signal: AbortSignal.timeout(15000) });
    const data = await response.json().catch(() => ({}));
    res.status(response.ok ? 200 : 502).json({ ok: response.ok, status: response.status, data });
  } catch (error) { res.status(502).json({ ok: false, error: error.message }); }
});
app.get('/api/news-preview', auth, async (req, res) => {
  try {
    const items = await getCandidates();
    res.json(items.filter(item => state.seen[item.id]?.status !== 'published').slice(0, 20).map(item => ({ title: clean(item.title), category: item.category, link: item.link, publishedAt: item.publishedAt })));
  } catch (error) { res.status(502).json({ error: error.message }); }
});
app.get('/api/events', auth, (req, res) => res.json(state.events.slice(0, 40)));
app.get('/api/history', auth, (req, res) => res.json(state.published.slice(0, 100)));
app.use((error, req, res, next) => { console.error(error); res.status(500).json({ error: 'Sunucu hatası. Ayrıntı güvenlik için kaydedildi.' }); });

if (process.env.CRON_SCHEDULE && cron.validate(process.env.CRON_SCHEDULE)) {
  cron.schedule(process.env.CRON_SCHEDULE, async () => {
    try { const result = await runCycle(); console.log('EHA otomasyon:', result); }
    catch (error) { console.error('EHA otomasyon hatası:', error.message); }
  }, { timezone: process.env.TZ || 'Europe/Istanbul' });
  console.log('Zamanlayıcı kuruldu:', process.env.CRON_SCHEDULE);
} else console.warn('Zamanlayıcı kurulamadı: CRON_SCHEDULE değerini kontrol edin.');

app.listen(PORT, () => console.log(`Erciş Haber Ajansı ${PORT} portunda çalışıyor.`));
