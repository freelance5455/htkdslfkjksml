<?php
declare(strict_types=1);
require_once __DIR__.'/app/platform.php';
require_once __DIR__.'/app/auth.php';
$user=auth_require_user();
$pageTitle='History';
$rows=[];
try {
    $s=db()->prepare('SELECT id,workspace,model,prompt,status,error_message,output_disk,output_mime,output_bytes,created_at,updated_at FROM platform_jobs WHERE owner_key=? ORDER BY created_at DESC LIMIT 150');
    $s->execute([owner_key()]);
    $rows=$s->fetchAll();
} catch(Throwable $e) {
    error_log('History page query failed: '.get_class($e));
}
$pending=0;
foreach($rows as $row) if(in_array((string)$row['status'],['submitted','processing'],true)) $pending++;
$e=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
require __DIR__.'/app/platform_header.php';
?>
<section class="history-hero">
  <div><span class="page-kicker">ACTIVITY</span><h1>History</h1><p>Your generation activity is linked to your account and remains available when you sign in on another device. Active jobs refresh automatically.</p></div>
  <div class="history-summary"><strong><?=count($rows)?></strong><span>RECORDED JOBS</span><?php if($pending): ?><small><i></i><?=$pending?> active</small><?php endif; ?></div>
</section>
<section class="history-panel data-panel">
  <div class="data-panel-head"><div><h2>Generation activity</h2><p class="muted-copy">Latest 150 jobs · Updated status appears automatically</p></div><span><?=count($rows)?> records</span></div>
  <?php if(!$rows): ?>
    <div class="history-empty"><b>No activity yet</b><p>Your image, video and Lip Sync jobs will appear here after submission.</p><a href="dashboard.php">Explore workspaces</a></div>
  <?php else: ?>
    <div class="history-list">
      <?php foreach($rows as $r):
        $model=(string)$r['model'];
        $label=$model==='magic-hour-lip-sync'?'Magic Hour · AI Lip Sync':(($model==='lucy-2.5'||$model==='lucy-2.6')?'Decart · '.strtoupper($model):ucfirst((string)$r['workspace']).' · '.$model);
        $status=(string)$r['status'];
        $active=in_array($status,['submitted','processing'],true);
        $mime=(string)($r['output_mime']??'');
        $isVideo=str_starts_with($mime,'video/');
        $isImage=str_starts_with($mime,'image/');
      ?>
      <article class="history-card" data-history-job="<?=$e($r['id'])?>" data-workspace="<?=$e($r['workspace'])?>" data-model="<?=$e($model)?>" data-status="<?=$e($status)?>" <?=$active?'data-poll="1"':''?>>
        <div class="history-card-main">
          <div class="history-card-heading"><div><span class="history-workspace-tag"><?=$e(strtoupper((string)$r['workspace']))?></span><h3><?=$e($label)?></h3></div><span class="history-status status-<?=$e($status)?>" data-history-status><?= $e(ucfirst($status)) ?></span></div>
          <?php if(trim((string)$r['prompt'])!==''): ?><p class="history-prompt"><?=$e($r['prompt'])?></p><?php endif; ?>
          <p class="history-message" data-history-message><?=$e($r['error_message']?:($active?'Waiting for provider update…':($status==='completed'?'Your result is ready.':'No additional provider details were recorded.')))?></p>
          <div class="history-meta"><span>Submitted <?=$e($r['created_at'])?></span><span>Last updated <?=$e($r['updated_at'])?></span><?php if(!empty($r['output_bytes'])): ?><span><?=number_format((int)$r['output_bytes']/1048576,2)?> MB</span><?php endif; ?></div>
          <div class="history-actions">
            <?php if($status==='completed'&&!empty($r['output_disk'])): ?><a class="history-download" href="api/media.php?id=<?=$e($r['id'])?>&amp;kind=output&amp;download=1">Download result <span>↓</span></a>
            <?php elseif($active): ?><span class="history-live-note"><i></i> Checking provider status</span>
            <?php elseif($status==='failed'||$status==='expired'): ?><a class="history-retry-link" href="<?= $r['model']==='magic-hour-lip-sync'?'lip-sync/':($r['workspace']==='video'?'video/':'image/') ?>">Open workspace to try again ↗</a><?php endif; ?>
          </div>
        </div>
        <?php if($status==='completed'&&!empty($r['output_disk'])&&$isVideo): ?><div class="history-output"><video controls playsinline preload="metadata"><source src="api/media.php?id=<?=$e($r['id'])?>&amp;kind=output" type="<?=$e($mime)?>">Your browser does not support video playback.</video></div>
        <?php elseif($status==='completed'&&!empty($r['output_disk'])&&$isImage): ?><div class="history-output history-image-output"><img src="api/media.php?id=<?=$e($r['id'])?>&amp;kind=output" alt="Generated image result" loading="lazy"></div><?php endif; ?>
      </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
<script src="assets/history.js?v=2.4.5" defer></script>
<?php require __DIR__.'/app/platform_footer.php'; ?>
