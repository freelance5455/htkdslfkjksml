# Rota da Aprovação — Transpetro Administração e Controle

Aplicativo Android simples com conteúdo embarcado e funcionamento offline. Interface em português, rosa/lilás.

## Recursos
- Banco de 15 questões autorais de treino, com correção comentada.
- Simulado de 10 questões com pontuação e histórico.
- Checklist diário e sugestão de divisão semanal.
- Resumos rápidos.
- Estatísticas de desempenho.
- Dados salvos localmente no aparelho e exportação JSON.

## Gerar o APK no Android Studio
Este ambiente não tem Android SDK nem Gradle instalados, então o APK não pôde ser compilado aqui. O projeto-fonte está preparado para abrir no Android Studio.

1. Instale o Android Studio em https://developer.android.com/studio
2. Extraia o ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `transpetro_estudos`.
4. Aguarde a sincronização do Gradle e instale o SDK indicado pelo Android Studio (compile SDK 35).
5. Para testar, conecte o Android com Depuração USB ou use um emulador e clique em **Run**.
6. Para gerar o APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.
8. Transfira o APK para o celular e abra-o. Se solicitado, autorize a instalação de apps dessa fonte nas configurações do Android.

## Observações
- Não é um app oficial da Transpetro nem substitui o edital.
- Questões e resumos são material de treino geral, não questões oficiais.
- O progresso fica no armazenamento local do app; desinstalar ou limpar dados pode apagá-lo. Use “Exportar meu progresso” para salvar uma cópia.
