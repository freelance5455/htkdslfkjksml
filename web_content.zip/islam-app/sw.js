const CORE='islam-core-v5',PAGES='islam-pages-v2';
const FILES=['./','./index.html','./manifest.json','./icon-192.png','./icon-512.png','./icon-maskable.png','./apple-touch-icon.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CORE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n!==CORE&&n!==PAGES).map(n=>caches.delete(n)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=='GET')return;
  const font=u.hostname==='fonts.googleapis.com'||u.hostname==='fonts.gstatic.com';
  if(u.origin!==location.origin&&!font)return;
  e.respondWith(caches.match(r,{ignoreSearch:false}).then(hit=>{
    if(hit){
      if(u.pathname.endsWith('.html')||u.pathname.endsWith('/'))fetch(r).then(n=>{if(n.ok)caches.open(CORE).then(c=>c.put(r,n))}).catch(()=>{});
      return hit;
    }
    return fetch(r).then(n=>{
      if(n.ok||n.type==='opaque'){const cp=n.clone();caches.open(u.pathname.includes('/pages/')?PAGES:CORE).then(c=>c.put(r,cp))}
      return n;
    }).catch(()=>caches.match('./index.html'));
  }));
});
