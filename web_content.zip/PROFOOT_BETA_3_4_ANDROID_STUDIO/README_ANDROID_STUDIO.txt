PROFOOT BETA 3.4 — PROJETO ANDROID STUDIO

Projeto Android nativo de embalagem (Java + WebView) para executar os arquivos web do PROFOOT localmente no Android.
O jogo permanece implementado em HTML/CSS/JavaScript; não é uma reescrita de toda a lógica do jogo em Java.

COMO ABRIR
1. Extraia este ZIP para uma pasta.
2. Abra o Android Studio.
3. Escolha Open e selecione a pasta PROFOOT_BETA_3_4_ANDROID_STUDIO (a pasta que contém settings.gradle).
4. Aguarde o Gradle Sync. É necessário ter Android SDK 35 e JDK 17 configurados; o Android Studio normalmente oferece a instalação.
5. Execute no emulador ou em um celular Android conectado por USB com Depuração USB habilitada.

OBSERVAÇÕES
- minSdk 23 (Android 6.0).
- A carreira é salva pelo localStorage do WebView.
- A conexão à internet é usada por recursos que carregam escudos externos.
- O jogo é carregado de app/src/main/assets/index.html.
- Este pacote foi montado a partir do pacote web Beta 3.4 disponível. Não foi possível executar um teste funcional de jogo/emulador neste ambiente.

CORREÇÃO DO CALENDÁRIO ESTADUAL (outubro/2026)
- A data base da carreira é 06/01/2026 (careerDay 0). Os jogos estaduais são agendados no intervalo de dias 0 a 6, correspondente a 06/01–12/01.
- Cada fixture estadual agora carrega id, competitionId, homeId e awayId; o início e o registro do resultado usam a identidade da fixture, não apenas o texto do adversário.
- O calendário estadual antigo é migrado uma única vez. Resultados já disputados são preservados; se a carreira avançou além de 12/01 sem nenhuma partida disputada, a migração retorna ao início para tornar os jogos de janeiro jogáveis.
- A tabela estadual exibe a data de calendário correspondente à fixture, e não o índice interno do dia.
- Removida a reinicialização automática da tabela estadual baseada apenas na versão do jogo, que poderia descartar a tabela persistida ao abrir o jogo.

TESTES AUTOMATIZADOS DE CALENDÁRIO
Com Node.js instalado, a partir da pasta do projeto execute:
  node tests/test_estaduais.js
O teste verifica geração de fixtures em 06/01–12/01, início no dia oficial, mensagem da próxima data, avanço até a data, bloqueio de fixture já disputada, migração de saves antigos e exibição da data na tela.

Limitação: os testes automatizados de lógica e a verificação de sintaxe JavaScript foram executados. Este ambiente não dispõe de um emulador Android configurado para executar um teste funcional de ponta a ponta no aparelho.

CORREÇÃO ADICIONAL — ESTADUAL COMO PARTIDA OFICIAL (BETA 3.4.7)
- Partidas estaduais agora aparecem no histórico geral da carreira, em vez de serem filtradas.
- O registro de cada partida salva explicitamente competitionType, inclusive estadual.
- Resultado estadual continua atualizando a tabela e os números individuais do atleta, sem somar pontos/resultado à tabela do Brasileirão.
- Jogo estadual não avança a rodada nacional nem pode disparar o encerramento da temporada do Brasileirão.
- Regressões cobertas pelos testes H e I em tests/test_estaduais.js.


BETA 3.4.10 — INÍCIO DE PARTIDA PELA DATA
- O botão de iniciar valida que o dia atual da carreira seja exatamente o dia marcado para o confronto.
- Removida a barreira de lesão que impedia a abertura da partida.
- Aplicado aos caminhos de calendário e partidas presentes nos arquivos JS do projeto.
- Verificação estática de sintaxe realizada; não equivale a teste no dispositivo Android.

BETA 3.4.11 — CALENDÁRIO E INÍCIO POR DATA EXATA
- O botão da tela Início só oferece INICIAR PARTIDA quando careerDay é igual ao dia marcado para o próximo confronto.
- O calendário identifica os compromissos de hoje, sinaliza datas passadas e oferece INICIAR PARTIDA somente para partidas do clube na data atual da carreira.
- A validação final no startMatch continua exigindo uma partida agendada para o dia exato; a mudança de interface não contorna essa validação.
- Verificações de sintaxe automatizadas; ainda requer teste funcional no Android.
