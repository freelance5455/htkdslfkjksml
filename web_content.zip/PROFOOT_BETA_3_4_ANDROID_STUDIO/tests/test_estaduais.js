const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
const normalize=html.match(/function pfNormalizeStateSchedule\(\)\{[\s\S]*?\n\}/)[0];
const patch=html.match(/const pfOriginalStartMatch=startMatch;[\s\S]*?\nconst pfOriginalPlayerDue=/)[0].replace(/\nconst pfOriginalPlayerDue=$/,'');
const sourceLines=html.split('\n');const advanceIndex=sourceLines.lastIndexOf('const pfOriginalAdvanceToNextMatch=advanceToNextMatch;');const advancePatch=sourceLines[advanceIndex]+'\n'+sourceLines[advanceIndex+1];assert(advanceIndex>=0,'missing advanceToNextMatch patch');

function extractFunction(source, name){
 const start=source.indexOf(`function ${name}(`);assert(start>=0,`missing ${name}`);let brace=source.indexOf('{',start),depth=0,inSingle=false,inDouble=false,inTemplate=false,escape=false;
 for(let i=brace;i<source.length;i++){const ch=source[i];if(escape){escape=false;continue;}if(ch==='\\'){escape=true;continue;}if(!inDouble&&!inTemplate&&ch==="'"){inSingle=!inSingle;continue;}if(!inSingle&&!inTemplate&&ch==='\"'){inDouble=!inDouble;continue;}if(!inSingle&&!inDouble&&ch==='`'){inTemplate=!inTemplate;continue;}if(inSingle||inDouble||inTemplate)continue;if(ch==='{')depth++;else if(ch==='}'&&--depth===0)return source.slice(start,i+1);}
 throw new Error(`unterminated ${name}`);
}
const ensureFn=extractFunction(html,'pfEnsureStateSeason');
const genCtx={s:{season:2026,seasonStartDay:0,stateChampionships:null},pfStateConfig:()=>[{state:'SP',name:'Paulista',clubs:['Corinthians','Palmeiras','Santos FC','São Paulo'],priority:true}],PF_ACCESS_CLUBS:{SP:[]},pfAllNationalClubs:()=>['Corinthians','Palmeiras','Santos FC','São Paulo'],PF_STATE_NAMES:{SP:'Paulista'},pfStateFormat:()=> 'teste'};
vm.createContext(genCtx);vm.runInContext(ensureFn,genCtx);genCtx.pfEnsureStateSeason();const generated=genCtx.s.stateChampionships.competitions.SP.fixtures;assert(generated.every(f=>f.day>=0&&f.day<=6));assert(generated.some(f=>f.round===1&&f.day===0));assert(generated.every(f=>f.id&&f.competitionId&&f.homeId&&f.awayId));

function setup(day, fixtures){
 const messages=[]; const comp={state:'SP',name:'Campeonato Paulista 2026',fixtures};
 let ctx; ctx={
  s:{created:true,season:2026,seasonStartDay:0,careerDay:day,round:1,player:{club:'Corinthians',competition:'serieA'},stateChampionships:{season:2026,scheduleVersion:2,competitions:{SP:comp}},played:[],liveMatch:null},
  pfEnsureStateSeason(){},pfNormalizeStateSchedule(){},pfClubState(){return 'SP'},pfStateClubKey(n){return String(n||'').toLowerCase().replace(/-(sp|ba)$/,'').replace(/^(ec|e\.c\.|fc|f\.c\.)\s*/,'').replace(/[^a-z0-9]+/g,' ').trim()},pfSameStateClub(a,b){const k=n=>String(n||'').toLowerCase().replace(/-(sp|ba)$/,'').replace(/^(ec|e\.c\.|fc|f\.c\.)\s*/,'').replace(/[^a-z0-9]+/g,' ').trim();return !!a&&!!b&&k(a)===k(b)},pfOriginalNextFixture(){return null},pfNextStateFixture(){const f=ctx.s.stateChampionships.competitions.SP.fixtures.find(x=>x.status==='scheduled');return f?{...f,type:'estadual',competition:'Paulista',state:'SP',opponent:f.home==='Corinthians'?f.away:f.home,fixture:f}:null},
  startMatch(){},nextOpponent(){return 'stub'},save(){},render(){},
  pfToast(m){messages.push(m)},dateLabel(d){return `${String(d.getUTCDate()).padStart(2,'0')}/${String(d.getUTCMonth()+1).padStart(2,'0')}/${d.getUTCFullYear()}`},
  careerDate(d){return new Date(Date.UTC(2026,0,1+d))},messages,console
 };
 ctx.startMatch=function(){ctx.s.liveMatch={status:'live',opponent:'stub'}}; vm.createContext(ctx); vm.runInContext(patch,ctx); return ctx;
}
const fixture=(day,round=1,status='scheduled')=>({id:`f${round}`,competitionId:'estadual:2026:SP',home:'Corinthians',away:'Palmeiras',homeId:'Corinthians',awayId:'Palmeiras',state:'SP',round,day,status,stage:'fase de grupos'});
// A: current-day (06/01) fixture launches the correct estadual.
let c=setup(0,[fixture(0)]); c.startMatch(); assert.equal(c.s.liveMatch.status,'live'); assert.equal(c.s.liveMatch.competitionType,'estadual'); assert.equal(c.s.liveMatch.scheduledDay,0);
// A2: aliases such as Vitória-BA (fixture ID) and Vitória (display/player name) must resolve to the same same-day state match.
{
 const f={...fixture(0),home:'Vitória',away:'Juazeirense',homeId:'Vitória-BA',awayId:'Juazeirense-BA',state:'BA',id:'vitoria-juazeirense'};
 const c=setup(0,[f]);c.s.player.club='Vitória';c.pfClubState=()=> 'SP';c.startMatch();assert.equal(c.s.liveMatch.status,'live');assert.equal(c.s.liveMatch.competitionType,'estadual');assert.equal(c.s.liveMatch.opponent,'Juazeirense');
}
// B: before the next fixture, the next date is reported as 09/01 (day 3), not February.
c=setup(0,[fixture(3)]); c.startMatch(); assert.equal(c.s.liveMatch,null); assert(c.messages.some(x=>x.includes('04/01/2026')),c.messages.join('|'));
// D: arriving on the official date opens the corresponding fixture.
c=setup(3,[fixture(3)]); c.startMatch(); assert.equal(c.s.liveMatch.competitionType,'estadual'); assert.equal(c.s.liveMatch.stateFixtureId,'f1');
// F: played fixtures cannot start again.
c=setup(0,[fixture(0,1,'played')]); c.startMatch(); assert.equal(c.s.liveMatch,null); assert(c.messages.some(x=>x.includes('não tem partidas')));
// D: the real advance-to-next-state-match wrapper reaches the official day and then starts it.
{
 const c=setup(0,[fixture(3)]);c.advanceToNextMatch=function(){};c.getNextPlayerFixture=function(){const f=c.s.stateChampionships.competitions.SP.fixtures.find(x=>x.status==='scheduled');return f?{...f,type:'estadual',competition:'Paulista',state:'SP',opponent:f.away,fixture:f}:null};c._advanceCareerDayEngine=function(){c.s.careerDay++};c.pfSimStateDay=function(){};c.simulateWorldScheduleThroughDay=function(){};c.progressBrazilCupBackground=function(){};c.pfEnsureStateSeason=function(){};vm.runInContext(advancePatch,c);c.advanceToNextMatch();assert.equal(c.s.careerDay,3);c.startMatch();assert.equal(c.s.liveMatch.competitionType,'estadual');assert.equal(c.s.liveMatch.scheduledDay,3);
}
// Schedule mapping places every estadual round between 05/01 and 12/02 inclusive.
for(let roundCount=1;roundCount<=20;roundCount++) for(let r=0;r<roundCount;r++){const d=roundCount===1?4:Math.round(4+38*r/(roundCount-1));assert(d>=4&&d<=42);if(roundCount>1&&r===roundCount-1)assert.equal(d,42);}
// G: schedule v6 re-sorts all fixtures, rebuilds tables and schedules Jan 05–Feb 12.
const oldFixtures=[fixture(39,1,'scheduled')];
const ctx={s:{season:2026,seasonStartDay:0,careerDay:39,round:5,played:[],liveMatch:null,stateChampionships:{season:2026,scheduleVersion:5,processed:[],competitions:{SP:{state:'SP',clubs:['Corinthians','Palmeiras','Santos FC','São Paulo'],fixtures:oldFixtures,table:{Corinthians:{played:3,pts:9}}}}}},maxRounds:()=>0,leagueRoundDay:()=>100,BRAZIL_CUP_STAGE_DAYS:[],BRAZIL_CUP_RETURN_OFFSETS:[],console,Math};vm.createContext(ctx);vm.runInContext(normalize,ctx);ctx.pfNormalizeStateSchedule();const rebuilt=ctx.s.stateChampionships.competitions.SP.fixtures;assert.equal(ctx.s.stateChampionships.scheduleVersion,6);assert.equal(rebuilt.length,6);assert(rebuilt.every(f=>f.status==='scheduled'&&f.id&&f.homeId&&f.awayId));assert(rebuilt.every(f=>f.day>=4&&f.day<=42));assert.equal(Math.min(...rebuilt.map(f=>f.day)),4);assert.equal(Math.max(...rebuilt.map(f=>f.day)),42);assert.equal(ctx.s.stateChampionships.competitions.SP.table.Corinthians.played,0);assert.equal(ctx.s.careerDay,39);console.log('PASS G: schedule v6 reshuffles fixtures, resets state table and schedules Jan 05–Feb 12 without rewinding career');
assert(html.includes('${dateLabel(careerDate(f.day))} · ${esc(f.stage)}'));console.log('PASS E: estadual screen renders the same calendar date derived from fixture.day');
// H: estadual is retained in the career history and its match type is explicit.
assert(!html.includes("filter(g=>g.competitionType!=='estadual'&&!/^Campeonato"),'state matches must not be filtered from history');
assert(html.includes("competitionType:m.competitionType||'league'"),'played match record must persist competitionType');
// I: a state match must neither finish the national league season nor increment its round.
assert(html.includes("m.competitionType!=='copaBrasil'&&m.competitionType!=='estadual'&&s.round>=maxRounds"),'state match must not trigger national season end');
assert(html.includes("else if(m.competitionType!=='copaBrasil'&&m.competitionType!=='estadual')s.round++"),'state match must not increment the national round');
console.log('PASS H: estadual is included in career history and its competition type is saved');
console.log('PASS I: estadual results do not change the Brasileirão round or end the national season');

// J: home enables launch only when the fixture day equals the career day; calendar offers the same-day action.
assert(html.includes('Number(fixture.day)===Number(s.careerDay||0)'), 'home must require exact day equality');
assert(html.includes("${due?'startMatch()':'advanceToNextMatch()'}"), 'home should start directly when today is match day');
assert(html.includes('HOJE · DIA DE JOGO') && html.includes('onclick=\"startMatch()\">▶ INICIAR PARTIDA'), 'calendar should mark and launch same-day fixtures');
console.log('PASS J: exact date equality controls start button on home and calendar');
