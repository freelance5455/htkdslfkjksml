# Bombe Lite — projeto Android Studio único

Este pacote contém **uma única aplicação Android**, com as opções reunidas no menu inicial do Bombe Lite. Não é necessário instalar um app Bluetooth separado nem usar a variante Godot.

## Abrir e executar

1. Abra esta pasta no Android Studio.
2. Use JDK 17 e Android SDK 35 e aguarde a sincronização do Gradle.
3. Conecte um aparelho Android e pressione **Run**.

Para gerar um APK, use **Build → Build APK(s)** no Android Studio. Este pacote é o projeto-fonte; não inclui um APK compilado.

## Recursos no mesmo app

- **Bluetooth:** busca de dispositivos próximos, lista e filtros por tipo, seleção e solicitação de pareamento com confirmação do Android. A opção **Desconectar** abre as configurações oficiais, pois o Android não oferece uma API pública genérica para desconectar qualquer perfil. A imagem enviada aparece ao tocar em **Ver imagem de referência**.
- **Wi‑Fi:** tela visual e atalhos para as configurações oficiais do Android; os nomes de rede ilustrativos não são redes reais.
- **Mensagens:** hub com conversas de exemplo, teclado visual, abertura do WhatsApp para confirmação e opção POST HTTPS para um servidor WhatsApp Business. O endpoint precisa ser configurado; mantenha credenciais somente no servidor.
- **Loja e jogos:** catálogo e atalhos para os apps/jogos, com instalação confirmada pela Play Store.
- **Instalar APK:** seletor de arquivos do Android e confirmação no instalador do sistema.
- **Configurações, atalhos Android e minijogo Bombe Lite** integrados ao mesmo menu.

O Bluetooth desta versão usa a integração Kotlin em `app/src/main/java/com/bombelite/app/MainActivity.kt`; não depende do singleton Godot `AndroidBluetooth`. A imagem de referência Bluetooth está em `app/src/main/assets/referencia_bluetooth_interface.jpg`.
