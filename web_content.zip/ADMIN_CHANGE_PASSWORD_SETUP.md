# Admin Change Password setup

1. Supabase Dashboard -> Edge Functions -> Create function named `admin-change-password`.
2. Replace `index.ts` with `supabase/functions/admin-change-password/index.ts` from this ZIP.
3. Deploy the function.
4. Do not put the Supabase service-role key in the app. The Edge Function reads `SUPABASE_SERVICE_ROLE_KEY` from the server environment.
5. Build/install this Android project.

The admin Users screen now has `Change Password` for other users. Passwords must be at least 8 characters and the confirmation must match. The administrator cannot change their own password from this button.
