-- GH MARKETPLACE: owner-controlled global country market
-- Run in Supabase SQL Editor as project owner.
-- Requires the existing public.gh_is_marketplace_owner() RPC.

CREATE TABLE IF NOT EXISTS public.marketplace_settings (
  id integer PRIMARY KEY CHECK (id = 1),
  country text NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.marketplace_settings (id, country)
VALUES (1, NULL)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.marketplace_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Marketplace settings readable by everyone" ON public.marketplace_settings;
CREATE POLICY "Marketplace settings readable by everyone"
ON public.marketplace_settings FOR SELECT TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "Only GH owner can insert marketplace settings" ON public.marketplace_settings;
CREATE POLICY "Only GH owner can insert marketplace settings"
ON public.marketplace_settings FOR INSERT TO authenticated
WITH CHECK ((SELECT public.gh_is_marketplace_owner()));

DROP POLICY IF EXISTS "Only GH owner can update marketplace settings" ON public.marketplace_settings;
CREATE POLICY "Only GH owner can update marketplace settings"
ON public.marketplace_settings FOR UPDATE TO authenticated
USING ((SELECT public.gh_is_marketplace_owner()))
WITH CHECK ((SELECT public.gh_is_marketplace_owner()));

GRANT SELECT ON public.marketplace_settings TO anon, authenticated;
GRANT INSERT, UPDATE ON public.marketplace_settings TO authenticated;
NOTIFY pgrst, 'reload schema';

-- Verify current setting:
-- SELECT * FROM public.marketplace_settings WHERE id = 1;
