-- Patch 4: source-level shadow facts for like-for-like admin reconciliation.
-- Additive only. Existing leaderboard tables and calculations are unchanged.

create table if not exists private.competition_shadow_source_weekly_stats (
  user_id uuid not null references auth.users(id) on delete cascade,
  week_basis text not null check (week_basis in ('utc','asia_kolkata')),
  week_start date not null,
  source text not null check (source in ('home','focus','practice','sample_paper')),
  eligible_seconds bigint not null default 0 check (eligible_seconds >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id,week_basis,week_start,source)
);

alter table private.competition_shadow_source_weekly_stats enable row level security;
revoke all on private.competition_shadow_source_weekly_stats from public,anon,authenticated;

create or replace function public.get_competition_shadow_comparison_v2()
returns table(
  week_start date,
  legacy_week_start date,
  user_id uuid,
  display_name text,
  competition_opt_in boolean,
  legacy_focus_utc_seconds bigint,
  verified_focus_utc_seconds bigint,
  focus_utc_delta_seconds bigint,
  verified_focus_ist_seconds bigint,
  verified_home_ist_seconds bigint,
  verified_practice_ist_seconds bigint,
  verified_sample_paper_ist_seconds bigint,
  verified_all_sources_ist_seconds bigint,
  verified_rank bigint,
  previous_verified_rank bigint
)
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := (select auth.uid());
  v_ist_week date := date_trunc('week',now() at time zone 'Asia/Kolkata')::date;
  v_utc_week date := date_trunc('week',now() at time zone 'UTC')::date;
  v_previous_ist_week date := (date_trunc('week',now() at time zone 'Asia/Kolkata')::date-7);
begin
  if v_uid is null or not exists (
    select 1 from public.scoredeck_admin_roles r where r.user_id=v_uid and r.role in ('owner','co_admin')
  ) then raise exception 'Owner/admin access required'; end if;

  perform public.refresh_competition_shadow();

  with ranges as (
    select i.user_id,i.source,unnest(range_agg(tstzrange(i.started_at,i.ended_at,'[)'))) as r
    from private.competition_time_intervals i
    group by i.user_id,i.source
  ), weeks as (
    select x.user_id,x.source,b.week_basis,g.week_start::date as week_start,
      extract(epoch from (least(upper(x.r),((g.week_start+interval '7 days') at time zone b.zone_name))
        - greatest(lower(x.r),(g.week_start at time zone b.zone_name))))::bigint as seconds
    from ranges x
    cross join (values ('utc','UTC'),('asia_kolkata','Asia/Kolkata')) as b(week_basis,zone_name)
    cross join lateral generate_series(
      date_trunc('week',lower(x.r) at time zone b.zone_name),
      date_trunc('week',(upper(x.r)-interval '1 microsecond') at time zone b.zone_name),
      interval '7 days'
    ) as g(week_start)
  ), totals as (
    select w.user_id,w.week_basis,w.week_start,w.source,sum(w.seconds)::bigint as seconds
    from weeks w where w.seconds>0 group by w.user_id,w.week_basis,w.week_start,w.source
  )
  insert into private.competition_shadow_source_weekly_stats(user_id,week_basis,week_start,source,eligible_seconds,updated_at)
  select t.user_id,t.week_basis,t.week_start,t.source,t.seconds,clock_timestamp() from totals t
  on conflict on constraint competition_shadow_source_weekly_stats_pkey do update set
    eligible_seconds=excluded.eligible_seconds,updated_at=excluded.updated_at;

  return query
  select v_ist_week,v_utc_week,p.id,p.display_name,p.competition_opt_in,
    coalesce(l.focus_seconds,0)::bigint,
    coalesce(fu.eligible_seconds,0)::bigint,
    coalesce(fu.eligible_seconds,0)-coalesce(l.focus_seconds,0),
    coalesce(fi.eligible_seconds,0)::bigint,
    coalesce(h.eligible_seconds,0)::bigint,
    coalesce(pr.eligible_seconds,0)::bigint,
    coalesce(sp.eligible_seconds,0)::bigint,
    coalesce(all_ist.verified_seconds,0)::bigint,
    all_ist.shared_rank,
    prev.shared_rank
  from public.profiles p
  left join public.competition_weekly_stats l
    on l.user_id=p.id and l.week_start=v_utc_week and l.subject_key='__all__'
  left join private.competition_shadow_source_weekly_stats fu
    on fu.user_id=p.id and fu.week_basis='utc' and fu.week_start=v_utc_week and fu.source='focus'
  left join private.competition_shadow_source_weekly_stats fi
    on fi.user_id=p.id and fi.week_basis='asia_kolkata' and fi.week_start=v_ist_week and fi.source='focus'
  left join private.competition_shadow_source_weekly_stats h
    on h.user_id=p.id and h.week_basis='asia_kolkata' and h.week_start=v_ist_week and h.source='home'
  left join private.competition_shadow_source_weekly_stats pr
    on pr.user_id=p.id and pr.week_basis='asia_kolkata' and pr.week_start=v_ist_week and pr.source='practice'
  left join private.competition_shadow_source_weekly_stats sp
    on sp.user_id=p.id and sp.week_basis='asia_kolkata' and sp.week_start=v_ist_week and sp.source='sample_paper'
  left join private.competition_shadow_weekly_stats all_ist
    on all_ist.user_id=p.id and all_ist.week_start=v_ist_week
  left join private.competition_shadow_weekly_stats prev
    on prev.user_id=p.id and prev.week_start=v_previous_ist_week
  where p.competition_opt_in
  order by all_ist.shared_rank nulls last,p.display_name,p.id;
end;
$function$;

revoke all on function public.get_competition_shadow_comparison_v2() from public,anon;
grant execute on function public.get_competition_shadow_comparison_v2() to authenticated;
