# Contractor Pro Server

Node 20+ (tested on 22). Auth, RBAC, tamper-evident audit log, offline sync with conflict resolution, license check, AI gateway.

```bash
cd server
npm install                 # installs pg
cp .env.example .env        # set JWT_SECRET, DATABASE_URL, ANTHROPIC_API_KEY
npm run migrate             # applies sql/001_schema.sql to PostgreSQL
npm start
npm test                    # 25 tests, uses the in-memory store (no database needed)
```
Without `DATABASE_URL` (development only) the server uses an in-memory store. In production it refuses to start without `DATABASE_URL` and a 32+ char `JWT_SECRET`.

## API (matches the app's V17.5 clients)
`GET /health` · `POST /api/auth/{register,login,request-otp,verify-otp,refresh,logout}` · `GET /api/auth/me` · `POST /api/account/password`
`GET|POST /api/users`, `PATCH /api/users/:id` · `GET /api/audit` · `POST /api/sync/push` · `GET /api/sync/pull` · `POST /api/sync/changes` · `GET /api/sync/records`
`POST /api/license/validate` · `POST /api/billing/create-checkout` (501 until a crypto provider is configured) · `POST /api/ai/copilot` · `POST /api/ai/task` (project_analysis, estimate_from_text, drawing_to_boq, contract_review, daily_report, invoice_followup, cashflow_forecast)
`GET /api/billing/plans` · `GET /api/billing/status` · `POST /api/billing/create-checkout` (BTC/USDT via BTCPay or NOWPayments) · `POST /api/billing/webhook/:provider`

### Project management AI analysis
The `project_analysis` task is available from the AI Tools panel. It analyzes the latest server-side workspace snapshot for overdue schedule tasks, overdue invoices, and inventory items at/below their configured minimum. It returns a risk level, evidence, recommended actions, and missing-data warnings. With no AI API key it still returns a deterministic rule-based report; when the configured Anthropic provider is available, the model adds a language-aware interpretation. Results depend on the latest successful cloud sync and the signed-in role's readable modules; this is a practical risk aid, not a critical-path scheduler or a guarantee of forecast accuracy.

Deployment: see ../DEPLOY-fa.md

Not verified in the build environment: the PostgreSQL store (no database available) and the live Anthropic call (no network/key).
