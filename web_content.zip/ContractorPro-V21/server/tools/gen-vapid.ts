import { generateVapidKeys } from '../src/webpush.ts';
const k = generateVapidKeys('mailto:admin@example.com');
console.log(`VAPID_PUBLIC_KEY=${k.publicKey}\nVAPID_PRIVATE_KEY=${k.privateKey}\nVAPID_SUBJECT=mailto:you@your-domain.com`);
