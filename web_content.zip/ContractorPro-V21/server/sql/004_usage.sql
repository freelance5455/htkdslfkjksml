-- Per-customer cost cap: usage ledger (+ extra credit rows), policy settings, payment adjustments for net-revenue maths.
CREATE TABLE IF NOT EXISTS usage_ledger (
  id bigserial PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id text,
  kind text NOT NULL,                 -- ai | sync | credit
  cost_usd numeric(14,6) NOT NULL,    -- real cost (for kind=credit: the credit amount added)
  credit_usd numeric(14,6) NOT NULL DEFAULT 0,  -- part of cost_usd that was paid from extra credit
  meta text,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS usage_ledger_org_at ON usage_ledger(org_id, at);
CREATE TABLE IF NOT EXISTS settings (key text PRIMARY KEY, value jsonb NOT NULL);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS fee_usd numeric(12,2);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS tax_usd numeric(12,2);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS refunded_usd numeric(12,2) NOT NULL DEFAULT 0;
