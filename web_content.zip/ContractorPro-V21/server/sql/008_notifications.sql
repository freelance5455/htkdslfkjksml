-- Web Push subscriptions and "already alerted" keys (so each overdue item is announced once).
CREATE TABLE IF NOT EXISTS push_subscriptions (
  endpoint text PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  p256dh text NOT NULL,
  auth text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS push_subscriptions_user ON push_subscriptions(org_id, user_id);
CREATE TABLE IF NOT EXISTS notified_alerts (
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  alert_key text NOT NULL,
  at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, alert_key)
);
