-- GDPR erasure: allow an organization's audit rows to be removed ONLY inside a transaction that names it
-- (set_config('cp.purge_org', <org uuid>, true)). UPDATE stays forbidden and DELETE without the setting stays forbidden.
CREATE OR REPLACE FUNCTION audit_log_immutable() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' AND current_setting('cp.purge_org', true) = OLD.org_id::text THEN
    RETURN OLD;
  END IF;
  RAISE EXCEPTION 'audit_log is append-only';
END;
$$ LANGUAGE plpgsql;
