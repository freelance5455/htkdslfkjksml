-- Cloud photos/files metadata (bytes live in the blob store).
CREATE TABLE IF NOT EXISTS files (
  id uuid PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  uploaded_by text NOT NULL,
  name text NOT NULL,
  mime text NOT NULL,
  size bigint NOT NULL,
  sha256 text NOT NULL,
  module text NOT NULL DEFAULT '',
  record_id text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS files_org_rec ON files(org_id, module, record_id);
CREATE UNIQUE INDEX IF NOT EXISTS files_org_hash ON files(org_id, sha256, module, record_id);
