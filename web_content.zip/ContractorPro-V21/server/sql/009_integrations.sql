-- Live accounting integrations. tokens_enc is AES-256-GCM sealed by the app (INTEGRATION_KEY); the database never sees plaintext tokens.
CREATE TABLE IF NOT EXISTS integrations (
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  provider text NOT NULL CHECK (provider IN ('quickbooks','xero')),
  tokens_enc text NOT NULL,
  realm text NOT NULL,
  connected_by text NOT NULL,
  connected_at timestamptz NOT NULL DEFAULT now(),
  last_sync_at timestamptz,
  PRIMARY KEY (org_id, provider)
);
-- one external document per Contractor Pro record; hash detects edits so unchanged records are skipped
CREATE TABLE IF NOT EXISTS integration_map (
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  provider text NOT NULL,
  module text NOT NULL,
  record_id text NOT NULL,
  external_id text NOT NULL,
  hash text NOT NULL,
  synced_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, provider, module, record_id)
);
