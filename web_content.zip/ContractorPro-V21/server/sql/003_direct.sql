-- Direct-wallet crypto payments (customer pays the operator's address; operator confirms).
ALTER TABLE payments ADD COLUMN IF NOT EXISTS currency text;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS amount_crypto numeric(24,8);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS address text;
-- an open direct invoice must have an amount no other open invoice uses
CREATE UNIQUE INDEX IF NOT EXISTS payments_direct_open_amount ON payments(currency, amount_crypto) WHERE provider = 'direct' AND status = 'pending';
