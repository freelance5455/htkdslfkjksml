-- Crypto billing: one row per checkout. order_id is our own id (sent to the provider as metadata/order_id).
CREATE TABLE IF NOT EXISTS payments (
  order_id text PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  plan_id text NOT NULL,
  tier text NOT NULL,
  days int NOT NULL,
  amount_usd numeric(12,2) NOT NULL,
  provider text NOT NULL,
  provider_ref text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','failed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  paid_at timestamptz
);
CREATE INDEX IF NOT EXISTS payments_org ON payments(org_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS payments_provider_ref ON payments(provider, provider_ref) WHERE provider_ref IS NOT NULL;
