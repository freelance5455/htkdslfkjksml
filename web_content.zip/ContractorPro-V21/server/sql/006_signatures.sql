-- Simple e-signature / approval records (tamper-evident; NOT a qualified eIDAS signature).
CREATE TABLE IF NOT EXISTS signatures (
  id uuid PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id text NOT NULL,
  user_email text NOT NULL,
  signer_name text NOT NULL,
  module text NOT NULL,
  record_id text NOT NULL,
  title text NOT NULL DEFAULT '',
  decision text NOT NULL,
  doc_hash text NOT NULL,
  sig_hash text NOT NULL,
  image text NOT NULL DEFAULT '',
  ip text NOT NULL DEFAULT '',
  signed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS signatures_rec ON signatures(org_id, module, record_id);
