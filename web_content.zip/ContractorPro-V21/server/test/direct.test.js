import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { MemoryStore } from '../src/store-memory.js';
import { LocalProvider } from '../src/ai-gateway.js';
import { parseDirect, uniqueAmount, tokenOk } from '../src/direct.js';
import { getBtcUsdRate } from '../src/crypto-rates.js';

const PW = 'correct-horse-battery', OP = 'o'.repeat(32);
const BTC = 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', USDT = 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE';

async function boot({ rate = async () => 50000, direct = { wallets: { btc: BTC, usdt: USDT }, operatorToken: OP, usdtNetwork: 'TRC20' } } = {}) {
  const store = new MemoryStore();
  const app = createApp({ store, aiProvider: new LocalProvider(), billing: { direct, rate }, config: { jwtSecret: 'x'.repeat(40) } });
  const server = http.createServer(app); await new Promise(r => server.listen(0, r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, path, body, token, headers = {}) => {
    const r = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, body: await r.json() };
  };
  const owner = (await call('POST', '/api/auth/register', { email: 'o@x.com', password: PW, orgName: 'Acme' })).body;
  const member = async (email, role) => { await call('POST', '/api/users', { email, password: PW, role }, owner.accessToken); return (await call('POST', '/api/auth/login', { email, password: PW })).body; };
  return { store, call, owner, member, close: () => server.close() };
}

test('parseDirect validates addresses and requires an operator token', () => {
  assert.equal(parseDirect({}), null);
  assert.throws(() => parseDirect({ DIRECT_BTC_ADDRESS: 'not-an-address', OPERATOR_TOKEN: OP }), /valid BTC/);
  assert.throws(() => parseDirect({ DIRECT_BTC_ADDRESS: BTC }), /OPERATOR_TOKEN/);
  assert.deepEqual(Object.keys(parseDirect({ DIRECT_BTC_ADDRESS: BTC, DIRECT_USDT_ADDRESS: USDT, OPERATOR_TOKEN: OP }).wallets), ['btc', 'usdt']);
});

test('uniqueAmount avoids amounts used by open invoices and tokenOk is strict', () => {
  const seq = [0.0005, 0.0005, 0.7]; const r = () => seq.shift();
  const a = uniqueAmount('usdt', 29, [], r), b = uniqueAmount('usdt', 29, [a], r);
  assert.notEqual(a, b); assert.ok(a > 29 && a < 29.1);
  const s = uniqueAmount('btc', 0.0006, [], () => 0.5); assert.ok(s > 0.0006 && s < 0.00061);
  assert.equal(tokenOk(OP, OP), true); assert.equal(tokenOk('x', OP), false); assert.equal(tokenOk(OP, ''), false);
});

test('rate fetch: parses price, rejects bad data, injectable', async () => {
  assert.equal(await getBtcUsdRate(async () => ({ ok: true, json: async () => ({ bitcoin: { usd: 61000 } }) })), 61000);
  await assert.rejects(getBtcUsdRate(async () => ({ ok: true, json: async () => ({}) })));
  await assert.rejects(getBtcUsdRate(async () => ({ ok: false, status: 500 })));
});

test('invoice creation: roles, unique amounts, BTC conversion, plan list exposes currencies', async (x) => {
  const t = await boot(); x.after(t.close);
  const plans = await t.call('GET', '/api/billing/plans');
  assert.deepEqual(plans.body.direct.currencies, ['btc', 'usdt']);
  assert.equal((await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'usdt' })).status, 401);
  const acc = await t.member('acc@x.com', 'accountant');
  assert.equal((await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'usdt' }, acc.accessToken)).status, 403);
  assert.equal((await t.call('POST', '/api/billing/direct-invoice', { plan: 'nope', currency: 'usdt' }, t.owner.accessToken)).status, 400);
  assert.equal((await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'doge' }, t.owner.accessToken)).status, 400);
  const u1 = (await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'usdt' }, t.owner.accessToken)).body;
  const u2 = (await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'usdt' }, t.owner.accessToken)).body;
  assert.equal(u1.address, USDT); assert.notEqual(u1.amountCrypto, u2.amountCrypto);
  const price = (await t.call('GET', '/api/billing/plans')).body.plans.find(p => p.id === 'pro_monthly').usd;
  assert.ok(u1.amountCrypto > price && u1.amountCrypto < price + 0.1);
  const b = (await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'btc' }, t.owner.accessToken)).body;
  assert.equal(b.address, BTC); assert.ok(Math.abs(b.amountCrypto - price / 50000) < 0.00001);
});

test('rate outage returns 503 and creates nothing', async (x) => {
  const t = await boot({ rate: async () => { throw new Error('down'); } }); x.after(t.close);
  assert.equal((await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'btc' }, t.owner.accessToken)).status, 503);
  assert.equal((await t.store.listPendingDirect()).length, 0);
});

test('only the operator can confirm; customer cannot self-activate; confirm is idempotent and activates the plan', async (x) => {
  const t = await boot(); x.after(t.close);
  const inv = (await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'usdt' }, t.owner.accessToken)).body;
  // customer (owner of the workspace) has no way to confirm
  assert.equal((await t.call('POST', '/api/operator/direct-confirm/' + inv.orderId, {}, t.owner.accessToken)).status, 401);
  assert.equal((await t.call('POST', '/api/operator/direct-confirm/' + inv.orderId, {}, null, { 'x-operator-token': 'wrong' })).status, 401);
  let st = (await t.call('GET', '/api/billing/status', null, t.owner.accessToken)).body;
  assert.notEqual(st.subscription && st.subscription.plan, 'pro');
  const list = (await t.call('GET', '/api/operator/direct-pending', null, null, { 'x-operator-token': OP })).body.pending;
  assert.equal(list.length, 1); assert.equal(list[0].amountCrypto, inv.amountCrypto);
  const ok = await t.call('POST', '/api/operator/direct-confirm/' + inv.orderId, { txid: 'abc123' }, null, { 'x-operator-token': OP });
  assert.deepEqual(ok.body, { ok: true, applied: true });
  const again = await t.call('POST', '/api/operator/direct-confirm/' + inv.orderId, {}, null, { 'x-operator-token': OP });
  assert.equal(again.body.applied, false);
  st = (await t.call('GET', '/api/billing/status', null, t.owner.accessToken)).body;
  assert.equal(st.subscription.plan, 'pro');
  const mine = (await t.call('GET', '/api/billing/direct-invoices', null, t.owner.accessToken)).body.invoices;
  assert.equal(mine[0].status, 'paid');
  assert.equal((await t.call('GET', '/api/operator/direct-pending', null, null, { 'x-operator-token': OP })).body.pending.length, 0);
  assert.equal((await t.call('POST', '/api/operator/direct-confirm/nope', {}, null, { 'x-operator-token': OP })).status, 404);
  const audit = (await t.call('GET', '/api/audit?limit=50', null, t.owner.accessToken)).body;
  assert.ok(audit.chain.ok && audit.entries.some(e => e.action === 'subscription-paid'));
});

test('without direct config the endpoints are disabled', async (x) => {
  const t = await boot({ direct: null }); x.after(t.close);
  assert.equal((await t.call('POST', '/api/billing/direct-invoice', { plan: 'pro_monthly', currency: 'usdt' }, t.owner.accessToken)).status, 501);
  assert.equal((await t.call('POST', '/api/operator/direct-confirm/x', {}, null, { 'x-operator-token': OP })).status, 404);
});
