import test from 'node:test';
import assert from 'node:assert/strict';
import { runTask, analyzeProjectSnapshot } from '../src/ai-tasks.js';
import { LocalProvider } from '../src/ai-gateway.js';

test('project analysis produces conservative offline schedule and invoice signals', async () => {
  const snapshot = {
    projects: [{ id: 'p1', name: 'Villa', amount: 100000, status: 'active' }],
    schedule: [
      { id: 's1', name: 'Foundation', dueDate: '2020-01-01', status: 'open' },
      { id: 's2', name: 'Roof', dueDate: '2099-01-01', status: 'open' },
      { id: 's3', name: 'Done task', dueDate: '2020-01-01', status: 'done' }
    ],
    invoices: [{ id: 'i1', dueDate: '2020-01-01', status: 'sent' }],
    finance: [],
    inventory: []
  };
  const out = await runTask({ provider: new LocalProvider(), task: 'project_analysis', input: { lang: 'en' }, snapshot, role: 'owner' });
  assert.equal(out.provider, 'local');
  assert.equal(out.result.metrics.projects, 1);
  assert.equal(out.result.metrics.openTasks, 2);
  assert.equal(out.result.metrics.overdueTasks, 1);
  assert.equal(out.result.metrics.overdueInvoices, 1);
  assert.equal(out.result.overallRisk, 'medium');
  assert.ok(out.result.risks.some(r => r.title === 'Overdue schedule tasks'));
  assert.ok(out.result.dataGaps.some(x => x.includes('finance')));
});

test('project analysis enforces project and schedule read permissions', async () => {
  await assert.rejects(
    runTask({ provider: new LocalProvider(), task: 'project_analysis', input: {}, snapshot: {}, role: 'unknown' }),
    /Forbidden/
  );
});

test('project analysis accepts and sanitizes AI structured output', async () => {
  const provider = {
    name: 'fake',
    async complete({ prompt }) {
      assert.match(prompt, /Villa/);
      return JSON.stringify({
        summary: 'Review the overdue task.',
        overallRisk: 'high',
        metrics: { projects: 1, overdueTasks: 1, openTasks: 1, overdueInvoices: 0, lowStockItems: 0 },
        risks: [{ severity: 'high', title: 'Schedule delay', evidence: 'One task overdue', action: 'Assign owner' }],
        actions: ['Assign owner'],
        dataGaps: []
      });
    }
  };
  const out = await runTask({
    provider, task: 'project_analysis', input: { lang: 'en' },
    snapshot: { projects: [{ id: 'p1', name: 'Villa' }], schedule: [{ name: 'Foundation', status: 'open', dueDate: '2020-01-01' }] },
    role: 'owner'
  });
  assert.equal(out.result.overallRisk, 'high');
  assert.equal(out.result.risks[0].title, 'Schedule delay');
});
