import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { MemoryStore } from '../src/store-memory.js';

const PW = 'correct-horse-battery';
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
async function boot() {
  const store = new MemoryStore(), app = createApp({ store, config: { jwtSecret: 'x'.repeat(40) } });
  const server = http.createServer(app); await new Promise(r => server.listen(0, r)); const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (m, p, b, t) => { const r = await fetch(base + p, { method: m, headers: { 'content-type': 'application/json', ...(t ? { authorization: 'Bearer ' + t } : {}) }, body: b ? JSON.stringify(b) : undefined }); return { status: r.status, body: await r.json().catch(() => ({})) }; };
  const owner = (await call('POST', '/api/auth/register', { email: 'o@x.com', password: PW, orgName: 'A' })).body;
  const member = async (email, role) => { await call('POST', '/api/users', { email, password: PW, role }, owner.accessToken); return (await call('POST', '/api/auth/login', { email, password: PW })).body.accessToken; };
  return { call, owner, member, store, close: () => server.close() };
}
const good = { module: 'changeOrders', recordId: 'c1', title: 'CO-1', decision: 'approved', snapshot: '{"amount":500}', signerName: 'Jane Client', image: PNG };

test('sign, list, fetch image and verify', async () => {
  const s = await boot(); const t = s.owner.accessToken;
  const r = await s.call('POST', '/api/signatures', good, t); assert.equal(r.status, 201);
  assert.match(r.body.signature.docHash, /^[0-9a-f]{64}$/); assert.equal(r.body.signature.hasImage, true); assert.equal(r.body.signature.image, undefined);
  const l = await s.call('GET', '/api/signatures?module=changeOrders&recordId=c1', null, t); assert.equal(l.body.signatures.length, 1);
  const g = await s.call('GET', '/api/signatures/' + r.body.signature.id, null, t); assert.equal(g.body.signature.image, PNG);
  const v1 = await s.call('POST', `/api/signatures/${r.body.signature.id}/verify`, { snapshot: good.snapshot }, t); assert.equal(v1.body.valid, true);
  const v2 = await s.call('POST', `/api/signatures/${r.body.signature.id}/verify`, { snapshot: '{"amount":900}' }, t); assert.equal(v2.body.valid, false); assert.equal(v2.body.contentMatches, false);
  const audit = (await s.call('GET', '/api/audit', null, t)).body; assert.ok(JSON.stringify(audit).includes('sign-approved')); s.close();
});
test('tampering with the stored record is detected', async () => {
  const s = await boot(); const t = s.owner.accessToken;
  const r = await s.call('POST', '/api/signatures', good, t); const id = r.body.signature.id;
  [...s.store.sigs.values()][0].decision = 'rejected';
  const v = await s.call('POST', `/api/signatures/${id}/verify`, {}, t); assert.equal(v.body.recordIntact, false); assert.equal(v.body.valid, false); s.close();
});
test('validation: decision, name, snapshot, image, module', async () => {
  const s = await boot(); const t = s.owner.accessToken;
  for (const bad of [{ decision: 'maybe' }, { signerName: 'x' }, { snapshot: '' }, { image: 'data:image/svg+xml;base64,AAAA' }, { module: 'billing' }, { module: 'nope' }, { recordId: '' }])
    assert.equal((await s.call('POST', '/api/signatures', { ...good, ...bad }, t)).status, 400, JSON.stringify(bad));
  s.close();
});
test('RBAC: client may sign what it can read; worker cannot; unauthenticated rejected; cross-org hidden', async () => {
  const s = await boot(); const client = await s.member('c@x.com', 'client'), worker = await s.member('w@x.com', 'worker');
  assert.equal((await s.call('POST', '/api/signatures', good, client)).status, 201);
  assert.equal((await s.call('POST', '/api/signatures', good, worker)).status, 403);
  assert.equal((await s.call('POST', '/api/signatures', { ...good, module: 'smartDrawings' }, client)).status, 403);
  assert.equal((await s.call('POST', '/api/signatures', good)).status, 401);
  const o2 = (await s.call('POST', '/api/auth/register', { email: 'z@x.com', password: PW, orgName: 'B' })).body;
  const id = (await s.call('GET', '/api/signatures', null, s.owner.accessToken)).body.signatures[0].id;
  assert.equal((await s.call('GET', '/api/signatures/' + id, null, o2.accessToken)).status, 404); s.close();
});
