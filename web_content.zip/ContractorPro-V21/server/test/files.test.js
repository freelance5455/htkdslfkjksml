import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { createApp } from '../src/app.js';
import { MemoryStore } from '../src/store-memory.js';
import { MemoryBlobStore, DiskBlobStore, sniff } from '../src/blobstore.js';

const PW = 'correct-horse-battery', OP = 'q'.repeat(32);
const jpeg = (n = 200, seed = 1) => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(n, seed)]);
const png = () => Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(50, 7)]);
const pdf = () => Buffer.from('%PDF-1.4\n' + 'x'.repeat(100));

async function boot({ blobs = new MemoryBlobStore() } = {}) {
  const store = new MemoryStore(), app = createApp({ store, blobs, config: { jwtSecret: 'x'.repeat(40), operatorToken: OP } });
  const server = http.createServer(app); await new Promise(r => server.listen(0, r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, p, body, token, headers = {}) => { const r = await fetch(base + p, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined }); return { status: r.status, body: await r.json() }; };
  const up = async (token, buf, { name = 'photo.jpg', type = 'image/jpeg', module = '', recordId = '' } = {}) => { const r = await fetch(base + '/api/files', { method: 'POST', headers: { authorization: 'Bearer ' + token, 'content-type': type, 'x-file-name': encodeURIComponent(name), 'x-module': module, 'x-record-id': recordId }, body: buf }); return { status: r.status, body: await r.json() }; };
  const get = async (token, id) => { const r = await fetch(base + '/api/files/' + id, { headers: { authorization: 'Bearer ' + token } }); return { status: r.status, headers: r.headers, buf: Buffer.from(await r.arrayBuffer()) }; };
  const owner = (await call('POST', '/api/auth/register', { email: 'o@x.com', password: PW, orgName: 'Acme' })).body;
  const op = (m, p, b) => call(m, p, b, null, { 'x-operator-token': OP });
  const member = async (email, role) => { await call('POST', '/api/users', { email, password: PW, role }, owner.accessToken); return (await call('POST', '/api/auth/login', { email, password: PW })).body; };
  await op('PUT', '/api/operator/policy', { freeMonthlyUsd: 50, storageMb: { free: 5 } });
  return { store, call, up, get, owner, op, member, base, close: () => server.close() };
}

test('sniff accepts only real JPEG/PNG/WebP/PDF bytes', () => {
  assert.equal(sniff(jpeg()), 'image/jpeg'); assert.equal(sniff(png()), 'image/png'); assert.equal(sniff(pdf()), 'application/pdf');
  assert.equal(sniff(Buffer.concat([Buffer.from('RIFF'), Buffer.alloc(4), Buffer.from('WEBP'), Buffer.alloc(4)])), 'image/webp');
  assert.equal(sniff(Buffer.from('MZ' + 'x'.repeat(40))), null); assert.equal(sniff(Buffer.from('<script>alert(1)</script>')), null);
});

test('upload / list / download round trip with safe headers and metering', async (x) => {
  const t = await boot(); x.after(t.close);
  const buf = jpeg(5000), r = await t.up(t.owner.accessToken, buf, { name: 'crack ü.jpg', module: 'punchList', recordId: 'r1' });
  assert.equal(r.status, 201); assert.equal(r.body.file.size, buf.length); assert.equal(r.body.file.name, 'crack ü.jpg');
  const list = (await t.call('GET', '/api/files?module=punchList&recordId=r1', null, t.owner.accessToken)).body.files; assert.equal(list.length, 1);
  const g = await t.get(t.owner.accessToken, r.body.file.id);
  assert.equal(g.status, 200); assert.ok(g.buf.equals(buf)); assert.equal(g.headers.get('content-type'), 'image/jpeg'); assert.equal(g.headers.get('x-content-type-options'), 'nosniff'); assert.match(g.headers.get('content-security-policy'), /sandbox/);
  const u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body;
  assert.ok(u.byKind.storage > 0 && u.byKind.egress > 0, JSON.stringify(u.byKind)); assert.equal(u.storage.usedBytes, buf.length); assert.equal(u.storage.quotaBytes, 5 * 1048576);
});

test('rejects wrong types, mismatched claims, empty, oversized; dedupes identical uploads', async (x) => {
  const t = await boot(); x.after(t.close); const tok = t.owner.accessToken;
  assert.equal((await t.up(tok, Buffer.from('MZ' + 'x'.repeat(80)), { name: 'a.jpg', type: 'image/jpeg' })).status, 400);
  assert.equal((await t.up(tok, pdf(), { type: 'image/jpeg' })).status, 400, 'PDF bytes claimed as JPEG');
  assert.equal((await t.up(tok, Buffer.alloc(0))).status, 400);
  await t.op('PUT', '/api/operator/policy', { maxFileMb: 1 });
  assert.equal((await t.up(tok, jpeg(2 * 1048576))).status, 413);
  const a = await t.up(tok, png(), { type: 'image/png', module: 'dailyLogs', recordId: 'r' }), b = await t.up(tok, png(), { type: 'image/png', module: 'dailyLogs', recordId: 'r' });
  assert.equal(a.status, 201); assert.equal(b.status, 200); assert.equal(b.body.duplicate, true); assert.equal(b.body.file.id, a.body.file.id);
  assert.equal((await t.up(tok, png(), { type: 'image/png', module: 'dailyLogs', recordId: 'other' })).status, 201, 'same bytes on another record is a separate attachment');
});

test('plan storage quota is enforced; unused PDF type works', async (x) => {
  const t = await boot(); x.after(t.close); const tok = t.owner.accessToken;
  await t.op('PUT', '/api/operator/policy', { storageMb: { free: 0.0004 }, maxFileMb: 5 });    // ~419 bytes
  assert.equal((await t.up(tok, pdf(), { type: 'application/pdf' })).status, 201);
  assert.equal((await t.up(tok, jpeg(400, 9))).status, 413);
});

test('roles: module write rights apply to attachments; clients read only; org isolation; invalid ids', async (x) => {
  const t = await boot(); x.after(t.close);
  const worker = await t.member('w@x.com', 'worker'), client = await t.member('c@x.com', 'client'), acc = await t.member('a@x.com', 'accountant');
  assert.equal((await t.up(worker.accessToken, jpeg(100, 2), { module: 'dailyLogs', recordId: 'r' })).status, 201);
  assert.equal((await t.up(worker.accessToken, jpeg(100, 3), { module: 'finance', recordId: 'r' })).status, 403, 'worker cannot write finance');
  assert.equal((await t.up(client.accessToken, jpeg(100, 4), { module: 'dailyLogs' })).status, 403);
  const fin = await t.up(t.owner.accessToken, jpeg(100, 5), { module: 'finance', recordId: 'r' }); assert.equal(fin.status, 201);
  assert.equal((await t.get(client.accessToken, fin.body.file.id)).status, 404, 'client cannot read finance attachments');
  assert.equal((await t.get(acc.accessToken, fin.body.file.id)).status, 200);
  assert.equal((await t.call('GET', '/api/files?module=finance', null, client.accessToken)).status, 403);
  assert.ok(!(await t.call('GET', '/api/files', null, client.accessToken)).body.files.some(f => f.module === 'finance'));
  // other organization
  const o2 = (await t.call('POST', '/api/auth/register', { email: 'z@y.com', password: PW, orgName: 'Other' })).body;
  assert.equal((await t.get(o2.accessToken, fin.body.file.id)).status, 404);
  assert.equal((await t.call('DELETE', '/api/files/' + fin.body.file.id, null, o2.accessToken)).status, 404);
  assert.equal((await t.get(t.owner.accessToken, '../../etc/passwd')).status, 404);
  assert.equal((await t.call('POST', '/api/files', null, null)).status, 401);
  assert.equal((await t.up(t.owner.accessToken, jpeg(100, 6), { module: 'nonsense' })).status, 400);
});

test('delete: uploader or privileged role only; frees quota', async (x) => {
  const t = await boot(); x.after(t.close);
  const w1 = await t.member('w1@x.com', 'worker'), w2 = await t.member('w2@x.com', 'worker');
  const f = (await t.up(w1.accessToken, jpeg(300, 8), { module: 'dailyLogs', recordId: 'r' })).body.file;
  assert.equal((await t.call('DELETE', '/api/files/' + f.id, null, w2.accessToken)).status, 403);
  assert.equal((await t.call('DELETE', '/api/files/' + f.id, null, w1.accessToken)).status, 200);
  assert.equal((await t.get(t.owner.accessToken, f.id)).status, 404);
  assert.equal((await t.call('GET', '/api/usage', null, t.owner.accessToken)).body.storage.usedBytes, 0);
  const g = (await t.up(w1.accessToken, jpeg(300, 9), { module: 'dailyLogs', recordId: 'r' })).body.file;
  assert.equal((await t.call('DELETE', '/api/files/' + g.id, null, t.owner.accessToken)).status, 200);
});

test('cost cap: uploads stop when the budget is gone, downloads and listing keep working', async (x) => {
  const t = await boot(); x.after(t.close); const tok = t.owner.accessToken;
  const ok = await t.up(tok, jpeg(1000, 1)); assert.equal(ok.status, 201);
  await t.op('PUT', '/api/operator/policy', { freeMonthlyUsd: 0.1, storageUsdPerGb: 1000, maxFileMb: 5 });   // 1 MB would cost $1
  const big = await t.up(tok, jpeg(1048576, 2)); assert.equal(big.status, 402); assert.match(JSON.stringify(big.body), /Usage limit/);
  assert.equal((await t.get(tok, ok.body.file.id)).status, 200);
  assert.equal((await t.call('GET', '/api/files', null, tok)).status, 200);
});

test('DiskBlobStore persists bytes on disk and refuses path tricks', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cpblob-')), s = new DiskBlobStore(dir);
  const org = '11111111-1111-1111-1111-111111111111', id = '22222222-2222-2222-2222-222222222222';
  await s.put(org, id, Buffer.from('hello')); assert.equal((await s.get(org, id)).toString(), 'hello');
  assert.ok(fs.existsSync(path.join(dir, org, id)));
  await assert.rejects(s.get(org, '../../x'), /bad id/); await assert.rejects(s.put('..', id, Buffer.from('x')), /bad id/);
  await s.del(org, id); await assert.rejects(s.get(org, id));
  fs.rmSync(dir, { recursive: true, force: true });
});
