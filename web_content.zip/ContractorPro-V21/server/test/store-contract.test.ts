// The same behavioural contract is run against MemoryStore (always) and PgStore (when TEST_DATABASE_URL points at an EMPTY, migrated test database).
//   createdb cp_test && DATABASE_URL=postgres://localhost/cp_test npm run migrate && TEST_DATABASE_URL=postgres://localhost/cp_test npm test
import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { MemoryStore } from '../src/store-memory.js';

type Maker = { name: string; make: () => Promise<any>; done?: () => Promise<void> };
const makers: Maker[] = [{ name: 'MemoryStore', make: async () => new MemoryStore() }];
let pool: any;
if (process.env.TEST_DATABASE_URL) {
  const { PgStore } = await import('../src/store-pg.js');
  makers.push({ name: 'PgStore', make: async () => { const s = await PgStore.connect(process.env.TEST_DATABASE_URL); pool = s.pool; return s; }, done: async () => { await pool?.end(); } });
}

for (const m of makers) {
  test(`[${m.name}] export, push, notified, integrations and erasure behave identically`, async (t) => {
    const s = await m.make(); t.after(async () => { await m.done?.(); });
    const tag = randomUUID().slice(0, 8);
    const mk = async (email: string, orgName: string) => s.createOrgWithOwner({ orgName, email: `${tag}-${email}`, passwordHash: 'h' });
    const A = await mk('a@x.com', 'Org A'), B = await mk('b@x.com', 'Org B');
    const member = await s.createUser({ email: `${tag}-m@x.com`, passwordHash: 'h' }); await s.addMember({ orgId: A.org.id, userId: member.id, role: 'worker' });
    const put = (orgId: string, module: string, id: string) => s.applyChange(orgId, { module, id, data: { id, name: id }, updatedAt: '2026-10-01T00:00:00Z', baseVersion: 0 });
    await put(A.org.id, 'projects', 'p1'); await put(A.org.id, 'invoices', 'i1'); await put(B.org.id, 'projects', 'pb');
    const fid = randomUUID(); await s.addFile({ id: fid, orgId: A.org.id, uploadedBy: A.user.id, name: 'a.jpg', mime: 'image/jpeg', size: 3, sha256: 'ab', module: 'projects', recordId: 'p1' });
    for (const [o, u] of [[A.org.id, A.user.id], [A.org.id, member.id], [B.org.id, B.user.id]] as const) await s.appendAudit(o, { at: new Date().toISOString(), userId: u, role: 'x', action: 'test', module: 'projects', recordId: 'p1', details: '', ip: '' });
    await s.pushSnapshot(A.org.id, 'dev', { projects: [] });

    // read side used by the export
    assert.equal((await s.getOrg(A.org.id)).name, 'Org A'); assert.equal((await s.listAllRecords(A.org.id)).length, 2); assert.equal((await s.allFiles(A.org.id)).length, 1);
    assert.equal((await s.allAudit(A.org.id)).length, 2); assert.equal((await s.listMembers(A.org.id)).length, 2);

    // push subscriptions and alert de-duplication
    const sub = { endpoint: `https://push.example/${tag}`, keys: { p256dh: 'k', auth: 'a' } };
    await s.savePushSub(A.org.id, member.id, sub); await s.savePushSub(A.org.id, member.id, { ...sub, keys: { p256dh: 'k2', auth: 'a2' } });      // upsert
    assert.deepEqual((await s.listPushSubs(A.org.id, member.id)).map((x: any) => x.keys.p256dh), ['k2']); assert.equal((await s.listPushSubs(A.org.id, A.user.id)).length, 0);
    assert.equal(await s.markNotified(A.org.id, 'k1'), true); assert.equal(await s.markNotified(A.org.id, 'k1'), false); assert.equal(await s.markNotified(B.org.id, 'k1'), true);

    // integrations: sealed tokens, mapping upsert, disconnect clears mappings
    const row = { orgId: A.org.id, provider: 'xero', tokensEnc: 'v1.a.b.c', realm: 'T', connectedBy: A.user.id, connectedAt: new Date().toISOString(), lastSyncAt: null };
    await s.saveIntegration(row); assert.equal((await s.getIntegration(A.org.id, 'xero')).tokensEnc, 'v1.a.b.c'); assert.equal(await s.getIntegration(B.org.id, 'xero'), null);
    await s.saveMapping(A.org.id, 'xero', 'invoices', 'i1', { externalId: 'X1', hash: 'h1' }); await s.saveMapping(A.org.id, 'xero', 'invoices', 'i1', { externalId: 'X1', hash: 'h2' });
    assert.deepEqual(await s.getMapping(A.org.id, 'xero', 'invoices', 'i1'), { externalId: 'X1', hash: 'h2' });
    await s.saveIntegration({ ...row, lastSyncAt: new Date().toISOString() }); assert.ok((await s.getIntegration(A.org.id, 'xero')).lastSyncAt);
    await s.deleteIntegration(A.org.id, 'xero'); assert.equal(await s.getIntegration(A.org.id, 'xero'), null); assert.equal(await s.getMapping(A.org.id, 'xero', 'invoices', 'i1'), null);
    await s.saveIntegration(row); await s.saveMapping(A.org.id, 'xero', 'invoices', 'i1', { externalId: 'X1', hash: 'h1' });
    await s.setSetting('notify:' + member.id, { email: false });

    // erasure rules
    assert.equal(await s.deleteUserOnly(A.org.id, A.user.id), false, 'the owner cannot be removed by the member path');
    assert.equal(await s.deleteUserOnly(B.org.id, member.id), false, 'a user cannot be removed through another workspace');
    assert.equal(await s.deleteUserOnly(A.org.id, member.id), true); assert.equal(await s.getUserById(member.id), null);
    assert.equal((await s.listPushSubs(A.org.id, member.id)).length, 0); assert.equal(await s.getSetting('notify:' + member.id), null);
    assert.equal((await s.listMembers(A.org.id)).length, 1);

    // the whole workspace goes (this is the path that must get past the append-only audit trigger on PostgreSQL)
    const r = await s.deleteOrgCascade(A.org.id); assert.equal(r.users, 1);
    assert.equal(await s.getOrg(A.org.id), null); assert.equal(await s.getUserById(A.user.id), null);
    for (const f of ['listAllRecords', 'allFiles', 'allAudit']) assert.equal((await s[f](A.org.id)).length, 0, f);
    assert.equal(await s.getIntegration(A.org.id, 'xero'), null); assert.equal(await s.latestSnapshot(A.org.id), null);
    assert.equal(await s.markNotified(A.org.id, 'k1'), true, 'alert keys are gone with the workspace');
    // the other workspace is untouched, and its audit trail is still intact
    assert.equal((await s.getOrg(B.org.id)).name, 'Org B'); assert.equal((await s.listAllRecords(B.org.id)).length, 1); assert.equal((await s.allAudit(B.org.id)).length, 1);
    assert.equal((await s.getIntegration(B.org.id, 'xero')), null); assert.equal(await s.markNotified(B.org.id, 'k1'), false);
    await s.deleteOrgCascade(B.org.id);
  });
}

if (process.env.TEST_DATABASE_URL) {
  test('[PgStore] audit_log stays append-only: UPDATE and plain DELETE are rejected', async () => {
    const { PgStore } = await import('../src/store-pg.js'); const s = await PgStore.connect(process.env.TEST_DATABASE_URL);
    try {
      const A = await s.createOrgWithOwner({ orgName: 'Audit', email: `${randomUUID()}@x.com`, passwordHash: 'h' });
      await s.appendAudit(A.org.id, { at: new Date().toISOString(), userId: A.user.id, role: 'owner', action: 'a', module: 'm', recordId: '', details: '', ip: '' });
      await assert.rejects(s.q('UPDATE audit_log SET action=$2 WHERE org_id=$1', [A.org.id, 'x']), /append-only/);
      await assert.rejects(s.q('DELETE FROM audit_log WHERE org_id=$1', [A.org.id]), /append-only/);
      await assert.rejects(s.q("SELECT set_config('cp.purge_org', $1, false)", [randomUUID()]).then(() => s.q('DELETE FROM audit_log WHERE org_id=$1', [A.org.id])), /append-only/, 'a different organization id in the setting must not unlock deletion');
      await s.deleteOrgCascade(A.org.id);
    } finally { await s.pool.end(); }
  });
}
