import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { randomUUID } from 'node:crypto';
import { createApp } from '../src/app.js';
import { MemoryStore } from '../src/store-memory.js';
import { MemoryBlobStore } from '../src/blobstore.js';
import { can } from '../src/rbac.js';
import { Notifier, collectAlerts } from '../src/notifier.ts';
import type { Mail } from '../src/smtp.ts';

const PW = 'correct-horse-battery', OP = 'o'.repeat(32);
const UA = { p256dh: 'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4', auth: 'BTBZMqHH6r4Tts7J_aSIgg' };

async function boot() {
  const store = new MemoryStore() as any, blobs = new MemoryBlobStore(), mails: Mail[] = [], pushes: Array<{ endpoint: string; msg: any }> = []; let otp = '';
  const mailer = { mode: 'test', async send(_e: string, c: string) { otp = c; }, async sendMail(m: Mail) { mails.push(m); } };
  const push = { async send(s: any, msg: any) { pushes.push({ endpoint: s.endpoint, msg }); return s.endpoint.includes('gone') ? { ok: false as const, gone: true, status: 410 } : { ok: true as const }; } };
  const today = '2026-10-13';
  const notifier = new Notifier({ store, mailer, push, canRead: (r, m) => can(r, 'read', m), now: () => new Date(today + 'T08:00:00Z'), appName: 'CP' });
  const app = createApp({ store, blobs, mailer, notifier, pushPublicKey: UA.p256dh, config: { jwtSecret: 'x'.repeat(40), operatorToken: OP } });
  const server = http.createServer(app); await new Promise<void>(r => server.listen(0, r));
  const base = `http://127.0.0.1:${(server.address() as any).port}`;
  const call = async (method: string, path: string, body?: unknown, token?: string, headers: Record<string, string> = {}) => {
    const r = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
    const text = await r.text(); let json: any = null; try { json = JSON.parse(text); } catch { /* not json */ }
    return { status: r.status, body: json, text, headers: r.headers };
  };
  return { store, blobs, mails, pushes, call, otp: () => otp, close: () => server.close() };
}
type T = Awaited<ReturnType<typeof boot>>;
async function setup(t: T) {
  const o = (await t.call('POST', '/api/auth/register', { email: 'owner@x.com', password: PW, orgName: 'Acme' })).body;
  const mk = async (email: string, role: string) => { assert.equal((await t.call('POST', '/api/users', { email, password: PW, role }, o.accessToken)).status, 201); return (await t.call('POST', '/api/auth/login', { email, password: PW })).body; };
  return { o, acc: await mk('acc@x.com', 'accountant'), wk: await mk('wk@x.com', 'worker'), orgId: o.user.workspaceId as string };
}
const put = (t: T, orgId: string, module: string, id: string, data: object) => t.store.applyChange(orgId, { module, id, data: { id, ...data }, updatedAt: '2026-10-01T00:00:00Z', baseVersion: 0 });

test('export: owner gets the workspace, members only their own data, and no secrets ever', async (x) => {
  const t = await boot(); x.after(t.close); const { o, wk, orgId } = await setup(t);
  await put(t, orgId, 'projects', 'p1', { name: 'Villa' });
  assert.equal((await t.call('GET', '/api/account/export')).status, 401);
  const r = await t.call('GET', '/api/account/export', undefined, o.accessToken);
  assert.equal(r.status, 200); assert.match(r.headers.get('content-disposition')!, /attachment; filename="contractor-pro-export-\d{4}-\d{2}-\d{2}\.json"/);
  assert.equal(r.body.scope, 'workspace'); assert.equal(r.body.records.length, 1); assert.equal(r.body.members.length, 3);
  assert.ok(r.body.auditLog.length >= 3);
  for (const bad of ['scrypt$', 'passwordHash', 'refreshToken', 'codeHash', o.accessToken]) assert.ok(!r.text.includes(bad), 'leaked ' + bad);
  const m = await t.call('GET', '/api/account/export', undefined, wk.accessToken);
  assert.equal(m.body.scope, 'personal'); assert.equal(m.body.records, undefined); assert.equal(m.body.members, undefined); assert.equal(m.body.account.email, 'wk@x.com');
  assert.ok(m.body.activityLog.every((a: any) => a.action));
});

test('erase workspace: needs confirm phrase, password and explicit workspace flag; then everything is really gone', async (x) => {
  const t = await boot(); x.after(t.close); const { o, acc, orgId } = await setup(t);
  await put(t, orgId, 'projects', 'p1', { name: 'Villa' });
  const fid = randomUUID(); await t.blobs.put(orgId, fid, Buffer.from('photo')); await t.store.addFile({ id: fid, orgId, uploadedBy: o.user.id, name: 'a.jpg', mime: 'image/jpeg', size: 5, sha256: 'ab', module: 'projects', recordId: 'p1' });
  await t.store.pushSnapshot(orgId, 'dev', { projects: [] }); await t.store.setSetting('notify:' + o.user.id, { email: false });
  const del = (b: object, tok = o.accessToken) => t.call('POST', '/api/account/delete', b, tok);
  assert.equal((await del({ password: PW, workspace: true })).status, 400);
  assert.equal((await del({ confirm: 'delete my account', password: PW, workspace: true })).status, 400);
  assert.equal((await del({ confirm: 'DELETE MY ACCOUNT', password: 'wrong-password-123', workspace: true })).status, 401);
  assert.equal((await del({ confirm: 'DELETE MY ACCOUNT', password: PW })).status, 400);           // owner must acknowledge the workspace scope
  assert.equal((await del({ confirm: 'DELETE MY ACCOUNT', password: PW, workspace: true }, 'bad.token.here')).status, 401);
  assert.equal(t.store.orgs.size, 1);                                                               // nothing was erased by the failed attempts
  const ok = await del({ confirm: 'DELETE MY ACCOUNT', password: PW, workspace: true });
  assert.equal(ok.status, 200); assert.deepEqual(ok.body.erased, { scope: 'workspace', users: 3, files: 1 });
  const s = t.store; assert.deepEqual([s.orgs.size, s.users.size, s.members.size, s.recs.size, s.snaps.length, s.audits.length, s.filesMeta.size, s.subs.size, s.refresh.size, s.sigs.size, s.payments.size], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
  assert.equal(s.settings.has('notify:' + o.user.id), false);
  await assert.rejects(t.blobs.get(orgId, fid)); assert.equal((await t.call('GET', '/api/auth/me', undefined, o.accessToken)).status, 401);
  assert.equal((await t.call('GET', '/api/auth/me', undefined, acc.accessToken)).status, 401);
  assert.equal((await t.call('POST', '/api/auth/login', { email: 'owner@x.com', password: PW })).status, 401);
  assert.equal(t.mails.at(-1)!.to, 'owner@x.com'); assert.match(t.mails.at(-1)!.text, /permanently erased/);
  // the e-mail address is free again
  assert.equal((await t.call('POST', '/api/auth/register', { email: 'owner@x.com', password: PW })).status, 201);
});

test('erase as a member removes only that login; the workspace and its data stay', async (x) => {
  const t = await boot(); x.after(t.close); const { o, wk, orgId } = await setup(t);
  await put(t, orgId, 'projects', 'p1', { name: 'Villa' });
  await t.call('POST', '/api/push/subscribe', { subscription: { endpoint: 'https://push.example/wk', keys: UA } }, wk.accessToken);
  const r = await t.call('POST', '/api/account/delete', { confirm: 'DELETE MY ACCOUNT', password: PW }, wk.accessToken);
  assert.equal(r.status, 200); assert.deepEqual(r.body.erased, { scope: 'account', users: 1, files: 0 });
  assert.equal((await t.call('POST', '/api/auth/login', { email: 'wk@x.com', password: PW })).status, 401);
  assert.equal((await t.call('GET', '/api/auth/me', undefined, o.accessToken)).status, 200);
  assert.equal((await t.store.listAllRecords(orgId)).length, 1); assert.equal(t.store.pushSubs.size, 0);
  assert.equal((await t.call('GET', '/api/account/export', undefined, o.accessToken)).body.members.length, 2);
});

test('erase for an OTP-only account requires a fresh e-mail code', async (x) => {
  const t = await boot(); x.after(t.close);
  await t.call('POST', '/api/auth/request-otp', { email: 'otp@x.com' }); const login = await t.call('POST', '/api/auth/verify-otp', { email: 'otp@x.com', code: t.otp() });
  const tok = login.body.accessToken, b = { confirm: 'DELETE MY ACCOUNT', workspace: true };
  assert.equal((await t.call('POST', '/api/account/delete', { ...b, code: '000000' }, tok)).status, 401);
  await t.call('POST', '/api/auth/request-otp', { email: 'otp@x.com' });
  assert.equal((await t.call('POST', '/api/account/delete', { ...b, code: t.otp() }, tok)).status, 200);
  assert.equal(t.store.users.size, 0);
});

test('push subscription validation, preferences, and operator-only digest', async (x) => {
  const t = await boot(); x.after(t.close); const { o } = await setup(t);
  const sub = (s: object) => t.call('POST', '/api/push/subscribe', { subscription: s }, o.accessToken);
  assert.equal((await t.call('GET', '/api/push/key', undefined, o.accessToken)).body.publicKey, UA.p256dh);
  assert.equal((await sub({ endpoint: 'http://insecure.example/x', keys: UA })).status, 400);
  assert.equal((await sub({ endpoint: 'https://p.example/x', keys: { p256dh: 'AAAA', auth: UA.auth } })).status, 400);
  assert.equal((await sub({ endpoint: 'https://p.example/x', keys: { p256dh: UA.p256dh, auth: 'AAAA' } })).status, 400);
  assert.equal((await sub({ endpoint: 'https://p.example/x', keys: UA })).status, 201); assert.equal(t.store.pushSubs.size, 1);
  assert.equal((await t.call('POST', '/api/push/unsubscribe', { endpoint: 'https://p.example/x' }, o.accessToken)).status, 200); assert.equal(t.store.pushSubs.size, 0);
  assert.deepEqual((await t.call('GET', '/api/notifications/prefs', undefined, o.accessToken)).body, { email: true, push: true });
  assert.deepEqual((await t.call('PUT', '/api/notifications/prefs', { email: false }, o.accessToken)).body, { email: false, push: true });
  assert.equal((await t.call('POST', '/api/operator/digest')).status, 401);
  assert.equal((await t.call('POST', '/api/operator/digest', undefined, undefined, { 'x-operator-token': 'wrong'.repeat(8) })).status, 401);
  assert.equal((await t.call('POST', '/api/operator/digest', undefined, undefined, { 'x-operator-token': OP })).status, 200);
});

test('digest: role-aware recipients, each alert sent once, opt-out and dead push endpoints handled', async (x) => {
  const t = await boot(); x.after(t.close); const { o, acc, wk, orgId } = await setup(t);
  await put(t, orgId, 'invoices', 'i1', { name: 'INV-1', status: 'sent', dueDate: '2026-10-01' });
  await put(t, orgId, 'punchList', 'k1', { name: 'Crack', status: 'Open', dueDate: '2026-10-05' });
  await put(t, orgId, 'safetyForms', 's1', { name: 'Fall near-miss', formType: 'Incident / near miss', severity: 'Critical', status: 'Open', date: '2026-10-12' });
  await put(t, orgId, 'invoices', 'i2', { name: 'PAID', status: 'paid', dueDate: '2026-09-01' });
  await t.call('POST', '/api/push/subscribe', { subscription: { endpoint: 'https://push.example/gone', keys: UA } }, acc.accessToken);
  await t.call('POST', '/api/push/subscribe', { subscription: { endpoint: 'https://push.example/ok', keys: UA } }, wk.accessToken);
  await t.call('PUT', '/api/notifications/prefs', { email: false }, o.accessToken);
  const run = async () => (await t.call('POST', '/api/operator/digest', undefined, undefined, { 'x-operator-token': OP })).body;
  const r1 = await run(); assert.equal(r1.newAlerts, 3);
  const byTo = Object.fromEntries(t.mails.filter(m => m.subject.includes('alert')).map(m => [m.to, m.text]));
  assert.ok(!('owner@x.com' in byTo), 'owner opted out of e-mail');
  assert.match(byTo['acc@x.com']!, /Invoice overdue: INV-1/); assert.doesNotMatch(byTo['acc@x.com']!, /Crack|incident/i);   // accountant: invoices only
  assert.match(byTo['wk@x.com']!, /Punch item overdue: Crack/); assert.match(byTo['wk@x.com']!, /Critical incident open/); assert.doesNotMatch(byTo['wk@x.com']!, /INV-1/);
  assert.equal(t.pushes.length, 2); assert.equal(t.store.pushSubs.size, 1, 'gone (410) endpoint removed'); assert.ok(t.store.pushSubs.has('https://push.example/ok'));
  const sent = t.mails.length, r2 = await run(); assert.equal(r2.newAlerts, 0); assert.equal(t.mails.length, sent);            // idempotent
  await put(t, orgId, 'invoices', 'i3', { name: 'INV-3', status: 'overdue', dueDate: '2026-10-10' });
  assert.equal((await run()).newAlerts, 1);
});

test('alert rules: safety actions and tender deadlines', () => {
  const R = (module: string, id: string, data: object) => ({ module, id, data: data as any });
  const a = collectAlerts([
    R('safetyForms', 'a', { name: 'Scaffold', status: 'Action required', actionDueDate: '2026-10-12' }),
    R('safetyForms', 'b', { name: 'Closed', status: 'Closed', actionDueDate: '2026-10-01' }),
    R('safetyForms', 'c', { name: 'Minor', formType: 'Incident / near miss', severity: 'Low', status: 'Open' }),
    R('tenders', 't1', { name: 'Hospital', status: 'Preparing', submissionDeadline: '2026-10-15T10:00' }),
    R('tenders', 't2', { name: 'Far', status: 'Preparing', submissionDeadline: '2026-10-20' }),
    R('tenders', 't3', { name: 'Missed', status: 'Identified', submissionDeadline: '2026-10-10' }),
    R('tenders', 't4', { name: 'Sent', status: 'Submitted', submissionDeadline: '2026-10-10' }),
    { module: 'rfis', id: 'r', data: { name: 'Gone', status: 'Open', dueDate: '2026-01-01' }, deleted: true },
    R('inventory', 'n1', { name: 'Cement', quantity: 2, minStock: 5 })
  ], '2026-10-13').map(x => x.title).sort();
  assert.deepEqual(a, ['Low stock: Cement', 'Safety action overdue: Scaffold', 'Tender deadline missed: Missed', 'Tender due soon: Hospital']);
});
