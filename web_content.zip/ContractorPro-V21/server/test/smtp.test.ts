import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import tls from 'node:tls';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { SmtpMailer, sendSmtp, buildMessage, bareAddress } from '../src/smtp.ts';

// A tiny but strict SMTP server: records what a real client sends.
interface Got { from: string; rcpt: string[]; data: string; auth: string; tlsUsed: boolean }
function fakeServer(opts: { implicitTls?: { key: string; cert: string }; starttls?: { key: string; cert: string }; failFirstData?: number; rejectRcpt?: boolean; bind?: string } = {}) {
  const sessions: Got[] = []; let datas = 0;
  const handle = (sock: net.Socket) => {
    let buf = '', inData = false, dataBuf = '', cur: Got = { from: '', rcpt: [], data: '', auth: '', tlsUsed: sock instanceof tls.TLSSocket };
    let s: net.Socket = sock;
    const send = (l: string) => s.write(l + '\r\n');
    const onData = (d: Buffer) => {
      buf += d.toString('utf8');
      for (;;) {
        if (inData) { const i = buf.indexOf('\r\n.\r\n'); if (i < 0) return; dataBuf = buf.slice(0, i); buf = buf.slice(i + 5); inData = false; datas++;
          if (opts.failFirstData && datas <= opts.failFirstData) { send('451 try later'); continue; } cur.data = dataBuf; sessions.push({ ...cur }); send('250 queued'); continue; }
        const i = buf.indexOf('\r\n'); if (i < 0) return; const line = buf.slice(0, i); buf = buf.slice(i + 2);
        if (/^EHLO/i.test(line)) { const ex = ['250-fake', '250-AUTH PLAIN LOGIN']; if (opts.starttls && !(s instanceof tls.TLSSocket)) ex.push('250-STARTTLS'); ex.push('250 8BITMIME'); ex.forEach(send); }
        else if (/^STARTTLS/i.test(line)) { send('220 go'); const t = new tls.TLSSocket(s, { isServer: true, key: opts.starttls!.key, cert: opts.starttls!.cert }); s.removeAllListeners('data'); s = t; cur.tlsUsed = true; t.on('data', onData); t.on('error', () => {}); }
        else if (/^AUTH PLAIN /i.test(line)) { cur.auth = Buffer.from(line.slice(11), 'base64').toString(); send('235 ok'); }
        else if (/^MAIL FROM:/i.test(line)) { cur.from = /<(.*)>/.exec(line)![1]; send('250 ok'); }
        else if (/^RCPT TO:/i.test(line)) { if (opts.rejectRcpt) send('550 no such user'); else { cur.rcpt.push(/<(.*)>/.exec(line)![1]); send('250 ok'); } }
        else if (/^DATA/i.test(line)) { send('354 go'); inData = true; }
        else if (/^QUIT/i.test(line)) { send('221 bye'); s.end(); return; }
        else send('500 what');
      }
    };
    sock.on('data', onData); sock.on('error', () => {}); send('220 fake ESMTP');
  };
  const server = opts.implicitTls ? tls.createServer({ key: opts.implicitTls.key, cert: opts.implicitTls.cert }, handle) : net.createServer(handle);
  return new Promise<{ port: number; sessions: Got[]; close: () => void }>(res => server.listen(0, opts.bind ?? '127.0.0.1', () => res({ port: (server.address() as net.AddressInfo).port, sessions, close: () => server.close() })));
}
function selfSigned() {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'cp-tls-'));
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', d + '/k.pem', '-out', d + '/c.pem', '-subj', '/CN=localhost', '-days', '2'], { stdio: 'ignore' });
  return { key: fs.readFileSync(d + '/k.pem', 'utf8'), cert: fs.readFileSync(d + '/c.pem', 'utf8') };
}
const decodeBody = (raw: string) => { // returns the decoded text/plain and text/html parts
  const [head, ...rest] = raw.split('\r\n\r\n'); const body = rest.join('\r\n\r\n');
  const parts = /boundary="([^"]+)"/.exec(head) ? body.split(/--cp_[0-9a-f]+(?:--)?\r\n?/).filter(p => p.trim()) : [body];
  return parts.map(p => { const b = p.split('\r\n\r\n').slice(-1)[0].replace(/\r\n--cp_.*$/s, ''); return Buffer.from(b.replace(/\s+/g, ''), 'base64').toString('utf8'); });
};
const CFG = { from: 'Contractor Pro <noreply@example.com>', timeoutMs: 3000 };

test('plain SMTP with AUTH PLAIN delivers a UTF-8 (Persian) message correctly', async (t) => {
  const srv = await fakeServer(); t.after(srv.close);
  await sendSmtp({ ...CFG, host: '127.0.0.1', port: srv.port, starttls: false, user: 'u', pass: 'p' }, { to: ['a@x.com', 'b@y.org'], subject: 'هشدار فاکتور', text: 'فاکتور شما سررسید شده است.\n.leading dot line\n', html: '<p>سلام</p>' });
  const g = srv.sessions[0]!;
  assert.equal(g.from, 'noreply@example.com'); assert.deepEqual(g.rcpt, ['a@x.com', 'b@y.org']); assert.equal(g.auth, '\0u\0p');
  assert.match(g.data, /^Subject: =\?UTF-8\?B\?/m); assert.match(g.data, /^From: Contractor Pro <noreply@example\.com>/m);
  const [txt, html] = decodeBody(g.data); assert.equal(txt, 'فاکتور شما سررسید شده است.\n.leading dot line\n'); assert.equal(html, '<p>سلام</p>');
  const subj = /^Subject: =\?UTF-8\?B\?([^?]+)\?=/m.exec(g.data)![1]!; assert.equal(Buffer.from(subj, 'base64').toString(), 'هشدار فاکتور');
});

test('header injection and bad addresses are refused before anything is sent', async () => {
  assert.throws(() => buildMessage(CFG, { to: 'a@x.com', subject: 'hi\r\nBcc: evil@x.com', text: 't' }), /illegal characters/);
  assert.throws(() => buildMessage(CFG, { to: 'a@x.com\r\nRCPT TO:<evil@x.com>', subject: 's', text: 't' }), /illegal|invalid/);
  assert.throws(() => bareAddress('not-an-email'), /invalid email/);
  assert.throws(() => bareAddress('a b@x.com'), /invalid email/);
  assert.throws(() => buildMessage({ from: 'x@y.com' }, { to: [], subject: 's', text: 't' }), /no recipients/);
});

test('STARTTLS upgrade happens before credentials are sent', async (t) => {
  const c = selfSigned(), srv = await fakeServer({ starttls: c }); t.after(srv.close);
  await sendSmtp({ ...CFG, host: '127.0.0.1', port: srv.port, user: 'u', pass: 'secret', rejectUnauthorized: false }, { to: 'a@x.com', subject: 's', text: 'hello' });
  assert.equal(srv.sessions[0]!.tlsUsed, true); assert.equal(srv.sessions[0]!.auth, '\0u\0secret');
});

test('implicit TLS (port 465 style) works and certificates are verified by default', async (t) => {
  const c = selfSigned(), srv = await fakeServer({ implicitTls: c }); t.after(srv.close);
  await assert.rejects(sendSmtp({ ...CFG, host: '127.0.0.1', port: srv.port, secure: true }, { to: 'a@x.com', subject: 's', text: 'x' }), /self.signed|certificate|altnames|Hostname/i);
  await sendSmtp({ ...CFG, host: '127.0.0.1', port: srv.port, secure: true, rejectUnauthorized: false }, { to: 'a@x.com', subject: 's', text: 'x' });
  assert.equal(srv.sessions.length, 1); assert.equal(srv.sessions[0]!.tlsUsed, true);
});

test('credentials are never sent over an unencrypted non-local connection', async (t) => {
  const srv = await fakeServer({ bind: '127.0.0.2' }); t.after(srv.close);
  await assert.rejects(sendSmtp({ ...CFG, host: '127.0.0.2', port: srv.port, starttls: false, user: 'u', pass: 'p' }, { to: 'a@x.com', subject: 's', text: 'x' }), /refusing to send credentials/);
  assert.equal(srv.sessions.length, 0);
});

test('mailer retries a transient 4xx and succeeds; a 5xx recipient rejection is not retried', async (t) => {
  const srv = await fakeServer({ failFirstData: 2 }); t.after(srv.close);
  const m = new SmtpMailer({ ...CFG, host: '127.0.0.1', port: srv.port, starttls: false }, 3, async () => {});
  await m.sendMail({ to: 'a@x.com', subject: 's', text: 'x' }); assert.equal(srv.sessions.length, 1);
  const bad = await fakeServer({ rejectRcpt: true }); t.after(bad.close);
  let tries = 0; const m2 = new SmtpMailer({ ...CFG, host: '127.0.0.1', port: bad.port, starttls: false }, 3, async () => { tries++; });
  await assert.rejects(m2.sendMail({ to: 'a@x.com', subject: 's', text: 'x' }), /SMTP 550/); assert.equal(tries, 0);
});

test('OTP mail carries the code; connection failure and timeout surface as errors', async (t) => {
  const srv = await fakeServer(); t.after(srv.close);
  await new SmtpMailer({ ...CFG, host: '127.0.0.1', port: srv.port, starttls: false }, 0).send('a@x.com', '123456');
  assert.ok(decodeBody(srv.sessions[0]!.data).some(p => p.includes('123456')));
  await assert.rejects(sendSmtp({ ...CFG, host: '127.0.0.1', port: 1, starttls: false }, { to: 'a@x.com', subject: 's', text: 'x' }));
  const silent = net.createServer(() => {}); await new Promise<void>(r => silent.listen(0, '127.0.0.1', r)); t.after(() => silent.close());
  await assert.rejects(sendSmtp({ ...CFG, timeoutMs: 300, host: '127.0.0.1', port: (silent.address() as net.AddressInfo).port, starttls: false }, { to: 'a@x.com', subject: 's', text: 'x' }), /timeout/i);
});
