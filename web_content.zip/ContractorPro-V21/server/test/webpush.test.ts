import test from 'node:test';
import assert from 'node:assert/strict';
import { createECDH, createPublicKey, createVerify } from 'node:crypto';
import { encryptPayload, generateVapidKeys, vapidAuthHeader, WebPush } from '../src/webpush.ts';

const b = (s: string) => Buffer.from(s, 'base64url');
const UA = { p256dh: 'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4', auth: 'BTBZMqHH6r4Tts7J_aSIgg' };

test('payload encryption reproduces the RFC 8291 Appendix A test vector byte for byte', () => {
  const as = createECDH('prime256v1'); as.setPrivateKey(b('yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw'));
  const out = encryptPayload({ endpoint: 'https://push.example/x', keys: UA }, Buffer.from('When I grow up, I want to be a watermelon'), { salt: b('DGv6ra1nlYgDCS1FRnbzlw'), ephemeral: as });
  assert.equal(out.toString('base64url'),
    'DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN');
});

test('encryption uses fresh salt/key every time and rejects malformed subscriptions or oversize payloads', () => {
  const sub = { endpoint: 'https://push.example/x', keys: UA };
  assert.notEqual(encryptPayload(sub, Buffer.from('a')).toString('hex'), encryptPayload(sub, Buffer.from('a')).toString('hex'));
  assert.throws(() => encryptPayload({ ...sub, keys: { ...UA, auth: 'AAAA' } }, Buffer.from('a')), /auth/);
  assert.throws(() => encryptPayload({ ...sub, keys: { ...UA, p256dh: 'AAAA' } }, Buffer.from('a')), /p256dh/);
  assert.throws(() => encryptPayload(sub, Buffer.alloc(4000)), /too large/);
  assert.equal(encryptPayload(sub, Buffer.alloc(3993)).length, 16 + 4 + 1 + 65 + 3993 + 1 + 16);
});

test('VAPID JWT is a valid ES256 signature over the right audience, expiry and subject', () => {
  const v = generateVapidKeys('mailto:ops@example.com'), now = 1_800_000_000;
  const h = vapidAuthHeader(v, 'https://fcm.googleapis.com/fcm/send/abc', now);
  const m = /^vapid t=([\w-]+)\.([\w-]+)\.([\w-]+), k=([\w-]+)$/.exec(h)!; assert.ok(m); assert.equal(m[4], v.publicKey);
  const claims = JSON.parse(b(m[2]!).toString()); assert.deepEqual(claims, { aud: 'https://fcm.googleapis.com', exp: now + 43200, sub: 'mailto:ops@example.com' });
  const pub = b(v.publicKey), key = createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: pub.subarray(1, 33).toString('base64url'), y: pub.subarray(33).toString('base64url') }, format: 'jwk' });
  assert.ok(createVerify('SHA256').update(`${m[1]}.${m[2]}`).verify({ key, dsaEncoding: 'ieee-p1363' }, b(m[3]!)));
  const tampered = createVerify('SHA256').update(`${m[1]}.${m[2]}x`).verify({ key, dsaEncoding: 'ieee-p1363' }, b(m[3]!)); assert.equal(tampered, false);
});

test('WebPush.send posts an encrypted body with the required headers and classifies results', async () => {
  const v = generateVapidKeys('mailto:ops@example.com'); const calls: Array<{ url: string; init: RequestInit }> = []; let status = 201;
  const fake = (async (url: string, init: RequestInit) => { calls.push({ url, init }); return new Response(null, { status }); }) as unknown as typeof fetch;
  const wp = new WebPush(v, fake), sub = { endpoint: 'https://push.example/s/1', keys: UA };
  assert.deepEqual(await wp.send(sub, { title: 'T', body: 'B' }), { ok: true });
  const h = calls[0]!.init.headers as Record<string, string>; assert.equal(h['Content-Encoding'], 'aes128gcm'); assert.equal(h['TTL'], '86400'); assert.match(h['Authorization']!, /^vapid t=/);
  assert.ok((calls[0]!.init.body as Uint8Array).length > 86 + 20);
  status = 410; assert.deepEqual(await wp.send(sub, { title: 'T', body: 'B' }), { ok: false, gone: true, status: 410 });
  status = 503; assert.deepEqual(await wp.send(sub, { title: 'T', body: 'B' }), { ok: false, gone: false, status: 503 });
  const n = calls.length; assert.deepEqual(await wp.send({ ...sub, endpoint: 'http://10.0.0.1/x' }, { title: 'T', body: 'B' }), { ok: false, gone: true, status: 0 }); assert.equal(calls.length, n);
});
