import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { MemoryStore } from '../src/store-memory.js';
import { sanitizePolicy, netRevenue, currentWindow, levelOf, DEFAULT_POLICY as P } from '../src/usage.js';

const PW = 'correct-horse-battery', OP = 'p'.repeat(32), DAY = 864e5;
const near = (a, b, e = 1e-6) => assert.ok(Math.abs(a - b) < e, `${a} !~ ${b}`);

test('policy validation and defaults', () => {
  assert.equal(P.costShare, 0.25);
  assert.equal(sanitizePolicy({ costShare: 0.4 }).costShare, 0.4);
  assert.throws(() => sanitizePolicy({ costShare: 1.5 }), /costShare/);
  assert.throws(() => sanitizePolicy({ costShare: 'x' }), /costShare/);
  assert.throws(() => sanitizePolicy({ warn: [0.9, 0.7] }), /warn/);
  assert.deepEqual(sanitizePolicy({ warn: [0.5, 0.8] }).warn, [0.5, 0.8]);
});

test('net revenue = amount - fee - tax - refunds (never negative)', () => {
  near(netRevenue({ amountUsd: 10 }, P), 9.9);                                   // default 1% fee
  near(netRevenue({ amountUsd: 10, feeUsd: 0.5, taxUsd: 1 }, P), 8.5);
  near(netRevenue({ amountUsd: 10, feeUsd: 0, taxUsd: 0, refundedUsd: 4 }, P), 6);
  assert.equal(netRevenue({ amountUsd: 10, refundedUsd: 99 }, P), 0);
  near(netRevenue({ amountUsd: 10 }, { ...P, taxPct: 20 }), 7.9);
});

test('the 25% rule: $10 net -> $2.50 budget; yearly plans release the budget month by month', () => {
  const t0 = Date.parse('2026-01-01T00:00:00Z');
  const m = { orderId: 'a', paidAt: new Date(t0).toISOString(), days: 30, amountUsd: 10, feeUsd: 0, taxUsd: 0 };
  near(currentWindow([m], P, t0 + 5 * DAY).budgetUsd, 2.5);
  const y = { orderId: 'b', paidAt: new Date(t0).toISOString(), days: 365, amountUsd: 120, feeUsd: 0, taxUsd: 0 };
  const w1 = currentWindow([y], P, t0 + DAY), w2 = currentWindow([y], P, t0 + 31 * DAY);
  near(w1.budgetUsd, 120 * 0.25 * 30 / 365); assert.ok(w1.budgetUsd < 120 * 0.25 / 11);   // NOT the whole year on day 1
  assert.notEqual(w1.start, w2.start);
  let total = 0; for (let k = 0; k < 13; k++) total += currentWindow([y], P, t0 + k * 30 * DAY + DAY).budgetUsd;
  near(total, 120 * 0.25, 1e-9);                                                 // all windows together = exactly 25% of net
  const after = currentWindow([m], P, t0 + 40 * DAY);                            // expired -> free monthly budget
  assert.equal(after.paid, false); near(after.budgetUsd, P.freeMonthlyUsd);
  // stacked renewals continue one after the other
  const m2 = { ...m, orderId: 'c', paidAt: new Date(t0 + 10 * DAY).toISOString() };
  const w = currentWindow([m, m2], P, t0 + 35 * DAY); assert.equal(w.orderId, 'c');
});

test('levels: warn at 70% and 90%, blocked at 100% unless credit', () => {
  assert.equal(levelOf(0.5, 0, P), 'ok'); assert.equal(levelOf(0.7, 0, P), 'warn70'); assert.equal(levelOf(0.95, 0, P), 'warn90');
  assert.equal(levelOf(1, 0, P), 'blocked'); assert.equal(levelOf(1.2, 3, P), 'warn90');
});

// ---------- server integration
function boot() {
  const store = new MemoryStore(), seen = [];
  let tokens = { inputTokens: 10000, outputTokens: 1000 };   // what the fake model "reports": $0.03 + $0.015 = $0.045
  const ai = { name: 'fake', async complete(x) { seen.push(x); if (x.onUsage) x.onUsage(tokens); return 'ok'; } };
  const app = createApp({ store, aiProvider: ai, config: { jwtSecret: 'x'.repeat(40), operatorToken: OP } });
  const server = http.createServer(app);
  return new Promise(r => server.listen(0, async () => {
    const base = `http://127.0.0.1:${server.address().port}`;
    const call = async (method, path, body, token, headers = {}) => {
      const x = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
      return { status: x.status, body: await x.json() };
    };
    const owner = (await call('POST', '/api/auth/register', { email: 'o@x.com', password: PW, orgName: 'Acme' })).body;
    const op = (method, path, body) => call(method, path, body, null, { 'x-operator-token': OP });
    const member = async (email, role) => { await call('POST', '/api/users', { email, password: PW, role }, owner.accessToken); return (await call('POST', '/api/auth/login', { email, password: PW })).body; };
    const pay = async (planId, tier, days, usd, extra = {}) => { const id = 'P' + Math.random(); await store.createPayment({ orderId: id, orgId: owner.user.workspaceId, planId, tier, days, amountUsd: usd, provider: 'x' }); await store.completePayment(id, 'r' + id); if (extra) await store.adjustPayment(id, extra); return id; };
    const ask = (tok = owner.accessToken) => call('POST', '/api/ai/task', { task: 'daily_report' }, tok);
    r({ store, call, op, owner, member, pay, ask, setTokens: (t) => { tokens = t; }, close: () => server.close(), orgId: owner.user.workspaceId });
  }));
}

test('free tier: tiny budget, warnings, hard stop on the server, read/offline stays available', async (x) => {
  const t = await boot(); x.after(t.close);
  let u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body;
  near(u.budgetUsd, 0.1); assert.equal(u.level, 'ok'); assert.equal(u.period.paid, false);
  assert.equal((await t.ask()).status, 200);                                  // $0.045 -> 45% 
  u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body; near(u.spentUsd, 0.045); assert.equal(u.level, 'ok'); assert.equal(u.byKind.ai, 0.045);
  assert.equal((await t.ask()).status, 200);                                  // $0.090 -> 90%
  u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body; assert.equal(u.level, 'warn90'); assert.ok(u.percent >= 90);
  const blocked = await t.ask(); assert.equal(blocked.status, 402); assert.match(blocked.body.error || blocked.body.message || JSON.stringify(blocked.body), /Usage limit reached/);
  // viewing / sync pull / usage itself are never locked
  assert.equal((await t.call('GET', '/api/usage', null, t.owner.accessToken)).status, 200);
  assert.equal((await t.call('GET', '/api/sync/pull?workspaceId=' + t.orgId + '&since=0', null, t.owner.accessToken)).status, 200);
  // uploads are costly too: with a (deliberately high) storage price a 20 KB backup no longer fits in the remaining budget
  await t.op('PUT', '/api/operator/policy', { syncUsdPerGb: 1000 });
  const body = { workspaceId: t.orgId, deviceId: 'd', snapshot: { projects: [{ id: 1, notes: 'x'.repeat(20000) }] } };
  assert.equal((await t.call('POST', '/api/sync/push', body, t.owner.accessToken)).status, 402);
  const small = await t.call('POST', '/api/sync/push', { ...body, snapshot: { projects: [{ id: 1 }] } }, t.owner.accessToken);
  assert.equal(small.status, 200); assert.ok((await t.call('GET', '/api/usage', null, t.owner.accessToken)).body.byKind.sync > 0);
});

test('paid plans: budget = 25% of net; policy is adjustable by the operator; refunds shrink it; blocked can be lifted with credit', async (x) => {
  const t = await boot(); x.after(t.close);
  const id = await t.pay('pro_monthly', 'pro', 30, 10, { feeUsd: 0, taxUsd: 0 });
  let u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body; near(u.budgetUsd, 2.5); assert.equal(u.period.paid, true);
  // operator raises the share; budget follows without code changes
  assert.equal((await t.op('PUT', '/api/operator/policy', { costShare: 0.4 })).body.policy.costShare, 0.4);
  u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body; near(u.budgetUsd, 4);
  assert.equal((await t.op('PUT', '/api/operator/policy', { costShare: 7 })).status, 400);
  assert.equal((await t.call('PUT', '/api/operator/policy', { costShare: 0.9 }, t.owner.accessToken)).status, 401);   // a customer token is not an operator token
  await t.op('PUT', '/api/operator/policy', { costShare: 0.25 });
  // refund the whole payment -> budget 0 -> blocked
  await t.op('POST', '/api/operator/payment-adjust/' + id, { refundedUsd: 10 });
  u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body; assert.equal(u.budgetUsd, 0); assert.equal(u.level, 'blocked');
  assert.equal((await t.ask()).status, 402);
  // extra credit lets work continue and is consumed
  const c = await t.op('POST', '/api/operator/credit', { orgId: t.orgId, usd: 1, note: 'top-up' }); assert.equal(c.body.creditUsd, 1);
  assert.equal((await t.ask()).status, 200);
  u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body; near(u.creditUsd, 1 - 0.045);
  assert.equal((await t.op('POST', '/api/operator/credit', { orgId: t.orgId, usd: -5 })).status, 400);
  assert.equal((await t.op('POST', '/api/operator/credit', { orgId: 'nope', usd: 1 })).status, 404);
});

test('team plan: shared budget with a per-user cap; owner is not capped by it', async (x) => {
  const t = await boot(); x.after(t.close);
  await t.pay('team_monthly', 'team', 30, 40, { feeUsd: 0, taxUsd: 0 });          // budget 10, per-user cap 50% = 5
  const mgr = await t.member('m@x.com', 'manager');
  t.setTokens({ inputTokens: 400000, outputTokens: 0 });                            // $1.2 per call
  for (let i = 0; i < 5; i++) assert.equal((await t.ask(mgr.accessToken)).status, 200, 'call ' + i);   // guard uses an estimate; the 5th call may overshoot the cap by one request ($6.0)
  const over = await t.ask(mgr.accessToken); assert.equal(over.status, 402); assert.match(JSON.stringify(over.body), /personal share/);
  assert.equal((await t.ask(t.owner.accessToken)).status, 200);
  const u = (await t.call('GET', '/api/usage', null, t.owner.accessToken)).body; assert.ok(u.byUser && Object.keys(u.byUser).length === 2);
  const um = (await t.call('GET', '/api/usage', null, mgr.accessToken)).body; assert.equal(um.byUser, undefined, 'members do not see other users');
});

test('operator overview: revenue, spend and margin per customer; operator endpoints need the token', async (x) => {
  const t = await boot(); x.after(t.close);
  await t.pay('pro_monthly', 'pro', 30, 10, { feeUsd: 0, taxUsd: 0 }); await t.ask();
  const o = (await t.op('GET', '/api/operator/usage-overview')).body;
  assert.equal(o.orgs.length, 1); near(o.orgs[0].revenueUsd, 10); near(o.orgs[0].spentUsd, 0.045); near(o.orgs[0].marginUsd, 9.955); assert.equal(o.orgs[0].tier, 'pro');
  assert.equal((await t.call('GET', '/api/operator/usage-overview')).status, 401);
  assert.equal((await t.call('GET', '/api/operator/usage-overview', null, null, { 'x-operator-token': 'wrong' })).status, 401);
  assert.equal((await t.call('GET', '/api/operator/usage-overview', null, t.owner.accessToken)).status, 401);
});

test('without OPERATOR_TOKEN the operator endpoints do not exist; cap still applies', async (x) => {
  const store = new MemoryStore(), app = createApp({ store, config: { jwtSecret: 'x'.repeat(40) } });
  const server = http.createServer(app); await new Promise(r => server.listen(0, r)); x.after(() => server.close());
  const r = await fetch(`http://127.0.0.1:${server.address().port}/api/operator/policy`, { headers: { 'x-operator-token': 'anything' } });
  assert.equal(r.status, 404);
});
