import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { randomBytes } from 'node:crypto';
import { createApp } from '../src/app.js';
import { MemoryStore } from '../src/store-memory.js';
import { AccountingService, QuickBooks, Xero, seal, open, signState, verifyState } from '../src/accounting.ts';

// ---- A mock of both providers on one local HTTP server (OAuth + the REST calls we use). It records every request.
function mockProviders() {
  const log: Array<{ m: string; path: string; auth: string; body: any; tenant?: string }> = [];
  const db = { customers: [] as any[], vendors: [] as any[], items: [] as any[], invoices: new Map<string, any>(), bills: new Map<string, any>(), contacts: [] as any[], xinv: new Map<string, any>() };
  let seq = 100, tokenGen = 0, failNext: Array<{ match: RegExp; status: number; times: number; headers?: Record<string, string> }> = [], expireAccess = false;
  const server = http.createServer(async (req, res) => {
    const chunks: Buffer[] = []; for await (const c of req) chunks.push(c as Buffer);
    const raw = Buffer.concat(chunks).toString(), url = new URL(req.url!, 'http://x'), ct = String(req.headers['content-type'] || '');
    const body = ct.includes('json') ? JSON.parse(raw || 'null') : ct.includes('form') ? Object.fromEntries(new URLSearchParams(raw)) : null;
    const auth = String(req.headers.authorization || ''); log.push({ m: req.method!, path: url.pathname + url.search, auth, body, tenant: req.headers['xero-tenant-id'] as string });
    const send = (s: number, j: unknown, h: Record<string, string> = {}) => { res.writeHead(s, { 'content-type': 'application/json', ...h }); res.end(JSON.stringify(j)); };
    const f = failNext.find(x => x.times > 0 && x.match.test(url.pathname)); if (f) { f.times--; return send(f.status, { Message: 'boom' }, f.headers); }
    if (url.pathname === '/oauth/token') {
      if (!auth.startsWith('Basic ')) return send(401, { error: 'invalid_client' });
      if (body.grant_type === 'refresh_token' && body.refresh_token === 'revoked') return send(400, { error: 'invalid_grant', error_description: 'revoked' });
      tokenGen++; return send(200, { access_token: `acc-${tokenGen}`, refresh_token: `ref-${tokenGen}`, expires_in: expireAccess ? 1 : 3600 });
    }
    if (url.pathname === '/connections') return send(200, [{ tenantId: 'tenant-1' }]);
    const okAuth = /^Bearer acc-\d+$/.test(auth) && Number(auth.slice(11)) === tokenGen; if (!okAuth) return send(401, { Message: 'AuthenticationFailed' });
    // ---- QuickBooks
    const q = /^\/v3\/company\/([^/]+)\/(.*)$/.exec(url.pathname);
    if (q) {
      const [, , rest] = q;
      if (rest === 'query') {
        const s = url.searchParams.get('query')!; const name = /= '((?:\\'|[^'])*)'/.exec(s)?.[1]?.replace(/\\'/g, "'").replace(/\\\\/g, '\\');
        if (s.includes('from Customer')) return send(200, { QueryResponse: { Customer: db.customers.filter(c => c.DisplayName === name) } });
        if (s.includes('from Vendor')) return send(200, { QueryResponse: { Vendor: db.vendors.filter(c => c.DisplayName === name) } });
        if (s.includes('from Item')) return send(200, { QueryResponse: { Item: db.items.filter(c => c.Name === name) } });
        if (s.includes("AccountType = 'Income'")) return send(200, { QueryResponse: { Account: [{ Id: '79' }] } });
        if (s.includes("AccountType = 'Expense'")) return send(200, { QueryResponse: { Account: [{ Id: '80' }] } });
      }
      if (rest === 'customer' && req.method === 'POST') { const c = { Id: String(++seq), ...body }; db.customers.push(c); return send(200, { Customer: c }); }
      if (rest === 'vendor' && req.method === 'POST') { const c = { Id: String(++seq), ...body }; db.vendors.push(c); return send(200, { Vendor: c }); }
      if (rest === 'item' && req.method === 'POST') { const c = { Id: String(++seq), ...body }; db.items.push(c); return send(200, { Item: c }); }
      for (const [ent, map] of [['invoice', db.invoices], ['bill', db.bills]] as const) {
        const E = ent === 'invoice' ? 'Invoice' : 'Bill';
        if (rest === ent && req.method === 'POST') { if (body.Id) { const cur = map.get(body.Id); if (!cur || cur.SyncToken !== body.SyncToken) return send(400, { Fault: { Error: [{ Detail: 'Stale object' }] } }); const n = { ...cur, ...body, SyncToken: String(Number(cur.SyncToken) + 1) }; map.set(body.Id, n); return send(200, { [E]: n }); }
          const n = { Id: String(++seq), SyncToken: '0', ...body }; map.set(n.Id, n); return send(200, { [E]: n }); }
        if (rest.startsWith(ent + '/') && req.method === 'GET') { const cur = map.get(rest.split('/')[1]!); return cur ? send(200, { [E]: cur }) : send(404, { Message: 'nf' }); }
      }
    }
    // ---- Xero
    if (url.pathname === '/xero/Contacts' && req.method === 'GET') { const name = /Name=="((?:""|[^"])*)"/.exec(url.searchParams.get('where')!)?.[1]?.replace(/""/g, '"'); return send(200, { Contacts: db.contacts.filter(c => c.Name === name) }); }
    if (url.pathname === '/xero/Contacts' && req.method === 'POST') { const c = { ContactID: 'c-' + ++seq, ...body.Contacts[0] }; db.contacts.push(c); return send(200, { Contacts: [c] }); }
    if (url.pathname.startsWith('/xero/Invoices') && req.method === 'POST') {
      const inv = body.Invoices[0]; if (inv.Date === '2026-02-30') return send(200, { Invoices: [{ InvoiceID: 'bad', HasErrors: true, ValidationErrors: [{ Message: 'bad date' }] }] });
      const id = inv.InvoiceID || 'x-' + ++seq; db.xinv.set(id, { ...inv, InvoiceID: id }); return send(200, { Invoices: [{ InvoiceID: id }] });
    }
    send(404, { Message: 'no route ' + url.pathname });
  });
  return new Promise<{ base: string; log: typeof log; db: typeof db; setFail: (f: (typeof failNext)[number]) => void; expireFast: (v: boolean) => void; close: () => void }>(res => server.listen(0, '127.0.0.1', () => {
    const base = `http://127.0.0.1:${(server.address() as any).port}`;
    res({ base, log, db, setFail: f => failNext.push(f), expireFast: v => { expireAccess = v; }, close: () => server.close() });
  }));
}

const KEY = randomBytes(32), SECRET = 'x'.repeat(40), PW = 'correct-horse-battery';
async function boot() {
  const mock = await mockProviders(), store = new MemoryStore() as any, sleeps: number[] = [];
  const cfg = (extra = {}) => ({ clientId: 'cid', clientSecret: 'sec', redirectUri: 'https://app.test/api/integrations/x/callback', tokenUrl: mock.base + '/oauth/token', ...extra });
  const providers = { quickbooks: new QuickBooks(cfg({ apiBase: mock.base })), xero: new Xero(cfg({ apiBase: mock.base + '/xero', connectionsUrl: mock.base + '/connections' })) };
  const accounting = new AccountingService({ store, providers, key: KEY, stateSecret: SECRET, sleep: async (ms) => { sleeps.push(ms); } });
  const app = createApp({ store, accounting, config: { jwtSecret: SECRET } }), server = http.createServer(app); await new Promise<void>(r => server.listen(0, r));
  const base = `http://127.0.0.1:${(server.address() as any).port}`;
  const call = async (method: string, path: string, body?: unknown, token?: string) => { const r = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined }); const text = await r.text(); let json: any = null; try { json = JSON.parse(text); } catch { /* html */ } return { status: r.status, body: json, text }; };
  const o = (await call('POST', '/api/auth/register', { email: 'o@x.com', password: PW, orgName: 'Acme' })).body, orgId = o.user.workspaceId as string;
  const mk = async (email: string, role: string) => { await call('POST', '/api/users', { email, password: PW, role }, o.accessToken); return (await call('POST', '/api/auth/login', { email, password: PW })).body; };
  const put = (module: string, id: string, data: object) => store.applyChange(orgId, { module, id, data: { id, ...data }, updatedAt: '2026-10-01T00:00:00Z', baseVersion: 0 });
  const connect = async (provider: string, extra = '') => { const u = new URL((await call('POST', `/api/integrations/${provider}/connect`, {}, o.accessToken)).body.url); const state = u.searchParams.get('state')!; return call('GET', `/api/integrations/${provider}/callback?code=abc&state=${encodeURIComponent(state)}${extra}`); };
  return { mock, store, accounting, call, o, orgId, mk, put, connect, sleeps, close: () => { server.close(); mock.close(); } };
}
type T = Awaited<ReturnType<typeof boot>>;
const seedBooks = async (t: T) => {
  await t.put('clients', 'c1', { name: "O'Brien & Sons", email: 'ob@x.com' });
  await t.put('invoices', 'i1', { name: 'INV-001', client: 'c1', amount: 1250.5, status: 'sent', issueDate: '2026-10-01', dueDate: '2026-10-31', notes: 'Phase 1' });
  await t.put('invoices', 'i2', { name: 'DRAFT', client: 'c1', amount: 10, status: 'draft', issueDate: '2026-10-01' });
  await t.put('invoices', 'i3', { name: 'ZERO', client: 'c1', amount: 0, status: 'sent', issueDate: '2026-10-01' });
  await t.put('finance', 'f1', { name: 'Cement', type: 'expense', amount: 300, recordDate: '2026-10-02T10:00', category: 'Materials' });
  await t.put('finance', 'f2', { name: 'Payment in', type: 'income', amount: 999, recordDate: '2026-10-02' });
};

test('token vault and OAuth state: sealed, tamper-evident, expiring, provider-bound', () => {
  const t = { access: 'a', refresh: 'r', expiresAt: 1, realm: 'R' }, s = seal(KEY, t);
  assert.deepEqual(open(KEY, s), t); assert.ok(!s.includes('"a"') && !s.includes('refresh'));
  assert.throws(() => open(randomBytes(32), s)); assert.throws(() => open(KEY, s.slice(0, -2) + 'AA'));
  const st = signState(SECRET, { orgId: 'o', userId: 'u', provider: 'xero' }, 1000);
  assert.deepEqual({ ...verifyState(SECRET, st, 2000)!, exp: 0, n: '' }, { orgId: 'o', userId: 'u', provider: 'xero', exp: 0, n: '' });
  assert.equal(verifyState(SECRET, st, 1000 + 11 * 60e3), null); assert.equal(verifyState('y'.repeat(40), st, 2000), null);
  assert.equal(verifyState(SECRET, st.replace(/^./, c => (c === 'A' ? 'B' : 'A')), 2000), null);
});

test('QuickBooks: connect via OAuth, sync creates customer/item/invoice/bill exactly once, edits update, reruns are no-ops', async (x) => {
  const t = await boot(); x.after(t.close); await seedBooks(t);
  const page = await t.connect('quickbooks', '&realmId=9341'); assert.equal(page.status, 200); assert.match(page.text, /Connected/);
  const st = (await t.call('GET', '/api/integrations', undefined, t.o.accessToken)).body.providers.find((p: any) => p.provider === 'quickbooks'); assert.equal(st.connected, true);
  assert.ok(!JSON.stringify(await t.call('GET', '/api/integrations', undefined, t.o.accessToken)).includes('acc-'));            // tokens never exposed
  const r = (await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken)).body;
  assert.deepEqual(r.invoices, { created: 1, updated: 0, unchanged: 0, skipped: 2, failed: 0 }); assert.deepEqual(r.expenses, { created: 1, updated: 0, unchanged: 0, skipped: 0, failed: 0 });
  const inv = [...t.mock.db.invoices.values()][0]; assert.equal(inv.DocNumber, 'INV-001'); assert.equal(inv.Line[0].Amount, 1250.5); assert.equal(inv.DueDate, '2026-10-31');
  assert.equal(t.mock.db.customers[0].DisplayName, "O'Brien & Sons"); assert.equal(t.mock.db.customers[0].PrimaryEmailAddr.Address, 'ob@x.com'); assert.equal(t.mock.db.items.length, 1);
  assert.equal([...t.mock.db.bills.values()][0].Line[0].Amount, 300); assert.equal(t.mock.db.vendors[0].DisplayName, 'Materials');
  assert.ok(t.mock.log.every(l => !l.path.startsWith('/v3/company/9341') || l.path.includes('minorversion=')));
  const r2 = (await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken)).body; assert.equal(r2.invoices.unchanged, 1); assert.equal(r2.expenses.unchanged, 1); assert.equal(t.mock.db.invoices.size, 1);
  await t.put('invoices', 'i1', { name: 'INV-001', client: 'c1', amount: 2000, status: 'sent', issueDate: '2026-10-01', dueDate: '2026-10-31' });   // edit (baseVersion mismatch → LWW still applies via newer ts below)
  await t.store.applyChange(t.orgId, { module: 'invoices', id: 'i1', data: { id: 'i1', name: 'INV-001', client: 'c1', amount: 2000, status: 'sent', issueDate: '2026-10-01', dueDate: '2026-10-31' }, updatedAt: '2026-10-05T00:00:00Z', baseVersion: 1 });
  const r3 = (await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken)).body; assert.equal(r3.invoices.updated, 1); assert.equal(t.mock.db.invoices.size, 1);
  const upd = [...t.mock.db.invoices.values()][0]; assert.equal(upd.Line[0].Amount, 2000); assert.equal(upd.SyncToken, '1'); assert.equal(t.mock.db.customers.length, 1);
});

test('Xero: tenant discovery, contact reuse, invoice create/update, validation errors are reported per record', async (x) => {
  const t = await boot(); x.after(t.close); await seedBooks(t); await t.put('invoices', 'i9', { name: 'BAD-DATE', client: 'c1', amount: 5, status: 'sent', issueDate: '2026-02-30' });
  assert.equal((await t.connect('xero')).status, 200);
  const r = (await t.call('POST', '/api/integrations/xero/sync', {}, t.o.accessToken)).body;
  assert.equal(r.invoices.created, 1); assert.equal(r.invoices.failed, 1); assert.match(r.errors[0].message, /bad date/); assert.equal(r.expenses.created, 1);
  const ac = [...t.mock.db.xinv.values()].find(i => i.Type === 'ACCREC' && i.InvoiceNumber === 'INV-001')!; assert.equal(ac.LineItems[0].UnitAmount, 1250.5); assert.equal(ac.LineItems[0].AccountCode, '200'); assert.equal(ac.Status, 'AUTHORISED');
  assert.equal([...t.mock.db.xinv.values()].find(i => i.Type === 'ACCPAY')!.LineItems[0].AccountCode, '429');
  assert.ok(t.mock.log.filter(l => l.path.startsWith('/xero/')).every(l => l.tenant === 'tenant-1')); assert.equal(t.mock.db.contacts.filter(c => c.Name === "O'Brien & Sons").length, 1);
  await t.put('invoices', 'i4', { name: 'INV-004', client: 'c1', amount: 7, status: 'sent', issueDate: '2026-10-03' });
  await t.call('POST', '/api/integrations/xero/sync', {}, t.o.accessToken); assert.equal(t.mock.db.contacts.filter(c => c.Name === "O'Brien & Sons").length, 1);   // contact reused, not duplicated
});

test('expired access tokens are refreshed and the rotated refresh token is persisted; revoked access asks to reconnect', async (x) => {
  const t = await boot(); x.after(t.close); await seedBooks(t); await t.connect('quickbooks', '&realmId=1');
  const row = async () => open(KEY, (await t.store.getIntegration(t.orgId, 'quickbooks')).tokensEnc);
  const before = await row(); await t.store.saveIntegration({ ...(await t.store.getIntegration(t.orgId, 'quickbooks')), tokensEnc: seal(KEY, { ...before, expiresAt: Date.now() - 1000 }) });
  assert.equal((await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken)).status, 200);
  const after = await row(); assert.notEqual(after.access, before.access); assert.notEqual(after.refresh, before.refresh); assert.ok(after.expiresAt > Date.now());
  assert.ok(t.mock.log.some(l => l.path === '/oauth/token' && l.body.grant_type === 'refresh_token' && l.body.refresh_token === before.refresh));
  await t.store.saveIntegration({ ...(await t.store.getIntegration(t.orgId, 'quickbooks')), tokensEnc: seal(KEY, { ...after, refresh: 'revoked', expiresAt: 0 }) });
  await t.put('invoices', 'i8', { name: 'NEW', client: 'c1', amount: 3, status: 'sent', issueDate: '2026-10-06' });      // something to send, so credentials are actually needed
  const dead = await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken); assert.equal(dead.status, 409); assert.match(dead.body.error, /reconnect/i);
});

test('a 401 mid-sync triggers one refresh and a retry; 429/5xx are retried with backoff and Retry-After', async (x) => {
  const t = await boot(); x.after(t.close); await seedBooks(t); await t.connect('quickbooks', '&realmId=1');
  // server rotated its token generation behind our back: our stored access token is now stale → 401 → refresh → retry succeeds
  await fetch(t.mock.base + '/oauth/token', { method: 'POST', headers: { authorization: 'Basic eA==', 'content-type': 'application/x-www-form-urlencoded' }, body: 'grant_type=refresh_token&refresh_token=zzz' });
  t.mock.setFail({ match: /\/invoice$/, status: 429, times: 2, headers: { 'retry-after': '2' } }); t.mock.setFail({ match: /\/bill$/, status: 503, times: 1 });
  const r = (await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken)).body;
  assert.equal(r.invoices.created, 1); assert.equal(r.expenses.created, 1); assert.equal(t.mock.db.invoices.size, 1, 'no duplicates after retries');
  assert.deepEqual(t.sleeps.slice(0, 3), [2000, 2000, 500]);
  t.mock.setFail({ match: /\/query$/, status: 500, times: 99 }); await t.put('invoices', 'i7', { name: 'N', client: 'c1', amount: 1, status: 'sent', issueDate: '2026-10-04' });
  const bad = (await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken)).body; assert.equal(bad.invoices.failed, 1); assert.match(bad.errors[0].message, /500/);   // gives up after retries, reports, does not crash
});

test('security: callback needs a valid signed state; roles; disconnect; rate limit; unconfigured server', async (x) => {
  const t = await boot(); x.after(t.close);
  assert.equal((await t.call('GET', '/api/integrations/quickbooks/callback?code=abc&state=forged')).status, 400);
  const other = signState(SECRET, { orgId: t.orgId, userId: 'u', provider: 'xero' }); assert.equal((await t.call('GET', `/api/integrations/quickbooks/callback?code=abc&state=${other}`)).status, 400);   // state bound to provider
  assert.equal((await t.call('GET', '/api/integrations/quickbooks/callback?error=access_denied&state=' + signState(SECRET, { orgId: t.orgId, userId: 'u', provider: 'quickbooks' }))).status, 400);
  const wk = await t.mk('w@x.com', 'worker'), acc = await t.mk('a@x.com', 'accountant');
  assert.equal((await t.call('GET', '/api/integrations', undefined, wk.accessToken)).status, 403); assert.equal((await t.call('POST', '/api/integrations/xero/connect', {}, wk.accessToken)).status, 403);
  assert.equal((await t.call('POST', '/api/integrations/nope/connect', {}, t.o.accessToken)).status, 404);
  assert.equal((await t.call('POST', '/api/integrations/xero/sync', {}, acc.accessToken)).status, 409);          // accountant may sync, but nothing is connected yet
  await t.connect('xero'); assert.equal((await t.call('DELETE', '/api/integrations/xero', undefined, acc.accessToken)).status, 200);
  assert.equal(await t.store.getIntegration(t.orgId, 'xero'), null);
  assert.equal((await t.call('GET', '/api/integrations')).status, 401);
  const bare = http.createServer(createApp({ store: new MemoryStore(), config: { jwtSecret: SECRET } })); await new Promise<void>(r => bare.listen(0, r)); x.after(() => bare.close());
  const b = `http://127.0.0.1:${(bare.address() as any).port}`, tok = (await (await fetch(b + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'z@x.com', password: PW }) })).json()).accessToken;
  assert.equal((await fetch(b + '/api/integrations/xero/connect', { method: 'POST', headers: { authorization: 'Bearer ' + tok } })).status, 501);
  assert.deepEqual(await (await fetch(b + '/api/integrations', { headers: { authorization: 'Bearer ' + tok } })).json(), { providers: [] });
});

test('erasing the workspace also destroys stored provider tokens and mappings', async (x) => {
  const t = await boot(); x.after(t.close); await seedBooks(t); await t.connect('quickbooks', '&realmId=1'); await t.call('POST', '/api/integrations/quickbooks/sync', {}, t.o.accessToken);
  assert.ok(t.store.integrations.size === 1 && t.store.intMap.size === 2);
  assert.equal((await t.call('POST', '/api/account/delete', { confirm: 'DELETE MY ACCOUNT', password: PW, workspace: true }, t.o.accessToken)).status, 200);
  assert.deepEqual([t.store.integrations.size, t.store.intMap.size], [0, 0]);
});
