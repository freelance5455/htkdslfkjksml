// Web Push (RFC 8030) with VAPID (RFC 8292) and aes128gcm payload encryption (RFC 8188 / RFC 8291), using only node:crypto.
import { createECDH, createHmac, createCipheriv, createPrivateKey, createSign, randomBytes } from 'node:crypto';

export interface PushSubscription { endpoint: string; keys: { p256dh: string; auth: string } }
export interface VapidKeys { publicKey: string; privateKey: string; subject: string }   // base64url raw P-256 public (65 B) / private (32 B)

const b64u = (b: Buffer) => b.toString('base64url');
const fromB64u = (s: string) => Buffer.from(s, 'base64url');
function hkdf(salt: Buffer, ikm: Buffer, info: Buffer, len: number): Buffer {
  const prk = createHmac('sha256', salt).update(ikm).digest();
  const out: Buffer[] = []; let prev: Buffer = Buffer.alloc(0);
  for (let i = 1; Buffer.concat(out).length < len; i++) { prev = createHmac('sha256', prk).update(Buffer.concat([prev, info, Buffer.from([i])])).digest(); out.push(prev); }
  return Buffer.concat(out).subarray(0, len);
}

export function generateVapidKeys(subject: string): VapidKeys {
  const e = createECDH('prime256v1'); e.generateKeys();
  return { publicKey: b64u(e.getPublicKey()), privateKey: b64u(e.getPrivateKey()), subject };
}

export function vapidAuthHeader(v: VapidKeys, endpoint: string, nowSec = Math.floor(Date.now() / 1000)): string {
  const aud = new URL(endpoint).origin;
  const head = b64u(Buffer.from(JSON.stringify({ typ: 'JWT', alg: 'ES256' }))), claims = b64u(Buffer.from(JSON.stringify({ aud, exp: nowSec + 12 * 3600, sub: v.subject })));
  const pub = fromB64u(v.publicKey), d = fromB64u(v.privateKey);
  const key = createPrivateKey({ key: { kty: 'EC', crv: 'P-256', d: b64u(d), x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)) }, format: 'jwk' });
  const sig = createSign('SHA256').update(`${head}.${claims}`).sign({ key, dsaEncoding: 'ieee-p1363' });
  return `vapid t=${head}.${claims}.${b64u(sig)}, k=${v.publicKey}`;
}

/** RFC 8291 §3.4 encryption of one message (single record, 4096-byte record size). */
export function encryptPayload(sub: PushSubscription, plaintext: Buffer, opts: { salt?: Buffer; ephemeral?: ReturnType<typeof createECDH> } = {}): Buffer {
  const ua = fromB64u(sub.keys.p256dh), auth = fromB64u(sub.keys.auth);
  if (ua.length !== 65 || ua[0] !== 4) throw new Error('bad p256dh key'); if (auth.length !== 16) throw new Error('bad auth secret');
  if (plaintext.length > 3993) throw new Error('payload too large');   // 4096 - 86 header/tag/delimiter
  const as = opts.ephemeral ?? createECDH('prime256v1'); if (!opts.ephemeral) as.generateKeys();
  const asPub = as.getPublicKey(), salt = opts.salt ?? randomBytes(16);
  const secret = as.computeSecret(ua);
  const ikm = hkdf(auth, secret, Buffer.concat([Buffer.from('WebPush: info\0'), ua, asPub]), 32);
  const cek = hkdf(salt, ikm, Buffer.from('Content-Encoding: aes128gcm\0'), 16), nonce = hkdf(salt, ikm, Buffer.from('Content-Encoding: nonce\0'), 12);
  const c = createCipheriv('aes-128-gcm', cek, nonce);
  const ct = Buffer.concat([c.update(Buffer.concat([plaintext, Buffer.from([2])])), c.final(), c.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPub.length]), asPub, ct]);
}

export type PushResult = { ok: true } | { ok: false; gone: boolean; status: number };
export class WebPush {
  vapid: VapidKeys; fetchFn: typeof fetch;
  constructor(vapid: VapidKeys, fetchFn: typeof fetch = fetch) { this.vapid = vapid; this.fetchFn = fetchFn; }
  async send(sub: PushSubscription, message: { title: string; body: string; url?: string; tag?: string }, ttlSec = 86400): Promise<PushResult> {
    if (!/^https:\/\//.test(sub.endpoint)) return { ok: false, gone: true, status: 0 };     // only HTTPS push services; also blocks SSRF to plain internal hosts
    const body = encryptPayload(sub, Buffer.from(JSON.stringify(message)));
    const res = await this.fetchFn(sub.endpoint, { method: 'POST', headers: { Authorization: vapidAuthHeader(this.vapid, sub.endpoint), TTL: String(ttlSec), 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', Urgency: 'normal' }, body: new Uint8Array(body), signal: AbortSignal.timeout(10000) });
    if (res.status >= 200 && res.status < 300) return { ok: true };
    return { ok: false, gone: res.status === 404 || res.status === 410, status: res.status };
  }
}
