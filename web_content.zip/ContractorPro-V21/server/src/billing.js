// Crypto billing. Two interchangeable providers:
//  - BTCPay Server (self-hosted, no middleman, BTC / Lightning / USDT depending on the payment methods you enable)
//  - NOWPayments   (hosted, USDT on TRON/Ethereum/BSC, BTC and many others)
// Rules enforced here: a webhook is never trusted on its own. Its signature is verified, then the provider is asked
// directly for the real invoice/payment and the order id and amount must match what we stored before the plan is activated.
import { createHmac, timingSafeEqual } from 'node:crypto';

// Default prices (USD, about 12 Pro / 39 Team per month). Override with the PLANS_JSON environment variable. `tier` decides AI quota and features.
export const DEFAULT_PLANS = {
  pro_monthly:  { tier: 'pro',  usd: 12,  days: 30 },
  pro_yearly:   { tier: 'pro',  usd: 120, days: 365 },
  team_monthly: { tier: 'team', usd: 39,  days: 30 },
  team_yearly:  { tier: 'team', usd: 390, days: 365 }
};
export const DEFAULT_AI_LIMITS = { free: 10, pro: 200, team: 1000 };

export function parsePlans(raw) {
  if (!raw) return DEFAULT_PLANS;
  const j = JSON.parse(raw), out = {};
  for (const [id, p] of Object.entries(j)) {
    if (!/^[a-z0-9_]{2,40}$/.test(id) || !['pro', 'team'].includes(p.tier) || !(p.usd > 0) || !(p.days >= 1 && p.days <= 3660)) throw new Error('Invalid plan ' + id);
    out[id] = { tier: p.tier, usd: Math.round(p.usd * 100) / 100, days: Math.floor(p.days) };
  }
  if (!Object.keys(out).length) throw new Error('PLANS_JSON is empty');
  return out;
}

export function effectiveTier(sub, now = Date.now()) {
  if (!sub || sub.status !== 'active') return 'free';
  if (sub.expiresAt && new Date(sub.expiresAt).getTime() <= now) return 'free';
  return sub.plan || 'free';
}

const eqHex = (a, b) => { const x = Buffer.from(String(a), 'utf8'), y = Buffer.from(String(b), 'utf8'); return x.length === y.length && timingSafeEqual(x, y); };
const near = (a, b) => Math.abs(Number(a) - Number(b)) < 0.005;
const sortKeys = (v) => Array.isArray(v) ? v.map(sortKeys) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, sortKeys(v[k])])) : v;

export class BtcPayProvider {
  name = 'btcpay';
  constructor({ baseUrl, storeId, apiKey, webhookSecret, redirectUrl = '', fetchImpl = fetch }) {
    Object.assign(this, { baseUrl: String(baseUrl).replace(/\/+$/, ''), storeId, apiKey, webhookSecret, redirectUrl, f: fetchImpl });
  }
  async api(method, path, body) {
    const r = await this.f(this.baseUrl + path, { method, headers: { 'content-type': 'application/json', authorization: 'token ' + this.apiKey }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error('BTCPay error ' + r.status);
    return r.json();
  }
  async createCheckout({ orderId, amountUsd, description, buyerEmail }) {
    const inv = await this.api('POST', `/api/v1/stores/${this.storeId}/invoices`, {
      amount: amountUsd.toFixed(2), currency: 'USD',
      metadata: { orderId, itemDesc: description, ...(buyerEmail ? { buyerEmail } : {}) },
      checkout: { expirationMinutes: 60, redirectAutomatically: false, ...(this.redirectUrl ? { redirectURL: this.redirectUrl } : {}) }
    });
    if (!inv.id || !inv.checkoutLink) throw new Error('BTCPay returned no invoice');
    return { providerRef: inv.id, checkoutUrl: inv.checkoutLink };
  }
  verifyWebhook(raw, headers) {
    const sig = String(headers['btcpay-sig'] || ''), want = 'sha256=' + createHmac('sha256', this.webhookSecret).update(raw).digest('hex');
    if (!sig || !eqHex(sig, want)) return null;
    let e; try { e = JSON.parse(raw.toString('utf8')); } catch { return null; }
    const status = e.type === 'InvoiceSettled' ? 'paid' : ['InvoiceExpired', 'InvoiceInvalid'].includes(e.type) ? 'failed' : 'ignore';
    return { status, providerRef: String(e.invoiceId || ''), orderId: String(e.metadata?.orderId || '') };
  }
  // Ask BTCPay itself; the webhook body is not enough.
  async confirm(ev) {
    const inv = await this.api('GET', `/api/v1/stores/${this.storeId}/invoices/${encodeURIComponent(ev.providerRef)}`);
    return { paid: inv.status === 'Settled', orderId: String(inv.metadata?.orderId || ''), amountUsd: String(inv.currency).toUpperCase() === 'USD' ? Number(inv.amount) : NaN };
  }
}

export class NowPaymentsProvider {
  name = 'nowpayments';
  constructor({ apiKey, ipnSecret, publicUrl = '', baseUrl = 'https://api.nowpayments.io', successUrl = '', fetchImpl = fetch }) {
    Object.assign(this, { apiKey, ipnSecret, publicUrl: String(publicUrl).replace(/\/+$/, ''), baseUrl, successUrl, f: fetchImpl });
  }
  async api(method, path, body) {
    const r = await this.f(this.baseUrl + path, { method, headers: { 'content-type': 'application/json', 'x-api-key': this.apiKey }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error('NOWPayments error ' + r.status);
    return r.json();
  }
  async createCheckout({ orderId, amountUsd, description }) {
    const inv = await this.api('POST', '/v1/invoice', {
      price_amount: amountUsd, price_currency: 'usd', order_id: orderId, order_description: description,
      ...(this.publicUrl ? { ipn_callback_url: this.publicUrl + '/api/billing/webhook/nowpayments' } : {}),
      ...(this.successUrl ? { success_url: this.successUrl } : {})
    });
    if (!inv.id || !inv.invoice_url) throw new Error('NOWPayments returned no invoice');
    return { providerRef: String(inv.id), checkoutUrl: inv.invoice_url };
  }
  verifyWebhook(raw, headers) {
    let e; try { e = JSON.parse(raw.toString('utf8')); } catch { return null; }
    const want = createHmac('sha512', this.ipnSecret).update(JSON.stringify(sortKeys(e))).digest('hex');
    if (!eqHex(String(headers['x-nowpayments-sig'] || ''), want)) return null;
    const s = String(e.payment_status || '');
    const status = s === 'finished' ? 'paid' : ['failed', 'expired', 'refunded'].includes(s) ? 'failed' : 'ignore';
    return { status, providerRef: String(e.payment_id || ''), orderId: String(e.order_id || '') };
  }
  async confirm(ev) {
    const p = await this.api('GET', '/v1/payment/' + encodeURIComponent(ev.providerRef));
    return { paid: p.payment_status === 'finished', orderId: String(p.order_id || ''), amountUsd: String(p.price_currency).toLowerCase() === 'usd' ? Number(p.price_amount) : NaN };
  }
}

export { near };
