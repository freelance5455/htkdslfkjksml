import http from 'node:http';
import { createApp } from './app.js';
import { MemoryStore } from './store-memory.js';
import { AnthropicProvider, LocalProvider } from './ai-gateway.js';
import { DiskBlobStore } from './blobstore.js';
import { parseDirect } from './direct.js';
import { BtcPayProvider, NowPaymentsProvider, parsePlans } from './billing.js';
import { SmtpMailer } from './smtp.ts';
import { WebPush } from './webpush.ts';
import { Notifier } from './notifier.ts';
import { can } from './rbac.js';
import { AccountingService, QuickBooks, Xero } from './accounting.ts';

const env = process.env, prod = env.NODE_ENV === 'production';
const jwtSecret = env.JWT_SECRET || '';
if (prod && jwtSecret.length < 32) { console.error('JWT_SECRET (>=32 chars) is required in production'); process.exit(1); }
if (prod && !env.DATABASE_URL) { console.error('DATABASE_URL is required in production (in-memory storage would lose data)'); process.exit(1); }

let store;
if (env.DATABASE_URL) { const { PgStore } = await import('./store-pg.js'); store = await PgStore.connect(env.DATABASE_URL); }
else { console.warn('WARNING: no DATABASE_URL — using in-memory store (development only)'); store = new MemoryStore(); }

const aiProvider = env.ANTHROPIC_API_KEY ? new AnthropicProvider({ apiKey: env.ANTHROPIC_API_KEY, model: env.AI_MODEL || 'claude-sonnet-5-5' }) : new LocalProvider();
// Mail: real SMTP when SMTP_HOST is set (production requires it for OTP login and alerts); otherwise the development mailer prints the OTP to the console.
let mailer = null;
if (env.SMTP_HOST) {
  const port = Number(env.SMTP_PORT) || 587;
  if (!env.SMTP_FROM) { console.error('SMTP_FROM is required when SMTP_HOST is set'); process.exit(1); }
  mailer = new SmtpMailer({ host: env.SMTP_HOST, port, secure: env.SMTP_SECURE ? env.SMTP_SECURE === 'true' : port === 465, user: env.SMTP_USER || undefined, pass: env.SMTP_PASS || undefined, from: env.SMTP_FROM, heloName: env.SMTP_HELO || undefined });
} else if (!prod) {
  mailer = { mode: 'console', async send(email, code) { console.log(`[dev OTP] ${email}: ${code}`); }, async sendMail(m) { console.log(`[dev mail] to=${m.to} subject=${m.subject}`); } };
} else console.warn('WARNING: SMTP_HOST is not set; e-mail login codes and alert e-mails are disabled');

// Web Push (optional): generate keys once with `npm run vapid`.
let push = null, pushPublicKey = '';
if (env.VAPID_PUBLIC_KEY && env.VAPID_PRIVATE_KEY) { push = new WebPush({ publicKey: env.VAPID_PUBLIC_KEY, privateKey: env.VAPID_PRIVATE_KEY, subject: env.VAPID_SUBJECT || 'mailto:' + (env.SMTP_FROM || 'admin@example.com') }); pushPublicKey = env.VAPID_PUBLIC_KEY; }
const notifier = new Notifier({ store, mailer: mailer && typeof mailer.sendMail === 'function' ? mailer : null, push, canRead: (role, mod) => can(role, 'read', mod), appName: env.APP_NAME || 'Contractor Pro', appUrl: env.PUBLIC_URL || '', log: m => console.warn('[notify]', m) });

const providers = {};
if (env.BTCPAY_URL && env.BTCPAY_STORE_ID && env.BTCPAY_API_KEY && env.BTCPAY_WEBHOOK_SECRET)
  providers.btcpay = new BtcPayProvider({ baseUrl: env.BTCPAY_URL, storeId: env.BTCPAY_STORE_ID, apiKey: env.BTCPAY_API_KEY, webhookSecret: env.BTCPAY_WEBHOOK_SECRET, redirectUrl: env.PAYMENT_SUCCESS_URL || '' });
if (env.NOWPAYMENTS_API_KEY && env.NOWPAYMENTS_IPN_SECRET)
  providers.nowpayments = new NowPaymentsProvider({ apiKey: env.NOWPAYMENTS_API_KEY, ipnSecret: env.NOWPAYMENTS_IPN_SECRET, publicUrl: env.PUBLIC_URL || '', successUrl: env.PAYMENT_SUCCESS_URL || '' });
if (prod && !Object.keys(providers).length) console.warn('WARNING: no crypto payment provider configured; checkout will return 501');
let plans; try { plans = parsePlans(env.PLANS_JSON); } catch (e) { console.error('PLANS_JSON invalid:', e.message); process.exit(1); }

if (env.OPERATOR_TOKEN && env.OPERATOR_TOKEN.length < 24) { console.error('OPERATOR_TOKEN must be at least 24 chars'); process.exit(1); }
let direct = null; try { direct = parseDirect(env); } catch (e) { console.error(e.message); process.exit(1); }
// Live accounting (optional). Needs PUBLIC_URL (the redirect URI registered with the provider) and INTEGRATION_KEY (32 random bytes, base64) to seal OAuth tokens.
const accProviders = {}, redirect = (p) => `${(env.PUBLIC_URL || '').replace(/\/$/, '')}/api/integrations/${p}/callback`;
if (env.QBO_CLIENT_ID && env.QBO_CLIENT_SECRET) accProviders.quickbooks = new QuickBooks({ clientId: env.QBO_CLIENT_ID, clientSecret: env.QBO_CLIENT_SECRET, redirectUri: redirect('quickbooks'), sandbox: env.QBO_ENV !== 'production' });
if (env.XERO_CLIENT_ID && env.XERO_CLIENT_SECRET) accProviders.xero = new Xero({ clientId: env.XERO_CLIENT_ID, clientSecret: env.XERO_CLIENT_SECRET, redirectUri: redirect('xero'), salesAccount: env.XERO_SALES_ACCOUNT || undefined, expenseAccount: env.XERO_EXPENSE_ACCOUNT || undefined });
let accounting = null;
if (Object.keys(accProviders).length) {
  const key = Buffer.from(env.INTEGRATION_KEY || '', 'base64');
  if (key.length !== 32) { console.error('INTEGRATION_KEY (base64 of 32 random bytes) is required when an accounting provider is configured. Generate: openssl rand -base64 32'); process.exit(1); }
  if (!env.PUBLIC_URL || (prod && !env.PUBLIC_URL.startsWith('https://'))) { console.error('PUBLIC_URL (https in production) is required for accounting OAuth callbacks'); process.exit(1); }
  accounting = new AccountingService({ store, providers: accProviders, key, stateSecret: jwtSecret || 'dev-only-secret-change-me-dev-only-secret' });
}
const blobs = new DiskBlobStore(env.FILES_DIR || (prod ? '/data/files' : './data/files'));
const handler = createApp({ blobs,
  store, aiProvider, mailer, notifier, pushPublicKey, accounting, billing: { plans, providers, direct },
  config: { operatorToken: env.OPERATOR_TOKEN || '', jwtSecret: jwtSecret || 'dev-only-secret-change-me-dev-only-secret', corsOrigins: (env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean), aiDailyLimit: env.AI_DAILY_LIMIT_PER_ORG ? Number(env.AI_DAILY_LIMIT_PER_ORG) : undefined }
});
http.createServer(handler).listen(Number(env.PORT) || 8080, () => console.log('Contractor Pro server listening on', env.PORT || 8080));

// Alert digest: every DIGEST_INTERVAL_MIN minutes (0 disables). Each alert is announced once (atomic per-key marker), so several instances cannot double-send.
const every = Number(env.DIGEST_INTERVAL_MIN ?? 60);
if (every > 0) { const run = () => notifier.runDigest().then(r => r.newAlerts && console.log('[notify] digest', JSON.stringify(r)), e => console.error('[notify] digest failed:', e.message)); setTimeout(run, 30e3).unref(); setInterval(run, every * 60e3).unref(); }
