// Live accounting integration (QuickBooks Online, Xero) over OAuth2. Pushes invoices (receivables) and expenses (bills).
// Idempotent: each Contractor Pro record maps to ONE external document; unchanged records are skipped, changed ones are updated, never duplicated.
import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

export type ProviderId = 'quickbooks' | 'xero';
export interface Tokens { access: string; refresh: string; expiresAt: number; realm: string }
export interface InvoiceIn { id: string; number: string; party: string; email: string; amount: number; date: string; dueDate: string; note: string }
export interface ExpenseIn { id: string; number: string; party: string; amount: number; date: string; note: string }
export interface ProviderCfg { clientId: string; clientSecret: string; redirectUri: string; authUrl?: string; tokenUrl?: string; apiBase?: string; connectionsUrl?: string; sandbox?: boolean; salesAccount?: string; expenseAccount?: string }

export class AuthExpired extends Error {}
export class ProviderError extends Error { status: number; constructor(m: string, status: number) { super(m); this.status = status; } }

export type Call = (method: string, url: string, o?: { headers?: Record<string, string>; json?: unknown; form?: Record<string, string> }) => Promise<any>;
export interface Provider {
  id: ProviderId; label: string;
  authorizeUrl(state: string): string;
  exchange(code: string, query: Record<string, string>, call: Call): Promise<Tokens>;
  refresh(t: Tokens, call: Call): Promise<Tokens>;
  upsertInvoice(call: Call, t: Tokens, i: InvoiceIn, externalId?: string): Promise<string>;
  upsertExpense(call: Call, t: Tokens, e: ExpenseIn, externalId?: string): Promise<string>;
}

const basic = (c: ProviderCfg) => 'Basic ' + Buffer.from(`${c.clientId}:${c.clientSecret}`).toString('base64');
const tokensFrom = (j: any, realm: string, prev?: Tokens): Tokens => {
  if (!j || typeof j.access_token !== 'string') throw new ProviderError('token response missing access_token', 502);
  return { access: j.access_token, refresh: j.refresh_token || prev?.refresh || '', expiresAt: Date.now() + (Number(j.expires_in) || 1800) * 1000, realm };
};
const money = (n: number) => Math.round(n * 100) / 100;
const qboQuote = (s: string) => s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");

export class QuickBooks implements Provider {
  id = 'quickbooks' as const; label = 'QuickBooks Online'; c: ProviderCfg;
  constructor(c: ProviderCfg) { this.c = c; }
  private get api() { return this.c.apiBase || (this.c.sandbox ? 'https://sandbox-quickbooks.api.intuit.com' : 'https://quickbooks.api.intuit.com'); }
  private get tokenUrl() { return this.c.tokenUrl || 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer'; }
  authorizeUrl(state: string) { const u = new URL(this.c.authUrl || 'https://appcenter.intuit.com/connect/oauth2'); u.search = new URLSearchParams({ client_id: this.c.clientId, response_type: 'code', scope: 'com.intuit.quickbooks.accounting', redirect_uri: this.c.redirectUri, state }).toString(); return u.toString(); }
  async exchange(code: string, q: Record<string, string>, call: Call) {
    if (!q.realmId) throw new ProviderError('QuickBooks did not return a company (realmId)', 400);
    return tokensFrom(await call('POST', this.tokenUrl, { headers: { Authorization: basic(this.c) }, form: { grant_type: 'authorization_code', code, redirect_uri: this.c.redirectUri } }), q.realmId);
  }
  async refresh(t: Tokens, call: Call) { return tokensFrom(await call('POST', this.tokenUrl, { headers: { Authorization: basic(this.c) }, form: { grant_type: 'refresh_token', refresh_token: t.refresh } }), t.realm, t); }
  private async req(call: Call, t: Tokens, method: string, path: string, json?: unknown) {
    const sep = path.includes('?') ? '&' : '?';
    return call(method, `${this.api}/v3/company/${encodeURIComponent(t.realm)}${path}${sep}minorversion=75`, { headers: { Authorization: 'Bearer ' + t.access, Accept: 'application/json' }, json });
  }
  private async query(call: Call, t: Tokens, q: string) { const r = await this.req(call, t, 'GET', '/query?query=' + encodeURIComponent(q)); return r?.QueryResponse ?? {}; }
  private async party(call: Call, t: Tokens, kind: 'Customer' | 'Vendor', name: string, email = ''): Promise<string> {
    const n = name.slice(0, 100) || 'Contractor Pro', found = (await this.query(call, t, `select Id from ${kind} where DisplayName = '${qboQuote(n)}'`))[kind]?.[0];
    if (found) return String(found.Id);
    const made = await this.req(call, t, 'POST', '/' + kind.toLowerCase(), { DisplayName: n, ...(email ? { PrimaryEmailAddr: { Address: email } } : {}) });
    return String(made[kind].Id);
  }
  private async account(call: Call, t: Tokens, type: 'Income' | 'Expense'): Promise<string> {
    const a = (await this.query(call, t, `select Id from Account where AccountType = '${type}' MAXRESULTS 1`)).Account?.[0];
    if (!a) throw new ProviderError(`No ${type} account found in QuickBooks`, 422); return String(a.Id);
  }
  private async serviceItem(call: Call, t: Tokens): Promise<string> {
    const it = (await this.query(call, t, "select Id from Item where Name = 'Contractor Pro Services'")).Item?.[0]; if (it) return String(it.Id);
    const made = await this.req(call, t, 'POST', '/item', { Name: 'Contractor Pro Services', Type: 'Service', IncomeAccountRef: { value: await this.account(call, t, 'Income') } });
    return String(made.Item.Id);
  }
  private async upsert(call: Call, t: Tokens, entity: 'Invoice' | 'Bill', externalId: string | undefined, body: Record<string, unknown>): Promise<string> {
    const path = '/' + entity.toLowerCase();
    if (!externalId) return String((await this.req(call, t, 'POST', path, body))[entity].Id);
    const cur = (await this.req(call, t, 'GET', `${path}/${encodeURIComponent(externalId)}`))[entity];
    return String((await this.req(call, t, 'POST', path, { ...body, Id: cur.Id, SyncToken: cur.SyncToken, sparse: true }))[entity].Id);
  }
  async upsertInvoice(call: Call, t: Tokens, i: InvoiceIn, externalId?: string) {
    const customer = await this.party(call, t, 'Customer', i.party, i.email), item = await this.serviceItem(call, t);
    return this.upsert(call, t, 'Invoice', externalId, { DocNumber: i.number.slice(0, 21), TxnDate: i.date, ...(i.dueDate ? { DueDate: i.dueDate } : {}), CustomerRef: { value: customer }, PrivateNote: i.note.slice(0, 4000),
      Line: [{ Amount: money(i.amount), Description: i.number.slice(0, 4000), DetailType: 'SalesItemLineDetail', SalesItemLineDetail: { ItemRef: { value: item }, Qty: 1, UnitPrice: money(i.amount) } }] });
  }
  async upsertExpense(call: Call, t: Tokens, e: ExpenseIn, externalId?: string) {
    const vendor = await this.party(call, t, 'Vendor', e.party), acct = await this.account(call, t, 'Expense');
    return this.upsert(call, t, 'Bill', externalId, { TxnDate: e.date, VendorRef: { value: vendor }, PrivateNote: e.note.slice(0, 4000), DocNumber: e.number.slice(0, 21),
      Line: [{ Amount: money(e.amount), Description: e.number.slice(0, 4000), DetailType: 'AccountBasedExpenseLineDetail', AccountBasedExpenseLineDetail: { AccountRef: { value: acct } } }] });
  }
}

export class Xero implements Provider {
  id = 'xero' as const; label = 'Xero'; c: ProviderCfg;
  constructor(c: ProviderCfg) { this.c = c; }
  private get api() { return this.c.apiBase || 'https://api.xero.com/api.xro/2.0'; }
  private get tokenUrl() { return this.c.tokenUrl || 'https://identity.xero.com/connect/token'; }
  authorizeUrl(state: string) { const u = new URL(this.c.authUrl || 'https://login.xero.com/identity/connect/authorize'); u.search = new URLSearchParams({ response_type: 'code', client_id: this.c.clientId, redirect_uri: this.c.redirectUri, scope: 'offline_access accounting.transactions accounting.contacts', state }).toString(); return u.toString(); }
  async exchange(code: string, _q: Record<string, string>, call: Call) {
    const t = tokensFrom(await call('POST', this.tokenUrl, { headers: { Authorization: basic(this.c) }, form: { grant_type: 'authorization_code', code, redirect_uri: this.c.redirectUri } }), '');
    const conns = await call('GET', this.c.connectionsUrl || 'https://api.xero.com/connections', { headers: { Authorization: 'Bearer ' + t.access } });
    if (!Array.isArray(conns) || !conns[0]?.tenantId) throw new ProviderError('No Xero organisation was authorised', 400);
    return { ...t, realm: String(conns[0].tenantId) };
  }
  async refresh(t: Tokens, call: Call) { return tokensFrom(await call('POST', this.tokenUrl, { headers: { Authorization: basic(this.c) }, form: { grant_type: 'refresh_token', refresh_token: t.refresh } }), t.realm, t); }
  private req(call: Call, t: Tokens, method: string, path: string, json?: unknown) { return call(method, this.api + path, { headers: { Authorization: 'Bearer ' + t.access, 'xero-tenant-id': t.realm, Accept: 'application/json' }, json }); }
  private async contact(call: Call, t: Tokens, name: string, email = ''): Promise<string> {
    const n = name.slice(0, 255) || 'Contractor Pro', where = `Name=="${n.replace(/"/g, '""')}"`;
    const f = (await this.req(call, t, 'GET', '/Contacts?where=' + encodeURIComponent(where)))?.Contacts?.[0]; if (f) return String(f.ContactID);
    return String((await this.req(call, t, 'POST', '/Contacts', { Contacts: [{ Name: n, ...(email ? { EmailAddress: email } : {}) }] })).Contacts[0].ContactID);
  }
  private async upsert(call: Call, t: Tokens, type: 'ACCREC' | 'ACCPAY', externalId: string | undefined, o: { contact: string; number: string; date: string; dueDate?: string; note: string; amount: number; account: string }) {
    const inv = { ...(externalId ? { InvoiceID: externalId } : {}), Type: type, Contact: { ContactID: o.contact }, InvoiceNumber: o.number.slice(0, 255), Reference: o.note.slice(0, 255), Date: o.date, ...(o.dueDate ? { DueDate: o.dueDate } : {}), Status: 'AUTHORISED', LineAmountTypes: 'NoTax',
      LineItems: [{ Description: o.number.slice(0, 4000), Quantity: 1, UnitAmount: money(o.amount), AccountCode: o.account }] };
    const r = await this.req(call, t, 'POST', externalId ? '/Invoices/' + encodeURIComponent(externalId) : '/Invoices', { Invoices: [inv] });
    const out = r?.Invoices?.[0]; if (!out?.InvoiceID) throw new ProviderError('Xero returned no invoice', 502);
    if (out.HasErrors) throw new ProviderError('Xero rejected the document: ' + JSON.stringify(out.ValidationErrors || []).slice(0, 300), 422);
    return String(out.InvoiceID);
  }
  async upsertInvoice(call: Call, t: Tokens, i: InvoiceIn, externalId?: string) { return this.upsert(call, t, 'ACCREC', externalId, { contact: await this.contact(call, t, i.party, i.email), number: i.number, date: i.date, dueDate: i.dueDate, note: i.note, amount: i.amount, account: this.c.salesAccount || '200' }); }
  async upsertExpense(call: Call, t: Tokens, e: ExpenseIn, externalId?: string) { return this.upsert(call, t, 'ACCPAY', externalId, { contact: await this.contact(call, t, e.party), number: e.number, date: e.date, note: e.note, amount: e.amount, account: this.c.expenseAccount || '429' }); }
}

// ---- token vault: AES-256-GCM, key from INTEGRATION_KEY (32 bytes, base64)
export function seal(key: Buffer, t: Tokens): string { const iv = randomBytes(12), c = createCipheriv('aes-256-gcm', key, iv), ct = Buffer.concat([c.update(JSON.stringify(t), 'utf8'), c.final()]); return ['v1', iv.toString('base64url'), c.getAuthTag().toString('base64url'), ct.toString('base64url')].join('.'); }
export function open(key: Buffer, s: string): Tokens {
  const [v, iv, tag, ct] = s.split('.'); if (v !== 'v1' || !iv || !tag || !ct) throw new Error('bad token blob');
  const d = createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'base64url')); d.setAuthTag(Buffer.from(tag, 'base64url')); return JSON.parse(Buffer.concat([d.update(Buffer.from(ct, 'base64url')), d.final()]).toString('utf8'));
}
export function signState(secret: string, p: { orgId: string; userId: string; provider: string }, now = Date.now()): string {
  const body = Buffer.from(JSON.stringify({ ...p, exp: now + 10 * 60e3, n: randomBytes(8).toString('hex') })).toString('base64url');
  return body + '.' + createHmac('sha256', secret).update('oauth-state:' + body).digest('base64url');
}
export function verifyState(secret: string, s: string, now = Date.now()): { orgId: string; userId: string; provider: string } | null {
  const [body, sig] = String(s).split('.'); if (!body || !sig) return null;
  const want = createHmac('sha256', secret).update('oauth-state:' + body).digest(), got = Buffer.from(sig, 'base64url'); if (got.length !== want.length || !timingSafeEqual(got, want)) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.exp > now ? p : null; } catch { return null; }
}

export interface IntegrationRow { orgId: string; provider: ProviderId; tokensEnc: string; realm: string; connectedBy: string; connectedAt: string; lastSyncAt: string | null }
export interface MapRow { externalId: string; hash: string }
export interface AccStore {
  listAllRecords(orgId: string): Promise<Array<{ module: string; id: string; data: Record<string, any> | null; deleted?: boolean }>>;
  getIntegration(orgId: string, p: ProviderId): Promise<IntegrationRow | null>;
  saveIntegration(row: IntegrationRow): Promise<void>;
  deleteIntegration(orgId: string, p: ProviderId): Promise<void>;
  getMapping(orgId: string, p: ProviderId, module: string, recordId: string): Promise<MapRow | null>;
  saveMapping(orgId: string, p: ProviderId, module: string, recordId: string, m: MapRow): Promise<void>;
}
export interface Counts { created: number; updated: number; unchanged: number; skipped: number; failed: number }
export interface SyncResult { provider: ProviderId; invoices: Counts; expenses: Counts; errors: Array<{ module: string; recordId: string; message: string }> }
const zero = (): Counts => ({ created: 0, updated: 0, unchanged: 0, skipped: 0, failed: 0 });
const day = (v: unknown) => /^\d{4}-\d{2}-\d{2}/.test(String(v ?? '')) ? String(v).slice(0, 10) : '';

export class AccountingService {
  store: AccStore; providers: Partial<Record<ProviderId, Provider>>; key: Buffer; secret: string; fetchFn: typeof fetch; now: () => number; sleep: (ms: number) => Promise<void>;
  private locks = new Map<string, Promise<unknown>>();
  constructor(o: { store: AccStore; providers: Partial<Record<ProviderId, Provider>>; key: Buffer; stateSecret: string; fetchFn?: typeof fetch; now?: () => number; sleep?: (ms: number) => Promise<void> }) {
    if (o.key.length !== 32) throw new Error('INTEGRATION_KEY must decode to 32 bytes');
    this.store = o.store; this.providers = o.providers; this.key = o.key; this.secret = o.stateSecret; this.fetchFn = o.fetchFn ?? fetch; this.now = o.now ?? Date.now; this.sleep = o.sleep ?? (ms => new Promise(r => setTimeout(r, ms)));
  }
  available() { return Object.keys(this.providers) as ProviderId[]; }
  private prov(p: string): Provider { const x = this.providers[p as ProviderId]; if (!x) throw new ProviderError('Unknown or unconfigured provider', 404); return x; }
  /** One HTTP call with retry on 429/5xx (honours Retry-After) and clear errors; 401 becomes AuthExpired. */
  call: Call = async (method, url, o = {}) => {
    for (let attempt = 0; ; attempt++) {
      const headers: Record<string, string> = { ...(o.headers || {}) }; let body: string | undefined;
      if (o.form) { headers['Content-Type'] = 'application/x-www-form-urlencoded'; body = new URLSearchParams(o.form).toString(); } else if (o.json !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(o.json); }
      const res = await this.fetchFn(url, { method, headers, body, signal: AbortSignal.timeout(20000) });
      if ((res.status === 429 || res.status >= 500) && attempt < 3) { const ra = Number(res.headers.get('retry-after')); await this.sleep(ra > 0 ? Math.min(ra, 30) * 1000 : 500 * 2 ** attempt); continue; }
      const text = await res.text(); let j: any = null; try { j = text ? JSON.parse(text) : null; } catch { /* non-JSON error page */ }
      if (res.status === 401) throw new AuthExpired('401');
      if (!res.ok) throw new ProviderError(`${res.status}: ${String(j?.Fault?.Error?.[0]?.Detail || j?.Message || j?.error_description || j?.error || text).slice(0, 300)}`, res.status);
      return j;
    }
  };
  private lock<T>(k: string, fn: () => Promise<T>): Promise<T> { const prev = this.locks.get(k) ?? Promise.resolve(); const next = prev.then(fn, fn); this.locks.set(k, next.catch(() => {})); return next; }

  async status(orgId: string) {
    return Promise.all(this.available().map(async id => { const r = await this.store.getIntegration(orgId, id); return { provider: id, label: this.prov(id).label, connected: !!r, connectedAt: r?.connectedAt ?? null, lastSyncAt: r?.lastSyncAt ?? null }; }));
  }
  beginConnect(orgId: string, userId: string, provider: string): string { return this.prov(provider).authorizeUrl(signState(this.secret, { orgId, userId, provider }, this.now())); }
  async finishConnect(provider: string, q: Record<string, string>): Promise<{ orgId: string }> {
    const st = verifyState(this.secret, q.state || '', this.now()); if (!st || st.provider !== provider) throw new ProviderError('Invalid or expired connection request', 400);
    if (q.error) throw new ProviderError('Authorisation was declined', 400); if (!q.code) throw new ProviderError('Missing authorisation code', 400);
    const p = this.prov(provider), t = await p.exchange(q.code, q, this.call);
    await this.store.saveIntegration({ orgId: st.orgId, provider: p.id, tokensEnc: seal(this.key, t), realm: t.realm, connectedBy: st.userId, connectedAt: new Date(this.now()).toISOString(), lastSyncAt: null });
    return { orgId: st.orgId };
  }
  async disconnect(orgId: string, provider: string) { this.prov(provider); await this.store.deleteIntegration(orgId, provider as ProviderId); }

  private async tokens(orgId: string, p: Provider, force = false): Promise<Tokens> {
    const row = await this.store.getIntegration(orgId, p.id); if (!row) throw new ProviderError(`${p.label} is not connected`, 409);
    let t = open(this.key, row.tokensEnc);
    if (force || t.expiresAt - 60e3 < this.now()) {
      try { t = await p.refresh(t, this.call); } catch (e) { if (e instanceof ProviderError && (e.status === 400 || e.status === 401)) throw new ProviderError(`${p.label} access was revoked or expired; reconnect it`, 409); throw e; }
      await this.store.saveIntegration({ ...row, tokensEnc: seal(this.key, t) });      // refresh tokens rotate: persist immediately
    }
    return t;
  }
  private async withAuth<T>(orgId: string, p: Provider, fn: (t: Tokens) => Promise<T>): Promise<T> {
    let t = await this.tokens(orgId, p);
    try { return await fn(t); } catch (e) { if (!(e instanceof AuthExpired)) throw e; t = await this.tokens(orgId, p, true); try { return await fn(t); } catch (e2) { if (e2 instanceof AuthExpired) throw new ProviderError(`${p.label} rejected the credentials; reconnect it`, 409); throw e2; } }
  }

  sync(orgId: string, provider: string): Promise<SyncResult> {
    const p = this.prov(provider);
    return this.lock(orgId + '|' + p.id, async () => {
      if (!(await this.store.getIntegration(orgId, p.id))) throw new ProviderError(`${p.label} is not connected`, 409);   // even when there is nothing to send
      const recs = (await this.store.listAllRecords(orgId)).filter(r => !r.deleted && r.data), clients = new Map(recs.filter(r => r.module === 'clients').map(r => [r.id, r.data!]));
      const out: SyncResult = { provider: p.id, invoices: zero(), expenses: zero(), errors: [] };
      const run = async (module: 'invoices' | 'finance', kind: 'invoices' | 'expenses', payload: unknown, id: string, fn: (t: Tokens, ext?: string) => Promise<string>) => {
        const hash = createHash('sha256').update(JSON.stringify(payload)).digest('hex'), prev = await this.store.getMapping(orgId, p.id, module, id), c = out[kind];
        if (prev && prev.hash === hash) { c.unchanged++; return; }
        try { const ext = await this.withAuth(orgId, p, t => fn(t, prev?.externalId)); await this.store.saveMapping(orgId, p.id, module, id, { externalId: ext, hash }); prev ? c.updated++ : c.created++; }
        catch (e) { if (e instanceof ProviderError && e.status === 409) throw e; c.failed++; out.errors.push({ module, recordId: id, message: (e as Error).message.slice(0, 300) }); }
      };
      for (const r of recs) {
        const d = r.data!, amount = Number(d.amount);
        if (r.module === 'invoices') {
          if (['draft', 'cancelled'].includes(String(d.status)) || !(amount > 0) || !day(d.issueDate || d.createdAt)) { out.invoices.skipped++; continue; }
          const cl = clients.get(String(d.client)) as Record<string, any> | undefined;
          const inv: InvoiceIn = { id: r.id, number: String(d.name || r.id).slice(0, 255), party: String(cl?.name || 'Unnamed client'), email: String(cl?.email || ''), amount, date: day(d.issueDate || d.createdAt), dueDate: day(d.dueDate), note: String(d.notes || '') };
          await run('invoices', 'invoices', inv, r.id, (t, ext) => p.upsertInvoice(this.call, t, inv, ext));
        } else if (r.module === 'finance' && d.type === 'expense') {
          if (!(amount > 0) || !day(d.recordDate || d.createdAt)) { out.expenses.skipped++; continue; }
          const exp: ExpenseIn = { id: r.id, number: String(d.name || r.id).slice(0, 255), party: String(d.supplier || d.category || 'Contractor Pro expenses'), amount, date: day(d.recordDate || d.createdAt), note: String(d.notes || '') };
          await run('finance', 'expenses', exp, r.id, (t, ext) => p.upsertExpense(this.call, t, exp, ext));
        }
      }
      const row = await this.store.getIntegration(orgId, p.id); if (row) await this.store.saveIntegration({ ...row, lastSyncAt: new Date(this.now()).toISOString() });
      return out;
    });
  }
}
