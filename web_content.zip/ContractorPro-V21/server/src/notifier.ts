// Real delivery of alerts: e-mail (SMTP) and Web Push. The alert RULES are pure functions so they can be tested without any network.
import type { PushSubscription, PushResult } from './webpush.ts';
import type { Mail } from './smtp.ts';

export interface Alert { key: string; kind: 'task' | 'payment' | 'rfi' | 'submittal' | 'punch' | 'stock' | 'hse' | 'tender'; module: string; recordId: string; title: string; due: string }
export interface Rec { module: string; id: string; data: Record<string, unknown> | null; deleted?: boolean }

const s = (v: unknown) => (v == null ? '' : String(v));
const day = (v: unknown) => s(v).slice(0, 10);
const isoWeek = (d: Date) => { const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())); const n = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - n); const y0 = Date.UTC(t.getUTCFullYear(), 0, 1); return `${t.getUTCFullYear()}-W${Math.ceil(((+t - y0) / 864e5 + 1) / 7)}`; };
const addDays = (iso: string, n: number) => new Date(Date.parse(iso + 'T00:00:00Z') + n * 864e5).toISOString().slice(0, 10);

/** today = YYYY-MM-DD in the workspace's day. Same rules as the in-app smart alerts, plus safety and tender rules. */
export function collectAlerts(records: Rec[], today: string): Alert[] {
  const out: Alert[] = [];
  const add = (kind: Alert['kind'], r: Rec, label: string, due: string, bucket = due) => out.push({ key: `${kind}|${r.module}|${r.id}|${bucket}`, kind, module: r.module, recordId: r.id, title: `${label}: ${s(r.data?.name) || s(r.data?.number) || r.id}`, due });
  const openTill = (r: Rec, closed: string[]) => !closed.includes(s(r.data?.status));
  for (const r of records) {
    if (r.deleted || !r.data) continue;
    const d = r.data, due = day(d.dueDate);
    switch (r.module) {
      case 'invoices': if (!['paid', 'cancelled', 'draft'].includes(s(d.status)) && due && due < today) add('payment', r, 'Invoice overdue', due); break;
      case 'schedule': if (s(d.status) !== 'done' && due && due <= today) add('task', r, 'Task due', due); break;
      case 'rfis': if (openTill(r, ['Answered', 'Closed']) && due && due < today) add('rfi', r, 'RFI overdue', due); break;
      case 'submittals': if (openTill(r, ['Approved', 'Approved as noted', 'Rejected']) && due && due < today) add('submittal', r, 'Submittal overdue', due); break;
      case 'punchList': if (openTill(r, ['Closed']) && due && due < today) add('punch', r, 'Punch item overdue', due); break;
      case 'inventory': { const q = Number(d.quantity || 0), m = Number(d.minStock || 0); if (m > 0 && q <= m) add('stock', r, 'Low stock', today, isoWeek(new Date(today + 'T00:00:00Z'))); break; }
      case 'safetyForms': {
        const a = day(d.actionDueDate), open = s(d.status) !== 'Closed';
        if (open && a && a < today) add('hse', r, 'Safety action overdue', a);
        if (open && s(d.formType).startsWith('Incident') && ['High', 'Critical'].includes(s(d.severity))) add('hse', r, `${s(d.severity)} incident open`, day(d.date) || today, 'open');
        break;
      }
      case 'tenders': {
        const dl = day(d.submissionDeadline); if (!dl || !['Identified', 'Preparing'].includes(s(d.status))) break;
        if (dl < today) add('tender', r, 'Tender deadline missed', dl); else if (dl <= addDays(today, 3)) add('tender', r, 'Tender due soon', dl);
        break;
      }
    }
  }
  return out;
}

export interface Member { id: string; email: string; role: string }
export interface NotifyStore {
  listOrgs(): Promise<Array<{ id: string; name: string }>>;
  listMembers(orgId: string): Promise<Member[]>;
  listAllRecords(orgId: string): Promise<Rec[]>;
  markNotified(orgId: string, key: string): Promise<boolean>;          // true only the first time a key is seen
  listPushSubs(orgId: string, userId: string): Promise<Array<{ endpoint: string; keys: { p256dh: string; auth: string } }>>;
  deletePushSub(endpoint: string): Promise<void>;
  getSetting(key: string): Promise<unknown>;
}
export interface Deps {
  store: NotifyStore; mailer?: { sendMail(m: Mail): Promise<void> } | null; push?: { send(s: PushSubscription, m: { title: string; body: string; url?: string; tag?: string }): Promise<PushResult> } | null;
  canRead: (role: string, module: string) => boolean; appName?: string; appUrl?: string; now?: () => Date; log?: (msg: string) => void;
}
export interface DigestStats { orgs: number; newAlerts: number; emails: number; pushes: number; failures: number }

const esc = (t: string) => t.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] as string));

export class Notifier {
  d: Deps;
  constructor(d: Deps) { this.d = d; }
  get name() { return this.d.appName || 'Contractor Pro'; }

  async accountErased(email: string, scope: 'workspace' | 'account'): Promise<void> {
    if (!this.d.mailer) return;
    const what = scope === 'workspace' ? 'Your workspace and all of its data have been permanently erased.' : 'Your login has been permanently erased.';
    await this.d.mailer.sendMail({ to: email, subject: `${this.name}: your data was erased`, text: `${what}\n\nThis cannot be undone. If you did not request this, contact support immediately.` });
  }

  async runDigest(): Promise<DigestStats> {
    const st: DigestStats = { orgs: 0, newAlerts: 0, emails: 0, pushes: 0, failures: 0 };
    const today = (this.d.now?.() ?? new Date()).toISOString().slice(0, 10);
    for (const org of await this.d.store.listOrgs()) {
      st.orgs++;
      const alerts = collectAlerts(await this.d.store.listAllRecords(org.id), today), fresh: Alert[] = [];
      for (const a of alerts) if (await this.d.store.markNotified(org.id, a.key)) fresh.push(a);
      if (!fresh.length) continue;
      st.newAlerts += fresh.length;
      for (const m of await this.d.store.listMembers(org.id)) {
        const mine = fresh.filter(a => this.d.canRead(m.role, a.module)); if (!mine.length) continue;
        const prefs = ((await this.d.store.getSetting('notify:' + m.id)) as { email?: boolean; push?: boolean } | null) || {};
        if (this.d.mailer && prefs.email !== false) {
          try {
            await this.d.mailer.sendMail({ to: m.email, subject: `${this.name}: ${mine.length} new alert${mine.length > 1 ? 's' : ''} for ${org.name}`,
              text: mine.map(a => `• ${a.title} (${a.due})`).join('\n') + (this.d.appUrl ? `\n\nOpen the app: ${this.d.appUrl}` : ''),
              html: `<p>${mine.length} new alert(s) for <b>${esc(org.name)}</b>:</p><ul>${mine.map(a => `<li>${esc(a.title)} <small>(${esc(a.due)})</small></li>`).join('')}</ul>` });
            st.emails++;
          } catch (e) { st.failures++; this.d.log?.(`digest mail to member failed: ${(e as Error).message}`); }
        }
        if (this.d.push && prefs.push !== false) {
          for (const sub of await this.d.store.listPushSubs(org.id, m.id)) {
            try {
              const r = await this.d.push.send(sub, { title: `${this.name}: ${mine.length} new alert${mine.length > 1 ? 's' : ''}`, body: mine.slice(0, 3).map(a => a.title).join(' · '), url: this.d.appUrl, tag: 'cp-digest' });
              if (r.ok) st.pushes++; else { st.failures++; if (r.gone) await this.d.store.deletePushSub(sub.endpoint); }
            } catch (e) { st.failures++; this.d.log?.(`push failed: ${(e as Error).message}`); }
          }
        }
      }
    }
    return st;
  }
}
