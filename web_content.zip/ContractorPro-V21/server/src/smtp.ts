// Minimal, dependency-free SMTP client (RFC 5321/5322/3207/4954). Implicit TLS (465), STARTTLS (587) or plain (tests / local relay).
import net from 'node:net';
import tls from 'node:tls';
import { randomUUID } from 'node:crypto';

export interface SmtpConfig {
  host: string; port: number; secure?: boolean;            // secure=true → implicit TLS
  starttls?: boolean;                                      // default: true unless secure or host is localhost-style plain relay
  user?: string; pass?: string; from: string;              // from: "Name <addr@x>" or "addr@x"
  rejectUnauthorized?: boolean; timeoutMs?: number; heloName?: string;
}
export interface Mail { to: string | string[]; subject: string; text: string; html?: string; replyTo?: string }

const ADDR = /^[^\s@<>"',;]{1,64}@[^\s@<>"',;]{1,255}\.[^\s@<>"',;]{2,}$/;
const noCrlf = (s: string, what: string) => { if (/[\r\n\0]/.test(s)) throw new Error(`illegal characters in ${what}`); return s; };
export function bareAddress(a: string): string {
  noCrlf(a, 'address');                       // check the WHOLE input first: a CR/LF before an <addr> must not be silently dropped
  const m = /<([^<>]+)>\s*$/.exec(a); const addr = (m ? m[1]! : a).trim();
  if (!ADDR.test(addr)) throw new Error('invalid email address: ' + addr.replace(/[^\x20-\x7e]/g, '?'));
  return addr;
}
const encWord = (s: string) => /^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${Buffer.from(s, 'utf8').toString('base64')}?=`;
function displayFrom(from: string): string {
  const m = /^(.*?)\s*<([^<>]+)>$/.exec(from.trim());
  return m && m[1].trim() ? `${encWord(noCrlf(m[1].trim().replace(/^"|"$/g, ''), 'from name'))} <${bareAddress(m[2])}>` : bareAddress(from);
}
const b64Lines = (b: Buffer) => (b.toString('base64').match(/.{1,76}/g) || ['']).join('\r\n');

export function buildMessage(cfg: Pick<SmtpConfig, 'from' | 'heloName'>, m: Mail, now = new Date()): string {
  const to = (Array.isArray(m.to) ? m.to : [m.to]).map(bareAddress);
  if (!to.length) throw new Error('no recipients');
  const domain = bareAddress(cfg.from).split('@')[1];
  const h = [
    `From: ${displayFrom(cfg.from)}`, `To: ${to.join(', ')}`, `Subject: ${encWord(noCrlf(m.subject, 'subject'))}`,
    `Date: ${now.toUTCString().replace('GMT', '+0000')}`, `Message-ID: <${randomUUID()}@${domain}>`, 'MIME-Version: 1.0', 'Auto-Submitted: auto-generated'
  ];
  if (m.replyTo) h.push(`Reply-To: ${bareAddress(m.replyTo)}`);
  let body: string;
  if (m.html) {
    const bd = 'cp_' + randomUUID().replace(/-/g, '');
    h.push(`Content-Type: multipart/alternative; boundary="${bd}"`);
    body = `--${bd}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${b64Lines(Buffer.from(m.text, 'utf8'))}\r\n` +
           `--${bd}\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${b64Lines(Buffer.from(m.html, 'utf8'))}\r\n--${bd}--`;
  } else {
    h.push('Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64');
    body = b64Lines(Buffer.from(m.text, 'utf8'));
  }
  return h.join('\r\n') + '\r\n\r\n' + body;     // base64 bodies contain no leading dots, so no dot-stuffing is ever needed
}

class Conn {
  buf = ''; waiters: Array<() => void> = []; err: Error | null = null; sock: net.Socket;
  constructor(sock: net.Socket) {
    this.sock = sock;
    sock.setEncoding('utf8');
    sock.on('data', (d: string) => { this.buf += d; this.wake(); });
    sock.on('error', (e: Error) => { this.err = e; this.wake(); });
    sock.on('close', () => { this.err = this.err || new Error('connection closed'); this.wake(); });
  }
  wake() { const w = this.waiters; this.waiters = []; w.forEach(f => f()); }
  /** Reads one complete (possibly multi-line) reply. */
  async reply(timeoutMs: number): Promise<{ code: number; lines: string[] }> {
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const lines = this.buf.split('\r\n');
      let end = -1;
      for (let i = 0; i < lines.length - 1; i++) if (/^\d{3} /.test(lines[i]) || /^\d{3}$/.test(lines[i])) { end = i; break; }
      if (end >= 0) { const got = lines.slice(0, end + 1); this.buf = lines.slice(end + 1).join('\r\n'); return { code: Number(got[end].slice(0, 3)), lines: got.map(l => l.slice(4)) }; }
      if (this.err) throw this.err;
      const left = deadline - Date.now(); if (left <= 0) throw new Error('SMTP timeout');
      await new Promise<void>((res, rej) => { const t = setTimeout(() => rej(new Error('SMTP timeout')), left); this.waiters.push(() => { clearTimeout(t); res(); }); });
    }
  }
  write(s: string) { this.sock.write(s); }
}

export async function sendSmtp(cfg: SmtpConfig, m: Mail): Promise<void> {
  const to = (Array.isArray(m.to) ? m.to : [m.to]).map(bareAddress), from = bareAddress(cfg.from), T = cfg.timeoutMs ?? 15000;
  const data = buildMessage(cfg, m);
  const opts = { host: cfg.host, port: cfg.port, rejectUnauthorized: cfg.rejectUnauthorized !== false, servername: cfg.host };
  let conn = new Conn(await new Promise<net.Socket>((res, rej) => {
    const s: net.Socket = cfg.secure ? tls.connect(opts, () => res(s)) : net.connect({ host: cfg.host, port: cfg.port }, () => res(s));
    s.once('error', rej); s.setTimeout(T, () => s.destroy(new Error('SMTP connect timeout')));
  }));
  const cmd = async (line: string, ok: number[]) => { conn.write(line + '\r\n'); const r = await conn.reply(T); if (!ok.includes(r.code)) throw new Error(`SMTP ${r.code} after ${line.split(' ')[0]}: ${r.lines.join(' ').slice(0, 200)}`); return r; };
  try {
    const hello = await conn.reply(T); if (hello.code !== 220) throw new Error('SMTP greeting ' + hello.code);
    const name = cfg.heloName || 'contractor-pro.local';
    let ehlo = await cmd(`EHLO ${name}`, [250]);
    const wantTls = !cfg.secure && cfg.starttls !== false && ehlo.lines.some(l => /^STARTTLS$/i.test(l));
    if (!cfg.secure && cfg.starttls === true && !wantTls) throw new Error('server does not offer STARTTLS');
    if (wantTls) {
      await cmd('STARTTLS', [220]);
      const upgraded = tls.connect({ socket: conn.sock, ...opts });
      await new Promise<void>((res, rej) => { upgraded.once('secureConnect', () => res()); upgraded.once('error', rej); });
      conn = new Conn(upgraded); ehlo = await cmd(`EHLO ${name}`, [250]);
    }
    if (cfg.user) {
      const mech = ehlo.lines.find(l => /^AUTH\s/i.test(l)) || '';
      if (!cfg.secure && !wantTls && cfg.host !== '127.0.0.1' && cfg.host !== 'localhost') throw new Error('refusing to send credentials over an unencrypted connection');
      if (/\bPLAIN\b/i.test(mech)) await cmd('AUTH PLAIN ' + Buffer.from(`\0${cfg.user}\0${cfg.pass ?? ''}`).toString('base64'), [235]);
      else if (/\bLOGIN\b/i.test(mech)) { await cmd('AUTH LOGIN', [334]); await cmd(Buffer.from(cfg.user).toString('base64'), [334]); await cmd(Buffer.from(cfg.pass ?? '').toString('base64'), [235]); }
      else throw new Error('server offers no supported AUTH mechanism');
    }
    await cmd(`MAIL FROM:<${from}>`, [250]);
    for (const r of to) await cmd(`RCPT TO:<${r}>`, [250, 251]);
    await cmd('DATA', [354]);
    conn.write(data + '\r\n.\r\n'); const done = await conn.reply(T);
    if (done.code !== 250) throw new Error(`SMTP ${done.code} after DATA: ${done.lines.join(' ').slice(0, 200)}`);
    try { await cmd('QUIT', [221]); } catch { /* server may close first */ }
  } finally { conn.sock.destroy(); }
}

/** Mailer with the interface app.js expects (send(email, code) for OTP) plus sendMail for everything else. Retries transient 4xx/network failures. */
export class SmtpMailer {
  mode = 'smtp'; cfg: SmtpConfig; retries: number; sleep: (ms: number) => Promise<void>;
  constructor(cfg: SmtpConfig, retries = 2, sleep: (ms: number) => Promise<void> = (ms) => new Promise<void>(r => setTimeout(r, ms))) {
    this.cfg = cfg; this.retries = retries; this.sleep = sleep;
  }
  async sendMail(m: Mail): Promise<void> {
    let last: unknown;
    for (let i = 0; i <= this.retries; i++) {
      try { return await sendSmtp(this.cfg, m); }
      catch (e) { last = e; const msg = String((e as Error).message); if (/SMTP 5\d\d/.test(msg) || /illegal|invalid email|no recipients|refusing/.test(msg)) break; await this.sleep(500 * 2 ** i); }
    }
    throw last;
  }
  async send(email: string, code: string): Promise<void> {
    await this.sendMail({ to: email, subject: 'Your Contractor Pro sign-in code', text: `Your sign-in code is ${code}. It expires in 10 minutes. If you did not request it, ignore this email.`,
      html: `<p>Your sign-in code is <b style="font-size:20px;letter-spacing:3px">${code}</b></p><p>It expires in 10 minutes. If you did not request it, ignore this email.</p>` });
  }
}
