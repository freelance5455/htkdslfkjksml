// Binary storage for photos/files. DiskBlobStore keeps files under FILES_DIR/<orgId>/<fileId> (mount a persistent volume there).
// Swap for an S3-compatible implementation with the same 4 methods when you outgrow one disk.
import fs from 'node:fs/promises'; import path from 'node:path';
const SAFE = /^[0-9a-f-]{36}$/;
const chk = (...ids) => { for (const i of ids) if (!SAFE.test(i)) throw new Error('bad id'); };

export class MemoryBlobStore {
  m = new Map();
  async put(org, id, buf) { chk(org, id); this.m.set(org + '/' + id, Buffer.from(buf)); }
  async get(org, id) { chk(org, id); const b = this.m.get(org + '/' + id); if (!b) throw Object.assign(new Error('missing'), { code: 'ENOENT' }); return b; }
  async del(org, id) { chk(org, id); this.m.delete(org + '/' + id); }
}

export class DiskBlobStore {
  constructor(dir) { this.dir = path.resolve(dir); }
  p(org, id) { chk(org, id); return path.join(this.dir, org, id); }
  async put(org, id, buf) { const f = this.p(org, id); await fs.mkdir(path.dirname(f), { recursive: true }); const tmp = f + '.tmp'; await fs.writeFile(tmp, buf, { mode: 0o600 }); await fs.rename(tmp, f); }
  async get(org, id) { return fs.readFile(this.p(org, id)); }
  async del(org, id) { await fs.rm(this.p(org, id), { force: true }); }
}

// Only these types are accepted, and the real bytes must match the claimed type (a renamed .exe is refused).
export function sniff(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf.subarray(0, 5).toString('latin1') === '%PDF-') return 'application/pdf';
  return null;
}
