// Legacy plain-JS modules are imported from TypeScript as untyped.
declare module '*.js';
