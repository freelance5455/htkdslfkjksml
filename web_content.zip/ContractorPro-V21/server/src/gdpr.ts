// GDPR Art. 15/20 (access, portability) and Art. 17 (erasure) — server side.
// Pure orchestration over the store/blob interfaces so it is identical for MemoryStore and PgStore.

export interface Ctx { user: { id: string; email: string }; orgId: string; role: string }

export interface GdprStore {
  getUserById(id: string): Promise<{ id: string; email: string; emailVerified?: boolean } | null>;
  getOrg(orgId: string): Promise<{ id: string; name: string; createdAt?: string } | null>;
  listMembers(orgId: string): Promise<Array<{ id: string; email: string; role: string }>>;
  listAllRecords(orgId: string): Promise<unknown[]>;
  latestSnapshot(orgId: string): Promise<{ cursor: number; data: unknown } | null>;
  getSubscription(orgId: string): Promise<unknown>;
  listPayments(orgId: string): Promise<Array<Record<string, unknown>>>;
  listSignatures(orgId: string): Promise<unknown[]>;
  allFiles(orgId: string): Promise<Array<{ id: string }>>;
  allAudit(orgId: string): Promise<Array<Record<string, unknown>>>;
  deleteOrgCascade(orgId: string): Promise<{ users: number }>;
  deleteUserOnly(orgId: string, userId: string): Promise<boolean>;
}
export interface GdprBlobs { del(org: string, id: string): Promise<void> }

export const EXPORT_FORMAT = 'contractor-pro-account-export/1';
const OWNER_ONLY_PAYMENT_FIELDS = ['providerRef', 'address'];

/** Everything we hold about the caller. Members get their own data; the owner gets the whole workspace. */
export async function buildExport(store: GdprStore, c: Ctx, now = new Date()): Promise<Record<string, unknown>> {
  const user = await store.getUserById(c.user.id);
  if (!user) throw new Error('user not found');
  const base: Record<string, unknown> = {
    format: EXPORT_FORMAT, generatedAt: now.toISOString(), scope: c.role === 'owner' ? 'workspace' : 'personal',
    account: { id: user.id, email: user.email, emailVerified: !!user.emailVerified, role: c.role, workspaceId: c.orgId }
  };
  const mine = (await store.allAudit(c.orgId)).filter(a => a.userId === c.user.id)
    .map(a => ({ at: a.at, action: a.action, module: a.module, recordId: a.recordId, details: a.details, ip: a.ip }));
  base.activityLog = mine;
  if (c.role !== 'owner') return base;           // workspace content belongs to the workspace owner (the controller of that data)
  const org = await store.getOrg(c.orgId);
  base.workspace = org && { id: org.id, name: org.name, createdAt: org.createdAt ?? null };
  base.members = await store.listMembers(c.orgId);
  base.records = await store.listAllRecords(c.orgId);
  base.latestSnapshot = (await store.latestSnapshot(c.orgId))?.data ?? null;
  base.subscription = await store.getSubscription(c.orgId);
  base.payments = (await store.listPayments(c.orgId)).map(p => { const q = { ...p }; for (const k of OWNER_ONLY_PAYMENT_FIELDS) delete q[k]; return q; });
  base.signatures = (await store.listSignatures(c.orgId)).map(s => { const { image: _img, ...rest } = s as Record<string, unknown>; return { ...rest, hasImage: !!_img }; });
  base.files = await store.allFiles(c.orgId);
  base.auditLog = await store.allAudit(c.orgId);
  return base;
}

export interface EraseResult { scope: 'workspace' | 'account'; users: number; files: number }

/** Owner: erases the whole workspace (all members, records, files, billing). Anyone else: erases only their own login. */
export async function eraseAccount(store: GdprStore, blobs: GdprBlobs, c: Ctx): Promise<EraseResult> {
  if (c.role !== 'owner') {
    const ok = await store.deleteUserOnly(c.orgId, c.user.id);
    return { scope: 'account', users: ok ? 1 : 0, files: 0 };
  }
  const files = await store.allFiles(c.orgId);
  // Bytes first: if the process dies half way the DB rows still exist and the request can simply be repeated.
  for (const f of files) await blobs.del(c.orgId, f.id);
  const { users } = await store.deleteOrgCascade(c.orgId);
  return { scope: 'workspace', users, files: files.length };
}

export const ERASE_PHRASE = 'DELETE MY ACCOUNT';
