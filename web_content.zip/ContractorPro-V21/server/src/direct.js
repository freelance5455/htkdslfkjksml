// "Direct wallet" crypto payments: the customer pays to the operator's own address, the operator confirms on-chain.
// Safety rules: (1) only the OPERATOR (secret token) can mark an invoice paid, never the customer; (2) every invoice gets a
// unique amount so a payment can be matched to exactly one invoice; (3) confirming applies the subscription through the same
// idempotent completePayment() used by BTCPay/NOWPayments.
import { createHash, timingSafeEqual } from 'node:crypto';

export const DIRECT_CURRENCIES = ['btc', 'usdt'];
const ADDR = { btc: /^(bc1[a-z0-9]{20,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,39})$/, usdt: /^(T[1-9A-HJ-NP-Za-km-z]{33}|0x[0-9a-fA-F]{40})$/ };

export function parseDirect(env) {
  const wallets = {};
  for (const c of DIRECT_CURRENCIES) {
    const v = String(env['DIRECT_' + c.toUpperCase() + '_ADDRESS'] || '').trim();
    if (!v) continue;
    if (!ADDR[c].test(v)) throw new Error(`DIRECT_${c.toUpperCase()}_ADDRESS is not a valid ${c.toUpperCase()} address`);
    wallets[c] = v;
  }
  const operatorToken = String(env.OPERATOR_TOKEN || '');
  if (Object.keys(wallets).length && operatorToken.length < 24) throw new Error('OPERATOR_TOKEN (>=24 chars) is required when a direct wallet address is set');
  return Object.keys(wallets).length ? { wallets, operatorToken, usdtNetwork: String(env.DIRECT_USDT_NETWORK || (wallets.usdt?.startsWith('T') ? 'TRC20' : 'ERC20')) } : null;
}

export function tokenOk(given, expected) {
  if (!expected || expected.length < 24 || typeof given !== 'string') return false;
  const a = createHash('sha256').update(given).digest(), b = createHash('sha256').update(expected).digest();
  return timingSafeEqual(a, b);
}

// Adds a small unique offset (USDT: 0.0001 steps up to 0.0999, BTC: 1-999 satoshi) not used by another open invoice.
export function uniqueAmount(currency, baseAmount, taken, rnd = Math.random) {
  const used = new Set([...taken].map(x => Number(x).toFixed(8)));
  for (let i = 0; i < 2000; i++) {
    const n = 1 + Math.floor(rnd() * 999);
    const amt = currency === 'usdt' ? Math.round((baseAmount + n * 1e-4) * 1e6) / 1e6 : Math.round((baseAmount * 1e8 + n)) / 1e8;
    if (!used.has(amt.toFixed(8))) return amt;
  }
  throw new Error('No free unique amount; try again later');
}
