# web/ layout (V20 refactor)

Behaviour is identical to the previous single-file `index.html`; only the file layout changed.
All scripts are classic (non-module) scripts, so the app still works from `file://`, offline and inside Capacitor.
**Load order in `index.html` matters** (same global scope as before):

1. `js/i18n/dict-*.js`, `js/i18n/ui-labels.js` – translation data (`window.CP_I18N`, global `I`)
2. `js/core|views|features/*.js` – function declarations grouped by topic (hoisted, order between them is irrelevant)
3. `js/config.js`, `js/form-schema.js`, `js/i18n/labels-*.js`, `js/app-state.js`, `js/features/*-ui.js`, `js/pwa-icon.js`, `js/overrides.js` – top-level statements in their original execution order
4. `js/splash.js`, `js/server-services.js`, `js/quick-estimate.js`, `js/i18n/runtime.js`

`css/` holds the two stylesheets, `img/splash.jpg` the splash artwork (was inline base64).
`sw.js` precaches this file list (cache name `cp-v20-2`); update `SHELL` when adding files.
