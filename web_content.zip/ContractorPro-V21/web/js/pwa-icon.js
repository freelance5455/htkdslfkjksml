"use strict";
(function(){try{
 var base=new URL('img/',location.href).href;
 var mf={name:'Contractor Pro',short_name:'Contractor',start_url:'.',display:'standalone',background_color:'#0a0a0a',theme_color:'#0a0a0a',icons:[
  {src:base+'icon-192.png',sizes:'192x192',type:'image/png',purpose:'any'},
  {src:base+'icon-512.png',sizes:'512x512',type:'image/png',purpose:'any'},
  {src:base+'icon-512-maskable.png',sizes:'512x512',type:'image/png',purpose:'maskable'}]};
 if(location.protocol==='http:'||location.protocol==='https:'){var l=document.createElement('link');l.rel='manifest';l.href=URL.createObjectURL(new Blob([JSON.stringify(mf)],{type:'application/manifest+json'}));document.head.appendChild(l);
  if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(function(){})}
 var ic=document.createElement('link');ic.rel='icon';ic.type='image/png';ic.href=base+'icon-192.png';document.head.appendChild(ic)}catch(e){}})();
