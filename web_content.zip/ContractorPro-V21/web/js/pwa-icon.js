"use strict";
(function(){try{
 var icon="data:image/svg+xml,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="96" fill="#0f766e"/><path d="M96 380V252l160-112 160 112v128H96z" fill="#fff"/><rect x="216" y="280" width="80" height="100" fill="#0f766e"/></svg>');
 var mf={name:'Contractor Pro',short_name:'Contractor',start_url:'.',display:'standalone',background_color:'#ffffff',theme_color:'#0f766e',icons:[{src:icon,sizes:'any',type:'image/svg+xml',purpose:'any maskable'}]};
 if(location.protocol==='http:'||location.protocol==='https:'){var l=document.createElement('link');l.rel='manifest';l.href=URL.createObjectURL(new Blob([JSON.stringify(mf)],{type:'application/manifest+json'}));document.head.appendChild(l);
  if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(function(){})}
 var ic=document.createElement('link');ic.rel='icon';ic.href=icon;document.head.appendChild(ic)}catch(e){}})();
