"use strict";
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeForm()});

(function(){
 const cs=[["", "baseCurrency"]].concat(CURS.map(c=>[c,c]));
 const has=(id,k)=>F[id].some(f=>f[0]===k);
 const add=(id,after,fields)=>{const i=F[id].findIndex(f=>f[0]===after);F[id].splice(i<0?F[id].length:i+1,0,...fields.filter(f=>!has(id,f[0])))};
 add("invoices","amount",[["currency","s","currency",cs],["taxPercent","n","taxPercent"],["retentionPercent","n","retentionPercent"],["withholdingPercent","n","withholdingPercent"]]);
 add("contracts","amount",[["currency","s","currency",cs]]);
 add("finance","amount",[["currency","s","currency",cs]]);
 ["taxAmount","retentionAmount","withholdingAmount","netPayable","invoiceTotal","subtotal","total","markupAmount"].forEach(k=>{if(!MONEY.includes(k))MONEY.push(k)});
})();

const FX_WARN=new Set();

(function(){const _rd=renderDashboard;renderDashboard=function(){FX_WARN.clear();_rd.apply(this,arguments);showFxWarn()}})();

['click','touchstart','keydown'].forEach(ev=>document.addEventListener(ev,()=>{if(d&&d.security&&d.security.appLockEnabled&&d.security.lastUnlockAt)d.security.lastActivityAt=Date.now()},{passive:true}));

$("lang").onchange=e=>onLanguageChange(e.target.value);

$("country").onchange=e=>onCountryChange(e.target.value);

$("calendar").onchange=onSetting("calendar");

$("currency").onchange=e=>{d.currency=e.target.value;d.currencyMode="manual";persist();apply();if(cur()!=="dashboard")route(cur())};

$("timezone").onchange=onSetting("timezone");

setInterval(updateClock,1000);

cp16EnsureSmart();

cp17EnsureSecurity();

persist();

apply();
