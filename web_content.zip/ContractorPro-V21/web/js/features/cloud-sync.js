"use strict";
function cp12EnsureDeviceId(){
 if(!d.sync)d.sync={};
 if(!d.sync.deviceId){d.sync.deviceId="device-"+uid();persist();}
 return d.sync.deviceId;
}

function cp12SyncStatus(){
 var q=d.sync||{};
 if(q.status==="synced")return "Synced";
 if(q.status==="error")return "Error";
 if(q.enabled)return "Cloud ready · "+(Number(q.pending)||0)+" pending";
 return "Offline · local data only";
}

function cp12CloudView(){
 var q=d.sync||{};cp12EnsureDeviceId();q=d.sync;
 return '<div class="card cp12-cloud"><h3>☁️ Cloud &amp; Sync</h3>'+
 '<p class="muted">Offline-first synchronization layer. Your data continues to work on this device. Real cloud transfer requires a secure Contractor Pro server endpoint; this build does not pretend that a local action is an online sync.</p>'+
 '<div class="formgrid">'+
 '<div class="field"><label>Cloud sync</label><select id="cp12SyncEnabled"><option value="false"'+(!q.enabled?' selected':'')+'>Off / Offline</option><option value="true"'+(q.enabled?' selected':'')+'>Ready for cloud sync</option></select></div>'+
 '<div class="field"><label>Server endpoint</label><input id="cp12Endpoint" value="'+esc(q.endpoint||'')+'" maxlength="500" placeholder="https://api.example.com/sync"></div>'+
 '<div class="field"><label>Device ID</label><input value="'+esc(q.deviceId||'')+'" readonly></div>'+ 
 '<div class="field"><label>Pending changes</label><input value="'+fmtNum(Number(q.pending)||0)+'" readonly></div>'+ 
 '</div>'+ 
 '<div class="actions"><button class="btn" onclick="cp12SaveCloud()">Save Cloud Settings</button><button class="btn alt" onclick="cp12PrepareSync()">Prepare Sync</button><button class="btn alt" onclick="cp12ExportSnapshot()">Export Sync Snapshot</button><button class="btn alt" onclick="cp12ImportSnapshot()">Restore Snapshot</button></div>'+
 '<div class="notice" id="cp12CloudStatus">Status: '+esc(cp12SyncStatus())+(q.lastSyncAt?' · Last sync: '+esc(fmtDate(q.lastSyncAt,true)):'')+'</div>'+
 '<div class="mini">Schema: V12 · Device: '+esc(q.deviceId||'')+(q.lastSnapshotAt?' · Snapshot: '+esc(fmtDate(q.lastSnapshotAt,true)):'')+'</div></div>';
}

function cp12SaveCloud(){
 d.sync=d.sync||{};d.sync.enabled=$('cp12SyncEnabled')&&$('cp12SyncEnabled').value==='true';d.sync.endpoint=$('cp12Endpoint')?$('cp12Endpoint').value.trim().slice(0,500):'';d.sync.status=d.sync.enabled?(d.sync.endpoint?'ready':'offline'):'offline';d.sync.lastError="";cp12EnsureDeviceId();persist();route(cur());
}

function cp12PrepareSync(){
 d.sync=d.sync||{};cp12EnsureDeviceId();d.sync.pending=Math.max(0,Number(d.sync.pending)||0);d.sync.status=d.sync.endpoint?'ready':'offline';d.sync.lastError=d.sync.endpoint?'':'No server endpoint configured. Local changes remain safely stored on this device.';persist();route(cur());
 if(d.sync.endpoint) alert('Sync package is ready. Real upload will be enabled when the Contractor Pro backend endpoint is deployed and authenticated.'); else alert('Cloud is not connected yet. Your data remains offline and the sync queue is preserved.');
}

function cp12ExportSnapshot(){
 cp12EnsureDeviceId();var payload={contractorPro:"V12",schemaVersion:1,deviceId:d.sync.deviceId,exportedAt:new Date().toISOString(),data:d};var blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});var url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="contractor-pro-v12-sync-snapshot.json";document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url)},1000);d.sync.lastSnapshotAt=new Date().toISOString();persist();
}

function cp12ImportSnapshot(){
 var input=document.createElement("input");input.type="file";input.accept="application/json,.json";input.onchange=function(){var file=input.files&&input.files[0];if(!file)return;var r=new FileReader();r.onload=function(){try{var x=JSON.parse(r.result);if(!x||x.contractorPro!=="V12"||!x.data||typeof x.data!=="object")throw Error();merge(d,x.data);d.sync=d.sync||{};d.sync.lastSnapshotAt=new Date().toISOString();d.sync.status="restored";persist();apply();route(cur());alert('Snapshot restored on this device.');}catch(e){alert('Invalid Contractor Pro sync snapshot.')}};r.readAsText(file)};input.click();
}
