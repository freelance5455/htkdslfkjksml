"use strict";
function ganttChartHTML(){
 const rows=(d.projects||[]).filter(p=>p.startDate&&p.endDate&&!isNaN(new Date(p.startDate))&&!isNaN(new Date(p.endDate)));
 if(!rows.length) return '';
 const starts=rows.map(p=>new Date(p.startDate).getTime());
 const ends=rows.map(p=>new Date(p.endDate).getTime());
 const minT=Math.min(...starts), maxT=Math.max(...ends);
 const span=Math.max(1,maxT-minT);
 const todayPct=Math.min(100,Math.max(0,((Date.now()-minT)/span)*100));
 const bars=rows.map(p=>{
   const s=new Date(p.startDate).getTime(), e=new Date(p.endDate).getTime();
   const left=((s-minT)/span)*100, width=Math.max(1,((e-s)/span)*100);
   const done=p.status==='completed';
   const color=done?'var(--ok)':'var(--primary)';
   return `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
     <div style="width:120px;flex:0 0 120px;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.name||'')}">${esc(p.name||'')}</div>
     <div style="position:relative;flex:1;height:18px;background:var(--line);border-radius:4px">
       <div style="position:absolute;top:0;bottom:0;left:${left}%;width:${width}%;background:${color};border-radius:4px;min-width:3px" title="${esc(fmtDate(p.startDate))} → ${esc(fmtDate(p.endDate))}"></div>
     </div>
   </div>`;
 }).join('');
 return `<div class="card" style="margin-bottom:14px"><h3>📊 ${esc('Gantt')}</h3>
   <div style="position:relative">
     <div style="position:absolute;top:0;bottom:0;left:${todayPct}%;width:1px;background:var(--danger);z-index:1"></div>
     ${bars}
   </div>
   <div class="muted" style="font-size:11px;margin-top:4px">${esc(fmtDate(new Date(minT).toISOString().slice(0,10)))} — ${esc(fmtDate(new Date(maxT).toISOString().slice(0,10)))} · <span style="color:var(--danger)">│</span> ${esc('today')}</div>
 </div>`;
}

function cpDay(s){var m=/^(\d{4})-(\d{2})-(\d{2})/.exec(String(s||''));return m?Date.UTC(+m[1],+m[2]-1,+m[3])/DAYMS:null}

function cpIso(n){return new Date(n*DAYMS).toISOString().slice(0,10)}

function taskDuration(x){var dur=Number(x.durationDays);if(dur>0)return Math.round(dur);var s=cpDay(x.startDate),e=cpDay(x.dueDate);if(s!=null&&e!=null&&e>=s)return e-s+1;return 1}

function computeCPM(tasks){
 if(!tasks||!tasks.length)return {ok:false,cycle:[],tasks:{},finish:null,critical:[],empty:true};
 var by={},order=[];tasks.forEach(function(x){by[x.id]=x;order.push(x.id)});
 var preds={},succ={};order.forEach(function(id){preds[id]=[];succ[id]=[]});
 order.forEach(function(id){var x=by[id],lag=Math.round(Number(x.lagDays)||0);[x.predecessor,x.predecessor2].forEach(function(p){if(p&&by[p]&&p!==id&&preds[id].every(function(q){return q.id!==p})){preds[id].push({id:p,lag:lag});succ[p].push({id:id,lag:lag})}})});
 // topological order (Kahn); leftovers = cycle
 var indeg={},q=[],topo=[];order.forEach(function(id){indeg[id]=preds[id].length;if(!indeg[id])q.push(id)});
 while(q.length){var u=q.shift();topo.push(u);succ[u].forEach(function(s){if(--indeg[s.id]===0)q.push(s.id)})}
 var cycle=order.filter(function(id){return topo.indexOf(id)<0});
 if(cycle.length)return {ok:false,cycle:cycle,tasks:{},finish:null,critical:[]};
 var anchor=null;order.forEach(function(id){var s=cpDay(by[id].startDate);if(s!=null&&(anchor==null||s<anchor))anchor=s});
 if(anchor==null){order.forEach(function(id){var e=cpDay(by[id].dueDate);if(e!=null&&(anchor==null||e<anchor))anchor=e-taskDuration(by[id])+1})}
 if(anchor==null)anchor=Math.floor(Date.now()/DAYMS);
 var r={};
 topo.forEach(function(id){var x=by[id],dur=taskDuration(x),es=0,fixed=cpDay(x.startDate);if(fixed!=null)es=fixed-anchor;
  preds[id].forEach(function(p){var c=r[p.id].ef+1+p.lag;if(c>es)es=c});   // ef is the last working day (inclusive)
  r[id]={dur:dur,es:es,ef:es+dur-1}});
 var finish=Math.max.apply(null,topo.map(function(id){return r[id].ef}));
 topo.slice().reverse().forEach(function(id){var lf=finish;succ[id].forEach(function(s){var c=r[s.id].ls-1-s.lag;if(c<lf)lf=c});r[id].lf=lf;r[id].ls=lf-r[id].dur+1;r[id].float=r[id].ls-r[id].es;r[id].critical=r[id].float<=0});
 var out={};order.forEach(function(id){var v=r[id];out[id]={es:v.es,ef:v.ef,ls:v.ls,lf:v.lf,float:v.float,critical:v.critical,start:cpIso(anchor+v.es),end:cpIso(anchor+v.ef),dur:v.dur}});
 return {ok:true,cycle:[],tasks:out,anchor:cpIso(anchor),finish:cpIso(anchor+finish),duration:finish+1,critical:order.filter(function(id){return r[id].critical})};
}

function computeEVM(project,tasks,actualCost,asOf){
 var bac=Number(project.budget)||0,asOfD=cpDay(asOf)==null?Math.floor(Date.now()/DAYMS):cpDay(asOf);
 var cp=computeCPM(tasks),sw=0,sp=0,se=0;
 tasks.forEach(function(x){
  var w=Number(x.plannedCost)>0?Number(x.plannedCost):taskDuration(x);sw+=w;
  var bs=cpDay(x.baselineStart),be=cpDay(x.baselineEnd);
  if(bs==null||be==null){var c=cp.ok&&cp.tasks[x.id];if(c){bs=cpDay(c.start);be=cpDay(c.end)}else{bs=cpDay(x.startDate);be=cpDay(x.dueDate)}}
  var planned=0;if(bs!=null&&be!=null){planned=asOfD>=be?1:asOfD<bs?0:(asOfD-bs+1)/(be-bs+1)}
  var pc=x.status==='done'?100:Math.max(0,Math.min(100,Number(x.percentComplete)||0));
  sp+=w*planned;se+=w*pc/100});
 if(!sw)return {ok:false,reason:'no-tasks',bac:bac};
 var pv=bac*sp/sw,ev=bac*se/sw,ac=Number(actualCost)||0;
 var cpi=ac>0?ev/ac:null,spi=pv>0?ev/pv:null,eac=cpi?bac/cpi:null;
 return {ok:true,bac:bac,pv:pv,ev:ev,ac:ac,cv:ev-ac,sv:ev-pv,cpi:cpi,spi:spi,eac:eac,etc:eac==null?null:eac-ac,vac:eac==null?null:bac-eac,percentComplete:se/sw*100,percentPlanned:sp/sw*100,finish:cp.ok?cp.finish:null};
}

function cpmTasks(pid){return d.schedule.filter(function(x){return x.project===pid})}

function cpmCardHTML(){
 var pids=[];d.schedule.forEach(function(x){if(x.project&&pids.indexOf(x.project)<0)pids.push(x.project)});
 if(!pids.length)return '';
 if(pids.indexOf(cpmProject)<0)cpmProject=pids[0];
 var tasks=cpmTasks(cpmProject),r=computeCPM(tasks);
 var opts=pids.map(function(p){return '<option value="'+esc(p)+'"'+(p===cpmProject?' selected':'')+'>'+esc(rname('projects',p))+'</option>'}).join('');
 var head='<div class="card" style="margin-bottom:14px"><h3>🛤️ '+esc('Critical path')+'</h3><div class="field"><select onchange="cpmProject=this.value;route(cur())">'+opts+'</select></div>';
 if(!r.ok){return head+'<div class="notice">'+esc(r.cycle&&r.cycle.length?'Circular dependency between tasks:':'No tasks.')+' '+esc((r.cycle||[]).map(function(id){return rname('schedule',id)}).join(', '))+'</div></div>'}
 var span=r.duration||1,rows=tasks.slice().sort(function(a,b){return r.tasks[a.id].es-r.tasks[b.id].es}).map(function(x){
  var c=r.tasks[x.id],left=c.es/span*100,w=Math.max(1.5,c.dur/span*100),slip=x.baselineEnd?Math.round(cpDay(c.end)-cpDay(x.baselineEnd)):null;
  return '<div style="margin-bottom:8px"><div style="display:flex;justify-content:space-between;gap:8px;font-size:12px"><span>'+(c.critical?'🔴 ':'')+'<b>'+esc(x.name||'')+'</b></span><span class="muted">'+esc(fmtDate(c.start))+' → '+esc(fmtDate(c.end))+' · '+esc('Float')+': '+fmtNum(c.float)+(slip?' · '+esc('vs baseline')+': '+(slip>0?'+':'')+fmtNum(slip)+'d':'')+'</span></div><div style="position:relative;height:12px;background:var(--line);border-radius:4px"><div style="position:absolute;top:0;bottom:0;left:'+left+'%;width:'+w+'%;background:'+(c.critical?'var(--danger)':'var(--primary)')+';border-radius:4px"></div></div></div>'}).join('');
 return head+'<div class="muted" style="margin-bottom:8px">'+esc('Finish')+': <b>'+esc(fmtDate(r.finish))+'</b> · '+esc('Duration')+': <b>'+fmtNum(r.duration)+'</b> '+esc(t('subDays'))+' · '+esc('Critical tasks')+': <b>'+fmtNum(r.critical.length)+'</b></div>'+rows+'<div class="actions"><button class="btn alt" onclick="cpmSetBaseline()">'+esc('Set baseline')+'</button><button class="btn alt" onclick="cpmApplyDates()">'+esc('Apply scheduled dates')+'</button></div><div class="muted" style="font-size:11px">🔴 = '+esc('zero float: any delay moves the finish date')+'</div></div>'}

function cpmSetBaseline(){var r=computeCPM(cpmTasks(cpmProject));if(!r.ok)return;cpmTasks(cpmProject).forEach(function(x){var c=r.tasks[x.id];x.baselineStart=c.start;x.baselineEnd=c.end});persist();audit('update','schedule',cpmProject,'baseline set');route(cur())}

function cpmApplyDates(){var r=computeCPM(cpmTasks(cpmProject));if(!r.ok)return;if(!confirm(cp20T('Replace start and due dates of these tasks with the calculated schedule?')))return;cpmTasks(cpmProject).forEach(function(x){var c=r.tasks[x.id];x.startDate=c.start;x.dueDate=c.end;x.durationDays=c.dur});persist();route(cur())}

function evmCardHTML(pid,m){
 var tasks=cpmTasks(pid);if(!tasks.length)return '';
 var e=computeEVM({budget:m.budget},tasks,m.costs,today());if(!e.ok)return '';
 var cell=function(l,v,cls){return '<div class="card"><div class="muted">'+esc(l)+'</div><div class="big '+(cls||'')+'">'+v+'</div></div>'};
 var idx=function(v){return v==null?'—':(Math.round(v*100)/100).toFixed(2)};
 var cc=e.cpi==null?'':e.cpi<0.95?'dangertext':e.cpi<1?'':'ok',sc=e.spi==null?'':e.spi<0.95?'dangertext':e.spi<1?'':'ok';
 var msg=[];if(e.cpi!=null&&e.cpi<1)msg.push('Cost is running over the plan.');if(e.spi!=null&&e.spi<1)msg.push('Work is behind schedule.');if(e.cpi!=null&&e.cpi>=1&&e.spi!=null&&e.spi>=1)msg.push('On or ahead of plan.');
 return '<div class="card" style="margin-top:12px"><h3>📈 '+esc('Earned value')+'</h3><div class="grid">'+cell('BAC',money(e.bac))+cell('PV',money(e.pv))+cell('EV',money(e.ev))+cell('AC',money(e.ac))+cell('CPI',idx(e.cpi),cc)+cell('SPI',idx(e.spi),sc)+cell('EAC',e.eac==null?'—':money(e.eac),e.vac!=null&&e.vac<0?'dangertext':'')+cell('VAC',e.vac==null?'—':money(e.vac),e.vac!=null&&e.vac<0?'dangertext':'ok')+'</div><div class="muted" style="margin-top:6px">'+esc('Complete')+': <b>'+fmtNum(Math.round(e.percentComplete))+'%</b> · '+esc('Planned')+': <b>'+fmtNum(Math.round(e.percentPlanned))+'%</b></div>'+(msg.length?'<div class="notice" style="margin-top:8px">'+msg.map(esc).join(' ')+'</div>':'')+'</div>'}

function scheduleView(){const arr=[...d.schedule].sort((a,b)=>String(a.dueDate||'').localeCompare(String(b.dueDate||'')));const now=new Date();return `<div class="actions"><button class="btn" onclick="openForm('schedule')">+ ${esc(t('add'))}</button><button class="btn alt" onclick="copyModule('schedule')">📋 ${esc(t('copy'))}</button></div>${ganttChartHTML()}${cpmCardHTML()}<div class="card"><h3>📅 Calendar / Timeline</h3>${arr.length?arr.map(o=>{const late=o.status!=='done'&&o.dueDate&&new Date(o.dueDate)<now;return `<div class="metric"><span><b>${esc(o.name)}</b><br><span class="muted">${o.project?esc(rname('projects',o.project)):esc(t('noProject'))} · ${o.dueDate?esc(fmtDate(o.dueDate)):''}</span></span><span class="tag ${late?'t_out':o.status==='done'?'t_done':''}">${late?'⚠️ ':''}${esc(t(o.status||'open'))}</span></div>`}).join(''):`<div class="empty">${esc(t('noData'))}</div>`}</div>`}
