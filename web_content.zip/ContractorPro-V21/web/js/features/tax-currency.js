"use strict";
function fxRate(cur){if(!cur||cur===d.currency)return 1;if(d.fxBase&&d.fxBase!==d.currency)return null;const r=Number(d.fxRates&&d.fxRates[cur]);return r>0&&isFinite(r)?r:null}

function toBase(amount,cur){const n=Number(amount)||0;const r=fxRate(cur);if(r===null){FX_WARN.add(cur);return 0}return n*r}

function invCalc(o){const net=Number(o.amount)||0,tp=clampPct(o.taxPercent),rp=clampPct(o.retentionPercent),wp=clampPct(o.withholdingPercent);const taxAmount=round2(net*tp/100),invoiceTotal=round2(net+taxAmount),retentionAmount=round2(net*rp/100),withholdingAmount=round2(net*wp/100);return{taxAmount,invoiceTotal,retentionAmount,withholdingAmount,netPayable:round2(invoiceTotal-retentionAmount-withholdingAmount)}}

function showFxWarn(){const g=$("moduleGrid");if(!g||!g.parentNode)return;let w=$("fxWarn");if(!FX_WARN.size){if(w)w.remove();return}if(!w){w=document.createElement("div");w.id="fxWarn";w.className="notice";g.parentNode.insertBefore(w,g)}w.textContent="⚠️ "+t("fxMissing")+": "+[...FX_WARN].join(", ")}

function taxSettingsView(){
 const rule=TAX_RULES[d.country]||{label:d.taxLabel,rate:0};
 const fx=CURS.filter(c=>c!==d.currency).map(c=>{const ok=!d.fxBase||d.fxBase===d.currency;const v=ok&&d.fxRates&&d.fxRates[c]?d.fxRates[c]:"";return `<div class="field"><label><bdi dir="ltr">1 ${c} = ? ${d.currency}</bdi></label><input id="fx_${c}" type="number" step="any" min="0" inputmode="decimal" value="${esc(v)}"></div>`}).join("");
 return `<div class="card" style="margin-bottom:14px"><h3>🧾 ${esc(t("taxSettings"))}</h3><p class="muted">${esc(d.taxLabel||rule.label)} · ${esc(t("taxNote"))}</p><div class="formgrid"><div class="field"><label>${esc(t("taxRate"))}</label><input id="taxRate" type="number" step="any" min="0" max="100" inputmode="decimal" value="${esc(d.taxRate)}"></div><div class="field"><label>${esc(t("retentionPercent"))}</label><input id="retentionPct" type="number" step="any" min="0" max="100" inputmode="decimal" value="${esc(d.retentionPercent)}"></div><div class="field"><label>${esc(t("withholdingPercent"))}</label><input id="withholdingPct" type="number" step="any" min="0" max="100" inputmode="decimal" value="${esc(d.withholdingPercent)}"></div></div><h4 style="margin:14px 0 4px">💱 ${esc(t("fxRates"))} (${esc(t("baseCurrency"))}: ${esc(d.currency)})</h4><p class="muted mini">${esc(t("fxHint"))}</p><div class="formgrid">${fx}</div><div class="actions"><button class="btn" onclick="saveTaxSettings()">${esc(t("save"))}</button></div></div>`}

function saveTaxSettings(){
 const g=id=>{const e=$(id);return e?e.value.trim():""};
 for(const id of ["taxRate","retentionPct","withholdingPct"]){const v=g(id);if(v!==""&&(!(Number(v)>=0)||Number(v)>100)){alert(t("pctRange"));return}}
 d.taxRate=clampPct(g("taxRate"));d.retentionPercent=clampPct(g("retentionPct"));d.withholdingPercent=clampPct(g("withholdingPct"));
 const fx={};CURS.forEach(c=>{if(c===d.currency)return;const v=Number(g("fx_"+c));if(v>0&&isFinite(v))fx[c]=v});
 d.fxRates=fx;d.fxBase=d.currency;persist();apply();route(cur());alert(t("saved"));
}
