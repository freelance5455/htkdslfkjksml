"use strict";
function cp20T(s){return window.cpTr?window.cpTr(s):s}

function cp20DB(){return new Promise(function(ok,no){try{var r=indexedDB.open('cp20files',1);r.onupgradeneeded=function(){r.result.createObjectStore('q',{keyPath:'qid'})};r.onsuccess=function(){ok(r.result)};r.onerror=function(){no(r.error)}}catch(e){no(e)}})}

function cp20Tx(mode,fn){return cp20DB().then(function(db){return new Promise(function(ok,no){var tx=db.transaction('q',mode),st=tx.objectStore('q'),res=fn(st);tx.oncomplete=function(){ok(res&&res.result!==undefined?res.result:undefined)};tx.onerror=function(){no(tx.error)}})})}

function cp20Put(rec){return cp20Tx('readwrite',function(s){return s.put(rec)})}

function cp20Del(qid){return cp20Tx('readwrite',function(s){return s.delete(qid)})}

function cp20All(){return cp20Tx('readonly',function(s){return s.getAll()}).then(function(x){return x||[]})}

function cp20Compress(file){
 return new Promise(function(ok){
  if(!/^image\/(jpeg|png|webp)$/.test(file.type)){ok(file);return}
  var img=new Image(),u=URL.createObjectURL(file);
  img.onload=function(){try{var max=1600,s=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.round(img.width*s);c.height=Math.round(img.height*s);c.getContext('2d').drawImage(img,0,0,c.width,c.height);
   c.toBlob(function(b){URL.revokeObjectURL(u);ok(b&&b.size<file.size?new File([b],file.name.replace(/\.\w+$/,'')+'.jpg',{type:'image/jpeg'}):file)},'image/jpeg',0.8)}catch(e){URL.revokeObjectURL(u);ok(file)}};
  img.onerror=function(){URL.revokeObjectURL(u);ok(file)};img.src=u})}

function cp20Queue(module,recordId,file){
 return cp20Compress(file).then(function(f){return cp20Put({qid:uid(),module:module,recordId:recordId,name:f.name||'photo.jpg',type:f.type||'image/jpeg',blob:f,status:'pending',error:'',at:new Date().toISOString()})}).then(function(){return cp20Flush()})}

function cp20Flush(){
 if(cp20Flushing)return Promise.resolve();
 var S=window.cp20Svc;if(!S||!S.token()||!S.endpoint())return Promise.resolve();
 cp20Flushing=true;
 return cp20All().then(async function(items){
  for(var i=0;i<items.length;i++){var it=items[i];if(it.status==='failed')continue;
   try{var r=await fetch(S.endpoint()+'/api/files',{method:'POST',headers:{Authorization:'Bearer '+S.token(),'Content-Type':it.type,'X-File-Name':encodeURIComponent(it.name),'X-Module':it.module||'','X-Record-Id':it.recordId||''},body:it.blob});
    if(r.status===200||r.status===201){await cp20Del(it.qid);continue}
    var j={};try{j=await r.json()}catch(e){}
    if(r.status===401||r.status===429||r.status>=500)break;                          // sign in again / try later: keep in queue
    it.status='failed';it.error=j.error||('HTTP '+r.status);await cp20Put(it)         // permanent problem (quota, type, permission)
   }catch(e){break}}
 }).catch(function(){}).then(function(){cp20Flushing=false})}

function cp20Size(n){return n>=1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB'}

function cp20Blob(id){var S=window.cp20Svc;return fetch(S.endpoint()+'/api/files/'+id,{headers:{Authorization:'Bearer '+S.token()}}).then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.blob()})}

function cp20Lightbox(src,isPdf,name){
 var m=document.createElement('div');m.className='modal';m.style.zIndex=99999;m.onclick=function(e){if(e.target===m){m.remove();if(src.indexOf('blob:')===0)URL.revokeObjectURL(src)}};
 m.innerHTML='<div class="sheet" style="max-width:96vw;width:960px;text-align:center"><h3>'+esc(name||'')+'</h3>'+(isPdf?'<a class="btn" target="_blank" rel="noopener" href="'+esc(src)+'">'+esc('Open PDF')+'</a>':'<img alt="" src="'+esc(src)+'" style="max-width:100%;max-height:75vh;border-radius:8px">')+'<div class="actions"><button class="btn alt">'+esc('Close')+'</button></div></div>';
 m.querySelector('button').onclick=function(){m.remove()};document.body.appendChild(m)}

function cp20SheetImage(rec){
 var S=window.cp20Svc;
 return cp20All().then(function(q){var loc=q.find(function(x){return x.module==='drawings'&&x.recordId===rec.id&&/^image/.test(x.type)});if(loc)return {src:URL.createObjectURL(loc.blob),temp:true};
  if(!(S.token()&&S.endpoint()))return null;
  return S.jfetch(S.endpoint()+'/api/files?module=drawings&recordId='+encodeURIComponent(rec.id),{headers:{Authorization:'Bearer '+S.token()}}).then(function(r){var f=(r.files||[]).find(function(x){return /^image/.test(x.mime)});if(!f)return null;return cp20Blob(f.id).then(function(b){return {src:URL.createObjectURL(b),temp:true}})}).catch(function(){return null})})}

function cp20Snapshot(module,rec){var o={},keys=Object.keys(rec).filter(function(k){return k!=='pins'&&k!=='approval'&&k!=='updatedAt'&&k!=='updatedBy'}).sort();keys.forEach(function(k){o[k]=rec[k]});return JSON.stringify({module:module,record:o})}

function cp20Csv(rows){return rows.map(function(r){return r.map(function(v){v=String(v==null?'':v);if(/^[=+\-@\t\r]/.test(v))v="'"+v;return '"'+v.replace(/"/g,'""')+'"'}).join(',')}).join('\r\n')}

function cp20Save(name,text){var b=new Blob(['﻿'+text],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(a.href)},1000)}

function cp20Nm(coll,id){var o=(d[coll]||[]).find(function(x){return x.id===id});return o?(o.name||''):''}

function cp20Ymd(s){return String(s||'').slice(0,10)}

function cp20Us(s){s=cp20Ymd(s);return s?s.slice(5,7)+'/'+s.slice(8,10)+'/'+s.slice(0,4):''}
