"use strict";
function skey(n,u){return String(n||"").trim().toLowerCase()+"|"+String(u||"").trim().toLowerCase()}

function stockMap(skip){
 const m=new Map();
 d.inventory.forEach(o=>{if(o.id===skip)return;const k=skey(o.name,o.unit);
  const s=m.get(k)||{name:String(o.name||"").trim(),sku:"",unit:String(o.unit||"").trim(),in:0,out:0,minStock:0,shelves:new Set()};
  const q=Number(o.quantity)||0;if(o.status==="out")s.out+=q;else s.in+=q;if(!s.sku&&o.sku)s.sku=o.sku;s.minStock=Math.max(s.minStock,Number(o.minStock)||0);if(o.shelf)s.shelves.add(String(o.shelf));m.set(k,s)});
 return m;
}

function renderShelf(q){
 const box=$("shelf");if(!box)return;
 shelfCache=[...stockMap().values()].filter(s=>(s.name+" "+s.sku).toLowerCase().includes(q));
 box.innerHTML=shelfCache.length?shelfCache.map((s,i)=>{const n=s.in-s.out;
  return `<div class="slot${n<=s.minStock?" low":""}"><div class="sname">${esc(s.name)}</div>${s.sku?`<div class="muted">${esc(s.sku)}</div>`:""}<div class="sqty">${fmtNum(n)}</div><div class="muted">${esc(s.unit)}</div>${s.shelves.size?`<div class="muted">${esc(t("shelf"))}: ${esc([...s.shelves].join(", "))}</div>`:""}<div class="muted">↓ ${fmtNum(s.in)} · ↑ ${fmtNum(s.out)}</div><div class="actions" style="justify-content:center"><button class="btn" onclick="quickStock(${i},'in')">+ ${esc(t("in"))}</button><button class="btn alt" onclick="quickStock(${i},'out')">− ${esc(t("out"))}</button></div></div>`}).join(""):`<div class="empty" style="grid-column:1/-1">${esc(t("noData"))}</div>`;
}

function quickStock(i,st){const s=shelfCache[i];if(s)openForm("inventory",null,{name:s.name,sku:s.sku,unit:s.unit,status:st,minStock:s.minStock})}
