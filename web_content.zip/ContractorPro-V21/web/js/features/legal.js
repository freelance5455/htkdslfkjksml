"use strict";
function cp20LegalFill(s){return String(s).replace(/\{(\w+)\}/g,function(m,k){return CP_LEGAL_CFG[k]!=null?CP_LEGAL_CFG[k]:m})}

function cp20LegalHTML(which){var items=CP_LEGAL[which],head=which==='terms'?'Terms of Use':'Privacy Policy';
 var intro=which==='terms'?'These terms are between '+CP_LEGAL_CFG.publisher+' ("Publisher") and the person or company using Contractor Pro ("you"). By installing or using the app you accept them.':'Controlled by '+CP_LEGAL_CFG.publisher+', '+CP_LEGAL_CFG.address+', contact '+CP_LEGAL_CFG.email+' ("Publisher"). Version '+CP_LEGAL.version+'.';
 return '<div data-notr dir="ltr" lang="en" style="text-align:left"><h3>'+esc(head)+'</h3><p>'+esc(intro)+'</p><ol style="padding-left:20px">'+items.map(function(x){return '<li style="margin-bottom:8px"><b>'+esc(x[0])+'.</b> '+esc(cp20LegalFill(x[1]))+'</li>'}).join('')+'</ol></div>'}

function cp20LegalAccepted(){try{var v=JSON.parse(localStorage.getItem('cp_legal_accept')||'null');return !!(v&&v.version===CP_LEGAL.version)}catch(e){return false}}

function cp20LegalCard(){return '<div class="card" style="margin-bottom:14px"><h3>⚖️ '+esc('Legal and privacy')+'</h3><div class="actions"><button class="btn alt" onclick="cp20ShowLegal(\'terms\')">'+esc('Terms of Use')+'</button><button class="btn alt" onclick="cp20ShowLegal(\'privacy\')">'+esc('Privacy Policy')+'</button><button class="btn alt" onclick="exportData()">'+esc('Export my data')+'</button><button class="btn danger" onclick="cp20EraseLocal()">'+esc('Erase local data')+'</button></div></div>'}
