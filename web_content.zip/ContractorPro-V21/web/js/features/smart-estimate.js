"use strict";
function smartEstimateData(){
 d.smartDrawings=Array.isArray(d.smartDrawings)?d.smartDrawings:[];
 return d.smartDrawings;
}

function smartEstimateView(){
 const jobs=smartEstimateData();
 const last=jobs.slice(-1)[0];
 return `<div class="card" style="border:1px solid #bfdbfe;background:linear-gradient(135deg,#eff6ff,#ffffff)">
   <div style="display:flex;gap:12px;align-items:center"><div style="font-size:34px">📐</div><div><h2 style="margin:0">${esc(t("m_smartEstimate"))}</h2><div class="muted">${esc(t("d_smartEstimate"))}</div></div></div>
   <div class="metric" style="margin-top:14px"><span>${esc(t("smartEstimateReady"))}</span><b>V18</b></div>
 </div>
 <div class="card" style="margin-top:12px">
   <h3>1. ${esc(t("uploadDrawing"))}</h3>
   <div class="muted" style="margin-bottom:10px">${esc(t("v19SmartDrop"))}</div>
   <input id="v18DrawingFile" type="file" accept="application/pdf,image/*" onchange="v18PreviewDrawing(this)" style="width:100%"/>
   <div id="v18DrawingPreview" style="margin-top:12px"></div>
 </div>
 <div class="card" style="margin-top:12px">
   <h3>2. ${esc(t("takeoff"))}</h3>
   <div class="formgrid">
    <div class="field"><label>${esc(t("v19CountryRegion"))}</label><select id="v18Region"><option value="auto">${esc(t("auto"))}</option>${Object.keys(COUNTRIES).map(k=>`<option value="${k}">${esc(COUNTRIES[k].name[d.lang]||COUNTRIES[k].name.en)}</option>`).join("")}</select></div>
    <div class="field"><label>${esc(t("unitSystem"))}</label><select id="v18Unit"><option value="metric"${d.unitSystem==="metric"?" selected":""}>${esc(t("metric"))}</option><option value="imperial"${d.unitSystem==="imperial"?" selected":""}>${esc(t("imperial"))}</option></select></div>
    <div class="field"><label>${esc(t("v19Pricing"))}</label><select id="v18Pricing"><option value="regional">${esc(t("costDatabase"))}</option><option value="manual">${esc(t("manualMode"))}</option></select></div>
    <div class="field"><label>${esc(t("taxPercent"))}</label><input id="v18Tax" type="number" min="0" max="100" step="0.1" value="${esc(d.taxRate)}"/></div>
   </div>
   <button class="btn" style="margin-top:12px" onclick="v18StartAnalysis()">🤖 ${esc(t("analyzeDrawing"))}</button>
 </div>
 <div id="v18Analysis" style="margin-top:12px">${last?v18ResultCard(last):''}</div>
 <div class="card" style="margin-top:12px">
  <h3>3. ${esc(t("boq"))}</h3>
  <div id="v18Boq"><div class="muted">${esc(t("v19BoqEmpty"))}</div></div>
 </div>`;
}

function v18PreviewDrawing(input){
 const box=$("v18DrawingPreview"); if(!box)return;
 const f=input.files&&input.files[0]; if(!f){box.innerHTML="";return}
 const mb=(f.size/1048576).toFixed(2); let pages="—";
 if(f.type==="application/pdf"){
  const r=new FileReader();r.onload=()=>{try{const u=new Uint8Array(r.result);let txt="";for(let i=0;i<u.length;i++)txt+=String.fromCharCode(u[i]);pages=(txt.match(/\/Type\s*\/Page(?!s)/g)||[]).length||t("v19Unknown");box.innerHTML=v18FileMeta(f,mb,pages)}catch(e){box.innerHTML=v18FileMeta(f,mb,t("v19Unknown"))}};r.readAsArrayBuffer(f);
 }else box.innerHTML=v18FileMeta(f,mb,t("v19Image"));
}

function v18FileMeta(f,mb,pages){return `<div class="card" style="background:#f8fafc"><b>📄 ${esc(f.name)}</b><div class="muted">${esc(f.type||"file")} · ${mb} MB · ${esc(t("v19Pages"))}: ${esc(String(pages))}</div></div>`}

function v18StartAnalysis(){
 const input=$("v18DrawingFile"),f=input?.files?.[0];
 if(!f){alert(t("v19PickFile"));return}
 const job={id:uid(),fileName:f.name,fileType:f.type||"",fileSize:f.size,region:$('v18Region')?.value||"auto",unit:$('v18Unit')?.value||"metric",pricing:$('v18Pricing')?.value||"regional",tax:Number($('v18Tax')?.value)||0,status:"queued",confidence:null,createdAt:new Date().toISOString(),missing:["v19MissScale","v19MissStruct","v19MissRates"]};
 smartEstimateData().push(job);persist();
 const box=$("v18Analysis");if(box)box.innerHTML=v18ResultCard(job);
 const boq=$("v18Boq");if(boq)boq.innerHTML=`<div class="card"><div class="muted">⏳ ${esc(t("v19Queued"))}</div></div>`;
}

function v18ResultCard(job){
 const conf=job.confidence==null?"—":job.confidence+"%";
 return `<div class="card" style="border-inline-start:4px solid #1d4ed8"><h3>🔎 ${esc(t("v19Prelim"))}</h3><div class="metric"><span>${esc(t("v19File"))}</span><b>${esc(job.fileName)}</b></div><div class="metric"><span>${esc(t("confidence"))}</span><b>${conf}</b></div><div class="metric"><span>${esc(t("region"))}</span><b>${esc(job.region)}</b></div><h4>${esc(t("missingData"))}</h4><ul>${(job.missing||[]).map(x=>`<li>${esc(t(x))}</li>`).join("")}</ul><div class="muted">${esc(t("v19PrelimNote"))}</div></div>`;
}
