"use strict";
function cp13LicenseState(){
 const l=d.license||{};const exp=l.expiresAt?new Date(l.expiresAt):null;const now=new Date();
 const active=!!(l.serverValidated&&(!exp||exp>now));
 const offline=!!(l.offlineUntil&&new Date(l.offlineUntil)>now);
 return {plan:String(l.plan||"free"),status:String(l.status||"local"),active,offline,licenseId:String(l.licenseId||"")};
}

function cp13LicenseView(){
 const l=d.license||{};const st=cp13LicenseState();
 const exp=l.expiresAt?fmtDate(l.expiresAt,true):"—";
 return `<div class="card" style="margin-top:14px"><h3>💳 Subscription &amp; License</h3><p class="muted">License information and subscription connection points. Purchases and server validation are not simulated in this offline build.</p><div class="grid"><div class="card"><div class="muted">Plan</div><div class="big">${esc(st.plan)}</div></div><div class="card"><div class="muted">Status</div><div class="big">${esc(st.status)}</div></div><div class="card"><div class="muted">Server validated</div><div class="big">${l.serverValidated?'Yes':'No'}</div></div><div class="card"><div class="muted">Expires</div><div class="big">${esc(exp)}</div></div></div><div class="formgrid" style="margin-top:12px"><div class="field"><label>License ID</label><input id="cp13LicenseId" value="${esc(l.licenseId||"")}" maxlength="160" placeholder="Server-issued license ID"></div><div class="field"><label>Provider</label><input id="cp13Provider" value="${esc(l.provider||"")}" maxlength="80" placeholder="Google Play / App Store / Web"></div><div class="field"><label>Product ID</label><input id="cp13ProductId" value="${esc(l.productId||"")}" maxlength="120" placeholder="Product or subscription ID"></div><div class="field"><label>Server endpoint</label><input id="cp13LicenseEndpoint" value="${esc((d.sync&&d.sync.endpoint)||"")}" maxlength="500" placeholder="https://api.example.com"></div></div><div class="actions"><button class="btn" onclick="cp13SaveLicenseMeta()">Save License Info</button><button class="btn alt" onclick="cp13PrepareValidation()">Prepare Server Validation</button><button class="btn alt" onclick="cp13ClearLocalLicense()">Clear Local License Data</button></div><div class="notice" id="cp13LicenseStatus">${esc(l.serverMessage||"Offline license state: not server validated.")}</div><div class="mini" style="margin-top:8px">This build never grants paid access from a locally entered key. Final commercial entitlement must be returned and validated by the Contractor Pro backend.</div></div>`;
}

function cp13SaveLicenseMeta(){
 d.license=d.license||{};d.license.licenseId=String($("cp13LicenseId")?.value||"").trim().slice(0,160);d.license.provider=String($("cp13Provider")?.value||"").trim().slice(0,80);d.license.productId=String($("cp13ProductId")?.value||"").trim().slice(0,120);d.sync=d.sync||{};d.sync.endpoint=String($("cp13LicenseEndpoint")?.value||"").trim().slice(0,500);d.license.serverMessage="License metadata saved locally. Server validation is still required.";persist();route(cur());}

function cp13PrepareValidation(){
 d.license=d.license||{};d.license.lastCheckedAt=new Date().toISOString();d.license.serverValidated=false;d.license.status="pending_server";d.license.serverMessage="Validation request prepared. No network request was made by this offline build.";persist();route(cur());alert("Server validation is prepared. Connect this build to the production backend before enabling paid access.");
}

function cp13ClearLocalLicense(){
 if(!confirm("Clear local license metadata?"))return;d.license={plan:"free",status:"local",expiresAt:null,graceUntil:null,serverValidated:false,licenseId:"",provider:"",productId:"",lastCheckedAt:null,serverMessage:"Local license data cleared.",offlineUntil:null};persist();route(cur());
}
