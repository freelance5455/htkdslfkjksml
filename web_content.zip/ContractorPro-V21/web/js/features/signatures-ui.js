"use strict";
var CP20_SIGN_MODS=['changeOrders','estimates','contracts','submittals','invoices','rfis'];

window.cp20OpenSign=function(module,rid){
 var S=window.cp20Svc;S.servicesEnsure();var rec=(d[module]||[]).find(function(x){return x.id===rid});if(!rec)return;
 var snap=cp20Snapshot(module,rec),on=!!(S.token()&&S.endpoint());
 var m=S.modal('✍️ '+esc('Approval & signature'),'<div class="notice">'+esc('This is a simple electronic approval (name, drawn signature, time, IP and a fingerprint of the document). It is not a qualified/legally certified signature in every country.')+'</div>'+(on?'':'<div class="notice">'+esc('Sign in to your server to record approvals.')+'</div>')+
  '<div class="field"><label>'+esc('Signer name')+'</label><input id="cp20SigName" maxlength="120"></div><canvas id="cp20SigPad" width="500" height="160" style="width:100%;max-width:500px;height:160px;border:1px dashed var(--line);border-radius:8px;touch-action:none;background:#fff"></canvas>'+
  '<div class="actions"><button class="btn alt" id="cp20SigClear">'+esc('Clear')+'</button><button class="btn" id="cp20SigOk">✅ '+esc('Approve')+'</button><button class="btn danger" id="cp20SigNo">⛔ '+esc('Reject')+'</button><button class="btn alt" id="cp20SigClose">'+esc('Close')+'</button></div><div id="cp20SigMsg" class="muted"></div><div id="cp20SigList"></div>');
 var cv=m.querySelector('#cp20SigPad'),cx=cv.getContext('2d'),draw=false,inked=false;cx.lineWidth=2.5;cx.lineCap='round';cx.strokeStyle='#111';
 function pt(e){var b=cv.getBoundingClientRect();return [(e.clientX-b.left)*cv.width/b.width,(e.clientY-b.top)*cv.height/b.height]}
 cv.onpointerdown=function(e){draw=true;inked=true;var p=pt(e);cx.beginPath();cx.moveTo(p[0],p[1]);try{cv.setPointerCapture(e.pointerId)}catch(x){}};
 cv.onpointermove=function(e){if(!draw)return;var p=pt(e);cx.lineTo(p[0],p[1]);cx.stroke()};cv.onpointerup=cv.onpointercancel=function(){draw=false};
 m.querySelector('#cp20SigClear').onclick=function(){cx.clearRect(0,0,cv.width,cv.height);inked=false};
 m.querySelector('#cp20SigClose').onclick=function(){m.remove()};
 var msg=m.querySelector('#cp20SigMsg');
 async function list(){if(!on)return;try{var r=await S.jfetch(S.endpoint()+'/api/signatures?module='+encodeURIComponent(module)+'&recordId='+encodeURIComponent(rid),{headers:{Authorization:'Bearer '+S.token()}});
  m.querySelector('#cp20SigList').innerHTML=(r.signatures||[]).map(function(s){return '<div class="metric"><span>'+(s.decision==='approved'?'✅ ':'⛔ ')+'<b>'+esc(s.signerName)+'</b> <span class="muted">'+esc(fmtDate(s.signedAt,true))+' · '+esc(s.docHash.slice(0,12))+'…</span></span><button class="btn alt" data-v="'+esc(s.id)+'">'+esc('Verify')+'</button></div>'}).join('');
  m.querySelectorAll('[data-v]').forEach(function(b){b.onclick=async function(){try{var v=await S.jfetch(S.endpoint()+'/api/signatures/'+b.dataset.v+'/verify',{method:'POST',headers:{Authorization:'Bearer '+S.token()},body:JSON.stringify({snapshot:cp20Snapshot(module,rec)})});
   msg.textContent=v.valid?'✅ '+'Signature is intact and the document has not changed since signing.':(v.recordIntact?'⚠️ '+'The signature is intact, but the document was changed after it was signed.':'❌ '+'The signature record was altered.')}catch(e){msg.textContent='Error: '+e.message}}})}catch(e){}}
 async function send(decision){
  if(!on){msg.textContent='Sign in to your server to record approvals.';return}
  var name=m.querySelector('#cp20SigName').value.trim();if(name.length<2){msg.textContent='Enter the signer name.';return}
  if(!inked){msg.textContent='Please draw your signature.';return}
  try{var r=await S.jfetch(S.endpoint()+'/api/signatures',{method:'POST',headers:{Authorization:'Bearer '+S.token()},body:JSON.stringify({module:module,recordId:rid,title:rec.name||rec.title||rec.number||'',decision:decision,snapshot:snap,signerName:name,image:cv.toDataURL('image/png')})});
   rec.approval={decision:decision,by:name,at:r.signature.signedAt,signatureId:r.signature.id};rec.updatedAt=new Date().toISOString();audit('sign',module,rid,decision+' by '+name);persist();msg.textContent=decision==='approved'?'✅ Approved and recorded.':'⛔ Rejected and recorded.';cx.clearRect(0,0,cv.width,cv.height);inked=false;list()}catch(e){msg.textContent='Error: '+e.message}}
 m.querySelector('#cp20SigOk').onclick=function(){send('approved')};m.querySelector('#cp20SigNo').onclick=function(){send('rejected')};list()};

window.cp20Export=function(kind,fmt){
 var inv=d.invoices.filter(function(x){return x.status!=='cancelled'&&x.status!=='draft'}),cur=d.currency||'USD',rows,name;
 var exp=d.finance.filter(function(x){return ['expense','debt'].indexOf(x.type)>=0});
 if(kind==='invoices'){
  if(fmt==='quickbooks'){rows=[['InvoiceNo','Customer','InvoiceDate','DueDate','Item(Product/Service)','ItemDescription','ItemAmount']].concat(inv.map(function(x,i){return [x.name||('INV-'+(i+1)),cp20Nm('clients',x.client),cp20Us(x.issueDate||x.createdAt),cp20Us(x.dueDate),'Services',cp20Nm('projects',x.project),Number(x.amount)||0]}));name='contractor-pro-invoices-quickbooks.csv'}
  else if(fmt==='xero'){rows=[['*ContactName','*InvoiceNumber','*InvoiceDate','*DueDate','Description','*Quantity','*UnitAmount','*AccountCode','Currency']].concat(inv.map(function(x,i){return [cp20Nm('clients',x.client),x.name||('INV-'+(i+1)),cp20Ymd(x.issueDate||x.createdAt),cp20Ymd(x.dueDate),cp20Nm('projects',x.project)||'Services',1,Number(x.amount)||0,'200',cur]}));name='contractor-pro-invoices-xero.csv'}
  else{rows=[['Number','Client','Project','Issue date','Due date','Amount','Currency','Status']].concat(inv.map(function(x,i){return [x.name||('INV-'+(i+1)),cp20Nm('clients',x.client),cp20Nm('projects',x.project),cp20Ymd(x.issueDate||x.createdAt),cp20Ymd(x.dueDate),Number(x.amount)||0,x.currency||cur,x.status||'']}));name='contractor-pro-invoices.csv'}
 }else{
  if(fmt==='quickbooks'){rows=[['Date','Description','Amount']].concat(exp.map(function(x){return [cp20Us(x.recordDate||x.createdAt),(x.name||'')+(x.category?' ['+x.category+']':''),-Math.abs(Number(x.amount)||0)]}));name='contractor-pro-expenses-quickbooks.csv'}
  else if(fmt==='xero'){rows=[['*Date','*Amount','Payee','Description','Reference']].concat(exp.map(function(x){return [cp20Ymd(x.recordDate||x.createdAt),-Math.abs(Number(x.amount)||0),cp20Nm('suppliers',x.supplier),x.name||'',x.category||'']}));name='contractor-pro-expenses-xero.csv'}
  else{rows=[['Date','Type','Description','Category','Project','Client','Amount','Currency']].concat(d.finance.map(function(x){return [cp20Ymd(x.recordDate||x.createdAt),x.type||'',x.name||'',x.category||'',cp20Nm('projects',x.project),cp20Nm('clients',x.client),Number(x.amount)||0,x.currency||cur]}));name='contractor-pro-finance.csv'}
 }
 cp20Save(name,cp20Csv(rows));return rows};

window.cp20ExportCard=function(){return '<div class="card"><h3>📤 '+esc('Accounting export')+'</h3><div class="muted" style="margin-bottom:8px">'+esc('CSV files you can import into your accounting software. Column layouts follow the common import templates; check the first import with a few rows because vendors change their templates.')+'</div><div class="actions"><button class="btn alt" onclick="cp20Export(\'invoices\',\'generic\')">'+esc('Invoices CSV')+'</button><button class="btn alt" onclick="cp20Export(\'invoices\',\'quickbooks\')">'+esc('Invoices for QuickBooks')+'</button><button class="btn alt" onclick="cp20Export(\'invoices\',\'xero\')">'+esc('Invoices for Xero')+'</button></div><div class="actions"><button class="btn alt" onclick="cp20Export(\'finance\',\'generic\')">'+esc('Income and expenses CSV')+'</button><button class="btn alt" onclick="cp20Export(\'expenses\',\'quickbooks\')">'+esc('Expenses for QuickBooks')+'</button><button class="btn alt" onclick="cp20Export(\'expenses\',\'xero\')">'+esc('Expenses for Xero')+'</button></div></div>'};
