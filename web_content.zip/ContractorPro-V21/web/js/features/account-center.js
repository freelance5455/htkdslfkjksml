"use strict";
// V21 account centre (Settings): data export / erasure (GDPR), push alerts, live accounting connections.
(function () {
  var FA = { title: 'حساب و داده‌ها (سرور)', exp: 'دریافت داده‌های من', del: 'حذف دائمی حساب', push: 'اعلان‌های Push', pushOn: 'فعال', pushOff: 'غیرفعال', acc: 'اتصال به نرم‌افزار حسابداری', conn: 'اتصال', sync: 'همگام‌سازی', disc: 'قطع اتصال', login: 'برای استفاده وارد حساب سرور شوید.' };
  function L(k, en) { try { return (typeof d !== 'undefined' && d.lang === 'fa' && FA[k]) || en; } catch (e) { return en; } }
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function base() { try { return String((d.services || {}).endpoint || '').replace(/\/$/, ''); } catch (e) { return ''; } }
  function tok(k) { try { return sessionStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function put(a, r) { try { if (a) sessionStorage.setItem('cp175_access_token', a); if (r) sessionStorage.setItem('cp175_refresh_token', r); } catch (e) { } }
  function signedIn() { return !!(base() && tok('cp175_access_token')); }
  function msg(t) { var el = document.getElementById('cp21Msg'); if (el) el.textContent = t; }

  async function raw(method, path, body, retry) {
    var r = await fetch(base() + path, { method: method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok('cp175_access_token') }, body: body ? JSON.stringify(body) : undefined });
    if (r.status === 401 && retry !== false && tok('cp175_refresh_token')) {
      var rr = await fetch(base() + '/api/auth/refresh', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken: tok('cp175_refresh_token') }) });
      if (rr.ok) { var j = await rr.json(); put(j.accessToken, j.refreshToken); return raw(method, path, body, false); }
    }
    return r;
  }
  async function json(method, path, body) { var r = await raw(method, path, body), t = await r.text(), j = null; try { j = JSON.parse(t); } catch (e) { } if (!r.ok) throw new Error((j && j.error) || ('HTTP ' + r.status)); return j; }

  window.cp21Export = async function () {
    try { var r = await raw('GET', '/api/account/export'); if (!r.ok) throw new Error('HTTP ' + r.status); var b = await r.blob(), a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'contractor-pro-export-' + new Date().toISOString().slice(0, 10) + '.json'; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000); msg('✔'); }
    catch (e) { msg('⚠ ' + e.message); }
  };
  window.cp21Erase = async function () {
    var ws = confirm('Erase the whole WORKSPACE (all members, records, files) from the server? OK = workspace + everyone, Cancel = only my own login.');
    if (!confirm('This is permanent and cannot be undone. Continue?')) return;
    var phrase = prompt('Type DELETE MY ACCOUNT to confirm'); if (phrase !== 'DELETE MY ACCOUNT') return msg('Cancelled');
    var pw = prompt('Your password (leave empty if you sign in with an e-mail code - request a new code first)') || '', code = pw ? '' : (prompt('E-mail code') || '');
    try { var b = { confirm: phrase, password: pw, code: code }; if (ws) b.workspace = true; var j = await json('POST', '/api/account/delete', b);
      try { sessionStorage.removeItem('cp175_access_token'); sessionStorage.removeItem('cp175_refresh_token'); } catch (e) { }
      msg('✔ Erased (' + j.erased.scope + '). Data stored on this device was not touched.'); setTimeout(function () { try { render(); } catch (e) { } }, 800); }
    catch (e) { msg('⚠ ' + e.message); }
  };
  function b64uToBytes(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); var p = atob(s + '==='.slice((s.length + 3) % 4)), a = new Uint8Array(p.length); for (var i = 0; i < p.length; i++) a[i] = p.charCodeAt(i); return a; }
  window.cp21Push = async function (on) {
    try {
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) throw new Error('Push is not supported on this device/browser');
      var reg = await navigator.serviceWorker.ready, cur = await reg.pushManager.getSubscription();
      if (!on) { if (cur) { await json('POST', '/api/push/unsubscribe', { endpoint: cur.endpoint }); await cur.unsubscribe(); } return msg('Push alerts off'); }
      if ((await Notification.requestPermission()) !== 'granted') throw new Error('Notification permission was not granted');
      var key = (await json('GET', '/api/push/key')).publicKey, sub = cur || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64uToBytes(key) });
      await json('POST', '/api/push/subscribe', { subscription: sub.toJSON() }); msg('✔ Push alerts on');
    } catch (e) { msg('⚠ ' + e.message); }
  };
  window.cp21Connect = async function (p) { try { var j = await json('POST', '/api/integrations/' + p + '/connect', {}); window.open(j.url, '_blank', 'noopener'); msg('Finish the sign-in in the new window, then press Refresh.'); } catch (e) { msg('⚠ ' + e.message); } };
  window.cp21Sync = async function (p) { try { msg('Syncing…'); var j = await json('POST', '/api/integrations/' + p + '/sync', {}), c = function (x) { return x.created + ' new, ' + x.updated + ' updated, ' + x.unchanged + ' unchanged, ' + x.failed + ' failed'; }; msg('Invoices: ' + c(j.invoices) + ' | Expenses: ' + c(j.expenses) + (j.errors.length ? ' | First error: ' + j.errors[0].message : '')); window.cp21Refresh(); } catch (e) { msg('⚠ ' + e.message); } };
  window.cp21Disc = async function (p) { if (!confirm('Disconnect? Documents already created in the accounting software stay there.')) return; try { await json('DELETE', '/api/integrations/' + p); window.cp21Refresh(); } catch (e) { msg('⚠ ' + e.message); } };
  window.cp21Refresh = async function () {
    var box = document.getElementById('cp21Acc'); if (!box || !signedIn()) return;
    try { var j = await json('GET', '/api/integrations'); box.innerHTML = j.providers.length ? j.providers.map(function (p) {
      return '<div class="metric"><span><b>' + esc(p.label) + '</b><br><small class="muted">' + (p.connected ? 'Connected' + (p.lastSyncAt ? ' · last sync ' + esc(p.lastSyncAt.slice(0, 16).replace('T', ' ')) : '') : 'Not connected') + '</small></span><span>' +
        (p.connected ? '<button class="btn" onclick="cp21Sync(\'' + p.provider + '\')">' + esc(L('sync', 'Sync now')) + '</button> <button class="btn" onclick="cp21Disc(\'' + p.provider + '\')">' + esc(L('disc', 'Disconnect')) + '</button>' : '<button class="btn" onclick="cp21Connect(\'' + p.provider + '\')">' + esc(L('conn', 'Connect')) + '</button>') + '</span></div>'; }).join('') : '<div class="muted">Not enabled on this server.</div>'; }
    catch (e) { box.innerHTML = '<div class="muted">' + esc(e.message) + '</div>'; }
  };
  function card() {
    if (!signedIn()) return '<div class="card" style="margin-bottom:14px"><h3>🔐 ' + esc(L('title', 'Account & data (server)')) + '</h3><p class="muted">' + esc(L('login', 'Sign in to your server account to use these tools.')) + '</p></div>';
    setTimeout(window.cp21Refresh, 0);
    return '<div class="card" style="margin-bottom:14px"><h3>🔐 ' + esc(L('title', 'Account & data (server)')) + '</h3><div class="actions">' +
      '<button class="btn" onclick="cp21Export()">' + esc(L('exp', 'Download my data')) + '</button> <button class="btn" onclick="cp21Erase()">' + esc(L('del', 'Delete account permanently')) + '</button></div>' +
      '<h4>' + esc(L('push', 'Push alerts')) + '</h4><div class="actions"><button class="btn" onclick="cp21Push(true)">' + esc(L('pushOn', 'Turn on')) + '</button> <button class="btn" onclick="cp21Push(false)">' + esc(L('pushOff', 'Turn off')) + '</button></div>' +
      '<h4>' + esc(L('acc', 'Accounting software')) + '</h4><div id="cp21Acc" class="muted">…</div><div class="actions"><button class="btn" onclick="cp21Refresh()">Refresh</button></div>' +
      '<p id="cp21Msg" class="muted" role="status"></p></div>';
  }
  var prev = window.settingsView;
  if (typeof prev === 'function') window.settingsView = function () { return prev.apply(this, arguments) + card(); };
})();
