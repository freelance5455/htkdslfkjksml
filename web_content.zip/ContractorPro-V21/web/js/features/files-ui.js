"use strict";
window.cp20OpenFiles=function(module,recordId){
 var S=window.cp20Svc;S.servicesEnsure();
 var m=S.modal('📎 '+esc('Photos & files'),'<div class="notice" id="cp20Note"></div><div class="actions"><label class="btn">📷 '+esc('Take photo')+'<input id="cp20Cam" type="file" accept="image/*" capture="environment" hidden></label><label class="btn alt">🖼️ '+esc('Add files')+'<input id="cp20Pick" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" multiple hidden></label><button class="btn alt" id="cp20Close">'+esc('Close')+'</button></div><div id="cp20Usage" class="muted" style="font-size:12px;margin:6px 0"></div><div id="cp20List"></div>');
 var urls=[];function done(){urls.forEach(function(u){URL.revokeObjectURL(u)});m.remove()}
 m.querySelector('#cp20Close').onclick=done;
 var note=m.querySelector('#cp20Note'),list=m.querySelector('#cp20List');
 note.textContent=(S.token()&&S.endpoint())?'Photos are compressed, saved on this device and uploaded automatically when you are online.':'Not signed in: files are saved on this device and will upload after you sign in to your server.';
 async function draw(){
  var q=(await cp20All()).filter(function(x){return x.module===module&&x.recordId===recordId}),srv=[];
  if(S.token()&&S.endpoint()){try{srv=(await S.jfetch(S.endpoint()+'/api/files?module='+encodeURIComponent(module)+'&recordId='+encodeURIComponent(recordId),{headers:{Authorization:'Bearer '+S.token()}})).files||[];
   var u=await S.jfetch(S.endpoint()+'/api/usage',{headers:{Authorization:'Bearer '+S.token()}});if(u.storage)m.querySelector('#cp20Usage').textContent=esc('Storage')+': '+cp20Size(u.storage.usedBytes)+' / '+cp20Size(u.storage.quotaBytes)}catch(e){}}
  var h='';
  q.forEach(function(x){var u=URL.createObjectURL(x.blob);urls.push(u);h+='<div class="metric" style="gap:8px"><span style="display:flex;gap:8px;align-items:center">'+(/^image/.test(x.type)?'<img alt="" src="'+u+'" style="width:56px;height:56px;object-fit:cover;border-radius:6px">':'<span style="font-size:28px">📄</span>')+'<span><b>'+esc(x.name)+'</b><br><span class="muted">'+esc(x.status==='failed'?'Upload failed: '+x.error:'Waiting to upload')+' · '+cp20Size(x.blob.size)+'</span></span></span><span class="actions" style="margin:0">'+(x.status==='failed'?'<button class="btn alt" data-retry="'+esc(x.qid)+'">↻</button>':'')+'<button class="btn danger" data-qdel="'+esc(x.qid)+'">🗑️</button></span></div>'});
  srv.forEach(function(f){h+='<div class="metric" style="gap:8px"><span style="display:flex;gap:8px;align-items:center"><span class="cp20Th" data-fid="'+esc(f.id)+'" data-mime="'+esc(f.mime)+'" style="width:56px;height:56px;border-radius:6px;background:var(--line);display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:pointer">'+(f.mime==='application/pdf'?'📄':'…')+'</span><span><b>'+esc(f.name)+'</b><br><span class="muted">'+cp20Size(f.size)+' · '+esc(fmtDate(f.createdAt,true))+'</span></span></span><span class="actions" style="margin:0"><button class="btn danger" data-sdel="'+esc(f.id)+'">🗑️</button></span></div>'});
  list.innerHTML=h||'<div class="empty">'+esc(t('noData'))+'</div>';
  list.querySelectorAll('[data-qdel]').forEach(function(b){b.onclick=async function(){await cp20Del(b.dataset.qdel);draw()}});
  list.querySelectorAll('[data-retry]').forEach(function(b){b.onclick=async function(){var it=(await cp20All()).find(function(x){return x.qid===b.dataset.retry});if(it){it.status='pending';it.error='';await cp20Put(it);await cp20Flush();draw()}}});
  list.querySelectorAll('[data-sdel]').forEach(function(b){b.onclick=async function(){if(!confirm(cp20T('Delete this file?')))return;try{await S.jfetch(S.endpoint()+'/api/files/'+b.dataset.sdel,{method:'DELETE',headers:{Authorization:'Bearer '+S.token()}});draw()}catch(e){alert('Error: '+e.message)}}});
  list.querySelectorAll('.cp20Th').forEach(function(th){
   var isPdf=th.dataset.mime==='application/pdf';
   cp20Blob(th.dataset.fid).then(function(b){var u=URL.createObjectURL(b);urls.push(u);if(!isPdf)th.innerHTML='<img alt="" src="'+u+'" style="width:100%;height:100%;object-fit:cover">';th.onclick=function(){cp20Lightbox(u,isPdf,th.parentElement.querySelector('b').textContent)}}).catch(function(){th.textContent='⚠️'})})}
 async function add(files){for(var i=0;i<files.length;i++)await cp20Queue(module,recordId,files[i]);draw()}
 m.querySelector('#cp20Cam').onchange=function(){add([].slice.call(this.files));this.value=''};
 m.querySelector('#cp20Pick').onchange=function(){add([].slice.call(this.files));this.value=''};
 cp20Flush().then(draw)};

window.cp20OpenSheet=function(rid){
 var S=window.cp20Svc,rec=d.drawings.find(function(x){return x.id===rid});if(!rec)return;rec.pins=rec.pins||[];
 var m=S.modal('🗺️ '+esc(rec.name||''),'<div class="notice">'+esc('Tap the drawing to drop a pin, then turn it into a punch item or an RFI.')+'</div><div class="actions"><button class="btn alt" id="cp20SheetFiles">📎 '+esc('Photos & files')+'</button><button class="btn alt" id="cp20SheetClose">'+esc('Close')+'</button></div><div id="cp20Sheet" style="position:relative;display:inline-block;max-width:100%;margin-top:8px"></div><div id="cp20Pins"></div>');
 var box=m.querySelector('#cp20Sheet'),url=null;
 m.querySelector('#cp20SheetClose').onclick=function(){if(url)URL.revokeObjectURL(url);m.remove()};
 m.querySelector('#cp20SheetFiles').onclick=function(){if(url)URL.revokeObjectURL(url);cp20OpenFiles('drawings',rid)};
 function pins(){
  box.querySelectorAll('.cp20Pin').forEach(function(p){p.remove()});
  rec.pins.forEach(function(p,i){var e=document.createElement('button');e.className='cp20Pin';e.textContent=String(i+1);e.title=p.label||'';e.style.cssText='position:absolute;transform:translate(-50%,-50%);width:26px;height:26px;border-radius:50%;border:2px solid #fff;background:var(--danger);color:#fff;font-weight:700;font-size:12px;left:'+p.x+'%;top:'+p.y+'%;cursor:pointer';e.onclick=function(ev){ev.stopPropagation();pinMenu(p)};box.appendChild(e)});
  m.querySelector('#cp20Pins').innerHTML=rec.pins.length?rec.pins.map(function(p,i){return '<div class="metric"><span><b>'+(i+1)+'.</b> '+esc(p.label||'')+' <span class="muted">('+esc(p.module==='rfis'?'RFI':'Punch item')+')</span></span></div>'}).join(''):''}
 function pinMenu(p){var act=prompt((p.label||'')+'\n\n1 = '+t('edit')+'\n2 = '+t('delete'),'1');if(act==='1'&&p.recordId&&d[p.module]&&d[p.module].find(function(x){return x.id===p.recordId})){m.remove();openForm(p.module,p.recordId)}else if(act==='2'){rec.pins=rec.pins.filter(function(x){return x!==p});persist();pins()}}
 function addPin(x,y){
  var label=prompt(cp20T('Describe the issue / question'));if(!label||!label.trim())return;
  var kind=confirm(cp20T('OK = Punch item, Cancel = RFI'))?'punchList':'rfis',now=new Date().toISOString();
  var item={id:uid(),createdAt:now,createdBy:d.userId||'local-user',name:label.trim().slice(0,120),project:rec.project||'',status:'Open',priority:'Normal',notes:'Drawing: '+(rec.name||'')+(rec.sheetNo?' ('+rec.sheetNo+')':'')+' · pin at '+Math.round(x)+'%, '+Math.round(y)+'%'};
  if(kind==='punchList'){item.location=rec.name||''}else{item.question=label.trim()}
  d[kind].push(item);rec.pins.push({id:uid(),x:Math.round(x*10)/10,y:Math.round(y*10)/10,label:item.name,module:kind,recordId:item.id});audit('create',kind,item.id,item.name);persist();pins()}
 cp20SheetImage(rec).then(function(r){
  if(!r){box.innerHTML='<div class="notice">'+esc('No image attached yet. Add a PNG/JPG of the sheet with Photos & files. (Pins work on images; export PDF sheets as images.)')+'</div>';return}
  url=r.src;var img=new Image();img.alt='';img.src=r.src;img.style.cssText='max-width:100%;display:block;border-radius:6px;cursor:crosshair';img.onclick=function(ev){var b=img.getBoundingClientRect();addPin((ev.clientX-b.left)/b.width*100,(ev.clientY-b.top)/b.height*100)};box.appendChild(img);pins()})};
