(function(root){
'use strict';
var BASES=[0x660,0x6F0,0x966,0x9E6,0xAE6,0xBE6,0xC66,0xCE6];
function normDigits(s){
  return String(s==null?'':s).replace(/[\u0660-\u0669\u06F0-\u06F9\u0966-\u096F\u09E6-\u09EF\u0AE6-\u0AEF\u0BE6-\u0BEF\u0C66-\u0C6F\u0CE6-\u0CEF]/g,function(c){
    var cp=c.charCodeAt(0);for(var i=0;i<BASES.length;i++){if(cp>=BASES[i]&&cp<=BASES[i]+9)return String(cp-BASES[i])}return c;
  }).replace(/\u066B/g,'.').replace(/\u066C/g,',');
}
var SEP=new RegExp('[\\n;\\u061B\\u060C\\u0964]+|,(?!\\d)|\\s+(?:and|plus|\\u0648|और|மற்றும்|మరియు|ಮತ್ತು|आणि|અને|এবং)\\s+','iu');
var NUM=/(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)/;
var UNIT_DEFS=[
 ['m²',false,'(?:متر\\s*مربع|m\\s*2|m²|sq\\.?\\s*m(?:eters?|etres?)?|sqm|square\\s+met(?:er|re)s?|वर्ग\\s*मीटर|चौ\\.?\\s*मी\\.?|चौरस\\s*मीटर|சதுர\\s*மீட்டர்|చదరపు\\s*మీటర్(?:లు)?|ಚದರ\\s*ಮೀಟರ್|ચોરસ\\s*મીટર|বর্গ\\s*মিটার)'],
 ['ft²',false,'(?:sq\\.?\\s*ft|sqft|square\\s+(?:feet|foot)|वर्ग\\s*फुट|فوت\\s*مربع|ft\\s*2|ft²)'],
 ['m³',false,'(?:متر\\s*مکعب|m\\s*3|m³|cu\\.?\\s*m|cum|cubic\\s+met(?:er|re)s?|घन\\s*मीटर)'],
 ['m',true,'(?:متر|meters?|metres?|mtrs?|मीटर|மீட்டர்|మీటర్(?:లు)?|ಮೀಟರ್|મીટર|মিটার|मी\\.?|m)'],
 ['ft',false,'(?:feet|foot|ft|फुट|فوت)'],
 ['kg',false,'(?:kgs?|kilograms?|کیلوگرم|کیلو|किलो(?:ग्राम)?|கிலோ|కిలో|ಕಿಲೋ|કિલો|কেজি)'],
 ['ton',false,'(?:tons?|tonnes?|تن|टन|டன்|టన్ను(?:లు)?|ಟನ್|ટન|টন)'],
 ['bag',false,'(?:bags?|کیسه|बोरी|थैला|थैली|பை|సంచి|ಚೀಲ|થેલી|ব্যাগ|বস্তা)'],
 ['pcs',false,'(?:pcs?|pieces?|nos?\\.?|numbers?|units?|عدد|नग|तुकडे|तुकडा|சதுர்|టి|টি)'],
 ['L',false,'(?:liters?|litres?|لیتر|लीटर|லிட்டர்|లీటర్|ಲೀಟರ್|લીટર|লিটার|l)']
];
var UNITS=UNIT_DEFS.map(function(u){return {u:u[0],amb:u[1],re:new RegExp('^'+u[2]+'(?![\\p{L}\\p{M}])','iu')}});
var FILLER=['برای این پروژه','برای پروژه','این پروژه','نیاز دارم','لازم دارم','دارم','داریم','می‌خواهم',
 'for this project','for the project','i have','i need','we have','we need','need','have','total','about',
 'इस प्रोजेक्ट के लिए','मेरे पास','मुझे','चाहिए','हैं','है',
 'இந்த திட்டத்திற்கு','என்னிடம்','உள்ளது','வேண்டும்',
 'ఈ ప్రాజెక్టుకు','నా దగ్గర','ఉంది','కావాలి',
 'ಈ ಯೋಜನೆಗೆ','ನನ್ನ ಬಳಿ','ಇದೆ','ಬೇಕು',
 'या प्रकल्पासाठी','माझ्याकडे','आहे','हवे',
 'આ પ્રોજેક્ટ માટે','મારી પાસે','છે','જોઈએ',
 'এই প্রকল্পের জন্য','আমার কাছে','আছে','দরকার'];
FILLER.sort(function(a,b){return b.length-a.length});
function rxEsc(r){return r.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}
var FILL_RE=new RegExp('(^|[\\s.,:;!?\\u060C])(?:'+FILLER.map(rxEsc).join('|')+')(?=$|[\\s.,:;!?\\u060C])','giu');
function cleanName(x){
  var prev;x=' '+String(x||'')+' ';
  do{prev=x;x=x.replace(FILL_RE,'$1 ')}while(x!==prev);
  x=x.replace(/[\s.,:;!?\u060C\-–—]+/g,' ').trim();
  x=x.replace(/^(?:(?:and|of|\u0648|از|और|மற்றும்|మరియు|ಮತ್ತು|आणि|અને|এবং)\s+)+/iu,'').replace(/\s+(?:of|و)$/iu,'').trim();
  return x;
}
function parseQuantities(text){
  var src=normDigits(text),rows=[],skipped=[];
  src.split(SEP).forEach(function(seg){
    seg=String(seg||'').trim();if(!seg)return;
    var m=NUM.exec(seg);
    if(!m){if(cleanName(seg))skipped.push(seg);return}
    var qty=parseFloat(m[1].replace(/,/g,''));if(!isFinite(qty)||qty<=0){skipped.push(seg);return}
    var before=seg.slice(0,m.index),after=seg.slice(m.index+m[1].length).replace(/^\s+/,'');
    var unit='pcs',amb=false,found=false;
    for(var i=0;i<UNITS.length;i++){var um=UNITS[i].re.exec(after);if(um){unit=UNITS[i].u;amb=UNITS[i].amb;after=after.slice(um[0].length);found=true;break}}
    var name=cleanName(before+' '+after)||'Item';
    rows.push({name:name,qty:qty,unit:unit,amb:amb,unitGuessed:!found});
  });
  return {rows:rows,skipped:skipped};
}
function priceKey(n){return String(n||'').trim().toLowerCase().replace(/\s+/g,' ').slice(0,120)}
var api={normDigits:normDigits,parseQuantities:parseQuantities,priceKey:priceKey};
if(typeof module!=='undefined'&&module.exports){module.exports=api;return}
root.CPQuote=api;

/* ---------- UI (browser only) ---------- */
var ST={rows:[]};
function gp(name){
  var k=priceKey(name);
  if(d.priceBook&&d.priceBook[k]!=null)return d.priceBook[k];
  var est=(d.estimates||[]).slice().reverse().find(function(e){return priceKey(e.name)===k&&Number(e.unitPrice)>0});
  return est?Number(est.unitPrice):0;
}
function card(){
  var projOpts='<option value="">'+esc2(t('noProject'))+'</option>'+(d.projects||[]).map(function(p){return '<option value="'+esc2(p.id)+'">'+esc2(p.name)+'</option>'}).join('');
  return '<div class="card" style="margin-bottom:12px;border:1px solid #a7f3d0;background:linear-gradient(135deg,#ecfdf5,#fff)">'+
   '<h3 style="margin-top:0">🤖 '+esc2(t('aiTitle'))+'</h3><div class="muted" style="margin-bottom:10px">'+esc2(t('aiHint'))+'</div>'+
   '<div class="field"><textarea id="cpAiText" rows="3"></textarea></div>'+
   '<div class="actions"><button class="btn" type="button" onclick="cpAiRun()">'+esc2(t('aiRun'))+'</button></div>'+
   '<div id="cpAiOut"></div><div style="display:none" id="cpAiProjOpts">'+projOpts+'</div></div>';
}
function esc2(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]})}
function recalc(){
  var sub=0;ST.rows.forEach(function(r,i){var tot=(Number(r.qty)||0)*(Number(r.price)||0);sub+=tot;var c=document.getElementById('cpAiT'+i);if(c)c.textContent=money(tot)});
  var mk=Number((document.getElementById('cpAiMk')||{}).value)||0,tx=Number((document.getElementById('cpAiTx')||{}).value)||0;
  var ma=sub*mk/100,ta=(sub+ma)*tx/100,el=document.getElementById('cpAiSum');
  if(el)el.innerHTML=esc2(t('subtotal'))+': <b>'+money(sub)+'</b> · '+esc2(t('total'))+': <b>'+money(sub+ma+ta)+'</b>';
}
function renderOut(parsed){
  var box=document.getElementById('cpAiOut');if(!box)return;
  if(!ST.rows.length){box.innerHTML='<div class="notice">'+esc2(t('aiNone'))+'</div>';return}
  var amb=ST.rows.some(function(r){return r.amb});
  var h=(amb?'<div class="notice">⚠️ '+esc2(t('aiAmbig'))+'</div>':'')+'<div class="tablewrap"><table><thead><tr><th>'+esc2(t('item'))+'</th><th>'+esc2(t('quantity'))+'</th><th>'+esc2(t('unit'))+'</th><th>'+esc2(t('unitPrice'))+'</th><th>'+esc2(t('total'))+'</th></tr></thead><tbody>';
  ST.rows.forEach(function(r,i){
    h+='<tr><td><input data-k="name" data-i="'+i+'" value="'+esc2(r.name)+'"></td>'+
    '<td><input data-k="qty" data-i="'+i+'" type="number" step="any" min="0" inputmode="decimal" value="'+esc2(r.qty)+'" style="width:84px"></td>'+
    '<td><input data-k="unit" data-i="'+i+'" value="'+esc2(r.unit)+'" style="width:64px"></td>'+
    '<td><input data-k="price" data-i="'+i+'" type="number" step="any" min="0" inputmode="decimal" value="'+esc2(r.price||'')+'" style="width:100px"></td>'+
    '<td id="cpAiT'+i+'"></td></tr>';
  });
  h+='</tbody></table></div><div class="muted" style="margin:8px 0">'+esc2(t('aiNoPrice'))+'</div>'+
   '<div class="formgrid"><div class="field"><label>'+esc2(t('project'))+'</label><select id="cpAiProj">'+(document.getElementById('cpAiProjOpts')||{}).innerHTML+'</select></div>'+
   '<div class="field"><label>'+esc2(t('markup'))+'</label><input id="cpAiMk" type="number" step="any" min="0" value="0"></div>'+
   '<div class="field"><label>'+esc2(t('taxPercent'))+'</label><input id="cpAiTx" type="number" step="any" min="0" value="0"></div></div>'+
   '<div id="cpAiSum" style="margin:10px 0"></div><div class="actions"><button class="btn" type="button" onclick="cpAiSave()">'+esc2(t('aiSave'))+'</button></div>';
  box.innerHTML=h;
  box.oninput=function(e){var el=e.target;if(el.id==='cpAiMk'||el.id==='cpAiTx'){recalc();return}var i=el.getAttribute&&el.getAttribute('data-i');if(i==null)return;var k=el.getAttribute('data-k'),r=ST.rows[Number(i)];if(!r)return;
    r[k]=(k==='qty'||k==='price')?(Number(el.value)||0):el.value;recalc()};
  recalc();
}
window.cpAiRun=function(){
  var ta=document.getElementById('cpAiText');var res=parseQuantities(ta?ta.value:'');
  ST.rows=res.rows.map(function(r){r.price=gp(r.name);return r});renderOut(res);
};
window.cpAiSave=function(){
  var rows=ST.rows.filter(function(r){return r.name&&Number(r.qty)>0});
  if(!rows.length){alert(t('aiNone'));return}
  var pid=(document.getElementById('cpAiProj')||{}).value||'';
  var mk=Number((document.getElementById('cpAiMk')||{}).value)||0,tx=Number((document.getElementById('cpAiTx')||{}).value)||0;
  var proj=(d.projects||[]).find(function(p){return p.id===pid});
  d.estimates=d.estimates||[];d.priceBook=d.priceBook||{};
  rows.forEach(function(r){
    var q=Number(r.qty),p=Number(r.price)||0,sub=q*p,ma=sub*mk/100,ta=(sub+ma)*tx/100;
    var rec={id:uid(),createdAt:new Date().toISOString(),createdBy:d.userId||'local-user',name:String(r.name).slice(0,200),client:proj?proj.client||'':'',project:pid,description:'AI Quick Estimate',quantity:q,unit:String(r.unit||'').slice(0,20),unitPrice:p,markupPercent:mk,taxPercent:tx,notes:'',subtotal:sub,markupAmount:ma,taxAmount:ta,total:sub+ma+ta};
    d.estimates.push(rec);audit('create','estimates',rec.id,rec.name);
    if(p>0)d.priceBook[priceKey(r.name)]=p;
  });
  persist();ST.rows=[];alert(t('aiSaved'));openModule('estimates');
};
var old=window.smartEstimateView;
if(typeof old==='function'){window.smartEstimateView=function(){return card()+old()}}
})(typeof window!=='undefined'?window:globalThis);
