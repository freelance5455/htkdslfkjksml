"use strict";
function t(k){const e=I[k];return e?(e[d.lang]||e.en||k):k}

function cal(){return d.calendar==="auto"?(DEFCAL[d.lang]||"gregory"):d.calendar}

function tz(){return d.timezone&&d.timezone!=="auto"?d.timezone:(DEFTZ[d.lang]||"UTC")}

function today(){return nowLocalInput(false)}

function nowLocalInput(withTime=true){const x=new Date();const parts=new Intl.DateTimeFormat("en-CA",{timeZone:tz(),year:"numeric",month:"2-digit",day:"2-digit",hour:withTime?"2-digit":undefined,minute:withTime?"2-digit":undefined,hourCycle:"h23"}).formatToParts(x);const g=k=>parts.find(p=>p.type===k)?.value||"";return g("year")+"-"+g("month")+"-"+g("day")+(withTime?"T"+g("hour")+":"+g("minute"):"")}

function pd(s){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s));if(m)return new Date(+m[1],+m[2]-1,+m[3]);return new Date(s)}

function fmtDate(s,time){
 if(!s)return "—";const x=String(s).includes("T")||String(s).includes("Z")?new Date(s):pd(s);if(isNaN(x))return String(s);
 const o={calendar:cal(),dateStyle:"medium",timeZone:tz()};if(time||String(s).includes("T")||String(s).includes("Z")){o.timeStyle="short";o.hourCycle=TIME24[d.lang]?"h23":"h12";}
 try{return new Intl.DateTimeFormat(LOC[d.lang],o).format(x)}catch(e){return x.toLocaleString(LOC[d.lang],{timeZone:tz()})}
}

function fmtNum(n){try{return new Intl.NumberFormat(LOC[d.lang],{maximumFractionDigits:2}).format(Number(n)||0)}catch(e){return String(n||0)}}

function money(n,cur){const c=CURS.includes(cur)?cur:d.currency;try{return new Intl.NumberFormat(LOC[d.lang],{style:"currency",currency:c,maximumFractionDigits:2}).format(Number(n)||0)}catch(e){return fmtNum(n)+" "+c}}

function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}

function rname(kind,v){if(!v)return "—";const r=d[kind].find(x=>x.id===v);return r?r.name:v}

function apply(){
 const h=document.documentElement;h.lang=d.lang;h.dir=(isRTL(d.lang))?"rtl":"ltr";
 $("lang").value=d.lang;$("country").value=COUNTRIES[d.country]?d.country:(LANG_COUNTRY[d.lang]||"US");$("calendar").value=d.calendar;$("currency").value=d.currency;$("timezone").value=[...$("timezone").options].some(o=>o.value===d.timezone)?d.timezone:"auto";
 [["autoCal"],["persian"],["gregory"],["islamic"]].forEach((k,i)=>$("calendar").options[i].textContent=t(k[0]));
 ["auto","Asia/Tehran","America/New_York","Europe/London","Asia/Riyadh","Asia/Dubai","Europe/Istanbul","Europe/Moscow","Europe/Paris","Europe/Berlin"].forEach((v,i)=>{const o=$("timezone").options[i];if(o)o.textContent=v==="auto"?t("auto"):t(TZNAME[v]);});
 $("tagline").textContent=t("tagline");$("fab").setAttribute("aria-label",t("add"));
 document.querySelectorAll("[data-i18n]").forEach(e=>e.textContent=t(e.dataset.i18n));
 renderDashboard();updateClock();
}

function searchText(id,o){return (JSON.stringify(o)+" "+F[id].filter(f=>f[1]==="ref").map(f=>rname(f[3],o[f[0]])).join(" ")).toLowerCase()}

function acct(cid){const ct=sum(d.contracts.filter(x=>x.client===cid),x=>toBase(x.amount,x.currency)),rc=sum(d.finance.filter(x=>x.client===cid&&x.type==="income"),x=>toBase(x.amount,x.currency));return{ct,rc,bal:ct-rc}}
