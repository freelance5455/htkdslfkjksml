"use strict";
function show(id){document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");if(id==="dashboard")window.scrollTo({top:0})}
/* Modules open as a centred panel above the dashboard (the dashboard stays visible behind it). */
function openPanel(){$("dashboard").classList.add("active");$("detail").classList.add("active");document.body.classList.add("panel-open");$("detail").scrollTop=0}
function closePanel(){document.body.classList.remove("panel-open")}
function closePanelNav(){nav.length=1;route("dashboard")}
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&document.body.classList.contains("panel-open")&&!document.querySelector(".modal"))closePanelNav()});

function route(id){
 if(id==="dashboard"){closePanel();$("fab").style.display="none";show("dashboard");renderDashboard();return}
 if(id.startsWith("client:"))renderClient(id.slice(7));else if(id.startsWith("project:"))renderProject(id.slice(8));else if(id.startsWith("portal:"))renderPortalView(id.slice(7));else renderModule(id);
 openPanel();$("detail").focus({preventScroll:true});
}

function openModule(id){nav.push(id);route(id)}

function openClient(cid){nav.push("client:"+cid);route(cur())}

function goBack(){if(nav.length>1)nav.pop();route(cur())}

function quickAdd(id){openModule(id);openForm(id)}

function closeForm(){const m=$("modal");if(m)m.remove()}

function applyCountryDefaults(country){const c=COUNTRIES[country];if(!c)return;d.country=country;if(d.currencyMode==='auto'){d.currency=c.currency;d.timezone=c.tz;d.calendar=c.calendar;d.unitSystem=c.unit;d.taxLabel=c.tax}if(TAX_RULES[country]&&d.taxRateFor!==country){d.taxRate=TAX_RULES[country].rate;d.taxRateFor=country}}

function onLanguageChange(v){d.lang=v;if(d.countryMode==='auto'){d.country=LANG_COUNTRY[v]||'US'}if(d.currencyMode==='auto'){applyCountryDefaults(d.country||LANG_COUNTRY[v]||'US')}persist();apply();if(cur()!=='dashboard')route(cur())}

function onCountryChange(v){d.country=v;d.countryMode='manual';if(d.currencyMode==='auto')applyCountryDefaults(v);persist();apply();if(cur()!=='dashboard')route(cur())}

function onSetting(k){return e=>{d[k]=e.target.value;persist();apply();if(cur()!=="dashboard")route(cur())}}

function updateClock(){$("clock").textContent=fmtDate(new Date().toISOString(),true)}
