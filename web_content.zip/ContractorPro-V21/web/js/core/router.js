"use strict";
function show(id){document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");window.scrollTo({top:0})}

function route(id){
 if(id==="dashboard"){$("fab").style.display="none";show("dashboard");renderDashboard();return}
 if(id.startsWith("client:"))renderClient(id.slice(7));else if(id.startsWith("project:"))renderProject(id.slice(8));else if(id.startsWith("portal:"))renderPortalView(id.slice(7));else renderModule(id);
 show("detail");
}

function openModule(id){nav.push(id);route(id)}

function openClient(cid){nav.push("client:"+cid);route(cur())}

function goBack(){if(nav.length>1)nav.pop();route(cur())}

function quickAdd(id){openModule(id);openForm(id)}

function closeForm(){const m=$("modal");if(m)m.remove()}

function applyCountryDefaults(country){const c=COUNTRIES[country];if(!c)return;d.country=country;if(d.currencyMode==='auto'){d.currency=c.currency;d.timezone=c.tz;d.calendar=c.calendar;d.unitSystem=c.unit;d.taxLabel=c.tax}if(TAX_RULES[country]&&d.taxRateFor!==country){d.taxRate=TAX_RULES[country].rate;d.taxRateFor=country}}

function onLanguageChange(v){d.lang=v;if(d.countryMode==='auto'){d.country=LANG_COUNTRY[v]||'US'}if(d.currencyMode==='auto'){applyCountryDefaults(d.country||LANG_COUNTRY[v]||'US')}persist();apply();if(cur()!=='dashboard')route(cur())}

function onCountryChange(v){d.country=v;d.countryMode='manual';if(d.currencyMode==='auto')applyCountryDefaults(v);persist();apply();if(cur()!=='dashboard')route(cur())}

function onSetting(k){return e=>{d[k]=e.target.value;persist();apply();if(cur()!=="dashboard")route(cur())}}

function updateClock(){$("clock").textContent=fmtDate(new Date().toISOString(),true)}
