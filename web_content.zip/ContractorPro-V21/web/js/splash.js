(function(){
  function hideContractorSplash(){
    var el=document.getElementById('contractorSplash');
    if(!el)return;
    setTimeout(function(){el.classList.add('hide');setTimeout(function(){if(el.parentNode)el.parentNode.removeChild(el)},450)},900);
  }
  if(document.readyState==='complete') hideContractorSplash();
  else window.addEventListener('load',hideContractorSplash,{once:true});
  setTimeout(hideContractorSplash,3500);
})();
setInterval(function(){},60000);
