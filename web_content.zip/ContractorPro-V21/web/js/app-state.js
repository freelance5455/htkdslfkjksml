"use strict";
const cur=()=>nav[nav.length-1];

var DAYMS=86400000;

var cpmProject='';

var CP20_FILE_MODS=['rfis','submittals','punchList','safetyForms','tenders','dailyLogs','documents','changeOrders','drawings','contracts','projects'];

var cp20Flushing=false;

window.addEventListener('online',function(){cp20Flush()});

setInterval(function(){cp20Flush()},60000);
