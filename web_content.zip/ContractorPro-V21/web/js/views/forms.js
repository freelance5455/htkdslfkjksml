"use strict";
function openForm(id,rid,pre){
 closeForm();pre=pre||{};const o=rid?d[id].find(x=>x.id===rid):null;if(rid&&!o)return;
 const h=F[id].map(([k,kind,lk,ex])=>{
  let v=o?o[k]:pre[k];if(v==null)v=kind==="dt"?nowLocalInput(true):"";
  if(kind==="d"&&/^\d{4}-\d{2}-\d{2}/.test(v))v=String(v).slice(0,10);else if(kind==="dt"&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(v))v=String(v).slice(0,16);else if(kind==="d"||kind==="dt")v="";
  let inp,L=`<label>${esc(t(lk))}${k==="name"?" *":""}</label>`;
  if(kind==="ta")inp=`<textarea name="${k}">${esc(v)}</textarea>`;
  else if(kind==="s")inp=`<select name="${k}">${ex.map(x=>`<option value="${x[0]}"${x[0]===v?" selected":""}>${esc(t(x[1]))}</option>`).join("")}</select>`;
  else if(kind==="ref"){const L2=d[ex].filter(r=>!(ex==="schedule"&&id==="schedule"&&r.id===rid)).map(r=>[r.id,r.name]);if(v&&!L2.some(x=>x[0]===v))L2.push([v,v]);
   inp=`<select name="${k}"><option value="">${esc(t(ex==="clients"?"noClient":ex==="schedule"?"None":"noProject"))}</option>${L2.map(x=>`<option value="${esc(x[0])}"${x[0]===v?" selected":""}>${esc(x[1])}</option>`).join("")}</select>`}
  else{const ty={n:"number",d:"date",dt:"datetime-local",tel:"tel",em:"email",t:"text"}[kind];
   inp=`<input name="${k}" type="${ty}" value="${esc(v)}"${kind==="n"?' step="any" min="0" inputmode="decimal"':""}${k==="name"?' required':""}${id==="inventory"&&k==="name"?' list="itemlist" autocomplete="off"':""}>`}
  return `<div class="field">${L}${inp}</div>`}).join("");
 const dl=id==="inventory"?`<datalist id="itemlist">${[...stockMap().values()].map(s=>`<option value="${esc(s.name)}">`).join("")}</datalist>`:"";
 const m=document.createElement("div");m.id="modal";m.className="modal";
 m.onclick=e=>{if(e.target===m)closeForm()};
 m.innerHTML=`<div class="sheet" role="dialog" aria-modal="true"><h3>${esc(t(o?"edit":"add"))} — ${esc(titleOf(id))}</h3><form id="mf" novalidate><div class="formgrid">${h}</div>${dl}<div class="actions"><button class="btn" type="submit">${esc(t("save"))}</button><button type="button" class="btn alt" onclick="closeForm()">${esc(t("cancel"))}</button></div></form></div>`;
 document.body.appendChild(m);
 $("mf").onsubmit=ev=>submitForm(ev,id,rid||null);
 const f=m.querySelector("input,select,textarea");if(f&&!rid)f.focus();
}

function submitForm(ev,id,rid){
 ev.preventDefault();const fd=new FormData(ev.target),o={};
 F[id].forEach(([k,kind])=>{let v=fd.get(k);v=v==null?"":String(v).trim();if(kind==="n"&&v!=="")v=Number(v);o[k]=v});
 if(!o.name){alert(t("required"));return}
 if((id==="inventory"||id==="equipment")&&!(o.quantity>0)){alert(t("qtyReq"));return}
 if(id==="inventory"&&o.status==="out"){const s=stockMap(rid).get(skey(o.name,o.unit)),have=s?s.in-s.out:0;if(o.quantity>have){alert(t("notEnough")+" "+fmtNum(have));return}}
 if(id==="estimates"&&(o.taxPercent===""||o.taxPercent==null))o.taxPercent=Number(d.taxRate)||0;
 if(id==="invoices"){const dflt={taxPercent:d.taxRate,retentionPercent:d.retentionPercent,withholdingPercent:d.withholdingPercent};for(const k of Object.keys(dflt)){if(o[k]===""||o[k]==null)o[k]=Number(dflt[k])||0;if(!(o[k]>=0&&o[k]<=100)){alert(t("pctRange"));return}}Object.assign(o,invCalc(o))}
 if(id==="estimates"){o.subtotal=(Number(o.quantity)||0)*(Number(o.unitPrice)||0);o.markupAmount=o.subtotal*(Number(o.markupPercent)||0)/100;o.taxAmount=(o.subtotal+o.markupAmount)*(Number(o.taxPercent)||0)/100;o.total=o.subtotal+o.markupAmount+o.taxAmount;}
 if(rid){const rec=d[id].find(x=>x.id===rid);if(rec){Object.assign(rec,o,{updatedAt:new Date().toISOString(),updatedBy:d.userId||"local-user"});audit("update",id,rid,rec.name||rec.description||"")}}else{const rec={id:uid(),createdAt:new Date().toISOString(),createdBy:d.userId||"local-user",...o};d[id].push(rec);audit("create",id,rec.id,rec.name||rec.description||"")}
 persist();closeForm();route(cur());renderDashboard();
}

function deleteRecord(id,rid){
 if(!confirm(t("confirmDel")))return;
 d[id]=d[id].filter(x=>x.id!==rid);audit("delete",id,rid,"record deleted");
 if(id==="clients"||id==="projects"){const fld=id==="clients"?"client":"project";IDS.forEach(k=>d[k].forEach(r=>{if(r[fld]===rid)r[fld]=""}))}
 persist();if(cur()==="client:"+rid)nav.pop();route(cur());renderDashboard();
}

function recordText(id,o){
 const lines=[titleOf(id),t("createdAt")+": "+fmtDate(o.createdAt,true)];
 if(o.updatedAt)lines.push(t("updatedAt")+": "+fmtDate(o.updatedAt,true));
 F[id].forEach(([k,kind,lk,ex])=>{const v=o[k];if(v===""||v==null)return;let val=kind==="ref"?rname(ex,v):kind==="s"?t(v):(kind==="d"||kind==="dt")?fmtDate(v,true):(kind==="n"&&MONEY.includes(k)?money(v,o.currency):String(v));lines.push(t(lk)+": "+val)});
 if(id==="estimates"&&o.total!=null)lines.push(t("total")+": "+money(o.total));
 return lines.join("\n");
}

async function copyText(txt){try{await navigator.clipboard.writeText(txt);alert(t("copied"))}catch(e){const ta=document.createElement("textarea");ta.value=txt;document.body.appendChild(ta);ta.select();document.execCommand("copy");ta.remove();alert(t("copied"))}}

async function shareText(title,txt){if(navigator.share){try{await navigator.share({title,text:txt});return}catch(e){if(e&&e.name==="AbortError")return}}try{await navigator.clipboard.writeText(txt);alert(t("shared"))}catch(e){const ta=document.createElement("textarea");ta.value=txt;document.body.appendChild(ta);ta.select();document.execCommand("copy");ta.remove();alert(t("shared"))}}

function copyRecord(id,rid){const o=d[id].find(x=>x.id===rid);if(o)copyText(recordText(id,o))}

function shareRecord(id,rid){const o=d[id].find(x=>x.id===rid);if(o)shareText(titleOf(id)+": "+(o.name||o.description||""),recordText(id,o))}

function moduleText(id){if(id==="reports"){const inc=sum(d.finance.filter(x=>x.type==="income"),x=>toBase(x.amount,x.currency)),exp=sum(d.finance.filter(x=>x.type==="expense"),x=>toBase(x.amount,x.currency));return [titleOf(id),t("createdAt")+": "+fmtDate(new Date().toISOString(),true),t("income")+": "+money(inc),t("expense")+": "+money(exp),t("net")+": "+money(inc-exp)].join("\n")}return [titleOf(id),t("records")+": "+fmtNum(d[id].length),...d[id].slice(-20).reverse().map(o=>"— "+recordText(id,o).split("\n").join(" | "))].join("\n")}

function copyModule(id){copyText(moduleText(id))}

function shareModule(id){shareText(titleOf(id),moduleText(id))}
