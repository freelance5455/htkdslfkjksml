"use strict";
function renderModule(id){
 $("detailTitle").textContent=titleOf(id);const b=$("detailBody"),fab=$("fab");
 if(id==="smartEstimate"){b.innerHTML=smartEstimateView();fab.style.display="none";return}
 if(id==="settings"){b.innerHTML=settingsView();fab.style.display="none";return}
 if(id==="reports"){b.innerHTML=reportsView();fab.style.display="none";return}
 if(id==="schedule"){b.innerHTML=scheduleView();fab.style.display="flex";fab.onclick=()=>openForm(id);return}
 fab.style.display="flex";fab.onclick=()=>openForm(id);
 b.innerHTML=`<div class="actions"><button class="btn" onclick="openForm('${id}')">+ ${esc(t("add"))}</button><button class="btn alt" onclick="copyModule('${id}')">📋 ${esc(t("copy"))}</button><button class="btn alt" onclick="shareModule('${id}')">📤 ${esc(t("shareModule"))}</button></div>`
  +(id==="inventory"?`<h3>🗄️ ${esc(t("shelfView"))}</h3><div id="shelf" class="shelf"></div><h3>${esc(t("movements"))}</h3>`:"")
  +`<div class="field"><input id="searchBox" placeholder="${esc(t("search"))}" oninput="renderList('${id}')"></div><div id="records" class="list" style="margin-top:12px"></div>`;
 renderList(id);
}

function itemCard(id,o){
 let h="";const tag=o.status||o.type;
 F[id].forEach(([k,kind,lk,ex])=>{
  if(k==="name"||k==="notes"||k==="status"||k==="type")return;
  const v=o[k];if(v===""||v==null)return;let s;
  if(kind==="ref")s=esc(rname(ex,v));else if(kind==="s")s=esc(t(v));else if(kind==="d"||kind==="dt")s=esc(fmtDate(v));
  else if(kind==="n")s=MONEY.includes(k)?money(v,o.currency):fmtNum(v);else s=esc(v);
  h+=`<div>${esc(t(lk))}: <b>${s}</b></div>`;
 });
 if(id==="invoices"&&o.invoiceTotal!=null){[["taxAmount",o.taxAmount],["invoiceTotal",o.invoiceTotal],["retentionAmount",o.retentionAmount],["withholdingAmount",o.withholdingAmount],["netPayable",o.netPayable]].forEach(([k,v])=>{if(v)h+=`<div>${esc(t(k))}: <b>${money(v,o.currency)}</b></div>`})}
 if(id==="estimates"&&o.total!=null)h+=`<div>${esc(t("subtotal"))}: <b>${money(o.subtotal||0)}</b> · ${esc(t("markup"))}: <b>${fmtNum(o.markupPercent||0)}%</b> · ${esc(t("taxPercent"))}: <b>${fmtNum(o.taxPercent||0)}%</b></div><div>${esc(t("total"))}: <b>${money(o.total)}</b></div>`;
 if(id==="clients"){const a=acct(o.id);h+=`<div>${esc(t("contractsTotal"))}: <b>${money(a.ct)}</b> · ${esc(t("received"))}: <b>${money(a.rc)}</b> · ${esc(t("remaining"))}: <b class="${a.bal>0?"dangertext":"ok"}">${money(a.bal)}</b></div>`}
 if(o.notes)h+=`<div class="muted">${esc(t("notes"))}: ${esc(o.notes)}</div>`;
 const title=o.name||o.description||o.fileName||"—",q=`'${id}','${esc(o.id)}'`;
 const open=id==="clients"?` click" onclick="openClient('${esc(o.id)}')`:id==="projects"?` click" onclick="openProject('${esc(o.id)}')`:`"`;
 return `<div class="item${open}><div class="itemrow"><strong>${esc(title)}</strong>${tag?`<span class="tag t_${esc(tag)}">${esc(t(tag))}</span>`:""}</div>`
  +`${o.recordDate?`<div class="muted" style="margin-top:6px">${esc(t("date"))}: ${esc(fmtDate(o.recordDate,true))}</div>`:""}<div class="muted" style="margin-top:6px">${esc(t("createdAt"))}: ${esc(fmtDate(o.createdAt,true))}${o.updatedAt?` · ${esc(t("updatedAt"))}: ${esc(fmtDate(o.updatedAt,true))}`:""}</div>${h}`
  +`<div class="actions">${id==="clients"?`<button class="btn">👤 ${esc(t("account"))}</button>`:""}<button class="btn alt" onclick="event.stopPropagation();copyRecord('${id}','${esc(o.id)}')">📋 ${esc(t("copy"))}</button><button class="btn alt" onclick="event.stopPropagation();shareRecord('${id}','${esc(o.id)}')">📤 ${esc(t("share"))}</button>${["estimates","contracts","invoices"].includes(id)?`<button class="btn alt" onclick="event.stopPropagation();printRecord('${id}','${esc(o.id)}')">🖨️</button>`:""}${CP20_FILE_MODS.includes(id)?`<button class="btn alt" onclick="event.stopPropagation();cp20OpenFiles('${id}','${esc(o.id)}')">📎</button>`:""}${CP20_SIGN_MODS.includes(id)?`<button class="btn alt" onclick="event.stopPropagation();cp20OpenSign('${id}','${esc(o.id)}')">✍️${o.approval?(o.approval.decision==='approved'?' ✅':' ⛔'):''}</button>`:""}${id==="drawings"?`<button class="btn" onclick="event.stopPropagation();cp20OpenSheet('${esc(o.id)}')">🗺️</button>`:""}<button class="btn alt" aria-label="${esc(t("edit"))}" onclick="event.stopPropagation();openForm(${q})">✏️</button><button class="btn danger" aria-label="${esc(t("delete"))}" onclick="event.stopPropagation();deleteRecord(${q})">🗑️</button></div></div>`;
}

function renderList(id){
 const box=$("records");if(!box)return;
 const q=($("searchBox")?.value||"").toLowerCase();
 if(id==="inventory")renderShelf(q);
 const arr=d[id].filter(o=>searchText(id,o).includes(q)).reverse();
 if(!arr.length){box.innerHTML=`<div class="empty">${esc(t("noData"))}</div>`;return}
 if(id==="equipment"){
  const g={};arr.forEach(o=>{(g[o.project||""]=g[o.project||""]||[]).push(o)});
  box.innerHTML=Object.keys(g).map(p=>`<div class="grp">🏗️ ${esc(p?rname("projects",p):t("noProject"))} — ${fmtNum(sum(g[p],x=>x.quantity))} ${esc(t("pieces"))}</div>`+g[p].map(o=>itemCard(id,o)).join("")).join("");
 }else box.innerHTML=arr.map(o=>itemCard(id,o)).join("");
}

function sectionList(title,id,arr){return `<h3 style="margin-top:18px">${esc(title)}</h3><div class="list">${arr.length?[...arr].reverse().map(o=>itemCard(id,o)).join(""):`<div class="empty">${esc(t("noData"))}</div>`}</div>`}
