"use strict";
/* Stage layout: module cards alternate between the two side columns, the hero artwork sits in the middle. Safe to call again after extra cards are appended. */
function layoutStage(){
 const g=$("moduleGrid");if(!g)return;
 let hero=g.querySelector(":scope > .hero");
 if(!hero){hero=document.createElement("div");hero.className="hero";hero.setAttribute("aria-hidden","true");hero.innerHTML='<img class="art" src="img/hero.jpg" alt="" decoding="async"><img class="ya-hero" src="img/ya-logo.png" alt="">';g.prepend(hero)}
 const cards=[...g.children].filter(c=>c.classList.contains("click"));
 cards.forEach((c,i)=>{c.classList.remove("mod-l","mod-r");c.classList.add(i%2===0?"mod-l":"mod-r")});
 hero.style.gridRow="1 / span "+Math.max(1,Math.ceil(cards.length/2));
 const h=document.querySelector("header");if(h)document.documentElement.style.setProperty("--hdrh",(h.offsetHeight+20)+"px");
}
window.addEventListener("resize",()=>{const h=document.querySelector("header");if(h)document.documentElement.style.setProperty("--hdrh",(h.offsetHeight+20)+"px")});
function renderDashboard(){
 refreshNotifications();
 const g=$("moduleGrid");g.innerHTML="";
 MODS.forEach(([id,ic])=>{
  const c=document.createElement("div");c.className="card click";c.tabIndex=0;
  c.innerHTML=`<div class="icon">${ic}</div><h3>${esc(titleOf(id))}</h3><div class="muted">${esc(descOf(id))}</div>`+(F[id]?`<button class="plus" aria-label="${esc(t("add"))}" onclick="event.stopPropagation();quickAdd('${id}')">+</button>`:"");
  c.onclick=()=>openModule(id);c.onkeydown=e=>{if(e.key==="Enter"&&e.target===c)openModule(id)};g.appendChild(c);
 });
 layoutStage();
 $("dashProjects").textContent=fmtNum(d.projects.length);$("dashClients").textContent=fmtNum(d.clients.length);
 $("dashIncome").textContent=money(sum(d.finance.filter(x=>x.type==="income"),x=>toBase(x.amount,x.currency)));
 $("dashExpense").textContent=money(sum(d.finance.filter(x=>x.type==="expense"),x=>toBase(x.amount,x.currency)));
 if($("connectedProjects"))$("connectedProjects").textContent=fmtNum(d.projects.length);
 if($("connectedStock"))$("connectedStock").textContent=fmtNum(sum([...stockMap().values()],x=>x.in-x.out));
 if($("connectedTools"))$("connectedTools").textContent=fmtNum(d.equipment.length);
 if($("connectedUnits"))$("connectedUnits").textContent=t(d.unitSystem);
 if($('connectedSync'))$('connectedSync').textContent=(d.sync?.enabled?t('cloudReady'):t('offlineReady'));
 if($('connectedPending'))$('connectedPending').textContent=fmtNum(d.sync?.pending||0);
 const overdueInv=d.invoices.filter(x=>x.status!=="paid"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const overdueTasks=d.schedule.filter(x=>x.status!=="done"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const openChanges=d.changeOrders.filter(x=>!['approved','rejected'].includes(x.status)).length;
 const lowStock=[...stockMap().values()].filter(x=>(x.in-x.out)<=x.minStock).length;
 if($('attentionInvoices'))$('attentionInvoices').textContent=fmtNum(overdueInv);if($('attentionTasks'))$('attentionTasks').textContent=fmtNum(overdueTasks);if($('attentionChanges'))$('attentionChanges').textContent=fmtNum(openChanges);if($('attentionStock'))$('attentionStock').textContent=fmtNum(lowStock);
}
