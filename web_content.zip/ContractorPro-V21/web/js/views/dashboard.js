"use strict";
function renderDashboard(){
 refreshNotifications();
 const left=$("moduleGridLeft"),right=$("moduleGridRight");if(left)left.innerHTML="";if(right)right.innerHTML="";
 MODS.forEach(([id,ic],index)=>{
  const c=document.createElement("button");c.type="button";c.className="cp-module-key";
  c.innerHTML=`<span class="cp-module-icon">${ic}</span><span class="cp-module-copy"><strong>${esc(titleOf(id))}</strong><small>${esc(descOf(id))}</small></span><span class="cp-module-arrow" aria-hidden="true">↗</span>`;
  c.onclick=()=>openModule(id);(index%2===0?left:right)?.appendChild(c);
 });
 renderDashboardProgress();
 $("dashProjects").textContent=fmtNum(d.projects.length);$("dashClients").textContent=fmtNum(d.clients.length);
 $("dashIncome").textContent=money(sum(d.finance.filter(x=>x.type==="income"),x=>toBase(x.amount,x.currency)));
 $("dashExpense").textContent=money(sum(d.finance.filter(x=>x.type==="expense"),x=>toBase(x.amount,x.currency)));
 if($("connectedProjects"))$("connectedProjects").textContent=fmtNum(d.projects.length);
 if($("connectedStock"))$("connectedStock").textContent=fmtNum(sum([...stockMap().values()],x=>x.in-x.out));
 if($("connectedTools"))$("connectedTools").textContent=fmtNum(d.equipment.length);
 if($("connectedUnits"))$("connectedUnits").textContent=t(d.unitSystem);
 if($('connectedSync'))$('connectedSync').textContent=(d.sync?.enabled?t('cloudReady'):t('offlineReady'));
 if($('connectedPending'))$('connectedPending').textContent=fmtNum(d.sync?.pending||0);
 const overdueInv=d.invoices.filter(x=>x.status!=="paid"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const overdueTasks=d.schedule.filter(x=>x.status!=="done"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const openChanges=d.changeOrders.filter(x=>!['approved','rejected'].includes(x.status)).length;
 const lowStock=[...stockMap().values()].filter(x=>(x.in-x.out)<=x.minStock).length;
 if($('attentionInvoices'))$('attentionInvoices').textContent=fmtNum(overdueInv);if($('attentionTasks'))$('attentionTasks').textContent=fmtNum(overdueTasks);if($('attentionChanges'))$('attentionChanges').textContent=fmtNum(openChanges);if($('attentionStock'))$('attentionStock').textContent=fmtNum(lowStock);
}


function renderDashboardProgress(){
 const host=$("dashboardProgress");if(!host)return;
 const projects=Array.isArray(d.projects)?d.projects:[],tasks=Array.isArray(d.schedule)?d.schedule:[];
 if(!projects.length){host.innerHTML='<div class="cp-progress-empty">🏗️ هنوز پروژه‌ای ثبت نشده است. از کلید «پروژه‌ها» اولین پروژه را ایجاد کنید.</div>';return;}
 const rows=projects.slice(0,8).map(p=>{
  const list=tasks.filter(x=>x.project===p.id),done=list.reduce((n,x)=>n+(x.status==='done'||x.status==='completed'?1:Math.max(0,Math.min(100,Number(x.percentComplete)||0))/100),0);
  const pct=list.length?Math.round(done/list.length*100):0;
  return {name:String(p.name||'پروژه بدون نام'),pct,count:list.length};
 });
 host.innerHTML=rows.map(x=>`<div class="cp-progress-row"><div class="cp-progress-label"><strong>${esc(x.name)}</strong><span>${x.count?fmtNum(x.pct)+'%':'—'} <small>${x.count?'پیشرفت':'بدون فعالیت'}</small></span></div><div class="cp-progress-track" role="progressbar" aria-label="${esc(x.name)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${x.pct}"><span style="width:${x.pct}%"></span></div><div class="cp-progress-foot">${x.count?fmtNum(x.count)+' فعالیت زمان‌بندی‌شده':'برای نمایش درصد، فعالیت‌ها را در برنامه زمان‌بندی ثبت کنید'}</div></div>`).join('');
}
