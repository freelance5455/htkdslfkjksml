"use strict";
function renderDashboard(){
 refreshNotifications();
 const g=$("moduleGrid");g.innerHTML="";
 MODS.forEach(([id,ic])=>{
  const c=document.createElement("div");c.className="card click";c.tabIndex=0;
  c.innerHTML=`<div class="icon">${ic}</div><h3>${esc(titleOf(id))}</h3><div class="muted">${esc(descOf(id))}</div>`+(F[id]?`<button class="plus" aria-label="${esc(t("add"))}" onclick="event.stopPropagation();quickAdd('${id}')">+</button>`:"");
  c.onclick=()=>openModule(id);c.onkeydown=e=>{if(e.key==="Enter"&&e.target===c)openModule(id)};g.appendChild(c);
 });
 $("dashProjects").textContent=fmtNum(d.projects.length);$("dashClients").textContent=fmtNum(d.clients.length);
 $("dashIncome").textContent=money(sum(d.finance.filter(x=>x.type==="income"),x=>toBase(x.amount,x.currency)));
 $("dashExpense").textContent=money(sum(d.finance.filter(x=>x.type==="expense"),x=>toBase(x.amount,x.currency)));
 if($("connectedProjects"))$("connectedProjects").textContent=fmtNum(d.projects.length);
 if($("connectedStock"))$("connectedStock").textContent=fmtNum(sum([...stockMap().values()],x=>x.in-x.out));
 if($("connectedTools"))$("connectedTools").textContent=fmtNum(d.equipment.length);
 if($("connectedUnits"))$("connectedUnits").textContent=t(d.unitSystem);
 if($('connectedSync'))$('connectedSync').textContent=(d.sync?.enabled?t('cloudReady'):t('offlineReady'));
 if($('connectedPending'))$('connectedPending').textContent=fmtNum(d.sync?.pending||0);
 const overdueInv=d.invoices.filter(x=>x.status!=="paid"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const overdueTasks=d.schedule.filter(x=>x.status!=="done"&&x.dueDate&&new Date(x.dueDate)<new Date()).length;
 const openChanges=d.changeOrders.filter(x=>!['approved','rejected'].includes(x.status)).length;
 const lowStock=[...stockMap().values()].filter(x=>(x.in-x.out)<=x.minStock).length;
 if($('attentionInvoices'))$('attentionInvoices').textContent=fmtNum(overdueInv);if($('attentionTasks'))$('attentionTasks').textContent=fmtNum(overdueTasks);if($('attentionChanges'))$('attentionChanges').textContent=fmtNum(openChanges);if($('attentionStock'))$('attentionStock').textContent=fmtNum(lowStock);
}
