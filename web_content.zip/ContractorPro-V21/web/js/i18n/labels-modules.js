"use strict";
I["m_rfis"]={"en": "RFIs", "fa": "درخواست‌های اطلاعات (RFI)", "ar": "طلبات المعلومات (RFI)", "tr": "Bilgi Talepleri (RFI)", "ru": "Запросы информации (RFI)", "fr": "Demandes d'information (RFI)", "de": "Informationsanfragen (RFI)", "es": "Solicitudes de información (RFI)", "pt": "Solicitações de informação (RFI)", "id": "Permintaan Informasi (RFI)", "hi": "सूचना अनुरोध (RFI)", "ur": "معلومات کی درخواستیں (RFI)", "bn": "তথ্যের অনুরোধ (RFI)", "mr": "माहिती विनंत्या (RFI)", "ta": "தகவல் கோரிக்கைகள் (RFI)", "te": "సమాచార అభ్యర్థనలు (RFI)", "kn": "ಮಾಹಿತಿ ವಿನಂತಿಗಳು (RFI)", "gu": "માહિતી વિનંતીઓ (RFI)"};

I["d_rfis"]={"en": "Requests for information: questions, answers, cost and schedule impact", "fa": "درخواست‌های اطلاعات: پرسش‌ها، پاسخ‌ها، تأثیر هزینه و زمان‌بندی", "ar": "طلبات المعلومات: الأسئلة والإجابات وأثر التكلفة والجدول الزمني", "tr": "Bilgi talepleri: sorular, yanıtlar, maliyet ve program etkisi", "ru": "Запросы информации: вопросы, ответы, влияние на стоимость и сроки", "fr": "Demandes d'information : questions, réponses, impact sur le coût et le planning", "de": "Anfragen zu Informationen (RFI): Fragen, Antworten, Kosten- und Terminauswirkung", "es": "Solicitudes de información: preguntas, respuestas, impacto en costo y cronograma", "pt": "Solicitações de informação: perguntas, respostas, impacto no custo e no cronograma", "id": "Permintaan informasi: pertanyaan, jawaban, dampak biaya dan jadwal", "hi": "सूचना के लिए अनुरोध: प्रश्न, उत्तर, लागत और शेड्यूल पर प्रभाव", "ur": "معلومات کی درخواستیں: سوالات، جوابات، لاگت اور شیڈول پر اثر", "bn": "তথ্যের জন্য অনুরোধ: প্রশ্ন, উত্তর, খরচ ও সময়সূচির প্রভাব", "mr": "माहितीसाठी विनंत्या: प्रश्न, उत्तरे, खर्च आणि वेळापत्रकावरील परिणाम", "ta": "தகவல் கோரிக்கைகள்: கேள்விகள், பதில்கள், செலவு மற்றும் அட்டவணை தாக்கம்", "te": "సమాచార అభ్యర్థనలు: ప్రశ్నలు, సమాధానాలు, ఖర్చు మరియు షెడ్యూల్ ప్రభావం", "kn": "ಮಾಹಿತಿ ವಿನಂತಿಗಳು: ಪ್ರಶ್ನೆಗಳು, ಉತ್ತರಗಳು, ವೆಚ್ಚ ಮತ್ತು ವೇಳಾಪಟ್ಟಿ ಪರಿಣಾಮ", "gu": "માહિતી માટેની વિનંતીઓ: પ્રશ્નો, જવાબો, ખર્ચ અને શેડ્યૂલની અસર"};

I["m_submittals"]={"en": "Submittals", "fa": "مدارک ارسالی", "ar": "المستندات المقدّمة", "tr": "Onay dosyaları", "ru": "Документы на согласование", "fr": "Soumissions", "de": "Nachweise", "es": "Submittals", "pt": "Submittals", "id": "Submittal", "hi": "सबमिटल", "ur": "سب مٹلز", "bn": "সাবমিটাল", "mr": "सबमिटल्स", "ta": "சப்மிட்டல்கள்", "te": "సబ్‌మిటల్స్", "kn": "ಸಬ್‌ಮಿಟಲ್‌ಗಳು", "gu": "સબમિટલ"};

I["d_submittals"]={"en": "Shop drawings, samples and approvals with review status", "fa": "نقشه‌های کارگاهی، نمونه‌ها و تأییدیه‌ها همراه با وضعیت بازبینی", "ar": "المخططات التنفيذية والعينات والاعتمادات مع حالة المراجعة", "tr": "Şantiye çizimleri, numuneler ve onaylar, inceleme durumuyla", "ru": "Рабочие чертежи, образцы и согласования со статусом проверки", "fr": "Plans d'atelier, échantillons et approbations avec statut de révision", "de": "Werkstattzeichnungen, Muster und Freigaben mit Prüfstatus", "es": "Planos de taller, muestras y aprobaciones con estado de revisión", "pt": "Desenhos de fabricação, amostras e aprovações com status de revisão", "id": "Gambar kerja, sampel, dan persetujuan dengan status tinjauan", "hi": "समीक्षा स्थिति के साथ शॉप ड्रॉइंग, सैंपल और अनुमोदन", "ur": "شاپ ڈرائنگز، نمونے اور منظوریاں بمع جائزے کی حالت", "bn": "পর্যালোচনার অবস্থাসহ শপ ড্রয়িং, নমুনা ও অনুমোদন", "mr": "पुनरावलोकन स्थितीसह शॉप ड्रॉइंग्ज, नमुने आणि मंजुऱ्या", "ta": "மதிப்பாய்வு நிலையுடன் ஷாப் டிராயிங்குகள், மாதிரிகள் மற்றும் ஒப்புதல்கள்", "te": "సమీక్ష స్థితితో షాప్ డ్రాయింగ్‌లు, నమూనాలు మరియు ఆమోదాలు", "kn": "ಪರಿಶೀಲನೆ ಸ್ಥಿತಿಯೊಂದಿಗೆ ಶಾಪ್ ಡ್ರಾಯಿಂಗ್‌ಗಳು, ಮಾದರಿಗಳು ಮತ್ತು ಅನುಮೋದನೆಗಳು", "gu": "સમીક્ષા સ્થિતિ સાથે શોપ ડ્રોઇંગ, નમૂના અને મંજૂરીઓ"};

I["m_punchList"]={"en": "Punch List", "fa": "فهرست نواقص", "ar": "قائمة العيوب", "tr": "Eksik Listesi", "ru": "Перечень замечаний", "fr": "Liste de réserves", "de": "Mängelliste", "es": "Lista de pendientes", "pt": "Lista de pendências", "id": "Daftar punch", "hi": "पंच लिस्ट", "ur": "پنچ لسٹ", "bn": "পাঞ্চ লিস্ট", "mr": "पंच लिस्ट", "ta": "பஞ்ச் பட்டியல்", "te": "పంచ్ జాబితా", "kn": "ಪಂಚ್ ಪಟ್ಟಿ", "gu": "પંચ લિસ્ટ"};

I["d_punchList"]={"en": "Defects and closing-out items by location and trade", "fa": "نواقص و موارد اختتام بر اساس مکان و رشته کاری", "ar": "العيوب وبنود الإغلاق حسب الموقع والتخصص", "tr": "Konum ve branşa göre kusurlar ve kapanış maddeleri", "ru": "Дефекты и замечания к закрытию по местоположению и виду работ", "fr": "Défauts et points de clôture par emplacement et par corps de métier", "de": "Mängel und Restarbeiten nach Ort und Gewerk", "es": "Defectos y pendientes de cierre por ubicación y oficio", "pt": "Defeitos e itens de fechamento por local e especialidade", "id": "Cacat dan item penutupan menurut lokasi dan bidang kerja", "hi": "स्थान और ट्रेड के अनुसार दोष और समापन मदें", "ur": "مقام اور شعبے کے لحاظ سے نقائص اور اختتامی آئٹمز", "bn": "স্থান ও ট্রেড অনুযায়ী ত্রুটি ও সমাপ্তির আইটেম", "mr": "स्थान आणि ट्रेडनुसार दोष आणि समापन बाबी", "ta": "இடம் மற்றும் தொழில் வாரியாக குறைபாடுகள் மற்றும் முடிக்க வேண்டிய பணிகள்", "te": "స్థలం మరియు ట్రేడ్ వారీగా లోపాలు మరియు ముగింపు అంశాలు", "kn": "ಸ್ಥಳ ಮತ್ತು ಟ್ರೇಡ್ ಪ್ರಕಾರ ದೋಷಗಳು ಮತ್ತು ಮುಕ್ತಾಯ ಅಂಶಗಳು", "gu": "સ્થળ અને ટ્રેડ પ્રમાણે ખામીઓ અને પૂર્ણ કરવાની બાબતો"};
I["m_safetyForms"]={"en": "Safety (HSE)", "fa": "ایمنی و بهداشت (HSE)", "ar": "السلامة والصحة", "tr": "İSG Formları", "ru": "Безопасность (ОТ и ТБ)", "fr": "Sécurité (HSE)", "de": "Arbeitssicherheit (HSE)", "hi": "सुरक्षा (HSE)", "ta": "பாதுகாப்பு (HSE)", "te": "భద్రత (HSE)", "kn": "ಸುರಕ್ಷತೆ (HSE)", "mr": "सुरक्षा (HSE)", "gu": "સલામતી (HSE)", "bn": "নিরাপত্তা (HSE)", "es": "Seguridad (HSE)", "pt": "Segurança (HSE)", "ur": "حفاظت (HSE)", "id": "Keselamatan (K3)"};
I["d_safetyForms"]={"en": "Toolbox talks, site inspections, incidents, hazard analysis and permits to work", "fa": "جلسه ایمنی، بازرسی کارگاه، حوادث، تحلیل خطر و مجوز کار", "ar": "اجتماعات السلامة والتفتيش والحوادث", "tr": "Araç kutusu, saha denetimi, olaylar ve çalışma izni", "ru": "Инструктажи, проверки площадки, происшествия, анализ опасностей и наряды-допуски", "fr": "Causeries sécurité, inspections de chantier, incidents, analyse des risques et permis de travail", "de": "Toolbox-Talks, Baustellenbegehungen, Vorfälle, Gefährdungsanalysen und Arbeitsfreigaben", "hi": "टूलबॉक्स टॉक, साइट निरीक्षण, घटनाएँ, जोखिम विश्लेषण और कार्य अनुमति", "ta": "பாதுகாப்பு உரைகள், தள ஆய்வு, சம்பவங்கள், ஆபத்து பகுப்பாய்வு, பணி அனுமதி", "te": "టూల్‌బాక్స్ టాక్స్, సైట్ తనిఖీలు, సంఘటనలు, ప్రమాద విశ్లేషణ, పని అనుమతులు", "kn": "ಟೂಲ್‌ಬಾಕ್ಸ್ ಚರ್ಚೆ, ಸೈಟ್ ತಪಾಸಣೆ, ಘಟನೆಗಳು, ಅಪಾಯ ವಿಶ್ಲೇಷಣೆ, ಕೆಲಸದ ಅನುಮತಿ", "mr": "टूलबॉक्स चर्चा, साइट तपासणी, घटना, धोका विश्लेषण आणि कामाची परवानगी", "gu": "ટૂલબોક્સ ચર્ચા, સાઇટ તપાસ, ઘટનાઓ, જોખમ વિશ્લેષણ અને કાર્ય પરવાનગી", "bn": "টুলবক্স টক, সাইট পরিদর্শন, ঘটনা, ঝুঁকি বিশ্লেষণ ও কাজের অনুমতি", "es": "Charlas de seguridad, inspecciones de obra, incidentes, análisis de riesgos y permisos de trabajo", "pt": "Diálogos de segurança, inspeções de obra, incidentes, análise de riscos e permissões de trabalho", "ur": "ٹول باکس ٹاک، سائٹ معائنہ، حادثات، خطرے کا تجزیہ اور ورک پرمٹ", "id": "Toolbox talk, inspeksi lokasi, insiden, analisis bahaya, dan izin kerja"};
I["m_tenders"]={"en": "Tenders / Bids", "fa": "مناقصه‌ها", "ar": "المناقصات", "tr": "İhaleler", "ru": "Тендеры", "fr": "Appels d'offres", "de": "Ausschreibungen", "hi": "निविदाएँ", "ta": "ஒப்பந்தப்புள்ளிகள்", "te": "టెండర్లు", "kn": "ಟೆಂಡರ್‌ಗಳು", "mr": "निविदा", "gu": "ટેન્ડરો", "bn": "টেন্ডার", "es": "Licitaciones", "pt": "Licitações", "ur": "ٹینڈرز", "id": "Tender"};
I["d_tenders"]={"en": "Bid pipeline: deadlines, bonds, margin and win rate", "fa": "مناقصه‌ها: مهلت، ضمانت‌نامه، حاشیه سود و نرخ برنده شدن", "ar": "مسار العطاءات: المهل والضمانات والهامش", "tr": "İhale süreci: süreler, teminatlar, marj", "ru": "Воронка тендеров: сроки, гарантии, маржа и доля побед", "fr": "Pipeline d'offres : échéances, cautions, marge et taux de réussite", "de": "Angebots-Pipeline: Fristen, Bürgschaften, Marge und Gewinnquote", "hi": "बोली पाइपलाइन: समय-सीमा, गारंटी, मार्जिन और जीत दर", "ta": "ஏல நிலை: காலக்கெடு, உத்தரவாதம், லாபம், வெற்றி விகிதம்", "te": "బిడ్ పైప్‌లైన్: గడువులు, బాండ్లు, మార్జిన్, గెలుపు రేటు", "kn": "ಬಿಡ್ ಪೈಪ್‌ಲೈನ್: ಗಡುವು, ಬಾಂಡ್, ಮಾರ್ಜಿನ್, ಗೆಲುವಿನ ಪ್ರಮಾಣ", "mr": "बोली पाइपलाइन: मुदत, हमी, मार्जिन आणि विजयाचा दर", "gu": "બિડ પાઇપલાઇન: સમયમર્યાદા, બોન્ડ, માર્જિન અને જીતનો દર", "bn": "বিড পাইপলাইন: সময়সীমা, জামানত, মার্জিন ও জয়ের হার", "es": "Embudo de ofertas: plazos, avales, margen y tasa de éxito", "pt": "Funil de propostas: prazos, garantias, margem e taxa de vitória", "ur": "بولی پائپ لائن: ڈیڈ لائن، ضمانت، مارجن اور کامیابی کی شرح", "id": "Pipeline penawaran: tenggat, jaminan, margin, dan tingkat kemenangan"};

I["m_drawings"]={"en": "Drawings", "fa": "نقشه‌ها", "ar": "المخططات", "tr": "Çizimler", "ru": "Чертежи", "fr": "Plans", "de": "Pläne", "es": "Planos", "pt": "Desenhos", "id": "Gambar", "hi": "ड्रॉइंग", "ur": "ڈرائنگز", "bn": "ড্রয়িং", "mr": "ड्रॉइंग्ज", "ta": "வரைபடங்கள்", "te": "డ్రాయింగ్‌లు", "kn": "ನಕ್ಷೆಗಳು", "gu": "ડ્રોઇંગ"};

I["d_drawings"]={"en": "Drawing sheets with pins that become punch items or RFIs", "fa": "برگه‌های نقشه با پین‌هایی که به موارد فهرست نواقص یا RFI تبدیل می‌شوند", "ar": "لوحات مخططات بدبابيس تتحول إلى بنود قائمة العيوب أو RFI", "tr": "Eksik listesi maddelerine veya RFI'lara dönüşen iğneli çizim paftaları", "ru": "Листы чертежей с метками, которые превращаются в пункты перечня замечаний или RFI", "fr": "Feuilles de plans avec repères qui deviennent des points de réserve ou des RFI", "de": "Planblätter mit Markierungen, die zu Mängelpunkten oder RFIs werden", "es": "Hojas de planos con marcadores que se convierten en ítems de punch list o RFI", "pt": "Folhas de desenho com marcadores que viram itens de pendência ou RFIs", "id": "Lembar gambar dengan pin yang dapat menjadi item punch atau RFI", "hi": "पिन वाली ड्रॉइंग शीट, जो पंच आइटम या RFI बन जाती हैं", "ur": "ڈرائنگ شیٹس جن کے پن پنچ آئٹمز یا RFI بن جاتے ہیں", "bn": "পিনসহ ড্রয়িং শিট, যা পাঞ্চ আইটেম বা RFI হয়ে ওঠে", "mr": "पिन असलेल्या ड्रॉइंग शीट, ज्यांचे पंच आयटम किंवा RFI बनतात", "ta": "பஞ்ச் பொருட்கள் அல்லது RFI ஆக மாறும் பின்களுடன் வரைபடத் தாள்கள்", "te": "పంచ్ అంశాలు లేదా RFIలుగా మారే పిన్‌లతో డ్రాయింగ్ షీట్‌లు", "kn": "ಪಂಚ್ ಅಂಶಗಳು ಅಥವಾ RFIಗಳಾಗುವ ಪಿನ್‌ಗಳಿರುವ ನಕ್ಷೆ ಹಾಳೆಗಳು", "gu": "પંચ આઇટમ અથવા RFI બનતી પિન સાથેની ડ્રોઇંગ શીટ"};

I.cloudReady={fa:"آماده اتصال ابری",en:"Cloud bridge ready",ar:"جاهز للربط السحابي",tr:"Bulut bağlantısı hazır",ru:"Готово к облаку",fr:"Prêt pour le cloud",de:"Cloud-Verbindung bereit"};

I.offlineReady={fa:"حالت آفلاین",en:"Offline mode",ar:"وضع عدم الاتصال",tr:"Çevrimdışı",ru:"Офлайн",fr:"Hors ligne",de:"Offline-Modus"};

I.markup={fa:"درصد سود/مارکاپ",en:"Markup %",ar:"نسبة الهامش",tr:"Markup %",ru:"Наценка %",fr:"Marge %",de:"Aufschlag %"};

I.taxPercent={fa:"مالیات %",en:"Tax %",ar:"الضريبة %",tr:"Vergi %",ru:"Налог %",fr:"Taxe %",de:"Steuer %"};

I.subtotal={fa:"جمع پایه",en:"Subtotal",ar:"المجموع الفرعي",tr:"Ara toplam",ru:"Промежуточный итог",fr:"Sous-total",de:"Zwischensumme"};

I.attention={fa:"موارد نیازمند توجه",en:"Needs attention",ar:"يحتاج إلى الانتباه",tr:"Dikkat gerekenler",ru:"Требует внимания",fr:"À surveiller",de:"Aufmerksamkeit nötig"};

I.overdueTasks={fa:"کارهای سررسیدشده",en:"Overdue tasks",ar:"المهام المتأخرة",tr:"Geciken görevler",ru:"Просроченные задачи",fr:"Tâches en retard",de:"Überfällige Aufgaben"};

I.openChanges={fa:"تغییرات باز",en:"Open changes",ar:"التغييرات المفتوحة",tr:"Açık değişiklikler",ru:"Открытые изменения",fr:"Changements ouverts",de:"Offene Änderungen"};

I.m_leads={fa:"سرنخ‌ها و فرصت‌ها",en:"Leads & Opportunities",ar:"العملاء المحتملون والفرص",tr:"Adaylar ve Fırsatlar",ru:"Лиды и возможности",fr:"Prospects et opportunités",de:"Leads & Chancen"};

I.d_leads={fa:"پیگیری فرصت‌ها از درخواست تا قرارداد",en:"Track opportunities from request to contract",ar:"تتبع الفرص من الطلب إلى العقد",tr:"Talepden sözleşmeye fırsat takibi",ru:"Отслеживание возможностей до договора",fr:"Suivre les opportunités jusqu’au contrat",de:"Chancen bis zum Auftrag verfolgen"};

I.m_changeOrders={fa:"تغییرات قرارداد",en:"Change Orders",ar:"أوامر التغيير",tr:"Değişiklik Emirleri",ru:"Изменения договора",fr:"Ordres de changement",de:"Nachträge"};

I.d_changeOrders={fa:"ثبت تغییر مبلغ و وضعیت تأیید",en:"Track scope and contract changes",ar:"تتبع تغييرات النطاق والعقد",tr:"Kapsam ve sözleşme değişiklikleri",ru:"Изменения объёма и договора",fr:"Suivi des changements de périmètre",de:"Änderungen von Umfang und Vertrag"};

I.m_timeEntries={fa:"ثبت زمان کار",en:"Time Tracking",ar:"تتبع الوقت",tr:"Zaman Takibi",ru:"Учёт времени",fr:"Suivi du temps",de:"Zeiterfassung"};

I.d_timeEntries={fa:"ساعت کار نیروها در هر پروژه",en:"Track worker hours by project",ar:"ساعات العمل حسب المشروع",tr:"Projeye göre çalışma saatleri",ru:"Часы работы по проектам",fr:"Heures par projet",de:"Arbeitsstunden je Projekt"};

I.m_dailyLogs={fa:"گزارش روزانه کارگاه",en:"Daily Logs",ar:"التقارير اليومية",tr:"Günlük Şantiye Günlükleri",ru:"Дневные журналы",fr:"Journaux quotidiens",de:"Tagesberichte"};

I.d_dailyLogs={fa:"پیشرفت، نیرو، هوا، مشکل و یادداشت روزانه",en:"Progress, crew, weather, issues and notes",ar:"التقدم والعمال والطقس والمشكلات والملاحظات",tr:"İlerleme, ekip, hava, sorunlar ve notlar",ru:"Прогресс, команда, погода, проблемы и заметки",fr:"Avancement, équipe, météo et problèmes",de:"Fortschritt, Team, Wetter und Probleme"};

I.lead={fa:"سرنخ",en:"Lead",ar:"عميل محتمل",tr:"Aday",ru:"Лид",fr:"Prospect",de:"Lead"};

I.opportunity={fa:"فرصت",en:"Opportunity",ar:"فرصة",tr:"Fırsat",ru:"Вorgang",fr:"Opportunité",de:"Chance"};

I.proposed={fa:"پیشنهاد شده",en:"Proposed",ar:"مقترح",tr:"Teklif",ru:"Предложено",fr:"Proposé",de:"Angeboten"};

I.approved={fa:"تأیید شده",en:"Approved",ar:"معتمد",tr:"Onaylandı",ru:"Утверждено",fr:"Approuvé",de:"Genehmigt"};

I.rejected={fa:"رد شده",en:"Rejected",ar:"مرفوض",tr:"Reddedildi",ru:"Отклонено",fr:"Refusé",de:"Abgelehnt"};

I.pending={fa:"در انتظار",en:"Pending",ar:"قيد الانتظار",tr:"Bekliyor",ru:"Ожидает",fr:"En attente",de:"Ausstehend"};

I.changeAmount={fa:"مبلغ تغییر",en:"Change amount",ar:"مبلغ التغيير",tr:"Değişiklik tutarı",ru:"Сумма изменения",fr:"Montant du changement",de:"Änderungsbetrag"};

I.progress={fa:"پیشرفت",en:"Progress",ar:"التقدم",tr:"İlerleme",ru:"Прогres",fr:"Avancement",de:"Fortschritt"};

I.weather={fa:"هوا",en:"Weather",ar:"الطقس",tr:"Hava",ru:"Погода",fr:"Météo",de:"Wetter"};

I.issues={fa:"مشکلات",en:"Issues",ar:"المشكلات",tr:"Sorunlar",ru:"Проблемы",fr:"Problèmes",de:"Probleme"};

I.hours={fa:"ساعت",en:"Hours",ar:"الساعات",tr:"Saat",ru:"Часы",fr:"Heures",de:"Stunden"};

I.rate={fa:"نرخ ساعتی",en:"Hourly rate",ar:"الأجر بالساعة",tr:"Saatlik ücret",ru:"Почасовая ставка",fr:"Taux horaire",de:"Stundensatz"};

I.health={fa:"سلامت پروژه",en:"Project health",ar:"حالة المشروع",tr:"Proje durumu",ru:"Состояние проекта",fr:"Santé du projet",de:"Projektstatus"};

I.budget={fa:"بودجه",en:"Budget",ar:"الميزانية",tr:"Bütçe",ru:"Бюджет",fr:"Budget",de:"Budget"};

I.actual={fa:"واقعی",en:"Actual",ar:"فعلي",tr:"Gerçek",ru:"Факт",fr:"Réel",de:"Ist"};

I.audit={fa:"ردپای تغییرات",en:"Audit trail",ar:"سجل التدقيق",tr:"Denetim izi",ru:"Журнал действий",fr:"Journal d’audit",de:"Audit-Protokoll"};

I.m_smartEstimate={fa:"AI نقشه → برآورد هوشمند",en:"AI Drawing → Smart Estimate",ar:"مخطط AI ← تقدير ذكي",tr:"AI Çizim → Akıllı Keşif",ru:"AI-чертёж → умная смета",fr:"Plan IA → Estimation intelligente",de:"KI-Zeichnung → Intelligente Kalkulation"};

I.d_smartEstimate={fa:"تحلیل نقشه، متره، BOQ و برآورد هزینه با کنترل اطمینان",en:"Drawing analysis, takeoff, BOQ and cost estimate with confidence controls",ar:"تحليل المخططات والحصر وBOQ والتكلفة مع مؤشرات الثقة",tr:"Çizim analizi, metraj, BOQ ve güven göstergeli maliyet",ru:"Анализ чертежей, ведомость объёмов и смета с контролем уверенности",fr:"Analyse des plans, métré, DQE et estimation avec niveau de confiance",de:"Plananalyse, Mengen, LV und Kostenschätzung mit Konfidenz"};

I.uploadDrawing={fa:"آپلود نقشه",en:"Upload drawing",ar:"رفع المخطط",tr:"Çizim yükle",ru:"Загрузить чертёж",fr:"Téléverser le plan",de:"Plan hochladen"};

I.analyzeDrawing={fa:"شروع تحلیل نقشه",en:"Analyze drawing",ar:"Analyser le plan",tr:"Çizimi analiz et",ru:"Анализировать чертёж",fr:"Analyser le plan",de:"Plan analysieren"};

I.takeoff={fa:"متره و استخراج مقادیر",en:"Quantity takeoff",ar:"حصر الكميات",tr:"Metraj",ru:"Подсчёт объёмов",fr:"Métré",de:"Mengenermittlung"};

I.boq={fa:"فهرست مقادیر (BOQ)",en:"Bill of Quantities (BOQ)",ar:"جدول الكميات",tr:"Metraj Listesi (BOQ)",ru:"Ведомость объёмов (BOQ)",fr:"Bordereau des quantités (DQE)",de:"Leistungsverzeichnis (LV)"};

I.confidence={fa:"درصد اطمینان",en:"Confidence",ar:"درجة الثقة",tr:"Güven",ru:"Уверенность",fr:"Confiance",de:"Konfidenz"};

I.assumptions={fa:"فرضیات و موارد نامطمئن",en:"Assumptions & uncertainties",ar:"الافتراضات وحالات عدم اليقين",tr:"Varsayımlar ve belirsizlikler",ru:"Допущения и неопределённости",fr:"Hypothèses et incertitudes",de:"Annahmen und Unsicherheiten"};

I.costDatabase={fa:"پایگاه قیمت منطقه‌ای",en:"Regional cost database",ar:"قاعدة الأسعار الإقليمية",tr:"Bölgesel maliyet veritabanı",ru:"Региональная база цен",fr:"Base de coûts régionale",de:"Regionale Kostendatenbank"};

I.missingData={fa:"اطلاعات ناقص نقشه",en:"Missing drawing information",ar:"معلومات مفقودة في المخطط",tr:"Eksik çizim bilgileri",ru:"Недостающие данные чертежа",fr:"Informations manquantes",de:"Fehlende Planinformationen"};

I.smartEstimateReady={fa:"هسته برآورد هوشمند آماده اتصال به سرور است.",en:"The smart estimating workspace is ready for secure server analysis.",ar:"مساحة التقدير الذكي جاهزة للتحليل الآمن عبر الخادم.",tr:"Akıllı keşif çalışma alanı güvenli sunucu analizine hazır.",ru:"Рабочее пространство умной сметы готово к серверному анализу.",fr:"L’espace d’estimation intelligente est prêt pour l’analyse serveur sécurisée.",de:"Der intelligente Kalkulationsbereich ist für die sichere Serveranalyse bereit."};
