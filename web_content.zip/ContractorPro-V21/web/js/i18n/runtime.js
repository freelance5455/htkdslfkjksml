(function(){
var TX=window.CP_I18N.runtime;
var REV=null,ORIG=new WeakMap(),AORIG=new WeakMap(),busy=false;
function buildRev(){REV={};try{Object.keys(I).forEach(function(k){var v=I[k];if(v&&v.en&&!REV[v.en.trim()])REV[v.en.trim()]=v})}catch(e){}}
function lang(){return (typeof d!=='undefined'&&d.lang)||'en'}
Object.assign(TX,window.CP_I18N.runtimeExtra,window.CP_I18N.runtimeHardcoded||{});
function look(core,L){var e=TX[core];if(e&&e[L])return e[L];if(!REV)buildRev();var r=REV[core];if(r&&r[L])return r[L];return null}
function tr(s,L){
 L=L||lang();if(L==='en'||typeof s!=='string')return s;
 var m=s.match(/^(\s*)([\s\S]*?)(\s*)$/),core=m[2];if(!core||!/[A-Za-z]{2}/.test(core))return s;
 var hit=look(core,L);if(hit!==null)return m[1]+hit+m[3];
 if(/ \*$/.test(core)){var st=look(core.slice(0,-2),L);if(st!==null)return m[1]+st+' *'+m[3]}
 if(/^[^:]{2,80}:$/.test(core)){var lb=look(core.slice(0,-1),L);if(lb!==null)return m[1]+lb+':'+m[3]}
 var ss=core.split(/(?<=[.!?])\s+(?=[A-Z])/);if(ss.length>1){var sc=false,sq=ss.map(function(x){var y=tr(x,L);if(y!==x)sc=true;return y});if(sc)return m[1]+sq.join(' ')+m[3]}
 var nl=core.split('\n');if(nl.length>1){var nc=false,nq=nl.map(function(x){var y=tr(x,L);if(y!==x)nc=true;return y});if(nc)return m[1]+nq.join('\n')+m[3]}
 var c=core.match(/^([^:]{2,80}:)\s*([\s\S]+)$/);
 if(c){var a=look(c[1],L),b=tr(c[2],L);if(a===null){var a0=look(c[1].slice(0,-1),L);if(a0!==null)a=a0+':'}if(a!==null||b!==c[2])return m[1]+(a!==null?a:c[1])+' '+b+m[3]}
 var e=core.match(/^([^A-Za-z]{1,6})([A-Za-z][\s\S]*)$/);
 if(e&&!/^[\d\s.,:;()\-+/]+$/.test(e[1])){var z=tr(e[2],L);if(z!==e[2])return m[1]+e[1]+z+m[3]}
 var p=core.split(' · ');
 if(p.length>1){var ch=false,q=p.map(function(x){var y=tr(x,L);if(y!==x)ch=true;return y});if(ch)return m[1]+q.join(' · ')+m[3]}
 return s}
window.cpTr=tr;
var SKIP={SCRIPT:1,STYLE:1,CODE:1,PRE:1};
function doText(n){
 var p=n.parentElement;if(!p||SKIP[p.tagName]||p.closest('[data-notr]'))return;
 var rec=ORIG.get(n),cur=n.nodeValue;
 if(rec&&rec.out===cur){/* unchanged since we wrote it: retranslate from source */}else rec={src:cur,out:cur};
 var o=tr(rec.src);rec.out=o;ORIG.set(n,rec);if(o!==cur)n.nodeValue=o}
var ATTR=['placeholder','title','aria-label'];
function doEl(e){
 if(e.nodeType!==1||SKIP[e.tagName]||e.closest('[data-notr]'))return;
 var rec=AORIG.get(e)||{};
 ATTR.forEach(function(a){var v=e.getAttribute(a);if(v==null)return;var r=rec[a];if(!(r&&r.out===v))r={src:v,out:v};var o=tr(r.src);r.out=o;rec[a]=r;if(o!==v)e.setAttribute(a,o)});
 AORIG.set(e,rec)}
function walk(root){
 if(!root)return;
 if(root.nodeType===3){doText(root);return}
 if(root.nodeType!==1)return;
 doEl(root);
 var w=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT),n;
 while((n=w.nextNode())){if(n.nodeType===3)doText(n);else doEl(n)}}
function run(root){if(busy)return;busy=true;try{walk(root||document.body)}finally{busy=false}}
window.cpTrRun=run;
var obs=new MutationObserver(function(ms){
 if(busy)return;busy=true;
 try{ms.forEach(function(m){
  if(m.type==='childList')m.addedNodes.forEach(function(n){walk(n)});
  else if(m.type==='characterData')doText(m.target);
  else if(m.type==='attributes')doEl(m.target)})}finally{busy=false}});
function start(){obs.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:ATTR});run()}
['alert','confirm','prompt'].forEach(function(k){var f=window[k];if(!f)return;window[k]=function(m){var a=[].slice.call(arguments);a[0]=tr(String(m==null?'':m));return f.apply(window,a)}});
var ocl=window.onLanguageChange;
if(typeof ocl==='function')window.onLanguageChange=function(){var r=ocl.apply(this,arguments);setTimeout(run,0);return r};
if(document.body)start();else document.addEventListener('DOMContentLoaded',start);
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){cp20LegalGate()});else setTimeout(cp20LegalGate,0);
})();
