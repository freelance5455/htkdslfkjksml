"use strict";
I.companyName={fa:"نام شرکت/کسب‌وکار",en:"Company / Business Name",ar:"اسم الشركة / النشاط",tr:"Şirket / İşletme Adı",ru:"Название компании / бизнеса",fr:"Nom de l’entreprise",de:"Firmen-/Betriebsname"};

I.role={fa:"نقش کاربر",en:"User Role",ar:"دور المستخدم",tr:"Kullanıcı Rolü",ru:"Роль пользователя",fr:"Rôle utilisateur",de:"Benutzerrolle"};

I.workDays={fa:"روزهای کاری",en:"Work Days",ar:"أيام العمل",tr:"Çalışma Günleri",ru:"Рабочие дни",fr:"Jours travaillés",de:"Arbeitstage"};

I.overtime={fa:"اضافه‌کاری",en:"Overtime",ar:"العمل الإضافي",tr:"Fazla Mesai",ru:"Сверхурочные",fr:"Heures supplémentaires",de:"Überstunden"};

I.payment={fa:"پرداخت‌شده",en:"Paid",ar:"مدفوع",tr:"Ödenen",ru:"Ödenen",fr:"Payé",de:"Bezahlt"};

I.shelf={fa:"قفسه/محل",en:"Shelf / Location",ar:"الرف / الموقع",tr:"Raf / Konum",ru:"Полка / Место",fr:"Étagère / Emplacement",de:"Regal / Standort"};

I.minStock={fa:"حداقل موجودی",en:"Minimum Stock",ar:"Mindestbestand",tr:"Minimum Stok",ru:"Минимальный запас",fr:"Stock minimum",de:"Mindestbestand"};

I.category={fa:"نوع/دسته",en:"Type / Category",ar:"النوع / الفئة",tr:"Tür / Kategori",ru:"Тип / Категория",fr:"Type / Catégorie",de:"Typ / Kategorie"};

I.paymentSchedule={fa:"برنامه اقساط",en:"Payment Schedule",ar:"جدول الدفعات",tr:"Ödeme Planı",ru:"График платежей",fr:"Échéancier",de:"Zahlungsplan"};

I.signatureStatus={fa:"وضعیت امضا",en:"Signature Status",ar:"حالة التوقيع",tr:"İmza Durumu",ru:"Статус подписи",fr:"Statut de signature",de:"Unterschriftsstatus"};

I.pending={fa:"در انتظار",en:"Pending",ar:"قيد الانتظار",tr:"Bekliyor",ru:"Оdağı bekliyor",fr:"En attente",de:"Ausstehend"};

I.signed={fa:"امضا شده",en:"Signed",ar:"موقّع",tr:"İmzalandı",ru:"Подzeichnet",fr:"Signé",de:"Unterzeichnet"};

I.cancelled={fa:"لغو شده",en:"Cancelled",ar:"ملغى",tr:"İptal",ru:"Отlandı",fr:"Annulé",de:"Storniert"};

I.contractor={fa:"پیمانکار",en:"Contractor",ar:"مقاول",tr:"Müteahhit",ru:"Подрядчик",fr:"Entrepreneur",de:"Bauunternehmer"};

I.company={fa:"شرکت ساختمانی",en:"Construction Company",ar:"شركة مقاولات",tr:"İnşaat Şirketi",ru:"Строительная компания",fr:"Entreprise de construction",de:"Bauunternehmen"};

I.tradesperson={fa:"استادکار / فنی‌کار",en:"Tradesperson",ar:"حرفي",tr:"Usta / Zanaatkâr",ru:"Мастер",fr:"Artisan",de:"Handwerker"};

I.client={fa:"کارفرما / مشتری",en:"Client / Employer",ar:"العميل / صاحب العمل",tr:"Müşteri / İşveren",ru:"Клиент / Заказчик",fr:"Client / Donneur d’ordre",de:"Kunde / Auftraggeber"};

I.owner={fa:"مالک",en:"Property Owner",ar:"مالك العقار",tr:"Mülk Sahibi",ru:"Вarlık Sahibi",fr:"Propriétaire",de:"Eigentümer"};

I.worker={fa:"کارگر",en:"Worker",ar:"عامل",tr:"İşçi",ru:"Рабочий",fr:"Ouvrier",de:"Arbeiter"};

I.saved={fa:"ذخیره شد",en:"Saved",ar:"تم الحفظ",tr:"Kaydedildi",ru:"Сохранено",fr:"Enregistré",de:"Gespeichert"};

I.profile={fa:"پروفایل کسب‌وکار",en:"Business Profile",ar:"ملف النشاط",tr:"İşletme Profili",ru:"Профиль бизнеса",fr:"Profil d’entreprise",de:"Unternehmensprofil"};

I.version={fa:"نسخه",en:"Version",ar:"الإصدار",tr:"Sürüm",ru:"Версия",fr:"Version",de:"Version"};

I.open={fa:"باز کردن",en:"Open",ar:"فتح",tr:"Aç",ru:"Открыть",fr:"Ouvrir",de:"Öffnen"};

I.net={fa:"خالص",en:"Net",ar:"الصافي",tr:"Net",ru:"Итог",fr:"Net",de:"Netto"};

I.tool={fa:"ابزار",en:"Tools",ar:"الأدوات",tr:"Araçlar",ru:"Инструменты",fr:"Outils",de:"Werkzeuge"};

I.globalSearch={fa:"جستجوی همه‌چیز",en:"Search everything",ar:"بحث شامل",tr:"Her şeyi ara",ru:"Поиск по всему",fr:"Rechercher partout",de:"Alles durchsuchen"};

I.quickCapture={fa:"ثبت سریع",en:"Quick Capture",ar:"إدخال سريع",tr:"Hızlı Kayıt",ru:"Быстрый ввод",fr:"Saisie rapide",de:"Schnellerfassung"};

I.copilot={fa:"دستیار Contractor Pro",en:"Contractor Pro Copilot",ar:"مساعد Contractor Pro",tr:"Contractor Pro Asistanı",ru:"Помощник Contractor Pro",fr:"Assistant Contractor Pro",de:"Contractor Pro Assistent"};

I.clientPortal={fa:"پرتال مشتری",en:"Client Portal",ar:"بوابة العميل",tr:"Müşteri Portalı",ru:"Портал клиента",fr:"Portail client",de:"Kundenportal"};

I.country={fa:"کشور",en:"Country",ar:"الدولة",tr:"Ülke",ru:"Страна",fr:"Pays",de:"Land"};

I.region={fa:"استان/منطقه",en:"Region",ar:"المنطقة",tr:"Bölge",ru:"Region",fr:"Région",de:"Region"};

I.unitSystem={fa:"سیستم اندازه‌گیری",en:"Measurement system",ar:"نظام القياس",tr:"Ölçü sistemi",ru:"Система измерений",fr:"Système de mesure",de:"Maßsystem"};

I.metric={fa:"متریک",en:"Metric",ar:"متري",tr:"Metrik",ru:"Метрическая",fr:"Métrique",de:"Metrisch"};

I.imperial={fa:"امپریال",en:"Imperial",ar:"إمبراطوري",tr:"İngiliz",ru:"Имперская",fr:"Impérial",de:"Imperial"};

I.currencyMode={fa:"حالت ارز",en:"Currency mode",ar:"وضع العملة",tr:"Para birimi modu",ru:"Режим валюты",fr:"Mode de devise",de:"Währungsmodus"};

I.autoMode={fa:"خودکار بر اساس کشور",en:"Automatic by country",ar:"تلقائي حسب الدولة",tr:"Ülkeye göre otomatik",ru:"Авто по стране",fr:"Automatique selon le pays",de:"Automatisch nach Land"};

I.manualMode={fa:"دستی",en:"Manual",ar:"يدوي",tr:"Manuel",ru:"Вручную",fr:"Manuel",de:"Manuell"};

I.connectedConstruction={fa:"ساخت‌وساز متصل",en:"Connected Construction",ar:"البناء المتصل",tr:"Bağlantılı İnşaat",ru:"Связанное строительство",fr:"Construction connectée",de:"Vernetztes Bauen"};

I.projectCenter={fa:"مرکز فرمان پروژه",en:"Project Command Center",ar:"مركز قيادة المشروع",tr:"Proje Komuta Merkezi",ru:"Центр проекта",fr:"Centre de commande du projet",de:"Projektzentrale"};

I.noClientRecords={fa:"مشتری انتخاب کنید",en:"Select a client",ar:"اختر عميلاً",tr:"Bir müşteri seçin",ru:"Выберите клиента",fr:"Sélectionnez un client",de:"Kunden auswählen"};

I.portalPreview={fa:"پیش‌نمایش پرتال مشتری",en:"Client portal preview",ar:"معاينة بوابة العميل",tr:"Müşteri portalı önizleme",ru:"Предпросмотр портала",fr:"Aperçu du portail client",de:"Kundenportal-Vorschau"};

I.portalLiveNote={fa:"برای پرتال آنلاین چندکاربره، سرور و احراز هویت لازم است؛ این نسخه پیش‌نمایش امن و قابل اشتراک‌گذاری را فراهم می‌کند.",en:"A live multi-user portal requires a server and authentication; this version provides a safe shareable preview.",ar:"البوابة الحية متعددة المستخدمين تحتاج خادماً ومصادقة؛ يوفر هذا الإصدار معاينة آمنة قابلة للمشاركة.",tr:"Canlı çok kullanıcılı portal için sunucu ve kimlik doğrulama gerekir; bu sürüm güvenli paylaşılabilir önizleme sunar.",ru:"Для живого многопользовательского портала нужны сервер и аутентификация; эта версия даёт безопасный общий просмотр.",fr:"Un portail multi-utilisateur en ligne nécessite un serveur et une authentification ; cette version fournit un aperçu partageable sécurisé.",de:"Ein Live-Portal mit mehreren Benutzern benötigt Server und Authentifizierung; diese Version bietet eine sichere teilbare Vorschau."};

I.ask={fa:"سؤال",en:"Ask",ar:"اسأل",tr:"Sor",ru:"Спросить",fr:"Demander",de:"Fragen"};

I.copilotHint={fa:"درباره پروژه، هزینه، موجودی یا سود سؤال کنید.",en:"Ask about projects, costs, inventory or profit.",ar:"اسأل عن المشاريع والتكاليف والمخزون والربح.",tr:"Projeler, maliyetler, stok veya kâr hakkında sorun.",ru:"Спрашивайте о проектах, расходах, запасах или прибыли.",fr:"Posez des questions sur les projets, coûts, stocks ou bénéfices.",de:"Fragen Sie nach Projekten, Kosten, Bestand oder Gewinn."};

I.countryHint={fa:"با تغییر کشور، ارز و منطقه زمانی به‌صورت خودکار پیشنهاد می‌شوند؛ می‌توانید ارز را دستی تغییر دهید.",en:"Country suggests currency and time zone automatically; you can override currency manually.",ar:"اختيار الدولة يحدد العملة والمنطقة الزمنية تلقائياً؛ ويمكنك تغيير العملة يدوياً.",tr:"Ülke para birimini ve saat dilimini otomatik önerir; para birimini elle değiştirebilirsiniz.",ru:"Страна автоматически предлагает валюту и часовой пояс; валюту можно изменить вручную.",fr:"Le pays propose automatiquement la devise et le fuseau ; la devise reste modifiable.",de:"Das Land schlägt Währung und Zeitzone automatisch vor; die Währung kann manuell geändert werden."};

I.m_invoices={fa:"صورتحساب‌ها",en:"Invoices",ar:"الفواتير",tr:"Faturalar",ru:"Счета",fr:"Factures",de:"Rechnungen"};

I.d_invoices={fa:"صورتحساب و وضعیت پرداخت",en:"Invoices and payment status",ar:"الفواتير وحالة الدفع",tr:"Faturalar ve ödeme durumu",ru:"Счета и статус оплаты",fr:"Factures et statut de paiement",de:"Rechnungen und Zahlungsstatus"};

I.m_accounts={fa:"حساب‌های مالی",en:"Accounts",ar:"الحسابات",tr:"Hesaplar",ru:"Счета",fr:"Comptes",de:"Konten"};

I.d_accounts={fa:"صندوق، بانک و کارت",en:"Cash, bank and card accounts",ar:"النقد والبنك والبطاقة",tr:"Kasa, banka ve kart hesapları",ru:"Касса, банк и карты",fr:"Caisse, banque et cartes",de:"Kasse, Bank und Karten"};

I.m_suppliers={fa:"تأمین‌کنندگان",en:"Suppliers",ar:"الموردون",tr:"Tedarikçiler",ru:"Поставщики",fr:"Fournisseurs",de:"Lieferanten"};

I.d_suppliers={fa:"دفتر تأمین‌کنندگان",en:"Supplier directory",ar:"دليل الموردين",tr:"Tedarikçi rehberi",ru:"Справочник поставщиков",fr:"Annuaire fournisseurs",de:"Lieferantenverzeichnis"};

I.m_notifications={fa:"یادآوری‌ها",en:"Reminders",ar:"التذكيرات",tr:"Hatırlatıcılar",ru:"Напоминания",fr:"Rappels",de:"Erinnerungen"};

I.d_notifications={fa:"سررسید، بدهی، موجودی و کارها",en:"Deadlines, payments, stock and tasks",ar:"المواعيد والمدفوعات والمخزون والمهام",tr:"Son tarihler, ödemeler, stok ve görevler",ru:"Сроки, платежи, склад и задачи",fr:"Échéances, paiements, stock et tâches",de:"Fristen, Zahlungen, Bestand und Aufgaben"};

I.attachmentName={fa:"نام فایل پیوست",en:"Attachment name",ar:"اسم المرفق",tr:"Ek dosya adı",ru:"Имя вложения",fr:"Nom de la pièce jointe",de:"Anhangsname"};

I.invoice={fa:"صورتحساب",en:"Invoice",ar:"فاتورة",tr:"Fatura",ru:"Счёт",fr:"Facture",de:"Rechnung"};

I.overdue={fa:"معوق",en:"Overdue",ar:"متأخر",tr:"Gecikmiş",ru:"Просрочен",fr:"En retard",de:"Überfällig"};

I.partial={fa:"بخشی پرداخت شده",en:"Partial",ar:"Частично",tr:"Kısmi",ru:"Частiel",fr:"Partiel",de:"Teilweise"};

I.paid={fa:"پرداخت شده",en:"Paid",ar:"مدفوع",tr:"Ödendi",ru:"Payé",de:"Bezahlt",fr:"Bezahlt"};

I.draft={fa:"پیش‌نویس",en:"Draft",ar:"مسوده",tr:"Taslak",ru:"Черновик",fr:"Brouillon",de:"Entwurf"};

I.sent={fa:"ارسال شده",en:"Sent",ar:"أرسلت",tr:"Gönderildi",ru:"Отправлен",fr:"Envoyée",de:"Gesendet"};

I.transfer={fa:"انتقال",en:"Transfer",ar:"تحويل",tr:"Transfer",ru:"Перевод",fr:"Virement",de:"Übertragung"};

I.refund={fa:"برگشت وجه",en:"Refund",ar:"استرداد",tr:"İade",ru:"Возврат",fr:"Remboursement",de:"Erstattung"};

I.debt={fa:"بدهی",en:"Debt",ar:"دين",tr:"Borç",ru:"Долг",fr:"Dette",de:"Schuld"};

I.advance={fa:"پیش‌پرداخت",en:"Advance",ar:"دفعة مقدمة",tr:"Avans",ru:"Аванс",fr:"Avance",de:"Vorschuss"};

I.cash={fa:"صندوق",en:"Cash",ar:"نقد",tr:"Kasa",ru:"Касса",fr:"Caisse",de:"Kasse"};

I.bank={fa:"بانک",en:"Bank",ar:"البنك",tr:"Banka",ru:"Банк",fr:"Banque",de:"Bank"};

I.card={fa:"کارت",en:"Card",ar:"بطاقة",tr:"Kart",ru:"Карта",fr:"Carte",de:"Karte"};

I.pettyCash={fa:"تنخواه",en:"Petty Cash",ar:"صندوق نثريات",tr:"Küçük Kasa",ru:"Малая касса",fr:"Petite caisse",de:"Kleinkasse"};

I.maintenance={fa:"تعمیرات",en:"Maintenance",ar:"صيانة",tr:"Bakım",ru:"Обслуживание",fr:"Maintenance",de:"Wartung"};

I.lost={fa:"مفقود",en:"Lost",ar:"مفقود",tr:"Kayıp",ru:"Утерян",fr:"Perdu",de:"Verloren"};

I.damaged={fa:"آسیب‌دیده",en:"Damaged",ar:"متضرر",tr:"Hasarlı",ru:"Повреждён",fr:"Endommagé",de:"Beschädigt"};

I.ask=I.ask||{fa:"سؤال",en:"Ask",ar:"اسأل",tr:"Sor",ru:"Спросить",fr:"Demander",de:"Fragen"};

I.net=I.net||{fa:"خالص",en:"Net",ar:"الصافي",tr:"Net",ru:"Итог",fr:"Net",de:"Netto"};

I.tool=I.tool||{fa:"ابزار",en:"Tools",ar:"الأدوات",tr:"Araçlar",ru:"Инструменты",fr:"Outils",de:"Werkzeuge"};
