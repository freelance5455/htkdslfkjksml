// Contractor Pro service worker: cache-first app shell, network-only for the API.
const V = 'cp-v21-3';
const SHELL = ["./", "./index.html", "css/base.css", "css/commercial.css", "css/stage.css", "img/splash.jpg", "img/hero.jpg", "img/ya-logo.png", "img/icon-192.png", "img/icon-512.png", "img/icon-512-maskable.png", "js/i18n/dict-smart-drop.js", "js/i18n/dict-runtime.js", "js/i18n/dict-runtime-extra.js", "js/i18n/ui-labels.js", "js/core/state.js", "js/core/format.js", "js/core/router.js", "js/views/dashboard.js", "js/views/lists.js", "js/views/projects.js", "js/views/clients.js", "js/views/forms.js", "js/views/reports.js", "js/views/settings.js", "js/features/tax-currency.js", "js/features/inventory.js", "js/features/schedule.js", "js/features/smart-estimate.js", "js/features/files.js", "js/features/legal.js", "js/features/account-center.js", "js/features/cloud-sync.js", "js/features/team-portal.js", "js/features/notifications.js", "js/features/security-pin.js", "js/features/smart-assistant.js", "js/features/license.js", "js/config.js", "js/i18n/labels-modules.js", "js/form-schema.js", "js/i18n/labels-ui.js", "js/i18n/labels-extended.js", "js/app-state.js", "js/features/files-ui.js", "js/features/signatures-ui.js", "js/pwa-icon.js", "js/features/legal-ui.js", "js/overrides.js", "js/splash.js", "js/server-services.js", "js/quick-estimate.js", "js/i18n/runtime.js"];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url); if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/')) return;
  e.respondWith(fetch(e.request).then(r => { if (r.ok) { const c = r.clone(); caches.open(V).then(x => x.put(e.request, c)); } return r; }).catch(() => caches.match(e.request).then(m => m || caches.match('./index.html'))));
});

// Web Push: the server sends {title, body, url, tag}; show it and focus/open the app when tapped.
self.addEventListener('push', e => {
  let m = {}; try { m = e.data ? e.data.json() : {}; } catch (_) { m = { title: 'Contractor Pro', body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(String(m.title || 'Contractor Pro').slice(0, 80), { body: String(m.body || '').slice(0, 240), tag: m.tag || 'cp', data: { url: m.url || './' } }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close(); const url = (e.notification.data && e.notification.data.url) || './';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(cs => { const c = cs.find(x => 'focus' in x); return c ? c.focus() : self.clients.openWindow(url); }));
});
