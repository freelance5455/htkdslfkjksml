import re,subprocess,sys
h=open(sys.argv[1],encoding="utf-8").read();bad=0
for i,m in enumerate(re.finditer(r"<script[^>]*>(.*?)</script>",h,re.S)):
    open("/tmp/_s.js","w",encoding="utf-8").write(m.group(1));r=subprocess.run(["node","--check","/tmp/_s.js"],capture_output=True,text=True)
    if r.returncode: print("SYNTAX ERROR script",i,r.stderr[:300]);bad=1
print("syntax ok" if not bad else "syntax FAILED");sys.exit(bad)
