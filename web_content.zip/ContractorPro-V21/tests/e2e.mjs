import http from 'node:http'; import { createHmac } from 'node:crypto'; import { chromium } from 'playwright';
const SRV = process.argv[3];
const { createApp } = await import(SRV + '/src/app.js'); const { MemoryStore } = await import(SRV + '/src/store-memory.js'); const { BtcPayProvider } = await import(SRV + '/src/billing.js');
const inv = new Map();
const f = async (url, o = {}) => { const u = new URL(url); if (o.method === 'POST') { const b = JSON.parse(o.body), id = 'INV' + (inv.size + 1); inv.set(id, { id, status: 'New', amount: b.amount, currency: b.currency, metadata: b.metadata }); return { ok: true, json: async () => ({ id, checkoutLink: 'https://pay.example/i/' + id }) }; } return { ok: true, json: async () => inv.get(u.pathname.split('/').pop()) }; };
const bp = new BtcPayProvider({ baseUrl: 'https://pay.example', storeId: 'S', apiKey: 'k', webhookSecret: 'wh', fetchImpl: f });
const ai = { name: 'fake', async complete(r) { return r.task === 'estimate_from_text' ? '{"items":[{"name":"Facade stone","quantity":280,"unit":"m2"}],"assumptions":["flat wall"],"missing":["height"]}' : 'REPORT TEXT'; } };
const app = createApp({ store: new MemoryStore(), aiProvider: ai, billing: { providers: { btcpay: bp } }, config: { jwtSecret: 'x'.repeat(40) } });
const srv = http.createServer(app); await new Promise(r => srv.listen(0, r)); const base = 'http://127.0.0.1:' + srv.address().port;
const reg = await (await fetch(base + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'e@x.com', password: 'correct-horse-battery' }) })).json();
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined }); const ctx = await b.newContext(); const p = await ctx.newPage();
await ctx.route('https://pay.example/**', r => r.fulfill({ body: 'ok' })); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.dismiss());
await p.addInitScript(()=>{try{localStorage.setItem('cp_legal_accept',JSON.stringify({version:'2026-10-12'}))}catch(e){}}); await p.goto('file://' + process.argv[2]); await p.waitForTimeout(300);
let fails = 0; const ok = (n, c, x) => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + JSON.stringify(x))); if (!c) fails++; };
await p.evaluate(([base, tok]) => { sessionStorage.setItem('cp175_access_token', tok); d.services = d.services || {}; d.services.endpoint = base; persist(); }, [base, reg.accessToken]);
// billing modal
await p.evaluate(() => cp175OpenBilling()); await p.waitForSelector('#cp19Plans button[data-plan]');
ok('plans listed from server', await p.locator('#cp19Plans button[data-plan]').count() === 4);
ok('current plan shown as free', /./.test(await p.textContent('#cp19Cur')));
const [popup] = await Promise.all([ctx.waitForEvent('page'), p.locator('#cp19Plans button[data-plan="pro_monthly"]').click()]);
ok('checkout opens provider page', popup.url().startsWith('https://pay.example/i/INV1') || (await popup.url()).includes('pay.example'), popup.url());
// provider settles + webhook
inv.get('INV1').status = 'Settled'; const raw = JSON.stringify({ type: 'InvoiceSettled', invoiceId: 'INV1', metadata: inv.get('INV1').metadata });
const wh = await fetch(base + '/api/billing/webhook/btcpay', { method: 'POST', headers: { 'btcpay-sig': 'sha256=' + createHmac('sha256', 'wh').update(raw).digest('hex') }, body: raw }); ok('webhook accepted', wh.status === 200);
await p.click('#cp19Refresh'); await p.waitForTimeout(400);
const cur = await p.textContent('#cp19Cur'); ok('plan now Pro with expiry', /Pro|حرفه/.test(cur) && cur.includes('·'), cur);
// AI tools
await p.evaluate(() => { onLanguageChange('en'); cp19OpenAiTools(); });
await p.selectOption('#cp19Task', 'estimate_from_text'); await p.fill('#cp19Text', '280 m facade stone'); await p.click('#cp19Run'); await p.waitForTimeout(500);
const out = await p.textContent('#cp19Out'); ok('AI BOQ rendered', out.includes('Facade stone') && out.includes('height'), out);
const n0 = await p.evaluate(() => d.estimates.length); await p.click('#cp19SaveBtn');
ok('BOQ saved as estimate with tax default', await p.evaluate((n0) => d.estimates.length === n0 + 1 && d.estimates.at(-1).quantity === 280 && d.estimates.at(-1).taxPercent === d.taxRate, n0));
await p.evaluate(() => cp19OpenAiTools()); await p.selectOption('#cp19Task', 'daily_report'); await p.click('#cp19Run'); await p.waitForTimeout(500);
ok('text task works', (await p.textContent('#cp19Out')).includes('REPORT TEXT'));
// not signed in
await p.evaluate(() => { sessionStorage.removeItem('cp175_access_token'); cp19OpenAiTools(); }); await p.click('#cp19Run'); await p.waitForTimeout(200);
ok('signed-out shows hint', /server|سرور/i.test(await p.textContent('#cp19Out')));
console.log('page errors:', errs); console.log('FAILS', fails); await b.close(); srv.close(); process.exit(fails ? 1 : 0);
