/* ===== V20 schedule core: critical path (CPM) + earned value (EVM). Pure functions, no DOM. ===== */
var DAYMS=86400000;
function cpDay(s){var m=/^(\d{4})-(\d{2})-(\d{2})/.exec(String(s||''));return m?Date.UTC(+m[1],+m[2]-1,+m[3])/DAYMS:null}
function cpIso(n){return new Date(n*DAYMS).toISOString().slice(0,10)}
function taskDuration(x){var dur=Number(x.durationDays);if(dur>0)return Math.round(dur);var s=cpDay(x.startDate),e=cpDay(x.dueDate);if(s!=null&&e!=null&&e>=s)return e-s+1;return 1}
// tasks: [{id,startDate,dueDate,durationDays,predecessor,predecessor2,lagDays}] of ONE project.
// Finish-to-start with optional lag (days, may be negative). A fixed startDate acts as "start no earlier than".
function computeCPM(tasks){
 if(!tasks||!tasks.length)return {ok:false,cycle:[],tasks:{},finish:null,critical:[],empty:true};
 var by={},order=[];tasks.forEach(function(x){by[x.id]=x;order.push(x.id)});
 var preds={},succ={};order.forEach(function(id){preds[id]=[];succ[id]=[]});
 order.forEach(function(id){var x=by[id],lag=Math.round(Number(x.lagDays)||0);[x.predecessor,x.predecessor2].forEach(function(p){if(p&&by[p]&&p!==id&&preds[id].every(function(q){return q.id!==p})){preds[id].push({id:p,lag:lag});succ[p].push({id:id,lag:lag})}})});
 // topological order (Kahn); leftovers = cycle
 var indeg={},q=[],topo=[];order.forEach(function(id){indeg[id]=preds[id].length;if(!indeg[id])q.push(id)});
 while(q.length){var u=q.shift();topo.push(u);succ[u].forEach(function(s){if(--indeg[s.id]===0)q.push(s.id)})}
 var cycle=order.filter(function(id){return topo.indexOf(id)<0});
 if(cycle.length)return {ok:false,cycle:cycle,tasks:{},finish:null,critical:[]};
 var anchor=null;order.forEach(function(id){var s=cpDay(by[id].startDate);if(s!=null&&(anchor==null||s<anchor))anchor=s});
 if(anchor==null){order.forEach(function(id){var e=cpDay(by[id].dueDate);if(e!=null&&(anchor==null||e<anchor))anchor=e-taskDuration(by[id])+1})}
 if(anchor==null)anchor=Math.floor(Date.now()/DAYMS);
 var r={};
 topo.forEach(function(id){var x=by[id],dur=taskDuration(x),es=0,fixed=cpDay(x.startDate);if(fixed!=null)es=fixed-anchor;
  preds[id].forEach(function(p){var c=r[p.id].ef+1+p.lag;if(c>es)es=c});   // ef is the last working day (inclusive)
  r[id]={dur:dur,es:es,ef:es+dur-1}});
 var finish=Math.max.apply(null,topo.map(function(id){return r[id].ef}));
 topo.slice().reverse().forEach(function(id){var lf=finish;succ[id].forEach(function(s){var c=r[s.id].ls-1-s.lag;if(c<lf)lf=c});r[id].lf=lf;r[id].ls=lf-r[id].dur+1;r[id].float=r[id].ls-r[id].es;r[id].critical=r[id].float<=0});
 var out={};order.forEach(function(id){var v=r[id];out[id]={es:v.es,ef:v.ef,ls:v.ls,lf:v.lf,float:v.float,critical:v.critical,start:cpIso(anchor+v.es),end:cpIso(anchor+v.ef),dur:v.dur}});
 return {ok:true,cycle:[],tasks:out,anchor:cpIso(anchor),finish:cpIso(anchor+finish),duration:finish+1,critical:order.filter(function(id){return r[id].critical})};
}
// Earned value for one project at `asOf` (ISO date). BAC = project budget; weights = plannedCost or duration.
// Planned % uses the saved baseline dates when present, otherwise the current plan dates.
function computeEVM(project,tasks,actualCost,asOf){
 var bac=Number(project.budget)||0,asOfD=cpDay(asOf)==null?Math.floor(Date.now()/DAYMS):cpDay(asOf);
 var cp=computeCPM(tasks),sw=0,sp=0,se=0;
 tasks.forEach(function(x){
  var w=Number(x.plannedCost)>0?Number(x.plannedCost):taskDuration(x);sw+=w;
  var bs=cpDay(x.baselineStart),be=cpDay(x.baselineEnd);
  if(bs==null||be==null){var c=cp.ok&&cp.tasks[x.id];if(c){bs=cpDay(c.start);be=cpDay(c.end)}else{bs=cpDay(x.startDate);be=cpDay(x.dueDate)}}
  var planned=0;if(bs!=null&&be!=null){planned=asOfD>=be?1:asOfD<bs?0:(asOfD-bs+1)/(be-bs+1)}
  var pc=x.status==='done'?100:Math.max(0,Math.min(100,Number(x.percentComplete)||0));
  sp+=w*planned;se+=w*pc/100});
 if(!sw)return {ok:false,reason:'no-tasks',bac:bac};
 var pv=bac*sp/sw,ev=bac*se/sw,ac=Number(actualCost)||0;
 var cpi=ac>0?ev/ac:null,spi=pv>0?ev/pv:null,eac=cpi?bac/cpi:null;
 return {ok:true,bac:bac,pv:pv,ev:ev,ac:ac,cv:ev-ac,sv:ev-pv,cpi:cpi,spi:spi,eac:eac,etc:eac==null?null:eac-ac,vac:eac==null?null:bac-eac,percentComplete:se/sw*100,percentPlanned:sp/sw*100,finish:cp.ok?cp.finish:null};
}
