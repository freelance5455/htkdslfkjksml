import { chromium } from 'playwright';
const file = process.argv[2];
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const ctx = await b.newContext(); const p = await ctx.newPage();
const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => { errs.push('DIALOG:' + d.message()); d.dismiss(); });
await p.addInitScript(()=>{try{localStorage.setItem('cp_legal_accept',JSON.stringify({version:'2026-10-12'}))}catch(e){}}); await p.goto('file://' + file); await p.waitForTimeout(400);
let fails = 0; const ok = (n, c, extra) => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + JSON.stringify(extra))); if (!c) fails++; };

// 1. country defaults -> tax rate
await p.evaluate(() => onCountryChange('IN')); ok('India GST default 18', await p.evaluate(() => d.taxRate) === 18);
await p.evaluate(() => onCountryChange('AE')); ok('UAE VAT default 5', await p.evaluate(() => d.taxRate) === 5);
await p.evaluate(() => { d.taxRate = 7; persist(); onLanguageChange('en'); }); ok('language change keeps custom tax rate', await p.evaluate(() => d.taxRate) === 7);

// 2. invoice via real form
await p.evaluate(() => { onCountryChange('GB'); openForm('invoices'); });
await p.fill('#mf [name=name]', 'INV-1'); await p.fill('#mf [name=amount]', '1000');
await p.fill('#mf [name=retentionPercent]', '10'); await p.fill('#mf [name=withholdingPercent]', '5');
await p.click('#mf button[type=submit]');
let inv = await p.evaluate(() => d.invoices[0]);
ok('invoice tax 20% default (GB)', inv && inv.taxPercent === 20 && inv.taxAmount === 200, inv);
ok('invoice total/ret/wh/net', inv.invoiceTotal === 1200 && inv.retentionAmount === 100 && inv.withholdingAmount === 50 && inv.netPayable === 1050, inv);
// explicit 0% tax is respected
await p.evaluate(() => openForm('invoices')); await p.fill('#mf [name=name]', 'INV-0'); await p.fill('#mf [name=amount]', '500'); await p.fill('#mf [name=taxPercent]', '0');
await p.click('#mf button[type=submit]'); inv = await p.evaluate(() => d.invoices[1]);
ok('explicit 0% tax kept', inv.taxPercent === 0 && inv.invoiceTotal === 500, inv);
// out of range rejected
await p.evaluate(() => openForm('invoices')); await p.fill('#mf [name=name]', 'BAD'); await p.fill('#mf [name=amount]', '5'); await p.fill('#mf [name=taxPercent]', '150');
await p.click('#mf button[type=submit]');
ok('tax >100 rejected', await p.evaluate(() => d.invoices.length) === 2);
await p.evaluate(() => closeForm());

// 3. multi-currency
await p.evaluate(() => { d.currencyMode = 'manual'; d.currency = 'USD'; d.fxRates = { EUR: 1.1 }; d.fxBase = 'USD'; d.finance = [
  { id: 'a', name: 'x', type: 'income', amount: 100 },
  { id: 'b', name: 'y', type: 'income', amount: 100, currency: 'EUR' },
  { id: 'c', name: 'z', type: 'income', amount: 100, currency: 'AED' } ]; persist(); apply(); });
const inc = await p.evaluate(() => document.getElementById('dashIncome').textContent);
ok('dashboard converts EUR, skips AED, shows warning', /210/.test(inc) && await p.evaluate(() => !!document.getElementById('fxWarn') && document.getElementById('fxWarn').textContent.includes('AED')), inc);
// changing base currency invalidates old rates
await p.evaluate(() => { d.currency = 'EUR'; apply(); });
ok('stale rates ignored after base change', await p.evaluate(() => fxRate('USD')) === null);
await p.evaluate(() => { d.currency = 'USD'; apply(); });

// 4. settings save
await p.evaluate(() => openModule('settings'));
await p.fill('#taxRate', '12.5'); await p.fill('#fx_AED', '0.27'); await p.evaluate(() => saveTaxSettings());
ok('settings save', await p.evaluate(() => d.taxRate === 12.5 && d.fxRates.AED === 0.27 && d.fxBase === 'USD'));

// 5. persistence + new language/RTL
await p.evaluate(() => { onLanguageChange('ur'); });
ok('urdu is RTL', await p.evaluate(() => document.documentElement.dir) === 'rtl');
await p.evaluate(() => { onLanguageChange('es'); }); ok('spanish is LTR', await p.evaluate(() => document.documentElement.dir) === 'ltr');
await p.reload(); await p.waitForTimeout(400);
ok('state persists after reload', await p.evaluate(() => d.lang === 'es' && d.taxRate === 12.5 && d.invoices.length === 2 && d.fxRates.AED === 0.27));

// 6. legacy data migration (V18.2 state without new fields)
await p.evaluate(() => { const o = JSON.parse(localStorage.getItem(KEY)); delete o.taxRate; delete o.taxRateFor; delete o.fxRates; delete o.fxBase; o.country = 'DE'; o.countryMode = 'manual'; localStorage.setItem(KEY, JSON.stringify(o)); });
await p.reload(); await p.waitForTimeout(400);
ok('legacy state gets country tax rate', await p.evaluate(() => d.taxRate === 19));

// 7. PIN
const pin = await p.evaluate(async () => { const s = cp17Salt(); const a = await cp17HashPin('1234', s), b2 = await cp17HashPin('1234', s), c = await cp17HashPin('1235', s), leg = await cp17HashPin('1234'); return { same: a === b2, diff: a !== c, legacyDiffers: a !== leg, len: a.length }; });
ok('PIN PBKDF2 deterministic/salted', pin.same && pin.diff && pin.legacyDiffers && pin.len === 64, pin);
console.log('page errors:', errs.filter(e => !e.startsWith('DIALOG')));
console.log('FAILS', fails); await b.close(); process.exit(fails ? 1 : 0);
