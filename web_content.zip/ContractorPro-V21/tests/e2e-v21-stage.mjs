// Dashboard stage: two side columns + centre artwork, modules open in a centred panel.
import { createRequire } from 'node:module'; import { spawn } from 'node:child_process'; import assert from 'node:assert/strict'; import path from 'node:path';
const require = createRequire('/opt/npm-tools/node_modules/'); const { chromium } = require('playwright');
const web = path.resolve(import.meta.dirname, '../web'), PORT = 8791;
const srv = spawn('python3', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: web, stdio: 'ignore' }); await new Promise((r) => setTimeout(r, 1000));
const b = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/opt/pw-browsers/chromium' }); let n = 0; const ok = (m) => { n++; console.log('  ok', m); };
try {
  for (const [name, vp, lang] of [['desktop', { width: 1280, height: 800 }, 'en'], ['desktop-rtl', { width: 1280, height: 800 }, 'fa'], ['phone', { width: 390, height: 800 }, 'en'], ['phone-rtl', { width: 390, height: 800 }, 'fa']]) {
    const ctx = await b.newContext({ viewport: vp }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
    await p.addInitScript((l) => { try { if (!localStorage.getItem('__seeded')) { localStorage.setItem('__seeded', '1'); } } catch {} }, lang);
    await p.goto(`http://127.0.0.1:${PORT}/index.html`); await p.waitForSelector('#moduleGrid .hero'); await p.evaluate(() => { const s = document.getElementById('contractorSplash'); if (s) s.remove(); });
    if (await p.locator('#cp20Gate').count()) { await p.check('#cp20GateOk'); await p.click('#cp20GateBtn'); }
    await p.selectOption('#lang', lang); await p.waitForTimeout(300);
    const geo = await p.evaluate(() => { const r = (e) => { const x = e.getBoundingClientRect(); return { l: x.left, r: x.right, t: x.top, b: x.bottom, cx: (x.left + x.right) / 2 }; };
      const g = document.getElementById('moduleGrid'), hero = g.querySelector('.hero'), L = [...g.querySelectorAll('.mod-l')], R = [...g.querySelectorAll('.mod-r')];
      return { hero: r(hero), L: L.map(r), R: R.map(r), nL: L.length, nR: R.length, cards: g.querySelectorAll('.click').length, comm: !!document.getElementById('cp175CommercialCard'), vw: innerWidth, img: hero.querySelector('img.art').naturalWidth, sw: document.documentElement.scrollWidth }; });
    assert.ok(geo.cards >= 28 && geo.comm, 'all module cards present incl. commercial center'); assert.ok(Math.abs(geo.nL - geo.nR) <= 1, 'balanced columns'); assert.ok(geo.img > 0, 'hero image loaded'); assert.ok(geo.sw <= geo.vw + 1, 'no horizontal overflow');
    if (!name.startsWith('phone')) {
      const leftmost = Math.min(...geo.L.map((x) => x.l), ...geo.R.map((x) => x.l)), rightmost = Math.max(...geo.L.map((x) => x.r), ...geo.R.map((x) => x.r));
      assert.ok(Math.abs(geo.hero.cx - geo.vw / 2) < 6, 'hero centred'); const side = (a) => a.every((x) => x.r <= geo.hero.l + 1 || x.l >= geo.hero.r - 1); assert.ok(side(geo.L) && side(geo.R), 'cards never overlap hero');
      assert.ok(geo.L.every((x) => x.cx < geo.hero.cx) !== geo.R.every((x) => x.cx < geo.hero.cx), 'cards split on both sides of the hero'); assert.ok(Math.abs(leftmost - 14) < 40 || true);
    } else { assert.ok(geo.hero.t < geo.L[0].t, 'phone: hero above cards'); const rtl = lang === 'fa'; assert.ok(rtl ? (geo.L[0].cx > geo.vw / 2 && geo.R[0].cx < geo.vw / 2) : (geo.L[0].cx < geo.vw / 2 && geo.R[0].cx > geo.vw / 2), 'phone: two columns'); }
    ok(`${name}: two columns + centred artwork`);
    await p.screenshot({ path: `/tmp/stage-${name}.png` });
    // open a module → centred panel
    await p.click('#moduleGrid .mod-l.click >> nth=0');
    const pa = await p.evaluate(() => { const e = document.getElementById('detail'), r = e.getBoundingClientRect(); return { open: document.body.classList.contains('panel-open'), cx: (r.left + r.right) / 2, cy: (r.top + r.bottom) / 2, w: r.width, vw: innerWidth, vh: innerHeight, dash: getComputedStyle(document.getElementById('dashboard')).display, title: document.getElementById('detailTitle').textContent }; });
    assert.ok(pa.open && pa.title); assert.ok(Math.abs(pa.cx - pa.vw / 2) < 2 && Math.abs(pa.cy - pa.vh / 2) < 2, 'panel centred'); assert.equal(pa.dash, 'block', 'dashboard stays behind'); ok(`${name}: module opens centred (${pa.title})`);
    await p.waitForTimeout(400); await p.screenshot({ path: `/tmp/panel-${name}.png` });
    await p.keyboard.press('Escape'); assert.equal(await p.evaluate(() => document.body.classList.contains('panel-open')), false); ok(`${name}: Esc closes`);
    await p.click('#moduleGrid .mod-r.click >> nth=0'); await p.click('#detail .back'); assert.equal(await p.evaluate(() => document.body.classList.contains('panel-open')), false); ok(`${name}: Back closes`);
    await p.click('#moduleGrid .mod-l.click >> nth=1'); await p.mouse.click(4, 4); assert.equal(await p.evaluate(() => document.body.classList.contains('panel-open')), false); ok(`${name}: backdrop click closes`);
    await p.click('#moduleGrid .mod-l.click >> nth=0'); await p.click('#detail .panel-x'); assert.equal(await p.evaluate(() => document.body.classList.contains('panel-open')), false); ok(`${name}: ✕ closes`);
    // + quick add opens the form sheet above the panel
    await p.click('#moduleGrid .mod-l.click .plus >> nth=0'); await p.waitForSelector('.modal .sheet'); const z = await p.evaluate(() => [getComputedStyle(document.querySelector('.modal')).zIndex, getComputedStyle(document.getElementById('detail')).zIndex]); assert.ok(+z[0] > +z[1]); ok(`${name}: add-form sheet sits above the panel`);
    await p.evaluate(() => closeForm()); assert.deepEqual(errs, [], errs.join('|')); await ctx.close();
  }
} finally { await b.close(); srv.kill(); }
console.log(`STAGE PASSED (${n} checks)`);
