# امنیت نسخهٔ دسکتاپ (Electron) — راهنمای کوتاه
این بسته فایل Electron ندارد؛ این نکات برای `main.js` شماست (فایل را ندیده‌ام، پس درباره‌اش حکم قطعی نمی‌دهم).
```javascript
const { URL } = require('url');
// 1) پنجرهٔ جدید: فقط HTTPS در مرورگر بیرونی
win.webContents.setWindowOpenHandler(({ url }) => {
  try { const u = new URL(url); if (u.protocol === 'https:') shell.openExternal(u.href); } catch {}
  return { action: 'deny' };
});
// 2) جلوگیری از رفتن خود پنجره به آدرس خارجی (فقط فایل/صفحهٔ خود برنامه)
win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file://')) e.preventDefault(); });
// 3) هیچ مجوز مرورگری (دوربین، میکروفون، موقعیت...) مگر بخواهید
win.webContents.session.setPermissionRequestHandler((wc, permission, cb) => cb(false));
```
همچنین: `contextIsolation: true`، `nodeIntegration: false`، `sandbox: true` (که دارید)، یک CSP در `index.html` (فقط منبع‌های لازم و آدرس سرور خودتان)، به‌روز نگه‌داشتن نسخهٔ Electron، و امضای کد برنامه. برای بررسی کامل، `package.json` و `preload.js` را بفرستید.
