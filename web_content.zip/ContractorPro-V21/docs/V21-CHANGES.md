# V21 — what changed, and what is verified

## Added
| Feature | Where | Verified how |
|---|---|---|
| Server-side data export + account/workspace erasure (GDPR Art. 15/17/20) | `server/src/gdpr.ts`, `POST /api/account/delete`, `GET /api/account/export`, Settings > Account & data | automated tests (memory store) + browser E2E |
| Real e-mail (SMTP: TLS/STARTTLS/AUTH, retries) incl. OTP codes | `server/src/smtp.ts` | tests against a fake SMTP server incl. real TLS |
| Web Push (VAPID, RFC 8291 encryption) + alert digest (e-mail + push) | `webpush.ts`, `notifier.ts`, `sw.js` | RFC 8291 test vector reproduced byte-for-byte; delivery logic tested with fakes |
| Live accounting: QuickBooks Online + Xero (OAuth2, invoices + expenses, idempotent) | `accounting.ts`, `/api/integrations/*` | tests against a local mock of both APIs |
| HSE / safety forms and Tenders modules (+ RBAC, in-app and server alerts) | `form-schema.js`, `rbac.js` | browser E2E + unit tests |
| TypeScript (strict) for all new server code | `server/src/*.ts`, `tsconfig.json` | `npm run typecheck` |

## Tests
- Server: `cd server && npm test` (79 tests, +1 PostgreSQL contract that runs when TEST_DATABASE_URL is set) and `npm run typecheck`.
- Browser: `e2e/run.sh` (14 checks; needs python3 + playwright + chromium).

## Verify PostgreSQL yourself (2 minutes)
```
createdb cp_test
cd server && npm install
DATABASE_URL=postgres://localhost/cp_test npm run test:pg
```
This applies all migrations and runs `test/store-contract.test.ts` against the real `PgStore` (export reads, push subscriptions, alert de-duplication, accounting tokens, member and workspace erasure through the append-only audit trigger, other workspaces untouched). The same test already passes on the in-memory store. Code and SQL were also cross-checked by reading against schema 001-006 (table/column names, ON DELETE CASCADE chains, trigger name), but nothing replaces running it.

## NOT verified — needs your accounts/devices
1. SQL migrations 007-009 and the new `PgStore` methods were never executed (no PostgreSQL was available when written). Run the command above; if it is green, this item is closed.
2. QuickBooks/Xero: only a local mock was used. Create a sandbox company on each, register your app, run a real sync, and check the totals in their UI. Payments received are NOT synced (only invoices and expenses); multi-currency is not mapped.
3. SMTP with your real provider; Web Push on real phones (Chrome/Android, Safari/iOS needs the app installed to the home screen).
4. Android APK/AAB: `.github/workflows/android.yml` and `capacitor.config.json` are provided but never executed. Change `appId`. Then test on a real device before Google Play.
5. Legal texts still contain placeholders (`CP_LEGAL_CFG` in `web/js/features/legal-ui.js`) and need a lawyer. Payment records may have to be kept for tax law even after an erasure request; the current erase deletes them with the workspace — decide with your lawyer.
6. The legacy JavaScript (server `app.js`, stores, whole web UI) was not converted to TypeScript.
