# V21 — what changed, and what is verified

## Added
| Feature | Where | Verified how |
|---|---|---|
| Server-side data export + account/workspace erasure (GDPR Art. 15/17/20) | `server/src/gdpr.ts`, `POST /api/account/delete`, `GET /api/account/export`, Settings > Account & data | automated tests (memory store) + browser E2E |
| Real e-mail (SMTP: TLS/STARTTLS/AUTH, retries) incl. OTP codes | `server/src/smtp.ts` | tests against a fake SMTP server incl. real TLS |
| Web Push (VAPID, RFC 8291 encryption) + alert digest (e-mail + push) | `webpush.ts`, `notifier.ts`, `sw.js` | RFC 8291 test vector reproduced byte-for-byte; delivery logic tested with fakes |
| Live accounting: QuickBooks Online + Xero (OAuth2, invoices + expenses, idempotent) | `accounting.ts`, `/api/integrations/*` | tests against a local mock of both APIs |
| HSE / safety forms and Tenders modules (+ RBAC, in-app and server alerts) | `form-schema.js`, `rbac.js` | browser E2E + unit tests |
| TypeScript (strict) for all new server code | `server/src/*.ts`, `tsconfig.json` | `npm run typecheck` |

## Branding (YA signature logo)
- The gold "YA" signature (taken from the business card) is now on the splash screen (bottom centre), in the app header, as favicon and as PWA/app icon (`web/img/ya-logo.png`, `icon-192.png`, `icon-512.png`, `icon-512-maskable.png`).
- `resources/` holds icon.png (1024), icon-foreground.png and icon-background.png for `npx @capacitor/assets generate` (see docs/ANDROID-APK-fa.md).
- Service worker cache renamed `cp-v21-2` and now precaches the new images.
- The logo files are raster images cut from a photo of the card: fine for screens and app icons, NOT for large print. Ask a designer for a vector (SVG) version before printing banners.

## Fixed in this pass
- Dashboard headings "Connected construction" / "Needs attention" and the four attention labels showed raw code (`${esc(t(...))}`) because they were written as template text in static HTML; they now use `data-i18n` and translate in all languages.
- `application-name` meta said V14.
- Tests: two e2e files had a hard-coded browser path and one still expected version 20.0.0; they now use `CHROMIUM_PATH` and 21.0.0.

## Known, not changed
- `tests/functional.mjs` "state persists after reload" fails about half of the time when run from `file://` in headless Chromium (storage is empty at page start). The app itself keeps data across reloads; run that test through a local http server to make it stable.
- On tall phone screens the splash artwork is cropped by `object-fit: cover` (the word CONTRACTOR is cut at the edges). The artwork also carries a small "Made with AI" badge in its top-right corner, which `cover` hides on phones. Decide with the designer before changing either.

## Tests
- Server: `cd server && npm test` (79 tests, +1 PostgreSQL contract that runs when TEST_DATABASE_URL is set) and `npm run typecheck`.
- Browser: `e2e/run.sh` (14 checks; needs python3 + playwright + chromium).

## Verify PostgreSQL yourself (2 minutes)
```
createdb cp_test
cd server && npm install
DATABASE_URL=postgres://localhost/cp_test npm run test:pg
```
This applies all migrations and runs `test/store-contract.test.ts` against the real `PgStore` (export reads, push subscriptions, alert de-duplication, accounting tokens, member and workspace erasure through the append-only audit trigger, other workspaces untouched). The same test already passes on the in-memory store. Code and SQL were also cross-checked by reading against schema 001-006 (table/column names, ON DELETE CASCADE chains, trigger name), but nothing replaces running it.

## NOT verified — needs your accounts/devices
1. SQL migrations 007-009 and the new `PgStore` methods were never executed (no PostgreSQL was available when written). Run the command above; if it is green, this item is closed.
2. QuickBooks/Xero: only a local mock was used. Create a sandbox company on each, register your app, run a real sync, and check the totals in their UI. Payments received are NOT synced (only invoices and expenses); multi-currency is not mapped.
3. SMTP with your real provider; Web Push on real phones (Chrome/Android, Safari/iOS needs the app installed to the home screen).
4. Android APK/AAB: `.github/workflows/android.yml` and `capacitor.config.json` are provided but never executed. Change `appId`. Then test on a real device before Google Play.
5. Legal texts still contain placeholders (`CP_LEGAL_CFG` in `web/js/features/legal-ui.js`) and need a lawyer. Payment records may have to be kept for tax law even after an erasure request; the current erase deletes them with the workspace — decide with your lawyer.
6. The legacy JavaScript (server `app.js`, stores, whole web UI) was not converted to TypeScript.

## V21.1 — dashboard stage (layout change)
- Module cards are split into **two side columns** (alternating, so they stay balanced) with the gold *Contractor Pro* artwork in the **centre** (`web/img/hero.jpg`, a cropped copy of the splash image without the "Made with AI" badge strip; the splash itself is unchanged). On phones the artwork goes on top and the cards stay in two columns.
- Opening a module (or a client/project inside it) now shows it in a **centred panel** over the dashboard; the dashboard stays visible and dimmed behind it. Close with ✕, Back, Esc or a click on the dimmed area. The "+" form sheet opens above the panel.
- Files: `web/css/stage.css` (new), `web/js/views/dashboard.js` (`layoutStage`), `web/js/core/router.js` (`openPanel/closePanel`), `web/index.html`, service-worker cache `cp-v21-3`.
- Test: `node tests/e2e-v21-stage.mjs` (28 checks: geometry on desktop/phone, LTR/RTL, centring, all close paths, form sheet z-order). Existing suites re-run: e2e.py 14/14, functional, e2e-v20-* all pass.
