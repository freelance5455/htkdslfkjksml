#!/usr/bin/env bash
# Browser end-to-end test: real server (in-memory store) + the real web app in headless Chromium.
# Needs: node >=22.18, python3 with playwright + chromium (pip install playwright && playwright install chromium)
set -e; cd "$(dirname "$0")"
node api-server.mjs & API=$!; (cd ../web && python3 -m http.server 8788 --bind 127.0.0.1 >/dev/null 2>&1) & WEB=$!
trap 'kill $API $WEB 2>/dev/null' EXIT; sleep 1.5
python3 e2e.py "$@"
