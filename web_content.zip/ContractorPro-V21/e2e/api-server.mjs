import http from 'node:http';
import { createApp } from '../server/src/app.js';
import { MemoryStore } from '../server/src/store-memory.js';
const store = new MemoryStore();
http.createServer(createApp({ store, pushPublicKey: 'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4', config: { jwtSecret: 'x'.repeat(40) } })).listen(8787, '127.0.0.1', () => console.log('api up'));
