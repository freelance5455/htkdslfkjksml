import json, sys, urllib.request
from playwright.sync_api import sync_playwright
API, WEB = 'http://127.0.0.1:8787', 'http://127.0.0.1:8788/index.html'
def post(path, body):
    r = urllib.request.Request(API + path, json.dumps(body).encode(), {'Content-Type': 'application/json'}); return json.load(urllib.request.urlopen(r))
ok = fail = 0
def check(name, cond, extra=''):
    global ok, fail
    if cond: ok += 1; print('ok  ', name)
    else: fail += 1; print('FAIL', name, extra)
u = post('/api/auth/register', {'email': 'e2e@example.com', 'password': 'correct-horse-battery', 'orgName': 'E2E'})
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(accept_downloads=True); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept('DELETE MY ACCOUNT' if d.type == 'prompt' and 'DELETE' in d.message else ('correct-horse-battery' if d.type == 'prompt' else None)))
    pg.goto(WEB); pg.wait_for_timeout(1500)
    check('legal gate is shown on first launch', pg.locator('#cp20Gate').count() == 1)
    pg.check('#cp20GateOk'); pg.click('#cp20GateBtn'); pg.wait_for_timeout(300)
    check('legal gate closes after acceptance', pg.locator('#cp20Gate').count() == 0)
    # --- new modules exist and the generated forms contain the right fields
    for mod, fields in {'safetyForms': ['formType', 'severity', 'actionDueDate', 'correctiveAction'], 'tenders': ['submissionDeadline', 'bidAmount', 'estimatedCost', 'bondRequired']}.items():
        pg.evaluate(f"openModule('{mod}'); openForm('{mod}')"); pg.wait_for_timeout(200)
        ids = pg.evaluate("[...document.querySelectorAll('#modal [id],#modal [name]')].map(e=>e.id+'|'+e.name).join(' ')")
        check(f'{mod}: form renders with expected fields', all(f in ids for f in fields), ids[:200])
        pg.evaluate('closeForm()')
    # --- create a tender through the real UI form, then confirm it is stored
    pg.evaluate("openModule('tenders'); openForm('tenders')"); pg.wait_for_timeout(200)
    sel = lambda f: f"#modal [id*='{f}'], #modal [name='{f}']"
    pg.fill(sel('name') + ' >> nth=0', 'Hospital extension'); pg.fill(sel('bidAmount') + ' >> nth=0', '1200000'); pg.fill(sel('estimatedCost') + ' >> nth=0', '1000000')
    pg.evaluate("document.querySelector('#modal form').requestSubmit()"); pg.wait_for_timeout(400)
    t = pg.evaluate("(d.tenders||[]).map(x=>[x.name,x.bidAmount,x.estimatedCost,x.status])")
    check('tender saved through the UI', t and t[0][0] == 'Hospital extension' and float(t[0][1]) == 1200000, t)
    # --- in-app smart alerts for the new modules
    pg.evaluate("""()=>{const tm=new Date(Date.now()+86400000).toISOString().slice(0,10);d.tenders.push({id:'t9',name:'Bridge bid',status:'Preparing',submissionDeadline:tm+'T10:00'});d.safetyForms.push({id:'s9',name:'Crane near-miss',formType:'Incident / near miss',severity:'Critical',status:'Open',date:tm});cp15RefreshSmartAlerts()}""")
    al = pg.evaluate("d.notifications.map(n=>n.name)")
    check('alerts: tender due soon', any(a.startswith('Tender due soon: Bridge bid') for a in al), al)
    check('alerts: critical incident open', any(a.startswith('Critical incident open: Crane') for a in al), al)
    # --- connect the app to the server session and open the new account card
    pg.evaluate("""(a)=>{d.lang='en';d.services=d.services||{};d.services.endpoint=a.api;sessionStorage.setItem('cp175_access_token',a.at);sessionStorage.setItem('cp175_refresh_token',a.rt);persist();openModule('settings')}""", {'api': API, 'at': u['accessToken'], 'rt': u['refreshToken']})
    pg.wait_for_timeout(600)
    check('settings shows the account & data card', 'Download my data' in pg.inner_text('body'))
    check('accounting section reports not enabled', 'Not enabled' in pg.inner_text('#cp21Acc') or 'Not enabled' in pg.inner_text('body'))
    with pg.expect_download() as dl: pg.click('text=Download my data')
    exp = json.load(open(dl.value.path())); check('export downloads valid JSON for the signed-in account', exp.get('format') == 'contractor-pro-account-export/1' and exp['account']['email'] == 'e2e@example.com', list(exp)[:5])
    check('export contains no secrets', 'passwordHash' not in json.dumps(exp) and 'scrypt$' not in json.dumps(exp))
    # --- erase: wrong flow cancelled first, then real erase of the workspace
    pg.on('dialog', lambda d: None)
    pg.evaluate("window.confirm=()=>true; window.prompt=(m)=>/Type DELETE/.test(m)?'DELETE MY ACCOUNT':(/password/i.test(m)?'correct-horse-battery':'')")
    pg.click('text=Delete account permanently'); pg.wait_for_timeout(800)
    check('erase reports success in the UI', 'Erased' in pg.inner_text('#cp21Msg') or 'Erased' in pg.inner_text('body'), pg.evaluate("document.querySelector('#cp21Msg')?.textContent"))
    try: post('/api/auth/login', {'email': 'e2e@example.com', 'password': 'correct-horse-battery'}); gone = False
    except urllib.error.HTTPError as e: gone = e.code == 401
    check('after erase the account can no longer sign in', gone)
    check('no JavaScript errors during the whole session', not errs, errs[:3])
    b.close()
print(f'\n{ok} passed, {fail} failed'); sys.exit(1 if fail else 0)
