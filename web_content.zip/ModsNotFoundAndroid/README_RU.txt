ModsNotFound — заготовка Android-приложения

Как собрать APK:
1. Распакуй ZIP.
2. Открой Android Studio.
3. Выбери Open и укажи папку ModsNotFound.
4. Дождись завершения Gradle Sync.
5. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK обычно появится в app/build/outputs/apk/debug/app-debug.apk.

Приложение показывает локальный файл app/src/main/assets/index.html.
Интернет-разрешение не требуется.
Для сборки нужна Android Studio с JDK 17 и Android SDK 35.
