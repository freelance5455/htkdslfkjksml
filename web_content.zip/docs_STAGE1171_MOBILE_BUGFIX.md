# CryptoPulse Stage 1171 — Mobile startup / charts / full-price hydration

## Fixed
- Cold Android startup is explicitly forced to `index.html` / Home once; Settings/Profile cannot become the initial route from restored WebView state.
- Home keeps the complete LBank market universe visible and continuously rotates missing/stale price requests, so lower rows do not depend on scrolling into view.
- Trade chart now retries after the canvas becomes visible and after SPA layout settles; resize and first-entry zero-size races are handled.
- Futures chart now retries after layout/visibility settles and redraws idempotently on resize.

## Data integrity
- No fabricated market prices were added.
- LBank/native cache remains the primary market source.
- Futures candles remain explicitly sampled from the documented Contract `lastPrice` feed; they are not mislabeled as exchange-native OHLC.
- CPLS token work remains paused.
