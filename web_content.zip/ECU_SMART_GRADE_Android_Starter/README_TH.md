# ECU SMART GRADE — Android Starter 0.3.0

## สิ่งที่มีในชุดนี้
- โปรเจกต์ Android Native (Kotlin) เปิดหน้าจอเดิม `V0.2` ใน WebView โดยไม่แก้ไขไฟล์ต้นฉบับ
- ตรวจพบอุปกรณ์ USB Host ผ่าน Android USB Manager และขอสิทธิ์ USB
- ใช้ไลบรารี usb-serial-for-android เพื่อ probe และเปิดพอร์ต Serial ที่รู้จักโดยไดรเวอร์มาตรฐาน
- แสดงสถานะ USB จริงแยกจากสถานะการสื่อสาร ECU

## ข้อจำกัดสำคัญ
**นี่คือ Android starter source ไม่ใช่ APK ที่ build แล้ว และยังไม่ใช่เครื่องมืออ่าน ECU ที่พร้อมใช้งานจริง**
- ยังไม่ทราบ chipset / VID / PID ของอะแดปเตอร์ Guzzilla ตัวจริง จึงยังยืนยันไดรเวอร์ไม่ได้
- เปิดพอร์ต Serial เท่านั้น ยังไม่ได้ตั้ง baud rate, ทำ K-Line initialization, ส่งคำสั่ง ECU หรืออ่านข้อมูล
- DTC, Clear DTC, Live Data และ Auto Scan ถูกล็อกไว้โดยเจตนา ไม่ส่งคำสั่งเดาและไม่แสดงค่าจำลอง
- ต้องตรวจวงจร K-Line/ระดับแรงดันของอะแดปเตอร์ก่อนต่อกับ ECU

## Build APK
1. เปิดโฟลเดอร์นี้ด้วย Android Studio รุ่นที่รองรับ Android Gradle Plugin 8.7.3
2. ติดตั้ง Android SDK Platform 35 และ Android SDK Build-Tools ตามที่ Android Studio แจ้ง
3. Sync Gradle ให้ดาวน์โหลด dependencies
4. เลือก `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. ไฟล์ debug APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## ทดสอบอย่างปลอดภัย
- ทดสอบตรวจพบ USB กับโทรศัพท์และ OTG ก่อน โดยยังไม่ต่อเข้ากล่อง ECU
- บันทึก VID/PID และชื่อ chipset ที่พิมพ์บนแผง/ตัวแปลง
- ห้ามทดลองส่ง byte หรือคำสั่งสุ่มไปยัง ECU
- หลังยืนยันรุ่น ECU, ปี, connector, chipset และโปรโตคอลแล้ว จึงค่อยเพิ่มไดรเวอร์/ขั้นตอนสื่อสารเฉพาะรุ่น

## โครงสร้าง
- `app/src/main/assets/index.html` — หน้าจอ ECU SMART GRADE V0.2 ที่กู้คืนมา
- `app/src/main/java/com/smartgrade/ecu/MainActivity.kt` — Android USB Host + serial bridge
