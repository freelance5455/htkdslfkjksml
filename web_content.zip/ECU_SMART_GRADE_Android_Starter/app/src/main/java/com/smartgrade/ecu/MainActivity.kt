package com.smartgrade.ecu

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var usbManager: UsbManager
    private var serialPort: UsbSerialPort? = null
    private var pendingDevice: UsbDevice? = null
    private val actionUsbPermission = "com.smartgrade.ecu.USB_PERMISSION"

    private fun emit(type: String, message: String = "") {
        val safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        runOnUiThread {
            web.evaluateJavascript("window.onEcuBridgeEvent && window.onEcuBridgeEvent({type:'$type',message:'$safe'});", null)
        }
    }

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != actionUsbPermission) return
            val device = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            else
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE) as? UsbDevice
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            if (granted && device != null) openSerial(device)
            else emit("error", "ไม่ได้รับอนุญาตให้เข้าถึง USB")
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val filter = IntentFilter(actionUsbPermission)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(permissionReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(permissionReceiver, filter)

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(UsbBridge(), "AndroidUsbBridge")
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class UsbBridge {
        @JavascriptInterface fun requestUsbPermission() {
            runOnUiThread {
                val devices = usbManager.deviceList.values
                if (devices.isEmpty()) { emit("error", "ไม่พบอุปกรณ์ USB กรุณาตรวจสาย OTG และอะแดปเตอร์"); return@runOnUiThread }
                // If more than one device is attached, use the first enumerated device for this starter build.
                val device = devices.first()
                pendingDevice = device
                if (usbManager.hasPermission(device)) openSerial(device)
                else {
                    val pi = PendingIntent.getBroadcast(
                        this@MainActivity, 0, Intent(actionUsbPermission).setPackage(packageName),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                    )
                    usbManager.requestPermission(device, pi)
                }
            }
        }

        @JavascriptInterface fun connectFtdi() {
            runOnUiThread {
                val device = pendingDevice ?: usbManager.deviceList.values.firstOrNull()
                if (device == null) emit("error", "ไม่พบอุปกรณ์ USB")
                else if (usbManager.hasPermission(device)) openSerial(device)
                else emit("error", "ยังไม่ได้รับสิทธิ์ USB กรุณากด CONNECT อีกครั้ง")
            }
        }

        @JavascriptInterface fun disconnect() {
            try { serialPort?.close() } catch (_: Exception) {}
            serialPort = null
            emit("usb_disconnected", "ปิดพอร์ต USB Serial แล้ว")
        }

        // ECU commands deliberately remain disabled until the adapter chipset,
        // electrical K-Line interface, ECU family and protocol are verified.
        @JavascriptInterface fun readFaultCodes() = emit("error", "ยังไม่ส่งคำสั่งอ่าน DTC: ต้องยืนยัน ECU และโปรโตคอลก่อน")
        @JavascriptInterface fun clearFaultCodes() = emit("error", "ยังไม่ส่งคำสั่งลบรหัส: ต้องยืนยัน ECU และคำสั่งเฉพาะรุ่นก่อน")
        @JavascriptInterface fun startLiveData() = emit("error", "ยังไม่มีโปรโตคอล Live Data ที่ยืนยันแล้ว จึงไม่แสดงค่าจำลอง")
        @JavascriptInterface fun identifyEcu() = emit("error", "ยังไม่เปิด Auto ECU Scan จนกว่าจะมีฐานข้อมูลคำสั่งที่ตรวจสอบแล้ว")
    }

    private fun openSerial(device: UsbDevice) {
        try {
            val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
            if (driver == null) {
                emit("error", "ไม่รู้จัก USB chipset นี้ในไดรเวอร์มาตรฐาน กรุณายืนยันรุ่นชิปของ Guzzilla")
                return
            }
            val connection = usbManager.openDevice(device)
            if (connection == null) { emit("error", "เปิด USB device ไม่สำเร็จ"); return }
            val port = driver.ports.firstOrNull()
            if (port == null) { connection.close(); emit("error", "ไม่พบ Serial port"); return }
            port.open(connection)
            // Intentionally do not set baud rate or transmit bytes here.
            // K-Line initialization/baud/protocol must be matched to the verified ECU profile.
            serialPort?.close()
            serialPort = port
            emit("usb_connected", "เปิด USB Serial สำเร็จ (${device.vendorId.toString(16)}:${device.productId.toString(16)}) · ยังไม่เชื่อมต่อ ECU")
            emit("log", "USB Serial เปิดแล้ว · ยังไม่ได้เริ่มสื่อสาร K-Line หรือส่งคำสั่ง ECU")
        } catch (e: Exception) {
            emit("error", "เปิดพอร์ต USB ไม่สำเร็จ: ${e.message ?: "unknown error"}")
        }
    }

    override fun onDestroy() {
        try { serialPort?.close() } catch (_: Exception) {}
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) {}
        web.destroy()
        super.onDestroy()
    }
}
