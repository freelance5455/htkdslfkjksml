"""End-to-end browser test of the real app (optional).  pip install playwright && playwright install chromium
Run:  python3 tests/e2e.py        (add SHOTS=/some/dir to save screenshots)"""
import os, sys, threading, http.server, functools, json
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WWW = os.path.join(ROOT, "www")
EXPECTED = open(os.path.join(ROOT, "tests/fixtures/sample-prompt.txt"), encoding="utf-8").read()
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
H = functools.partial(Quiet, directory=WWW)
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
BASE = f"http://127.0.0.1:{srv.server_address[1]}/index.html"
threading.Thread(target=srv.serve_forever, daemon=True).start()
SHOTS = os.environ.get("SHOTS")
results = []

def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))

def new_page(b, locale="en-US", **kw):
    ctx = b.new_context(viewport={"width": 390, "height": 844}, locale=locale, is_mobile=True, has_touch=True,
                        permissions=["clipboard-read", "clipboard-write"], **kw)
    pg = ctx.new_page(); pg.errors = []
    pg.on("pageerror", lambda e: pg.errors.append(str(e)))
    pg.on("console", lambda m: m.type == "error" and pg.errors.append(m.text))
    return ctx, pg

def open_app(pg):
    pg.goto(BASE); pg.wait_for_selector(".hero"); pg.wait_for_timeout(300)

with sync_playwright() as p:
    b = p.chromium.launch()

    # ---------- language detection on first run ----------
    for loc, lang, direction in [("fa-IR", "fa", "rtl"), ("ar-SA", "ar", "rtl"), ("tr-TR", "tr", "ltr"), ("fr-FR", "fr", "ltr"),
                                 ("de-DE", "de", "ltr"), ("es-ES", "es", "ltr"), ("ru-RU", "ru", "ltr"), ("zh-CN", "zh", "ltr"),
                                 ("hi-IN", "hi", "ltr"), ("en-GB", "en", "ltr"), ("ja-JP", "en", "ltr")]:
        ctx, pg = new_page(b, loc); open_app(pg)
        got = pg.evaluate("[document.documentElement.lang, document.documentElement.dir]")
        check(f"first-run language {loc} -> {lang}/{direction}", got == [lang, direction], got)
        check(f"no JS errors on load ({loc})", not pg.errors, pg.errors)
        ctx.close()

    # ---------- main flow in English ----------
    ctx, pg = new_page(b, "en-US")
    external = []
    pg.on("request", lambda r: external.append(r.url) if not r.url.startswith("http://127.0.0.1") and not r.url.startswith("data:") else None)
    open_app(pg)
    check("home shows hero, categories strip, sample card", pg.locator(".hero").count() == 1 and pg.locator(".cat-strip .chip").count() >= 28 and pg.locator(".card").count() >= 1)
    check("sample image really loaded (naturalWidth>0)", pg.evaluate("new Promise(r=>{const i=document.querySelector('.card img');const f=()=>r(i.naturalWidth);i.complete?f():i.onload=f})") > 0)

    # categories page + filter
    pg.click("#nav a[href='#/categories']"); pg.wait_for_selector(".cat-card")
    check("28 category cards", pg.locator(".cat-card").count() == 28, pg.locator(".cat-card").count())
    pg.fill(".searchbar input", "logo"); pg.wait_for_timeout(200)
    check("category search filters", pg.locator(".cat-card").count() == 1)
    pg.fill(".searchbar input", ""); pg.wait_for_timeout(100)
    pg.click(".cat-card[href='#/category/personal-photo-editing']"); pg.wait_for_selector(".masonry .card")
    check("opening a category lists its prompts", pg.locator(".masonry .card").count() == 1)
    pg.go_back(); pg.wait_for_selector(".cat-card")
    pg.click(".cat-card[href='#/category/logo-design']"); pg.wait_for_selector(".empty")
    check("empty category shows empty state", pg.locator(".empty").count() == 1)

    # search
    pg.click("#nav a[href='#/search']"); pg.wait_for_selector(".searchbar input")
    pg.fill(".searchbar input", "سینمایی"); pg.wait_for_timeout(300)
    check("search by Persian title", pg.locator(".masonry .card").count() == 1)
    pg.fill(".searchbar input", "SUNSET"); pg.wait_for_timeout(300)
    check("search by tag (case-insensitive)", pg.locator(".masonry .card").count() == 1)
    pg.fill(".searchbar input", "nothing-matches"); pg.wait_for_timeout(300)
    check("no-results state", pg.locator(".empty").count() == 1)
    pg.fill(".searchbar input", ""); pg.wait_for_timeout(300)

    # detail page
    pg.goto(BASE + "#/prompt/cinematic-street-portrait"); pg.wait_for_selector(".prompt-text")
    shown = pg.evaluate("document.querySelector('.prompt-text').textContent")
    check("prompt text displayed exactly", shown == EXPECTED)
    check("title + category visible", "پرتره خیابانی سینمایی" in pg.inner_text(".detail-title") and pg.locator(".cat-link").count() == 1)
    pg.wait_for_timeout(600)
    check("bottom nav hidden on detail, action bar visible", pg.evaluate("getComputedStyle(document.querySelector('#nav')).opacity") == "0" and pg.locator(".actionbar").is_visible())

    # copy: exact clipboard content
    pg.evaluate("navigator.clipboard.writeText('SENTINEL')")
    pg.click(".btn-copy"); pg.wait_for_timeout(300)
    clip = pg.evaluate("navigator.clipboard.readText()")
    check("clipboard == exact prompt (no extras, newlines kept)", clip == EXPECTED, repr(clip[:60]))
    check("copy feedback: button state + toast", pg.locator(".btn-copy.is-done").count() == 1 and pg.locator(".toast").count() == 1)
    if SHOTS: pg.screenshot(path=f"{SHOTS}/copied.png")

    # multi-line prompt must keep its line breaks (inject a record and copy it)
    # favourites persist across reload
    pg.click(".actionbar .sq[aria-pressed]"); pg.wait_for_timeout(200)
    check("favourite toggled on", pg.locator(".actionbar .sq.is-on").count() == 1)
    pg.reload(); pg.wait_for_selector(".prompt-text")
    check("favourite persisted after reload", pg.locator(".actionbar .sq.is-on").count() == 1)
    pg.goto(BASE + "#/favorites"); pg.wait_for_selector(".page-title"); pg.wait_for_timeout(300)
    check("favourites page lists it", pg.locator(".masonry .card").count() == 1)
    check("history lists viewed prompt", pg.locator(".row").count() == 1)

    # full-screen viewer
    pg.goto(BASE + "#/prompt/cinematic-street-portrait"); pg.wait_for_selector(".detail-hero")
    pg.click(".detail-hero .glass-btn:last-child"); pg.wait_for_selector(".viewer")
    check("fullscreen viewer opens", pg.locator(".viewer img").count() == 1)
    pg.go_back(); pg.wait_for_timeout(400)
    check("back closes viewer (stays on the prompt)", pg.locator(".viewer").count() == 0 and pg.locator(".prompt-text").count() == 1)
    pg.click(".detail-hero .glass-btn:last-child"); pg.wait_for_selector(".viewer"); pg.click(".viewer .glass-btn"); pg.wait_for_timeout(400)
    check("close button closes viewer", pg.locator(".viewer").count() == 0)

    # zoom / selection lockdown
    check("viewport blocks page zoom", "user-scalable=no" in pg.evaluate("document.querySelector('meta[name=viewport]').content"))
    us = lambda sel: pg.evaluate(f"getComputedStyle(document.querySelector('{sel}')).userSelect")
    check("UI chrome not selectable, prompt text selectable", us("#nav") == "none" and us(".detail-title") == "none" and us(".prompt-text") == "text")
    check("brand name is PROMPTIX in the title", pg.title() == "PROMPTIX")
    pg.goto(BASE + "#/home"); pg.wait_for_selector(".brand-name")
    check("brand shown on home", pg.inner_text(".brand-name") == "PROMPTIX")
    pg.goto(BASE + "#/prompt/cinematic-street-portrait"); pg.wait_for_selector(".prompt-text")

    # language change persists after reload + RTL/LTR switch
    pg.goto(BASE + "#/settings"); pg.wait_for_selector(".lang-grid")
    pg.click(".lang-grid [lang='ar']"); pg.wait_for_timeout(300)
    check("switch to Arabic -> rtl", pg.evaluate("[document.documentElement.lang,document.documentElement.dir]") == ["ar", "rtl"])
    check("nav labels translated", "الإعدادات" in pg.inner_text("#nav"))
    pg.reload(); pg.wait_for_selector(".lang-grid")
    check("manual language kept after restart", pg.evaluate("document.documentElement.lang") == "ar")
    pg.click(".lang-grid [lang='zh']"); pg.wait_for_timeout(300)
    check("switch to Chinese -> ltr", pg.evaluate("[document.documentElement.lang,document.documentElement.dir]") == ["zh", "ltr"])
    check("no horizontal overflow (zh settings)", pg.evaluate("document.documentElement.scrollWidth<=innerWidth"))
    # prompt text is NOT translated by the UI language
    pg.goto(BASE + "#/prompt/cinematic-street-portrait"); pg.wait_for_selector(".prompt-text")
    check("prompt text unchanged under Chinese UI", pg.evaluate("document.querySelector('.prompt-text').textContent") == EXPECTED)

    # theme
    pg.goto(BASE + "#/settings"); pg.wait_for_selector(".seg")
    pg.click(".seg button:nth-child(3)"); pg.wait_for_timeout(200)
    check("light theme applies", pg.evaluate("document.documentElement.dataset.theme") == "light")

    # clear data (confirm dialog)
    pg.click(".list-btn.danger"); pg.wait_for_selector(".sheet .btn-primary"); pg.click(".sheet .btn-primary"); pg.wait_for_timeout(500)
    pg.goto(BASE + "#/favorites"); pg.wait_for_selector(".page-title")
    check("clear favourites works", pg.locator(".masonry .card").count() == 0 and pg.locator(".empty").count() == 1)

    check("zero external network requests (fully offline)", not external, external)
    check("no JS errors in main flow", not pg.errors, pg.errors)
    ctx.close()

    # ---------- offline: block everything except localhost, app still works ----------
    ctx, pg = new_page(b, "en-US"); ctx.set_offline(False)
    open_app(pg); ctx.route("**/*", lambda r: r.continue_() if r.request.url.startswith("http://127.0.0.1") else r.abort())
    pg.reload(); pg.wait_for_selector(".hero")
    check("works with all non-local traffic blocked", pg.locator(".card").count() >= 1)
    ctx.close()

    # ---------- layout at various phone sizes & RTL/LTR ----------
    for w, h_, loc in [(320, 640, "fa-IR"), (360, 740, "en-US"), (412, 915, "ar-SA"), (768, 1024, "de-DE")]:
        ctx = b.new_context(viewport={"width": w, "height": h_}, locale=loc, is_mobile=w < 600, has_touch=True)
        pg = ctx.new_page(); open_app(pg)
        for route in ["#/home", "#/categories", "#/search", "#/favorites", "#/settings", "#/prompt/cinematic-street-portrait"]:
            pg.evaluate(f"location.hash='{route}'"); pg.wait_for_timeout(500)
            ov = pg.evaluate("document.documentElement.scrollWidth - innerWidth")
            if ov > 1: check(f"no horizontal overflow {w}px {loc} {route}", False, f"+{ov}px")
        check(f"layout ok at {w}x{h_} ({loc})", True)
        if SHOTS: pg.evaluate("location.hash='#/home'"); pg.wait_for_timeout(600); pg.screenshot(path=f"{SHOTS}/home-{w}-{loc}.png")
        ctx.close()
    b.close()

failed = [n for n, ok in results if not ok]
print(f"\n{len(results) - len(failed)}/{len(results)} checks passed")
sys.exit(1 if failed else 0)
