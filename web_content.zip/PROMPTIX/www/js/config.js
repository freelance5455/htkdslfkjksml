// Single place for app-wide constants.
// To rename the app: change APP.name here, "appName" in capacitor.config.json and the
// app_name string (see docs/Persian-Setup-Guide.md, section "تغییر نام و آیکون").
export const APP = {
  name: 'PROMPTIX',
  version: '1.0.0',
  dataUrl: 'data/prompts.json',
  categoriesUrl: 'data/categories.json',
  translationsDir: 'translations/',
  fallbackLang: 'en',
  historyLimit: 30,
  similarLimit: 8,
};

// To add a language: add an entry here + create translations/<code>.json with the same keys as en.json
// + add a "<code>" name to every category in data/categories.json (missing names fall back to English).
export const LANGS = [
  { code: 'fa', native: 'فارسی', english: 'Persian', dir: 'rtl' },
  { code: 'en', native: 'English', english: 'English', dir: 'ltr' },
  { code: 'ar', native: 'العربية', english: 'Arabic', dir: 'rtl' },
  { code: 'tr', native: 'Türkçe', english: 'Turkish', dir: 'ltr' },
  { code: 'fr', native: 'Français', english: 'French', dir: 'ltr' },
  { code: 'de', native: 'Deutsch', english: 'German', dir: 'ltr' },
  { code: 'es', native: 'Español', english: 'Spanish', dir: 'ltr' },
  { code: 'ru', native: 'Русский', english: 'Russian', dir: 'ltr' },
  { code: 'zh', native: '简体中文', english: 'Chinese (Simplified)', dir: 'ltr' },
  { code: 'hi', native: 'हिन्दी', english: 'Hindi', dir: 'ltr' },
];
