import { h, svg, storage } from '../lib/dom.js';
import { t, catName, promptTitle } from '../i18n.js';
import { content } from '../store.js';
import { searchPrompts } from '../lib/search.js';
import { promptCard, emptyState } from '../ui.js';

// Search state survives tab switches (kept in memory + the last query in storage)
const S = { q: '', cat: '', sort: 'newest' };

export function renderSearch() {
  const pending = storage.get('q', null); // set by the home-page search box
  if (pending !== null) { S.q = pending; storage.remove('q'); }
  const page = h('div', { class: 'page' });
  const results = h('div');
  const chips = h('div', { class: 'rail', style: { padding: '0 var(--gutter)', marginTop: '14px' } });
  const input = h('input', { type: 'search', enterkeyhint: 'search', value: S.q, placeholder: t('home.searchPlaceholder'), autocomplete: 'off', 'aria-label': t('nav.search') });
  const clear = h('button', { class: 'clear', type: 'button', 'aria-label': t('search.clear'), onclick: () => { input.value = ''; S.q = ''; update(); input.focus(); } }, svg('close'));
  const sel = h('select', { 'aria-label': t('sort.label'), onchange: (e) => { S.sort = e.target.value; update(); } },
    ['newest', 'popular', 'title', 'oldest'].map((k) => h('option', { value: k, selected: k === S.sort }, t(`sort.${k}`))));

  const drawChips = () => chips.replaceChildren(
    h('button', { class: `chip${S.cat ? '' : ' is-active'}`, type: 'button', onclick: () => { S.cat = ''; update(); } }, t('filter.all')),
    ...content.categories.map((c) => h('button', { class: `chip${S.cat === c.id ? ' is-active' : ''}`, type: 'button',
      onclick: () => { S.cat = S.cat === c.id ? '' : c.id; update(); } }, svg(c.icon), catName(c))));

  function update() {
    clear.hidden = !S.q;
    drawChips();
    const list = searchPrompts(content.prompts, { query: S.q, categoryId: S.cat, sort: S.sort, titleOf: promptTitle });
    if (!list.length) {
      results.replaceChildren(emptyState('search', t('search.none'), t('search.noneHint')));
      return;
    }
    results.replaceChildren(
      h('div', { class: 'result-count' }, t('search.results', { n: list.length })),
      h('div', { class: 'masonry' }, list.map((p) => promptCard(p))));
  }
  let timer;
  input.addEventListener('input', () => { S.q = input.value; clearTimeout(timer); timer = setTimeout(update, 120); });

  page.append(
    h('header', { class: 'topbar' }, h('h1', { class: 'page-title' }, t('nav.search'))),
    h('div', { class: 'pad' }, h('label', { class: 'searchbar solid' }, svg('search'), input, clear)),
    chips,
    h('div', { class: 'filters' }, h('label', { class: 'select' }, sel, svg('chevron'))),
    results);
  update();
  return page;
}
