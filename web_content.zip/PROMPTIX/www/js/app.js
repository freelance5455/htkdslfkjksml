import { h, svg } from './lib/dom.js';
import { t, setLanguage, detectLanguage } from './i18n.js';
import { loadContent, applyTheme } from './store.js';
import { go } from './ui.js';
import { renderHome } from './views/home.js';
import { renderCategories, renderCategory } from './views/categories.js';
import { renderSearch } from './views/search.js';
import { renderFavorites } from './views/favorites.js';
import { renderSettings } from './views/settings.js';
import { renderDetail } from './views/detail.js';

const TABS = [
  { id: 'home', icon: 'home', key: 'nav.home', path: '/home' },
  { id: 'categories', icon: 'grid', key: 'nav.categories', path: '/categories' },
  { id: 'search', icon: 'search', key: 'nav.search', path: '/search' },
  { id: 'favorites', icon: 'heart', key: 'nav.favorites', path: '/favorites' },
  { id: 'settings', icon: 'settings', key: 'nav.settings', path: '/settings' },
];
// route table: pattern → [view, tab that should be highlighted]
const ROUTES = [
  [/^\/home$/, renderHome, 'home'],
  [/^\/categories$/, renderCategories, 'categories'],
  [/^\/category\/([^/]+)$/, renderCategory, 'categories'],
  [/^\/search$/, renderSearch, 'search'],
  [/^\/favorites$/, renderFavorites, 'favorites'],
  [/^\/settings$/, renderSettings, 'settings'],
  [/^\/prompt\/([^/]+)$/, renderDetail, null],
];

const viewEl = document.getElementById('view');
const navEl = document.getElementById('nav');
const scrollPos = new Map();
let current = null;     // current hash path
let lastTab = 'home';
let fresh = false;      // true when a tab was tapped → start at top

function buildNav(activeTab) {
  navEl.replaceChildren(...TABS.map((tab) => {
    const a = h('a', { href: '#' + tab.path, class: tab.id === activeTab ? 'is-active' : '', 'aria-label': t(tab.key), 'aria-current': tab.id === activeTab ? 'page' : false,
      onclick: (e) => { e.preventDefault(); fresh = true; scrollPos.delete(tab.path); if (current === tab.path) { scrollTo({ top: 0, behavior: 'smooth' }); a.classList.add('bump'); setTimeout(() => a.classList.remove('bump'), 400); } else go(tab.path, { replace: true }); },
    }, svg(tab.icon), h('span', { class: 'label' }, t(tab.key)));
    return a;
  }));
}

function parse() {
  const path = decodeURIComponent(location.hash.slice(1) || '/home').split('?')[0] || '/home';
  for (const [re, view, tab] of ROUTES) {
    const m = path.match(re);
    if (m) return { path, view, tab, params: { id: m[1] ? m[1] : undefined } };
  }
  return { path: '/home', view: renderHome, tab: 'home', params: {} };
}

function render() {
  const route = parse();
  // remember scroll of the page we are leaving (not detail pages)
  if (current && !current.startsWith('/prompt/')) scrollPos.set(current, scrollY);
  current = route.path;
  if (route.tab) lastTab = route.tab;
  let out = route.view({ params: route.params, rerender: render });
  if (out instanceof Node) out = { el: out };
  document.body.classList.toggle('on-detail', !!out.detail);
  viewEl.replaceChildren(out.el, ...(out.extra ? [out.extra] : []));
  buildNav(route.tab || lastTab);
  window.scrollTo(0, fresh || out.detail ? 0 : (scrollPos.get(route.path) || 0));
  fresh = false;
}

// block long-press context menus and pinch/double-tap page zoom everywhere except the prompt text and inputs
document.addEventListener('contextmenu', (e) => { if (!e.target.closest?.('.prompt-text, input, textarea')) e.preventDefault(); });
for (const ev of ['gesturestart', 'gesturechange', 'gestureend']) document.addEventListener(ev, (e) => e.preventDefault());
document.addEventListener('touchmove', (e) => { if (e.touches.length > 1 && !e.target.closest?.('.viewer')) e.preventDefault(); }, { passive: false });
document.addEventListener('selectstart', (e) => { if (!e.target.closest?.('.prompt-text, input, textarea') && !(e.target.nodeType === 3 && e.target.parentElement?.closest('.prompt-text'))) e.preventDefault(); });

async function boot() {
  applyTheme();
  window.matchMedia?.('(prefers-color-scheme: light)').addEventListener?.('change', () => applyTheme());
  try {
    await setLanguage(detectLanguage());
    await loadContent();
  } catch (err) {
    console.error(err);
    viewEl.replaceChildren(h('div', { class: 'empty', style: { paddingTop: '30vh' } },
      h('b', {}, (() => { try { return t('common.loadError'); } catch { return 'Could not load content'; } })()),
      h('button', { class: 'btn btn-primary', type: 'button', onclick: () => location.reload() }, t('common.retry'))));
    document.getElementById('boot')?.remove();
    return;
  }
  window.addEventListener('hashchange', render);
  render();
  const boot = document.getElementById('boot');
  if (boot) { boot.classList.add('done'); setTimeout(() => boot.remove(), 500); }
}
boot();
