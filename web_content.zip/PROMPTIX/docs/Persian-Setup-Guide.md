# راهنمای کامل (فارسی)

## ۱. معرفی ساختار پروژه
همهٔ برنامه داخل پوشهٔ `www/` است (یک وب‌اپ آفلاین). Capacitor این پوشه را داخل یک پوستهٔ اندروید می‌گذارد و APK می‌سازد.
- `www/data/` — فهرست دسته‌ها و پرامپت‌ها (JSON)
- `www/translations/` — متن‌های رابط به ۱۰ زبان
- `www/assets/` — تصاویر، آیکون‌ها، فونت‌ها
- `www/js/` و `www/css/` — کد و طراحی (برای افزودن محتوا لازم نیست دست بزنید)

## ۲. فناوری انتخاب‌شده و دلیلش
**وب‌اپ آفلاین (HTML/CSS/JS) + Capacitor.** دلیل: کنترل کامل روی طراحی خلاقانه و انیمیشن، پشتیبانی عالی RTL/LTR و فونت‌های چندزبانه، تعویض محتوا فقط با ویرایش JSON، و ساخت ساده‌تر نسبت به Flutter/Kotlin. افکت‌ها فقط با CSS هستند (گرادیان، محوشدگی ظریف، ترنزیشن) و سبک‌اند.

## ۳. نرم‌افزارهای موردنیاز (برای ساخت APK، روی کامپیوتر)
- Node.js نسخهٔ ۲۰ یا بالاتر (با npm)
- JDK (برای Capacitor 7 نسخهٔ ۲۱) — Android Studio خودش JDK همراه دارد
- Android Studio (آخرین نسخهٔ پایدار) + Android SDK (از داخل Android Studio نصب می‌شود)

نسخه‌های دقیق ممکن است با آپدیت Capacitor تغییر کنند؛ صفحهٔ «Environment Setup» در capacitorjs.com را ببینید.
> برای ساخت APK **اینترنت لازم است** (دانلود npm، Gradle و SDK). خود برنامهٔ ساخته‌شده هیچ اینترنتی نمی‌خواهد.

## ۴. بازکردن پروژه
ZIP را استخراج کنید، ترمینال را در پوشهٔ `PROMPTIX` باز کنید.

## ۵. نصب ابزارها و وابستگی‌ها
```bash
npm install
```

## ۶. اجرای آزمایشی
- پیش‌نمایش سریع در مرورگر: `npm run serve` و رفتن به `http://localhost:8080` (برای دیدن حالت موبایل، در Chrome کلید F12 و سپس آیکون گوشی).
- آزمون‌ها: `npm test`
- روی گوشی: بعد از ساخت پروژهٔ اندروید، در Android Studio دکمهٔ Run (گوشی با USB debugging یا شبیه‌ساز).

## ۷. ساخت APK
جزئیات در [`Build-APK.md`](Build-APK.md). خلاصه:
```bash
npx cap add android
npm run android:setup
npx cap sync android
npm run apk:debug
```

## ۸. محل فایل APK
`android/app/build/outputs/apk/debug/app-debug.apk`

## ۹. افزودن پرامپت جدید
[`Add-New-Prompts.md`](Add-New-Prompts.md) — خلاصه: تصویر را در `www/assets/images/` بگذارید، یک رکورد به `www/data/prompts.json` اضافه کنید، سپس `npx cap sync android` و ساخت دوبارهٔ APK. در پیش‌نمایش مرورگر فقط رفرش کافی است.

## ۱۰. افزودن تصویر جدید
تصویر (JPG/WEBP، ترجیحاً عرض ۱۰۸۰ تا ۱۵۰۰ پیکسل) را در `www/assets/images/` بگذارید. برای ساخت thumbnail سبک: `python3 tools/make-thumbs.py` (نیاز به `pip install pillow`). مسیر را در فیلدهای `image` و `thumb` رکورد بنویسید.

## ۱۱. ایجاد دسته‌بندی جدید
در `www/data/categories.json` یک آبجکت اضافه کنید:
```json
{ "id": "food-photography", "order": 29, "icon": "camera", "colors": ["#ff9a5c", "#e11d48"],
  "names": { "fa": "عکاسی غذا", "en": "Food photography", "ar": "...", "tr": "...", "fr": "...", "de": "...", "es": "...", "ru": "...", "zh": "...", "hi": "..." },
  "status": "published" }
```
`icon` یکی از نام‌های داخل `www/js/icons.js` است (مثل wand, camera, film, leaf, gem, rocket…). اگر نام زبانی را ننویسید، نام انگلیسی نشان داده می‌شود. تصویر کاور اختیاری است: پیش‌فرض، تصویر جدیدترین پرامپت همان دسته است (یا فیلد `"cover": "assets/images/x.jpg"`).

## ۱۲. ویرایش ترجمه‌ها
فایل زبان موردنظر در `www/translations/` را ویرایش کنید؛ **کلیدها را تغییر ندهید** و `{n}`، `{v}`، `{lang}` را نگه دارید. `npm test` بررسی می‌کند که همهٔ زبان‌ها کلیدهای یکسان دارند. متن پرامپت‌ها هرگز ترجمه نمی‌شود و همان‌طور که در `prompts.json` است نمایش و کپی می‌شود. (اختیاری: برای ترجمهٔ **عنوان و توضیح** یک پرامپت، فیلد `"i18n": {"en": {"title": "...", "description": "..."}}` اضافه کنید.)
افزودن زبان جدید: یک ورودی در `LANGS` فایل `www/js/config.js`، یک فایل `translations/<code>.json` (کپی از en.json) و نام در دسته‌ها.

## ۱۳. تغییر نام و آیکون برنامه
- نام: `APP.name` در `www/js/config.js` و `appName` در `capacitor.config.json` (و `<title>` در `www/index.html`). سپس `npm run android:setup` نام را در اندروید هم اعمال می‌کند.
- شناسهٔ بسته (`appId`) را قبل از `npx cap add android` به شناسهٔ دلخواه خود (مثل `com.yourname.app`) تغییر دهید.
- آیکون: `resources/icon.png` و `resources/icon-foreground.png` (۱۰۲۴×۱۰۲۴) را بسازید یا فایل‌های داخل `resources/android/mipmap-*` را جایگزین کنید، سپس `npm run android:setup`.

## ۱۴. خطاهای متداول
| مشکل | راه‌حل |
|---|---|
| `npx cap add android` خطا می‌دهد | `npm install` را اجرا کنید؛ Node ≥ ۲۰ لازم است |
| `JAVA_HOME is not set` / نسخهٔ Java اشتباه | JDK موردنیاز را نصب و `JAVA_HOME` را تنظیم کنید (یا از Android Studio بسازید) |
| `SDK location not found` | در Android Studio پروژه را یک‌بار باز کنید یا فایل `android/local.properties` با `sdk.dir=...` بسازید |
| تغییر JSON در اپ دیده نمی‌شود | `npx cap sync android` را اجرا و دوباره Build کنید |
| پرامپت جدید نمایش داده نمی‌شود | JSON معتبر نیست (ویرگول اضافه/کم)، `status` برابر `published` نیست، یا `categoryId` وجود ندارد؛ `npm test` علت را می‌گوید |
| تصویر نمایش داده نمی‌شود | مسیر نسبت به `www/` است (`assets/images/...`) و نام فایل حساس به بزرگی/کوچکی حروف است |
| ساخت Gradle به دلیل اینترنت متوقف شد | یک‌بار با اینترنت بسازید؛ وابستگی‌ها کش می‌شوند |
| (اختیاری) حذف مجوز اینترنت | `node tools/apply-android-resources.mjs --strip-internet` |
