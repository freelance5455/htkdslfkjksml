# PROMPTIX (نام موقت) — کتابخانهٔ آفلاین پرامپت‌های تصویری

اپ اندروید کاملاً آفلاین: بدون حساب کاربری، بدون تبلیغ، بدون پرداخت، بدون نیاز به اینترنت.
رابط کاربری با **HTML/CSS/JavaScript خالص (ES Modules)** نوشته شده و با **Capacitor** داخل پوستهٔ اندروید بسته‌بندی می‌شود.

## شروع سریع

```bash
npm install                 # دانلود وابستگی‌ها (فقط یک‌بار، نیازمند اینترنت)
npm test                    # آزمون‌های داده/ترجمه/منطق جست‌وجو
npm run serve               # پیش‌نمایش در مرورگر: http://localhost:8080
npx cap add android         # ساخت پروژهٔ اندروید (فقط یک‌بار)
npm run android:setup       # آیکون، اسپلش و نام برنامه
npx cap sync android        # کپی محتوای www به پروژهٔ اندروید
npm run android:open        # بازکردن در Android Studio ← Build ← Build APK
```

راهنمای کامل و مرحله‌به‌مرحله: [`docs/Persian-Setup-Guide.md`](docs/Persian-Setup-Guide.md)

## ساختار پروژه

```
PROMPTIX/
├── README.md · LICENSES.md · licenses/      متن مجوز فونت‌ها
├── package.json · capacitor.config.json     وابستگی‌ها و تنظیمات Capacitor
├── www/                                     ← تمام برنامه (همین پوشه داخل APK می‌رود)
│   ├── index.html
│   ├── css/app.css                          سیستم طراحی (رنگ، تایپوگرافی، کارت‌ها، انیمیشن)
│   ├── js/                                  منطق برنامه (app, store, i18n, ui, views/*, lib/*)
│   ├── data/prompts.json · categories.json  ← محتوا؛ پرامپت جدید فقط اینجا اضافه می‌شود
│   ├── translations/{fa,en,ar,tr,fr,de,es,ru,zh,hi}.json
│   └── assets/{images,icons,fonts}/
├── resources/android/                       آیکون‌های لانچر و تصویر اسپلش
├── docs/                                    راهنماها
├── tests/                                   آزمون‌ها (Node + یک آزمون مرورگری اختیاری)
└── tools/                                   اسکریپت‌های کمکی (thumbnail، فونت، سرور پیش‌نمایش…)
```

> نکته: پوشه‌های `data/`، `translations/` و `assets/` داخل `www/` قرار دارند، چون Capacitor فقط محتوای `www/` را داخل اپ می‌گذارد و این‌طور هیچ داده‌ای دوبار تعریف نمی‌شود.

## امکانات
خانهٔ تصویری (هدر، جست‌وجو، دسته‌ها، جدیدترین/محبوب/منتخب، علاقه‌مندی‌ها، اخیراً دیده‌شده) · ۲۸ دسته‌بندی با کارت‌های رنگی · صفحهٔ جزئیات با دکمهٔ ثابت کپی · نمایش تمام‌صفحه با زوم · جست‌وجو (عنوان/برچسب/دسته) · مرتب‌سازی · پرامپت‌های مشابه · ۱۰ زبان با RTL/LTR · تیره/روشن/سیستم · ذخیرهٔ محلی علاقه‌مندی‌ها، تاریخچه، زبان و تم.
