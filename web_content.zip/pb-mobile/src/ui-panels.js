/* ui-panels.js: zawartość zakładek. Kuźnia ma trwały DOM (aktualizowany w miejscu, by tapnięcia nie ginęły przy odświeżaniu);
   pozostałe zakładki są renderowane z HTML i odświeżane po akcjach lub gdy nie trwa dotyk. */
const panelBody = $('panelBody'), panelEl = $('panel');
let TAB = 'forge', pointerDown = false, spinning = false, wheelRot = 0, forgeBuilt = '', lastSig = '';
document.addEventListener('pointerdown', () => { pointerDown = true; }, true);
document.addEventListener('pointerup', () => { pointerDown = false; }, true);
document.addEventListener('pointercancel', () => { pointerDown = false; }, true);

function setTab(name) {
  TAB = name; lastSig = ''; forgeBuilt = '';
  document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.getAttribute('data-tab') === name));
  panelEl.scrollTop = 0;
  renderPanel(true);
}
document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => setTab(b.getAttribute('data-tab'))));

function renderPanel(force) {
  if (spinning && !force) return;
  if (TAB === 'forge') { renderForge(force); return; }
  forgeBuilt = '';
  const sig = panelSig();
  if (!force && (sig === lastSig || pointerDown)) return;
  lastSig = sig;
  const top = panelEl.scrollTop;
  panelBody.innerHTML = TAB === 'quests' ? questsHtml() : TAB === 'spin' ? spinHtml() : TAB === 'shop' ? shopHtml() : ascendHtml();
  panelEl.scrollTop = top;
  if (TAB === 'spin') drawWheel();
}
function panelSig() {
  if (TAB === 'quests') return JSON.stringify([P.quests, P.ach, P.daily, P.gems]);
  if (TAB === 'spin') return JSON.stringify([P.spin, P.gems]);
  if (TAB === 'shop') return JSON.stringify([P.gems, P.perm, Math.floor(P.piggy / 25), LANG]);
  return JSON.stringify([S.wave, S.phase, P.souls, P.best, S.over, P.tree, skSel, P.gems, LANG]);
}

/* ---------- kuźnia ---------- */
const forgeEls = {};
function renderForge(force) {
  const key = LANG;
  if (forgeBuilt !== key || force) {
    forgeBuilt = key; panelBody.innerHTML = '';
    for (const u of UPS) {
      const card = document.createElement('div'); card.className = 'card';
      card.innerHTML = '<div class="ct"><h3></h3><span class="lv"></span></div><p class="d"></p><div class="val"></div><div class="meter"><i></i></div>' +
        '<button class="btn primary" type="button"><span class="bl"></span><span class="price"><i class="ic coin"></i><b></b></span></button>';
      card.querySelector('h3').textContent = t('up.' + u.id + '.n');
      card.querySelector('.d').textContent = t('up.' + u.id + '.d');
      const e = { lv: card.querySelector('.lv'), val: card.querySelector('.val'), fill: card.querySelector('.meter i'), meter: card.querySelector('.meter'),
        btn: card.querySelector('.btn'), bl: card.querySelector('.bl'), price: card.querySelector('b') };
      if (u.action) e.meter.hidden = true;
      e.btn.addEventListener('click', () => { if (buyUp(u)) { beep(520, 0.08, 'square', 0.04, 880); buzz(15); forgeSig = ''; } });
      forgeEls[u.id] = e; panelBody.appendChild(card);
    }
    forgeSig = '';
  }
  updateForge();
}
let forgeSig = '';
function updateForge() {
  const sig = [S.coins, S.hp, S.maxHp, S.wave, JSON.stringify(S.lv), S.autoOn, LANG].join('|');
  if (sig === forgeSig) return;
  forgeSig = sig;
  for (const u of UPS) {
    const e = forgeEls[u.id]; if (!e) continue;
    if (u.action) {
      const c = repairCost();
      e.lv.textContent = ''; e.val.textContent = t('up.castle', { a: S.hp, b: S.maxHp });
      e.bl.textContent = S.hp >= S.maxHp ? t('up.full') : t('up.repair'); e.price.textContent = fmt(c);
      e.btn.disabled = S.coins < c || S.hp >= S.maxHp; continue;
    }
    const l = S.lv[u.id], maxed = l >= u.max, c = costOf(u, l);
    e.lv.textContent = u.max === 1 ? '' : l + '/' + u.max;
    e.val.textContent = maxed ? u.val(l) + ' (' + t('up.max') + ')' : u.val(l) + '  >  ' + u.val(l + 1);
    e.fill.style.width = (l / u.max * 100) + '%';
    e.bl.textContent = maxed ? t('up.max') : t('up.buy'); e.price.textContent = maxed ? '-' : fmt(c);
    e.btn.disabled = maxed || S.coins < c;
  }
}

/* ---------- misje, logowanie dzienne, osiągnięcia ---------- */
function questsHtml() {
  ensureQuests();
  const ds = dailyState();
  let h = '<div class="card' + (ds.claimed ? '' : ' hl') + '"><div class="ct"><h3>' + esc(t('daily.title')) + '</h3><span>' + esc(t('daily.streak', { n: ds.streak || 0 })) + '</span></div>' + daysHtml(ds);
  h += ds.claimed ? '<p>' + esc(t('daily.back')) + '</p>' : '<button class="btn primary" type="button" data-act="daily">' + esc(t('act.claim')) + '</button>';
  h += '</div><h3 class="sec">' + esc(t('q.title')) + '</h3>';
  P.quests.list.forEach((q, i) => {
    const def = questDef(q.id), ready = q.prog >= q.goal && !q.claimed;
    h += '<div class="card' + (ready ? ' hl' : '') + '"><div class="ct"><h3>' + esc(t('q.' + q.id, { n: fmt(q.goal) })) + '</h3><span class="price"><i class="ic gem"></i>' + def.gems + '</span></div>' +
      '<div class="meter q"><i style="width:' + (q.prog / q.goal * 100) + '%"></i></div><div class="ct"><span>' + fmt(q.prog) + ' / ' + fmt(q.goal) + '</span>' +
      (q.claimed ? '<span>' + esc(t('q.done')) + '</span>' : '<button class="btn primary" type="button" data-act="quest" data-i="' + i + '"' + (ready ? '' : ' disabled') + '>' + esc(t('act.claim')) + '</button>') + '</div></div>';
  });
  const all = questsAllDone();
  h += '<div class="card' + (all && !P.quests.bonus ? ' hl' : '') + '"><div class="ct"><h3>' + esc(t('q.bonus')) + '</h3><span class="price"><i class="ic gem"></i>' + QUEST_BONUS_GEMS + '</span></div>' +
    '<button class="btn primary" type="button" data-act="qbonus"' + (all && !P.quests.bonus ? '' : ' disabled') + '>' + esc(P.quests.bonus ? t('q.done') : t('act.claim')) + '</button></div>';
  h += '<h3 class="sec">' + esc(t('ach.title')) + '</h3>';
  ACHS.forEach((a) => {
    const s = achState(a);
    h += '<div class="card' + (s.ready ? ' hl' : '') + '"><div class="ct"><h3>' + esc(t('ach.' + a.id, { n: fmt(s.goal) })) + '</h3>' +
      (s.maxed ? '<span>' + esc(t('q.done')) + '</span>' : '<span class="price"><i class="ic gem"></i>' + s.gems + '</span>') + '</div>' +
      '<div class="meter q"><i style="width:' + (s.maxed ? 100 : Math.min(100, s.stat / s.goal * 100)) + '%"></i></div><div class="ct"><span>' + fmt(Math.min(s.stat, s.goal)) + ' / ' + fmt(s.goal) + '</span>' +
      (s.maxed ? '' : '<button class="btn primary" type="button" data-act="ach" data-id="' + a.id + '"' + (s.ready ? '' : ' disabled') + '>' + esc(t('act.claim')) + '</button>') + '</div></div>';
  });
  return h;
}

/* ---------- koło fortuny ---------- */
function spinHtml() {
  const st = spinState();
  let btns;
  if (st.free) btns = '<button class="btn primary big" type="button" data-act="spinfree"' + (spinning ? ' disabled' : '') + '>' + esc(t('spin.free')) + '</button>';
  else if (st.extraLeft > 0) btns = '<p>' + esc(t('spin.used')) + '</p><button class="btn ad big" type="button" data-act="spinad"' + (spinning ? ' disabled' : '') + '><i class="play"></i><span>' + esc(t('spin.extra', { n: st.extraLeft })) + '</span></button>';
  else btns = '<p>' + esc(t('spin.none')) + '</p>';
  return '<div class="card"><div id="wheelBox"><div id="wheelWrap"><canvas id="wheel" width="260" height="260"></canvas><i id="pointer"></i></div>' + btns + '</div></div>';
}
function segLabel(s) {
  if (s.c) return [fmt(rewardCoins(s.c)), t('wheel.c')];
  if (s.g) return [String(s.g), t('wheel.g')];
  return [t('boost.' + s.b[0]), Math.round(s.b[1] / 60) + ' ' + t('u.min')];
}
function drawWheel() {
  const c = document.getElementById('wheel'); if (!c) return;
  const x = c.getContext('2d'), n = SPIN_SEGS.length, R0 = 128, cx = 130, cy = 130, arc = Math.PI * 2 / n;
  x.clearRect(0, 0, 260, 260);
  c.style.transform = 'rotate(' + wheelRot + 'deg)';
  for (let i = 0; i < n; i++) {
    const a0 = -Math.PI / 2 + i * arc;
    x.beginPath(); x.moveTo(cx, cy); x.arc(cx, cy, R0, a0, a0 + arc); x.closePath();
    x.fillStyle = SPIN_SEGS[i].col; x.fill(); x.lineWidth = 3; x.strokeStyle = '#14233a'; x.stroke();
    x.save(); x.translate(cx, cy); x.rotate(a0 + arc / 2); x.textAlign = 'right'; x.fillStyle = '#fff'; x.shadowColor = '#000'; x.shadowBlur = 0; x.shadowOffsetX = 1; x.shadowOffsetY = 1;
    const lab = segLabel(SPIN_SEGS[i]);
    x.font = '22px VT323, "Pixelify Sans", monospace'; x.fillText(lab[0], R0 - 12, 2);
    x.font = '16px VT323, "Pixelify Sans", monospace'; x.fillText(lab[1], R0 - 12, 16);
    x.restore();
  }
  x.beginPath(); x.arc(cx, cy, 16, 0, 7); x.fillStyle = '#14233a'; x.fill();
}
function doSpin(free) {
  if (spinning) return;
  const run = () => {
    spinning = true;
    const i = spinRoll(), center = (i + 0.5) * (360 / SPIN_SEGS.length), jit = rnd(-14, 14);
    const base = wheelRot - (wheelRot % 360);
    wheelRot = base + 360 * 5 + ((360 - center + jit) % 360 + 360) % 360;
    const c = document.getElementById('wheel'), dur = matchMedia('(prefers-reduced-motion: reduce)').matches ? 400 : 4200;
    c.style.transition = 'transform ' + dur + 'ms cubic-bezier(.15,.7,.1,1)';
    c.style.transform = 'rotate(' + wheelRot + 'deg)';
    spinMarkUsed(free);
    setTimeout(() => {
      spinning = false;
      const r = spinReward(i);
      beep(600, 0.12, 'triangle', 0.05, 1200); buzz(40);
      toast(t('toast.got', { r: rewardText(r) }));
      renderPanel(true);
    }, dur + 150);
  };
  if (free) run(); else watchAd('spin', run);
}

/* ---------- sklep ---------- */
function iapCard(p, extra) {
  const owned = (p.sku === 'starter' && P.perm.starter) || (p.sku === 'noads' && P.perm.noAds);
  return '<div class="card' + (p.tag ? ' hl' : '') + '">' + (p.tag ? '<span class="tag">' + esc(t('tag.' + p.tag)) + '</span>' : '') +
    '<div class="ct"><h3>' + esc(t('iap.' + p.sku + '.n')) + '</h3></div><p>' + esc(t('iap.' + p.sku + '.d', { g: p.gems || 0, c: fmt(rewardCoins(p.coins || 0)) })) + '</p>' + (extra || '') +
    '<button class="btn primary" type="button" data-act="iap" data-sku="' + p.sku + '"' + (owned ? ' disabled' : '') + '>' + esc(owned ? t('shop.owned') : Billing.priceLabel(p)) + '</button></div>';
}
function gemCard(it) {
  const owned = it.perm && P.perm[it.id];
  return '<div class="card"><div class="ct"><h3>' + esc(t('gi.' + it.id + '.n')) + '</h3></div><p>' + esc(t('gi.' + it.id + '.d', { c: fmt(rewardCoins(it.coins || 0)) })) + '</p>' +
    '<button class="btn gemb" type="button" data-act="gem" data-id="' + it.id + '"' + (owned ? ' disabled' : '') + '>' +
    (owned ? esc(t('shop.owned')) : '<span class="price"><i class="ic gem"></i>' + it.cost + '</span>') + '</button></div>';
}
function shopHtml() {
  const byId = (s) => IAP.find((p) => p.sku === s);
  let h = '<div class="card"><div class="ct"><h3>' + esc(t('shop.gems')) + '</h3><span class="price"><i class="ic gem"></i>' + fmt(P.gems) + '</span></div><p>' + esc(t('shop.gemsInfo')) + '</p></div>';
  if (!P.perm.starter) h += iapCard(byId('starter'));
  const cap = piggyCap(), canBreak = P.piggy >= 200;
  h += '<div class="card"><div class="ct"><h3>' + esc(t('iap.piggy.n')) + '</h3><span class="price"><i class="ic coin"></i>' + fmt(P.piggy) + '</span></div><p>' + esc(t('iap.piggy.d', { m: fmt(cap) })) + '</p>' +
    '<div class="pig"><i style="width:' + Math.min(100, P.piggy / cap * 100) + '%"></i></div>' +
    '<button class="btn primary" type="button" data-act="iap" data-sku="piggy"' + (canBreak ? '' : ' disabled') + '>' + esc(canBreak ? t('piggy.break', { p: Billing.priceLabel(byId('piggy')) }) : t('piggy.min')) + '</button></div>';
  h += '<h3 class="sec">' + esc(t('shop.packs')) + '</h3><div class="grid2">' + ['gems_s', 'gems_m', 'gems_l'].map((s) => iapCard(byId(s))).join('') + '</div>';
  h += '<h3 class="sec">' + esc(t('shop.perm')) + '</h3><div class="grid2">' + gemCard(GEM_ITEMS[0]) + gemCard(GEM_ITEMS[1]) + iapCard(byId('noads')) + '</div>';
  h += '<h3 class="sec">' + esc(t('shop.boosts')) + '</h3><div class="grid2">' + GEM_ITEMS.slice(2).map(gemCard).join('') + '</div>';
  return h;
}

/* ---------- prestiż + drzewko umiejętności ---------- */
let skSel = 'blade';
function skTile(n) {
  const l = sk(n.id), un = skUnlocked(n), max = l >= n.max, can = un && !max && skCost(n) <= P.souls;
  return '<button type="button" class="sk' + (n.key ? ' key' : '') + (un ? '' : ' lock') + (max ? ' max' : '') + (can ? ' can' : '') + (n.id === skSel ? ' sel' : '') +
    '" data-act="sksel" data-id="' + n.id + '" aria-label="' + esc(t('sk.' + n.id + '.n')) + '"><b>' + n.ico + '</b><span>' + (un ? l + '/' + n.max : '&#9679;') + '</span></button>';
}
function skDetail() {
  const n = treeNode(skSel) || TREE[0], l = sk(n.id), un = skUnlocked(n), max = l >= n.max, c = max ? 0 : skCost(n);
  let st;
  if (max) st = t('tree.max'); else if (!un) st = t('tree.req', { n: t('sk.' + n.req[0] + '.n'), l: n.req[1] });
  else st = '';
  return '<div class="card' + (n.key ? ' hl' : '') + '"><div class="ct"><h3>' + esc(t('sk.' + n.id + '.n')) + '</h3><span class="lv">' + l + '/' + n.max + '</span></div>' +
    '<p class="d">' + esc(t('sk.' + n.id + '.d', { a: n.a, b: n.b })) + '</p>' + (st ? '<p class="d warn">' + esc(st) + '</p>' : '') +
    '<button class="btn primary" type="button" data-act="skbuy" data-id="' + n.id + '"' + (max || !un || P.souls < c ? ' disabled' : '') + '>' +
    (max ? esc(t('up.max')) : '<span class="bl">' + esc(t('up.buy')) + '</span><span class="price"><i class="ic soul"></i>' + c + '</span>') + '</button></div>';
}
function ascendHtml() {
  const w = runWave(), gain = soulsGain();
  let h = '<div class="card"><div class="ct"><h3>' + esc(t('asc.title')) + '</h3><span class="price"><i class="ic soul"></i>' + P.souls + '</span></div><p>' + esc(t('asc.info', { w: ASCEND_MIN_WAVE })) + '</p>' +
    '<p class="d">' + esc(t('asc.stats', { a: P.ascensions, b: P.best })) + '</p></div>';
  h += '<div class="card' + (gain > 0 ? ' hl' : '') + '"><div class="meter"><i style="width:' + Math.min(100, w / ASCEND_MIN_WAVE * 100) + '%"></i></div>' +
    '<p>' + esc(gain > 0 ? t('asc.gain', { n: gain }) : t('asc.need', { w: ASCEND_MIN_WAVE, c: w })) + '</p>' +
    '<button class="btn primary big" type="button" data-act="ascend"' + (canAscend() ? '' : ' disabled') + '>' + esc(S.phase === 'night' && gain > 0 ? t('asc.day') : t('asc.go')) + '</button></div>';
  h += '<h3 class="sec">' + esc(t('tree.title')) + '</h3><div class="tree">';
  for (const br of BRANCHES) h += '<div class="brh">' + esc(t('br.' + br)) + '</div>';
  for (let tier = 0; tier < 6; tier++) for (const br of BRANCHES) h += skTile(TREE.filter((n) => n.br === br)[tier]);
  h += '</div>' + skDetail();
  const spent = treeSpent();
  h += '<button class="btn gemb" type="button" data-act="respec"' + (spent ? '' : ' disabled') + '>' + esc(t('tree.respec', { s: spent })) + ' <span class="price"><i class="ic gem"></i>' + RESPEC_GEMS + '</span></button>';
  return h;
}
function openAscendConfirm() {
  const g = soulsGain();
  openModal({ title: t('asc.title'), html: '<p>' + esc(t('asc.confirm', { n: g })) + '</p>',
    acts: [{ label: t('asc.go'), cls: 'primary', fn: () => { const got = ascend(); if (got) { toast(t('asc.done', { n: got })); renderPanel(true); } } }, { label: t('act.cancel') }] });
}

/* ---------- jedna delegacja kliknięć dla zakładek renderowanych z HTML ---------- */
panelBody.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]'); if (!b || b.disabled) return;
  const a = b.getAttribute('data-act');
  if (a === 'daily') { const r = claimDaily(); if (r) toast(t('toast.got', { r: rewardText(r) })); }
  else if (a === 'quest') { const g = claimQuest(+b.getAttribute('data-i')); if (g) toast(t('toast.got', { r: t('rw.gems', { n: g }) })); }
  else if (a === 'qbonus') { const g = claimQuestBonus(); if (g) toast(t('toast.got', { r: t('rw.gems', { n: g }) })); }
  else if (a === 'ach') { const g = claimAch(b.getAttribute('data-id')); if (g) toast(t('toast.got', { r: t('rw.gems', { n: g }) })); }
  else if (a === 'spinfree') { doSpin(true); return; }
  else if (a === 'spinad') { doSpin(false); return; }
  else if (a === 'iap') { buyIap(b.getAttribute('data-sku')); return; }
  else if (a === 'gem') {
    const r = buyGemItem(b.getAttribute('data-id'));
    toast(r === 'ok' ? t('toast.purchased') : t('err.' + (r === 'nogems' ? 'nogems' : 'owned')), r !== 'ok');
    if (r === 'ok') beep(520, 0.08, 'square', 0.04, 880);
  }
  else if (a === 'ascend') { openAscendConfirm(); return; }
  else if (a === 'sksel') { skSel = b.getAttribute('data-id'); }
  else if (a === 'skbuy') {
    const r = buySkill(b.getAttribute('data-id'));
    if (r === 'ok') { beep(660, 0.1, 'square', 0.05, 1100); buzz(20); toast(t('tree.bought')); } else toast(t('err.' + r), true);
  }
  else if (a === 'respec') {
    const spent = treeSpent();
    openModal({ title: t('tree.respecT'), html: '<p>' + esc(t('tree.respecQ', { s: spent, g: RESPEC_GEMS })) + '</p>',
      acts: [{ label: t('tree.respecGo'), cls: 'primary', fn: () => { const r = respecTree(); if (r === 'ok') toast(t('tree.respecDone')); else toast(t('err.' + r), true); renderPanel(true); } }, { label: t('act.cancel') }] });
    return;
  }
  renderPanel(true);
});
bus.on('lang', () => { forgeBuilt = ''; lastSig = ''; renderPanel(true); });
bus.on('prices', () => { lastSig = ''; renderPanel(true); });
