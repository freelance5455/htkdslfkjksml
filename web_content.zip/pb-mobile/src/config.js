/* config.js: stałe świata gry oraz wszystkie tabele balansu i ofert (łatwe do strojenia w jednym miejscu) */
const W = 480, H = 300, GROUND = 250, CASTLE_X = 76;
const FIELD = { l: 96, r: 424, top: 38, bot: 208, colW: 16, rowH: 14 };
const GRAV = 380, STEP = 1 / 120, DAY_LEN = 25;
const BALL_R = 3, PEG_R = 2.5, REST = 0.52;
const RESPEC_GEMS = 40;           // reset drzewka umiejętności zwraca wszystkie wydane Dusze
const ASCEND_MIN_WAVE = 10;
const OFFLINE_CAP_SEC = 4 * 3600;
const REVIVE_GEMS = 50;
const INTERSTITIAL_EVERY = 3;     // co 3 przegrane
const INTERSTITIAL_GAP_MS = 4 * 60 * 1000;

/* ---------- potwory ---------- */
const TYPES = {
  slime:  { hp: 5,   spd: 14, w: 12, h: 10, reward: 2,  dmg: 1 },
  goblin: { hp: 4,   spd: 27, w: 10, h: 14, reward: 2,  dmg: 1 },
  bat:    { hp: 2,   spd: 40, w: 10, h: 8,  reward: 1,  dmg: 1, fly: true },
  brute:  { hp: 18,  spd: 10, w: 16, h: 20, reward: 6,  dmg: 3 },
  knight: { hp: 32,  spd: 9,  w: 14, h: 22, reward: 10, dmg: 4, armor: 1 },     // pancerz: odejmuje część obrażeń z każdego trafienia
  shaman: { hp: 16,  spd: 12, w: 12, h: 18, reward: 9,  dmg: 2, healer: true }, // leczy sąsiadów
  wraith: { hp: 90,  spd: 8,  w: 22, h: 28, reward: 30, dmg: 6, boss: true },
  golem:  { hp: 420, spd: 5,  w: 28, h: 32, reward: 90, dmg: 12, boss: true, armor: 1.6 },
  lich:   { hp: 260, spd: 7,  w: 20, h: 30, reward: 80, dmg: 9, boss: true, summons: true }
};
/* krzywa trudności: HP rośnie wykładniczo, więc kuźnia i drzewko muszą nadążać */
const hpMul = (n) => Math.pow(1.30, n - 1) * (1 + 0.05 * (n - 1)) * (1 + Math.pow(n / 18, 3));
const castleDmgMul = (n) => 1 + 0.06 * (n - 1);
const forgeDmg = (l) => Math.round((3 + 2 * l) * Math.pow(1.08, l));
const expDmg = (n) => forgeDmg(0.8 * n);                       // oczekiwane obrażenia gracza na fali n (do skalowania pancerza)
const armorOf = (type, n) => TYPES[type].armor ? Math.round(TYPES[type].armor * 0.3 * expDmg(n)) : 0;
const coinScale = (n) => Math.pow(hpMul(n), 0.72);               // nagroda za potwora rośnie wolniej niż jego HP
const bossOf = (n) => n % 5 !== 0 ? null : ['wraith', 'golem', 'lich'][(n / 5 + 2) % 3];
/* modyfikatory nocy (od fali 6, deterministyczne dla danej fali) */
const MODS = { swarm: { cnt: 1.8, hp: 0.55, gap: 0.6 }, iron: { hp: 1.5, spd: 0.85 }, haste: { spd: 1.35 }, rich: { coin: 1.5, hp: 1.25 } };
const MOD_IDS = Object.keys(MODS);
function waveMod(n) {
  if (n < 6 || bossOf(n)) return null;
  if (seeded(hashStr('mod' + n))() >= 0.4) return null;
  return MOD_IDS[Math.floor(seeded(hashStr('mid' + n))() * MOD_IDS.length)];
}
function buildWave(n, mod) {
  const M = mod ? MODS[mod] : {}, q = [];
  const count = Math.min(80, Math.round((5 + n * 1.9) * (M.cnt || 1)));
  const gap = Math.max(0.35, (1.5 - n * 0.045) * (M.gap || 1));
  const table = [['slime', n < 14 ? 10 : 3], ['goblin', n >= 2 ? 6 : 0], ['bat', n >= 5 ? 3 : 0], ['brute', n >= 4 ? 3 + n * 0.15 : 0],
                 ['knight', n >= 7 ? 2 + n * 0.12 : 0], ['shaman', n >= 9 ? 1.2 + n * 0.05 : 0]];
  const total = table.reduce((s, x) => s + x[1], 0);
  for (let i = 0; i < count; i++) {
    let r = Math.random() * total, ty = 'slime';
    for (const x of table) { r -= x[1]; if (r < 0) { ty = x[0]; break; } }
    q.push({ type: ty, delay: gap * rnd(0.7, 1.3) });
    if (ty === 'bat') for (let k = 0; k < 3; k++) q.push({ type: 'bat', delay: 0.18 });   // nietoperze lecą stadem
  }
  const boss = bossOf(n);
  if (boss) q.push({ type: boss, delay: gap * 3 });
  return q;
}
const isHardWave = (n) => n % 5 === 0 || n >= 8;

/* ---------- ulepszenia w kuźni (nazwy i opisy: klucze up.<id>.n / up.<id>.d) ---------- */
const cdVal = (l) => Math.max(0.2, 0.75 * Math.pow(0.92, l));
const sec1 = (n) => String(Math.round(n * 100) / 100) + ' ' + t('u.s');
const UPS = [
  { id: 'dmg',    max: 60, base: 12, mul: 1.30, val: (l) => fmt(forgeDmg(l)) },
  { id: 'rate',   max: 20, base: 15, mul: 1.40, val: (l) => sec1(cdVal(l)) },
  { id: 'multi',  max: 6,  base: 60, mul: 2.0,  val: (l) => 'x' + (1 + l) },
  { id: 'pierce', max: 8,  base: 50, mul: 1.8,  val: (l) => l === 0 ? '-' : '+' + l },
  { id: 'slow',   max: 5,  base: 25, mul: 1.5,  val: (l) => l === 0 ? '-' : '-' + (12 * l) + '%' },
  { id: 'crit',   max: 10, base: 30, mul: 1.5,  val: (l) => (6 * l) + '%' },
  { id: 'gold',   max: 20, base: 40, mul: 1.5,  val: (l) => '+' + (20 * l) + '%' },
  { id: 'auto',   max: 1,  base: 70, mul: 1,    val: (l) => l === 0 ? '-' : t('u.on') },
  { id: 'walls',  max: 12, base: 50, mul: 1.45, val: (l) => String(20 + 4 * l) },
  { id: 'repair', action: true }
];
const costOf = (u, l) => Math.round(u.base * Math.pow(u.mul, l) * (1 - 0.2 * sk('thrift')));

/* ---------- nagrody: {c: monety (bazowo), g: klejnoty, b: [id, sekundy], v: kule super-salwy} ---------- */
const BOOST_IDS = ['frenzy', 'gold', 'power'];   // frenzy: 2x szybkość zrzutu, gold: 2x monety, power: 2x obrażenia
const DAILY = [
  { c: 150 },
  { g: 5 },
  { b: ['gold', 600] },
  { c: 500 },
  { g: 10 },
  { b: ['power', 900] },
  { g: 40, c: 2000, b: ['frenzy', 900] }
];
const SPIN_SEGS = [
  { w: 22, c: 120,  col: '#4a90d9' },
  { w: 16, g: 3,    col: '#a259e0' },
  { w: 14, b: ['frenzy', 300], col: '#e0792e' },
  { w: 14, c: 400,  col: '#3aa86a' },
  { w: 12, b: ['gold', 300],   col: '#d9b12e' },
  { w: 5,  g: 10,   col: '#d94a8f' },
  { w: 12, b: ['power', 300],  col: '#d9433a' },
  { w: 2,  g: 25,   col: '#2ec7c7' }
];
const SPIN_EXTRA_MAX = 3;

/* ---------- misje dzienne: losowane z puli wg daty (id -> zdarzenie licznika) ---------- */
const QUEST_POOL = [
  { id: 'kill',  ev: 'kill',  goals: [30, 50, 80],    gems: 4 },
  { id: 'drop',  ev: 'drop',  goals: [60, 100, 150],  gems: 4 },
  { id: 'wave',  ev: 'wave',  goals: [3, 5, 7],       gems: 5 },
  { id: 'crit',  ev: 'crit',  goals: [8, 15, 25],     gems: 4 },
  { id: 'coins', ev: 'coins', goals: [400, 900, 1800], gems: 4 },
  { id: 'buy',   ev: 'buy',   goals: [3, 5, 8],       gems: 3 }
];
const QUEST_BONUS_GEMS = 10;

/* ---------- osiągnięcia kariery: stat -> progi i nagrody w klejnotach ---------- */
const ACHS = [
  { id: 'kills',  stat: (p) => p.totals.kills,  tiers: [100, 1000, 10000, 100000], gems: [5, 15, 40, 100] },
  { id: 'drops',  stat: (p) => p.totals.drops,  tiers: [200, 2000, 20000],         gems: [5, 15, 40] },
  { id: 'best',   stat: (p) => p.best,          tiers: [5, 10, 20, 35, 50, 75, 100, 150], gems: [5, 10, 25, 50, 100, 150, 250, 400] },
  { id: 'crits',  stat: (p) => p.totals.crits,  tiers: [50, 500, 5000],            gems: [5, 15, 40] },
  { id: 'bosses', stat: (p) => p.totals.bosses, tiers: [1, 10, 50],                gems: [5, 20, 60] },
  { id: 'asc',    stat: (p) => p.ascensions,    tiers: [1, 3, 10],                 gems: [10, 30, 80] },
  { id: 'spins',  stat: (p) => p.totals.spins,  tiers: [1, 7, 30],                 gems: [3, 10, 30] }
];

/* ---------- sklep: zakupy za prawdziwe pieniądze (SKU zgodne z Play Console) ---------- */
const IAP = [
  { sku: 'gems_s',  kind: 'consumable',    price: 0.99, gems: 100 },
  { sku: 'gems_m',  kind: 'consumable',    price: 4.99, gems: 550,  tag: 'popular' },
  { sku: 'gems_l',  kind: 'consumable',    price: 9.99, gems: 1250, tag: 'best' },
  { sku: 'starter', kind: 'once',          price: 2.99, gems: 300,  coins: 1500, boosts: [['frenzy', 1800], ['gold', 1800]] },
  { sku: 'piggy',   kind: 'consumable',    price: 1.99 },
  { sku: 'noads',   kind: 'nonconsumable', price: 2.99 }
];
/* ---------- sklep: zakupy za klejnoty ---------- */
const GEM_ITEMS = [
  { id: 'x2',        cost: 900, perm: true },
  { id: 'collector', cost: 500, perm: true },
  { id: 'frenzy',    cost: 40,  boost: ['frenzy', 900] },
  { id: 'power',     cost: 40,  boost: ['power', 900] },
  { id: 'gold',      cost: 40,  boost: ['gold', 900] },
  { id: 'coinpack',  cost: 30,  coins: 600 }
];
const piggyCap = () => 3000 + 600 * P.best;   // pojemność skarbonki rośnie z postępem
