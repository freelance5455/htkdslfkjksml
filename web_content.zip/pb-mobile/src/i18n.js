/* i18n.js: silnik tłumaczeń. Słowniki w i18n/en|pl|ru|de.js uzupełniają obiekt LANGS. */
const LANGS = {};
const SUPPORTED = ['en', 'pl', 'ru', 'de'];
const LANG_NAMES = { en: 'English', pl: 'Polski', ru: 'Русский', de: 'Deutsch' };
let LANG = 'en';

function detectLang() {
  const list = (navigator.languages && navigator.languages.length) ? navigator.languages : [navigator.language || 'en'];
  for (const l of list) {
    const c = String(l).slice(0, 2).toLowerCase();
    if (SUPPORTED.indexOf(c) >= 0) return c;
  }
  return 'en'; // każdy nierozpoznany język
}
function t(key, vars) {
  let s = LANGS[LANG] && LANGS[LANG][key];
  if (s === undefined) s = LANGS.en[key];
  if (s === undefined) return key;
  if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
  return s;
}
function applyI18n(root) {
  const r = root || document;
  r.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.getAttribute('data-i18n')); });
  r.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria'))); });
}
function setLang(code, persist) {
  if (SUPPORTED.indexOf(code) < 0) code = 'en';
  LANG = code;
  document.documentElement.setAttribute('lang', code);
  if (persist) { P.lang = code; save(); }
  document.title = t('app.title');
  applyI18n();
  bus.emit('lang', code);
}
