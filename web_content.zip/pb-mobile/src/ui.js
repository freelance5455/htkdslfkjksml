/* ui.js: modale, toasty, okna testowe (płatność / reklama), HUD, sterowanie, ustawienia, ekrany zdarzeń (koniec gry, nagrody) */
const modalRoot = $('modalRoot');
const cache = {};
function setText(id, v) { if (cache[id] !== v) { cache[id] = v; $(id).textContent = v; } }

function toast(text, bad) {
  const el = document.createElement('div');
  el.className = 'toast' + (bad ? ' bad' : '');
  el.textContent = text;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), 2600);
}

/* opts: {title, html, sim, acts:[{label, cls, ad, fn(api), keep}], onClose} */
function openModal(opts) {
  const m = document.createElement('div'), sh = document.createElement('div');
  m.className = 'modal'; sh.className = 'sheet';
  sh.setAttribute('role', 'dialog'); sh.setAttribute('aria-modal', 'true');
  sh.innerHTML = (opts.sim ? '<span class="sim">' + esc(opts.sim) + '</span>' : '') +
    (opts.title ? '<h2>' + esc(opts.title) + '</h2>' : '') + (opts.html || '') + '<div class="acts"></div>';
  const box = sh.querySelector('.acts');
  let closed = false;
  const api = { el: m, sheet: sh, btns: [],
    close() { if (closed) return; closed = true; m.remove(); modalCount = Math.max(0, modalCount - 1); if (opts.onClose) opts.onClose(); } };
  (opts.acts || []).forEach((a) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'btn ' + (a.cls || '');
    b.innerHTML = (a.ad ? '<i class="play"></i>' : '') + '<span>' + esc(a.label) + '</span>';
    if (a.disabled) b.disabled = true;
    b.addEventListener('click', () => { if (a.fn) a.fn(api); if (!a.keep) api.close(); });
    box.appendChild(b); api.btns.push(b);
  });
  m.appendChild(sh); modalRoot.appendChild(m); modalCount++;
  if (typeof releasePointers === 'function') releasePointers();
  return api;
}
const modalP = (opts) => new Promise((res) => { const o = Object.assign({}, opts, { onClose: () => res() }); openModal(o); });

/* ---------- okno testowe płatności (tryb symulacji; w aplikacji działa natywny Google Play Billing) ---------- */
function simPurchaseDialog(prod, priceText) {
  return new Promise((resolve) => {
    let result = 'cancel';
    openModal({
      sim: t('sim.badge'), title: t('pay.title'),
      html: '<div class="pay"><span>' + esc(t('iap.' + prod.sku + '.n')) + '</span><b>' + esc(priceText) + '</b></div><p>' + esc(t('pay.note')) + '</p>',
      acts: [
        { label: t('pay.buy'), cls: 'primary', fn: () => { result = 'ok'; } },
        { label: t('pay.fail'), fn: () => { result = 'fail'; } },
        { label: t('pay.cancel'), fn: () => { result = 'cancel'; } }
      ],
      onClose: () => resolve(result)
    });
  });
}

/* ---------- okno testowe reklamy (symulacja odtwarzacza; w aplikacji działa AdMob) ---------- */
function simAdDialog(kind, placement) {
  return new Promise((resolve) => {
    const rewarded = kind === 'rewarded', total = 5;
    let left = total, done = false, tm = 0, result = false;
    const api = openModal({
      sim: t('sim.badge'), title: rewarded ? t('ad.r.title') : t('ad.i.title'),
      html: '<div class="adbox"><span>' + esc(t('ad.body')) + '</span></div><div class="adbar"><i></i></div><p class="adtxt"></p>',
      acts: rewarded
        ? [{ label: t('ad.claim'), cls: 'primary', disabled: true, fn: () => { result = true; } }, { label: t('ad.skip'), fn: () => { result = false; } }]
        : [{ label: t('ad.close'), cls: 'primary', disabled: true, fn: () => { result = true; } }],
      onClose: () => { clearInterval(tm); resolve(result); }
    });
    const bar = api.sheet.querySelector('.adbar i'), txt = api.sheet.querySelector('.adtxt'), main = api.btns[0];
    const t0 = Date.now();
    const tick = () => {
      const el = (Date.now() - t0) / 1000; left = Math.max(0, total - el);
      bar.style.width = Math.min(100, el / total * 100) + '%';
      if (left <= 0 && !done) { done = true; main.disabled = false; clearInterval(tm); }
      txt.textContent = done ? (rewarded ? t('ad.done.r') : t('ad.done.i')) : (rewarded ? t('ad.wait.r', { n: Math.ceil(left) }) : t('ad.wait.i', { n: Math.ceil(left) }));
    };
    tick(); tm = setInterval(tick, 100);
  });
}

/* pomocnik: reklama z nagrodą; gra stoi na czas reklamy */
async function watchAd(placement, onReward) {
  modalCount++;
  let r = { rewarded: false };
  try { r = await Ads.showRewarded(placement); } catch (e) {}
  modalCount = Math.max(0, modalCount - 1);
  if (r.rewarded) { onReward(); } else toast(t('ad.noreward'), true);
  return r.rewarded;
}
async function showInterstitialSafe() {
  modalCount++;
  try { await Ads.showInterstitial(); } catch (e) {}
  modalCount = Math.max(0, modalCount - 1);
}
let payBusy = false;
async function buyIap(sku) {
  if (payBusy) return;
  payBusy = true; modalCount++;
  let r;
  try { r = await Billing.purchase(sku); } catch (e) { r = { ok: false, code: 'failed' }; }
  modalCount = Math.max(0, modalCount - 1); payBusy = false;
  if (r.ok) { fulfil(sku); toast(t('toast.purchased')); } else toast(t('err.' + r.code), r.code !== 'cancelled');
  renderPanel(true);
}

/* ---------- nagrody: wspólne fragmenty HTML ---------- */
function rewardMini(r) {
  if (r.g) return '<i class="ic gem"></i>' + r.g;
  if (r.c) return '<i class="ic coin"></i>' + fmt(rewardCoins(r.c));
  if (r.b) return esc(t('boost.' + r.b[0]));
  return '';
}
function daysHtml(st) {
  let h = '<div class="days">';
  for (let i = 0; i < 7; i++) {
    const cls = 'day' + (i === 6 ? ' last' : '') + (st.claimed ? (i <= st.day ? ' done' : '') : (i < st.day ? ' done' : (i === st.day ? ' now' : '')));
    h += '<div class="' + cls + '"><b>' + (i + 1) + '</b><span>' + rewardMini(DAILY[i]) + '</span></div>';
  }
  return h + '</div>';
}
function openDaily() {
  const st = dailyState();
  if (st.claimed) return Promise.resolve();
  const r = scaled(DAILY[st.day]);
  return modalP({
    title: t('daily.title'),
    html: '<p>' + esc(t('daily.streak', { n: st.streak })) + '</p>' + daysHtml(st) + '<p><b>' + esc(t('daily.today', { r: rewardText(r) })) + '</b></p>',
    acts: [{ label: t('act.claim'), cls: 'primary', fn: () => { claimDaily(); toast(t('toast.got', { r: rewardText(r) })); renderPanel(true); } }]
  });
}
function openOffline(off) {
  return modalP({
    title: t('off.title'), html: '<p>' + esc(t('off.body', { m: Math.round(off.sec / 60), c: fmt(off.coins) })) + '</p>',
    acts: [{ label: t('act.collect'), cls: 'primary', fn: () => { S.coins += off.coins; saveRun(); } }]
  });
}
function openTutorial() {
  return modalP({
    title: t('tut.title'), html: '<ul><li>' + esc(t('tut.1')) + '</li><li>' + esc(t('tut.2')) + '</li><li>' + esc(t('tut.3')) + '</li><li>' + esc(t('tut.4')) + '</li></ul>',
    acts: [{ label: t('tut.go'), cls: 'primary', fn: () => { P.tutorial = true; save(); } }]
  });
}

/* ---------- koniec gry ---------- */
function openGameOver(d) {
  const acts = [];
  if (!sessionRevived) acts.push({ label: t('over.reviveAd'), ad: true, cls: 'ad', keep: true, fn: (api) => {
    api.el.style.visibility = 'hidden';
    watchAd('revive', () => { sessionRevived = true; api.close(); revive(); }).then((ok) => { if (!ok) api.el.style.visibility = ''; });
  } });
  acts.push({ label: t('over.reviveGems', { n: REVIVE_GEMS }), cls: 'gemb', keep: true, fn: (api) => {
    if (reviveWithGems()) api.close(); else toast(t('err.nogems'), true);
  } });
  acts.push({ label: t('over.new'), fn: () => { startNewRun(); } });
  openModal({ title: t('over.title'), html: '<p>' + esc(t('over.body', { n: d.survived, b: P.best })) + '</p>', acts: acts });
}
async function startNewRun() {
  await showInterstitialSafe();
  P.run = null; newRun(); saveRun(); renderPanel(true);
}
bus.on('gameover', (d) => setTimeout(() => openGameOver(d), 650));

/* ---------- ustawienia i wybór języka ---------- */
function openSettings() {
  let langs = '<div class="langs">';
  SUPPORTED.forEach((c) => { langs += '<button type="button" class="lang' + (c === LANG ? ' on' : '') + '" data-lang="' + c + '">' + esc(LANG_NAMES[c]) + '</button>'; });
  langs += '</div>';
  let confirmReset = false;
  const api = openModal({
    title: t('menu.settings'),
    html: '<h3 class="sec">' + esc(t('menu.language')) + '</h3>' + langs +
      '<p class="ver">v1.0.0 · ' + esc(Billing.provider) + ' / ' + esc(Ads.provider) + '</p>',
    acts: [
      { label: t('menu.sound') + ': ' + (P.sound ? t('u.on') : t('u.off')), keep: true, fn: (a) => { P.sound = !P.sound; save(); a.btns[0].querySelector('span').textContent = t('menu.sound') + ': ' + (P.sound ? t('u.on') : t('u.off')); } },
      { label: t('menu.haptics') + ': ' + (P.haptics ? t('u.on') : t('u.off')), keep: true, fn: (a) => { P.haptics = !P.haptics; save(); a.btns[1].querySelector('span').textContent = t('menu.haptics') + ': ' + (P.haptics ? t('u.on') : t('u.off')); } },
      { label: t('menu.restore'), keep: true, fn: () => { Billing.restore().then(() => toast(t('menu.restored'))); } },
      { label: t('menu.reset'), cls: 'bad', keep: true, fn: (a) => {
        if (!confirmReset) { confirmReset = true; a.btns[3].querySelector('span').textContent = t('menu.reset2'); return; }
        resetProfile(); P.lang = LANG; P.tutorial = true; newRun(); a.close(); renderPanel(true); toast(t('menu.resetDone'));
      } },
      { label: t('act.close'), cls: 'primary' }
    ]
  });
  api.sheet.querySelectorAll('[data-lang]').forEach((b) => b.addEventListener('click', () => {
    setLang(b.getAttribute('data-lang'), true); api.close(); openSettings();
  }));
}
$('btnMenu').addEventListener('click', openSettings);

/* ---------- HUD i sterowanie (aktualizowane co klatkę, z cache tekstu) ---------- */
function updateHud() {
  const night = S.phase === 'night';
  document.documentElement.setAttribute('data-phase', S.night > 0.5 ? 'night' : 'day');
  setText('hWave', String(night ? S.wave : S.wave + 1));
  setText('hPhaseL', night ? t('hud.night') : t('hud.day'));
  setText('hPhase', night ? String(S.spawnQ.length + S.monsters.length) : (S.pendingBonus > 0 ? '||' : fmtTime(S.dayT)));
  setText('hCoins', fmt(S.coins));
  setText('hGems', fmt(P.gems));
  setText('hHp', S.hp + '/' + S.maxHp);
  const r = S.hp / S.maxHp, f = $('hpFill');
  f.style.width = (r * 100).toFixed(1) + '%';
  f.style.backgroundColor = r > 0.5 ? '' : (r > 0.25 ? '#e0a800' : '#d6403a');

  $('btnStart').hidden = night;
  setText('btnStart', t('act.start', { n: S.wave + 1 }));
  setText('btnPause', userPaused ? t('act.resume') : t('act.pause'));
  $('btnDrop').disabled = !night || S.over;
  $('cdBar').style.transform = 'scaleX(' + (night ? clamp(S.cd / curCd(), 0, 1) : 0).toFixed(3) + ')';
  const ba = $('btnAuto'); ba.hidden = !S.lv.auto;
  setText('btnAuto', t('act.auto') + ': ' + (S.autoOn ? t('u.on') : t('u.off')));
  const hardNext = S.phase === 'day' && isHardWave(S.wave + 1) && S.volleyPending === 0;
  $('btnVolley').hidden = !hardNext;
  $('bonusCard').hidden = S.pendingBonus <= 0;
  if (S.pendingBonus > 0) setText('bonusText', t('bonus.text', { n: fmt(S.pendingBonus) }));
}
let slowT = 0;
function updateSlow(dt) {              // rzadziej: boostery i czerwone kropki zakładek
  slowT -= dt; if (slowT > 0) return; slowT = 0.5;
  let h = '';
  for (const id of BOOST_IDS) if (P.boosts[id] > 0) h += '<div class="bst">' + esc(t('boost.' + id)) + ' ' + fmtTime(P.boosts[id]) + '</div>';
  if (cache.boosts !== h) { cache.boosts = h; $('boosts').innerHTML = h; }
  const c = claimables();
  document.querySelector('[data-tab="forge"]').classList.toggle('has', false);
  document.querySelector('[data-tab="quests"]').classList.toggle('has', c.daily || c.quests > 0);
  document.querySelector('[data-tab="spin"]').classList.toggle('has', c.spin);
  document.querySelector('[data-tab="shop"]').classList.toggle('has', false);
  document.querySelector('[data-tab="ascend"]').classList.toggle('has', c.ascend);
}

/* przyciski sterowania */
$('btnDrop').addEventListener('click', () => drop(lastAimX));
$('btnStart').addEventListener('click', () => { if (S.pendingBonus > 0) collectBonus(1); startNight(); });
$('btnAuto').addEventListener('click', () => { S.autoOn = !S.autoOn; });
$('btnPause').addEventListener('click', () => { userPaused = !userPaused; setText('btnPause', userPaused ? t('act.resume') : t('act.pause')); });
$('btnSpeed').addEventListener('click', () => { S.speed = S.speed === 1 ? 2 : (S.speed === 2 ? 3 : 1); $('btnSpeed').textContent = 'x' + S.speed; });
$('btnCollect').addEventListener('click', () => { const b = collectBonus(1); toast(t('toast.got', { r: t('rw.coins', { n: fmt(b) }) })); });
$('btnCollect2').addEventListener('click', () => {
  watchAd('wave_x2', () => { const b = collectBonus(2); toast(t('toast.got', { r: t('rw.coins', { n: fmt(b) }) })); });
});
$('btnVolley').addEventListener('click', () => {
  watchAd('volley', () => { grant({ v: 30 }); toast(t('toast.volley')); });
});
S.speed = 1;
