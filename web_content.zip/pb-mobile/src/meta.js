/* meta.js: pętle retencji i ekonomia poza samą walką: nagrody dzienne, misje, osiągnięcia, koło, prestiż, offline, zakupy */

/* ---------- nagrody ---------- */
const rewardCoins = (base) => Math.round(base * (1 + 0.3 * P.best));
function addBoost(id, sec) { P.boosts[id] = Math.min(3600, (P.boosts[id] || 0) + sec); }
function scaled(r) { const o = Object.assign({}, r); if (o.c) o.c = rewardCoins(o.c); return o; }
function grant(r) {                    // r: {c, g, b:[id,sec], v}; monety w r.c są już przeskalowane
  if (r.c) S.coins += r.c;
  if (r.g) P.gems += r.g;
  if (r.b) addBoost(r.b[0], r.b[1]);
  if (r.v) S.volleyPending += r.v;
  save();
}
function rewardText(r) {
  const parts = [];
  if (r.c) parts.push(t('rw.coins', { n: fmt(r.c) }));
  if (r.g) parts.push(t('rw.gems', { n: r.g }));
  if (r.b) parts.push(t('rw.boost.' + r.b[0], { m: Math.round(r.b[1] / 60) }));
  return parts.join(' + ');
}

/* ---------- codzienne logowanie (7-dniowy cykl, seria zeruje się po pominiętym dniu) ---------- */
function dailyState() {
  const today = dateKey(), d = P.daily;
  if (d.last === today) return { claimed: true, day: (d.streak - 1) % 7, streak: d.streak };
  const streak = d.last && daysBetween(d.last, today) === 1 ? d.streak + 1 : 1;
  return { claimed: false, day: (streak - 1) % 7, streak: streak };
}
function claimDaily() {
  const s = dailyState();
  if (s.claimed) return null;
  P.daily.last = dateKey(); P.daily.streak = s.streak;
  const r = scaled(DAILY[s.day]);
  grant(r); saveNow();
  return r;
}

/* ---------- misje dzienne ---------- */
function ensureQuests() {
  const today = dateKey();
  if (P.quests.date === today && P.quests.list.length) return;
  const rand = seeded(hashStr(today)), pool = QUEST_POOL.slice(), tier = P.best < 5 ? 0 : (P.best < 12 ? 1 : 2), list = [];
  for (let i = 0; i < 3; i++) {
    const q = pool.splice(Math.floor(rand() * pool.length), 1)[0];
    list.push({ id: q.id, goal: q.goals[tier], prog: 0, claimed: false });
  }
  P.quests = { date: today, list: list, bonus: false };
  save();
}
function questDef(id) { return QUEST_POOL.find((q) => q.id === id); }
function questProgress(ev, n) {
  ensureQuests();
  for (const q of P.quests.list) { const def = questDef(q.id); if (def.ev === ev && q.prog < q.goal) q.prog = Math.min(q.goal, q.prog + n); }
}
function claimQuest(i) {
  const q = P.quests.list[i];
  if (!q || q.claimed || q.prog < q.goal) return 0;
  q.claimed = true; const g = questDef(q.id).gems; P.gems += g; save(); return g;
}
function questsAllDone() { return P.quests.list.length > 0 && P.quests.list.every((q) => q.claimed); }
function claimQuestBonus() {
  if (!questsAllDone() || P.quests.bonus) return 0;
  P.quests.bonus = true; P.gems += QUEST_BONUS_GEMS; save(); return QUEST_BONUS_GEMS;
}

/* ---------- osiągnięcia kariery (progi kolejno, nagroda w klejnotach) ---------- */
function achState(a) {
  const done = P.ach[a.id] || 0, stat = a.stat(P), maxed = done >= a.tiers.length;
  return { stat: stat, done: done, maxed: maxed, goal: maxed ? a.tiers[a.tiers.length - 1] : a.tiers[done], gems: maxed ? 0 : a.gems[done], ready: !maxed && stat >= a.tiers[done] };
}
function claimAch(id) {
  const a = ACHS.find((x) => x.id === id), s = achState(a);
  if (!s.ready) return 0;
  P.ach[id] = s.done + 1; P.gems += s.gems; save(); return s.gems;
}

/* ---------- koło fortuny ---------- */
function spinState() {
  const today = dateKey();
  if (P.spin.xdate !== today) { P.spin.xdate = today; P.spin.extra = 0; }
  return { free: P.spin.date !== today, extraLeft: SPIN_EXTRA_MAX - P.spin.extra };
}
function spinRoll() {
  const total = SPIN_SEGS.reduce((s, x) => s + x.w, 0);
  let r = Math.random() * total;
  for (let i = 0; i < SPIN_SEGS.length; i++) { r -= SPIN_SEGS[i].w; if (r < 0) return i; }
  return 0;
}
function spinMarkUsed(free) { if (free) P.spin.date = dateKey(); else P.spin.extra++; save(); }
function spinReward(i) {
  const seg = SPIN_SEGS[i], r = { c: seg.c ? rewardCoins(seg.c) : 0, g: seg.g || 0, b: seg.b || null };
  grant(r); P.totals.spins++; saveNow(); return r;
}

/* ---------- prestiż (Ascension) ---------- */
function runWave() { return S.phase === 'night' ? S.wave - 1 : S.wave; }
function soulsGain() { const w = runWave(); return w < ASCEND_MIN_WAVE ? 0 : Math.floor(Math.pow(w - ASCEND_MIN_WAVE + 3, 1.5) * (1 + 0.08 * sk('soulgain'))); }
const canAscend = () => S.phase === 'day' && !S.over && soulsGain() > 0;
function ascend() {
  if (!canAscend()) return 0;
  const g = soulsGain();
  P.souls += g; P.soulsTotal += g; P.ascensions++; P.run = null;
  newRun(); saveRun(); saveNow();
  bus.emit('ascend', g);
  return g;
}

/* ---------- drzewko umiejętności (za Dusze) ---------- */
function buySkill(id) {
  const n = treeNode(id);
  if (!n) return 'locked';
  if (sk(id) >= n.max) return 'maxed';
  if (!skUnlocked(n)) return 'locked';
  const c = skCost(n);
  if (P.souls < c) return 'nosouls';
  P.souls -= c; P.tree[id] = sk(id) + 1;
  if (id === 'walls2' && S && !S.over) { S.maxHp += n.a; S.hp += n.a; }
  saveNow(); bus.emit('skill', id);
  return 'ok';
}
function respecTree() {
  const spent = treeSpent();
  if (!spent) return 'empty';
  if (P.gems < RESPEC_GEMS) return 'nogems';
  P.gems -= RESPEC_GEMS; P.souls += spent; P.tree = {};
  if (S) { S.maxHp = baseMaxHp() + 4 * S.lv.walls; S.hp = Math.min(S.hp, S.maxHp); }
  saveNow(); bus.emit('skill');
  return 'ok';
}
const skillAffordable = () => TREE.some((n) => sk(n.id) < n.max && skUnlocked(n) && skCost(n) <= P.souls);

/* ---------- zbieracz offline (stałe ulepszenie) ---------- */
function offlineEarnings() {
  if (!P.perm.collector || !P.lastSeen) return null;
  const sec = Math.min(OFFLINE_CAP_SEC, (Date.now() - P.lastSeen) / 1000);
  if (sec < 90) return null;
  const perMin = Math.round((4 + 1.5 * P.best) * (1 + 0.12 * sk('greed')) * (P.perm.x2 ? 2 : 1));
  return { sec: sec, coins: Math.floor(sec / 60 * perMin) };
}

/* ---------- kuźnia (ulepszenia w trakcie runu) ---------- */
const repairCost = () => 20 + 3 * S.wave;
function buyUp(u) {
  if (S.over) return false;
  if (u.action) {
    const c = repairCost();
    if (S.coins < c || S.hp >= S.maxHp) return false;
    S.coins -= c; S.hp = Math.min(S.maxHp, S.hp + 6);
  } else {
    const l = S.lv[u.id];
    if (l >= u.max) return false;
    const c = costOf(u, l);
    if (S.coins < c) return false;
    S.coins -= c; S.lv[u.id] = l + 1;
    if (u.id === 'walls') { S.maxHp += 4; S.hp += 4; }
    if (u.id === 'auto') S.autoOn = true;
  }
  bus.emit('buy'); saveRun();
  return true;
}

/* ---------- sklep za klejnoty ---------- */
function buyGemItem(id) {
  const it = GEM_ITEMS.find((x) => x.id === id);
  if (!it) return 'unknown';
  if (it.perm && P.perm[id]) return 'owned';
  if (P.gems < it.cost) return 'nogems';
  P.gems -= it.cost;
  if (it.perm) P.perm[id] = true;
  if (it.boost) addBoost(it.boost[0], it.boost[1]);
  if (it.coins) S.coins += rewardCoins(it.coins);
  P.totals.bought++; saveNow();
  return 'ok';
}
function reviveWithGems() {
  if (P.gems < REVIVE_GEMS) return false;
  P.gems -= REVIVE_GEMS; save(); revive(); return true;
}

/* ---------- zakupy za prawdziwe pieniądze: realizacja po potwierdzeniu płatności ---------- */
function fulfil(sku) {
  const p = IAP.find((x) => x.sku === sku);
  if (!p) return;
  if (p.gems) P.gems += p.gems;
  if (p.coins) S.coins += rewardCoins(p.coins);
  if (p.boosts) p.boosts.forEach((b) => addBoost(b[0], b[1]));
  if (sku === 'starter') P.perm.starter = true;
  if (sku === 'noads') P.perm.noAds = true;
  if (sku === 'piggy') { S.coins += P.piggy; P.piggy = 0; P.piggyBroken++; }
  P.totals.bought++; saveNow();
  bus.emit('buy');
}

/* ---------- liczniki: statystyki kariery + postęp misji ---------- */
bus.on('kill', () => { P.totals.kills++; questProgress('kill', 1); });
bus.on('boss', () => { P.totals.bosses++; });
bus.on('crit', () => { P.totals.crits++; questProgress('crit', 1); });
bus.on('drop', (n) => { P.totals.drops += n; questProgress('drop', n); });
bus.on('coins', (c) => { P.totals.coins += c; questProgress('coins', c); });
bus.on('wave', () => { P.totals.waves++; questProgress('wave', 1); });
bus.on('buy', () => { questProgress('buy', 1); });

/* czerwone kropki na zakładkach: co można odebrać */
function claimables() {
  ensureQuests(); spinState();
  const q = P.quests.list.filter((x) => !x.claimed && x.prog >= x.goal).length + (questsAllDone() && !P.quests.bonus ? 1 : 0);
  const a = ACHS.filter((x) => achState(x).ready).length;
  return { daily: !dailyState().claimed, quests: q + a, spin: spinState().free, ascend: canAscend() || skillAffordable() };
}
