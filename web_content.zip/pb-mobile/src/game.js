/* game.js: stan przebiegu (run), fizyka kulek, fale potworów. Zdarzenia: bus.emit('kill'|'drop'|'crit'|'coins'|'wave'|'boss'|'buy'|...) */
const S = {};
let sessionRevived = false;   // wskrzeszenie reklamą: raz na sesję aplikacji
let userPaused = false, modalCount = 0, gameStarted = false;
const isPaused = () => userPaused || modalCount > 0 || !gameStarted;

/* ---------- mnożniki: drzewko Dusz, stałe ulepszenia, boostery ---------- */
const boostOn = (id) => P.boosts[id] > 0;
const coinMul = () => (P.perm.x2 ? 2 : 1) * (1 + 0.12 * sk('greed')) * (boostOn('gold') ? 2 : 1) * (1 + 0.2 * S.lv.gold);
const dmgMul = () => (1 + 0.12 * sk('blade')) * (boostOn('power') ? 2 : 1);
const dmgVal = () => forgeDmg(S.lv.dmg) * dmgMul();
const critChance = () => 0.06 * S.lv.crit + 0.04 * sk('furyc');
const critMult = () => 2.5 + 0.15 * sk('furyc');
const pierceBase = () => S.lv.pierce + sk('pierce2');
const curCd = () => cdVal(S.lv.rate) * (1 - 0.05 * sk('tempo')) / (boostOn('frenzy') ? 2 : 1);
const baseMaxHp = () => 20 + 5 * sk('walls2');
const skipCoins = (h) => { let c = 0; for (let w = 1; w <= h; w++) c += (5 + 1.9 * w) * 2.4 * coinScale(w); return Math.round(c); };

function newRun(snap) {
  const hs = Math.min(2 * sk('headstart'), 10), hp = baseMaxHp();
  Object.assign(S, {
    wave: hs, phase: 'day', dayT: DAY_LEN, coins: 20 + 60 * sk('purse') + skipCoins(hs), hp: hp, maxHp: hp,
    monsters: [], balls: [], parts: [], floats: [], spawnQ: [], spawnT: 0,
    cd: 0, night: 0, over: false, autoOn: false, shake: 0, flash: 0, time: 0, hitSnd: 0,
    grace: 0, volleyN: 0, volleyT: 0, volleyPending: 0, pendingBonus: 0, banner: null,
    mod: null, ballCount: 0, towerT: 0, shieldLeft: 0, lastStand: sk('laststand'),
    lv: { dmg: 0, rate: 0, multi: 0, pierce: 0, slow: 0, crit: 0, gold: 0, auto: 0, walls: 0 }
  });
  if (snap) {
    S.wave = snap.wave; S.coins = snap.coins; S.hp = snap.hp; S.maxHp = snap.maxHp;
    Object.assign(S.lv, snap.lv); S.autoOn = !!snap.autoOn;
  }
  S.banner = { text: 'banner.prep', sub: '', t: 0, dur: 2.6 };
  bus.emit('run');
}
function saveRun() {
  P.run = { wave: S.phase === 'night' ? S.wave - 1 : S.wave, coins: S.coins, hp: S.hp, maxHp: S.maxHp, lv: S.lv, autoOn: S.autoOn };
  save();
}

/* ---------- dźwięk i wibracje ---------- */
let AC = null;
function beep(f, d, type, vol, f2) {
  if (!P.sound) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    if (AC.state === 'suspended') AC.resume();
    const o = AC.createOscillator(), g = AC.createGain(), now = AC.currentTime;
    o.type = type || 'square';
    o.frequency.setValueAtTime(f, now);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, now + d);
    g.gain.setValueAtTime(vol || 0.04, now);
    g.gain.exponentialRampToValueAtTime(0.0001, now + d);
    o.connect(g); g.connect(AC.destination);
    o.start(now); o.stop(now + d + 0.02);
  } catch (e) {}
}
function buzz(ms) { if (P.haptics && navigator.vibrate) { try { navigator.vibrate(ms); } catch (e) {} } }

/* ---------- kołki ---------- */
const pegs = [];
(function () {
  const rows = Math.floor((FIELD.bot - FIELD.top) / FIELD.rowH) + 1;
  for (let i = 0; i < rows; i++) {
    const off = (i % 2) ? FIELD.colW / 2 : 0;
    for (let x = FIELD.l + off; x <= FIELD.r; x += FIELD.colW) pegs.push({ x: x, y: FIELD.top + i * FIELD.rowH, f: 0 });
  }
})();

/* ---------- monety (skarbonka zbiera część zarobku) ---------- */
function earn(n, fromKill) {
  const c = Math.max(1, Math.round(n));
  S.coins += c;
  if (fromKill) P.piggy = Math.min(piggyCap(), P.piggy + Math.max(1, Math.round(c * 0.12)));
  bus.emit('coins', c);
  return c;
}

/* ---------- akcje gracza ---------- */
function spawnBall(x) {
  S.ballCount++;
  const mega = sk('mega') > 0 && S.ballCount % 8 === 0;   // kamień milowy: co 8. kula jest mega
  S.balls.push({ x: x, y: 16, vx: rnd(-14, 14), vy: 0, r: mega ? 5 : BALL_R, hit: [], pierce: pierceBase() + (mega ? 2 : 0), groundT: 0, bounces: 0, mega: mega });
}
function drop(x) {
  if (S.phase !== 'night' || S.cd > 0 || S.over || isPaused()) return false;
  const n = 1 + S.lv.multi, cx = clamp(x, FIELD.l + 4, FIELD.r - 4);
  for (let i = 0; i < n; i++) spawnBall(clamp(cx + (i - (n - 1) / 2) * 8, FIELD.l + 4, FIELD.r - 4));
  S.cd = curCd();
  bus.emit('drop', n);
  beep(520, 0.05, 'square', 0.02, 300);
  return true;
}
const towerInterval = () => 9 - sk('tower');
function startNight() {
  if (S.phase === 'night' || S.over) return;
  S.wave++;
  S.phase = 'night';
  S.mod = waveMod(S.wave);
  S.spawnQ = buildWave(S.wave, S.mod);
  S.spawnT = 2.4;
  S.shieldLeft = sk('shield');
  S.towerT = towerInterval();
  const boss = bossOf(S.wave);
  S.banner = { text: 'banner.wave', n: S.wave, sub: boss ? 'banner.boss' : (S.mod ? 'mod.' + S.mod : 'banner.incoming'), t: 0, dur: 2.6 };
  if (S.volleyPending > 0) { S.volleyN = S.volleyPending; S.volleyT = 1.2; S.volleyPending = 0; }
  beep(140, 0.5, 'sawtooth', 0.05, 70);
  buzz(boss ? 120 : 40);
}
function endNight() {
  S.phase = 'day'; S.dayT = DAY_LEN; S.balls.length = 0; S.volleyN = 0;
  S.pendingBonus = Math.round((8 + 3 * S.wave) * coinScale(S.wave) * coinMul() * (1 + 0.2 * sk('dawnb')));
  const heal = sk('regen') + (sk('bastion') > 0 ? Math.ceil(0.10 * S.maxHp) : 0);
  if (heal > 0 && S.hp < S.maxHp) { S.hp = Math.min(S.maxHp, S.hp + heal); S.floats.push({ x: CASTLE_X - 6, y: GROUND - 40, vy: -18, t: 0, life: 1.2, text: '+' + heal, col: '#6dff9a', size: 8 }); }
  if (S.wave > P.best) P.best = S.wave;
  S.banner = { text: 'banner.dawn', sub: 'banner.repelled', n: S.wave, t: 0, dur: 2.6 };
  beep(440, 0.12, 'triangle', 0.05); setTimeout(() => beep(660, 0.18, 'triangle', 0.05), 120);
  bus.emit('wave', S.wave);
  saveRun();
  bus.emit('waveEnd', { wave: S.wave, bonus: S.pendingBonus });
}
function collectBonus(mult) {
  const b = S.pendingBonus * (mult || 1);
  S.pendingBonus = 0;
  if (b > 0) earn(b, false);
  saveRun();
  return b;
}

/* ---------- potwory ---------- */
function spawnMonster(type, atX) {
  const T = TYPES[type], M = S.mod ? MODS[S.mod] : {};
  const hp = Math.max(1, Math.round(T.hp * hpMul(S.wave) * (M.hp || 1)));
  const y0 = T.fly ? GROUND - rnd(26, 70) : GROUND + Math.floor(rnd(0, 6));
  const m = { type: type, x: atX || W + 14, y: y0, y0: y0, hp: hp, maxHp: hp, spd: T.spd * (M.spd || 1), w: T.w, h: T.h,
    reward: T.reward * (M.coin || 1), dmg: Math.max(1, Math.round(T.dmg * castleDmgMul(S.wave))), armor: armorOf(type, S.wave),
    t: rnd(0, 6), flash: 0, slowT: 0, slowF: 1, dead: false, healT: 2.5, sumT: 5, fly: !!T.fly, boss: !!T.boss };
  S.monsters.push(m);
  return m;
}
function addPart(x, y, vx, vy, life, col, size) {
  if (S.parts.length > 260) return;
  S.parts.push({ x: x, y: y, vx: vx, vy: vy, life: life, max: life, col: col, size: size });
}
function killMonster(m) {
  m.dead = true;
  const c = earn(m.reward * coinScale(S.wave) * coinMul(), true);
  S.floats.push({ x: m.x, y: m.y - m.h - 4, vy: -16, t: 0, life: 1.1, text: '+' + fmt(c), col: '#ffd23f', size: 8 });
  for (let i = 0; i < (m.boss ? 24 : 9); i++) addPart(m.x + rnd(-m.w / 3, m.w / 3), m.y - m.h / 2 + rnd(-4, 4), rnd(-50, 50), rnd(-90, -20), rnd(0.4, 0.8), i % 3 === 0 ? '#ffd23f' : '#e9e9f5', 2);
  bus.emit('kill', m.type);
  if (m.boss) {
    bus.emit('boss'); buzz(60);
    const g = sk('bounty');
    if (g > 0) { P.gems += g; S.floats.push({ x: m.x, y: m.y - m.h - 14, vy: -14, t: 0, life: 1.4, text: '+' + g + ' gem', col: '#5ee0ff', size: 8 }); }
  }
  beep(700, 0.1, 'square', 0.03, 1200);
}
function hitMonster(b, m) {
  let d = dmgVal();
  if (b.mega) d *= sk('mega') > 0 ? 4 : 1;
  if (b.bounces > 0) d *= 1 + Math.min(1, 0.03 * sk('momentum') * b.bounces);       // rozpęd: im więcej kołków, tym mocniejsza kula
  if (sk('exec') > 0 && m.hp <= 0.35 * m.maxHp) d *= 1 + 0.2 * sk('exec');           // egzekucja
  if (sk('iceage') > 0 && m.slowT > 0) d *= 1.3;
  const crit = Math.random() < critChance();
  if (crit) d *= critMult();
  d = Math.round(d);
  if (m.armor > 0) d = Math.max(Math.ceil(d * 0.2), d - m.armor);                     // pancerz: min. 20% obrażeń
  d = Math.max(1, d);
  m.hp -= d; m.flash = 0.1; m.x += m.boss ? 0.4 : 1.5;
  if (crit) bus.emit('crit');
  const slow = clamp(0.12 * S.lv.slow + 0.06 * sk('frost'), 0, 0.65);
  if (slow > 0) { m.slowT = 2.2 + 0.4 * sk('frost'); m.slowF = 1 - slow; }
  S.floats.push({ x: m.x + rnd(-3, 3), y: m.y - m.h - 2, vy: -22, t: 0, life: 0.7, text: fmt(d) + (crit ? '!' : ''), col: crit ? '#ffd23f' : (b.mega ? '#d9a7ff' : '#ffffff'), size: 8 });
  for (let i = 0; i < 4; i++) addPart(b.x, b.y, rnd(-60, 60), rnd(-80, -10), rnd(0.2, 0.4), crit ? '#ffd23f' : '#ffffff', 1);
  if (S.time - S.hitSnd > 0.05) { S.hitSnd = S.time; beep(crit ? 330 : 220, 0.05, 'square', 0.025, crit ? 180 : 110); }
  if (m.hp <= 0) killMonster(m);
}

/* ---------- fizyka kulki (stały krok 1/120 s) ---------- */
function stepBall(b, dt) {
  b.vy += GRAV * dt;
  const mg = sk('magnet');
  if (mg > 0 && b.y > FIELD.top + 30) {                       // magnes: kula lekko skręca ku najbliższemu potworowi
    let best = null, bd = 1e9;
    for (const m of S.monsters) { if (m.dead) continue; const dx = Math.abs(m.x - b.x); if (dx < bd) { bd = dx; best = m; } }
    if (best) b.vx += clamp((best.x - b.x) / 50, -1, 1) * 140 * mg * dt;
  }
  b.x += b.vx * dt; b.y += b.vy * dt;
  const sp = Math.hypot(b.vx, b.vy);
  if (sp > 420) { b.vx *= 420 / sp; b.vy *= 420 / sp; }
  if (b.y < FIELD.bot + 8) {
    const lw = FIELD.l - 6 + b.r, rw = FIELD.r + 6 - b.r;
    if (b.x < lw) { b.x = lw; b.vx = Math.abs(b.vx) * 0.6; }
    if (b.x > rw) { b.x = rw; b.vx = -Math.abs(b.vx) * 0.6; }
  }
  const PR = b.r + PEG_R;
  for (let i = 0; i < pegs.length; i++) {
    const p = pegs[i], dx = b.x - p.x; if (dx > PR || dx < -PR) continue;
    const dy = b.y - p.y; if (dy > PR || dy < -PR) continue;
    const d2 = dx * dx + dy * dy;
    if (d2 < PR * PR && d2 > 1e-6) {
      const d = Math.sqrt(d2), nx = dx / d, ny = dy / d;
      b.x = p.x + nx * PR; b.y = p.y + ny * PR;
      const vn = b.vx * nx + b.vy * ny;
      if (vn < 0) { b.vx -= (1 + REST) * vn * nx; b.vy -= (1 + REST) * vn * ny; b.vx += rnd(-7, 7); b.bounces++; }
      p.f = 0.14;
    }
  }
  if (b.y + b.r > GROUND) {
    b.y = GROUND - b.r; b.vy = -b.vy * 0.4; b.vx *= 0.82;
    if (Math.abs(b.vy) < 24) b.vy = 0;
  }
  if (b.y + b.r >= GROUND - 0.6) b.groundT += dt;
  for (let i = 0; i < S.monsters.length; i++) {
    const m = S.monsters[i];
    if (m.dead || b.hit.indexOf(m) >= 0) continue;
    const cx = clamp(b.x, m.x - m.w / 2, m.x + m.w / 2), cy = clamp(b.y, m.y - m.h, m.y);
    const ddx = b.x - cx, ddy = b.y - cy;
    if (ddx * ddx + ddy * ddy < (b.r + 1) * (b.r + 1)) {
      b.hit.push(m); hitMonster(b, m);
      if (b.pierce <= 0) { b.dead = true; return; }
      b.pierce--;
    }
  }
  if (b.groundT > 1.3 || b.y > H + 10 || b.x < -10 || b.x > W + 10) b.dead = true;
}

function castleHit(m) {
  if (S.shieldLeft > 0) {                                      // tarcza: pierwsze trafienia w każdej fali są blokowane
    S.shieldLeft--; S.flash = 0.1;
    S.floats.push({ x: CASTLE_X - 6, y: GROUND - 40, vy: -18, t: 0, life: 1, text: '0', col: '#6cc0ff', size: 8 });
    beep(300, 0.12, 'triangle', 0.05, 600);
    return;
  }
  const d = sk('bastion') > 0 ? Math.max(1, Math.round(m.dmg * 0.65)) : m.dmg;
  S.hp = Math.max(0, S.hp - d);
  S.shake = 0.35; S.flash = 0.3;
  S.floats.push({ x: CASTLE_X - 6, y: GROUND - 40, vy: -18, t: 0, life: 1, text: '-' + d, col: '#ff5a4d', size: 8 });
  beep(110, 0.25, 'sawtooth', 0.06, 50); buzz(70);
  if (S.hp <= 0 && S.lastStand > 0) {                          // ostatnia szansa: raz na bieg zostajesz z 1 życiem
    S.lastStand--; S.hp = 1;
    S.floats.push({ x: CASTLE_X, y: GROUND - 60, vy: -14, t: 0, life: 1.6, text: '!', col: '#ffd23f', size: 12 });
  }
  if (S.hp <= 0) gameOver();
}
function gameOver() {
  S.over = true; S.monsters.length = 0; S.balls.length = 0;
  P.best = Math.max(P.best, S.wave - 1);
  P.losses++; P.run = null; saveNow();
  beep(200, 0.8, 'sawtooth', 0.06, 40);
  bus.emit('gameover', { survived: Math.max(0, S.wave - 1) });
}
function revive() {
  if (!S.over) return;
  S.over = false; S.hp = Math.ceil(S.maxHp / 2); S.monsters.length = 0; S.grace = 3;
  S.banner = { text: 'banner.revived', sub: '', t: 0, dur: 2 };
  beep(330, 0.15, 'triangle', 0.05, 880);
  bus.emit('revive');
}
function autoTarget() {
  let best = null;
  for (const m of S.monsters) { if (!m.dead && m.x <= FIELD.r + 20 && (!best || m.x < best.x)) best = m; }
  return best ? clamp(best.x - best.spd * 1.5 + rnd(-6, 6), FIELD.l + 6, FIELD.r - 6) : null;
}

/* ---------- krok symulacji; heldX to x aktywnego dotyku albo null ---------- */
function update(dt, heldX) {
  S.time += dt;
  const target = S.phase === 'night' ? 1 : 0;
  S.night += clamp(target - S.night, -0.3 * dt, 0.3 * dt);
  S.cd = Math.max(0, S.cd - dt);
  S.shake = Math.max(0, S.shake - dt); S.flash = Math.max(0, S.flash - dt);
  if (S.banner) { S.banner.t += dt; if (S.banner.t > S.banner.dur) S.banner = null; }
  for (const p of pegs) if (p.f > 0) p.f -= dt;
  for (const id of BOOST_IDS) if (P.boosts[id] > 0) P.boosts[id] = Math.max(0, P.boosts[id] - dt);

  if (S.phase === 'day') {
    if (S.pendingBonus === 0) { S.dayT -= dt; if (S.dayT <= 0) startNight(); }
  } else if (!S.over) {
    if (S.grace > 0) S.grace -= dt;
    else {
      S.spawnT -= dt;
      if (S.spawnQ.length && S.spawnT <= 0) { spawnMonster(S.spawnQ.shift().type); S.spawnT = S.spawnQ.length ? S.spawnQ[0].delay : 0; }
    }
    if (heldX !== null && heldX !== undefined) drop(heldX);
    if (S.lv.auto && S.autoOn && S.cd <= 0) { const x = autoTarget(); if (x !== null) drop(x); }
    if (S.volleyN > 0) {
      S.volleyT -= dt;
      if (S.volleyT <= 0) { spawnBall(rnd(FIELD.l + 6, FIELD.r - 6)); S.volleyN--; S.volleyT = 0.045; bus.emit('drop', 1); }
    }
    if (sk('tower') > 0 && S.monsters.length) {                 // wieża zamku sama wystrzeliwuje kulę
      S.towerT -= dt;
      if (S.towerT <= 0) { S.towerT = towerInterval(); const x = autoTarget(); spawnBall(x === null ? rnd(FIELD.l + 6, FIELD.r - 6) : x); }
    }
  }
  for (const b of S.balls) if (!b.dead) stepBall(b, dt);
  S.balls = S.balls.filter((b) => !b.dead);

  const wm = Math.min(1.6, 1 + 0.015 * (S.wave - 1)) * (1 - 0.03 * sk('chill')) * (sk('iceage') > 0 ? 0.9 : 1);
  const born = [];
  for (const m of S.monsters) {
    if (m.dead) continue;
    m.t += dt; if (m.flash > 0) m.flash -= dt;
    let sm = 1; if (m.slowT > 0) { m.slowT -= dt; sm = m.slowF; }
    m.x -= m.spd * wm * sm * dt;
    if (m.fly) m.y = m.y0 + Math.sin(m.t * 6) * 6;
    if (TYPES[m.type].healer) {                                 // szaman leczy potwory w pobliżu
      m.healT -= dt;
      if (m.healT <= 0) {
        m.healT = 2.5;
        for (const o of S.monsters) if (!o.dead && Math.abs(o.x - m.x) < 80 && o.hp < o.maxHp) {
          o.hp = Math.min(o.maxHp, o.hp + Math.ceil(0.08 * o.maxHp));
          addPart(o.x, o.y - o.h, 0, -30, 0.5, '#6dff9a', 2);
        }
      }
    }
    if (TYPES[m.type].summons && m.x < W - 10) {                // lisz przyzywa nietoperze
      m.sumT -= dt;
      if (m.sumT <= 0 && S.monsters.length < 140) { m.sumT = 7; for (let i = 0; i < 3; i++) born.push(m.x + i * 6); }
    }
    if (m.x - m.w / 2 <= CASTLE_X) { m.dead = true; castleHit(m); }
  }
  for (const x of born) spawnMonster('bat', x);
  S.monsters = S.monsters.filter((m) => !m.dead);
  for (const p of S.parts) { p.life -= dt; p.vy += 260 * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
  S.parts = S.parts.filter((p) => p.life > 0);
  for (const f of S.floats) { f.t += dt; f.y += f.vy * dt; f.vy *= 0.96; }
  S.floats = S.floats.filter((f) => f.t < f.life);
  if (S.phase === 'night' && !S.over && S.spawnQ.length === 0 && S.monsters.length === 0 && S.grace <= 0) endNight();
}
