/* tree.js: drzewko umiejętności kupowane za Dusze (prestiż). 4 gałęzie x 6 poziomów; każdy węzeł wymaga rozwinięcia poprzedniego w gałęzi.
   a, b: liczby wstawiane do opisu (sk.<id>.d) i używane w efektach (patrz game.js). key: węzeł-kamień milowy na szczycie gałęzi. */
const BRANCHES = ['power', 'wealth', 'fort', 'time'];
const TREE_COST_MUL = 1;
const TREE = [
  /* SIŁA */
  { id: 'blade',     br: 'power',  ico: 'DMG', max: 10, a: 12,         cost: (l) => 2 + l },
  { id: 'furyc',     br: 'power',  ico: 'CRT', max: 6,  a: 4,  b: 15,  cost: (l) => 4 + 2 * l,   req: ['blade', 3] },
  { id: 'pierce2',   br: 'power',  ico: 'PRC', max: 3,  a: 1,          cost: (l) => 10 + 8 * l,  req: ['furyc', 2] },
  { id: 'exec',      br: 'power',  ico: 'EXE', max: 5,  a: 20, b: 35,  cost: (l) => 12 + 6 * l,  req: ['pierce2', 1] },
  { id: 'momentum',  br: 'power',  ico: 'MOM', max: 5,  a: 3,          cost: (l) => 15 + 7 * l,  req: ['exec', 2] },
  { id: 'mega',      br: 'power',  ico: 'MEG', max: 1,  a: 8,  b: 4,   cost: () => 60,           req: ['momentum', 3], key: true },
  /* ZŁOTO */
  { id: 'greed',     br: 'wealth', ico: 'GLD', max: 10, a: 12,         cost: (l) => 2 + l },
  { id: 'purse',     br: 'wealth', ico: 'BAG', max: 8,  a: 60,         cost: (l) => 3 + 2 * l,   req: ['greed', 3] },
  { id: 'soulgain',  br: 'wealth', ico: 'SOL', max: 10, a: 8,          cost: (l) => 6 + 4 * l,   req: ['purse', 2] },
  { id: 'bounty',    br: 'wealth', ico: 'GEM', max: 3,  a: 1,          cost: (l) => 15 + 10 * l, req: ['soulgain', 2] },
  { id: 'headstart', br: 'wealth', ico: 'RUN', max: 5,  a: 2,          cost: (l) => 20 + 12 * l, req: ['bounty', 1] },
  { id: 'thrift',    br: 'wealth', ico: 'SAV', max: 1,  a: 20,         cost: () => 70,           req: ['headstart', 2], key: true },
  /* MURY */
  { id: 'walls2',    br: 'fort',   ico: 'HP',  max: 10, a: 5,          cost: (l) => 2 + l },
  { id: 'regen',     br: 'fort',   ico: 'REG', max: 5,  a: 1,          cost: (l) => 5 + 3 * l,   req: ['walls2', 3] },
  { id: 'shield',    br: 'fort',   ico: 'SHD', max: 3,  a: 1,          cost: (l) => 12 + 8 * l,  req: ['regen', 2] },
  { id: 'laststand', br: 'fort',   ico: 'LST', max: 2,  a: 1,          cost: (l) => 25 + 25 * l, req: ['shield', 1] },
  { id: 'tower',     br: 'fort',   ico: 'TWR', max: 5,  a: 8,          cost: (l) => 18 + 10 * l, req: ['laststand', 1] },
  { id: 'bastion',   br: 'fort',   ico: 'BAS', max: 1,  a: 35, b: 10,  cost: () => 75,           req: ['tower', 2], key: true },
  /* CZAS */
  { id: 'chill',     br: 'time',   ico: 'SLO', max: 8,  a: 3,          cost: (l) => 2 + l },
  { id: 'frost',     br: 'time',   ico: 'ICE', max: 5,  a: 6,          cost: (l) => 5 + 3 * l,   req: ['chill', 3] },
  { id: 'magnet',    br: 'time',   ico: 'MAG', max: 3,  a: 1,          cost: (l) => 12 + 8 * l,  req: ['frost', 2] },
  { id: 'tempo',     br: 'time',   ico: 'TMP', max: 8,  a: 5,          cost: (l) => 10 + 5 * l,  req: ['magnet', 1] },
  { id: 'dawnb',     br: 'time',   ico: 'DAW', max: 5,  a: 20,         cost: (l) => 12 + 8 * l,  req: ['tempo', 3] },
  { id: 'iceage',    br: 'time',   ico: 'AGE', max: 1,  a: 10, b: 30,  cost: () => 80,           req: ['dawnb', 2], key: true }
];
TREE.forEach((n) => { const c = n.cost; n.cost = (l) => Math.round(c(l) * TREE_COST_MUL); });

const sk = (id) => (P.tree && P.tree[id]) || 0;                 // poziom umiejętności
const treeNode = (id) => TREE.find((n) => n.id === id);
const skUnlocked = (n) => !n.req || sk(n.req[0]) >= n.req[1];
const skCost = (n) => n.cost(sk(n.id));
function treeSpent() {
  let s = 0;
  for (const n of TREE) for (let l = 0; l < sk(n.id); l++) s += n.cost(l);
  return s;
}
