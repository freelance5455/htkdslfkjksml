/* services/ads.js: adapter reklam.
   provider 'sim'    : okienko testowe z odliczaniem (przeglądarka / development).
   provider 'admob'  : @capacitor-community/admob (window.Capacitor.Plugins.AdMob). Używa testowych ID Google.
                       Przed wydaniem podmień ID na własne z konsoli AdMob i dodaj zgodę UMP (RODO).
   Kontrakt: showRewarded(placement) -> Promise<{rewarded:boolean}>, showInterstitial() -> Promise<void> */
const Ads = (() => {
  const TEST_IDS = { rewarded: 'ca-app-pub-3940256099942544/5224354917', interstitial: 'ca-app-pub-3940256099942544/1033173712' };
  let provider = 'sim', AdMob = null, lastFinish = 0;

  function init() {
    const C = window.Capacitor;
    const native = C && C.isNativePlatform && C.isNativePlatform();
    const plugin = native ? (C.registerPlugin ? C.registerPlugin('AdMob') : (C.Plugins || {}).AdMob) : null;
    if (plugin) {
      AdMob = plugin; provider = 'admob';
      return AdMob.initialize({ initializeForTesting: true }).catch(() => { provider = 'sim'; });
    }
    return Promise.resolve();
  }
  function showRewarded(placement) {
    if (provider === 'admob') {
      return new Promise((resolve) => {
        let rewarded = false;
        const subs = [];
        const done = () => { subs.forEach((s) => s && s.remove && s.remove()); resolve({ rewarded: rewarded }); };
        Promise.all([
          AdMob.addListener('onRewardedVideoAdReward', () => { rewarded = true; }),
          AdMob.addListener('onRewardedVideoAdDismissed', () => done()),
          AdMob.addListener('onRewardedVideoAdFailedToLoad', () => done())
        ]).then((s) => { subs.push.apply(subs, s); return AdMob.prepareRewardVideoAd({ adId: TEST_IDS.rewarded }); })
          .then(() => AdMob.showRewardVideoAd()).catch(done);
      }).then((r) => { if (r.rewarded) { P.totals.ads++; save(); } return r; });
    }
    return simAdDialog('rewarded', placement).then((ok) => { if (ok) { P.totals.ads++; save(); } return { rewarded: ok }; });
  }
  function interstitialAllowed() {
    if (P.perm.noAds) return false;
    if (P.losses === 0 || P.losses % INTERSTITIAL_EVERY !== 0) return false;
    return Date.now() - Math.max(P.lastInter, lastFinish) > INTERSTITIAL_GAP_MS;
  }
  function showInterstitial() {
    if (!interstitialAllowed()) return Promise.resolve();
    P.lastInter = Date.now(); save();
    const fin = () => { lastFinish = Date.now(); };
    if (provider === 'admob') {
      return AdMob.prepareInterstitial({ adId: TEST_IDS.interstitial }).then(() => AdMob.showInterstitial()).then(fin, fin);
    }
    return simAdDialog('interstitial').then(fin);
  }
  return { init: init, showRewarded: showRewarded, showInterstitial: showInterstitial, get provider() { return provider; } };
})();
