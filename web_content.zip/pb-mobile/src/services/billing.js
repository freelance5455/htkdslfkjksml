/* services/billing.js: adapter płatności.
   provider 'sim'  : okno testowe w grze (przeglądarka / development), nic nie kosztuje.
   provider 'play' : cordova-plugin-purchase (CdvPurchase) po spakowaniu przez Capacitor. Adapter referencyjny:
                     przed publikacją podłącz weryfikację paragonów po stronie serwera i przetestuj na koncie testowym Play.
   Kontrakt: purchase(sku) -> Promise<{ok:true}> | Promise<{ok:false, code:'cancelled'|'failed'|'owned'|'unavailable'}> */
const Billing = (() => {
  const SIM_DELAY = 900;
  let provider = 'sim', plugin = null, ready = false;
  const pending = {};            // sku -> {resolve}
  const prices = {};             // sku -> lokalna cena z Google Play (gdy dostępna)

  function setup() {
    const C = window.CdvPurchase;
    if (!C || !C.store) return Promise.resolve();
    plugin = C; provider = 'play';
    const { store, ProductType, Platform } = C;
    store.register(IAP.map((p) => ({
      id: p.sku, platform: Platform.GOOGLE_PLAY,
      type: p.kind === 'nonconsumable' || p.kind === 'once' ? ProductType.NON_CONSUMABLE : ProductType.CONSUMABLE
    })));
    store.when()
      .approved((tr) => tr.verify())            // TODO: ustaw store.validator na własny serwer weryfikujący paragony
      .verified((rc) => rc.finish());
    store.when().finished((tr) => {
      const id = tr.products && tr.products[0] && tr.products[0].id;
      if (id && pending[id]) { pending[id].resolve({ ok: true }); delete pending[id]; }
    });
    store.error((e) => {
      Object.keys(pending).forEach((k) => {
        pending[k].resolve({ ok: false, code: e && e.code === C.ErrorCode.PAYMENT_CANCELLED ? 'cancelled' : 'failed' }); delete pending[k];
      });
    });
    return store.initialize([Platform.GOOGLE_PLAY]).then(() => {
      ready = true;
      IAP.forEach((p) => {
        const pr = store.get(p.sku, Platform.GOOGLE_PLAY), off = pr && pr.getOffer && pr.getOffer();
        if (off && off.pricingPhases && off.pricingPhases[0]) prices[p.sku] = off.pricingPhases[0].price;
      });
      bus.emit('prices');
    });
  }
  function init() {            // w aplikacji wtyczka pojawia się dopiero po deviceready
    return new Promise((resolve) => {
      const start = () => { try { Promise.resolve(setup()).then(resolve, resolve); } catch (e) { resolve(); } };
      if (window.CdvPurchase) return start();
      const native = window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
      if (!native) return resolve();
      document.addEventListener('deviceready', start, { once: true });
      setTimeout(() => { if (window.CdvPurchase && !ready) start(); else resolve(); }, 4000);
    });
  }
  function priceLabel(p) { return prices[p.sku] || ('$' + p.price.toFixed(2)); }
  function purchase(sku) {
    const prod = IAP.find((p) => p.sku === sku);
    if (!prod) return Promise.resolve({ ok: false, code: 'unavailable' });
    if ((prod.kind === 'once' || prod.kind === 'nonconsumable') && P.perm[sku === 'starter' ? 'starter' : 'noAds']) return Promise.resolve({ ok: false, code: 'owned' });
    if (provider === 'play') {
      if (!ready) return Promise.resolve({ ok: false, code: 'unavailable' });
      return new Promise((resolve) => {
        pending[sku] = { resolve: resolve };
        const pr = plugin.store.get(sku, plugin.Platform.GOOGLE_PLAY), off = pr && pr.getOffer();
        if (!off) { delete pending[sku]; resolve({ ok: false, code: 'unavailable' }); return; }
        off.order();
      });
    }
    // symulacja: okno testowe z możliwością wymuszenia błędu
    return simPurchaseDialog(prod, priceLabel(prod)).then((res) => new Promise((resolve) => {
      if (res === 'cancel') return resolve({ ok: false, code: 'cancelled' });
      setTimeout(() => resolve(res === 'ok' ? { ok: true } : { ok: false, code: 'failed' }), SIM_DELAY);
    }));
  }
  function restore() {
    if (provider === 'play' && ready) return plugin.store.restorePurchases().then(() => ({ ok: true }));
    return Promise.resolve({ ok: true });   // sim: stan trzymany w profilu
  }
  return { init: init, purchase: purchase, restore: restore, priceLabel: priceLabel, get provider() { return provider; } };
})();
