/* util.js: pomocnicze funkcje, magistrala zdarzeń, profil gracza (localStorage z awaryjnym zapisem w pamięci) */
const $ = (id) => document.getElementById(id);
const rnd = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const ease = (t) => t * t * (3 - 2 * t);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const bus = (() => {
  const m = {};
  return {
    on(e, f) { (m[e] = m[e] || []).push(f); },
    emit(e, d) { (m[e] || []).forEach((f) => f(d)); }
  };
})();

function fmt(n) {
  n = Math.floor(n);
  if (n < 1000) return String(n);
  const u = ['K', 'M', 'B', 'T']; let i = -1, v = n;
  while (v >= 1000 && i < u.length - 1) { v /= 1000; i++; }
  return (v < 10 ? v.toFixed(2) : v < 100 ? v.toFixed(1) : String(Math.floor(v))) + u[i];
}
function fmtTime(sec) {
  sec = Math.max(0, Math.ceil(sec));
  const m = Math.floor(sec / 60), s = sec % 60;
  return m + ':' + (s < 10 ? '0' : '') + s;
}
function dateKey(d) {
  d = d || new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function daysBetween(a, b) { // a, b: 'YYYY-MM-DD'
  const pa = a.split('-').map(Number), pb = b.split('-').map(Number);
  return Math.round((Date.UTC(pb[0], pb[1] - 1, pb[2]) - Date.UTC(pa[0], pa[1] - 1, pa[2])) / 864e5);
}
function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function seeded(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

/* ---------- profil ---------- */
const SAVE_KEY = 'plinko-bastion-v2';
const defaultProfile = () => ({
  v: 2, lang: null, sound: true, haptics: true,
  gems: 20, souls: 0, soulsTotal: 0, tree: {}, ascensions: 0, best: 0,
  perm: { x2: false, collector: false, noAds: false, starter: false },
  piggy: 0, piggyBroken: 0,
  totals: { kills: 0, drops: 0, waves: 0, bosses: 0, crits: 0, coins: 0, spins: 0, ads: 0, bought: 0 },
  daily: { streak: 0, last: '' },
  quests: { date: '', list: [], bonus: false },
  ach: {},
  spin: { date: '', extra: 0, xdate: '' },
  boosts: { frenzy: 0, gold: 0, power: 0 },
  lastSeen: 0, run: null, tutorial: false, losses: 0, lastInter: 0
});
function mergeDeep(base, src) {
  if (!src || typeof src !== 'object') return base;
  for (const k of Object.keys(base)) {
    if (!(k in src)) continue;
    const b = base[k];
    if (b && typeof b === 'object' && !Array.isArray(b)) {
      if (Object.keys(b).length === 0) { if (src[k] && typeof src[k] === 'object') base[k] = src[k]; }   // słownik z dowolnymi kluczami (ach, tree)
      else mergeDeep(b, src[k]);
    } else base[k] = src[k];
  }
  return base;
}
let memStore = null;
function loadProfile() {
  let raw = null;
  try { raw = localStorage.getItem(SAVE_KEY); } catch (e) { raw = memStore; }
  const p = defaultProfile();
  if (raw) { try { mergeDeep(p, JSON.parse(raw)); } catch (e) {} }
  return p;
}
let P = loadProfile();
let saveTimer = 0;
function saveNow() {
  clearTimeout(saveTimer); saveTimer = 0;
  P.lastSeen = Date.now();
  const s = JSON.stringify(P);
  try { localStorage.setItem(SAVE_KEY, s); } catch (e) { memStore = s; }
}
function save() { if (!saveTimer) saveTimer = setTimeout(saveNow, 400); }
function resetProfile() { P = defaultProfile(); saveNow(); }
