/* main.js: wejście dotykowe (multi-touch), dopasowanie rozmiaru canvasa, pętla 60/120 FPS, start aplikacji */
let lastAimX = 260, rotIdx = 0;
const pointers = new Map();
const finePointer = matchMedia('(pointer: fine)').matches;
function releasePointers() { pointers.clear(); }
const canvasX = (e) => { const r = cv.getBoundingClientRect(); return clamp((e.clientX - r.left) / r.width * W, FIELD.l + 4, FIELD.r - 4); };
function heldX() {
  if (!pointers.size) return null;
  const v = Array.from(pointers.values());
  return v[rotIdx % v.length];               // przy kilku palcach zrzuty rotują między nimi
}
bus.on('drop', () => { rotIdx++; });

cv.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  const x = canvasX(e);
  pointers.set(e.pointerId, x); lastAimX = x;
  try { cv.setPointerCapture(e.pointerId); } catch (_) {}
  drop(x);
});
cv.addEventListener('pointermove', (e) => { const x = canvasX(e); lastAimX = x; if (pointers.has(e.pointerId)) pointers.set(e.pointerId, x); });
const endPtr = (e) => { pointers.delete(e.pointerId); };
window.addEventListener('pointerup', endPtr);
window.addEventListener('pointercancel', endPtr);
window.addEventListener('blur', releasePointers);
cv.addEventListener('contextmenu', (e) => e.preventDefault());
window.addEventListener('keydown', (e) => {
  if (e.target && /input|textarea/i.test(e.target.tagName)) return;
  if (e.code === 'Space') { e.preventDefault(); if (!e.repeat) drop(lastAimX); }
  else if (e.code === 'KeyP') $('btnPause').click();
});

/* ---------- rozmiar planszy: największy prostokąt 8:5 mieszczący się w kontenerze ---------- */
const wrap = $('cvwrap');
function fit() {
  const landscape = matchMedia('(min-width: 640px) and (min-aspect-ratio: 1/1)').matches;
  let w = wrap.clientWidth;
  if (landscape) w = Math.min(w, wrap.clientHeight * 1.6);
  w = Math.max(160, Math.floor(w));
  cv.style.width = w + 'px'; cv.style.height = Math.round(w / 1.6) + 'px';
}
if (window.ResizeObserver) new ResizeObserver(fit).observe(wrap);
window.addEventListener('resize', fit);
window.addEventListener('orientationchange', () => setTimeout(fit, 120));

/* ---------- pętla: stały krok fizyki 1/120 s, rysowanie przy każdym odświeżeniu ekranu (60 lub 120 Hz) ---------- */
let last = performance.now(), acc = 0, panelT = 0;
function frame(now) {
  const dt = Math.min(0.1, (now - last) / 1000);
  last = now;
  if (!isPaused() && !S.over) {
    acc += dt * S.speed;
    let n = 0;
    while (acc >= STEP && n < 400) { update(STEP, heldX()); acc -= STEP; n++; }
    if (n >= 400) acc = 0;
  } else acc = 0;
  draw(pointers.size ? Array.from(pointers.values()) : (finePointer ? [lastAimX] : []));
  updateHud(); updateSlow(dt);
  panelT -= dt;
  if (panelT <= 0) { panelT = 0.25; renderPanel(false); }
  requestAnimationFrame(frame);
}

/* ---------- zapis przy wyjściu z aplikacji ---------- */
function flush() { if (S.phase === 'day' && !S.over) saveRun(); saveNow(); }
document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });
window.addEventListener('pagehide', flush);
setInterval(() => { if (!document.hidden) saveNow(); }, 15000);

/* ---------- start ---------- */
function boot() {
  const off = offlineEarnings();
  newRun(P.run);                       // stan gry musi istnieć, zanim setLang odświeży panele
  setLang(P.lang || detectLang(), false);
  Billing.init(); Ads.init();
  P.lastSeen = Date.now();
  ensureQuests();
  gameStarted = true;
  fit(); setTab('forge');
  (async () => {
    if (off) await openOffline(off);
    if (!P.tutorial) await openTutorial();
    await openDaily();
  })();
  requestAnimationFrame((t0) => { last = t0; frame(t0); });
  if (window.__PB_TEST) window.__PB_TEST({ S: S, get P() { return P; }, drop: drop, startNight: startNight, update: update, claimDaily: claimDaily, dailyState: dailyState,
    ensureQuests: ensureQuests, questProgress: questProgress, claimQuest: claimQuest, spinRoll: spinRoll, spinReward: spinReward, ascend: ascend, soulsGain: soulsGain,
    fulfil: fulfil, buyGemItem: buyGemItem, buyUp: buyUp, setLang: setLang, t: t, detectLang: detectLang, LANGS: LANGS, grant: grant, collectBonus: collectBonus,
    buySkill: buySkill, respecTree: respecTree, TREE: TREE, sk: sk, treeSpent: treeSpent, newRun: newRun, autoTarget: autoTarget, buildWave: buildWave, hpMul: hpMul, curCd: curCd, UPS: UPS, costOf: costOf });
}
boot();
