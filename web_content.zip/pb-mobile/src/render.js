/* render.js: rysowanie planszy 480x300 (pixel art). Statyczne warstwy są cache'owane w offscreen canvas. */
const cv = $('cv');
const ctx = cv.getContext('2d', { alpha: false });
ctx.imageSmoothingEnabled = false;

const rgb = (c) => 'rgb(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ')';
const mixA = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const mix = (a, b, k) => rgb(mixA(a, b, k));
function Rc(c, x, y, w, h, col) { c.fillStyle = col; c.fillRect(Math.round(x), Math.round(y), w, h); }
const R = (x, y, w, h, col) => Rc(ctx, x, y, w, h, col);
function disc(c, cx, cy, r, col) {
  c.fillStyle = col;
  for (let dy = -r; dy <= r; dy++) { const w = Math.floor(Math.sqrt(r * r - dy * dy + 0.5)); c.fillRect(Math.round(cx) - w, Math.round(cy) + dy, 2 * w + 1, 1); }
}
function layer(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; return { c: c, x: x, key: -1 }; }

const stars = [], clouds = [];
for (let i = 0; i < 46; i++) stars.push({ x: Math.floor(rnd(0, W)), y: Math.floor(rnd(2, 150)), p: rnd(0, 6.28) });
for (let i = 0; i < 5; i++) clouds.push({ x: rnd(0, W), y: rnd(18, 90), w: rnd(26, 46), v: rnd(2, 6) });

const SKY_DAY_TOP = [112, 188, 236], SKY_DAY_BOT = [214, 236, 246], SKY_NIGHT_TOP = [7, 10, 30], SKY_NIGHT_BOT = [30, 36, 86], DAWN = [255, 158, 96];
const skyL = layer(W, GROUND), landL = layer(W, H), boardL = layer(W, H);

function buildSky(n) {
  const dawn = Math.sin(clamp(n, 0, 1) * Math.PI), top = mixA(SKY_DAY_TOP, SKY_NIGHT_TOP, n), bot = mixA(SKY_DAY_BOT, SKY_NIGHT_BOT, n);
  const bands = 14, bh = Math.ceil(GROUND / bands);
  for (let i = 0; i < bands; i++) {
    const k = i / (bands - 1);
    Rc(skyL.x, 0, i * bh, W, bh + 1, rgb(mixA(mixA(top, bot, k), DAWN, dawn * 0.85 * k * k)));
  }
}
function buildLand(n) {
  const x = landL.x; x.clearRect(0, 0, W, H);
  x.fillStyle = mix([140, 190, 190], [26, 34, 78], n);
  for (let i = 0; i < W; i += 2) { const y = Math.round(GROUND - 28 - (Math.sin(i * 0.018 + 1) * 14 + Math.sin(i * 0.05 + 2) * 5)); x.fillRect(i, y, 2, GROUND - y); }
  x.fillStyle = mix([86, 160, 110], [18, 40, 54], n);
  for (let i = 0; i < W; i += 2) { const y = Math.round(GROUND - 12 - (Math.sin(i * 0.027 + 4) * 8 + Math.sin(i * 0.07) * 3)); x.fillRect(i, y, 2, GROUND - y); }
  Rc(x, 0, GROUND, W, H - GROUND, mix([122, 86, 54], [40, 30, 38], n));
  Rc(x, 0, GROUND, W, 4, mix([96, 178, 84], [30, 74, 62], n));
  Rc(x, 0, GROUND + 4, W, 2, mix([72, 140, 64], [22, 56, 50], n));
  const dc = mix([100, 68, 42], [30, 22, 30], n);
  for (let i = 6; i < W; i += 23) Rc(x, i, GROUND + 14 + (i * 7) % 22, 5, 2, dc);
}
function buildBoard() {
  const x = boardL.x, x0 = FIELD.l - 10, w = FIELD.r - FIELD.l + 20, y0 = 22, h = FIELD.bot - y0 + 12;
  x.fillStyle = 'rgba(8,12,36,0.30)'; x.fillRect(x0, y0, w, h);
  x.fillStyle = 'rgba(255,255,255,0.35)';
  x.fillRect(x0, y0, w, 1); x.fillRect(x0, y0, 1, h); x.fillRect(x0 + w - 1, y0, 1, h);
  for (const p of pegs) { Rc(x, p.x - 1, p.y - 2, 3, 5, '#e6ecff'); Rc(x, p.x - 2, p.y - 1, 5, 3, '#e6ecff'); Rc(x, p.x - 1, p.y - 1, 1, 1, '#fff'); }
}
buildBoard();

function drawSkyDynamic(n) {
  if (n > 0.05) for (const s of stars) { ctx.fillStyle = 'rgba(255,255,235,' + (n * (0.55 + 0.45 * Math.sin(S.time * 2 + s.p))).toFixed(2) + ')'; ctx.fillRect(s.x, s.y, 1, 1); }
  const sunH = ease(clamp(1 - n, 0, 1));
  if (sunH > 0.01) {
    const sy = lerp(GROUND + 14, 44, sunH);
    ctx.globalAlpha = 0.25; disc(ctx, 330, sy, 17, '#fff2b0'); ctx.globalAlpha = 1;
    disc(ctx, 330, sy, 12, '#ffe27a'); disc(ctx, 330, sy, 9, '#fff3b8');
  }
  const moonH = ease(clamp(n, 0, 1));
  if (moonH > 0.01) {
    const my = lerp(GROUND + 14, 40, moonH);
    ctx.globalAlpha = 0.18; disc(ctx, 384, my, 17, '#cfd8ff'); ctx.globalAlpha = 1;
    disc(ctx, 384, my, 11, '#e6ebff'); disc(ctx, 381, my - 3, 2, '#c3cbee'); disc(ctx, 388, my + 3, 3, '#c3cbee');
  }
  const cc = rgb(mixA([255, 255, 255], [70, 80, 140], n));
  ctx.globalAlpha = 0.9 * (1 - n * 0.75);
  for (const c of clouds) { const x = Math.round(c.x), y = Math.round(c.y), w = Math.round(c.w); R(x + 4, y, w - 8, 3, cc); R(x, y + 3, w, 3, cc); R(x + 8, y - 3, w / 2, 3, cc); }
  ctx.globalAlpha = 1;
}
function drawCave(n) {
  const x = W - 24, st = mix([110, 112, 130], [56, 58, 86], n);
  R(x, GROUND - 40, 24, 40, st); R(x + 2, GROUND - 44, 22, 4, st);
  R(x + 6, GROUND - 32, 18, 32, '#07070f'); R(x + 8, GROUND - 35, 16, 3, '#07070f');
  R(x, GROUND - 40, 24, 2, mix([150, 152, 170], [80, 84, 120], n));
  if (n > 0.3 && S.phase === 'night') { ctx.globalAlpha = 0.5 + 0.5 * (0.5 + 0.5 * Math.sin(S.time * 4)); R(x + 11, GROUND - 24, 2, 2, '#ff3b3b'); R(x + 17, GROUND - 24, 2, 2, '#ff3b3b'); ctx.globalAlpha = 1; }
}
function drawCastle(n) {
  const hurt = 1 - S.hp / S.maxHp, L = mix([172, 178, 198], [112, 118, 150], n), D = mix([128, 134, 160], [78, 84, 116], n);
  R(0, 204, 50, 46, L);
  for (let y = 210; y < 250; y += 6) R(0, y, 50, 1, D);
  for (let y = 204, i = 0; y < 250; y += 6, i++) for (let x = (i % 2) * 6; x < 50; x += 12) R(x, y, 1, 6, D);
  for (let x = 0; x < 48; x += 10) R(x, 198, 6, 6, L);
  R(44, 164, 30, 86, L);
  for (let y = 170; y < 250; y += 6) R(44, y, 30, 1, D);
  for (let y = 164, i = 0; y < 250; y += 6, i++) for (let x = 44 + (i % 2) * 7; x < 74; x += 14) R(x, y, 1, 6, D);
  for (let x = 44; x < 74; x += 10) R(x, 158, 6, 6, L);
  R(44, 164, 30, 2, D); R(58, 134, 1, 24, '#3a3a48');
  if (sk('tower') > 0) { R(74, 150, 10, 6, '#6a6f88'); R(82, 151, 6, 2, '#2a2e42'); R(74, 156, 6, 8, D); }
  const fw = 11 + Math.round(Math.sin(S.time * 5) * 1.5);
  R(59, 134, fw, 7, '#d6403a'); R(59, 134, fw, 1, '#f06a5e');
  R(8, 222, 20, 28, '#2a1d14'); R(10, 219, 16, 3, '#2a1d14'); R(13, 216, 10, 3, '#2a1d14');
  R(17, 218, 2, 32, '#4a3626'); R(8, 232, 20, 1, '#4a3626'); R(8, 242, 20, 1, '#4a3626');
  R(55, 178, 6, 11, '#151a30'); R(30, 214, 4, 8, '#151a30');
  if (n > 0.2) { ctx.globalAlpha = n; R(56, 179, 4, 9, '#ffd45a'); R(31, 215, 2, 6, '#ffd45a'); ctx.globalAlpha = 1; }
  if (hurt > 0.3) { R(16, 206, 1, 6, D); R(17, 212, 2, 1, D); R(36, 232, 1, 8, D); }
  if (hurt > 0.6) { R(62, 196, 1, 10, D); R(60, 206, 2, 1, D); R(6, 236, 1, 8, D); R(24, 200, 1, 5, D); }
  if (S.flash > 0) { ctx.globalAlpha = S.flash * 1.4; R(0, 134, 76, 116, '#ff3b3b'); ctx.globalAlpha = 1; }
  R(1, 186, 46, 6, '#000');
  const r = S.hp / S.maxHp;
  R(2, 187, Math.round(44 * r), 4, r > 0.5 ? '#4cc77a' : (r > 0.25 ? '#ffc83d' : '#ff5a4d'));
}

/* ---------- sprity potworów ---------- */
function mcol(m, base) { if (m.flash > 0) return '#ffffff'; if (m.slowT > 0) return mix(base, [130, 200, 255], 0.55); return rgb(base); }
function drawSlime(m) {
  const hop = Math.round(Math.abs(Math.sin(m.t * 5)) * 2), x = Math.round(m.x - 6), y = Math.round(m.y - 10) - hop, c = mcol(m, [76, 190, 98]);
  R(x + 4, y, 4, 1, c); R(x + 2, y + 1, 8, 1, c); R(x + 1, y + 2, 10, 2, c); R(x, y + 4, 12, 5, c); R(x + 1, y + 9, 10, 1, c);
  R(x + 3, y + 4, 2, 3, '#fff'); R(x + 7, y + 4, 2, 3, '#fff'); R(x + 3, y + 5, 1, 2, '#18222e'); R(x + 7, y + 5, 1, 2, '#18222e');
}
function drawGoblin(m) {
  const x = Math.round(m.x - 5), y = Math.round(m.y - 14), st = Math.floor(m.t * 8) % 2, skin = mcol(m, [128, 176, 64]), cloth = mcol(m, [160, 88, 52]);
  R(x + 2, y, 6, 5, skin); R(x, y + 1, 2, 2, skin); R(x + 8, y + 1, 2, 2, skin); R(x + 3, y + 2, 1, 1, '#ffec6a'); R(x + 6, y + 2, 1, 1, '#ffec6a');
  R(x + 2, y + 5, 6, 5, cloth); R(x + 2, y + 10, 2, 4 - st, skin); R(x + 6, y + 10, 2, 3 + st, skin);
  R(x - 3, y + 7, 4, 1, '#d6dcee'); R(x + 1, y + 6, 1, 3, '#6b4a2a');
}
function drawBrute(m) {
  const x = Math.round(m.x - 8), y = Math.round(m.y - 20), st = Math.floor(m.t * 5) % 2, skin = mcol(m, [150, 92, 176]);
  R(x + 4, y, 8, 6, skin); R(x + 2, y, 2, 3, '#e8e0c8'); R(x + 12, y, 2, 3, '#e8e0c8'); R(x + 5, y + 2, 2, 2, '#ff4040'); R(x + 9, y + 2, 2, 2, '#ff4040');
  R(x + 1, y + 6, 14, 9, skin); R(x + 1, y + 11, 14, 2, '#4a3322'); R(x - 1, y + 7, 2, 6, skin); R(x + 15, y + 7, 2, 6, skin);
  R(x - 4, y + 4 + st, 3, 12, '#7a5230'); R(x - 5, y + 3 + st, 5, 3, '#6a4426'); R(x + 3, y + 15, 4, 5 - st, skin); R(x + 9, y + 15, 4, 4 + st, skin);
}
function drawWraith(m) {
  const hov = Math.round(Math.sin(m.t * 2.5) * 2), x = Math.round(m.x - 11), y = Math.round(m.y - 28) - 2 + hov, st = Math.floor(m.t * 6), c = mcol(m, [92, 70, 140]);
  R(x + 4, y, 14, 6, c); R(x + 2, y + 6, 18, 10, c); R(x, y + 16, 22, 8, c);
  for (let i = 0; i < 6; i++) R(x + i * 4, y + 24, 3, 3 + ((i + st) % 2) * 2, c);
  R(x + 6, y + 3, 10, 7, '#0a0a14'); R(x + 8, y + 6, 2, 2, '#ff3b3b'); R(x + 13, y + 6, 2, 2, '#ff3b3b');
  R(x - 4, y + 4, 1, 22, '#7a5230'); R(x - 6, y + 2, 5, 2, '#cfd6e6'); R(x - 7, y + 4, 2, 2, '#cfd6e6');
}
function drawBat(m) {
  const x = Math.round(m.x - 5), y = Math.round(m.y - 8), f = Math.floor(m.t * 14) % 2, c = mcol(m, [120, 84, 160]);
  R(x + 3, y + 2, 4, 4, c); R(x + 4, y + 1, 2, 1, c);
  if (f) { R(x - 2, y, 5, 2, c); R(x + 7, y, 5, 2, c); } else { R(x - 2, y + 3, 5, 2, c); R(x + 7, y + 3, 5, 2, c); }
  R(x + 4, y + 3, 1, 1, '#ff4040'); R(x + 6, y + 3, 1, 1, '#ff4040');
}
function drawKnight(m) {
  const x = Math.round(m.x - 7), y = Math.round(m.y - 22), st = Math.floor(m.t * 4) % 2, c = mcol(m, [150, 160, 185]), d = mcol(m, [100, 108, 130]);
  R(x + 3, y, 8, 7, c); R(x + 3, y + 3, 8, 2, '#12141c'); R(x + 6, y - 2, 2, 3, '#d6403a');
  R(x + 1, y + 7, 12, 9, c); R(x + 1, y + 12, 12, 1, d); R(x - 3, y + 6, 5, 10, m.flash > 0 ? '#fff' : '#3a5ea8'); R(x - 3, y + 6, 5, 1, d);
  R(x + 13, y + 8, 1, 10, '#dfe6f5'); R(x + 3, y + 16, 3, 6 - st, d); R(x + 8, y + 16, 3, 5 + st, d);
}
function drawShaman(m) {
  const x = Math.round(m.x - 6), y = Math.round(m.y - 18), c = mcol(m, [70, 140, 110]), g = Math.floor(S.time * 6) % 2;
  R(x + 2, y - 1, 8, 3, c); R(x + 3, y + 1, 6, 4, '#c9e8c0'); R(x + 4, y + 2, 1, 1, '#2a2a2a'); R(x + 7, y + 2, 1, 1, '#2a2a2a');
  R(x + 1, y + 5, 10, 11, c); R(x + 3, y + 16, 2, 2, c); R(x + 7, y + 16, 2, 2, c);
  R(x + 12, y - 2, 1, 18, '#6b4a2a'); R(x + 11, y - 5, 3, 3, g ? '#6dff9a' : '#2ea860');
}
function drawGolem(m) {
  const x = Math.round(m.x - 14), y = Math.round(m.y - 32), st = Math.floor(m.t * 2) % 2, c = mcol(m, [130, 126, 120]), d = mcol(m, [88, 84, 80]);
  R(x + 8, y, 12, 9, c); R(x + 10, y + 3, 3, 2, '#ffb02e'); R(x + 15, y + 3, 3, 2, '#ffb02e');
  R(x + 2, y + 9, 24, 14, c); R(x + 2, y + 9, 24, 2, d); R(x + 10, y + 14, 8, 1, d);
  R(x - 4, y + 10, 6, 14, c); R(x + 26, y + 10, 6, 14, c); R(x - 5, y + 22, 8, 5, d); R(x + 25, y + 22, 8, 5, d);
  R(x + 5, y + 23, 7, 9 - st, d); R(x + 16, y + 23, 7, 8 + st, d);
}
function drawLich(m) {
  const hov = Math.round(Math.sin(m.t * 3) * 2), x = Math.round(m.x - 10), y = Math.round(m.y - 30) + hov, c = mcol(m, [60, 70, 120]);
  R(x + 5, y + 2, 10, 8, '#e8e4d0'); R(x + 7, y + 5, 2, 2, '#33e0ff'); R(x + 11, y + 5, 2, 2, '#33e0ff'); R(x + 8, y + 9, 4, 1, '#2a2a2a');
  R(x + 5, y + 1, 10, 1, '#ffd23f'); R(x + 5, y - 1, 2, 3, '#ffd23f'); R(x + 9, y - 2, 2, 4, '#ffd23f'); R(x + 13, y - 1, 2, 3, '#ffd23f');
  R(x + 2, y + 10, 16, 12, c); R(x, y + 22, 20, 6, c);
  R(x - 4, y + 6, 1, 20, '#6b4a2a'); R(x - 6, y + 3, 5, 4, '#33e0ff');
}
const SPRITES = { slime: drawSlime, goblin: drawGoblin, brute: drawBrute, wraith: drawWraith, bat: drawBat, knight: drawKnight, shaman: drawShaman, golem: drawGolem, lich: drawLich };
function drawMonsters() {
  const list = S.monsters.slice().sort((a, b) => a.y - b.y);
  for (const m of list) {
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(Math.round(m.x - m.w / 2), Math.round(m.fly ? GROUND + 2 : m.y), m.w, 2);
    SPRITES[m.type](m);
    if (m.hp < m.maxHp) {
      const x = Math.round(m.x - m.w / 2), y = Math.round(m.y - m.h) - 5;
      R(x, y, m.w, 3, '#000'); R(x + 1, y + 1, Math.max(1, Math.round((m.w - 2) * m.hp / m.maxHp)), 1, m.boss ? '#ffb02e' : '#ff5a4d');
    }
  }
}
function drawBalls() {
  const ice = S.lv.slow > 0, c = ice ? '#bfe6ff' : '#ffd23f';
  for (const b of S.balls) {
    if (b.mega) { R(b.x - 3, b.y - 5, 7, 11, '#d9a7ff'); R(b.x - 5, b.y - 3, 11, 7, '#d9a7ff'); R(b.x - 3, b.y - 3, 3, 2, '#fff'); R(b.x - 3, b.y + 3, 6, 2, '#8a4fd0'); continue; }
    R(b.x - 2, b.y - 3, 5, 7, c); R(b.x - 3, b.y - 2, 7, 5, c); R(b.x - 2, b.y - 2, 2, 1, '#fff'); R(b.x - 2, b.y + 2, 4, 1, ice ? '#5aa8e0' : '#c98a00'); }
}
/* aimXs: tablica x aktywnych dotknięć / kursora */
function drawAim(aimXs) {
  if (S.phase !== 'night' || isPaused() || S.over) return;
  ctx.globalAlpha = S.cd > 0 ? 0.25 : 0.7;
  for (const ax of aimXs) {
    const x = Math.round(clamp(ax, FIELD.l + 4, FIELD.r - 4));
    for (let y = 24; y < FIELD.top - 2; y += 4) R(x, y, 1, 2, '#ffffff');
    R(x - 3, 12, 7, 3, '#ffd23f'); R(x - 2, 15, 5, 3, '#ffd23f');
  }
  ctx.globalAlpha = 1;
}
function drawText(text, x, y, size, col, alpha) {
  ctx.font = size + 'px "Press Start 2P", monospace';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  while (size > 6 && ctx.measureText(text).width > W - 24) { size--; ctx.font = size + 'px "Press Start 2P", monospace'; }
  ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  ctx.fillStyle = '#000'; ctx.fillText(text, Math.round(x) + 1, Math.round(y) + 1);
  ctx.fillStyle = col; ctx.fillText(text, Math.round(x), Math.round(y));
  ctx.globalAlpha = 1;
}

function draw(aimXs) {
  const n = S.night, key = Math.round(n * 24);
  if (skyL.key !== key) { skyL.key = key; buildSky(n); }
  if (landL.key !== key) { landL.key = key; buildLand(n); }
  for (const c of clouds) { c.x -= c.v / 60; if (c.x < -60) c.x = W + 20; }
  ctx.save();
  if (S.shake > 0) ctx.translate(Math.round(rnd(-1, 1) * S.shake * 6), Math.round(rnd(-1, 1) * S.shake * 6));
  ctx.drawImage(skyL.c, 0, 0);
  drawSkyDynamic(n);
  ctx.drawImage(landL.c, 0, 0);
  drawCave(n); drawCastle(n);
  ctx.drawImage(boardL.c, 0, 0);
  for (const p of pegs) if (p.f > 0) { R(p.x - 1, p.y - 2, 3, 5, '#ffd23f'); R(p.x - 2, p.y - 1, 5, 3, '#ffd23f'); }
  drawMonsters();
  if (n > 0.01) { ctx.fillStyle = 'rgba(8,10,44,' + (0.26 * n).toFixed(3) + ')'; ctx.fillRect(-8, -8, W + 16, H + 16); }
  drawAim(aimXs); drawBalls();
  for (const p of S.parts) { ctx.globalAlpha = clamp(p.life / p.max * 1.5, 0, 1); R(p.x, p.y, p.size, p.size, p.col); }
  ctx.globalAlpha = 1;
  for (const f of S.floats) drawText(f.text, f.x, f.y, f.size, f.col, clamp((f.life - f.t) / 0.3, 0, 1));
  if (S.mod && S.phase === 'night') drawText(t('mod.' + S.mod), W / 2, 10, 7, '#ff9a5e', 0.9);
  if (S.banner) {
    const b = S.banner, a = Math.min(1, b.t / 0.3, (b.dur - b.t) / 0.6), v = { n: b.n };
    drawText(t(b.text, v), W / 2, 112, 16, '#ffd23f', a);
    if (b.sub) drawText(t(b.sub, v), W / 2, 134, 8, '#ffffff', a);
  }
  ctx.restore();
}
