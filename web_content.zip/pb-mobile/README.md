# Plinko Bastion: wersja mobilna (Google Play)

Gra w HTML/JS (canvas, bez frameworka) w układzie modułowym. `node build.js` składa pliki z `src/` w:

- `www/index.html`: jeden samodzielny plik dla aplikacji (czcionki wbudowane, działa offline, bez połączeń z Google Fonts),
- `dist/plinko-bastion.html`: ten sam kod do podglądu w przeglądarce.

Build sprawdza też komplet tłumaczeń (EN, PL, RU, DE) i przerywa, gdy któregoś brakuje.

## Struktura `src/`

| Plik | Zawartość |
|---|---|
| `util.js` | pomocnicze, magistrala zdarzeń, profil gracza w `localStorage` |
| `i18n.js`, `i18n/*.js` | wykrywanie języka (`navigator.languages`), słowniki, wybór w Ustawieniach |
| `config.js` | **cały balans w jednym miejscu**: ulepszenia, nagrody dzienne, koło, misje, osiągnięcia, oferty |
| `game.js` | stan walki, fizyka kulek (stały krok 1/120 s), fale, wskrzeszenie |
| `render.js` | canvas 480x300, statyczne warstwy w cache |
| `tree.js` | drzewko umiejętności za Dusze: 24 węzły, 4 gałęzie (Siła, Złoto, Twierdza, Czas), każdy wymaga poprzedniego |
| `meta.js` | nagrody dzienne, misje, osiągnięcia, koło, prestiż, zbieracz offline, realizacja zakupów |
| `services/billing.js`, `services/ads.js` | adaptery płatności i reklam (symulacja albo prawdziwe SDK) |
| `ui.js`, `ui-panels.js`, `main.js` | okna, panele, dotyk (multi-touch), pętla gry |

## Co jest prawdziwe, a co symulowane

Adaptery wybierają tryb same:

- **w przeglądarce / podglądzie**: okna testowe z oznaczeniem „TRYB TESTOWY (SYMULACJA)”. Płatność nie pobiera pieniędzy, reklama to zaślepka z odliczaniem 5 s. To są okna własne, nie kopie okien Google Play ani AdMob.
- **w aplikacji Android (Capacitor)**: `Billing` używa `cordova-plugin-purchase` (Google Play Billing), a `Ads` używa `@capacitor-community/admob`. Kod tych dwóch gałęzi jest referencyjny i **nie był uruchamiany na urządzeniu**. Trzeba go przetestować na koncie testowym Play i na prawdziwym telefonie.

## Budowa pliku AAB (bez instalowania czegokolwiek)

Plik `.aab` buduje GitHub Actions (`.github/workflows/android.yml`: Node 22, Java 21, Capacitor 8, targetSdk 36 zgodny z wymogiem Google Play).

1. Utwórz prywatne repozytorium na GitHub i wgraj cały folder projektu.
2. Zakładka **Actions → Android AAB → Run workflow**.
3. **Pierwszy bieg** tworzy klucz podpisu i dodaje artefakt `NOWY-KLUCZ-ZAPISZ-GO` (plik `upload.jks` + `secrets.txt`). Zapisz go w bezpiecznym miejscu i wklej wartości z `secrets.txt` jako **Settings → Secrets → Actions**: `KEYSTORE_B64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Kolejne buduje się już tym samym kluczem. W Play Console włącz Play App Signing (domyślne), a ten klucz jest tylko „kluczem wysyłania”.
4. Pobierz artefakt `plinko-bastion-aab` (`app-release.aab`) i wgraj w Play Console. `versionCode` rośnie sam (numer biegu).
5. Opcjonalny sekret `ADMOB_APP_ID` (twój prawdziwy ID aplikacji AdMob). Bez niego używany jest testowy ID Google.

Przed pierwszym wgraniem zmień `appId` w `capacitor.config.json` (domyślnie `com.plinkobastion.game`). Po publikacji nie da się go zmienić.

Lokalnie (jeśli wolisz): `npm install && npm run build && npx cap add android && npm run android:assets && npx cap sync android && npm run android:patch`, potem `cd android && ./gradlew bundleRelease`.

**Do zrobienia przed „na produkcji”:** w `src/services/ads.js` podmień `TEST_IDS` na własne bloki reklamowe i usuń `initializeForTesting`; dodaj zgodę UMP (RODO); podłącz weryfikację paragonów. Do tego czasu reklamy są testowe.

## Produkty w Google Play Console

Identyfikatory muszą być dokładnie takie (patrz `IAP` w `config.js`):

| SKU | Typ | Cena w kodzie |
|---|---|---|
| `gems_s`, `gems_m`, `gems_l` | zarządzany, zużywalny | 0,99 / 4,99 / 9,99 USD |
| `piggy` | zarządzany, zużywalny | 1,99 USD |
| `starter` | zarządzany, jednorazowy | 2,99 USD |
| `noads` | zarządzany, jednorazowy | 2,99 USD |

Ceny w grze są pobierane z Google Play (lokalne waluty). Wartości w `config.js` to tylko tryb symulacji.

**Przed publikacją koniecznie:** weryfikuj paragony po stronie serwera (`store.validator` w `billing.js`). Zakupy zapisane tylko w `localStorage` da się łatwo podrobić. Dotyczy to też stanu klejnotów.

## Zasady Google Play, o które łatwo się potknąć

- Reklamy przerywnikowe pokazują się tylko między podejściami (co 3. przegrana, nie częściej niż co 4 min) i można je wyłączyć zakupem `noads`. Reklamy z nagrodą są zawsze dobrowolne.
- Aplikacja nie jest skierowana do dzieci. Ustaw odpowiednią grupę wiekową w Play Console, bo inaczej obowiązują ostrzejsze zasady reklam i danych.
- Formularz „Bezpieczeństwo danych”: zadeklaruj identyfikator reklamowy i dane z AdMob oraz Play Billing.
- Polityka prywatności z publicznym adresem URL jest wymagana (reklamy + zakupy).
- Koło fortuny jest darmowe (dodatkowe obroty za reklamę), więc nie podlega zasadom losowych płatnych przedmiotów. Jeśli kiedyś dodasz losowe przedmioty za pieniądze, trzeba pokazać szanse wygranej.

## Lista kontrolna testów na telefonie

Nowy dzień (zmień datę w systemie): nagroda dzienna i misje się odnawiają, seria przerwana po pominiętym dniu · zakup, anulowanie i błąd płatności · przywracanie zakupów (`noads`, `starter`) · reklama z nagrodą zamknięta przed końcem (brak nagrody) · tryb samolotowy · obrót ekranu w trakcie fali · wycięcie ekranu i pasek gestów · zabicie aplikacji w trakcie nocy (wraca do początku dnia z zapisanego stanu).

## Strojenie balansu

Wszystko w `src/config.js`: `UPS` (ceny i poziomy ulepszeń), `buildWave` i `hpMul` (trudność), `DAILY`, `SPIN_SEGS`, `QUEST_POOL`, `ACHS`, `RESPEC_GEMS` (cena resetu drzewka), `ASCEND_MIN_WAVE`, `piggyCap`.

## Trudność i drzewko dusz

- HP potworów rośnie wykładniczo (`hpMul` w `config.js`), od fali 6 noce dostają losowe modyfikatory (Rój, Żelazna Horda, Szał, Noc Skarbów), a co 5. fala jest bossem (Zjawa, Golem, Lisz). Nowi wrogowie: nietoperze (latają, stadami), rycerze (pancerz), szamani (leczą), lisz (przyzywa).
- Prestiż (Wniebowstąpienie od fali 10) daje Dusze, które **wydaje się** w drzewku (zakładka „Wniebow."). Dusze nie resetują się nigdy. Reset drzewka kosztuje 40 klejnotów i zwraca wszystkie wydane Dusze.
- Balans stroisz w `config.js` (`hpMul`, `forgeDmg`, `coinScale`, `UPS`) i `tree.js` (koszty `cost`, efekty `a`/`b`). Symulacja botem: `window.__PB_TEST` udostępnia `update`, `startNight`, `buySkill` itd.
