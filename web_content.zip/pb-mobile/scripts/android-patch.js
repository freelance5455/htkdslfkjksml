// Uruchamiany po `npx cap add android` / `cap sync`. Dodaje: uprawnienie Billing, ID aplikacji AdMob, wersję i podpis wydania.
// Zmienne środowiskowe: ADMOB_APP_ID, VERSION_CODE, VERSION_NAME, KEYSTORE_PATH, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..', 'android');
const fail = (m) => { console.error('PATCH BŁĄD:', m); process.exit(1); };
const E = process.env;

// 1) AndroidManifest
const mf = path.join(root, 'app/src/main/AndroidManifest.xml');
let x = fs.readFileSync(mf, 'utf8');
const admob = E.ADMOB_APP_ID || 'ca-app-pub-3940256099942544~3347511713';      // domyślnie testowy ID Google
if (!x.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  if (!x.includes('</application>')) fail('brak </application> w manifeście');
  x = x.replace('</application>', '    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="' + admob + '"/>\n    </application>');
}
for (const perm of ['com.android.vending.BILLING', 'android.permission.INTERNET', 'com.google.android.gms.permission.AD_ID']) {
  if (!x.includes(perm)) x = x.replace('</manifest>', '    <uses-permission android:name="' + perm + '"/>\n</manifest>');
}
fs.writeFileSync(mf, x);

// 2) app/build.gradle: wersja + podpis
const gf = path.join(root, 'app/build.gradle');
let g = fs.readFileSync(gf, 'utf8');
if (!/versionCode\s*=?\s*\d+/.test(g) || !/versionName\s*=?\s*"[^"]*"/.test(g)) fail('nie znaleziono versionCode/versionName w app/build.gradle');
g = g.replace(/versionCode\s*=?\s*\d+/, 'versionCode ' + (E.VERSION_CODE || 1)).replace(/versionName\s*=?\s*"[^"]*"/, 'versionName "' + (E.VERSION_NAME || '1.0.0') + '"');
if (E.KEYSTORE_PATH && !g.includes('signingConfigs.release')) {
  const sc = '    signingConfigs {\n        release {\n            storeFile file("' + E.KEYSTORE_PATH.replace(/\\/g, '/') + '")\n            storePassword System.getenv("KEYSTORE_PASSWORD")\n            keyAlias System.getenv("KEY_ALIAS")\n            keyPassword System.getenv("KEY_PASSWORD")\n        }\n    }\n';
  if (!/\n\s*buildTypes\s*\{/.test(g)) fail('brak bloku buildTypes');
  g = g.replace(/\n(\s*)buildTypes\s*\{/, '\n' + sc + '    buildTypes {');
  if (!/release\s*\{/.test(g.slice(g.indexOf('buildTypes')))) fail('brak bloku release');
  g = g.replace(/(buildTypes\s*\{[\s\S]*?release\s*\{)/, '$1\n            signingConfig signingConfigs.release');
}
fs.writeFileSync(gf, g);
console.log('OK: manifest + gradle zaktualizowane (versionCode', E.VERSION_CODE || 1, ')');
