// Składa src/* w jeden plik dist/plinko-bastion.html i sprawdza komplet tłumaczeń.
const fs = require('fs'), path = require('path');
const R = (f) => fs.readFileSync(path.join(__dirname, 'src', f), 'utf8');
const JS = ['util.js','i18n.js','i18n/en.js','i18n/pl.js','i18n/ru.js','i18n/de.js','config.js','tree.js','game.js','render.js',
  'services/billing.js','services/ads.js','meta.js','ui.js','ui-panels.js','main.js'];
const js = JS.map((f) => '/* ==== ' + f + ' ==== */\n' + R(f)).join('\n');
// kontrola kluczy i18n: każdy klucz użyty w kodzie musi istnieć w 4 językach
const used = new Set();
for (const m of (js + R('index.template.html')).matchAll(/\bt\(\s*['"`]([\w.]+)['"`]|data-i18n(?:-[a-z]+)?="([\w.]+)"/g)) used.add(m[1] || m[2]);
const langs = {};
for (const l of ['en','pl','ru','de']) {
  const o = {}; new Function('LANGS', R('i18n/' + l + '.js'))(o); langs[l] = o[l] || {};
}
let bad = 0;
for (const l in langs) for (const k of Object.keys(langs.en)) if (!(k in langs[l])) { console.error('BRAK', l, k); bad++; }
for (const k of used) if (!(k in langs.en) && !/\.$/.test(k)) { console.error('NIEZNANY KLUCZ', k); bad++; }
if (bad) { console.error(bad + ' problemów i18n'); if (!process.argv.includes('--force')) process.exit(1); }
const out = R('index.template.html').replace('/*@CSS*/', () => R('styles.css')).replace('/*@JS*/', () => js);
fs.writeFileSync(path.join(__dirname, 'dist/plinko-bastion.html'), out);
console.log('OK dist/plinko-bastion.html', (out.length / 1024).toFixed(0) + ' KB, klucze:', Object.keys(langs.en).length);

/* ---------- wersja do aplikacji (Capacitor): pełny dokument, czcionki wbudowane, działa offline ---------- */
const RANGES = {
  'latin': 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD',
  'latin-ext': 'U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF',
  'cyrillic': 'U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116'
};
let fontCss = '';
for (const [fam, slug, weights] of [['VT323', 'vt323', [400]], ['Pixelify Sans', 'pixelify-sans', [400]], ['Press Start 2P', 'press-start-2p', [400]]]) {
  for (const sub of Object.keys(RANGES)) for (const w of weights) {
    const fp = path.join(__dirname, 'fonts', slug + '-' + sub + '-' + w + '-normal.woff2');
    if (!fs.existsSync(fp)) continue;
    fontCss += '@font-face{font-family:"' + fam + '";font-style:normal;font-weight:' + w + ';font-display:swap;' + (fam === 'Pixelify Sans' ? 'size-adjust:82%;' : '') + 'src:url(data:font/woff2;base64,' +
      fs.readFileSync(fp).toString('base64') + ') format("woff2");unicode-range:' + RANGES[sub] + '}\n';
  }
}
const tpl = R('index.template.html')
  .replace(/<meta name="claude:viewport-fit-sides"[^>]*>\n?/, '')
  .replace(/<link [^>]*>\n/g, '');
const cut = tpl.indexOf('<div id="app">');
const headPart = tpl.slice(0, cut).replace('/*@CSS*/', () => fontCss + R('styles.css'));
const bodyPart = tpl.slice(cut).replace('/*@JS*/', () => js);
const full = '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n' +
  '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">\n' +
  '<meta name="theme-color" content="#0b0f2e">\n<meta name="mobile-web-app-capable" content="yes">\n' +
  headPart + '\n</head>\n<body>\n' + bodyPart + '\n</body>\n</html>\n';
fs.writeFileSync(path.join(__dirname, 'www/index.html'), full);
console.log('OK www/index.html', (full.length / 1024).toFixed(0) + ' KB (czcionki wbudowane)');
