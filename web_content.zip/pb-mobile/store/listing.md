# Wpis w Google Play (kopiuj-wklej)

**Kategoria:** Gry > Strategia (lub Zręcznościowe) · **Typ:** Gra · **Darmowa**, z reklamami i zakupami w aplikacji
**Grupa wiekowa / IARC:** kwestionariusz → przemoc fantasy (kreskówkowa, pixel art), brak hazardu za prawdziwe pieniądze, brak treści dla dorosłych → zwykle PEGI 7 / Everyone 10+. **Odpowiedz zgodnie z prawdą w formularzu.**
**Docelowa grupa odbiorców:** 13+ (NIE zaznaczaj dzieci, inaczej obowiązują ostrzejsze zasady reklam).

## EN (domyślny)
**Nazwa (max 30):** Plinko Bastion: Tower Defense
**Krótki opis (max 80):** Drop balls through a peg maze to smash monsters and defend your castle!
**Pełny opis:**
Night falls and monsters march on your castle. Your weapon? Balls dropped into a giant Plinko peg field!

★ Tap to drop balls – every bounce can hit a monster
★ Brutal night waves: bats, armored knights, healing shamans, bosses and special wave modifiers
★ Forge upgrades: damage, fire rate, multi-ball, piercing, slow, crits, gold and castle walls
★ Soul Tree: ascend to earn Souls and unlock 24 permanent skills in four branches
★ Daily rewards, missions, achievements and a free daily wheel
★ Pixel-art style, plays in portrait and landscape, works offline

How far can you hold the line?

## PL
**Nazwa:** Plinko Bastion: Obrona Zamku
**Krótki:** Zrzucaj kule przez las kołków, rozbijaj potwory i obroń swój zamek!
**Pełny:**
Zapada noc, a potwory idą na Twój zamek. Twoja broń? Kule zrzucane w gigantyczną planszę Plinko!

★ Dotknij, by zrzucić kule – każde odbicie może trafić potwora
★ Brutalne nocne fale: nietoperze, opancerzeni rycerze, szamani leczący wrogów, bossowie i specjalne modyfikatory fal
★ Kuźnia: obrażenia, szybkostrzelność, wiele kul, przebicie, spowolnienie, krytyki, złoto i mury
★ Drzewko dusz: wniebowstąp, zdobądź Dusze i odblokuj 24 stałe umiejętności w czterech gałęziach
★ Nagrody dzienne, misje, osiągnięcia i darmowe koło fortuny
★ Styl pixel art, tryb pionowy i poziomy, działa offline

Jak długo utrzymasz linię obrony?

## RU
**Название:** Plinko Bastion: Защита замка
**Кратко:** Бросай шары сквозь лес колышков, круши монстров и защити замок!
**Полно:**
Наступает ночь, и монстры идут на твой замок. Твоё оружие — шары, падающие в огромное поле Plinko!

★ Касайся экрана, чтобы бросать шары — каждый отскок может попасть по монстру
★ Жестокие ночные волны: летучие мыши, рыцари в броне, шаманы-целители, боссы и особые модификаторы волн
★ Кузница: урон, скорострельность, мультишар, пробивание, замедление, криты, золото и стены
★ Древо душ: вознесись, получи души и открой 24 постоянных навыка в четырёх ветках
★ Ежедневные награды, задания, достижения и бесплатное колесо
★ Пиксель-арт, портретный и альбомный режим, работает офлайн

Как долго ты продержишься?

## DE
**Name:** Plinko Bastion: Burgverteidigung
**Kurz:** Lass Kugeln durch den Stiftwald fallen, zerschmettere Monster und rette die Burg!
**Lang:**
Die Nacht bricht an und Monster marschieren auf deine Burg. Deine Waffe? Kugeln im riesigen Plinko-Feld!

★ Tippen, um Kugeln fallen zu lassen – jeder Abpraller kann ein Monster treffen
★ Brutale Nachtwellen: Fledermäuse, gepanzerte Ritter, heilende Schamanen, Bosse und Wellen-Modifikatoren
★ Schmiede: Schaden, Feuerrate, Multi-Kugel, Durchschlag, Verlangsamung, Krits, Gold und Mauern
★ Seelenbaum: Steige auf, sammle Seelen und schalte 24 dauerhafte Fähigkeiten in vier Zweigen frei
★ Tägliche Belohnungen, Missionen, Erfolge und ein kostenloses Glücksrad
★ Pixel-Art, Hoch- und Querformat, funktioniert offline

Wie lange hältst du die Linie?

## Formularz „Bezpieczeństwo danych” (Data safety)
- Zbierane dane: **Identyfikatory urządzenia lub inne** (reklamowy ID) – zbierane/udostępniane przez AdMob, cel: reklamy i analityka; **Informacje o zakupach** – obsługuje Google Play.
- Dane szyfrowane w tranzycie: tak. Można poprosić o usunięcie: dane są tylko lokalne (podaj to).
- Reklamy: **Tak, aplikacja zawiera reklamy.** Deklaracja identyfikatora reklamowego: **Tak** (reklamy).
- Polityka prywatności: wgraj `store/privacy-policy.html` np. na GitHub Pages i wklej adres URL.

## Zasoby graficzne
`store/icon-512.png` (ikona 512×512) · `store/feature-graphic-1024x500.png` · `store/screenshots/*.png` (1080×1920).

## Produkty w aplikacji (Monetyzacja > Produkty w aplikacji)
Identyfikatory dokładnie: `gems_s` `gems_m` `gems_l` `piggy` (zużywalne) · `starter` `noads` (jednorazowe). Ceny: 0,99 / 4,99 / 9,99 / 1,99 / 2,99 / 2,99 USD.
