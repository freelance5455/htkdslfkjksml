WarZone 3D — Android APK project

Це Android-проєкт-обгортка для вашої HTML-гри. Він відкриває гру у WebView,
в горизонтальному режимі та на весь екран.

ВАЖЛИВО:
- Гра використовує Three.js із CDN (інтернет потрібен для завантаження бібліотеки).
- Це вихідний проєкт, а не готовий APK.
- Для збирання APK потрібен Android Studio/Android SDK та Gradle.

Як зібрати:
1. Розпакуйте ZIP.
2. Відкрийте папку WarZone3D_APK_Project в Android Studio.
3. Дочекайтеся Gradle Sync.
4. В меню Build виберіть Build Bundle(s) / APK(s) -> Build APK(s).
5. APK буде створено в app/build/outputs/apk/debug/.

На телефоні:
- Найпростіше зібрати цей проєкт на комп'ютері з Android Studio.
- Сам ZIP не встановлюється як додаток. Потрібно спочатку зібрати APK.
