package com.artracker.typing

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import android.widget.Button
import android.widget.Switch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val db by lazy { TypingDb(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.dashboard)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler(
                "/assets/",
                WebViewAssetLoader.AssetsPathHandler(this)
            )
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false

        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }

        web.addJavascriptInterface(object {

            @android.webkit.JavascriptInterface
            fun getData(): String {
                return db.all().reversed().joinToString("\n") {
                    "${it.time}\t${it.app}\t${it.text.replace("\n", "↵")}"
                }
            }

            @android.webkit.JavascriptInterface
            fun exportTxt(): String {
                return db.all().reversed().joinToString("\n") {
                    val t = SimpleDateFormat(
                        "yyyy-MM-dd HH:mm:ss",
                        Locale.getDefault()
                    ).format(Date(it.time))
                    "$t | ${it.app} | ${it.text.replace("\n", "↵")}"
                }
            }

            @android.webkit.JavascriptInterface
            fun clearHistory() {
                db.clear()
            }

        }, "AndroidTracker")

        findViewById<Button>(R.id.enableKeyboard).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        val sw = findViewById<Switch>(R.id.recordSwitch)
        sw.isChecked = Prefs.isRecording(this)
        sw.setOnCheckedChangeListener { _, checked ->
            Prefs.setRecording(this, checked)
        }

        web.loadUrl(
            "https://appassets.androidplatform.net/assets/dashboard.html"
        )
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) {
            web.evaluateJavascript(
                "if(window.refresh){window.refresh();}",
                null
            )
        }
    }
}
