package com.artracker.typing

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues

data class TypingEvent(
    val time: Long,
    val app: String,
    val text: String
)

class TypingDb(context: Context) :
    SQLiteOpenHelper(context, "typing_history.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE events(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_time INTEGER NOT NULL,
                app_package TEXT NOT NULL,
                typed_text TEXT NOT NULL
            )
        """)
        db.execSQL("CREATE INDEX idx_event_time ON events(event_time)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(event: TypingEvent) {
        val values = ContentValues().apply {
            put("event_time", event.time)
            put("app_package", event.app)
            put("typed_text", event.text)
        }
        writableDatabase.insert("events", null, values)
    }

    fun all(): List<TypingEvent> {
        val result = mutableListOf<TypingEvent>()
        readableDatabase.rawQuery(
            "SELECT event_time, app_package, typed_text FROM events ORDER BY event_time DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                result += TypingEvent(c.getLong(0), c.getString(1), c.getString(2))
            }
        }
        return result
    }

    fun clear() {
        writableDatabase.delete("events", null, null)
    }
}
