package com.artracker.typing

import android.content.Context

object Prefs {
    private const val FILE = "settings"
    private const val RECORD = "record"

    fun isRecording(context: Context): Boolean =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(RECORD, true)

    fun setRecording(context: Context, enabled: Boolean) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(RECORD, enabled).apply()
    }
}
