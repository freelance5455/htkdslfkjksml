package com.artracker.typing

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.util.TypedValue

class TypingImeService : InputMethodService() {

    private var recordingAllowed = false
    private var currentApp = "unknown"
    private val db by lazy { TypingDb(this) }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        currentApp = attribute?.packageName ?: "unknown"

        // Do not record password/sensitive fields.
        val inputType = attribute?.inputType ?: 0
        val variation = inputType and android.text.InputType.TYPE_MASK_VARIATION
        val isPassword =
            variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD

        recordingAllowed = Prefs.isRecording(this) && !isPassword
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setBackgroundColor(Color.rgb(238, 238, 238))
        }

        val info = TextView(this).apply {
            text = "Typing Productivity Keyboard"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        root.addView(info, LinearLayout.LayoutParams(-1, dp(28)))

        val rows = listOf(
            listOf("Q","W","E","R","T","Y","U","I","O","P"),
            listOf("A","S","D","F","G","H","J","K","L"),
            listOf("Z","X","C","V","B","N","M","⌫"),
            listOf("123","SPACE","ENTER")
        )

        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            row.forEach { label ->
                val b = Button(this).apply {
                    text = label
                    textSize = if (label == "SPACE") 12f else 14f
                    setAllCaps(false)
                    background = GradientDrawable().apply {
                        setColor(Color.WHITE)
                        cornerRadius = dp(6).toFloat()
                    }
                    setOnClickListener { press(label) }
                }
                val weight = when (label) {
                    "SPACE" -> 4f
                    "ENTER" -> 1.5f
                    "123" -> 1.2f
                    else -> 1f
                }
                line.addView(b, LinearLayout.LayoutParams(0, dp(48), weight).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            root.addView(line, LinearLayout.LayoutParams(-1, dp(52)))
        }
        return root
    }

    private fun press(key: String) {
        val ic: InputConnection = currentInputConnection ?: return
        when (key) {
            "⌫" -> {
                ic.deleteSurroundingText(1, 0)
                log("⌫")
            }
            "SPACE" -> {
                ic.commitText(" ", 1)
                log(" ")
            }
            "ENTER" -> {
                ic.sendKeyEvent(android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_DOWN,
                    android.view.KeyEvent.KEYCODE_ENTER
                ))
                ic.sendKeyEvent(android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_UP,
                    android.view.KeyEvent.KEYCODE_ENTER
                ))
                log("\n")
            }
            "123" -> {
                // Kept as a placeholder; add a numeric layout if desired.
            }
            else -> {
                ic.commitText(key.lowercase(), 1)
                log(key.lowercase())
            }
        }
    }

    private fun log(text: String) {
        if (!recordingAllowed || text.isEmpty()) return
        Thread {
            db.insert(TypingEvent(System.currentTimeMillis(), currentApp, text))
        }.start()
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
}
