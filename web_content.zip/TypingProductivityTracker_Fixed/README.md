# Typing Productivity Tracker

A consent-based Android custom keyboard/IME for personal typing productivity.

## What it does

- Provides a basic QWERTY custom keyboard.
- Records text entered through this keyboard when recording is enabled.
- Stores timestamp and the target application package exposed by Android.
- Does not record password/sensitive input fields.
- Stores history locally in SQLite.
- Provides a WebView dashboard.
- Exports TXT and CSV from the dashboard.
- No network permission is requested.

## Build

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build and install on an Android device.
4. Open the app.
5. Tap "Enable / Select Keyboard".
6. Enable "Typing Productivity Keyboard" in Android keyboard settings.
7. Select it as the current keyboard.
8. Return to the app and leave "Record typing history" enabled if desired.

## Important Android behavior

This is an Input Method Service, not a hidden keylogger. Android requires the user to explicitly enable/select the keyboard. Password fields are excluded based on EditorInfo input-type flags.

The sample keyboard is intentionally simple. It demonstrates the recording architecture and dashboard; production keyboards should add proper language layouts, IME actions, accessibility labels, autocorrect, suggestions, numeric/symbol pages, and robust lifecycle handling.
