ELYSIUM CELL KASIR — PROYEK ANDROID AWAL

Isi:
- Aplikasi Android WebView dengan tampilan kasir demo.
- HTML berada di app/src/main/assets/index.html.
- Data demo disimpan oleh browser WebView pada perangkat melalui localStorage.

CARA MEMBANGUN APK DARI HP ANDROID:
1. Unduh dan ekstrak ZIP ini di HP.
2. Pasang AndroidIDE dari sumber resminya jika tersedia untuk perangkat Anda.
3. Buka AndroidIDE dan pilih Open Project / Import Project.
4. Pilih folder ELYSIUM_CELL_Android hasil ekstrak (folder yang berisi settings.gradle).
5. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35 dan Build Tools yang sesuai.
6. Pilih Build > Assemble Debug APK (nama menu bisa berbeda menurut versi).
7. Cari APK debug di app/build/outputs/apk/debug/app-debug.apk.
8. Buka file APK itu dan izinkan pemasangan dari sumber tersebut jika Android meminta.

CATATAN:
- ZIP ini adalah KODE SUMBER PROYEK, bukan APK yang sudah dikompilasi.
- Build pertama perlu internet untuk mengunduh Gradle/plugin dan Android SDK.
- Setelah APK terpasang, antarmuka kasir bisa dibuka tanpa internet.
- Ini masih prototipe pembukuan. Belum terhubung ke sistem BRILink, bank, EDC, PPOB, QRIS, atau printer Bluetooth.
- Saldo awal yang tampil adalah data contoh berdasarkan screenshot. Ubah saldo contoh sebelum dipakai.
- Jangan gunakan sebagai pencatatan keuangan resmi sebelum rumus transaksi diuji dan fitur pencadangan dibuat.
