package ir.parsamehr.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * پل HTML ↔ اندروید. در صفحه با window.PMNative در دسترس است.
 * همهٔ متدها رشته برمی‌گردانند: "ok" یا "ok:مسیر" در صورت موفقیت، و "err:علت" در صورت خطا.
 * (صفحهٔ HTML فقط به پیشوند "ok" نگاه می‌کند.)
 */
public class PMNative {
    private final Activity act;

    PMNative(Activity activity) {
        this.act = activity;
    }

    /* ------------------------------------------------------------------ */
    /* اشتراک‌گذاری                                                        */
    /* ------------------------------------------------------------------ */

    /** اشتراک یک فایل (PDF، تصویر، پشتیبان و ...) از طریق Intent.ACTION_SEND */
    @JavascriptInterface
    public String shareFile(String b64, String name, String mime, String title) {
        try {
            File f = toCache(b64, name);
            List<File> one = new ArrayList<>();
            one.add(f);
            String m = mimeOf(mime, f.getName());
            sendFiles(one, m, title);
            return "ok";
        } catch (Throwable e) {
            return err(e);
        }
    }

    /** سازگاری با نسخه‌های قدیمی صفحه */
    @JavascriptInterface
    public String shareImage(String b64, String name, String mime) {
        return shareFile(b64, name, (mime == null || mime.isEmpty()) ? "image/png" : mime, name);
    }

    /** اشتراک چند فایل؛ json = [{"b64":"..","name":"..","mime":".."}, ...] */
    @JavascriptInterface
    public String shareFiles(String json, String title) {
        try {
            JSONArray arr = new JSONArray(json);
            if (arr.length() == 0) return "err:empty";
            File dir = newBatchDir();
            List<File> files = new ArrayList<>();
            List<String> mimes = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                File f = writeTo(dir, o.optString("name", "file" + i), decode(o.getString("b64")));
                files.add(f);
                mimes.add(mimeOf(o.optString("mime", ""), f.getName()));
            }
            sendFiles(files, commonMime(mimes), title);
            return "ok";
        } catch (Throwable e) {
            return err(e);
        }
    }

    /** اشتراک متن ساده (تلگرام، واتساپ، پیامک ...) */
    @JavascriptInterface
    public String shareText(String text, String title) {
        try {
            final Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
            if (title != null && !title.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, title);
            final Intent chooser = Intent.createChooser(i, "ارسال به…");
            act.runOnUiThread(() -> startSafely(chooser));
            return "ok";
        } catch (Throwable e) {
            return err(e);
        }
    }

    /* ------------------------------------------------------------------ */
    /* ذخیره                                                               */
    /* ------------------------------------------------------------------ */

    /** ذخیرهٔ تصویر در گالری (Pictures/ParsaMehr) */
    @JavascriptInterface
    public String saveImage(String b64, String name, String mime) {
        try {
            String m = mimeOf(mime, name);
            boolean image = m.startsWith("image/");
            return "ok:" + store(decode(b64), name, m, image);
        } catch (Throwable e) {
            return err(e);
        }
    }

    /** ذخیرهٔ فایل (PDF، پشتیبان و ...) در Download/ParsaMehr */
    @JavascriptInterface
    public String saveFile(String b64, String name, String mime) {
        try {
            String m = mimeOf(mime, name);
            return "ok:" + store(decode(b64), name, m, false);
        } catch (Throwable e) {
            return err(e);
        }
    }

    /* ------------------------------------------------------------------ */
    /* باز کردن / کپی / چاپ                                                */
    /* ------------------------------------------------------------------ */

    /** باز کردن فایل با برنامهٔ مناسب (مثلاً .ics در تقویم). اگر برنامه‌ای نبود در Downloads ذخیره می‌شود. */
    @JavascriptInterface
    public String openFile(String b64, String name, String mime) {
        try {
            final byte[] data = decode(b64);
            final File f = writeTo(newBatchDir(), name, data);
            final String m = mimeOf(mime, f.getName());
            final String nm = name;
            act.runOnUiThread(() -> {
                try {
                    Uri u = uriFor(f);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(u, m);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(i);
                } catch (ActivityNotFoundException ex) {
                    try {
                        String p = store(data, nm, m, false);
                        toast("برنامه‌ای برای باز کردن نبود؛ فایل ذخیره شد: " + p);
                    } catch (Throwable e2) {
                        toast("باز کردن فایل ممکن نشد");
                    }
                } catch (Throwable ex) {
                    toast("باز کردن فایل ممکن نشد");
                }
            });
            return "ok";
        } catch (Throwable e) {
            return err(e);
        }
    }

    /** کپی تصویر در کلیپ‌بورد (برای Paste در پیام‌رسان‌ها) */
    @JavascriptInterface
    public String copyImage(String b64, String name, String mime) {
        try {
            final File f = toCache(b64, name);
            final Uri u = uriFor(f);
            act.runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newUri(act.getContentResolver(), "image", u));
                    if (Build.VERSION.SDK_INT < 33) toast("تصویر کپی شد");
                } catch (Throwable e) {
                    toast("کپی تصویر ممکن نشد");
                }
            });
            return "ok";
        } catch (Throwable e) {
            return err(e);
        }
    }

    /** چاپ / ذخیره به‌صورت PDF با سرویس چاپ اندروید */
    @JavascriptInterface
    public String printPdf(String b64, String name) {
        try {
            final byte[] data = decode(b64);
            final String doc = clean(name);
            act.runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                    pm.print(doc, new PdfAdapter(doc, data), null);
                } catch (Throwable e) {
                    toast("چاپ ممکن نشد");
                }
            });
            return "ok";
        } catch (Throwable e) {
            return err(e);
        }
    }

    /** برای تشخیص نسخهٔ پل از سمت HTML */
    @JavascriptInterface
    public String version() {
        return "ok:PMNative-1";
    }

    /* ------------------------------------------------------------------ */
    /* ابزارهای داخلی                                                      */
    /* ------------------------------------------------------------------ */

    private void sendFiles(List<File> files, String mime, String title) {
        final Intent i;
        if (files.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            Uri u = uriFor(files.get(0));
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.setClipData(ClipData.newRawUri(files.get(0).getName(), u));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            ArrayList<Uri> uris = new ArrayList<>();
            ClipData clip = null;
            for (File f : files) {
                Uri u = uriFor(f);
                uris.add(u);
                if (clip == null) clip = ClipData.newRawUri(f.getName(), u);
                else clip.addItem(new ClipData.Item(u));
            }
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            i.setClipData(clip);
        }
        i.setType(mime);
        if (title != null && !title.isEmpty()) i.putExtra(Intent.EXTRA_SUBJECT, title);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        final Intent chooser = Intent.createChooser(i, "ارسال به…");
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        act.runOnUiThread(() -> startSafely(chooser));
    }

    private void startSafely(Intent i) {
        try {
            act.startActivity(i);
        } catch (Throwable e) {
            toast("برنامه‌ای برای ارسال پیدا نشد");
        }
    }

    private void toast(String m) {
        Toast.makeText(act, m, Toast.LENGTH_LONG).show();
    }

    private static String err(Throwable e) {
        String m = e.getMessage();
        return "err:" + e.getClass().getSimpleName() + (m == null ? "" : " " + m);
    }

    private static byte[] decode(String b64) {
        if (b64 == null) b64 = "";
        int c = b64.indexOf(',');
        if (b64.startsWith("data:") && c > 0) b64 = b64.substring(c + 1);
        return Base64.decode(b64, Base64.DEFAULT);
    }

    private static String clean(String n) {
        if (n == null) n = "";
        n = n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (n.isEmpty()) n = "file";
        if (n.length() > 120) n = n.substring(n.length() - 120);
        return n;
    }

    private static String mimeOf(String mime, String name) {
        if (mime != null && mime.contains("/")) return mime;
        if (name != null) {
            int d = name.lastIndexOf('.');
            if (d >= 0 && d < name.length() - 1) {
                String ext = name.substring(d + 1).toLowerCase(Locale.ROOT);
                String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                if (m != null) return m;
                if (ext.equals("ics")) return "text/calendar";
            }
        }
        return "application/octet-stream";
    }

    private static String commonMime(List<String> mimes) {
        String first = mimes.get(0);
        boolean same = true, sameType = true;
        String type = first.contains("/") ? first.substring(0, first.indexOf('/')) : first;
        for (String m : mimes) {
            if (!m.equals(first)) same = false;
            String t = m.contains("/") ? m.substring(0, m.indexOf('/')) : m;
            if (!t.equals(type)) sameType = false;
        }
        if (same) return first;
        if (sameType) return type + "/*";
        return "*/*";
    }

    private Uri uriFor(File f) {
        return FileProvider.getUriForFile(act, act.getPackageName() + ".fileprovider", f);
    }

    private File newBatchDir() throws IOException {
        File root = new File(act.getCacheDir(), "shared");
        if (!root.exists() && !root.mkdirs()) throw new IOException("cache dir");
        purge(root);
        File d = new File(root, String.valueOf(System.nanoTime()));
        if (!d.mkdirs()) throw new IOException("batch dir");
        return d;
    }

    private static void purge(File root) {
        File[] kids = root.listFiles();
        if (kids == null) return;
        long limit = System.currentTimeMillis() - 24L * 3600L * 1000L;
        for (File k : kids) {
            if (k.lastModified() < limit) deleteRec(k);
        }
    }

    private static void deleteRec(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private File toCache(String b64, String name) throws IOException {
        return writeTo(newBatchDir(), name, decode(b64));
    }

    private static File writeTo(File dir, String name, byte[] data) throws IOException {
        File f = new File(dir, clean(name));
        try (FileOutputStream os = new FileOutputStream(f)) {
            os.write(data);
        }
        return f;
    }

    private static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
        return new File(dir, base + "_" + System.currentTimeMillis() + ext);
    }

    /** ذخیره در Pictures/ParsaMehr یا Download/ParsaMehr؛ مسیر نمایشی را برمی‌گرداند */
    private String store(byte[] data, String name, String mime, boolean image) throws IOException {
        name = clean(name);
        String top = image ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = act.getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, top + "/ParsaMehr");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri col = image
                    ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            Uri u = cr.insert(col, cv);
            if (u == null) throw new IOException("MediaStore insert failed");
            try (OutputStream os = cr.openOutputStream(u)) {
                if (os == null) throw new IOException("openOutputStream failed");
                os.write(data);
            } catch (IOException e) {
                cr.delete(u, null, null);
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, done, null, null);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(top), "ParsaMehr");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("mkdir failed (storage permission?)");
            File f = unique(dir, name);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
            }
            MediaScannerConnection.scanFile(act, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
            name = f.getName();
        }
        return top + "/ParsaMehr/" + name;
    }

    /** آداپتر چاپ برای PDF آماده */
    private static class PdfAdapter extends PrintDocumentAdapter {
        private final String name;
        private final byte[] data;

        PdfAdapter(String name, byte[] data) {
            this.name = name;
            this.data = data;
        }

        @Override
        public void onLayout(PrintAttributes oldA, PrintAttributes newA, CancellationSignal cs,
                             LayoutResultCallback cb, Bundle extras) {
            if (cs.isCanceled()) {
                cb.onLayoutCancelled();
                return;
            }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build();
            cb.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal cs,
                            WriteResultCallback cb) {
            try (FileOutputStream os = new FileOutputStream(dest.getFileDescriptor())) {
                os.write(data);
                cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Throwable e) {
                cb.onWriteFailed(e.getMessage());
            }
        }
    }
}
