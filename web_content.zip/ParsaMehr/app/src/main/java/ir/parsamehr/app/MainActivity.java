package ir.parsamehr.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.AlertDialog;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {

    /** صفحه از طریق آدرس امن https داخل برنامه بارگذاری می‌شود (برای دوربین، کلیپ‌بورد و localStorage پایدار) */
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/assets/www/index.html";

    private static final int REQ_FILE = 11;
    private static final int REQ_CAMERA = 12;
    private static final int REQ_STORAGE = 13;

    private WebView web;
    private ValueCallback<Uri[]> filePathCb;
    private Uri cameraUri;
    private Runnable afterCamera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setSupportMultipleWindows(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.addJavascriptInterface(new PMNative(this), "PMNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                String sch = u.getScheme() == null ? "" : u.getScheme();
                if (sch.equals("blob") || sch.equals("data") || sch.equals("javascript")) return true;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "برنامه‌ای برای باز کردن این لینک نیست", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("باشه", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("بله", (d, w) -> r.confirm())
                        .setNegativeButton("خیر", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            /** دوربین برای getUserMedia (اسکن بارکد) */
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsVideo = false;
                    for (String res : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) wantsVideo = true;
                    }
                    if (!wantsVideo) {
                        request.deny();
                        return;
                    }
                    ensureCamera(() -> {
                        if (hasCamera()) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                        else request.deny();
                    });
                });
            }

            /** انتخاب فایل / عکس از دوربین برای <input type=file> */
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, final FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                if (p.isCaptureEnabled()) {
                    ensureCamera(() -> launchChooser(p));
                } else {
                    launchChooser(p);
                }
                return true;
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                return super.onConsoleMessage(m);
            }
        });

        // دانلود از data: URL (برای وقتی که صفحه پل را نداشته باشد)
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                if (url != null && url.startsWith("data:")) {
                    int c = url.indexOf(',');
                    String head = url.substring(5, c);
                    String body = url.substring(c + 1);
                    String m = head.contains(";") ? head.substring(0, head.indexOf(';')) : head;
                    if (m.isEmpty()) m = mime == null ? "application/octet-stream" : mime;
                    String name = android.webkit.URLUtil.guessFileName(url, cd, m);
                    String b64 = head.contains("base64") ? body : Base64.encodeToString(Uri.decode(body).getBytes("UTF-8"), Base64.NO_WRAP);
                    String r = new PMNative(this).saveFile(b64, name, m);
                    Toast.makeText(this, r.startsWith("ok") ? "ذخیره شد: " + r.substring(3) : "ذخیره ممکن نشد", Toast.LENGTH_LONG).show();
                } else {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                }
            } catch (Throwable e) {
                Toast.makeText(this, "دانلود ممکن نشد", Toast.LENGTH_SHORT).show();
            }
        });

        // اندروید ۹ و پایین‌تر: مجوز ذخیره در Downloads / Pictures
        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(HOME);
    }

    /* ---------------- دوربین و فایل ---------------- */

    private boolean hasCamera() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureCamera(Runnable next) {
        if (hasCamera()) {
            next.run();
            return;
        }
        afterCamera = next;
        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_CAMERA) {
            Runnable r = afterCamera;
            afterCamera = null;
            if (r != null) r.run();
        }
    }

    private void launchChooser(WebView.FileChooserParams p) {
        try {
            Intent cam = null;
            if (hasCamera()) {
                File dir = new File(getCacheDir(), "photos");
                if (!dir.exists()) dir.mkdirs();
                File f = File.createTempFile("cam_", ".jpg", dir);
                cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
                cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                cam.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            }
            Intent send;
            if (p.isCaptureEnabled() && cam != null) {
                send = cam;
            } else {
                Intent content = p.createIntent();
                send = new Intent(Intent.ACTION_CHOOSER);
                send.putExtra(Intent.EXTRA_INTENT, content);
                send.putExtra(Intent.EXTRA_TITLE, "انتخاب فایل");
                if (cam != null) send.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
            }
            startActivityForResult(send, REQ_FILE);
        } catch (IOException | ActivityNotFoundException | SecurityException e) {
            finishChooser(null);
        }
    }

    private void finishChooser(Uri[] result) {
        if (filePathCb != null) filePathCb.onReceiveValue(result);
        filePathCb = null;
        cameraUri = null;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE) return;
        Uri[] out = null;
        if (res == RESULT_OK) {
            if (data != null && (data.getData() != null || data.getClipData() != null)) {
                out = WebChromeClient.FileChooserParams.parseResult(res, data);
            } else if (cameraUri != null) {
                out = new Uri[]{cameraUri};
            }
        }
        finishChooser(out);
    }

    /* ---------------- دکمهٔ برگشت و چرخهٔ عمر ---------------- */

    @Override
    public void onBackPressed() {
        // صفحه با history.pushState خودش دکمهٔ برگشت را مدیریت می‌کند (appBack)
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("PMNative");
            web.destroy();
        }
        super.onDestroy();
    }
}
