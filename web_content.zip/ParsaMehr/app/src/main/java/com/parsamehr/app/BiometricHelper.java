package com.parsamehr.app;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.webkit.WebView;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import java.security.KeyStore;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/**
 * Real Android biometric authentication (AndroidX BiometricPrompt, BIOMETRIC_STRONG).
 *
 * The prompt is bound to a hardware-backed Android Keystore key that requires user
 * authentication for every use (CryptoObject). Success is reported only after the
 * fingerprint-gated key has actually been used, so a result cannot be produced
 * without the sensor having authenticated the user.
 *
 * Result strings delivered to JavaScript via window.pmBio(id, result):
 *   "ok" | "cancel" | "err:<reason>"
 */
final class BiometricHelper {
    private static final String ALIAS = "pm_bio_key_v1";
    private static final Pattern ID = Pattern.compile("^[A-Za-z0-9_-]{1,40}$");

    private final FragmentActivity act;
    private final WebView web;
    private boolean busy = false; // touched on the UI thread only

    BiometricHelper(FragmentActivity act, WebView web) {
        this.act = act;
        this.web = web;
    }

    /** "ok" when a strong biometric (fingerprint) is enrolled and usable. */
    String available() {
        int r = BiometricManager.from(act)
                .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);
        switch (r) {
            case BiometricManager.BIOMETRIC_SUCCESS: return "ok";
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED: return "none_enrolled";
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE: return "no_hardware";
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE: return "hw_unavailable";
            case BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED: return "update_required";
            default: return "unavailable";
        }
    }

    void authenticate(final String id, final String rawTitle) {
        if (id == null || !ID.matcher(id).matches()) return;
        final String title = (rawTitle == null || rawTitle.trim().isEmpty())
                ? "ورود به پارسا مهر"
                : rawTitle.trim().substring(0, Math.min(60, rawTitle.trim().length()));
        act.runOnUiThread(() -> {
            if (busy) { deliver(id, "err:busy"); return; }
            if (!"ok".equals(available())) { deliver(id, "err:unavailable"); return; }
            final Cipher cipher;
            try {
                cipher = newCipher();
            } catch (Exception e) {
                deliver(id, "err:key");
                return;
            }
            busy = true;
            BiometricPrompt prompt = new BiometricPrompt(act, ContextCompat.getMainExecutor(act),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            busy = false;
                            boolean ok = false;
                            BiometricPrompt.CryptoObject co = result.getCryptoObject();
                            if (co != null && co.getCipher() != null) {
                                try {
                                    // Only works if the sensor really unlocked the Keystore key.
                                    co.getCipher().doFinal(new byte[]{1});
                                    ok = true;
                                } catch (Exception ignored) { }
                            }
                            deliver(id, ok ? "ok" : "err:crypto");
                        }

                        @Override
                        public void onAuthenticationError(int code, CharSequence msg) {
                            busy = false;
                            if (code == BiometricPrompt.ERROR_NEGATIVE_BUTTON
                                    || code == BiometricPrompt.ERROR_USER_CANCELED
                                    || code == BiometricPrompt.ERROR_CANCELED) {
                                deliver(id, "cancel");
                            } else if (code == BiometricPrompt.ERROR_LOCKOUT
                                    || code == BiometricPrompt.ERROR_LOCKOUT_PERMANENT) {
                                deliver(id, "err:lockout");
                            } else {
                                deliver(id, "err:" + code);
                            }
                        }
                        // onAuthenticationFailed: wrong finger -> the system prompt keeps waiting.
                    });
            BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(title)
                    .setSubtitle("پارسا مهر")
                    .setNegativeButtonText("انصراف")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .setConfirmationRequired(false)
                    .build();
            try {
                prompt.authenticate(info, new BiometricPrompt.CryptoObject(cipher));
            } catch (Exception e) {
                busy = false;
                deliver(id, "err:prompt");
            }
        });
    }

    /** Cipher backed by the auth-required Keystore key; key is recreated if invalidated. */
    private Cipher newCipher() throws Exception {
        try {
            return initCipher();
        } catch (Exception first) {
            // Typically KeyPermanentlyInvalidatedException (fingerprints changed): rebuild the key.
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS);
            return initCipher();
        }
    }

    private Cipher initCipher() throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        return c;
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) {
            return (SecretKey) ks.getKey(ALIAS, null);
        }
        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
        } else {
            b.setUserAuthenticationValidityDurationSeconds(-1); // authenticate for every use
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(b.build());
        return kg.generateKey();
    }

    private void deliver(String id, String result) {
        // id and result come from fixed, validated character sets -> safe to inline.
        final String js = "window.pmBio&&window.pmBio('" + id + "','" + result + "')";
        web.post(() -> web.evaluateJavascript(js, null));
    }
}
