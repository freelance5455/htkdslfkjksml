package com.parsamehr.app;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.regex.Pattern;

/** Saving / sharing files for the JS bridge. Inputs are validated; nothing is trusted. */
final class FileHelper {
    static final int MAX_BYTES = 50 * 1024 * 1024;
    private static final Pattern MIME = Pattern.compile("^[a-z0-9][a-z0-9.+-]*/[a-z0-9][a-z0-9.+-]*$");

    private final Context ctx;

    FileHelper(Context c) {
        ctx = c.getApplicationContext();
        cleanCache();
    }

    // ---------- validation ----------
    static String safeName(String n, String def) {
        if (n == null) n = "";
        n = n.replace('\\', '/');
        int i = n.lastIndexOf('/');
        if (i >= 0) n = n.substring(i + 1);
        n = n.replaceAll("[\\p{Cntrl}:*?\"<>|]", "_").trim().replaceAll("^\\.+", "");
        int dot = n.lastIndexOf('.');
        String ext = (dot > 0 && n.length() - dot <= 8) ? n.substring(dot) : "";
        String base = ext.isEmpty() ? n : n.substring(0, dot);
        if (base.length() > 60) base = base.substring(0, 60);
        n = base + ext;
        return n.isEmpty() ? def : n;
    }

    static String safeMime(String m, String def) {
        if (m == null) return def;
        m = m.trim().toLowerCase(Locale.ROOT);
        return (m.length() <= 100 && MIME.matcher(m).matches()) ? m : def;
    }

    static byte[] decode(String b64) throws IOException {
        if (b64 == null || b64.isEmpty() || b64.length() > (long) MAX_BYTES * 4 / 3 + 16)
            throw new IOException("size");
        try {
            byte[] d = Base64.decode(b64, Base64.DEFAULT);
            if (d.length == 0 || d.length > MAX_BYTES) throw new IOException("size");
            return d;
        } catch (IllegalArgumentException e) {
            throw new IOException("base64");
        }
    }

    private static String withExt(String name, String mime) {
        if (name.lastIndexOf('.') > 0) return name;
        switch (mime) {
            case "image/png": return name + ".png";
            case "image/jpeg": return name + ".jpg";
            case "image/webp": return name + ".webp";
            case "application/pdf": return name + ".pdf";
            case "application/json": return name + ".json";
            default: return name;
        }
    }

    // ---------- public gallery / Downloads (Android 10+, no permission needed) ----------
    String saveImage(byte[] data, String name, String mime) throws IOException {
        mime = safeMime(mime, "image/png");
        if (!mime.startsWith("image/")) mime = "image/png";
        name = withExt(name, mime);
        Uri col = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        insert(col, data, name, mime, "Pictures/ParsaMehr");
        return "Pictures/ParsaMehr/" + name;
    }

    String saveFile(byte[] data, String name, String mime) throws IOException {
        mime = safeMime(mime, "application/octet-stream");
        name = withExt(name, mime);
        Uri col = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        insert(col, data, name, mime, "Download/ParsaMehr");
        return "Download/ParsaMehr/" + name;
    }

    private void insert(Uri collection, byte[] data, String name, String mime, String rel) throws IOException {
        ContentResolver cr = ctx.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri u = cr.insert(collection, v);
        if (u == null) throw new IOException("insert");
        try (OutputStream o = cr.openOutputStream(u)) {
            if (o == null) throw new IOException("stream");
            o.write(data);
        } catch (IOException e) {
            cr.delete(u, null, null);
            throw e;
        }
        v.clear();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(u, v, null, null);
    }

    // ---------- private cache + FileProvider (share / open / print / copy) ----------
    File cacheFile(byte[] data, String name) throws IOException {
        File root = new File(ctx.getCacheDir(), "shared");
        File dir = new File(root, Long.toHexString(System.nanoTime()));
        if (!dir.mkdirs()) throw new IOException("mkdir");
        File f = new File(dir, name);
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) {
            o.write(data);
        }
        return f;
    }

    Uri uriFor(File f) {
        return FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".files", f);
    }

    ClipData clipFor(Uri... uris) {
        ClipData c = ClipData.newRawUri("", uris[0]);
        for (int i = 1; i < uris.length; i++) c.addItem(new ClipData.Item(uris[i]));
        return c;
    }

    private void cleanCache() {
        try {
            File root = new File(ctx.getCacheDir(), "shared");
            File[] kids = root.listFiles();
            if (kids == null) return;
            long cutoff = System.currentTimeMillis() - 24L * 3600 * 1000;
            for (File k : kids) if (k.lastModified() < cutoff) deleteTree(k);
        } catch (Exception ignored) { }
    }

    private static void deleteTree(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
