package com.parsamehr.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

/**
 * JavaScript <-> Android bridge, exposed to the page as window.PMNative.
 *
 * Security model:
 *  - only methods annotated with @JavascriptInterface are reachable;
 *  - the WebView can only ever load the app's own bundled assets (all other requests are
 *    blocked in MainActivity), and every call re-checks that the current page is that origin;
 *  - all file names / MIME types / sizes / ids are validated before use;
 *  - methods return short status strings: "ok", "ok:<where>" or "err:<reason>".
 *
 * The method names and return formats are exactly what the app's HTML already expects.
 */
final class NativeBridge {
    private final MainActivity act;
    private final BiometricHelper bio;
    private final FileHelper files;

    NativeBridge(MainActivity act, android.webkit.WebView web) {
        this.act = act;
        this.bio = new BiometricHelper(act, web);
        this.files = new FileHelper(act);
    }

    private static String err(Exception e) {
        String m = e.getMessage();
        if (m == null || m.length() > 40 || !m.matches("[A-Za-z0-9_ .:-]+")) m = e.getClass().getSimpleName();
        return "err:" + m;
    }

    // ---------------- biometric ----------------
    @JavascriptInterface
    public String bioAvailable() {
        if (!act.isTrusted()) return "untrusted";
        try { return bio.available(); } catch (Exception e) { return "unavailable"; }
    }

    @JavascriptInterface
    public void bioAuth(String id, String title) {
        if (!act.isTrusted()) return;
        bio.authenticate(id, title);
    }

    // ---------------- save ----------------
    @JavascriptInterface
    public String saveImage(String b64, String name, String mime) {
        if (!act.isTrusted()) return "err:untrusted";
        try {
            return "ok:" + files.saveImage(FileHelper.decode(b64), FileHelper.safeName(name, "parsamehr.png"), mime);
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String saveFile(String b64, String name, String mime) {
        if (!act.isTrusted()) return "err:untrusted";
        try {
            return "ok:" + files.saveFile(FileHelper.decode(b64), FileHelper.safeName(name, "parsamehr.bin"), mime);
        } catch (Exception e) { return err(e); }
    }

    // ---------------- open / share ----------------
    @JavascriptInterface
    public String openFile(String b64, String name, String mime) {
        if (!act.isTrusted()) return "err:untrusted";
        try {
            final String m = FileHelper.safeMime(mime, "application/octet-stream");
            final Uri u = files.uriFor(files.cacheFile(FileHelper.decode(b64), FileHelper.safeName(name, "parsamehr.bin")));
            act.runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, m)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                i.setClipData(ClipData.newRawUri("", u));
                act.startSafe(Intent.createChooser(i, null));
            });
            return "ok";
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String shareImage(String b64, String name, String mime) {
        return shareOne(b64, FileHelper.safeName(name, "parsamehr.png"), FileHelper.safeMime(mime, "image/png"));
    }

    @JavascriptInterface
    public String shareFile(String b64, String name, String mime, String title) {
        return shareOne(b64, FileHelper.safeName(name, "parsamehr.bin"), FileHelper.safeMime(mime, "application/octet-stream"));
    }

    private String shareOne(String b64, String name, String mime) {
        if (!act.isTrusted()) return "err:untrusted";
        try {
            final Uri u = files.uriFor(files.cacheFile(FileHelper.decode(b64), name));
            final String m = mime;
            act.runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND).setType(m)
                        .putExtra(Intent.EXTRA_STREAM, u)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                i.setClipData(ClipData.newRawUri("", u));
                act.startSafe(Intent.createChooser(i, null));
            });
            return "ok";
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String shareFiles(String json, String title) {
        if (!act.isTrusted()) return "err:untrusted";
        try {
            JSONArray arr = new JSONArray(json);
            if (arr.length() == 0 || arr.length() > 20) return "err:count";
            final ArrayList<Uri> uris = new ArrayList<>();
            String common = null;
            long total = 0;
            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                byte[] d = FileHelper.decode(o.optString("b64", ""));
                total += d.length;
                if (total > FileHelper.MAX_BYTES) return "err:size";
                String mime = FileHelper.safeMime(o.optString("mime", ""), "application/octet-stream");
                common = (common == null || common.equals(mime)) ? mime : "*/*";
                uris.add(files.uriFor(files.cacheFile(d, FileHelper.safeName(o.optString("name", ""), "parsamehr-" + (k + 1)))));
            }
            final String type = common == null ? "*/*" : common;
            act.runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE).setType(type)
                        .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                i.setClipData(files.clipFor(uris.toArray(new Uri[0])));
                act.startSafe(Intent.createChooser(i, null));
            });
            return "ok";
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String shareText(String text, String subject) {
        if (!act.isTrusted()) return "err:untrusted";
        if (text == null || text.length() > 200000) return "err:size";
        final String t = text;
        act.runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t);
            act.startSafe(Intent.createChooser(i, null));
        });
        return "ok";
    }

    // ---------------- print / clipboard ----------------
    @JavascriptInterface
    public String printPdf(String b64, String name) {
        if (!act.isTrusted()) return "err:untrusted";
        try {
            final String n = FileHelper.safeName(name, "parsamehr.pdf");
            final File f = files.cacheFile(FileHelper.decode(b64), n);
            act.runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                    if (pm != null) pm.print(n, new PdfPrintAdapter(f, n), null);
                } catch (Exception ignored) { }
            });
            return "ok";
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String copyImage(String b64, String name, String mime) {
        if (!act.isTrusted()) return "err:untrusted";
        try {
            final Uri u = files.uriFor(files.cacheFile(FileHelper.decode(b64), FileHelper.safeName(name, "parsamehr.png")));
            act.runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newUri(act.getContentResolver(), "image", u));
                } catch (Exception ignored) { }
            });
            return "ok";
        } catch (Exception e) { return err(e); }
    }
}
