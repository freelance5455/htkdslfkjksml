package com.parsamehr.app;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Locale;

/**
 * Hosts the unchanged Parsa Mehr HTML (assets/index.html) in a WebView.
 * Fully offline: the page is served from the APK through WebViewAssetLoader on a fixed
 * https origin (so localStorage data stays stable across restarts and updates) and every
 * other network request is blocked. The manifest has no INTERNET permission at all.
 */
public class MainActivity extends AppCompatActivity {
    static final String HOST = "appassets.androidplatform.net";
    static final String ORIGIN = "https://" + HOST;
    static final String START_URL = ORIGIN + "/assets/index.html";

    private WebView webView;
    private WebViewAssetLoader loader;
    private volatile boolean trusted = false;
    private ValueCallback<Uri[]> chooserCb;
    private ActivityResultLauncher<Intent> chooserLauncher;

    /** True only while the page currently shown is this app's own bundled page. */
    boolean isTrusted() { return trusted; }

    void startSafe(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "برنامهٔ مناسبی پیدا نشد", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) { }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        chooserLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (chooserCb != null) {
                chooserCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.getResultCode(), r.getData()));
                chooserCb = null;
            }
        });

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0B1412);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                       // localStorage = all app data
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setSupportMultipleWindows(true);                  // catch target=_blank (WhatsApp/Telegram)
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        boolean debuggable = (getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        WebView.setWebContentsDebuggingEnabled(debuggable);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
                if ("https".equals(sc) && HOST.equalsIgnoreCase(u.getHost())) {
                    WebResourceResponse res = loader.shouldInterceptRequest(u);
                    return res != null ? res : blocked(404);
                }
                if (sc.equals("data") || sc.equals("blob") || sc.equals("about")) return null; // in-page content
                return blocked(403);                                                           // offline: no network
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("https".equalsIgnoreCase(u.getScheme()) && HOST.equalsIgnoreCase(u.getHost())) return false;
                openExternal(u);
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                trusted = url != null && url.startsWith(ORIGIN + "/");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean userGesture, Message resultMsg) {
                final WebView tmp = new WebView(MainActivity.this);
                final boolean[] done = {false};
                tmp.setWebViewClient(new WebViewClient() {
                    private void go(WebView w, Uri u) {
                        if (done[0]) return;
                        done[0] = true;
                        if (u != null && !"about:blank".equals(u.toString())) openExternal(u);
                        w.stopLoading();
                        w.post(w::destroy);
                    }
                    @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) { go(w, r.getUrl()); return true; }
                    @Override public void onPageStarted(WebView w, String url, Bitmap f) { go(w, url == null ? null : Uri.parse(url)); }
                });
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    String[] acc = p.getAcceptTypes();
                    if (acc != null && acc.length > 0 && acc[0] != null && !acc[0].isEmpty()) {
                        i.putExtra(Intent.EXTRA_MIME_TYPES, acc);
                    }
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    chooserLauncher.launch(i);
                    return true;
                } catch (Exception e) {
                    chooserCb = null;
                    cb.onReceiveValue(null);
                    return false;
                }
            }
        });

        // Bridge to native Android (BiometricPrompt, save/share/print). Page is bundled & trusted only.
        webView.addJavascriptInterface(new NativeBridge(this, webView), "PMNative");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        webView.loadUrl(START_URL);
    }

    private static WebResourceResponse blocked(int code) {
        return new WebResourceResponse("text/plain", "utf-8", code, "Blocked",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private void openExternal(Uri u) {
        if (u == null || u.getScheme() == null) return;
        String sc = u.getScheme().toLowerCase(Locale.ROOT);
        Intent i;
        switch (sc) {
            case "http": case "https": case "mailto": case "sms": case "smsto":
                i = new Intent(Intent.ACTION_VIEW, u); break;
            case "tel":
                i = new Intent(Intent.ACTION_DIAL, u); break;
            default:
                return; // never launch arbitrary schemes (intent:, file:, javascript: ...)
        }
        startSafe(i);
    }

    @Override protected void onResume() { super.onResume(); webView.onResume(); }
    @Override protected void onPause() { webView.onPause(); super.onPause(); }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("PMNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
