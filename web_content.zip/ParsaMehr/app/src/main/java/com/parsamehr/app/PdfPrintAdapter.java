package com.parsamehr.app;

import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Streams an existing PDF file into Android's print framework (print / save as PDF). */
final class PdfPrintAdapter extends PrintDocumentAdapter {
    private final File file;
    private final String name;

    PdfPrintAdapter(File file, String name) {
        this.file = file;
        this.name = name;
    }

    @Override
    public void onLayout(PrintAttributes oldA, PrintAttributes newA, CancellationSignal cancel,
                         LayoutResultCallback cb, Bundle extras) {
        if (cancel.isCanceled()) { cb.onLayoutCancelled(); return; }
        cb.onLayoutFinished(new PrintDocumentInfo.Builder(name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                .build(), true);
    }

    @Override
    public void onWrite(PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal cancel,
                        WriteResultCallback cb) {
        try (InputStream in = new FileInputStream(file);
             OutputStream out = new FileOutputStream(dest.getFileDescriptor())) {
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                if (cancel.isCanceled()) { cb.onWriteCancelled(); return; }
                out.write(buf, 0, n);
            }
            cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
        } catch (IOException e) {
            cb.onWriteFailed(e.getMessage());
        }
    }
}
