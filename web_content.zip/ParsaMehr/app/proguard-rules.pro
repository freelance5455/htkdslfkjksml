# empty: no shrinking is applied (minifyEnabled false)
