# پارسا مهر — پروژهٔ Android Studio (WebView + BiometricPrompt)

برنامهٔ HTML فعلی (`app/src/main/assets/index.html`) بدون تغییر در عملکرد داخل یک WebView اجرا می‌شود.
اثر انگشت از **AndroidX BiometricPrompt** (حسگر واقعی، BIOMETRIC_STRONG، کلید Keystore) استفاده می‌کند.

## ساخت APK
**روش ۱ — Android Studio:** پوشه را Open کنید → Sync → `Build > Build APK(s)`.
خروجی: `app/build/outputs/apk/debug/app-debug.apk`

**روش ۲ — خط فرمان** (JDK 17 و Android SDK نصب باشد، یک‌بار برای ساخت wrapper):
```
gradle wrapper --gradle-version 8.7
./gradlew assembleDebug
```
**روش ۳ — بدون نصب چیزی:** پروژه را در GitHub بگذارید و Action به نام «Build APK» را اجرا کنید.

APK نهایی با امضای release: یک keystore بسازید (`keytool -genkeypair ...`) و
`zipalign` + `apksigner` را روی `assembleRelease` اجرا کنید. keystore را نگه دارید؛ بدون آن نمی‌توانید به‌روزرسانی بدهید.

## ساختار
- `MainActivity.java` — WebView، بارگذاری آفلاین از assets، مسدودسازی شبکه، لینک‌های خارجی، انتخاب فایل (بازیابی پشتیبان)
- `NativeBridge.java` — پل `window.PMNative` (همان متدهایی که HTML از قبل صدا می‌زند)
- `BiometricHelper.java` — BiometricPrompt + کلید Keystore
- `FileHelper.java`, `PdfPrintAdapter.java` — ذخیره در گالری/Downloads، اشتراک‌گذاری، چاپ PDF
- `AndroidManifest.xml` — فقط مجوز USE_BIOMETRIC؛ **بدون مجوز اینترنت**

## تست دستی پیشنهادی (روی گوشی)
1. نصب → در تنظیمات برنامه قفل الگویی بسازید.
2. «فعال‌سازی ورود با اثر انگشت» → انگشت را روی حسگر بگذارید.
3. برنامه را ببندید/به پس‌زمینه ببرید و برگردید → باید درخواست اثر انگشت بیاید؛ «انصراف» → الگو کار کند.
4. تغییر الگو، قفل خودکار (فوراً/۱ دقیقه)، غیرفعال‌سازی اثر انگشت.
5. ذخیرهٔ تصویر فاکتور، اشتراک‌گذاری، چاپ/PDF، پشتیبان‌گیری و بازیابی.
