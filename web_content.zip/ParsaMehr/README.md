# پارسا مهر — پروژهٔ اندروید (v22)

HTML برنامه در `app/src/main/assets/www/index.html` است و بدون تغییر در امکانات حسابداری داخل WebView اجرا می‌شود.
پل `window.PMNative` در `PMNative.java` پیاده شده: shareFile, shareFiles, shareText, saveImage, saveFile, openFile, copyImage, printPdf.

## ساخت APK
**روش ۱ — اندروید استودیو:** پوشهٔ پروژه را Open کنید، صبر کنید Sync تمام شود، سپس Build ▸ Build APK(s).
خروجی: `app/build/outputs/apk/debug/app-debug.apk`

**روش ۲ — بدون کامپیوتر (GitHub Actions):** پروژه را در یک مخزن GitHub آپلود کنید ▸ تب Actions ▸ Build APK ▸ Run workflow.
بعد از چند دقیقه فایل APK در بخش Artifacts دانلود می‌شود.

## نکته‌ها
- اولین بار «پشتیبان‌گیری» را در APK قدیمی بگیرید و بعد از نصب نسخهٔ جدید «بازیابی» کنید؛ چون آدرس داخلی برنامه عوض شده و داده‌ٔ قدیمی خودکار منتقل نمی‌شود.
- اگر APK قدیمی با همین applicationId نبود، هر دو کنار هم نصب می‌شوند.
- فونت Vazirmatn از اینترنت لود می‌شود؛ بدون اینترنت فونت پیش‌فرض نمایش داده می‌شود.
- اسکن با دوربین به `BarcodeDetector` در WebView نیاز دارد که روی بعضی گوشی‌ها نیست؛ در آن صورت برنامه پیام «پشتیبانی نمی‌شود» می‌دهد.
