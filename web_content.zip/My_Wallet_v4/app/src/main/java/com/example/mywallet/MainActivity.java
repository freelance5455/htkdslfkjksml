package com.example.mywallet;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 1001;
    private static final int REQ_IMPORT = 1002;
    private static final int DARK = Color.rgb(7, 11, 22);
    private static final int LIGHT = Color.rgb(238, 242, 251);

    private WebView webView;
    private FrameLayout root;
    private String pendingExport;

    /** Methods callable from the page as window.Android.* */
    public class Bridge {
        @JavascriptInterface
        public void exportBackup(final String json, final String name) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    pendingExport = json;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, name);
                    try { startActivityForResult(i, REQ_EXPORT); }
                    catch (Exception e) { webView.evaluateJavascript("window.onExportDone(false)", null); }
                }
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    try { startActivityForResult(i, REQ_IMPORT); }
                    catch (Exception e) { webView.evaluateJavascript("window.onExportDone(false)", null); }
                }
            });
        }

        @JavascriptInterface
        public void setBars(final boolean dark) {
            runOnUiThread(new Runnable() {
                @Override public void run() { applyBars(dark); }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new FrameLayout(this);
        root.setBackgroundColor(DARK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);          // assets are still loadable
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        webView.addJavascriptInterface(new Bridge(), "Android");

        webView.setWebChromeClient(new WebChromeClient());  // needed so JS dialogs / focus behave
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return !url.startsWith("file:///android_asset/");  // never navigate away
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        // Android 15 draws edge-to-edge for targetSdk 35: keep content clear of system bars.
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
                return insets;
            }
        });
        root.requestApplyInsets();

        applyBars(true);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void applyBars(boolean dark) {
        int c = dark ? DARK : LIGHT;
        root.setBackgroundColor(c);
        getWindow().setStatusBarColor(c);
        getWindow().setNavigationBarColor(c);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            int flags = root.getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            root.setSystemUiVisibility(flags);
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (req == REQ_EXPORT && pendingExport != null) {
                OutputStream out = getContentResolver().openOutputStream(uri, "wt");
                out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                out.close();
                pendingExport = null;
                webView.evaluateJavascript("window.onExportDone(true)", null);
            } else if (req == REQ_IMPORT) {
                InputStream in = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) buf.write(b, 0, n);
                in.close();
                String text = new String(buf.toByteArray(), StandardCharsets.UTF_8);
                webView.evaluateJavascript("window.onImportText(" + JSONObject.quote(text) + ")", null);
            }
        } catch (Exception e) {
            if (req == REQ_EXPORT) webView.evaluateJavascript("window.onExportDone(false)", null);
            else webView.evaluateJavascript("window.onImportText('')", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
