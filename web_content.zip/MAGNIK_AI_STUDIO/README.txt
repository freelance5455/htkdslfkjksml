# MAGNIK AI STUDIO — maquette web

## Lancer
Ouvrez `index.html` dans un navigateur. Aucun serveur n'est nécessaire pour consulter cette maquette.

## Inclus
- Interface responsive inspirée des assistants IA modernes
- Navigation Assistant / Mes créations / Premium
- Chat de démonstration avec réponses simulées
- Ajout local de projets (dans la session du navigateur)
- Écrans de présentation Google et Wave

## Important avant une mise en production
Cette archive est un prototype front-end. Elle ne contient pas de véritable modèle IA, de connexion Google OAuth, de base de données, de système d'abonnement, ni de paiement Wave actif. Les boutons Google et Wave affichent volontairement un message de configuration et ne collectent aucune donnée ni aucun paiement.

Pour un lancement réel, il faudra :
1. Ajouter un backend sécurisé et une base de données.
2. Connecter un fournisseur de modèle IA via une API conservée côté serveur.
3. Configurer Google OAuth avec des identifiants propres au domaine.
4. Intégrer Wave via la documentation et les identifiants marchands officiels, puis vérifier les paiements côté serveur avant d'activer Premium.
5. Tester la sécurité, les comptes, les paiements et les exports Android/iOS avant publication.
