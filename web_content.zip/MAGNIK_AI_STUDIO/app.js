const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const views = {chat:$("#chatView"),projects:$("#projectsView"),premium:$("#premiumView"),account:$("#accountView")};
const pageNames={chat:"Assistant",projects:"Mes créations",premium:"Premium",account:"Mon espace"};
let chats=[];
let current=[];
let toastTimer;
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),3000)}
function showView(name){Object.entries(views).forEach(([k,v])=>v.classList.toggle("active",k===name));$("#pageName").textContent=pageNames[name]||"Assistant";$$(".nav").forEach(b=>b.classList.toggle("active",b.dataset.view===name));$("#sidebar").classList.remove("open")}
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
function renderMessages(){const box=$("#messages");box.innerHTML="";current.forEach(m=>{const d=document.createElement("div");d.className="message "+m.role;d.textContent=m.text;box.appendChild(d)});$("#welcome").style.display=current.length?"none":"block";box.scrollTop=box.scrollHeight}
function addHistory(title){const btn=document.createElement("button");btn.className="history-item";btn.textContent=title.slice(0,34);btn.addEventListener("click",()=>{toast("Historique de démonstration : conversation actuelle.");});$("#history").prepend(btn)}
function answerFor(text){const t=text.toLowerCase();if(t.includes("application")||t.includes("app"))return "Très bonne idée ! Pour créer une vraie application, commençons par définir son objectif, les utilisateurs et les fonctions principales.\\n\\nDans MAGNIK AI STUDIO, l'espace « Mes créations » sert à organiser tes projets. Dans cette version de démonstration, la génération et l'export d'une application ne sont pas encore connectés à un moteur de développement.";if(t.includes("site")||t.includes("web"))return "Pour un site professionnel, je te conseille une page d'accueil claire, une présentation des services, une page contact et un design adapté au téléphone.\\n\\nJe peux t'aider à préparer le cahier des charges et les textes. La génération complète du site nécessitera de connecter un service IA.";if(t.includes("bonjour")||t.includes("salut"))return "Bonjour ! Bienvenue dans MAGNIK AI STUDIO. Que souhaites-tu imaginer ou construire aujourd'hui ?";return "Merci pour ton message ! Je suis l'aperçu de MAGNIK AI STUDIO. Je peux t'aider à structurer une idée, préparer un projet d'application ou de site web et expliquer les étapes.\\n\\nÀ noter : cette version utilise des réponses de démonstration. Pour obtenir de vraies réponses comme ChatGPT, il faudra connecter un modèle IA avec une API sécurisée."}
function sendMessage(text){const clean=text.trim();if(!clean)return;current.push({role:"user",text:clean});if(current.length===1)addHistory(clean);renderMessages();$("#prompt").value="";setTimeout(()=>{current.push({role:"assistant",text:answerFor(clean)});renderMessages()},450)}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();sendMessage($("#prompt").value)});
$("#prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#chatForm").requestSubmit()}});
$$(".suggestion").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
$("#newChat").addEventListener("click",()=>{current=[];renderMessages();showView("chat")});
$("#createProject").addEventListener("click",()=>{const name=prompt("Nom de ton projet :");if(!name||!name.trim())return;const card=document.createElement("article");card.className="project-card";const icon=document.createElement("div");icon.className="project-icon purple";icon.textContent="✧";const tag=document.createElement("span");tag.className="tag";tag.textContent="Nouveau";const h=document.createElement("h3");h.textContent=name.trim();const p=document.createElement("p");p.textContent="Projet ajouté à ton espace de démonstration.";const small=document.createElement("small");small.textContent="Créé maintenant";card.append(icon,tag,h,p,small);$("#projectGrid").prepend(card);toast("Projet ajouté !")});
$("#wavePay").addEventListener("click",()=>toast("Wave n'est pas encore connecté. Aucun paiement n'a été lancé."));
$("#googleBtn").addEventListener("click",()=>toast("Connexion Google à configurer avec OAuth avant publication."));
renderMessages();
