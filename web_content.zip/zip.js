window.ZipHandler = {
    async extractDexFiles(arrayBuffer) {
        UI.log('جاري فحص حاوية APK واستخراج ملفات DEX...', 'info');
        
        const zip = new JSZip();
        const loadedZip = await zip.loadAsync(arrayBuffer);
        const dexFiles = [];

        const dexEntries = Object.keys(loadedZip.files).filter(fileName => 
            fileName.endsWith('.dex') && !loadedZip.files[fileName].dir
        );

        if (dexEntries.length === 0) {
            throw new Error('لم يتم العثور على أي ملفات DEX داخل حزمة APK.');
        }

        UI.log(`تم العثور على ${dexEntries.length} ملف (DEX) داخل التطبيق.`, 'success');

        for (let i = 0; i < dexEntries.length; i++) {
            const fileName = dexEntries[i];
            const fileData = await loadedZip.files[fileName].async('arraybuffer');
            
            dexFiles.push({
                name: fileName,
                buffer: fileData
            });

            const percent = Math.round(((i + 1) / dexEntries.length) * 30) + 40;
            UI.updateProgress(percent, `تم استخراج ${fileName}...`);
        }

        return dexFiles;
    }
};
