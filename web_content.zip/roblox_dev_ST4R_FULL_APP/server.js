import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { GoogleGenAI } from "@google/genai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "64kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/health", (_req, res) => res.json({ status: "online", service: "ST4R AI" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: "Serverda GEMINI_API_KEY maxfiy sozlamasi yo‘q." });
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Xabar bo‘sh bo‘lmasin." });
    if (message.length > 12000) return res.status(413).json({ error: "Xabar juda uzun (maksimum 12000 belgi)." });

    const rawHistory = Array.isArray(req.body?.history) ? req.body.history.slice(-16) : [];
    const transcript = rawHistory.map((m) => {
      const role = m?.role === "model" ? "ST4R AI" : "Foydalanuvchi";
      const text = Array.isArray(m?.parts) ? m.parts.map(p => typeof p?.text === "string" ? p.text : "").join("") :
        (typeof m?.text === "string" ? m.text : "");
      return text ? `${role}: ${text.slice(0, 4000)}` : "";
    }).filter(Boolean).join("\n\n");

    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const prompt = `Sening noming ST4R AI. Sen Roblox o‘yin ishlab chiqish yordamchisisan. Roblox Studio, Luau, game design, UI, debugging va loyihani rejalashda foydali, aniq va amaliy javob ber. Foydalanuvchi o‘zbekcha yozsa o‘zbekcha javob ber. Kod so‘ralsa kodni to‘liq ber va qaysi Script/LocalScript/ModuleScript ichiga qo‘yilishini, qayerga joylashtirishni tushuntir. Noma’lum narsani uydirma; xavfsiz, Roblox qoidalariga mos yechim tanla. Savol Robloxga tegishli bo‘lmasa ham foydali javob ber.\n\nOldingi suhbat:\n${transcript || "(yangi suhbat)"}\n\nFoydalanuvchining yangi xabari:\n${message}`;

    const result = await ai.models.generateContent({
      model: MODEL,
      contents: prompt,
      config: { temperature: 0.65, maxOutputTokens: 1800 }
    });
    const reply = result.text?.trim();
    if (!reply) return res.status(502).json({ error: "Gemini bo‘sh javob qaytardi. Qayta urinib ko‘r." });
    res.json({ reply });
  } catch (err) {
    // Deliberately do not log credentials or full request contents.
    const message = String(err?.message || "Unknown error");
    console.error("ST4R AI request failed:", message.slice(0, 240));
    res.status(502).json({ error: "Gemini so‘rovi bajarilmadi. API kalit, model nomi, limit va internet ulanishini tekshir." });
  }
});

app.listen(PORT, "0.0.0.0", () => console.log(`ST4R AI server listening on port ${PORT}`));
