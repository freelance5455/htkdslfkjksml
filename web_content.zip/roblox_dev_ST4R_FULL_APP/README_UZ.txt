ROBLOX dev.ST4R — ST4R AI FULL APP
================================

NIMA BOR?
- Mobilga mos ST4R AI web ilovasi (public/index.html)
- Haqiqiy Gemini API bilan gaplashadigan backend (server.js)
- Luau Lab: kod yozish, nusxalash va .luau fayl qilib saqlash
- AI Planner, chat tarixi, sozlamalar
- API kalit frontendga joylanmaydi

MUHIM
API kalitini HTML, APK, GitHub yoki chatga yozmang. Avval oldin oshkor bo‘lgan kalitni bekor qiling.
Yangi kalitni faqat backend hostingining Environment Variables / Secrets bo‘limiga kiriting:
GEMINI_API_KEY = yangi API kalit
GEMINI_MODEL = gemini-3.8-flash (agar akkauntingizda mavjud bo‘lmasa, Google AI Studio'da ruxsat berilgan model nomini kiriting)

LOCAL TEST (Node.js o‘rnatilgan kompyuter kerak)
1. Loyiha papkasida terminal oching.
2. npm install
3. GEMINI_API_KEY ni terminal muhitiga yoki .env qo‘llaydigan hosting secrets qismiga kiriting.
   Linux/macOS: export GEMINI_API_KEY="YANGI_KALIT"
   Windows PowerShell: $env:GEMINI_API_KEY="YANGI_KALIT"
4. npm start
5. Brauzerda http://localhost:3000 oching.

INTERNETGA CHIQARISH
- Node.js qo‘llaydigan hostingga butun papkani joylang.
- Hostingda GEMINI_API_KEY va kerak bo‘lsa GEMINI_MODEL environment secretlarini sozlang.
- Start command: npm start
- Hosting bergan HTTPS domenni oching. /health endpoint JSON qaytarishi kerak.
- Sayt /api/chat endpoint bilan o‘zi bog‘lanadi, chunki frontend va backend bitta origin'da xizmat qiladi.

APK
Bu web loyiha o‘zi APK emas. Avval backendni HTTPS hostingga joylang, saytda AI ishlayotganini sinang, keyin HTTPS saytni Android WebView/HTML-to-APK loyihasiga o‘rang. APK ichiga API kalitni qo‘shmang.
HTML faylni shunchaki telefonda ochish orqali Gemini ishlamaydi; backend ishga tushishi va internetda ochiq bo‘lishi kerak.

MODEL HAQIDA
Model mavjudligi API kalit va akkauntga bog‘liq bo‘lishi mumkin. Agar model xatosi chiqsa, Google AI Studio'da mavjud model nomini tekshirib GEMINI_MODEL ni yangilang.
