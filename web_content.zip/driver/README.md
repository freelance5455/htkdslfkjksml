# SHESHA DELIVERY — Driver App

Standalone phone-testable PWA prototype for the driver role.

## Test
Open `index.html` in a browser. For Android installation, serve the folder from HTTPS (or localhost) and use Chrome → Add to Home screen.

## Brand
Red #B71C1C · Dark red #7A0D0D · Charcoal #1E1E1E · Orange #F59E0B · White #FFFFFF

## Important
No bike shop/category/products/pages. Bike/vehicle logic is only relevant to delivery operations and fee calculation.

This prototype uses local UI/demo data; connect it to Firebase/Supabase/API and a real card processor for production.
