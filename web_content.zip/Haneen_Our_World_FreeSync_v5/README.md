# Haneen • Our World v0.4 — Firebase sync build

This is the same Haneen world with Firebase-backed synchronization added.

## Firebase project already linked
- Project: haneen-our-world
- Android package: com.haneen.ourworld
- Firebase config: android_project/google-services.json

## One-time Firebase console setup
1. In Firebase Console, open **Authentication → Sign-in method** and enable **Anonymous** sign-in.
2. Open **Realtime Database → Create database**. Choose a location and create it. Then set the Realtime Database rules to the contents of `android_project/database.rules.json`.
3. Open **Storage → Get started** and create the default bucket if it has not already been created. Set Storage Rules to the contents of `android_project/storage.rules`.

The app uses the Firebase REST APIs directly from its Android WebView wrapper, so no Firebase Android SDK dependency is required in the project.

## Sync model
Photos and audio are uploaded to Cloud Storage under `haneen-world/photos/...` and `haneen-world/audio/...`; text records are stored in Realtime Database under `haneen-world/...`.

## Important privacy note
The supplied build uses Firebase Anonymous Authentication and an app-specific world path. This is suitable for a private two-phone project that is not publicly distributed, but it is not equivalent to end-to-end encryption or a strict two-account allowlist. For stronger isolation, use email/password or another identified auth provider and rules that allow only the two chosen UIDs.
