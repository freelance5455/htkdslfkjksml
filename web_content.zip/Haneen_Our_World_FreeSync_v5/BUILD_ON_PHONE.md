# Haneen APK build

The Android project is ready for a cloud build. The repository workflow at `.github/workflows/build-apk.yml` runs Gradle 8.7 with Java 17 and produces `app-debug.apk`.

Firebase uses Anonymous Authentication + Realtime Database only. Cloud Storage is not used, so this build does not require Blaze billing.
