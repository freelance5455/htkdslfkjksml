package com.haneen.ourworld;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.view.Window;
import android.graphics.Color;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){
    super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE);
    WebView w=new WebView(this);
    w.setWebViewClient(new WebViewClient());
    WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setMediaPlaybackRequiresUserGesture(true);
    w.addJavascriptInterface(new FirebaseBridge(this,w),"HaneenCloud");
    w.loadUrl("file:///android_asset/index.html"); setContentView(w);
  }
}
