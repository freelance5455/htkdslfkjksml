package com.haneen.ourworld;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FirebaseBridge {
  private final Context ctx; private final WebView web;
  private final Handler main=new Handler(Looper.getMainLooper());
  private final ExecutorService pool=Executors.newCachedThreadPool();
  private final SharedPreferences prefs;
  private static final String API_KEY="AIzaSyCAk6eKD-hHcgN3d8iYY5EitjrgURx1WgI";
  private static final String DB_URL="https://haneen-our-world-default-rtdb.firebaseio.com";
  private static final String WORLD="haneen-world-v5";
  public FirebaseBridge(Context c,WebView w){ctx=c;web=w;prefs=c.getSharedPreferences("firebase",0);}

  @JavascriptInterface public void init(){pool.execute(()->{try{refreshOrSignIn();js("window.onCloudReady&&window.onCloudReady(true,'Cloud connected');");pull();}catch(Exception e){js("window.onCloudReady&&window.onCloudReady(false,"+q(e.toString())+");");}});}
  @JavascriptInterface public void push(String store,String id,String json){pool.execute(()->{try{String t=requireToken();String p="/"+WORLD+"/"+enc(store)+"/"+enc(id)+".json?auth="+enc(t);jsonPut(DB_URL+p,json);js("window.onCloudPush&&window.onCloudPush("+q(store)+","+q(id)+",true,'');");}catch(Exception e){js("window.onCloudPush&&window.onCloudPush("+q(store)+","+q(id)+",false,"+q(e.toString())+");");}});}
  @JavascriptInterface public void deleteRemote(String store,String id){pool.execute(()->{try{String t=requireToken();String p="/"+WORLD+"/"+enc(store)+"/"+enc(id)+".json?auth="+enc(t);jsonDelete(DB_URL+p);}catch(Exception ignored){}});}
  @JavascriptInterface public void pull(){pool.execute(()->{try{String t=requireToken();String p="/"+WORLD+".json?auth="+enc(t);String b=get(DB_URL+p);if(b==null||b.equals("null"))b="{}";js("window.onCloudPull&&window.onCloudPull("+q(b)+");");}catch(Exception e){js("window.onCloudPullError&&window.onCloudPullError("+q(e.toString())+");");}});}
  private String requireToken()throws Exception{refreshIfNeeded();String t=prefs.getString("token",null);if(t==null)throw new Exception("Cloud authentication is not ready");return t;}
  private void refreshOrSignIn()throws Exception{String r=prefs.getString("refresh",null);if(r!=null){try{refreshToken(r);return;}catch(Exception ignored){}}JSONObject req=new JSONObject();req.put("returnSecureToken",true);JSONObject out=jsonPost("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key="+API_KEY,req.toString());saveAuth(out);}
  private synchronized void refreshIfNeeded()throws Exception{long exp=prefs.getLong("expiresAt",0);if(prefs.getString("token",null)==null||System.currentTimeMillis()+60000>=exp){String r=prefs.getString("refresh",null);if(r!=null)refreshToken(r);else refreshOrSignIn();}}
  private void refreshToken(String r)throws Exception{String body="grant_type=refresh_token&refresh_token="+URLEncoder.encode(r,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL("https://securetoken.googleapis.com/v1/token?key="+API_KEY).openConnection();c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");c.setDoOutput(true);write(c,body);int code=c.getResponseCode();String b=read(c,code);if(code>=400)throw new Exception(b);JSONObject o=new JSONObject(b);prefs.edit().putString("token",o.getString("id_token")).putString("refresh",o.getString("refresh_token")).putString("uid",o.optString("user_id","")).putLong("expiresAt",System.currentTimeMillis()+Long.parseLong(o.optString("expires_in","3600"))*1000L).apply();}
  private void saveAuth(JSONObject r)throws Exception{prefs.edit().putString("token",r.getString("idToken")).putString("refresh",r.getString("refreshToken")).putString("uid",r.getString("localId")).putLong("expiresAt",System.currentTimeMillis()+Long.parseLong(r.optString("expiresIn","3600"))*1000L).apply();}
  private String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8").replace("+","%20");}
  private void js(String code){main.post(()->web.evaluateJavascript(code,null));}
  private String q(String s){return JSONObject.quote(s==null?"":s);}
  private String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(15000);c.setReadTimeout(120000);int code=c.getResponseCode();String b=read(c,code);if(code>=400)throw new Exception(b);return b;}
  private JSONObject jsonPost(String u,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);write(c,body);int code=c.getResponseCode();String b=read(c,code);if(code>=400)throw new Exception(b);return new JSONObject(b);}
  private void jsonPut(String u,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("PUT");c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);write(c,body);int code=c.getResponseCode();String b=read(c,code);if(code>=400)throw new Exception(b);}
  private void jsonDelete(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("DELETE");int code=c.getResponseCode();String b=read(c,code);if(code>=400)throw new Exception(b);}
  private void write(HttpURLConnection c,String s)throws Exception{try(OutputStream o=c.getOutputStream()){o.write(s.getBytes(StandardCharsets.UTF_8));}}
  private String read(HttpURLConnection c,int code)throws Exception{InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)return "";ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[16384];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString(StandardCharsets.UTF_8.name());}
}
