package com.mjtaghipour.daftarresipi;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ClipData;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.Base64;
import androidx.exifinterface.media.ExifInterface;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_CHOOSER = 1001;
    private Uri cameraOutputUri;
    private static final int REQ_CAMERA = 1002;
    private static final int REQ_GALLERY = 1003;
    private File pendingCameraFile;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            String p = savedInstanceState.getString("pendingCameraFile");
            if (p != null) pendingCameraFile = new File(p);
        }
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        webView.addJavascriptInterface(new RecipeStorageBridge(), "AndroidStorage");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = callback;
                cameraOutputUri = null;
                try {
                    if (params.isCaptureEnabled()) {
                        launchCamera();
                    } else {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("image/*");
                        startActivityForResult(Intent.createChooser(intent, "انتخاب عکس"), FILE_CHOOSER);
                    }
                } catch (ActivityNotFoundException e) {
                    finishFileSelection(null);
                    Toast.makeText(MainActivity.this, "دوربین یا انتخاب‌گر عکس روی گوشی پیدا نشد.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    finishFileSelection(null);
                    Toast.makeText(MainActivity.this, "باز کردن دوربین/گالری ناموفق بود.", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }


    /**
     * A durable local copy of all recipe data (including embedded photo data URLs).
     * Stored privately in the app's internal files directory; no cloud or broad file
     * permissions are required. It remains across app restarts and normal updates.
     */
    private class RecipeStorageBridge {
        @JavascriptInterface
        public void pickPhoto(final String source) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        if ("camera".equals(source)) launchCameraNative();
                        else launchGalleryNative();
                    } catch (ActivityNotFoundException e) {
                        jsPhoto("error", "برنامه دوربین/گالری روی گوشی پیدا نشد.");
                    } catch (Exception e) {
                        jsPhoto("error", "باز کردن دوربین/گالری ناموفق بود.");
                    }
                }
            });
        }

        @JavascriptInterface
        public synchronized boolean saveRecipes(String json) {
            if (json == null) return false;
            try {
                // Validate that the file contains JSON array data before overwriting backup.
                new JSONArray(json);
                File target = new File(getFilesDir(), "recipes_backup.json");
                File temp = new File(getFilesDir(), "recipes_backup.tmp");
                try (FileOutputStream out = new FileOutputStream(temp)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.getFD().sync();
                }
                if (target.exists() && !target.delete()) return false;
                return temp.renameTo(target);
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public synchronized String loadRecipes() {
            File source = new File(getFilesDir(), "recipes_backup.json");
            if (!source.isFile()) return "";
            try (FileInputStream in = new FileInputStream(source)) {
                byte[] bytes = new byte[(int) source.length()];
                int offset = 0, count;
                while (offset < bytes.length && (count = in.read(bytes, offset, bytes.length - offset)) > 0) offset += count;
                String json = new String(bytes, 0, offset, StandardCharsets.UTF_8);
                new JSONArray(json); // validate before returning it to the web app
                return json;
            } catch (Exception e) {
                return "";
            }
        }
    }

    private void launchCamera() throws IOException {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) == null) {
            throw new ActivityNotFoundException("No camera app");
        }
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (storageDir == null) storageDir = getFilesDir();
        if (!storageDir.exists() && !storageDir.mkdirs()) throw new IOException("Cannot create image folder");
        String time = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File photoFile = File.createTempFile("RECIPE_" + time + "_", ".jpg", storageDir);
        cameraOutputUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photoFile);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
        cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(cameraIntent, FILE_CHOOSER);
    }

    // ---------- Native photo picking (camera / gallery) ----------
    private void jsPhoto(String status, String data) {
        String js = "window.__photoResult && window.__photoResult(" + JSONObject.quote(status) + "," +
                (data == null ? "null" : JSONObject.quote(data)) + ")";
        webView.evaluateJavascript(js, null);
    }

    private void launchCameraNative() throws IOException {
        File dir = new File(getCacheDir(), "photos");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create photo dir");
        pendingCameraFile = File.createTempFile("RECIPE_", ".jpg", dir);
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", pendingCameraFile);
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        i.setClipData(ClipData.newRawUri("photo", uri));
        int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        i.addFlags(flags);
        try {
            List<ResolveInfo> list = getPackageManager().queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY);
            for (ResolveInfo ri : list) grantUriPermission(ri.activityInfo.packageName, uri, flags);
        } catch (Exception ignored) {}
        startActivityForResult(i, REQ_CAMERA);
    }

    private void launchGalleryNative() {
        Intent get = new Intent(Intent.ACTION_GET_CONTENT);
        get.addCategory(Intent.CATEGORY_OPENABLE);
        get.setType("image/*");
        try {
            startActivityForResult(get, REQ_GALLERY);
        } catch (ActivityNotFoundException e) {
            Intent pick = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            pick.setType("image/*");
            startActivityForResult(pick, REQ_GALLERY);
        }
    }

    private void processPhotoAsync(final Uri uri, final File tempToDelete) {
        jsPhoto("start", null);
        new Thread(new Runnable() {
            @Override public void run() {
                String result = null;
                try {
                    result = compressToDataUrl(uri);
                } catch (Throwable t) {
                    result = null;
                }
                if (tempToDelete != null) { try { tempToDelete.delete(); } catch (Exception ignored) {} }
                final String fin = result;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (fin != null) jsPhoto("ok", fin);
                        else jsPhoto("error", "این عکس باز نشد. یه عکس دیگه امتحان کن.");
                    }
                });
            }
        }).start();
    }

    private String compressToDataUrl(Uri uri) throws IOException {
        // 1) read size
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("no stream");
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("bad image");
        // 2) EXIF orientation
        int degrees = 0;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in != null) {
                int o = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (o == ExifInterface.ORIENTATION_ROTATE_90) degrees = 90;
                else if (o == ExifInterface.ORIENTATION_ROTATE_180) degrees = 180;
                else if (o == ExifInterface.ORIENTATION_ROTATE_270) degrees = 270;
            }
        } catch (Exception ignored) {}
        // 3) decode downsampled
        int sample = 1;
        int longest = Math.max(bounds.outWidth, bounds.outHeight);
        while (longest / (sample * 2) >= 960) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("no stream");
            bmp = BitmapFactory.decodeStream(in, null, opts);
        }
        if (bmp == null) throw new IOException("decode failed");
        // 4) scale + rotate + compress (keep result reasonably small for storage)
        float max = 960f; int q = 74; String out = null;
        for (int i = 0; i < 7; i++) {
            float scale = Math.min(1f, max / Math.max(bmp.getWidth(), bmp.getHeight()));
            Matrix m = new Matrix();
            m.postScale(scale, scale);
            if (degrees != 0) m.postRotate(degrees);
            Bitmap b = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, q, bos);
            if (b != bmp) b.recycle();
            out = "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            if (out.length() < 170000) break;
            max *= 0.82f; q = Math.max(50, q - 6);
        }
        bmp.recycle();
        return out;
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (pendingCameraFile != null) outState.putString("pendingCameraFile", pendingCameraFile.getAbsolutePath());
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAMERA) {
            File f = pendingCameraFile;
            pendingCameraFile = null;
            if (resultCode == RESULT_OK && f != null && f.length() > 0) {
                processPhotoAsync(Uri.fromFile(f), f);
            } else {
                if (f != null) f.delete();
                jsPhoto("cancel", null);
            }
            return;
        }
        if (requestCode == REQ_GALLERY) {
            Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
            if (uri == null && resultCode == RESULT_OK && data != null && data.getClipData() != null && data.getClipData().getItemCount() > 0)
                uri = data.getClipData().getItemAt(0).getUri();
            if (uri != null) processPhotoAsync(uri, null);
            else jsPhoto("cancel", null);
            return;
        }
        if (requestCode == FILE_CHOOSER && uploadCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (cameraOutputUri != null) {
                    File f = new File(cameraOutputUri.getPath() == null ? "" : cameraOutputUri.getPath());
                    // The URI is returned directly; WebView can read it through FileProvider grants.
                    results = new Uri[]{cameraOutputUri};
                } else if (data != null) {
                    Uri uri = data.getData();
                    if (uri != null) results = new Uri[]{uri};
                    else if (data.getClipData() != null) {
                        ClipData clip = data.getClipData();
                        results = new Uri[clip.getItemCount()];
                        for (int i = 0; i < clip.getItemCount(); i++) results[i] = clip.getItemAt(i).getUri();
                    }
                }
            }
            finishFileSelection(results);
        }
    }

    private void finishFileSelection(Uri[] results) {
        if (uploadCallback != null) {
            uploadCallback.onReceiveValue(results);
            uploadCallback = null;
        }
        cameraOutputUri = null;
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
