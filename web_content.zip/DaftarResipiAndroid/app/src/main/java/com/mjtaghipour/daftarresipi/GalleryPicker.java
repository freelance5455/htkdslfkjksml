package com.mjtaghipour.daftarresipi;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

/**
 * Dedicated gallery opener. Finds every installed photo app that can pick an image
 * (Google Photos, Xiaomi/Redmi Gallery, Samsung Gallery, Files...) and shows them in one chooser.
 * Google Photos is listed first when installed.
 */
public final class GalleryPicker {
    private GalleryPicker() {}

    private static final String[] PREFERRED = {
            "com.google.android.apps.photos",
            "com.miui.gallery",
            "com.google.android.apps.photosgo",
            "com.sec.android.gallery3d",
            "com.android.gallery3d",
            "com.android.gallery"
    };

    private static Intent pickIntent() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        i.setType("image/*");
        return i;
    }

    private static Intent getContentIntent() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        return i;
    }

    private static Intent documentIntent() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        return i;
    }

    private static int rank(String pkg) {
        for (int i = 0; i < PREFERRED.length; i++) if (PREFERRED[i].equals(pkg)) return i;
        return PREFERRED.length;
    }

    /** Opens the photo picker. Returns true if some screen was launched. */
    public static boolean launch(Activity activity, int requestCode) {
        PackageManager pm = activity.getPackageManager();
        List<Intent> explicit = new ArrayList<Intent>();
        List<String> seen = new ArrayList<String>();
        Intent[] bases = {pickIntent(), getContentIntent()};
        for (Intent base : bases) {
            List<ResolveInfo> infos;
            try { infos = pm.queryIntentActivities(base, 0); } catch (Exception e) { continue; }
            if (infos == null) continue;
            for (ResolveInfo ri : infos) {
                if (ri.activityInfo == null || !ri.activityInfo.exported) continue;
                String key = ri.activityInfo.packageName + "/" + ri.activityInfo.name;
                if (seen.contains(key)) continue;
                seen.add(key);
                Intent e = new Intent(base);
                e.setComponent(new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name));
                explicit.add(e);
            }
        }
        // Google Photos / phone gallery first
        java.util.Collections.sort(explicit, new java.util.Comparator<Intent>() {
            @Override public int compare(Intent a, Intent b) {
                return rank(a.getComponent().getPackageName()) - rank(b.getComponent().getPackageName());
            }
        });

        // 1) One chooser with all photo apps found
        try {
            Intent chooser = Intent.createChooser(getContentIntent(), "انتخاب عکس از گالری");
            if (!explicit.isEmpty()) {
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, explicit.toArray(new Intent[0]));
            }
            activity.startActivityForResult(chooser, requestCode);
            return true;
        } catch (Exception ignored) {}

        // 2) Each app directly, then the generic intents
        List<Intent> tries = new ArrayList<Intent>(explicit);
        tries.add(pickIntent());
        tries.add(getContentIntent());
        tries.add(documentIntent());
        for (Intent it : tries) {
            try {
                activity.startActivityForResult(it, requestCode);
                return true;
            } catch (Exception ignored) {}
        }
        return false;
    }
}
