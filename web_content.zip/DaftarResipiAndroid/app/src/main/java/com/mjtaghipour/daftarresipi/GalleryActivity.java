package com.mjtaghipour.daftarresipi;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Built-in gallery: lists the phone's photos straight from MediaStore (needs the photos permission),
 * so it does not depend on any system picker. RESULT_FIRST_USER = "use other apps instead".
 */
public class GalleryActivity extends Activity {
    private static final int REQ_PERM = 77;
    private final List<Uri> items = new ArrayList<Uri>();
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LruCache<String, Bitmap> cache;
    private GridView grid;
    private TextView empty;
    private int cell;
    private BaseAdapter adapter;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        cache = new LruCache<String, Bitmap>(((int) (Runtime.getRuntime().maxMemory() / 1024)) / 8) {
            @Override protected int sizeOf(String k, Bitmap v) { return v.getByteCount() / 1024; }
        };
        int w = getResources().getDisplayMetrics().widthPixels;
        cell = w / 3;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(24, 24, 24, 24);
        Button close = new Button(this);
        close.setText("بستن");
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setResult(RESULT_CANCELED); finish(); }
        });
        TextView title = new TextView(this);
        title.setText("یک عکس انتخاب کن");
        title.setTextSize(17);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        Button other = new Button(this);
        other.setText("برنامه‌های دیگر");
        other.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setResult(RESULT_FIRST_USER); finish(); }
        });
        bar.addView(close);
        bar.addView(title, tl);
        bar.addView(other);
        root.addView(bar);

        empty = new TextView(this);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(32, 64, 32, 32);
        empty.setVisibility(View.GONE);
        root.addView(empty);

        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(2);
        grid.setVerticalSpacing(2);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return items.size(); }
            @Override public Object getItem(int i) { return items.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convert, ViewGroup parent) {
                final ImageView iv = convert instanceof ImageView ? (ImageView) convert : new ImageView(GalleryActivity.this);
                iv.setLayoutParams(new AbsListView.LayoutParams(cell, cell));
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setBackgroundColor(Color.LTGRAY);
                final Uri uri = items.get(i);
                final String key = uri.toString();
                iv.setTag(key);
                Bitmap c = cache.get(key);
                if (c != null) { iv.setImageBitmap(c); return iv; }
                iv.setImageBitmap(null);
                pool.execute(new Runnable() {
                    @Override public void run() {
                        final Bitmap bm = thumb(uri);
                        if (bm == null) return;
                        cache.put(key, bm);
                        ui.post(new Runnable() {
                            @Override public void run() { if (key.equals(iv.getTag())) iv.setImageBitmap(bm); }
                        });
                    }
                });
                return iv;
            }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                Intent r = new Intent();
                r.setData(items.get(pos));
                setResult(RESULT_OK, r);
                finish();
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        ensurePermissionThenLoad();
    }

    private String permission() {
        return Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_IMAGES" : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private void ensurePermissionThenLoad() {
        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission()) == PackageManager.PERMISSION_GRANTED) {
            load();
        } else {
            requestPermissions(new String[]{permission()}, REQ_PERM);
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_PERM) return;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) load();
        else {
            Toast.makeText(this, "دسترسی به عکس‌ها داده نشد؛ از برنامه‌های دیگر انتخاب کن.", Toast.LENGTH_LONG).show();
            setResult(RESULT_FIRST_USER);
            finish();
        }
    }

    private void load() {
        pool.execute(new Runnable() {
            @Override public void run() {
                final List<Uri> found = new ArrayList<Uri>();
                Cursor c = null;
                try {
                    c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            new String[]{MediaStore.Images.Media._ID}, null, null,
                            MediaStore.Images.Media.DATE_ADDED + " DESC");
                    if (c != null) {
                        int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                        while (c.moveToNext() && found.size() < 600) {
                            found.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)));
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.close();
                }
                ui.post(new Runnable() {
                    @Override public void run() {
                        items.clear();
                        items.addAll(found);
                        adapter.notifyDataSetChanged();
                        if (items.isEmpty()) {
                            empty.setText("عکسی پیدا نشد. «برنامه‌های دیگر» را بزن.");
                            empty.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }
        });
    }

    private Bitmap thumb(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return null;
            try { BitmapFactory.decodeStream(in, null, o); } finally { in.close(); }
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= cell) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            in = getContentResolver().openInputStream(uri);
            if (in == null) return null;
            try { return BitmapFactory.decodeStream(in, null, o2); } finally { in.close(); }
        } catch (Throwable t) {
            return null;
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }
}
