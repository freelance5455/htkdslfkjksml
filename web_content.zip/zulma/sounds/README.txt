ضع ملفات الصوت هنا: pistol.mp3 rifle.mp3 shotgun.mp3 reload.mp3 zombie.mp3 hurt.mp3 ambient.mp3
