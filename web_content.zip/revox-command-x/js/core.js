'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let tt;const toast=m=>{const t=$('#toast');t.textContent=m;t.className='on';clearTimeout(tt);tt=setTimeout(()=>t.className='',2500)};
const DB={get(k,d){try{const v=localStorage.getItem('rcx:'+k);return v==null?d:JSON.parse(v)}catch(e){return d}},
 set(k,v){try{localStorage.setItem('rcx:'+k,JSON.stringify(v));return true}catch(e){toast('⚠ Storage: '+e.message);return false}}};
const S={lang:'ar',theme:'dark',motion:true,endpoint:'',...DB.get('settings',{})};
const L=(a,e)=>S.lang==='ar'?a:e;
const sz=n=>n<1024?n+' B':n<1048576?(n/1024).toFixed(1)+' KB':(n/1048576).toFixed(1)+' MB';
const log=m=>{const a=DB.get('log',[]);a.unshift({t:Date.now(),m});DB.set('log',a.slice(0,50))};
const dl=(name,data,type)=>{const u=URL.createObjectURL(data instanceof Blob?data:new Blob([data],{type:type||'text/plain'})),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),3000)};
const IC={home:'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M9 22V12h6v10',
game:'M6 12h4 M8 10v4 M15 13h.01 M18 11h.01 M17.3 5H6.7a4 4 0 0 0-3.9 3.1L1.5 15a3 3 0 0 0 5.2 2l1.3-2h8l1.3 2a3 3 0 0 0 5.2-2l-1.3-6.9A4 4 0 0 0 17.3 5z',
chat:'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z',
folder:'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z',
code:'M16 18l6-6-6-6 M8 6l-6 6 6 6',
pen:'M12 19l7-7 3 3-7 7-3-3z M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z M2 2l7.6 7.6',
cpu:'M4 4h16v16H4z M9 9h6v6H9z M9 1v3 M15 1v3 M9 20v3 M15 20v3 M20 9h3 M20 14h3 M1 9h3 M1 14h3',
sliders:'M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6',
bolt:'M13 2L3 14h9l-1 8 10-12h-9z',shield:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'};
const icon=k=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${IC[k]}"/></svg>`;
const SEC={};let CLEAN=[];
function nav(){$('#nav').innerHTML=Object.keys(SEC).map(k=>`<a href="#${k}" data-k="${k}">${icon(SEC[k].ic)}<span>${SEC[k].t()}</span></a>`).join('')}
function route(){
 const h=location.hash.slice(1),id=SEC[h]?h:'home';
 CLEAN.forEach(f=>f());CLEAN=[];
 $$('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.k===id));
 const m=$('#view');m.style.animation='none';void m.offsetWidth;m.style.animation='';m.innerHTML='';
 try{SEC[id].render(m)}catch(e){m.innerHTML=`<div class="card">⚠ ${esc(e.message)}</div>`;console.error(e)}
 window.scrollTo(0,0);
}
function apply(){const d=document.documentElement;d.lang=S.lang;d.dir=S.lang==='ar'?'rtl':'ltr';d.dataset.theme=S.theme;d.classList.toggle('nomo',!S.motion);nav()}
addEventListener('hashchange',route);
addEventListener('error',e=>toast('⚠ '+e.message));
addEventListener('unhandledrejection',e=>toast('⚠ '+((e.reason&&e.reason.message)||e.reason)));
document.addEventListener('click',e=>{const b=e.target.closest('[data-go]');if(b)location.hash=b.dataset.go});
(()=>{let n=0,t=performance.now();const el=$('#fps');(function f(){n++;const x=performance.now();if(x-t>=1000){el.textContent='UI '+n+' fps';n=0;t=x}requestAnimationFrame(f)})()})();
