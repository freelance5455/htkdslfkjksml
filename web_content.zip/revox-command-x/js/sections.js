'use strict';
/* ---------- Dashboard ---------- */
SEC.home={ic:'home',t:()=>L('الرئيسية','Dashboard'),render(m){
 const G=DB.get('games',[]),P=DB.get('projects',[]),lg=DB.get('log',[]);
 const st=(n,l,h)=>`<div class="card" data-go="${h}" style="cursor:pointer"><div class="st">${n}</div><div class="m">${l}</div></div>`;
 m.innerHTML=`<h2>REVOX COMMAND X</h2><div class="g">${st(G.length,L('ألعاب','Games'),'games')}${st(G.filter(x=>x.fav).length,L('مفضلة','Favorites'),'games')}${st(P.length,L('مشاريع','Projects'),'code')}${st(DB.get('designs',[]).length,L('تصاميم','Designs'),'design')}</div>
 <div class="card"><h3>${L('اختصارات','Shortcuts')}</h3><div class="r">${Object.keys(SEC).filter(k=>k!=='home').map(k=>`<button class="s" data-go="${k}">${SEC[k].t()}</button>`).join('')}</div></div>
 <div class="card"><h3>${L('سجل النشاط','Activity log')}</h3>${lg.length?lg.slice(0,10).map(x=>`<div class="row"><span>${esc(x.m)}</span><span class="m">${new Date(x.t).toLocaleString()}</span></div>`).join(''):`<div class="m">${L('لا نشاط بعد','No activity yet')}</div>`}<div class="r"><button class="s" id="cl">${L('مسح السجل','Clear log')}</button></div></div>`;
 $('#cl').onclick=()=>{DB.set('log',[]);route()};
}};
/* ---------- Gaming Center ---------- */
SEC.games={ic:'game',t:()=>L('الألعاب','Games'),render(m){
 const G=DB.get('games',[]);let fav=false,q='';
 const PN={saver:L('توفير بطارية','Battery saver'),balanced:L('متوازن','Balanced'),perf:L('أداء','Performance')};
 m.innerHTML=`<h2>Gaming Center</h2><div class="card"><h3>${L('إضافة لعبة','Add game')}</h3><div class="r"><input id="gn" placeholder="${L('الاسم','Name')}"><input id="gg" placeholder="${L('النوع','Genre')}"><input id="gp" placeholder="${L('المنصة','Platform')}"></div><textarea id="gi" style="min-height:60px;direction:auto;text-align:start" placeholder="${L('معلومات / ملاحظات','Info / notes')}"></textarea><div class="r"><button id="ga">${L('إضافة','Add')}</button><input id="gs" placeholder="${L('بحث','Search')}"><button class="s" id="gf">★</button></div></div><div id="gl"></div>
 <div class="card"><h3>${L('مراقب الأداء','Performance monitor')}</h3><div class="m">${L('يقيس هذا التطبيق وذاكرة المتصفح والبطارية إن توفرت. لا يرفع FPS الألعاب ولا يغيّر إعدادات النظام؛ ملفات الأداء أعلاه مجرد إعدادات تسجّلها لنفسك.','Measures this app, browser memory and battery when exposed. It does not raise game FPS or change system settings; the profiles above are personal notes only.')}</div><div id="mon"></div></div>`;
 function draw(){const f=G.map((g,i)=>[g,i]).filter(([g])=>(!fav||g.fav)&&(g.n+' '+(g.g||'')).toLowerCase().includes(q));
  $('#gl').innerHTML=f.length?f.map(([g,i])=>`<div class="card"><div class="r"><b>${esc(g.n)}</b><span class="m">${esc(g.g||'')} ${esc(g.p||'')}</span><button class="s" data-a="fav" data-i="${i}" style="margin-inline-start:auto">${g.fav?'★':'☆'}</button><button class="s" data-a="del" data-i="${i}">✕</button></div><div class="m">${esc(g.i||'')}</div><div class="r"><select data-a="pre" data-i="${i}">${Object.keys(PN).map(x=>`<option value="${x}"${g.pre===x?' selected':''}>${PN[x]}</option>`).join('')}</select><select data-a="fps" data-i="${i}">${[30,60,90,120].map(x=>`<option${g.fps==x?' selected':''}>${x}</option>`).join('')}</select></div></div>`).join(''):`<div class="m">${L('لا توجد ألعاب بعد. أضف أول لعبة من الأعلى.','No games yet. Add your first game above.')}</div>`}
 const save=()=>{DB.set('games',G);draw()};
 $('#ga').onclick=()=>{const n=$('#gn').value.trim();if(!n)return toast(L('أدخل اسم اللعبة','Enter a game name'));G.push({n,g:$('#gg').value.trim(),p:$('#gp').value.trim(),i:$('#gi').value.trim(),pre:'balanced',fps:60,fav:false});log(L('إضافة لعبة: ','Game added: ')+n);['gn','gg','gp','gi'].forEach(i=>$('#'+i).value='');save()};
 $('#gs').oninput=e=>{q=e.target.value.toLowerCase();draw()};
 $('#gf').onclick=e=>{fav=!fav;e.currentTarget.className=fav?'':'s';draw()};
 $('#gl').onclick=e=>{const b=e.target.closest('button[data-a]');if(!b)return;const i=+b.dataset.i;if(b.dataset.a==='fav')G[i].fav=!G[i].fav;else{log(L('حذف لعبة: ','Game removed: ')+G[i].n);G.splice(i,1)}save()};
 $('#gl').onchange=e=>{const t=e.target,i=+t.dataset.i;if(t.dataset.a==='pre')G[i].pre=t.value;if(t.dataset.a==='fps')G[i].fps=+t.value;DB.set('games',G)};
 const mon=$('#mon'),iv=setInterval(async()=>{let s=$('#fps').textContent;if(performance.memory)s+=' · JS '+sz(performance.memory.usedJSHeapSize);try{const b=await navigator.getBattery();s+=' · 🔋'+Math.round(b.level*100)+'%'}catch(e){}mon.textContent=s},1000);
 CLEAN.push(()=>clearInterval(iv));draw();
}};
/* ---------- AI Assistant ---------- */
const ERR=[[/is not defined/i,'ReferenceError: المتغير غير معرّف أو مكتوب خطأ أو خارج النطاق.','ReferenceError: the variable is undefined, misspelled or out of scope.'],
[/is not a function/i,'TypeError: تستدعي شيئاً ليس دالة؛ تحقق من الاسم ونوع القيمة.','TypeError: you are calling something that is not a function; check the name and value type.'],
[/cannot read|undefined|null/i,'قراءة خاصية من undefined/null؛ تأكد أن الكائن موجود قبل استخدامه (مثلاً ?.).','Reading a property of undefined/null; make sure the object exists first (e.g. use ?.).'],
[/unexpected token|syntaxerror/i,'SyntaxError: قوس أو فاصلة أو اقتباس ناقص/زائد قرب السطر المذكور.','SyntaxError: a missing or extra bracket, comma or quote near the reported line.'],
[/cors/i,'CORS: الخادم لا يسمح بطلبات من هذا الأصل؛ فعّل الترويسات المناسبة في الخادم.','CORS: the server does not allow this origin; enable the right headers server-side.']];
SEC.ai={ic:'chat',t:()=>L('المساعد','AI'),render(m){
 let H=DB.get('chat',[]);
 m.innerHTML=`<h2>AI Assistant</h2><div class="card"><div class="ai" id="ch"></div><textarea id="ci" style="min-height:70px;direction:auto;text-align:start" placeholder="${L('الصق رسالة خطأ أو كوداً…','Paste an error or code…')}"></textarea><div class="r"><button id="cs">${L('إرسال','Send')}</button><button class="s" id="cc">${L('مسح','Clear')}</button><span class="m">${S.endpoint?L('متصل بخادم AI','AI endpoint set'):L('وضع محلي: شرح أخطاء شائعة فقط (ليس AI حقيقياً)','Local mode: common-error hints only (not a real AI)')}</span></div></div>`;
 const draw=()=>{$('#ch').innerHTML=H.map(x=>`<div class="b ${x.r==='u'?'u':'a'}">${esc(x.c)}</div>`).join('');$('#ch').scrollTop=1e9};
 const add=(r,c)=>{H.push({r,c});H=H.slice(-40);DB.set('chat',H);draw()};
 $('#cs').onclick=async()=>{const v=$('#ci').value.trim();if(!v)return;$('#ci').value='';add('u',v);
  if(S.endpoint){try{const c=new AbortController(),to=setTimeout(()=>c.abort(),30000);const r=await fetch(S.endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:H.map(x=>({role:x.r==='u'?'user':'assistant',content:x.c}))}),signal:c.signal});clearTimeout(to);if(!r.ok)throw Error('HTTP '+r.status);const d=await r.json();add('a',d.reply||d.text||JSON.stringify(d))}catch(e){add('a','⚠ '+e.message)}}
  else{const h=ERR.find(x=>x[0].test(v));add('a',h?L(h[1],h[2]):L('لا أملك إجابة محلية لهذا. اضبط عنوان خادم AI آمن من الإعدادات للحصول على مساعدة حقيقية.','No local answer for this. Set a secure AI endpoint in Settings for real help.'))}};
 $('#cc').onclick=()=>{H=[];DB.set('chat',H);draw()};draw();
}};
/* ---------- File Lab ---------- */
SEC.files={ic:'folder',t:()=>L('الملفات','Files'),render(m){
 let F=[];const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join(''),pipe=(b,C,md)=>new Response(b.stream().pipeThrough(new C(md))).blob(),out=h=>{$('#fo').innerHTML=h};
 m.innerHTML=`<h2>File Lab</h2><div class="card"><input type="file" id="fi" multiple><div class="m">${L('الملفات تُحفظ في الذاكرة طوال الجلسة فقط.','Files stay in memory for this session only.')}</div></div><div id="fl"></div><div class="card" id="fo"><span class="m">${L('نتائج العمليات تظهر هنا','Results appear here')}</span></div>`;
 async function zip(f){const ab=await f.arrayBuffer(),b=new DataView(ab);let e=ab.byteLength-22;while(e>=0&&b.getUint32(e,true)!==0x06054b50)e--;if(e<0)throw Error('Not a ZIP');let n=b.getUint16(e+10,true),o=b.getUint32(e+16,true);const r=[];
  while(n--){if(b.getUint32(o,true)!==0x02014b50)break;const l=b.getUint16(o+28,true),x=b.getUint16(o+30,true),c=b.getUint16(o+32,true);r.push({name:new TextDecoder().decode(new Uint8Array(ab,o+46,l)),m:b.getUint16(o+10,true),c:b.getUint32(o+20,true),s:b.getUint32(o+24,true),h:b.getUint32(o+42,true)});o+=46+l+x+c}
  r.get=async z=>{const p=z.h+30+b.getUint16(z.h+26,true)+b.getUint16(z.h+28,true),d=new Blob([ab.slice(p,p+z.c)]);return z.m===0?d:z.m===8?pipe(d,DecompressionStream,'deflate-raw'):Promise.reject(Error('ZIP method '+z.m))};return r}
 const draw=()=>{$('#fl').innerHTML=F.map((f,i)=>`<div class="card"><b style="word-break:break-all">${esc(f.name)}</b><div class="m">${sz(f.size)} · ${esc(f.type||'?')} · ${new Date(f.lastModified).toLocaleDateString()}</div><div class="r">${[['sha','SHA-256'],['pre',L('معاينة','Preview')],['gz','GZip']].concat(/\.zip$/i.test(f.name)?[['zip',L('محتوى ZIP','ZIP')]]:[],/\.gz$/i.test(f.name)?[['gun',L('فك GZip','Un-GZip')]]:[]).map(([a,t])=>`<button class="s" data-a="${a}" data-i="${i}">${t}</button>`).join('')}<button class="s" data-a="rm" data-i="${i}">✕</button></div></div>`).join('')};
 $('#fi').onchange=e=>{F=F.concat([...e.target.files]);log(L('استيراد ملفات: ','Files imported: ')+e.target.files.length);draw()};
 $('#fl').onclick=async e=>{const b=e.target.closest('button');if(!b)return;const i=+b.dataset.i,f=F[i],a=b.dataset.a;try{
  if(a==='rm'){F.splice(i,1);draw()}
  if(a==='sha'){if(!(window.crypto&&crypto.subtle))throw Error(L('SHA-256 يتطلب سياقاً آمناً (https). راجع README.','SHA-256 needs a secure context (https). See README.'));out(`<b>SHA-256</b><div class="m" style="word-break:break-all;direction:ltr">${hex(await crypto.subtle.digest('SHA-256',await f.arrayBuffer()))}</div>`)}
  if(a==='pre'){if(f.type.startsWith('image/'))out(`<img src="${URL.createObjectURL(f)}" style="max-width:100%">`);else if(/^text\/|json|xml|javascript/.test(f.type)||/\.(txt|md|js|css|html|json|csv|xml)$/i.test(f.name))out(`<pre style="white-space:pre-wrap;word-break:break-all;direction:ltr">${esc(await f.slice(0,5000).text())}</pre>`);else out(L('نوع غير مدعوم للمعاينة','Preview not supported for this type'))}
  if(a==='gz')dl(f.name+'.gz',await pipe(f,CompressionStream,'gzip'));
  if(a==='gun')dl(f.name.replace(/\.gz$/i,'')||'out',await pipe(f,DecompressionStream,'gzip'));
  if(a==='zip'){const z=await zip(f);out(z.map((x,j)=>`<div class="row"><span>${esc(x.name)}</span><span>${sz(x.s)} ${x.name.endsWith('/')?'':`<button class="s" data-z="${j}">⬇</button>`}</span></div>`).join('')||L('ZIP فارغ','Empty ZIP'));
   $('#fo').onclick=async ev=>{const q=ev.target.closest('[data-z]');if(q)try{const x=z[+q.dataset.z];dl(x.name.split('/').pop(),await z.get(x))}catch(er){toast('⚠ '+er.message)}}}
 }catch(er){toast('⚠ '+er.message)}};
 draw();
}};
/* ---------- Code Studio ---------- */
SEC.code={ic:'code',t:()=>L('الكود','Code'),render(m){
 let P=DB.get('projects',[]),cur=P.length?0:-1;const K=['html','css','js'];
 const ST={name:'untitled',html:'<h1>Hello REVOX</h1>',css:'body{font-family:sans-serif;background:#05060d;color:#00f0ff;text-align:center}',js:'document.querySelector("h1").onclick=e=>e.target.textContent="OK"'};
 let p={...(cur>=0?P[0]:ST)};
 const RE={js:/(\/\*[\s\S]*?\*\/|\/\/.*)|("(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|`(?:[^`\\]|\\.)*`)|\b(const|let|var|function|return|if|else|for|while|class|new|async|await|true|false|null|undefined)\b/g,
  css:/(\/\*[\s\S]*?\*\/)|("[^"]*"|'[^']*')|([.#]?[\w-]+(?=\s*[:{]))/g,html:/(<!--[\s\S]*?-->)|("[^"]*"|'[^']*')|(<\/?[\w-]+)/g};
 const hl=(c,l)=>{const re=new RegExp(RE[l]);let o='',i=0,x;while((x=re.exec(c))){o+=esc(c.slice(i,x.index))+`<span class="${x[1]?'c1':x[2]?'s1':'k'}">${esc(x[0])}</span>`;i=re.lastIndex}return o+esc(c.slice(i))+'\n'};
 const doc=()=>`<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${p.css}</style></head><body>${p.html}<script>onerror=function(m,s,l){parent.postMessage({rcx:m+' (line '+l+')'},'*')};<\/script><script>${p.js}<\/script></body></html>`;
 const chk=()=>{const r=[];try{new Function(p.js)}catch(e){r.push('JS: '+e.message)}
  const o=(p.html.match(/<(?!\/|!|br|hr|img|input|meta|link)[a-z][\w-]*/gi)||[]).length,c=(p.html.match(/<\/[a-z][\w-]*/gi)||[]).length;if(o!==c)r.push(L(`HTML: ${o} وسم مفتوح مقابل ${c} مغلق`,`HTML: ${o} opening vs ${c} closing tags`));
  if((p.css.match(/{/g)||[]).length!==(p.css.match(/}/g)||[]).length)r.push(L('CSS: الأقواس {} غير متوازنة','CSS: unbalanced braces'));return r};
 m.innerHTML=`<h2>Code Studio</h2><div class="card"><div class="r"><select id="ps"></select><input id="pn" style="flex:1;min-width:90px"><button id="pw">💾</button><button class="s" id="pnew">＋</button><button class="s" id="pd">🗑</button><button class="s" id="px">⬇ HTML</button></div>
 <div class="r" id="tb">${K.map(k=>`<button class="s" data-t="${k}">${k.toUpperCase()}</button>`).join('')}<button id="pr">▶ ${L('تشغيل','Run')}</button><button class="s" id="pc">${L('فحص','Check')}</button></div>
 ${K.map(k=>`<div class="ed" id="e-${k}"><pre></pre><textarea spellcheck="false" autocapitalize="off"></textarea></div>`).join('')}<div id="er" class="m" style="white-space:pre-wrap"></div></div><iframe id="fr" sandbox="allow-scripts" title="preview"></iframe>`;
 const ed=k=>$('#e-'+k+' textarea'),paint=k=>{$('#e-'+k+' pre').innerHTML=hl(ed(k).value,k)};
 const load=()=>{$('#ps').innerHTML=P.map((x,i)=>`<option value="${i}"${i===cur?' selected':''}>${esc(x.name)}</option>`).join('')||'<option>—</option>';$('#pn').value=p.name;K.forEach(k=>{ed(k).value=p[k];paint(k)})};
 const show=k=>K.forEach(x=>$('#e-'+x).style.display=x===k?'':'none');
 const run=()=>{$('#er').textContent='';$('#fr').srcdoc=doc()};
 K.forEach(k=>{const t=ed(k);t.oninput=()=>{p[k]=t.value;paint(k)};t.onscroll=()=>{const r=$('#e-'+k+' pre');r.scrollTop=t.scrollTop;r.scrollLeft=t.scrollLeft}});
 $('#tb').onclick=e=>{const b=e.target.closest('[data-t]');if(b)show(b.dataset.t)};
 $('#pn').oninput=e=>{p.name=e.target.value};
 $('#ps').onchange=e=>{if(!P.length)return;cur=+e.target.value;p={...P[cur]};load();run()};
 $('#pw').onclick=()=>{p.name=$('#pn').value.trim()||'untitled';if(cur<0){P.push({...p});cur=P.length-1}else P[cur]={...p};if(DB.set('projects',P)){log(L('حفظ مشروع: ','Project saved: ')+p.name);toast(L('تم الحفظ','Saved'))}load()};
 $('#pnew').onclick=()=>{cur=-1;p={...ST};load();run()};
 $('#pd').onclick=()=>{if(cur<0)return toast(L('المشروع غير محفوظ','Project is not saved'));log(L('حذف مشروع: ','Project deleted: ')+p.name);P.splice(cur,1);DB.set('projects',P);cur=P.length?0:-1;p={...(cur>=0?P[cur]:ST)};load();run()};
 $('#px').onclick=()=>dl((p.name||'project')+'.html',doc(),'text/html');
 $('#pr').onclick=run;
 $('#pc').onclick=()=>{const r=chk();$('#er').textContent=r.length?r.join('\n'):L('✓ لم تُكتشف أخطاء أساسية','✓ No basic errors found')};
 const mh=e=>{if(e.data&&e.data.rcx)$('#er').textContent+='⚠ '+e.data.rcx+'\n'};addEventListener('message',mh);CLEAN.push(()=>removeEventListener('message',mh));
 show('html');load();run();
}};
/* ---------- Design Lab ---------- */
let uid=0;const rnd=s=>()=>(s=s*16807%2147483647)/2147483647;
const SHP={hex:'M256 40l190 108v216L256 472 66 364V148z',diamond:'M256 30l226 226-226 226L30 256z'};
function svg(d){const id='g'+(++uid),df=`<defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${d.c1}"/><stop offset="1" stop-color="${d.c2}"/></linearGradient></defs>`,X='xmlns="http://www.w3.org/2000/svg"';
 if(d.mode==='bg'){const r=rnd(d.seed||1);let s='';for(let i=0;i<14;i++)s+=`<circle cx="${r()*360|0}" cy="${r()*640|0}" r="${(20+r()*90)|0}" fill="${r()>.5?d.c1:d.c2}" opacity=".2"/>`;return `<svg ${X} viewBox="0 0 360 640">${df}<rect width="360" height="640" fill="#05060d"/><rect width="360" height="640" fill="url(#${id})" opacity=".4"/>${s}</svg>`}
 const A=`fill="url(#${id})" stroke="${d.c1}" stroke-width="6"`,sh=d.shape==='circle'?`<circle cx="256" cy="256" r="216" ${A}/>`:d.shape==='round'?`<rect x="40" y="40" width="432" height="432" rx="96" ${A}/>`:`<path d="${SHP[d.shape]}" ${A}/>`;
 const t=d.mode==='icon'?`<g transform="translate(136 136) scale(10)" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${IC[d.ic]}"/></g>`:`<text x="256" y="256" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-weight="800" font-size="${Math.min(180,(380/Math.max(1,d.text.length)*1.5)|0)}" fill="#fff">${esc(d.text)}</text>`;
 return `<svg ${X} viewBox="0 0 512 512"><rect width="512" height="512" fill="#05060d"/>${df}${sh}${t}</svg>`}
const PRE=[{mode:'logo',text:'RX',c1:'#00f0ff',c2:'#a855f7',shape:'hex',ic:'bolt',seed:7},{mode:'logo',text:'REVOX',c1:'#ff00aa',c2:'#00f0ff',shape:'round',ic:'bolt',seed:7},{mode:'icon',text:'',c1:'#a855f7',c2:'#00f0ff',shape:'circle',ic:'game',seed:7},{mode:'icon',text:'',c1:'#00f0ff',c2:'#0a0a2a',shape:'diamond',ic:'code',seed:7},{mode:'bg',text:'',c1:'#00f0ff',c2:'#a855f7',shape:'hex',ic:'bolt',seed:21},{mode:'bg',text:'',c1:'#ff00aa',c2:'#4400ff',shape:'hex',ic:'bolt',seed:99}];
SEC.design={ic:'pen',t:()=>L('التصميم','Design'),render(m){
 let d={...PRE[0]},D=DB.get('designs',[]),cur=-1;
 const op=a=>a.map(x=>`<option>${x}</option>`).join('');
 m.innerHTML=`<h2>Design Lab</h2><div class="card"><div id="pv"></div><div class="r"><select id="dm">${['logo','icon','bg'].map(x=>`<option value="${x}">${{logo:L('شعار','Logo'),icon:L('أيقونة','Icon'),bg:L('خلفية','Wallpaper')}[x]}</option>`).join('')}</select><input id="dt" maxlength="12" size="8"><input type="color" id="d1"><input type="color" id="d2"><select id="ds">${op(['hex','circle','round','diamond'])}</select><select id="di">${op(Object.keys(IC))}</select><button class="s" id="dr">🎲</button></div><div class="r"><button id="dv">💾 ${L('حفظ','Save')}</button><button class="s" id="dd">🗑</button><button class="s" id="dx">SVG</button><button class="s" id="dp">PNG</button></div></div><div class="card"><h3>${L('قوالب جاهزة','Templates')}</h3><div class="r" id="tp"></div></div><div class="card"><h3>${L('محفوظاتي','Saved')}</h3><div class="r" id="sv"></div></div>`;
 const th=(a,k)=>a.map((x,i)=>`<div class="th" data-${k}="${i}">${svg(x)}</div>`).join('');
 const draw=()=>{$('#pv').innerHTML=svg(d).replace('<svg','<svg class="pv"');$('#tp').innerHTML=th(PRE,'p');$('#sv').innerHTML=D.length?th(D,'s'):`<span class="m">${L('لا تصاميم محفوظة','Nothing saved yet')}</span>`};
 const sync=()=>{$('#dm').value=d.mode;$('#dt').value=d.text;$('#d1').value=d.c1;$('#d2').value=d.c2;$('#ds').value=d.shape;$('#di').value=d.ic;draw()};
 const rd=()=>{d={...d,mode:$('#dm').value,text:$('#dt').value,c1:$('#d1').value,c2:$('#d2').value,shape:$('#ds').value,ic:$('#di').value};draw()};
 ['dm','dt','d1','d2','ds','di'].forEach(i=>{$('#'+i).oninput=rd;$('#'+i).onchange=rd});
 const pick=e=>{const t=e.target.closest('.th');if(!t)return;if(t.dataset.p!=null){d={...PRE[+t.dataset.p]};cur=-1}else{cur=+t.dataset.s;d={...D[cur]}}sync()};
 $('#tp').onclick=pick;$('#sv').onclick=pick;
 $('#dr').onclick=()=>{const r=rnd(Date.now()%2147483646+1),c=()=>'#'+[0,0,0].map(()=>((r()*200+55)|0).toString(16).padStart(2,'0')).join('');d={...d,c1:c(),c2:c(),seed:(r()*1e6)|0};sync()};
 $('#dv').onclick=()=>{D.push({...d});DB.set('designs',D);log(L('حفظ تصميم','Design saved'));draw()};
 $('#dd').onclick=()=>{if(cur<0)return toast(L('اختر تصميماً محفوظاً أولاً','Select a saved design first'));D.splice(cur,1);cur=-1;DB.set('designs',D);draw()};
 $('#dx').onclick=()=>dl('revox-'+d.mode+'.svg',svg(d),'image/svg+xml');
 $('#dp').onclick=()=>{const i=new Image(),w=d.mode==='bg'?1080:1024,h=d.mode==='bg'?1920:1024;i.onload=()=>{const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(i,0,0,w,h);c.toBlob(b=>dl('revox-'+d.mode+'.png',b),'image/png')};i.onerror=()=>toast(L('تعذّر التصدير','Export failed'));i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg(d))};
 sync();
}};
/* ---------- Device Center ---------- */
SEC.device={ic:'cpu',t:()=>L('الجهاز','Device'),async render(m){
 const n=navigator,c=n.connection||{};
 const rows=[['User-Agent',n.userAgent],[L('المنصة','Platform'),(n.userAgentData&&n.userAgentData.platform)||n.platform],[L('اللغة','Language'),n.language],[L('الشاشة','Screen'),`${screen.width}×${screen.height} @${devicePixelRatio}x`],[L('النافذة','Viewport'),`${innerWidth}×${innerHeight}`],[L('أنوية المعالج','CPU cores'),n.hardwareConcurrency||'?'],[L('ذاكرة تقريبية','Approx. RAM'),n.deviceMemory?n.deviceMemory+' GB':'?'],[L('الشبكة','Network'),(n.onLine?'online':'offline')+(c.effectiveType?' · '+c.effectiveType:'')],[L('نقاط اللمس','Touch points'),n.maxTouchPoints],[L('مظهر النظام','System theme'),matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light']];
 try{const e=await n.storage.estimate();rows.push([L('حصة تخزين المتصفح','Browser storage quota'),sz(e.usage)+' / '+sz(e.quota)])}catch(e){}
 try{const b=await n.getBattery();rows.push([L('البطارية','Battery'),Math.round(b.level*100)+'%'+(b.charging?' ⚡':'')])}catch(e){}
 m.innerHTML=`<h2>Device Center</h2><div class="card">${rows.map(([k,v])=>`<div class="row"><b>${k}</b><span dir="ltr">${esc(v)}</span></div>`).join('')}</div><div class="card m">${L('هذه القيم يوفرها المتصفح/WebView فقط. لا يمكن لصفحة ويب قراءة المساحة الحرة الحقيقية للجهاز أو قائمة التطبيقات أو أي بيانات يمنعها Android.','These values come only from the browser/WebView. A web page cannot read real free disk space, installed apps, or anything Android blocks.')}</div>`;
}};
/* ---------- Settings ---------- */
SEC.set={ic:'sliders',t:()=>L('الإعدادات','Settings'),render(m){
 m.innerHTML=`<h2>${L('الإعدادات','Settings')}</h2><div class="card">
 <div class="row"><span>${L('اللغة','Language')}</span><select id="sl"><option value="ar">العربية</option><option value="en">English</option></select></div>
 <div class="row"><span>${L('المظهر','Theme')}</span><select id="st"><option value="dark">Dark</option><option value="light">Light</option></select></div>
 <div class="row"><span>${L('الحركة','Animations')}</span><input type="checkbox" id="sm"></div>
 <div class="row"><span>AI endpoint</span><input id="se" dir="ltr" placeholder="https://your-server/chat"></div>
 <div class="m">${L('لا تضع مفاتيح API هنا. استخدم خادماً وسيطاً يحتفظ بالمفتاح ويستقبل {messages} ويرجع {reply}.','Never put API keys here. Use your own proxy that holds the key, accepts {messages} and returns {reply}.')}</div>
 <div class="r"><button id="sa">${L('حفظ','Save')}</button></div></div>
 <div class="card"><div class="r"><button class="s" id="ex">${L('تصدير البيانات','Export data')}</button><label class="m">${L('استيراد','Import')} <input type="file" id="im" accept=".json"></label><button class="s" id="rs">${L('مسح كل البيانات','Reset all')}</button></div></div>`;
 $('#sl').value=S.lang;$('#st').value=S.theme;$('#sm').checked=S.motion;$('#se').value=S.endpoint;
 $('#sa').onclick=()=>{const u=$('#se').value.trim();if(u&&!/^https:\/\//i.test(u))return toast(L('العنوان يجب أن يبدأ بـ https://','URL must start with https://'));Object.assign(S,{lang:$('#sl').value,theme:$('#st').value,motion:$('#sm').checked,endpoint:u});DB.set('settings',S);apply();route();toast(L('تم الحفظ','Saved'))};
 const keys=()=>Object.keys(localStorage).filter(k=>k.startsWith('rcx:'));
 $('#ex').onclick=()=>{const o={};keys().forEach(k=>o[k]=localStorage.getItem(k));dl('revox-backup.json',JSON.stringify(o),'application/json')};
 $('#im').onchange=async e=>{try{const o=JSON.parse(await e.target.files[0].text());Object.keys(o).forEach(k=>{if(k.startsWith('rcx:')&&typeof o[k]==='string')localStorage.setItem(k,o[k])});location.reload()}catch(er){toast('⚠ '+er.message)}};
 let arm=0;$('#rs').onclick=()=>{if(!arm){arm=1;toast(L('اضغط مرة أخرى للتأكيد','Tap again to confirm'));setTimeout(()=>arm=0,3000)}else{keys().forEach(k=>localStorage.removeItem(k));location.reload()}};
}};
apply();route();
