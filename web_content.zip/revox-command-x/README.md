# REVOX COMMAND X

تطبيق ويب (HTML/CSS/JS بدون مكتبات خارجية) يعمل داخل Android WebView.
الأقسام: Dashboard · Gaming Center · AI Assistant · File Lab · Code Studio · Design Lab · Device Center · Settings.

## التشغيل
- في المتصفح: افتح `index.html` مباشرة، أو شغّل `python3 -m http.server` ثم افتح `http://localhost:8000`.
- كل البيانات تُحفظ في `localStorage` (مفاتيحها تبدأ بـ `rcx:`). يمكن تصديرها/استيرادها من الإعدادات.

## التحويل إلى APK
**الخيار 1: Android Studio + WebView**
1. أنشئ مشروعاً، وانسخ محتوى هذا المجلد إلى `app/src/main/assets/`.
2. أضف `androidx.webkit:webkit` وحمّل الصفحة عبر `WebViewAssetLoader` على `https://appassets.androidplatform.net/assets/index.html` (سياق آمن، يلزم لـ SHA-256).
3. فعّل: `settings.javaScriptEnabled = true` و `settings.domStorageEnabled = true`.
4. التنزيلات (تصدير الملفات) تستخدم Blob: أضف `DownloadListener` يعالج روابط `blob:`، وإلا لن تُحفظ الملفات.

**الخيار 2: Capacitor** — `npm i @capacitor/core @capacitor/cli @capacitor/android`، ثم `npx cap init`، واجعل `webDir` يشير لهذا المجلد، ثم `npx cap add android` و `npx cap open android`.

## الحدود التقنية (بصراحة)
- **المساعد الذكي**: بدون خادم يعمل في وضع محلي يشرح أخطاء JavaScript الشائعة فقط. للاتصال بـ AI حقيقي أنشئ خادماً وسيطاً (https) يحتفظ بالمفتاح، يستقبل `POST {messages:[{role,content}]}` ويرجع `{reply}`، ثم ضع عنوانه في الإعدادات. لا توجد مفاتيح داخل الكود.
- **الألعاب**: القسم مكتبة وملاحظات؛ ملفات الأداء (توفير/متوازن/أداء، FPS مستهدف) مجرد تسجيل شخصي ولا تغيّر النظام. المراقب يقيس هذا التطبيق فقط.
- **File Lab**: الملفات في الذاكرة طوال الجلسة. ZIP: عرض المحتوى واستخراج ملف بملف (الطريقتان stored/deflate، بدون ZIP64 أو تشفير). الضغط المتاح GZip؛ إنشاء ZIP غير منفّذ. الضغط/الفك يحتاجان `CompressionStream` (WebView حديث).
- **Device Center**: ما يوفره المتصفح فقط؛ لا مساحة تخزين حقيقية للجهاز ولا قائمة تطبيقات. ظهور البطارية والذاكرة يعتمد على دعم WebView.
- **Code Studio**: المعاينة داخل iframe معزول (`sandbox="allow-scripts"`) فلا تعمل `alert` ولا الوصول لبيانات التطبيق. الفحص أساسي (صياغة JS، توازن أقواس CSS، عدّ وسوم HTML) وليس محلل شامل.
- **الخطوط**: خطوط النظام (لا ملفات خطوط). **الأيقونات**: SVG مدمجة في `js/core.js`.

## الهيكل
`index.html` · `css/style.css` · `js/core.js` (نواة: تخزين، تنقل، إعدادات) · `js/sections.js` (الأقسام) · `assets/icon.svg`
لإضافة قسم: عرّف `SEC.name={ic,t,render(el)}` في `sections.js`.
