# Calculadora de Iluminación de Emergencia (NFPA 101 / COVENIN)

Este documento te permite entender los cálculos necesarios para diseñar tu sistema de iluminación.

## 1. Fórmulas de Conversión Básicas
* **Lúmenes (lm) a Lux (lx):** $Lux = \frac{Lúmenes}{Área (m^2)}$
* **Lux (lx) a Pie-Candela (fc):** $Pie-Candela = \frac{Lux}{10.76}$ o $Lux = fc \times 10.76$
* **Intensidad (Candelas) y Distancia:** $Lux = \frac{Candelas}{Distancia^2}$

## 2. Ejemplo Práctico de Simulación (Lámpara de Emergencia Estándar)
* **Potencia de la Lámpara:** 5 Vatios (LED de alta eficiencia)
* **Eficiencia Lumínica:** 100 lúmenes por vatio $\rightarrow$ **Total Lúmenes:** 500 lm
* **Capacidad de la Batería:** 12V 4.5Ah (54 Vatios-hora)
* **Tiempo de Duración Estimado:** 54 Wh / 5W = **10.8 horas** (Cumple con creces los 90 minutos de la norma).
* **Área Iluminada Estimada a nivel del suelo (a 2.5m de altura con ángulo de 60°):** ~12.5 metros cuadrados.
* **Alcance en Línea Recta:** ~7 metros hacia el frente garantizando el mínimo de la norma COVENIN (15 lux a 3 metros).

---
*Nota: Este archivo fue generado automáticamente para servir como guía de referencia de ingeniería rápida.*
