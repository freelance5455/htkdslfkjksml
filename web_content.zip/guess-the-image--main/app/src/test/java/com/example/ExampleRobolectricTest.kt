package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DailyChallenges
import com.example.data.GAME_LEVELS
import com.example.data.QUIZ_ITEMS
import com.example.data.getDailyStreakMultiplier
import com.example.data.getEffectiveDailyStreak
import com.example.data.getTodayDateString
import com.example.model.QuizItem
import com.example.model.UserStats
import com.example.storage.GamePreferences
import com.example.ui.components.TileLetter
import com.example.viewmodel.GameViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Guess The Image", appName)
    }

    @Test
    fun `verify quiz catalog integrity`() {
        assertTrue("Quiz catalog should have at least 25 items", QUIZ_ITEMS.size >= 25)
        QUIZ_ITEMS.forEach { item ->
            assertFalse("Clean answer cannot be empty for ${item.id}", item.cleanAnswer.isEmpty())
            assertTrue("Zoom coordinates must be valid for ${item.id}", item.zoom.x in 0f..100f && item.zoom.y in 0f..100f)
            assertNotNull("Hints must exist for ${item.id}", item.hints.clue1)
            assertTrue("Level must be between 1 and 7", item.level in 1..7)
        }
    }

    @Test
    fun `verify level progression configuration`() {
        assertEquals(7, GAME_LEVELS.size)
        assertEquals(1, GAME_LEVELS.first().levelNumber)
        assertEquals(7, GAME_LEVELS.last().levelNumber)
        assertTrue(GAME_LEVELS.last().requiredScore > GAME_LEVELS.first().requiredScore)
    }

    @Test
    fun `verify daily streak multipliers`() {
        val info0 = getDailyStreakMultiplier(0)
        assertEquals(1.0f, info0.multiplier)

        val info1 = getDailyStreakMultiplier(1)
        assertEquals(1.1f, info1.multiplier)

        val info7 = getDailyStreakMultiplier(7)
        assertTrue("7-day streak multiplier should be >= 1.75f", info7.multiplier >= 1.75f)

        val info14 = getDailyStreakMultiplier(14)
        assertEquals(2.0f, info14.multiplier)
    }

    @Test
    fun `verify game preferences persistence`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = GamePreferences(context)
        val initialStats = prefs.loadStats()
        assertNotNull(initialStats)

        val updatedStats = initialStats.copy(score = 1200, coins = 350, currentLevel = 2, streak = 5)
        prefs.saveStats(updatedStats)

        val reloadedStats = prefs.loadStats()
        assertEquals(1200, reloadedStats.score)
        assertEquals(350, reloadedStats.coins)
        assertEquals(2, reloadedStats.currentLevel)
        assertEquals(5, reloadedStats.streak)
    }

    @Test
    fun `verify game viewmodel initialization and tile interaction`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = GameViewModel(app)
        val state = vm.uiState.value

        assertNotNull(state.currentItem)
        assertEquals(state.currentItem.cleanAnswer.length, state.placedLetters.size)
        assertEquals(14, state.keyboardTiles.size)

        // Simulate clicking an available tile
        val availableTile = state.keyboardTiles.first { !it.isUsed }
        vm.onTileClick(availableTile)

        val updatedState = vm.uiState.value
        assertEquals(availableTile.char, updatedState.placedLetters.first())
        assertTrue(updatedState.keyboardTiles.first { it.id == availableTile.id }.isUsed)

        // Backspace
        vm.onBackspace()
        assertEquals(null, vm.uiState.value.placedLetters.first())
        assertFalse(vm.uiState.value.keyboardTiles.first { it.id == availableTile.id }.isUsed)
    }
}

