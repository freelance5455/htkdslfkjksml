package com.example.data

import com.example.model.LevelInfo

val GAME_LEVELS = listOf(
    LevelInfo(
        levelNumber = 1,
        title = "Starter Icons",
        theme = "Legendary Logos",
        requiredScore = 0,
        requiredSolved = 0,
        badge = "🔥",
        description = "Iconic global symbols every internet citizen knows. Get ready to zoom in!"
    ),
    LevelInfo(
        levelNumber = 2,
        title = "Tech & Mobile Titans",
        theme = "Digital Ecosystems",
        requiredScore = 1200,
        requiredSolved = 4,
        badge = "📱",
        description = "The hardware and operating systems powering billions of handhelds."
    ),
    LevelInfo(
        levelNumber = 3,
        title = "Top YouTubers",
        theme = "Creator Legends",
        requiredScore = 3000,
        requiredSolved = 8,
        badge = "🎬",
        description = "Channel emblems of YouTube icons who command hundreds of millions of views."
    ),
    LevelInfo(
        levelNumber = 4,
        title = "Supercars & Autos",
        theme = "Horsepower Badges",
        requiredScore = 5500,
        requiredSolved = 12,
        badge = "🏎️",
        description = "Prancing stallions, raging bulls, and iconic emblems forged in steel."
    ),
    LevelInfo(
        levelNumber = 5,
        title = "Fashion & Streetwear",
        theme = "Runway & Culture",
        requiredScore = 8500,
        requiredSolved = 16,
        badge = "✨",
        description = "Luxury houses and hype streetwear brands recognizable from a single stitch."
    ),
    LevelInfo(
        levelNumber = 6,
        title = "Apps & Gaming Arena",
        theme = "Virtual Worlds",
        requiredScore = 12000,
        requiredSolved = 20,
        badge = "🎮",
        description = "Blocky universes, social feeds, and digital realms that dominate gaming."
    ),
    LevelInfo(
        levelNumber = 7,
        title = "Master Mystery",
        theme = "Extreme Zoom Elite",
        requiredScore = 16000,
        requiredSolved = 25,
        badge = "👑",
        description = "Microscopic crops and ultra-close examinations for true master guessers."
    )
)
