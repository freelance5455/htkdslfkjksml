package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.DailyChallenges
import com.example.model.QuizItem
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameOrange
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DailyChallengeDialog(
    dailyItem: QuizItem,
    isCompletedToday: Boolean,
    streakDays: Int,
    multiplierLabel: String,
    onPlayDaily: () -> Unit,
    onDismiss: () -> Unit
) {
    val dateString = DailyChallenges.getTodayDateString()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(2.dp, GameViolet.copy(alpha = 0.6f), RoundedCornerShape(28.dp))
                .testTag("daily_challenge_dialog"),
            color = GameDarkBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = Color(0xFFE879F9),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DAILY CHALLENGE",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Streak Multiplier Hero Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF231336),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF6B21A8))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = null,
                                tint = GameOrange,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$streakDays Day Streak",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Active Score Multiplier: $multiplierLabel",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = GameAmberBright
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Streak ladder indicator (1d -> 2d -> 3d -> 5d -> 7d)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StreakStep(day = "1d", mult = "1.0x", reached = streakDays >= 1)
                            StreakStep(day = "2d", mult = "1.25x", reached = streakDays >= 2)
                            StreakStep(day = "3d", mult = "1.5x", reached = streakDays >= 3)
                            StreakStep(day = "5d", mult = "1.75x", reached = streakDays >= 5)
                            StreakStep(day = "7d+", mult = "2.0x", reached = streakDays >= 7)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Mystery Daily Challenge Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = GameSurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26334D))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isCompletedToday) GameEmerald.copy(alpha = 0.2f) else Color(0xFF22163A)
                                )
                                .border(
                                    1.dp,
                                    if (isCompletedToday) GameEmerald else Color(0xFF6B21A8),
                                    RoundedCornerShape(12.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCompletedToday) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = GameEmerald,
                                    modifier = Modifier.size(24.dp)
                                )
                            } else {
                                Text("🎯", fontSize = 22.sp)
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Today's Puzzle ($dateString)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (isCompletedToday) "Completed! Streak protected" else "Category: ${dailyItem.categoryLabel}",
                                fontSize = 11.sp,
                                color = if (isCompletedToday) GameEmerald else TextSecondary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GameAmber.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "+100 🪙",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = GameAmberBright,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        onPlayDaily()
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("play_daily_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCompletedToday) Color(0xFF222F47) else GameViolet,
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        text = if (isCompletedToday) "Replay Daily Puzzle" else "Play Today's Challenge",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StreakStep(
    day: String,
    mult: String,
    reached: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(if (reached) GameAmber else Color(0xFF1B2438))
                .border(1.dp, if (reached) GameAmberBright else Color(0xFF334155), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (reached) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = Color(0xFF0F172A),
                    modifier = Modifier.size(14.dp)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF64748B))
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(day, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (reached) Color.White else TextMuted)
        Text(mult, fontSize = 8.sp, color = if (reached) GameAmberBright else TextMuted)
    }
}
