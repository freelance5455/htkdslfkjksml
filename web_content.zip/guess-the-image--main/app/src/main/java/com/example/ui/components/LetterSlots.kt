package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.keyframes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.SlotBorder
import com.example.ui.theme.SlotFilledBorder
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LetterSlots(
    placedLetters: List<Char?>,
    isRevealed: Boolean,
    isWrongShake: Boolean,
    onRemoveLetter: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val shakeOffset = remember { Animatable(0f) }

    LaunchedEffect(isWrongShake) {
        if (isWrongShake) {
            shakeOffset.animateTo(
                targetValue = 0f,
                animationSpec = keyframes {
                    durationMillis = 400
                    0f at 0
                    -12f at 50
                    12f at 100
                    -10f at 150
                    10f at 200
                    -6f at 250
                    6f at 300
                    0f at 400
                }
            )
        }
    }

    FlowRow(
        modifier = modifier
            .fillMaxWidth()
            .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        placedLetters.forEachIndexed { index, char ->
            val isFilled = char != null

            val slotBackground = if (isRevealed) {
                Modifier.background(GameEmerald)
            } else if (isFilled) {
                Modifier.background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                    )
                )
            } else {
                Modifier.background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0F172A), Color(0xFF080D1A))
                    )
                )
            }

            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .size(width = 44.dp, height = 54.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .then(slotBackground)
                    .border(
                        width = 2.dp,
                        color = when {
                            isRevealed -> Color(0xFF6EE7B7)
                            isFilled -> SlotFilledBorder
                            else -> SlotBorder
                        },
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable(enabled = isFilled && !isRevealed) {
                        onRemoveLetter(index)
                    }
                    .testTag("letter_slot_$index"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = char?.toString() ?: "",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = if (isRevealed) Color(0xFF062E1A) else GameAmberBright
                )
            }
        }
    }
}
