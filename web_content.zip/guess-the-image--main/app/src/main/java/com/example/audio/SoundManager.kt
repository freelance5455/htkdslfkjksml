package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.sin

class SoundManager(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
        if (!_isMuted.value) {
            playPing()
        }
    }

    private fun playTone(
        frequencies: List<Float>,
        durationMs: Int,
        decay: Boolean = true,
        volume: Float = 0.25f
    ) {
        if (_isMuted.value) return
        scope.launch {
            try {
                val sampleRate = 44100
                val numSamples = (sampleRate * (durationMs / 1000f)).toInt()
                val buffer = ShortArray(numSamples)

                for (i in 0 until numSamples) {
                    val time = i.toFloat() / sampleRate
                    var sampleVal = 0.0
                    for (freq in frequencies) {
                        sampleVal += sin(2.0 * Math.PI * freq * time)
                    }
                    sampleVal /= frequencies.size.coerceAtLeast(1)

                    val envelope = if (decay) {
                        exp(-3.5 * (i.toDouble() / numSamples))
                    } else {
                        1.0
                    }

                    val shortVal = (sampleVal * envelope * volume * Short.MAX_VALUE).toInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                    buffer[i] = shortVal.toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()
                // Release after playback
                launch {
                    kotlinx.coroutines.delay(durationMs.toLong() + 100)
                    audioTrack.release()
                }
            } catch (_: Exception) {
                // Ignore audio errors gracefully
            }
        }
    }

    /**
     * Subtle high-frequency crystal chime for correct guesses.
     */
    fun playPing() {
        playTone(listOf(1174.66f, 2349.32f), durationMs = 350, decay = true, volume = 0.25f)
        vibrate(35)
    }

    /**
     * Soft low-frequency damped thud for incorrect guesses.
     */
    fun playThud() {
        playTone(listOf(85f, 110f), durationMs = 220, decay = true, volume = 0.35f)
        vibrate(70)
    }

    /**
     * Crisp tap for letter selection.
     */
    fun playTap() {
        playTone(listOf(520f, 880f), durationMs = 50, decay = true, volume = 0.15f)
        vibrate(15)
    }

    /**
     * Low backspace / remove sound.
     */
    fun playDelete() {
        playTone(listOf(320f, 220f), durationMs = 60, decay = true, volume = 0.15f)
        vibrate(20)
    }

    /**
     * Swoosh tone for zooming out.
     */
    fun playZoom() {
        playTone(listOf(400f, 300f), durationMs = 150, decay = true, volume = 0.2f)
        vibrate(25)
    }

    /**
     * Ascending arpeggio fanfare for level unlock and victory.
     */
    fun playUnlock() {
        scope.launch {
            val notes = listOf(440f, 554.37f, 659.25f, 880f, 1108.73f)
            notes.forEach { freq ->
                playTone(listOf(freq), durationMs = 250, decay = true, volume = 0.25f)
                kotlinx.coroutines.delay(70)
            }
        }
        vibrate(100)
    }

    /**
     * Mystery clue tone.
     */
    fun playHint() {
        playTone(listOf(600f, 950f), durationMs = 150, decay = true, volume = 0.2f)
        vibrate(30)
    }

    private fun vibrate(ms: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(ms)
            }
        } catch (_: Exception) {}
    }
}
