package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FilterCenterFocus
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.QuizItem
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameRose
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ZoomViewer(
    item: QuizItem,
    zoomStage: Int,
    onZoomOut: () -> Unit = {},
    isRevealed: Boolean,
    scoreBonus: Int,
    modifier: Modifier = Modifier
) {
    var panOffsetX by remember(item.id, zoomStage) { mutableStateOf(0f) }
    var panOffsetY by remember(item.id, zoomStage) { mutableStateOf(0f) }

    val targetScale = if (isRevealed) {
        1.0f
    } else {
        when (zoomStage) {
            1 -> item.zoom.initialScale
            2 -> item.zoom.stage2Scale
            3 -> item.zoom.stage3Scale
            else -> 1.0f
        }
    }

    val animatedScale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = tween(durationMillis = 400),
        label = "zoomScale"
    )

    val pivotX = if (isRevealed) 0.5f else (item.zoom.x / 100f).coerceIn(0.1f, 0.9f)
    val pivotY = if (isRevealed) 0.5f else (item.zoom.y / 100f).coerceIn(0.1f, 0.9f)

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status row above viewer
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isRevealed) GameEmerald.copy(alpha = 0.2f) else GameRose.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isRevealed) GameEmerald.copy(alpha = 0.5f) else GameRose.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isRevealed) Icons.Default.CheckCircle else Icons.Default.ZoomIn,
                        contentDescription = null,
                        tint = if (isRevealed) GameEmerald else GameRose,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isRevealed) {
                            "SOLVED & REVEALED"
                        } else {
                            "STAGE $zoomStage/4 • ${(animatedScale * 100).toInt()}% ZOOM"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isRevealed) GameEmerald else Color.White
                    )
                }
            }

            if (!isRevealed) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GameAmber.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GameAmber.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "+$scoreBonus PTS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = GameAmberBright,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Viewport Frame
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(4f / 3f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF070B14))
                .border(
                    width = 2.dp,
                    color = if (isRevealed) GameEmerald.copy(alpha = 0.8f) else Color(0xFF222F47),
                    shape = RoundedCornerShape(24.dp)
                )
                .clipToBounds()
                .pointerInput(isRevealed, zoomStage) {
                    if (!isRevealed && zoomStage < 4) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            panOffsetX = (panOffsetX + dragAmount.x).coerceIn(-180f, 180f)
                            panOffsetY = (panOffsetY + dragAmount.y).coerceIn(-180f, 180f)
                        }
                    }
                }
                .testTag("zoom_viewport")
        ) {
            // Scaled Graphic Container
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = animatedScale
                        scaleY = animatedScale
                        transformOrigin = TransformOrigin(pivotX, pivotY)
                        translationX = if (isRevealed) 0f else panOffsetX
                        translationY = if (isRevealed) 0f else panOffsetY
                    }
            ) {
                LogoGraphic(item = item)
            }

            // Cinematic Viewfinder Overlay (when unsolved)
            if (!isRevealed) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Subtle radial vignette
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.Transparent, Color(0x77000000)),
                            center = Offset(w / 2f, h / 2f),
                            radius = size.minDimension * 0.75f
                        )
                    )

                    // Corner reticles
                    val cornerLen = 22.dp.toPx()
                    val pad = 16.dp.toPx()
                    val reticleColor = Color(0xCCFBBF24)
                    val strokeW = 2.dp.toPx()

                    // Top-Left
                    drawLine(reticleColor, Offset(pad, pad), Offset(pad + cornerLen, pad), strokeW)
                    drawLine(reticleColor, Offset(pad, pad), Offset(pad, pad + cornerLen), strokeW)
                    // Top-Right
                    drawLine(reticleColor, Offset(w - pad, pad), Offset(w - pad - cornerLen, pad), strokeW)
                    drawLine(reticleColor, Offset(w - pad, pad), Offset(w - pad, pad + cornerLen), strokeW)
                    // Bottom-Left
                    drawLine(reticleColor, Offset(pad, h - pad), Offset(pad + cornerLen, h - pad), strokeW)
                    drawLine(reticleColor, Offset(pad, h - pad), Offset(pad, h - pad - cornerLen), strokeW)
                    // Bottom-Right
                    drawLine(reticleColor, Offset(w - pad, h - pad), Offset(w - pad - cornerLen, h - pad), strokeW)
                    drawLine(reticleColor, Offset(w - pad, h - pad), Offset(w - pad, h - pad - cornerLen), strokeW)

                    // Center Crosshair
                    val cx = w / 2f
                    val cy = h / 2f
                    val chLen = 14.dp.toPx()
                    val chGap = 4.dp.toPx()
                    drawLine(reticleColor.copy(alpha = 0.4f), Offset(cx - chLen, cy), Offset(cx - chGap, cy), 1.dp.toPx())
                    drawLine(reticleColor.copy(alpha = 0.4f), Offset(cx + chGap, cy), Offset(cx + chLen, cy), 1.dp.toPx())
                    drawLine(reticleColor.copy(alpha = 0.4f), Offset(cx, cy - chLen), Offset(cx, cy - chGap), 1.dp.toPx())
                    drawLine(reticleColor.copy(alpha = 0.4f), Offset(cx, cy + chGap), Offset(cx, cy + chLen), 1.dp.toPx())
                }
            }

            // Identity Revealed Overlay
            if (isRevealed) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, GameDarkBackground.copy(alpha = 0.95f))
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = item.name,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.description,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            maxLines = 2
                        )
                    }
                }
            }
        }

        // Zoom & Center Control Buttons
        if (!isRevealed) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onZoomOut,
                    enabled = zoomStage < 4,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("zoom_out_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1B2438),
                        contentColor = Color.White,
                        disabledContainerColor = Color(0xFF131B2B),
                        disabledContentColor = Color(0xFF475569)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomOut,
                        contentDescription = "Zoom Out",
                        tint = if (zoomStage < 4) GameAmber else Color(0xFF475569),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (zoomStage >= 4) "Fully Zoomed Out" else "Zoom Out (Stage ${zoomStage + 1}/4)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (panOffsetX != 0f || panOffsetY != 0f) {
                    OutlinedButton(
                        onClick = {
                            panOffsetX = 0f
                            panOffsetY = 0f
                        },
                        modifier = Modifier.height(48.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterCenterFocus,
                            contentDescription = "Center View",
                            tint = GameAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Center", fontSize = 12.sp, color = TextPrimary)
                    }
                }
            }
        }
    }
}
