package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiClueService
import com.example.audio.SoundManager
import com.example.data.DailyChallenges
import com.example.data.GAME_LEVELS
import com.example.data.LeaderboardRepository
import com.example.data.QUIZ_ITEMS
import com.example.data.getEffectiveDailyStreak
import com.example.data.getTodayDateString
import com.example.data.getYesterdayDateString
import com.example.model.DailyRecord
import com.example.model.LeaderboardEntry
import com.example.model.QuizItem
import com.example.model.UserStats
import com.example.storage.GamePreferences
import com.example.ui.components.TileLetter
import com.example.ui.components.VictorySummary
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

data class GameUiState(
    val currentItem: QuizItem,
    val zoomStage: Int = 1,
    val placedLetters: List<Char?> = emptyList(),
    val keyboardTiles: List<TileLetter> = emptyList(),
    val userStats: UserStats = UserStats(),
    val solvedIds: Set<String> = emptySet(),
    val isRevealed: Boolean = false,
    val isWrongShake: Boolean = false,
    val isSubtleClueUnlocked: Boolean = false,
    val subtleClueFeedback: String? = null,
    val activeClueText: String? = null,
    val isLoadingAi: Boolean = false,
    val victorySummary: VictorySummary? = null,
    val showLevelsDialog: Boolean = false,
    val showDailyDialog: Boolean = false,
    val showLeaderboardDialog: Boolean = false,
    val leaderboardEntries: List<LeaderboardEntry> = emptyList(),
    val isDailyMode: Boolean = false,
    val dailyMultiplierLabel: String = "1.0x",
    val dailyMultiplier: Float = 1.0f,
    val isDailyCompletedToday: Boolean = false
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = GamePreferences(application)
    private val soundManager = SoundManager(application)
    private val leaderboardRepo = LeaderboardRepository(application)
    private val geminiService = GeminiClueService()

    private val _uiState = MutableStateFlow(
        GameUiState(
            currentItem = QUIZ_ITEMS.first()
        )
    )
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    init {
        loadInitialState()
    }

    private fun loadInitialState() {
        val stats = prefs.loadStats()
        val solved = prefs.getSolvedIds()
        val todayStr = getTodayDateString()
        val effectiveDailyStreak = getEffectiveDailyStreak(stats, todayStr)
        val multiplier = DailyChallenges.getStreakMultiplier(effectiveDailyStreak)
        val multLabel = DailyChallenges.getMultiplierLabel(multiplier)
        val isDailyCompleted = stats.lastDailyDate == todayStr

        // Find initial item to display
        val candidate = QUIZ_ITEMS.firstOrNull { it.level == stats.currentLevel && !solved.contains(it.id) }
            ?: QUIZ_ITEMS.firstOrNull { it.level == stats.currentLevel }
            ?: QUIZ_ITEMS.first()

        _uiState.value = _uiState.value.copy(
            userStats = stats.copy(dailyStreak = effectiveDailyStreak),
            solvedIds = solved,
            dailyMultiplier = multiplier,
            dailyMultiplierLabel = multLabel,
            isDailyCompletedToday = isDailyCompleted,
            leaderboardEntries = leaderboardRepo.getLeaderboard()
        )

        prepareItem(candidate, isDaily = false)
    }

    fun prepareItem(item: QuizItem, isDaily: Boolean = false) {
        val clean = item.cleanAnswer.uppercase()
        val slots = List<Char?>(clean.length) { null }

        // Create 14 keyboard tiles: letters from clean answer + random distractors
        val neededLetters = clean.toList().toMutableList()
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        while (neededLetters.size < 14) {
            neededLetters.add(alphabet[Random.nextInt(alphabet.length)])
        }
        neededLetters.shuffle()

        val tiles = neededLetters.mapIndexed { idx, ch ->
            TileLetter(
                id = "${ch}_${idx}_${UUID.randomUUID()}",
                char = ch,
                isUsed = false,
                isDisabled = false
            )
        }

        val isAlreadySolved = _uiState.value.solvedIds.contains(item.id)

        _uiState.value = _uiState.value.copy(
            currentItem = item,
            zoomStage = if (isAlreadySolved) 4 else 1,
            placedLetters = if (isAlreadySolved) clean.toList() else slots,
            keyboardTiles = tiles,
            isRevealed = isAlreadySolved,
            isWrongShake = false,
            isSubtleClueUnlocked = false,
            subtleClueFeedback = null,
            activeClueText = null,
            isLoadingAi = false,
            victorySummary = null,
            isDailyMode = isDaily
        )
    }

    fun onTileClick(tile: TileLetter) {
        val state = _uiState.value
        if (state.isRevealed || tile.isUsed || tile.isDisabled) return

        val emptyIndex = state.placedLetters.indexOfFirst { it == null }
        if (emptyIndex == -1) return

        soundManager.playTap()

        val updatedSlots = state.placedLetters.toMutableList().apply {
            set(emptyIndex, tile.char)
        }
        val updatedTiles = state.keyboardTiles.map {
            if (it.id == tile.id) it.copy(isUsed = true) else it
        }

        _uiState.value = state.copy(
            placedLetters = updatedSlots,
            keyboardTiles = updatedTiles
        )

        // If all slots are filled, evaluate
        if (!updatedSlots.contains(null)) {
            viewModelScope.launch {
                delay(120)
                evaluateGuess(updatedSlots.filterNotNull().joinToString(""))
            }
        }
    }

    fun onRemoveLetter(slotIndex: Int) {
        val state = _uiState.value
        if (state.isRevealed) return

        val charToRemove = state.placedLetters.getOrNull(slotIndex) ?: return
        soundManager.playDelete()

        // Unuse one matching tile in keyboard
        var unmarkDone = false
        val updatedTiles = state.keyboardTiles.map { tile ->
            if (!unmarkDone && tile.isUsed && tile.char == charToRemove) {
                unmarkDone = true
                tile.copy(isUsed = false)
            } else {
                tile
            }
        }

        val updatedSlots = state.placedLetters.toMutableList().apply {
            set(slotIndex, null)
        }

        _uiState.value = state.copy(
            placedLetters = updatedSlots,
            keyboardTiles = updatedTiles
        )
    }

    fun onBackspace() {
        val state = _uiState.value
        if (state.isRevealed) return

        val lastFilledIndex = state.placedLetters.indexOfLast { it != null }
        if (lastFilledIndex != -1) {
            onRemoveLetter(lastFilledIndex)
        }
    }

    fun onClearAll() {
        val state = _uiState.value
        if (state.isRevealed) return

        soundManager.playDelete()
        val clean = state.currentItem.cleanAnswer
        _uiState.value = state.copy(
            placedLetters = List(clean.length) { null },
            keyboardTiles = state.keyboardTiles.map { it.copy(isUsed = false) }
        )
    }

    private fun evaluateGuess(guess: String) {
        val state = _uiState.value
        val item = state.currentItem
        val isCorrect = guess.equals(item.cleanAnswer, ignoreCase = true) ||
                item.aliases.any { it.replace(" ", "").equals(guess, ignoreCase = true) }

        val newTotalGuesses = state.userStats.totalGuesses + 1

        if (isCorrect) {
            soundManager.playPing()

            val basePoints = when (state.zoomStage) {
                1 -> 500
                2 -> 350
                3 -> 250
                else -> 150
            }

            val newStreak = state.userStats.streak + 1
            val bestStreak = maxOf(state.userStats.highestStreak, newStreak)
            val streakBonus = (newStreak - 1).coerceAtLeast(0) * 40

            val dailyBonus = if (state.isDailyMode) {
                ((basePoints * state.dailyMultiplier) - basePoints).toInt()
            } else 0

            val totalEarned = basePoints + streakBonus + dailyBonus
            val coinsEarned = if (state.isDailyMode) 100 else 25

            val newScore = state.userStats.score + totalEarned
            val newCoins = state.userStats.coins + coinsEarned
            val newSolvedSet = state.solvedIds + item.id
            val totalSolved = newSolvedSet.size
            val newCorrectGuesses = state.userStats.correctGuesses + 1

            // Check level unlocks
            var newUnlockedLevel = state.userStats.unlockedLevel
            var newlyUnlockedLevel: Int? = null
            val updatedUnlockedLevels = state.userStats.unlockedLevels.toMutableSet()
            for (lvl in GAME_LEVELS) {
                if (lvl.levelNumber > newUnlockedLevel) {
                    if (newScore >= lvl.requiredScore && totalSolved >= lvl.requiredSolved) {
                        newUnlockedLevel = lvl.levelNumber
                        newlyUnlockedLevel = lvl.levelNumber
                        updatedUnlockedLevels.add(lvl.levelNumber)
                        soundManager.playUnlock()
                    }
                }
            }

            // Daily tracking
            val todayStr = getTodayDateString()
            val yesterdayStr = getYesterdayDateString(todayStr)
            var newDailyStreak = state.userStats.dailyStreak
            var newHighestDailyStreak = state.userStats.highestDailyStreak
            var lastDailyDate = state.userStats.lastDailyDate
            val updatedDailyHistory = state.userStats.dailyHistory.toMutableMap()

            if (state.isDailyMode) {
                newDailyStreak = when (state.userStats.lastDailyDate) {
                    todayStr -> state.userStats.dailyStreak
                    yesterdayStr -> state.userStats.dailyStreak + 1
                    else -> 1
                }
                newHighestDailyStreak = maxOf(newHighestDailyStreak, newDailyStreak)
                lastDailyDate = todayStr
                updatedDailyHistory[todayStr] = DailyRecord(
                    date = todayStr,
                    itemId = item.id,
                    solved = true,
                    scoreEarned = totalEarned,
                    bonusPoints = dailyBonus,
                    zoomStage = state.zoomStage,
                    completedAt = System.currentTimeMillis().toString()
                )
            }

            val updatedStats = state.userStats.copy(
                score = newScore,
                coins = newCoins,
                unlockedLevels = updatedUnlockedLevels,
                streak = newStreak,
                highestStreak = bestStreak,
                solvedIds = newSolvedSet,
                totalGuesses = newTotalGuesses,
                correctGuesses = newCorrectGuesses,
                dailyStreak = newDailyStreak,
                highestDailyStreak = newHighestDailyStreak,
                lastDailyDate = lastDailyDate,
                dailyHistory = updatedDailyHistory
            )

            prefs.saveStats(updatedStats)
            prefs.markSolved(item.id)

            val stars = when (state.zoomStage) {
                1 -> 3
                2, 3 -> 2
                else -> 1
            }

            val summary = VictorySummary(
                basePoints = basePoints,
                streakBonus = streakBonus,
                dailyStreakMultiplier = state.dailyMultiplier,
                dailyStreakBonus = dailyBonus,
                dailyStreakLabel = state.dailyMultiplierLabel,
                dailyStreakDays = newDailyStreak,
                totalEarned = totalEarned,
                coinsEarned = coinsEarned,
                stars = stars,
                newlyUnlockedLevel = newlyUnlockedLevel
            )

            val refreshedMult = DailyChallenges.getStreakMultiplier(newDailyStreak)

            _uiState.value = state.copy(
                userStats = updatedStats,
                solvedIds = newSolvedSet,
                isRevealed = true,
                victorySummary = summary,
                dailyMultiplier = refreshedMult,
                dailyMultiplierLabel = DailyChallenges.getMultiplierLabel(refreshedMult),
                isDailyCompletedToday = (lastDailyDate == todayStr)
            )
        } else {
            // Wrong Guess
            soundManager.playThud()
            val updatedStats = state.userStats.copy(
                streak = 0,
                totalGuesses = newTotalGuesses
            )
            prefs.saveStats(updatedStats)

            _uiState.value = state.copy(
                userStats = updatedStats,
                isWrongShake = true
            )

            viewModelScope.launch {
                delay(450)
                _uiState.value = _uiState.value.copy(isWrongShake = false)
            }
        }
    }

    fun onZoomOut() {
        val state = _uiState.value
        if (state.isRevealed || state.zoomStage >= 4) return

        soundManager.playZoom()
        _uiState.value = state.copy(zoomStage = state.zoomStage + 1)
    }

    fun getScoreBonusForCurrentStage(): Int {
        return when (_uiState.value.zoomStage) {
            1 -> 500
            2 -> 350
            3 -> 250
            else -> 150
        }
    }

    fun unlockSubtleClue() {
        val state = _uiState.value
        if (state.isSubtleClueUnlocked) return

        if (state.userStats.score >= 500) {
            soundManager.playHint()
            val newScore = state.userStats.score - 500
            val updatedStats = state.userStats.copy(score = newScore)
            prefs.saveStats(updatedStats)

            _uiState.value = state.copy(
                userStats = updatedStats,
                isSubtleClueUnlocked = true,
                activeClueText = state.currentItem.hints.clue1,
                subtleClueFeedback = "-500 PTS: Mystery clue unlocked!"
            )
        } else {
            soundManager.playThud()
            _uiState.value = state.copy(
                subtleClueFeedback = "Need 500 PTS! Solve images to build your score."
            )
        }
    }

    fun revealOneLetter() {
        val state = _uiState.value
        if (state.isRevealed || state.userStats.coins < 20) return

        val clean = state.currentItem.cleanAnswer
        var targetIndex = -1
        for (i in clean.indices) {
            if (state.placedLetters.getOrNull(i) != clean[i]) {
                targetIndex = i
                break
            }
        }
        if (targetIndex == -1) return

        soundManager.playHint()
        val correctChar = clean[targetIndex]
        val newCoins = state.userStats.coins - 20
        val updatedStats = state.userStats.copy(coins = newCoins)
        prefs.saveStats(updatedStats)

        val updatedSlots = state.placedLetters.toMutableList().apply {
            set(targetIndex, correctChar)
        }

        var marked = false
        val updatedTiles = state.keyboardTiles.map { tile ->
            if (!marked && !tile.isUsed && tile.char == correctChar) {
                marked = true
                tile.copy(isUsed = true)
            } else {
                tile
            }
        }

        _uiState.value = state.copy(
            userStats = updatedStats,
            placedLetters = updatedSlots,
            keyboardTiles = updatedTiles
        )

        if (!updatedSlots.contains(null)) {
            viewModelScope.launch {
                delay(120)
                evaluateGuess(updatedSlots.filterNotNull().joinToString(""))
            }
        }
    }

    fun removeThreeWrongLetters() {
        val state = _uiState.value
        if (state.isRevealed || state.userStats.coins < 30) return

        val clean = state.currentItem.cleanAnswer
        val wrongTiles = state.keyboardTiles.filter { !it.isDisabled && !it.isUsed && !clean.contains(it.char) }
        if (wrongTiles.isEmpty()) return

        soundManager.playHint()
        val toDisable = wrongTiles.shuffled().take(3).map { it.id }.toSet()
        val newCoins = state.userStats.coins - 30
        val updatedStats = state.userStats.copy(coins = newCoins)
        prefs.saveStats(updatedStats)

        val updatedTiles = state.keyboardTiles.map {
            if (toDisable.contains(it.id)) it.copy(isDisabled = true) else it
        }

        _uiState.value = state.copy(
            userStats = updatedStats,
            keyboardTiles = updatedTiles
        )
    }

    fun requestAiClue() {
        val state = _uiState.value
        if (state.isLoadingAi || state.userStats.coins < 25) return

        soundManager.playTap()
        val newCoins = state.userStats.coins - 25
        val updatedStats = state.userStats.copy(coins = newCoins)
        prefs.saveStats(updatedStats)

        _uiState.value = state.copy(
            userStats = updatedStats,
            isLoadingAi = true
        )

        viewModelScope.launch {
            val clue = geminiService.getMysteryClue(state.currentItem)
            soundManager.playHint()
            _uiState.value = _uiState.value.copy(
                isLoadingAi = false,
                activeClueText = clue
            )
        }
    }

    fun nextImage() {
        val state = _uiState.value
        val itemsInLevel = QUIZ_ITEMS.filter { it.level == state.userStats.currentLevel }
        val unsolvedInLevel = itemsInLevel.filter { !state.solvedIds.contains(it.id) }

        val nextItem = unsolvedInLevel.firstOrNull { it.id != state.currentItem.id }
            ?: itemsInLevel.firstOrNull { it.id != state.currentItem.id }
            ?: QUIZ_ITEMS.firstOrNull { it.level <= state.userStats.unlockedLevel && !state.solvedIds.contains(it.id) }
            ?: QUIZ_ITEMS.first()

        prepareItem(nextItem, isDaily = false)
    }

    fun selectLevel(lvlNumber: Int) {
        val state = _uiState.value
        if (lvlNumber > state.userStats.unlockedLevel) return

        val updatedStats = state.userStats.copy(currentLevel = lvlNumber)
        prefs.saveStats(updatedStats)

        val items = QUIZ_ITEMS.filter { it.level == lvlNumber }
        val itemToPlay = items.firstOrNull { !state.solvedIds.contains(it.id) } ?: items.first()

        _uiState.value = state.copy(
            userStats = updatedStats,
            showLevelsDialog = false
        )
        prepareItem(itemToPlay, isDaily = false)
    }

    fun playDailyChallenge() {
        val dailyItem = DailyChallenges.getTodayDailyItem()
        _uiState.value = _uiState.value.copy(showDailyDialog = false)
        prepareItem(dailyItem, isDaily = true)
    }

    fun submitLeaderboardScore(name: String) {
        val state = _uiState.value
        val accuracy = if (state.userStats.totalGuesses > 0) {
            (state.userStats.correctGuesses * 100) / state.userStats.totalGuesses
        } else 100

        val (_, updated) = leaderboardRepo.submitScore(
            name = name,
            score = state.userStats.score,
            level = state.userStats.unlockedLevel,
            accuracy = accuracy,
            avatar = "⚡",
            streak = state.userStats.bestStreak
        )

        _uiState.value = state.copy(leaderboardEntries = updated)
    }

    fun setShowLevelsDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showLevelsDialog = show)
    }

    fun setShowDailyDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showDailyDialog = show)
    }

    fun setShowLeaderboardDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showLeaderboardDialog = show)
    }

    fun dismissVictoryDialog() {
        _uiState.value = _uiState.value.copy(victorySummary = null)
    }
}
