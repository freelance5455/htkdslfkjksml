package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.GAME_LEVELS
import com.example.model.LevelInfo
import com.example.model.QuizItem
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LevelsDialog(
    currentLevel: Int,
    unlockedLevel: Int,
    score: Int,
    totalSolved: Int,
    allItems: List<QuizItem>,
    solvedIds: Set<String>,
    onSelectLevel: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(28.dp))
                .border(2.dp, Color(0xFF26334D), RoundedCornerShape(28.dp))
                .testTag("levels_dialog"),
            color = GameDarkBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "LEVELS MAP",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "Score: $score pts • Solved: $totalSolved images",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(GAME_LEVELS) { lvl ->
                        val isUnlocked = lvl.levelNumber <= unlockedLevel
                        val isCurrent = lvl.levelNumber == currentLevel
                        val levelItems = allItems.filter { it.level == lvl.levelNumber }
                        val solvedCount = levelItems.count { solvedIds.contains(it.id) }
                        val progress = if (levelItems.isNotEmpty()) solvedCount.toFloat() / levelItems.size else 0f

                        LevelCard(
                            level = lvl,
                            isUnlocked = isUnlocked,
                            isCurrent = isCurrent,
                            solvedCount = solvedCount,
                            totalCount = levelItems.size,
                            progress = progress,
                            score = score,
                            onClick = {
                                if (isUnlocked) {
                                    onSelectLevel(lvl.levelNumber)
                                    onDismiss()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelCard(
    level: LevelInfo,
    isUnlocked: Boolean,
    isCurrent: Boolean,
    solvedCount: Int,
    totalCount: Int,
    progress: Float,
    score: Int,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(enabled = isUnlocked) { onClick() }
            .testTag("level_card_${level.levelNumber}"),
        shape = RoundedCornerShape(18.dp),
        color = when {
            isCurrent -> Color(0xFF1B263B)
            isUnlocked -> GameSurfaceDark
            else -> Color(0xFF0F1420)
        },
        border = androidx.compose.foundation.BorderStroke(
            if (isCurrent) 2.dp else 1.dp,
            when {
                isCurrent -> GameAmber
                isUnlocked -> Color(0xFF26334D)
                else -> Color(0xFF161E2E)
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Level Badge Circle
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (isUnlocked) {
                            Brush.verticalGradient(listOf(Color(0xFF2B3A55), Color(0xFF192233)))
                        } else {
                            Brush.verticalGradient(listOf(Color(0xFF141A29), Color(0xFF0D111A)))
                        }
                    )
                    .border(
                        1.dp,
                        if (isCurrent) GameAmber else if (isUnlocked) Color(0xFF3B4D6E) else Color(0xFF1E2638),
                        RoundedCornerShape(14.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isUnlocked) {
                    Text(
                        text = level.badge,
                        fontSize = 22.sp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Level Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Level ${level.levelNumber}: ${level.title}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isUnlocked) Color.White else TextMuted
                    )
                    if (isCurrent) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = GameAmber.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "PLAYING",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = GameAmberBright,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Text(
                    text = if (isUnlocked) level.theme else "Unlocks at ${level.requiredScore} pts (${level.requiredSolved} solved)",
                    fontSize = 11.sp,
                    color = if (isUnlocked) TextSecondary else TextMuted
                )

                if (isUnlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (progress >= 1f) GameEmerald else GameAmber,
                            trackColor = Color(0xFF1A2234)
                        )
                        Text(
                            text = "$solvedCount/$totalCount",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (progress >= 1f) GameEmerald else TextSecondary
                        )
                    }
                }
            }

            if (isUnlocked) {
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = if (isCurrent) GameAmber else TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
