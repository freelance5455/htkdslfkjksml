package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

data class TileLetter(
    val id: String,
    val char: Char,
    val isUsed: Boolean = false,
    val isDisabled: Boolean = false
)

@Composable
fun KeyboardPool(
    tiles: List<TileLetter>,
    onTileClick: (TileLetter) -> Unit,
    onBackspace: () -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = GameSurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222F47))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header control bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SELECT LETTERS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 1.sp
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onClearAll,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("clear_all_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RotateLeft,
                            contentDescription = "Clear All",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = onBackspace,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("backspace_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Backspace,
                            contentDescription = "Backspace",
                            tint = GameRose,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Two rows of 7 tiles each
            val row1 = tiles.take(7)
            val row2 = tiles.drop(7).take(7)

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    row1.forEach { tile ->
                        LetterTile(
                            tile = tile,
                            onClick = { onTileClick(tile) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    row2.forEach { tile ->
                        LetterTile(
                            tile = tile,
                            onClick = { onTileClick(tile) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LetterTile(
    tile: TileLetter,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isClickable = !tile.isUsed && !tile.isDisabled

    val tileBackground = if (tile.isDisabled) {
        Modifier.background(Color(0xFF0F172A))
    } else if (tile.isUsed) {
        Modifier.background(Color(0xFF161F33))
    } else {
        Modifier.background(
            Brush.verticalGradient(listOf(Color(0xFF27354F), Color(0xFF1A2438)))
        )
    }

    Box(
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(12.dp))
            .then(tileBackground)
            .border(
                width = 1.dp,
                color = when {
                    tile.isDisabled -> Color(0xFF1E293B)
                    tile.isUsed -> Color(0xFF1E293B)
                    else -> Color(0xFF3B4D6E)
                },
                shape = RoundedCornerShape(12.dp)
            )
            .alpha(
                when {
                    tile.isDisabled -> 0.15f
                    tile.isUsed -> 0.35f
                    else -> 1.0f
                }
            )
            .clickable(enabled = isClickable) { onClick() }
            .testTag("tile_${tile.char}"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = tile.char.toString(),
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = if (tile.isUsed || tile.isDisabled) TextMuted else Color.White
        )
    }
}
