package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.QuizItem
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun LogoGraphic(
    item: QuizItem,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(item.bgColor)),
        contentAlignment = Alignment.Center
    ) {
        when (item.logoType) {
            "nike" -> NikeLogo()
            "apple" -> AppleLogo()
            "youtube" -> YouTubeLogo()
            "mcdonalds" -> McDonaldsLogo()
            "discord" -> DiscordLogo()
            "mrbeast" -> MrBeastLogo()
            "google" -> GoogleLogo()
            "samsung" -> SamsungLogo()
            "tesla" -> TeslaLogo()
            "spotify" -> SpotifyLogo()
            "xiaomi" -> XiaomiLogo()
            "microsoft" -> MicrosoftLogo()
            "pewdiepie" -> PewDiePieLogo()
            "dude-perfect" -> DudePerfectLogo()
            "mkbhd" -> MkbhdLogo()
            "markiplier" -> MarkiplierLogo()
            "sidemen" -> SidemenLogo()
            "ferrari" -> FerrariLogo()
            "lamborghini" -> LamborghiniLogo()
            "bmw" -> BmwLogo()
            "mercedes" -> MercedesLogo()
            "audi" -> AudiLogo()
            "adidas" -> AdidasLogo()
            "gucci" -> GucciLogo()
            "supreme" -> SupremeLogo()
            "puma" -> PumaLogo()
            "louis-vuitton" -> LouisVuittonLogo()
            "minecraft", "creeper" -> MinecraftLogo()
            "roblox" -> RobloxLogo()
            "tiktok" -> TikTokLogo()
            "instagram" -> InstagramLogo()
            "steam" -> SteamLogo()
            "netflix" -> NetflixLogo()
            "starbucks" -> StarbucksLogo()
            "playstation" -> PlayStationLogo()
            "twitch" -> TwitchLogo()
            "red-bull" -> RedBullLogo()
            "rolex" -> RolexLogo()
            "bugatti" -> BugattiLogo()
            "nasa" -> NasaLogo()
            "porsche" -> PorscheLogo()
            else -> GenericLogo(item)
        }
    }
}

@Composable
fun NikeLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.18f, h * 0.65f)
            cubicTo(w * 0.32f, h * 0.75f, w * 0.58f, h * 0.77f, w * 0.85f, h * 0.28f)
            cubicTo(w * 0.78f, h * 0.45f, w * 0.60f, h * 0.70f, w * 0.38f, h * 0.68f)
            cubicTo(w * 0.26f, h * 0.67f, w * 0.21f, h * 0.66f, w * 0.18f, h * 0.65f)
            close()
        }
        drawPath(path, color = Color(0xFF0F172A), style = Fill)
    }
}

@Composable
fun AppleLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.53f
        val r = size.minDimension * 0.26f

        // Leaf
        val leafPath = Path().apply {
            moveTo(cx + r * 0.1f, cy - r * 1.5f)
            cubicTo(cx + r * 0.6f, cy - r * 1.5f, cx + r * 0.9f, cy - r * 1.0f, cx + r * 0.9f, cy - r * 0.7f)
            cubicTo(cx + r * 0.4f, cy - r * 0.6f, cx + r * 0.1f, cy - r * 1.0f, cx + r * 0.1f, cy - r * 1.5f)
            close()
        }
        drawPath(leafPath, color = Color(0xFF1E293B))

        // Left lobe
        drawCircle(
            color = Color(0xFF1E293B),
            radius = r,
            center = Offset(cx - r * 0.45f, cy - r * 0.15f)
        )
        // Right lobe
        drawCircle(
            color = Color(0xFF1E293B),
            radius = r,
            center = Offset(cx + r * 0.45f, cy - r * 0.15f)
        )
        // Bottom left
        drawCircle(
            color = Color(0xFF1E293B),
            radius = r * 0.95f,
            center = Offset(cx - r * 0.4f, cy + r * 0.45f)
        )
        // Bottom right
        drawCircle(
            color = Color(0xFF1E293B),
            radius = r * 0.95f,
            center = Offset(cx + r * 0.4f, cy + r * 0.45f)
        )
        // Center fill
        drawRect(
            color = Color(0xFF1E293B),
            topLeft = Offset(cx - r * 0.45f, cy - r * 0.2f),
            size = Size(r * 0.9f, r * 0.8f)
        )
        // Apple bite out of right side
        drawCircle(
            color = Color.White,
            radius = r * 0.55f,
            center = Offset(cx + r * 1.05f, cy - r * 0.1f)
        )
        // Top dip cutout
        drawCircle(
            color = Color.White,
            radius = r * 0.28f,
            center = Offset(cx, cy - r * 1.05f)
        )
    }
}

@Composable
fun YouTubeLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val rw = w * 0.65f
        val rh = h * 0.48f
        val rx = (w - rw) / 2f
        val ry = (h - rh) / 2f

        drawRoundRect(
            color = Color(0xFFFF0000),
            topLeft = Offset(rx, ry),
            size = Size(rw, rh),
            cornerRadius = CornerRadius(rw * 0.22f, rw * 0.22f)
        )

        val triPath = Path().apply {
            moveTo(w * 0.44f, h * 0.38f)
            lineTo(w * 0.62f, h * 0.50f)
            lineTo(w * 0.44f, h * 0.62f)
            close()
        }
        drawPath(triPath, color = Color.White)
    }
}

@Composable
fun McDonaldsLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val archColor = Color(0xFFFFC72C)
        val strokeW = w * 0.055f

        val leftArch = Path().apply {
            moveTo(w * 0.31f, h * 0.76f)
            cubicTo(w * 0.31f, h * 0.30f, w * 0.40f, h * 0.24f, w * 0.49f, h * 0.68f)
        }
        val rightArch = Path().apply {
            moveTo(w * 0.51f, h * 0.68f)
            cubicTo(w * 0.60f, h * 0.24f, w * 0.69f, h * 0.30f, w * 0.69f, h * 0.76f)
        }
        drawPath(leftArch, color = archColor, style = Stroke(width = strokeW, cap = StrokeCap.Round))
        drawPath(rightArch, color = archColor, style = Stroke(width = strokeW, cap = StrokeCap.Round))
    }
}

@Composable
fun DiscordLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.45f
        val discordColor = Color(0xFF5865F2)

        drawRoundRect(
            color = discordColor,
            topLeft = Offset(cx - s, cy - s * 0.75f),
            size = Size(s * 2f, s * 1.5f),
            cornerRadius = CornerRadius(s * 0.4f, s * 0.4f)
        )
        // White eyes
        drawCircle(color = Color.White, radius = s * 0.22f, center = Offset(cx - s * 0.42f, cy))
        drawCircle(color = Color.White, radius = s * 0.22f, center = Offset(cx + s * 0.42f, cy))
    }
}

@Composable
fun MrBeastLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.42f

        // Wildcat head shape
        val headPath = Path().apply {
            moveTo(cx - s * 0.8f, cy - s * 0.4f)
            lineTo(cx - s * 0.2f, cy - s * 0.9f)
            lineTo(cx + s * 0.3f, cy - s * 0.6f)
            lineTo(cx + s * 0.8f, cy - s * 0.8f)
            lineTo(cx + s * 0.7f, cy + s * 0.1f)
            lineTo(cx + s * 0.9f, cy + s * 0.6f)
            lineTo(cx + s * 0.3f, cy + s * 0.9f)
            lineTo(cx - s * 0.4f, cy + s * 0.9f)
            lineTo(cx - s * 0.9f, cy + s * 0.4f)
            close()
        }
        drawPath(headPath, color = Color(0xFF00C8FF))

        // Neon pink lightning bolt eye
        val lightningPath = Path().apply {
            moveTo(cx - s * 0.1f, cy - s * 0.5f)
            lineTo(cx + s * 0.2f, cy)
            lineTo(cx, cy)
            lineTo(cx + s * 0.25f, cy + s * 0.55f)
            lineTo(cx - s * 0.15f, cy + s * 0.1f)
            lineTo(cx + s * 0.05f, cy + s * 0.1f)
            close()
        }
        drawPath(lightningPath, color = Color(0xFFFF007F))

        // White fangs
        val fang1 = Path().apply {
            moveTo(cx - s * 0.5f, cy + s * 0.4f)
            lineTo(cx - s * 0.3f, cy + s * 0.45f)
            lineTo(cx - s * 0.42f, cy + s * 0.75f)
            close()
        }
        drawPath(fang1, color = Color.White)
    }
}

@Composable
fun GoogleLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.34f
        val strokeW = r * 0.38f

        // Blue right arc + crossbar
        drawArc(
            color = Color(0xFF4285F4),
            startAngle = 315f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(cx - r, cy - r),
            size = Size(r * 2, r * 2),
            style = Stroke(strokeW, cap = StrokeCap.Butt)
        )
        // Green bottom arc
        drawArc(
            color = Color(0xFF34A853),
            startAngle = 45f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(cx - r, cy - r),
            size = Size(r * 2, r * 2),
            style = Stroke(strokeW, cap = StrokeCap.Butt)
        )
        // Yellow left arc
        drawArc(
            color = Color(0xFFFBBC05),
            startAngle = 135f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(cx - r, cy - r),
            size = Size(r * 2, r * 2),
            style = Stroke(strokeW, cap = StrokeCap.Butt)
        )
        // Red top arc
        drawArc(
            color = Color(0xFFEA4335),
            startAngle = 225f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(cx - r, cy - r),
            size = Size(r * 2, r * 2),
            style = Stroke(strokeW, cap = StrokeCap.Butt)
        )
        // Crossbar in blue
        drawRect(
            color = Color(0xFF4285F4),
            topLeft = Offset(cx, cy - strokeW / 2f),
            size = Size(r + strokeW / 2f, strokeW)
        )
    }
}

@Composable
fun SamsungLogo() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            rotate(-10f) {
                drawOval(
                    color = Color(0xFF1428A0),
                    topLeft = Offset(size.width * 0.15f, size.height * 0.32f),
                    size = Size(size.width * 0.70f, size.height * 0.36f)
                )
            }
        }
        Text(
            text = "SAMSUNG",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 3.sp
        )
    }
}

@Composable
fun TeslaLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f
        val tRed = Color(0xFFE82127)

        // Curved top cap
        val capPath = Path().apply {
            moveTo(cx - s, cy - s * 0.8f)
            cubicTo(cx - s * 0.4f, cy - s * 1.1f, cx + s * 0.4f, cy - s * 1.1f, cx + s, cy - s * 0.8f)
            cubicTo(cx + s * 0.6f, cy - s * 0.65f, cx - s * 0.6f, cy - s * 0.65f, cx - s, cy - s * 0.8f)
            close()
        }
        drawPath(capPath, color = tRed)

        // Dagger blade / stem
        val bladePath = Path().apply {
            moveTo(cx - s * 0.75f, cy - s * 0.45f)
            cubicTo(cx - s * 0.2f, cy - s * 0.55f, cx + s * 0.2f, cy - s * 0.55f, cx + s * 0.75f, cy - s * 0.45f)
            cubicTo(cx + s * 0.4f, cy - s * 0.2f, cx + s * 0.15f, cy - s * 0.1f, cx + s * 0.12f, cy + s * 0.7f)
            lineTo(cx, cy + s * 0.9f)
            lineTo(cx - s * 0.12f, cy + s * 0.7f)
            cubicTo(cx - s * 0.15f, cy - s * 0.1f, cx - s * 0.4f, cy - s * 0.2f, cx - s * 0.75f, cy - s * 0.45f)
            close()
        }
        drawPath(bladePath, color = tRed)
    }
}

@Composable
fun SpotifyLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.38f

        // Green circle
        drawCircle(color = Color(0xFF1DB954), radius = r, center = Offset(cx, cy))

        // 3 Soundwaves in dark gray
        val waveColor = Color(0xFF121212)
        rotate(-15f, pivot = Offset(cx, cy)) {
            val strokeW = r * 0.14f
            drawArc(
                color = waveColor,
                startAngle = 205f,
                sweepAngle = 130f,
                useCenter = false,
                topLeft = Offset(cx - r * 0.65f, cy - r * 0.55f),
                size = Size(r * 1.3f, r * 0.6f),
                style = Stroke(strokeW, cap = StrokeCap.Round)
            )
            drawArc(
                color = waveColor,
                startAngle = 205f,
                sweepAngle = 130f,
                useCenter = false,
                topLeft = Offset(cx - r * 0.55f, cy - r * 0.20f),
                size = Size(r * 1.1f, r * 0.5f),
                style = Stroke(strokeW * 0.9f, cap = StrokeCap.Round)
            )
            drawArc(
                color = waveColor,
                startAngle = 205f,
                sweepAngle = 130f,
                useCenter = false,
                topLeft = Offset(cx - r * 0.45f, cy + r * 0.15f),
                size = Size(r * 0.9f, r * 0.4f),
                style = Stroke(strokeW * 0.8f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun XiaomiLogo() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.size(160.dp)) {
            drawRoundRect(
                color = Color(0xFFFF6900),
                topLeft = Offset.Zero,
                size = size,
                cornerRadius = CornerRadius(size.width * 0.35f, size.height * 0.35f)
            )
        }
        Text(
            text = "mi",
            color = Color.White,
            fontSize = 58.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.SansSerif
        )
    }
}

@Composable
fun MicrosoftLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val tileSize = size.minDimension * 0.28f
        val gap = tileSize * 0.14f

        // Top-left: Orange-Red
        drawRect(
            color = Color(0xFFF25022),
            topLeft = Offset(cx - tileSize - gap / 2f, cy - tileSize - gap / 2f),
            size = Size(tileSize, tileSize)
        )
        // Top-right: Green
        drawRect(
            color = Color(0xFF7FBA00),
            topLeft = Offset(cx + gap / 2f, cy - tileSize - gap / 2f),
            size = Size(tileSize, tileSize)
        )
        // Bottom-left: Blue
        drawRect(
            color = Color(0xFF00A4EF),
            topLeft = Offset(cx - tileSize - gap / 2f, cy + gap / 2f),
            size = Size(tileSize, tileSize)
        )
        // Bottom-right: Yellow
        drawRect(
            color = Color(0xFFFFB900),
            topLeft = Offset(cx + gap / 2f, cy + gap / 2f),
            size = Size(tileSize, tileSize)
        )
    }
}

@Composable
fun PewDiePieLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val waveColor = Color(0xFFFF0055)

        for (i in -4..4) {
            val yOffset = cy + i * size.height * 0.12f
            val path = Path().apply {
                moveTo(-50f, yOffset)
                cubicTo(
                    size.width * 0.25f, yOffset - 50f,
                    size.width * 0.75f, yOffset + 50f,
                    size.width + 50f, yOffset
                )
            }
            drawPath(path, color = waveColor, style = Stroke(width = 18f, cap = StrokeCap.Round))
        }

        // Center Brofist badge
        drawCircle(color = Color(0xFF0F0F0F), radius = 64f, center = Offset(cx, cy))
        drawCircle(color = waveColor, radius = 64f, center = Offset(cx, cy), style = Stroke(width = 6f))

        // Stylized fist
        drawCircle(color = waveColor, radius = 32f, center = Offset(cx, cy))
        drawCircle(color = Color.White, radius = 10f, center = Offset(cx - 12f, cy - 8f))
    }
}

@Composable
fun DudePerfectLogo() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.5f
            val r = size.minDimension * 0.32f

            // Cyan 'd'
            drawCircle(
                color = Color(0xFF00D2FF),
                radius = r * 0.6f,
                center = Offset(cx - r * 0.4f, cy + r * 0.2f),
                style = Stroke(width = r * 0.35f)
            )
            drawRect(
                color = Color(0xFF00D2FF),
                topLeft = Offset(cx - r * 0.3f, cy - r * 0.8f),
                size = Size(r * 0.35f, r * 1.5f)
            )

            // Orange 'p'
            drawCircle(
                color = Color(0xFFFF7700),
                radius = r * 0.6f,
                center = Offset(cx + r * 0.4f, cy - r * 0.2f),
                style = Stroke(width = r * 0.35f)
            )
            drawRect(
                color = Color(0xFFFF7700),
                topLeft = Offset(cx + r * 0.1f, cy - r * 0.3f),
                size = Size(r * 0.35f, r * 1.5f)
            )
        }
    }
}

@Composable
fun MkbhdLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.35f

        val redPath = Path().apply {
            moveTo(cx - s, cy + s * 0.6f)
            lineTo(cx - s * 0.4f, cy - s * 0.6f)
            lineTo(cx, cy + s * 0.1f)
            close()
        }
        val whitePath = Path().apply {
            moveTo(cx, cy + s * 0.1f)
            lineTo(cx + s * 0.4f, cy - s * 0.6f)
            lineTo(cx + s, cy + s * 0.6f)
            close()
        }
        val centerRed = Path().apply {
            moveTo(cx - s * 0.4f, cy + s * 0.6f)
            lineTo(cx, cy - s * 0.2f)
            lineTo(cx + s * 0.4f, cy + s * 0.6f)
            close()
        }

        drawPath(redPath, color = Color(0xFFFF1E27))
        drawPath(whitePath, color = Color(0xFFE2E8F0))
        drawPath(centerRed, color = Color(0xFFFF1E27), alpha = 0.8f)
    }
}

@Composable
fun MarkiplierLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.54f
        val s = size.minDimension * 0.38f

        // Big Pink Mustache (Warfstache)
        val mustachePath = Path().apply {
            moveTo(cx, cy - s * 0.1f)
            cubicTo(cx - s * 0.3f, cy - s * 0.5f, cx - s * 0.9f, cy - s * 0.4f, cx - s * 0.95f, cy)
            cubicTo(cx - s * 1.0f, cy + s * 0.3f, cx - s * 0.7f, cy + s * 0.4f, cx - s * 0.4f, cy + s * 0.3f)
            cubicTo(cx - s * 0.2f, cy + s * 0.2f, cx - s * 0.1f, cy + s * 0.1f, cx, cy)
            cubicTo(cx + s * 0.1f, cy + s * 0.1f, cx + s * 0.2f, cy + s * 0.2f, cx + s * 0.4f, cy + s * 0.3f)
            cubicTo(cx + s * 0.7f, cy + s * 0.4f, cx + s * 1.0f, cy + s * 0.3f, cx + s * 0.95f, cy)
            cubicTo(cx + s * 0.9f, cy - s * 0.4f, cx + s * 0.3f, cy - s * 0.5f, cx, cy - s * 0.1f)
            close()
        }
        drawPath(mustachePath, color = Color(0xFFFF1493))
        drawPath(mustachePath, color = Color(0xFFFF69B4), style = Stroke(width = 6f))

        // White 'M' above
        val mPath = Path().apply {
            moveTo(cx - s * 0.4f, cy - s * 0.35f)
            lineTo(cx - s * 0.4f, cy - s * 0.85f)
            lineTo(cx, cy - s * 0.55f)
            lineTo(cx + s * 0.4f, cy - s * 0.85f)
            lineTo(cx + s * 0.4f, cy - s * 0.35f)
        }
        drawPath(mPath, color = Color.White, style = Stroke(width = 16f, cap = StrokeCap.Round))
    }
}

@Composable
fun SidemenLogo() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(0xFF1E1E1E),
                radius = size.minDimension * 0.42f,
                style = Stroke(width = 4f)
            )
        }
        Text(
            text = "XIX",
            color = Color.White,
            fontSize = 62.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 10.sp
        )
    }
}

@Composable
fun FerrariLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f

        // Yellow Shield
        val shieldPath = Path().apply {
            moveTo(cx - s * 0.8f, cy - s * 0.9f)
            lineTo(cx + s * 0.8f, cy - s * 0.9f)
            cubicTo(cx + s * 0.9f, cy + s * 0.1f, cx + s * 0.5f, cy + s * 0.9f, cx, cy + s * 1.1f)
            cubicTo(cx - s * 0.5f, cy + s * 0.9f, cx - s * 0.9f, cy + s * 0.1f, cx - s * 0.8f, cy - s * 0.9f)
            close()
        }
        drawPath(shieldPath, color = Color(0xFFFFE600))
        drawPath(shieldPath, color = Color.Black, style = Stroke(width = 8f))

        // Italian Tricolor header
        drawRect(color = Color(0xFF009246), topLeft = Offset(cx - s * 0.75f, cy - s * 0.85f), size = Size(s * 0.5f, s * 0.15f))
        drawRect(color = Color.White, topLeft = Offset(cx - s * 0.25f, cy - s * 0.85f), size = Size(s * 0.5f, s * 0.15f))
        drawRect(color = Color(0xFFCE2B37), topLeft = Offset(cx + s * 0.25f, cy - s * 0.85f), size = Size(s * 0.5f, s * 0.15f))

        // Prancing horse silhouette
        val horsePath = Path().apply {
            moveTo(cx, cy - s * 0.5f)
            cubicTo(cx - s * 0.2f, cy - s * 0.3f, cx - s * 0.3f, cy, cx - s * 0.15f, cy + s * 0.3f)
            lineTo(cx - s * 0.35f, cy + s * 0.7f)
            lineTo(cx - s * 0.15f, cy + s * 0.65f)
            lineTo(cx, cy + s * 0.4f)
            lineTo(cx + s * 0.2f, cy + s * 0.7f)
            lineTo(cx + s * 0.1f, cy + s * 0.3f)
            cubicTo(cx + s * 0.3f, cy, cx + s * 0.2f, cy - s * 0.3f, cx, cy - s * 0.5f)
            close()
        }
        drawPath(horsePath, color = Color.Black)
    }
}

@Composable
fun LamborghiniLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f
        val gold = Color(0xFFD4AF37)

        val shield = Path().apply {
            moveTo(cx - s * 0.8f, cy - s * 0.9f)
            lineTo(cx + s * 0.8f, cy - s * 0.9f)
            lineTo(cx + s * 0.85f, cy + s * 0.1f)
            cubicTo(cx + s * 0.85f, cy + s * 0.7f, cx + s * 0.4f, cy + s * 1.0f, cx, cy + s * 1.15f)
            cubicTo(cx - s * 0.4f, cy + s * 1.0f, cx - s * 0.85f, cy + s * 0.7f, cx - s * 0.85f, cy + s * 0.1f)
            close()
        }
        drawPath(shield, color = Color(0xFF0C0C0C))
        drawPath(shield, color = gold, style = Stroke(width = 10f))

        // Charging Golden Bull
        val bull = Path().apply {
            moveTo(cx - s * 0.3f, cy - s * 0.3f)
            lineTo(cx, cy - s * 0.1f)
            lineTo(cx + s * 0.4f, cy - s * 0.2f)
            lineTo(cx + s * 0.35f, cy + s * 0.2f)
            lineTo(cx + s * 0.1f, cy + s * 0.45f)
            lineTo(cx - s * 0.3f, cy + s * 0.35f)
            close()
        }
        drawPath(bull, color = gold)
    }
}

@Composable
fun BmwLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.38f

        // Outer black ring
        drawCircle(color = Color.Black, radius = r, center = Offset(cx, cy))
        drawCircle(color = Color(0xFF94A3B8), radius = r, center = Offset(cx, cy), style = Stroke(width = 8f))

        // Inner quadrants
        val ir = r * 0.65f
        drawCircle(color = Color.White, radius = ir, center = Offset(cx, cy))

        // Top-right and bottom-left blue
        drawArc(
            color = Color(0xFF0066B1),
            startAngle = 270f,
            sweepAngle = 90f,
            useCenter = true,
            topLeft = Offset(cx - ir, cy - ir),
            size = Size(ir * 2, ir * 2)
        )
        drawArc(
            color = Color(0xFF0066B1),
            startAngle = 90f,
            sweepAngle = 90f,
            useCenter = true,
            topLeft = Offset(cx - ir, cy - ir),
            size = Size(ir * 2, ir * 2)
        )
        drawCircle(color = Color(0xFF94A3B8), radius = ir, center = Offset(cx, cy), style = Stroke(width = 4f))
    }
}

@Composable
fun MercedesLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.38f

        // Chrome circle
        drawCircle(color = Color(0xFFCBD5E1), radius = r, center = Offset(cx, cy), style = Stroke(width = 16f))

        // 3-point star
        for (angle in listOf(270.0, 30.0, 150.0)) {
            val rad = Math.toRadians(angle)
            val px = cx + (r * 0.95f * cos(rad)).toFloat()
            val py = cy + (r * 0.95f * sin(rad)).toFloat()
            drawLine(
                color = Color(0xFFF8FAFC),
                start = Offset(cx, cy),
                end = Offset(px, py),
                strokeWidth = 12f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun AudiLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.18f
        val spacing = r * 1.35f
        val startX = size.width * 0.5f - spacing * 1.5f

        for (i in 0..3) {
            val cx = startX + i * spacing
            drawCircle(
                color = Color(0xFF27272A),
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(width = 14f)
            )
        }
    }
}

@Composable
fun AdidasLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.35f

        // 3 Mountain stripes
        val stripe1 = Path().apply {
            moveTo(cx - s * 0.85f, cy + s * 0.5f)
            lineTo(cx - s * 0.45f, cy + s * 0.5f)
            lineTo(cx - s * 0.65f, cy + s * 0.05f)
            lineTo(cx - s * 1.0f, cy + s * 0.25f)
            close()
        }
        val stripe2 = Path().apply {
            moveTo(cx - s * 0.35f, cy + s * 0.5f)
            lineTo(cx + s * 0.05f, cy + s * 0.5f)
            lineTo(cx - s * 0.25f, cy - s * 0.35f)
            lineTo(cx - s * 0.6f, cy - s * 0.15f)
            close()
        }
        val stripe3 = Path().apply {
            moveTo(cx + s * 0.15f, cy + s * 0.5f)
            lineTo(cx + s * 0.55f, cy + s * 0.5f)
            lineTo(cx + s * 0.1f, cy - s * 0.75f)
            lineTo(cx - s * 0.25f, cy - s * 0.55f)
            close()
        }

        drawPath(stripe1, color = Color.Black)
        drawPath(stripe2, color = Color.Black)
        drawPath(stripe3, color = Color.Black)
    }
}

@Composable
fun GucciLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.48f
        val r = size.minDimension * 0.25f
        val strokeW = r * 0.3f

        // Left G
        drawArc(
            color = Color(0xFF18181B),
            startAngle = 45f,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(cx - r * 1.35f, cy - r),
            size = Size(r * 2, r * 2),
            style = Stroke(strokeW, cap = StrokeCap.Round)
        )
        drawLine(
            color = Color(0xFF18181B),
            start = Offset(cx - r * 0.35f, cy),
            end = Offset(cx - r * 0.9f, cy),
            strokeWidth = strokeW,
            cap = StrokeCap.Square
        )

        // Right Mirrored G
        drawArc(
            color = Color(0xFF18181B),
            startAngle = 225f,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(cx - r * 0.65f, cy - r),
            size = Size(r * 2, r * 2),
            style = Stroke(strokeW, cap = StrokeCap.Round)
        )
        drawLine(
            color = Color(0xFF18181B),
            start = Offset(cx + r * 0.35f, cy),
            end = Offset(cx + r * 0.9f, cy),
            strokeWidth = strokeW,
            cap = StrokeCap.Square
        )
    }
}

@Composable
fun SupremeLogo() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.size(width = 240.dp, height = 80.dp)) {
            drawRect(color = Color(0xFFDA291C))
        }
        Text(
            text = "Supreme",
            color = Color.White,
            fontSize = 42.sp,
            fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic,
            letterSpacing = (-1).sp
        )
    }
}

@Composable
fun PumaLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.4f

        val puma = Path().apply {
            moveTo(cx + s * 0.8f, cy - s * 0.4f)
            cubicTo(cx + s * 0.5f, cy - s * 0.6f, cx + s * 0.1f, cy - s * 0.5f, cx - s * 0.2f, cy - s * 0.2f)
            cubicTo(cx - s * 0.4f, cy, cx - s * 0.7f, cy + s * 0.1f, cx - s * 0.9f, cy - s * 0.1f)
            cubicTo(cx - s * 0.7f, cy + s * 0.4f, cx - s * 0.3f, cy + s * 0.5f, cx, cy + s * 0.3f)
            cubicTo(cx + s * 0.3f, cy + s * 0.1f, cx + s * 0.6f, cy + s * 0.3f, cx + s * 0.8f, cy + s * 0.1f)
            close()
        }
        drawPath(puma, color = Color.Black)
    }
}

@Composable
fun LouisVuittonLogo() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Text(
            text = "LV",
            color = Color(0xFFD4AF37),
            fontSize = 68.sp,
            fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic,
            letterSpacing = 6.sp
        )
    }
}

@Composable
fun MinecraftLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.42f

        // Green face base
        drawRect(
            color = Color(0xFF22C55E),
            topLeft = Offset(cx - s, cy - s),
            size = Size(s * 2, s * 2)
        )

        // Creeper eyes & mouth in black
        val u = s * 0.25f
        // Eyes
        drawRect(color = Color.Black, topLeft = Offset(cx - s * 0.75f, cy - s * 0.5f), size = Size(u * 1.5f, u * 1.5f))
        drawRect(color = Color.Black, topLeft = Offset(cx + s * 0.75f - u * 1.5f, cy - s * 0.5f), size = Size(u * 1.5f, u * 1.5f))
        // Nose bridge
        drawRect(color = Color.Black, topLeft = Offset(cx - u, cy - s * 0.1f), size = Size(u * 2, u * 2))
        // Mouth
        drawRect(color = Color.Black, topLeft = Offset(cx - s * 0.5f, cy + s * 0.15f), size = Size(u * 1.2f, u * 2.5f))
        drawRect(color = Color.Black, topLeft = Offset(cx + s * 0.5f - u * 1.2f, cy + s * 0.15f), size = Size(u * 1.2f, u * 2.5f))
    }
}

@Composable
fun RobloxLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f

        rotate(-15f, pivot = Offset(cx, cy)) {
            drawRoundRect(
                color = Color.Black,
                topLeft = Offset(cx - s, cy - s),
                size = Size(s * 2, s * 2),
                cornerRadius = CornerRadius(16f, 16f)
            )
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(cx - s * 0.36f, cy - s * 0.36f),
                size = Size(s * 0.72f, s * 0.72f),
                cornerRadius = CornerRadius(8f, 8f)
            )
        }
    }
}

@Composable
fun TikTokLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f

        // Chromatic Glitch: Cyan offset, Magenta offset, White center
        val drawNote: (Color, Float, Float) -> Unit = { col, ox, oy ->
            val note = Path().apply {
                moveTo(cx + ox + s * 0.1f, cy + oy - s * 0.8f)
                lineTo(cx + ox + s * 0.5f, cy + oy - s * 0.8f)
                lineTo(cx + ox + s * 0.5f, cy + oy + s * 0.3f)
                cubicTo(
                    cx + ox + s * 0.5f, cy + oy + s * 0.7f,
                    cx + ox + s * 0.1f, cy + oy + s * 0.8f,
                    cx + ox - s * 0.2f, cy + oy + s * 0.8f
                )
                cubicTo(
                    cx + ox - s * 0.6f, cy + oy + s * 0.8f,
                    cx + ox - s * 0.7f, cy + oy + s * 0.4f,
                    cx + ox - s * 0.4f, cy + oy + s * 0.3f
                )
                cubicTo(
                    cx + ox - s * 0.1f, cy + oy + s * 0.3f,
                    cx + ox, cy + oy + s * 0.45f,
                    cx + ox + s * 0.1f, cy + oy + s * 0.35f
                )
                lineTo(cx + ox + s * 0.1f, cy + oy - s * 0.8f)
                close()
            }
            drawPath(note, color = col)
        }

        drawNote(Color(0xFF25F4EE), -12f, -10f)
        drawNote(Color(0xFFFE2C55), 12f, 10f)
        drawNote(Color.White, 0f, 0f)
    }
}

@Composable
fun InstagramLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f

        // Sunset gradient background
        drawRoundRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFFFDC80),
                    Color(0xFFF77737),
                    Color(0xFFF56040),
                    Color(0xFFFD1D1D),
                    Color(0xFFC13584),
                    Color(0xFF833AB4)
                ),
                center = Offset(cx - s, cy + s),
                radius = s * 2.5f
            ),
            topLeft = Offset(cx - s, cy - s),
            size = Size(s * 2, s * 2),
            cornerRadius = CornerRadius(s * 0.5f, s * 0.5f)
        )

        // White Camera outline
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(cx - s * 0.6f, cy - s * 0.6f),
            size = Size(s * 1.2f, s * 1.2f),
            cornerRadius = CornerRadius(s * 0.35f, s * 0.35f),
            style = Stroke(width = 16f)
        )
        // Center lens
        drawCircle(color = Color.White, radius = s * 0.32f, center = Offset(cx, cy), style = Stroke(width = 16f))
        // Flash dot
        drawCircle(color = Color.White, radius = s * 0.09f, center = Offset(cx + s * 0.35f, cy - s * 0.35f))
    }
}

@Composable
fun SteamLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.38f

        drawCircle(color = Color(0xFF1B2838), radius = r, center = Offset(cx, cy))
        drawCircle(color = Color(0xFF66C0F4), radius = r, center = Offset(cx, cy), style = Stroke(width = 8f))

        rotate(-30f, pivot = Offset(cx, cy)) {
            val pColor = Color(0xFFC7D5E0)
            drawCircle(color = pColor, radius = r * 0.35f, center = Offset(cx - r * 0.35f, cy))
            drawCircle(color = Color(0xFF171A21), radius = r * 0.16f, center = Offset(cx - r * 0.35f, cy))

            drawCircle(color = pColor, radius = r * 0.2f, center = Offset(cx + r * 0.45f, cy + r * 0.3f))
            drawCircle(color = Color(0xFF171A21), radius = r * 0.09f, center = Offset(cx + r * 0.45f, cy + r * 0.3f))

            drawLine(
                color = pColor,
                start = Offset(cx - r * 0.35f, cy),
                end = Offset(cx + r * 0.45f, cy + r * 0.3f),
                strokeWidth = r * 0.25f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun NetflixLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f
        val darkRed = Color(0xFFB81D24)
        val brightRed = Color(0xFFE50914)
        val legW = s * 0.35f

        // Left leg
        drawRect(
            color = darkRed,
            topLeft = Offset(cx - s * 0.8f, cy - s),
            size = Size(legW, s * 2)
        )
        // Right leg
        drawRect(
            color = darkRed,
            topLeft = Offset(cx + s * 0.8f - legW, cy - s),
            size = Size(legW, s * 2)
        )
        // Diagonal ribbon with drop shadow effect
        val diagonal = Path().apply {
            moveTo(cx - s * 0.8f, cy - s)
            lineTo(cx - s * 0.8f + legW, cy - s)
            lineTo(cx + s * 0.8f, cy + s)
            lineTo(cx + s * 0.8f - legW, cy + s)
            close()
        }
        drawPath(diagonal, color = brightRed)
    }
}

@Composable
fun StarbucksLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.38f

        drawCircle(color = Color(0xFF00704A), radius = r, center = Offset(cx, cy))

        // White crowned Siren
        drawCircle(color = Color.White, radius = r * 0.35f, center = Offset(cx, cy - r * 0.1f))
        // Crown
        val crown = Path().apply {
            moveTo(cx - r * 0.4f, cy - r * 0.35f)
            lineTo(cx - r * 0.25f, cy - r * 0.7f)
            lineTo(cx, cy - r * 0.45f)
            lineTo(cx + r * 0.25f, cy - r * 0.7f)
            lineTo(cx + r * 0.4f, cy - r * 0.35f)
            close()
        }
        drawPath(crown, color = Color.White)
        // Star in crown
        drawCircle(color = Color(0xFF00704A), radius = r * 0.08f, center = Offset(cx, cy - r * 0.5f))
    }
}

@Composable
fun PlayStationLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f

        // Horizontal Shadow layers (Yellow, Cyan, Green)
        drawRect(color = Color(0xFFFFD500), topLeft = Offset(cx - s * 0.6f, cy + s * 0.4f), size = Size(s * 1.2f, s * 0.15f))
        drawRect(color = Color(0xFF00A0E9), topLeft = Offset(cx - s * 0.7f, cy + s * 0.55f), size = Size(s * 1.2f, s * 0.15f))
        drawRect(color = Color(0xFF00AA66), topLeft = Offset(cx - s * 0.8f, cy + s * 0.7f), size = Size(s * 1.2f, s * 0.15f))

        // Red Upright 'P'
        val pStem = Path().apply {
            moveTo(cx - s * 0.5f, cy + s * 0.4f)
            lineTo(cx - s * 0.2f, cy + s * 0.4f)
            lineTo(cx - s * 0.2f, cy - s * 0.8f)
            cubicTo(cx + s * 0.4f, cy - s * 0.8f, cx + s * 0.5f, cy - s * 0.5f, cx + s * 0.5f, cy - s * 0.2f)
            cubicTo(cx + s * 0.5f, cy + s * 0.1f, cx + s * 0.3f, cy + s * 0.3f, cx - s * 0.2f, cy + s * 0.3f)
            close()
        }
        drawPath(pStem, color = Color(0xFFE4002B))
        drawCircle(color = Color.White, radius = s * 0.15f, center = Offset(cx + s * 0.15f, cy - s * 0.25f))
    }
}

@Composable
fun TwitchLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f
        val purple = Color(0xFF9146FF)

        val bubble = Path().apply {
            moveTo(cx - s * 0.8f, cy - s * 0.9f)
            lineTo(cx + s * 0.8f, cy - s * 0.9f)
            lineTo(cx + s * 0.8f, cy + s * 0.3f)
            lineTo(cx + s * 0.3f, cy + s * 0.8f)
            lineTo(cx - s * 0.1f, cy + s * 0.8f)
            lineTo(cx - s * 0.3f, cy + s * 1.0f)
            lineTo(cx - s * 0.3f, cy + s * 0.8f)
            lineTo(cx - s * 0.8f, cy + s * 0.8f)
            close()
        }
        drawPath(bubble, color = purple)

        // White inner eye slits
        drawRect(color = Color.White, topLeft = Offset(cx - s * 0.35f, cy - s * 0.35f), size = Size(s * 0.2f, s * 0.5f))
        drawRect(color = Color.White, topLeft = Offset(cx + s * 0.15f, cy - s * 0.35f), size = Size(s * 0.2f, s * 0.5f))
    }
}

@Composable
fun RedBullLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.32f

        // Golden Sun
        drawCircle(color = Color(0xFFFFCC00), radius = r, center = Offset(cx, cy))

        // Two Clashing Crimson Bulls
        val red = Color(0xFFCC0000)
        // Left bull
        val leftBull = Path().apply {
            moveTo(cx - r * 1.2f, cy + r * 0.3f)
            cubicTo(cx - r * 0.8f, cy - r * 0.4f, cx - r * 0.3f, cy - r * 0.3f, cx - r * 0.05f, cy)
            lineTo(cx - r * 0.2f, cy + r * 0.4f)
            close()
        }
        drawPath(leftBull, color = red)

        // Right bull
        val rightBull = Path().apply {
            moveTo(cx + r * 1.2f, cy + r * 0.3f)
            cubicTo(cx + r * 0.8f, cy - r * 0.4f, cx + r * 0.3f, cy - r * 0.3f, cx + r * 0.05f, cy)
            lineTo(cx + r * 0.2f, cy + r * 0.4f)
            close()
        }
        drawPath(rightBull, color = red)
    }
}

@Composable
fun RolexLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.36f
        val gold = Color(0xFFEAB308)

        // Rolex 5-point crown
        val crown = Path().apply {
            moveTo(cx - s * 0.8f, cy - s * 0.2f)
            lineTo(cx - s * 0.6f, cy + s * 0.4f)
            lineTo(cx - s * 0.3f, cy - s * 0.6f)
            lineTo(cx - s * 0.2f, cy + s * 0.4f)
            lineTo(cx, cy - s * 0.8f)
            lineTo(cx + s * 0.2f, cy + s * 0.4f)
            lineTo(cx + s * 0.3f, cy - s * 0.6f)
            lineTo(cx + s * 0.6f, cy + s * 0.4f)
            lineTo(cx + s * 0.8f, cy - s * 0.2f)
            lineTo(cx + s * 0.5f, cy + s * 0.6f)
            lineTo(cx - s * 0.5f, cy + s * 0.6f)
            close()
        }
        drawPath(crown, color = gold)

        // 5 gold pearls on tips
        listOf(
            Offset(cx - s * 0.8f, cy - s * 0.25f),
            Offset(cx - s * 0.3f, cy - s * 0.65f),
            Offset(cx, cy - s * 0.85f),
            Offset(cx + s * 0.3f, cy - s * 0.65f),
            Offset(cx + s * 0.8f, cy - s * 0.25f)
        ).forEach { p ->
            drawCircle(color = Color(0xFFFEF08A), radius = 10f, center = p)
        }
    }
}

@Composable
fun BugattiLogo() {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width * 0.5f
            val cy = size.height * 0.5f
            val rx = size.width * 0.4f
            val ry = size.height * 0.3f

            drawOval(color = Color(0xFFD4D4D8), topLeft = Offset(cx - rx, cy - ry), size = Size(rx * 2, ry * 2))
            drawOval(color = Color(0xFFDC2626), topLeft = Offset(cx - rx * 0.95f, cy - ry * 0.95f), size = Size(rx * 1.9f, ry * 1.9f))
        }
        Text(
            text = "BUGATTI",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 6.sp
        )
    }
}

@Composable
fun NasaLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val r = size.minDimension * 0.38f

        drawCircle(color = Color(0xFF0B3D91), radius = r, center = Offset(cx, cy))

        // Orbital ellipse
        drawOval(
            color = Color.White,
            topLeft = Offset(cx - r * 0.9f, cy - r * 0.35f),
            size = Size(r * 1.8f, r * 0.7f),
            style = Stroke(width = 6f)
        )

        // Red Supersonic Vector Chevron
        val chevron = Path().apply {
            moveTo(cx - r * 0.7f, cy - r * 0.35f)
            lineTo(cx + r * 0.8f, cy + r * 0.1f)
            lineTo(cx - r * 0.5f, cy + r * 0.5f)
            lineTo(cx - r * 0.3f, cy + r * 0.15f)
            close()
        }
        drawPath(chevron, color = Color(0xFFFC3D21))
    }
}

@Composable
fun PorscheLogo() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f
        val s = size.minDimension * 0.38f
        val gold = Color(0xFFF59E0B)

        val shield = Path().apply {
            moveTo(cx - s * 0.7f, cy - s * 0.9f)
            lineTo(cx + s * 0.7f, cy - s * 0.9f)
            lineTo(cx + s * 0.7f, cy + s * 0.1f)
            cubicTo(cx + s * 0.7f, cy + s * 0.6f, cx + s * 0.35f, cy + s * 0.95f, cx, cy + s * 1.15f)
            cubicTo(cx - s * 0.35f, cy + s * 0.95f, cx - s * 0.7f, cy + s * 0.6f, cx - s * 0.7f, cy + s * 0.1f)
            close()
        }
        drawPath(shield, color = gold)
        drawPath(shield, color = Color(0xFFB45309), style = Stroke(width = 6f))

        // Red and black stripes
        drawRect(color = Color.Black, topLeft = Offset(cx - s * 0.6f, cy - s * 0.45f), size = Size(s * 0.55f, s * 0.7f))
        drawRect(color = Color(0xFFDC2626), topLeft = Offset(cx + s * 0.05f, cy - s * 0.45f), size = Size(s * 0.55f, s * 0.7f))
    }
}

@Composable
fun GenericLogo(item: QuizItem) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(item.primaryColor),
                radius = size.minDimension * 0.35f,
                center = center
            )
        }
        Text(
            text = item.cleanAnswer.take(4),
            color = Color(item.accentColor),
            fontSize = 32.sp,
            fontWeight = FontWeight.Black
        )
    }
}
