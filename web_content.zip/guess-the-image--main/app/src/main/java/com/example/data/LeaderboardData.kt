package com.example.data

import android.content.Context
import com.example.model.LeaderboardEntry
import org.json.JSONArray
import org.json.JSONObject

class LeaderboardRepository(context: Context) {
    private val prefs = context.getSharedPreferences("guess_the_image_leaderboard", Context.MODE_PRIVATE)

    private val defaultEntries = listOf(
        LeaderboardEntry("lead_1", "PixelHunter", 18450, 7, 96, "👑", "10 mins ago", 18),
        LeaderboardEntry("lead_2", "LogoSavant", 16200, 7, 92, "🦉", "35 mins ago", 14),
        LeaderboardEntry("lead_3", "ChampionPlayer", 15000, 6, 94, "🏆", "Just now", 12),
        LeaderboardEntry("lead_4", "ApexGamer", 14750, 6, 89, "⚡", "1 hour ago", 11),
        LeaderboardEntry("lead_5", "CarEnthusiast", 12900, 5, 88, "🏎️", "3 hours ago", 9),
        LeaderboardEntry("lead_6", "BeastFan2026", 11400, 5, 85, "🔥", "5 hours ago", 8),
        LeaderboardEntry("lead_7", "VogueVibe", 9800, 4, 83, "✨", "Yesterday", 6),
        LeaderboardEntry("lead_8", "ZoomNovice", 7200, 3, 78, "🎯", "Yesterday", 4)
    )

    fun getLeaderboard(): List<LeaderboardEntry> {
        val raw = prefs.getString("entries_json", null) ?: return defaultEntries
        return try {
            val jsonArray = JSONArray(raw)
            val list = mutableListOf<LeaderboardEntry>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    LeaderboardEntry(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        score = obj.getInt("score"),
                        level = obj.getInt("level"),
                        accuracy = obj.getInt("accuracy"),
                        avatar = obj.getString("avatar"),
                        timestamp = obj.getString("timestamp"),
                        streak = obj.getInt("streak")
                    )
                )
            }
            list.sortedByDescending { it.score }
        } catch (_: Exception) {
            defaultEntries
        }
    }

    fun submitScore(
        name: String,
        score: Int,
        level: Int,
        accuracy: Int,
        avatar: String,
        streak: Int
    ): Pair<Int, List<LeaderboardEntry>> {
        val current = getLeaderboard().toMutableList()
        val cleanName = name.trim().ifEmpty { "Anonymous" }
        val existingIndex = current.indexOfFirst { it.name.equals(cleanName, ignoreCase = true) }

        val entry = LeaderboardEntry(
            id = if (existingIndex >= 0) current[existingIndex].id else "user_${System.currentTimeMillis()}",
            name = cleanName,
            score = if (existingIndex >= 0) maxOf(current[existingIndex].score, score) else score,
            level = if (existingIndex >= 0) maxOf(current[existingIndex].level, level) else level,
            accuracy = accuracy.coerceIn(0, 100),
            avatar = avatar,
            timestamp = "Just now",
            streak = streak
        )

        if (existingIndex >= 0) {
            current[existingIndex] = entry
        } else {
            current.add(entry)
        }

        val sorted = current.sortedByDescending { it.score }.take(100)
        saveEntries(sorted)
        val rank = sorted.indexOfFirst { it.id == entry.id } + 1
        return Pair(rank, sorted)
    }

    private fun saveEntries(entries: List<LeaderboardEntry>) {
        val array = JSONArray()
        for (e in entries) {
            val obj = JSONObject()
            obj.put("id", e.id)
            obj.put("name", e.name)
            obj.put("score", e.score)
            obj.put("level", e.level)
            obj.put("accuracy", e.accuracy)
            obj.put("avatar", e.avatar)
            obj.put("timestamp", e.timestamp)
            obj.put("streak", e.streak)
            array.put(obj)
        }
        prefs.edit().putString("entries_json", array.toString()).apply()
    }
}
