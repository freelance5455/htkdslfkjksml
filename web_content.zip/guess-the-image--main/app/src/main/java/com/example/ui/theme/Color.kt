package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GameDarkBackground = Color(0xFF0B0F19)
val GameSurfaceDark = Color(0xFF131B2B)
val GameSurfaceElevated = Color(0xFF1B2438)
val GameBorder = Color(0xFF26334D)

val GameAmber = Color(0xFFF59E0B)
val GameAmberBright = Color(0xFFFBBF24)
val GameRose = Color(0xFFF43F5E)
val GameEmerald = Color(0xFF10B981)
val GameCyan = Color(0xFF06B6D4)
val GameViolet = Color(0xFF8B5CF6)
val GameOrange = Color(0xFFF97316)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val SlotBorder = Color(0xFF334155)
val SlotFilledBorder = Color(0xFFF59E0B)

