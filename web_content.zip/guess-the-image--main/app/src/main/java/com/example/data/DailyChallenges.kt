package com.example.data

import com.example.model.DailyRecord
import com.example.model.QuizHints
import com.example.model.QuizItem
import com.example.model.UserStats
import com.example.model.ZoomTarget
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class DailyStreakMultiplierInfo(
    val multiplier: Float,
    val bonusPercent: Int,
    val label: String,
    val tierName: String,
    val badge: String,
    val nextThreshold: Int,
    val nextMultiplier: Float,
    val daysNeeded: Int
)

data class StreakTierMilestone(
    val days: Int,
    val multiplier: Float,
    val bonusPercent: Int,
    val tierName: String,
    val badge: String,
    val description: String
)

object DailyConfig {
    val STAGE_POINTS = mapOf(
        1 to 1000,
        2 to 750,
        3 to 500,
        4 to 300
    )
    const val COMPLETION_BONUS = 500
    const val COINS_REWARD = 100

    val TIERS = listOf(
        StreakTierMilestone(0, 1.0f, 0, "Starter", "⚡", "Complete your first daily challenge to unlock streak multipliers."),
        StreakTierMilestone(1, 1.1f, 10, "Bronze Spark", "🥉", "+10% score multiplier across all challenges and puzzles."),
        StreakTierMilestone(2, 1.2f, 20, "Silver Flame", "🥈", "+20% score multiplier for 2 consecutive days solved."),
        StreakTierMilestone(3, 1.3f, 30, "Golden Blaze", "🥇", "+30% score boost on every puzzle you solve."),
        StreakTierMilestone(4, 1.4f, 40, "Platinum Fire", "💎", "+40% score boost rewarding 4 days of dedication."),
        StreakTierMilestone(5, 1.5f, 50, "Inferno Streak", "🔥", "+50% score boost! 1.5x score on every single level."),
        StreakTierMilestone(7, 1.75f, 75, "Week Warrior", "👑", "+75% massive multiplier for a full uninterrupted week!"),
        StreakTierMilestone(14, 2.0f, 100, "Legendary Streak", "🌟", "2.0x DOUBLE POINTS! The ultimate badge of daily excellence.")
    )
}

object DailyChallenges {
    fun getTodayDateString(): String = com.example.data.getTodayDateString()
    fun getTodayDailyItem(): QuizItem = com.example.data.getDailyChallengeItem()
    fun getDailyItem(dateStr: String): QuizItem = com.example.data.getDailyChallengeItem(dateStr)
    fun getMultiplierInfo(streak: Int) = com.example.data.getDailyStreakMultiplier(streak)
    fun getStreakMultiplier(streak: Int): Float = com.example.data.getDailyStreakMultiplier(streak).multiplier
    fun getMultiplierLabel(multiplier: Float): String = String.format(Locale.US, "%.1fx", multiplier)
    fun formatDailyDate(dateStr: String): String = com.example.data.formatDailyDate(dateStr)
}

fun getTodayDateString(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return sdf.format(Date())
}

fun getYesterdayDateString(todayDateStr: String = getTodayDateString()): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val cal = Calendar.getInstance()
    cal.time = sdf.parse(todayDateStr) ?: Date()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    return sdf.format(cal.time)
}

fun formatDailyDate(dateStr: String): String {
    return try {
        val inFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US)
        val date = inFormat.parse(dateStr) ?: Date()
        outFormat.format(date)
    } catch (_: Exception) {
        dateStr
    }
}

fun getTimeUntilNextDaily(): String {
    val cal = Calendar.getInstance()
    val now = cal.timeInMillis
    cal.add(Calendar.DAY_OF_YEAR, 1)
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    val diff = (cal.timeInMillis - now).coerceAtLeast(0)
    val hours = diff / (1000 * 60 * 60)
    val minutes = (diff % (1000 * 60 * 60)) / (1000 * 60)
    val seconds = (diff % (1000 * 60)) / 1000
    return String.format(Locale.US, "%02dh %02dm %02ds", hours, minutes, seconds)
}

fun getEffectiveDailyStreak(stats: UserStats, todayDateStr: String = getTodayDateString()): Int {
    if (stats.dailyStreak <= 0 || stats.lastDailyDate == null) return 0
    if (stats.lastDailyDate == todayDateStr) return stats.dailyStreak
    val yesterday = getYesterdayDateString(todayDateStr)
    if (stats.lastDailyDate == yesterday) return stats.dailyStreak
    return 0
}

fun getDailyStreakMultiplier(streak: Int): DailyStreakMultiplierInfo {
    return when {
        streak <= 0 -> DailyStreakMultiplierInfo(
            multiplier = 1.0f,
            bonusPercent = 0,
            label = "1.0x",
            tierName = "No Streak",
            badge = "⚡",
            nextThreshold = 1,
            nextMultiplier = 1.1f,
            daysNeeded = 1
        )
        streak == 1 -> DailyStreakMultiplierInfo(
            multiplier = 1.1f,
            bonusPercent = 10,
            label = "1.1x (+10%)",
            tierName = "Bronze Spark",
            badge = "🥉",
            nextThreshold = 2,
            nextMultiplier = 1.2f,
            daysNeeded = 1
        )
        streak == 2 -> DailyStreakMultiplierInfo(
            multiplier = 1.2f,
            bonusPercent = 20,
            label = "1.2x (+20%)",
            tierName = "Silver Flame",
            badge = "🥈",
            nextThreshold = 3,
            nextMultiplier = 1.3f,
            daysNeeded = 1
        )
        streak == 3 -> DailyStreakMultiplierInfo(
            multiplier = 1.3f,
            bonusPercent = 30,
            label = "1.3x (+30%)",
            tierName = "Golden Blaze",
            badge = "🥇",
            nextThreshold = 4,
            nextMultiplier = 1.4f,
            daysNeeded = 1
        )
        streak == 4 -> DailyStreakMultiplierInfo(
            multiplier = 1.4f,
            bonusPercent = 40,
            label = "1.4x (+40%)",
            tierName = "Platinum Fire",
            badge = "💎",
            nextThreshold = 5,
            nextMultiplier = 1.5f,
            daysNeeded = 1
        )
        streak < 7 -> DailyStreakMultiplierInfo(
            multiplier = 1.5f,
            bonusPercent = 50,
            label = "1.5x (+50%)",
            tierName = "Inferno Streak",
            badge = "🔥",
            nextThreshold = 7,
            nextMultiplier = 1.75f,
            daysNeeded = 7 - streak
        )
        streak < 14 -> DailyStreakMultiplierInfo(
            multiplier = 1.75f,
            bonusPercent = 75,
            label = "1.75x (+75%)",
            tierName = "Week Warrior",
            badge = "👑",
            nextThreshold = 14,
            nextMultiplier = 2.0f,
            daysNeeded = 14 - streak
        )
        else -> DailyStreakMultiplierInfo(
            multiplier = 2.0f,
            bonusPercent = 100,
            label = "2.0x (Double Points)",
            tierName = "Legendary Streak",
            badge = "🌟",
            nextThreshold = streak + 1,
            nextMultiplier = 2.0f,
            daysNeeded = 0
        )
    }
}

val DAILY_CHALLENGE_ITEMS = listOf(
    QuizItem(
        id = "daily_rolex",
        name = "ROLEX",
        cleanAnswer = "ROLEX",
        category = "clothes",
        categoryLabel = "Luxury Timepieces",
        level = 7,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 72f, y = 32f, initialScale = 5.2f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Prestigious Swiss luxury watchmaker headquartered in Geneva.",
            clue2 = "Famous for the Oyster Perpetual and Daytona; trademark is a five-pointed golden coronet crown."
        ),
        primaryColor = 0xFF006039,
        bgColor = 0xFF042416,
        accentColor = 0xFFE5B128,
        description = "The iconic five-point golden coronet crown of Rolex, synonymous with prestige and precision.",
        logoType = "rolex"
    ),
    QuizItem(
        id = "daily_bugatti",
        name = "BUGATTI",
        cleanAnswer = "BUGATTI",
        category = "car",
        categoryLabel = "Hypercars",
        level = 7,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 45f, initialScale = 5.5f, stage2Scale = 3.4f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "French hypercar manufacturer known for the Veyron, Chiron, and Tourbillon producing over 1,500 hp.",
            clue2 = "Emblem is a red oval ringed with sixty silver pearls and the reversed 'EB' monogram of Ettore Bugatti."
        ),
        primaryColor = 0xFFDC2626,
        bgColor = 0xFF111827,
        accentColor = 0xFFF8FAFC,
        description = "The historic Ettore Bugatti red oval emblem with silver pearls, defining world-record speeds.",
        logoType = "bugatti"
    ),
    QuizItem(
        id = "daily_redbull",
        name = "RED BULL",
        cleanAnswer = "REDBULL",
        aliases = listOf("RED BULL RACING", "REDBULL ENERGY"),
        category = "company",
        categoryLabel = "Energy & Motorsports",
        level = 6,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 46f, initialScale = 5.2f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Austrian energy drink and dominant Formula 1 racing team whose slogan claims it 'gives you wings'.",
            clue2 = "Emblem depicts two muscular crimson charging bulls colliding heads in front of a radiant yellow sun."
        ),
        primaryColor = 0xFFDC2626,
        bgColor = 0xFF001B44,
        accentColor = 0xFFFBBF24,
        description = "The high-voltage Red Bull charging bulls clash against the golden sun.",
        logoType = "red-bull"
    ),
    QuizItem(
        id = "daily_nasa",
        name = "NASA",
        cleanAnswer = "NASA",
        category = "company",
        categoryLabel = "Space & Science",
        level = 6,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 58f, y = 38f, initialScale = 5.4f, stage2Scale = 3.3f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "United States government agency responsible for Apollo moon landings, James Webb, and Artemis.",
            clue2 = "Affectionately called the 'meatball' insignia: blue planetary sphere with stars and red supersonic chevron."
        ),
        primaryColor = 0xFF0B3D91,
        bgColor = 0xFF051636,
        accentColor = 0xFFFC3D21,
        description = "NASA's world-famous 'meatball' insignia representing space aeronautics and human exploration.",
        logoType = "nasa"
    ),
    QuizItem(
        id = "daily_porsche",
        name = "PORSCHE",
        cleanAnswer = "PORSCHE",
        category = "car",
        categoryLabel = "German Sports Cars",
        level = 6,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 42f, initialScale = 5.0f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Iconic sports car builder from Stuttgart, Germany, renowned for the rear-engine 911.",
            clue2 = "Gold heraldic crest combining black and red stripes, stag antlers of Württemberg, and a rearing stallion."
        ),
        primaryColor = 0xFFD97706,
        bgColor = 0xFF18181B,
        accentColor = 0xFFB91C1C,
        description = "The Porsche Stuttgart crest combining the Württemberg antlers with the legendary rearing black horse.",
        logoType = "porsche"
    ),
    QuizItem(
        id = "daily_pewdiepie",
        name = "PEWDIEPIE",
        cleanAnswer = "PEWDIEPIE",
        aliases = listOf("PEWDS", "FELIX KJELLBERG"),
        category = "youtuber",
        categoryLabel = "Top YouTubers",
        level = 7,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 52f, y = 48f, initialScale = 5.0f, stage2Scale = 3.1f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Swedish creator Felix Kjellberg, holder of YouTube's most legendary subscriber wars and 111M+ Bro Army.",
            clue2 = "Hallmark visual identity is the mesmerizing black-and-red optical wave pattern and iconic 'Brofist' gesture."
        ),
        primaryColor = 0xFFFF0055,
        bgColor = 0xFF0D0D0D,
        accentColor = 0xFFFF0033,
        description = "PewDiePie's signature black and crimson optical wave pattern with the central Brofist emblem.",
        logoType = "pewdiepie"
    ),
    QuizItem(
        id = "daily_sidemen",
        name = "SIDEMEN",
        cleanAnswer = "SIDEMEN",
        aliases = listOf("THE SIDEMEN", "SDMN"),
        category = "youtuber",
        categoryLabel = "YouTubers Logo",
        level = 7,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 48f, initialScale = 5.2f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Seven British YouTube creators behind XIX Vodka, Sides, and charity football matches.",
            clue2 = "Their minimalist luxury streetwear brand is celebrated by the Roman numeral XIX (19)."
        ),
        primaryColor = 0xFFFFFFFF,
        bgColor = 0xFF000000,
        accentColor = 0xFFA855F7,
        description = "The Sidemen XIX Roman numeral insignia, recognized worldwide across apparel and entertainment.",
        logoType = "sidemen"
    ),
    QuizItem(
        id = "daily_minecraft",
        name = "MINECRAFT",
        cleanAnswer = "MINECRAFT",
        aliases = listOf("CREEPER", "MOJANG"),
        category = "app_game",
        categoryLabel = "Sandbox Gaming",
        level = 6,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.2f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "The bestselling video game in human history with over 300 million copies sold.",
            clue2 = "Its most feared mob is the hissing, explosive Creeper with an iconic frowning pixelated face."
        ),
        primaryColor = 0xFF15803D,
        bgColor = 0xFF14532D,
        accentColor = 0xFF000000,
        description = "The pixelated face of the Minecraft Creeper, one of gaming's most memorable and terrifying creatures.",
        logoType = "creeper"
    ),
    QuizItem(
        id = "daily_twitch",
        name = "TWITCH",
        cleanAnswer = "TWITCH",
        category = "app_game",
        categoryLabel = "Live Streaming",
        level = 6,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 58f, y = 42f, initialScale = 5.0f, stage2Scale = 3.1f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Leading global livestreaming platform for gamers, esports, and creators, owned by Amazon.",
            clue2 = "Trademark is a vibrant purple robot-like speech bubble named 'Glitch' with two rectangular eyes."
        ),
        primaryColor = 0xFF9146FF,
        bgColor = 0xFF0E0E10,
        accentColor = 0xFFFFFFFF,
        description = "Twitch's iconic 'Glitch' mascot and vibrant purple speech bubble, symbol of live gaming culture.",
        logoType = "twitch"
    ),
    QuizItem(
        id = "daily_supreme",
        name = "SUPREME",
        cleanAnswer = "SUPREME",
        category = "clothes",
        categoryLabel = "Streetwear Royalty",
        level = 6,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 48f, y = 50f, initialScale = 5.2f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "New York City skateboarding and streetwear titan notorious for Thursday drops and high resale value.",
            clue2 = "World-famous red box logo with white text set in Futura Bold Oblique, inspired by artist Barbara Kruger."
        ),
        primaryColor = 0xFFDC2626,
        bgColor = 0xFF171717,
        accentColor = 0xFFFFFFFF,
        description = "The Supreme New York red box logo, the defining symbol of 21st-century streetwear hype.",
        logoType = "supreme"
    )
)

fun getDailyChallengeItem(dateStr: String = getTodayDateString()): QuizItem {
    var hash = 0
    for (i in dateStr.indices) {
        hash = (hash shl 5) - hash + dateStr[i].code
    }
    val index = Math.abs(hash) % DAILY_CHALLENGE_ITEMS.size
    return DAILY_CHALLENGE_ITEMS[index]
}
