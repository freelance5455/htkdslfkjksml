package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HintBar(
    score: Int,
    coins: Int,
    isSubtleClueUnlocked: Boolean,
    onUnlockSubtleClue: () -> Unit,
    subtleClueFeedback: String?,
    onRevealLetter: () -> Unit,
    onRemoveWrong: () -> Unit,
    onGetAiClue: () -> Unit,
    isLoadingAi: Boolean,
    activeClueText: String?,
    categoryLabel: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 500-Point Subtle Clue System Button
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable(enabled = !isSubtleClueUnlocked) { onUnlockSubtleClue() }
                .testTag("subtle_clue_button"),
            shape = RoundedCornerShape(16.dp),
            color = if (isSubtleClueUnlocked) {
                Color(0xFF1E2018)
            } else {
                GameSurfaceElevated
            },
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSubtleClueUnlocked) GameEmerald.copy(alpha = 0.5f) else GameAmber.copy(alpha = 0.4f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSubtleClueUnlocked) GameEmerald.copy(alpha = 0.2f) else GameAmber.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isSubtleClueUnlocked) Icons.Default.Check else Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = if (isSubtleClueUnlocked) GameEmerald else GameAmber,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Subtle Clue",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSubtleClueUnlocked) GameEmerald.copy(alpha = 0.2f) else GameAmber.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = if (isSubtleClueUnlocked) "UNLOCKED" else "Mystery Clue",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isSubtleClueUnlocked) GameEmerald else GameAmberBright,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = if (isSubtleClueUnlocked) "Clue displayed below" else "Reveals a subtle hint about this mystery image",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSubtleClueUnlocked) {
                        GameEmerald.copy(alpha = 0.15f)
                    } else if (score >= 500) {
                        GameAmber
                    } else {
                        Color(0xFF222F47)
                    }
                ) {
                    Text(
                        text = if (isSubtleClueUnlocked) "ACTIVE" else "500 PTS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isSubtleClueUnlocked) GameEmerald else if (score >= 500) Color(0xFF0F172A) else TextMuted,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Subtle clue feedback message (e.g. Insufficient score)
        AnimatedVisibility(visible = subtleClueFeedback != null) {
            subtleClueFeedback?.let { msg ->
                val isSuccess = msg.startsWith("-500")
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSuccess) Color(0xFF062E1A) else Color(0xFF3B0D18),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSuccess) GameEmerald.copy(alpha = 0.6f) else GameRose.copy(alpha = 0.6f)
                    )
                ) {
                    Text(
                        text = msg,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSuccess) GameEmerald else GameRose,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // Unlocked Active Clue Box
        AnimatedVisibility(
            visible = activeClueText != null,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            activeClueText?.let { clue ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF161F38),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GameAmber.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = GameAmber,
                            modifier = Modifier
                                .size(18.dp)
                                .padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "CLUE ($categoryLabel):",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = GameAmberBright,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "\"$clue\"",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // 3 Coin Hints Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Reveal 1 Letter (20 coins)
            HintButton(
                title = "Reveal Letter",
                cost = "20 🪙",
                icon = Icons.Default.Lightbulb,
                iconColor = GameAmber,
                enabled = coins >= 20,
                onClick = onRevealLetter,
                modifier = Modifier.weight(1f),
                tag = "hint_reveal_button"
            )

            // Remove 3 Wrong (30 coins)
            HintButton(
                title = "Remove 3",
                cost = "30 🪙",
                icon = Icons.Default.DeleteSweep,
                iconColor = GameRose,
                enabled = coins >= 30,
                onClick = onRemoveWrong,
                modifier = Modifier.weight(1f),
                tag = "hint_remove_button"
            )

            // AI Clue (25 coins)
            HintButton(
                title = if (isLoadingAi) "Thinking..." else "AI Clue",
                cost = "25 🪙",
                icon = Icons.Default.SmartToy,
                iconColor = GameViolet,
                enabled = coins >= 25 && !isLoadingAi,
                onClick = onGetAiClue,
                isLoading = isLoadingAi,
                modifier = Modifier.weight(1f),
                tag = "hint_ai_button"
            )
        }
    }
}

@Composable
private fun HintButton(
    title: String,
    cost: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    tag: String = ""
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled) { onClick() }
            .testTag(tag),
        shape = RoundedCornerShape(14.dp),
        color = if (enabled) GameSurfaceDark else Color(0xFF101624),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (enabled) Color(0xFF26334D) else Color(0xFF1A2234)
        )
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp,
                    color = GameViolet
                )
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (enabled) iconColor else TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (enabled) TextPrimary else TextMuted,
                maxLines = 1
            )
            Text(
                text = cost,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (enabled) GameAmberBright else TextMuted
            )
        }
    }
}
