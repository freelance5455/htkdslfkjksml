package com.example.ai

import com.example.BuildConfig
import com.example.model.QuizItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClueService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun getMysteryClue(item: QuizItem): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext item.hints.clue1
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val promptText = "You are a fun game show host for the game 'GUESS THE IMAGE'. The player is guessing a zoomed-in logo for '${item.name}' in category '${item.categoryLabel}'. Give a clever, mysterious 1-sentence clue (maximum 15 words) that helps the player guess WITHOUT mentioning the name '${item.name}' or directly giving it away. Be punchy and playful!"

            val partsArray = JSONArray().apply {
                put(JSONObject().put("text", promptText))
            }
            val contentsArray = JSONArray().apply {
                put(JSONObject().put("parts", partsArray))
            }
            val requestJson = JSONObject().apply {
                put("contents", contentsArray)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext item.hints.clue1
            }

            val responseBody = response.body?.string() ?: return@withContext item.hints.clue1
            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates") ?: return@withContext item.hints.clue1
            val firstCandidate = candidates.optJSONObject(0) ?: return@withContext item.hints.clue1
            val content = firstCandidate.optJSONObject("content") ?: return@withContext item.hints.clue1
            val parts = content.optJSONArray("parts") ?: return@withContext item.hints.clue1
            val text = parts.optJSONObject(0)?.optString("text")?.trim()

            if (!text.isNullOrBlank()) {
                text.replace("\"", "")
            } else {
                item.hints.clue1
            }
        } catch (_: Exception) {
            item.hints.clue1
        }
    }
}
