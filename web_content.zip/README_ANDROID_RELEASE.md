# TEVET POWER APP — Android Packaging, Google Play Store & Backend Setup Guide

**Tagline:** *Learn, Connect, Share and Build Your Future*
**Target Market:** Malawi (initial primary market) & International Technical Learners
**Suggested Android Package ID:** `mw.tevetpower.app`

---

## 1. Architecture Summary

This repository contains the complete, live full-stack application:
- **Frontend & PWA:** React 19 + TypeScript + Tailwind CSS v4 + `vite-plugin-pwa` (installable directly on Android devices via Chrome "Install App" / in-app install prompt, with offline library caching).
- **Backend Server (`server.ts`):** Express + WebSockets (`ws`) for WebRTC signaling (1-to-1 voice/video calls), live typing indicators, online presence, server-side Gemini AI (`@google/genai`), and Malawi mobile money merchant gateway endpoints.
- **Database & Auth:** Firebase Authentication + Cloud Firestore with hardened RBAC security rules (`firestore.rules`).

---

## 2. Generating a Signed / Shareable Android APK (SHAREit, Bluetooth, WhatsApp) & Play Store AAB

Because this cloud sandbox runs a Node.js runtime without a local Android SDK or Java JDK installed, compile the real `.apk` / `.aab` release artifacts using either the included **GitHub Actions workflow** or **Capacitor** (`capacitor.config.ts` is already pre-configured):

### Option A: Automated Cloud APK Build (No Android Studio Needed)
1. Push this repository to GitHub.
2. Open **Actions → Build TEVET POWER APP Android APK** (`.github/workflows/build-android-apk.yml`) and run it.
3. Download the `TEVET-POWER-APP-APK` artifact (`app-debug.apk`), rename it to `TEVET-POWER-APP.apk`, and share directly over **SHAREit, Bluetooth, WhatsApp, Xender, or Facebook Messenger**.

### Option B: Local Capacitor Build
```bash
# 1. Build the optimized production bundle
npm install
npm run build

# 2. Add the native Android project using the pre-configured capacitor.config.ts
npm install --no-save @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync android
```

### Android Permissions (`android/app/src/main/AndroidManifest.xml`)
Ensure the following permissions are declared for voice notes, WebRTC calls, camera uploads, and offline storage:
- `android.permission.INTERNET`
- `android.permission.ACCESS_NETWORK_STATE`
- `android.permission.CAMERA`
- `android.permission.RECORD_AUDIO`
- `android.permission.MODIFY_AUDIO_SETTINGS`
- `android.permission.POST_NOTIFICATIONS`

### Signing & Building Release Artifacts
1. Generate an upload keystore:
   ```bash
   keytool -genkey -v -keystore tevet-power-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias tevetpower
   ```
2. Configure `signingConfigs.release` in `android/app/build.gradle` (`minSdkVersion 26` for Android 8.0+).
3. Build shareable signed APK (WhatsApp / Telegram / Bluetooth distribution):
   ```bash
   cd android && ./gradlew assembleRelease
   ```
4. Build Google Play App Bundle (AAB):
   ```bash
   cd android && ./gradlew bundleRelease
   ```

---

## 3. Malawi Mobile Money & Google Play Billing Configuration

- **Never hardcode merchant numbers or secrets in client code.**
- Configure server environment secrets in your hosting environment (`.env`):
  - `PAYMENT_GATEWAY_PROVIDER`
  - `AIRTEL_MONEY_CLIENT_ID` & `AIRTEL_MONEY_CLIENT_SECRET` & `AIRTEL_MONEY_MERCHANT_MSISDN`
  - `TNM_MPAMBA_API_KEY` & `TNM_MPAMBA_MERCHANT_CODE`
  - `PAYMENT_WEBHOOK_SECRET`
- **Google Play Store Policy Notice:** For distribution via Google Play Console, configure Google Play Billing (`com.android.billingclient:billing`) for digital educational subscriptions in countries where Google Play mandates in-app billing, and use Airtel Money / TNM Mpamba merchant APIs strictly where permitted by Google Play distribution policies and local regulations.

---

## 4. Google Play Console Metadata & Data Safety

- **Short Description:** TEVETA Malawi digital library, technical social network, chats, calls & AI study tutor.
- **Category:** Education
- **Content Rating:** Everyone / Teen (moderated user-generated posts with reporting & blocking).
- **Data Safety Disclosure:**
  - Collects: Name, Email/Phone (optional), Profile Photo, User Posts, Messages, Audio/Video streams during live calls (not stored).
  - Security: Data encrypted in transit (HTTPS/WSS), strict Firestore RBAC, PII isolated to owner/admin, in-app account deletion supported.
