// Pruebas del banner mixto: node tests.js
const fs=require('fs'),h=fs.readFileSync(__dirname+'/index.html','utf8'),sc=[...h.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
let ok=0,bad=0;const T=(n,c)=>{c?ok++:(bad++,console.log('FALLA',n))};
sc.forEach((c,i)=>{try{new Function(c);T('sintaxis script '+i,true)}catch(e){T('sintaxis script '+i+': '+e.message,false)}});
const BAL=new Function(sc[0]+';return BAL')();
// reconstruir el banner desde el script principal (datos puros)
const m=sc[1],ex=n=>{const a=m.indexOf('const '+n+'=');return a};
const CH=new Function(m.slice(ex('CH'),ex('POOL'))+';return {CH,SUP}')();
const POOL=[1,2,3,4,5,6,7,8],GU=[...POOL.map(i=>({r:CH.CH[i].r,cat:'ch'})),...CH.SUP.map(q=>({r:q.r,cat:'su'}))];
T('probabilidades suman 100',BAL.SPIN_W.reduce((a,b)=>a+b)===100);
const w=BAL.weights(GU,0),tot=w.reduce((a,b)=>a+b);T('pesos suman 100',Math.abs(tot-100)<1e-9);
[0,1,2,3].forEach(r=>T('rareza '+r,Math.abs(w.filter((_,i)=>GU[i].r===r).reduce((a,b)=>a+b)-BAL.SPIN_W[r])<1e-9));
T('reparto 60/40 por rareza',Math.abs(w.filter((_,i)=>GU[i].r===0&&GU[i].cat==='ch').reduce((a,b)=>a+b)/60-.6)<1e-9);
const w2=BAL.weights(GU,0,{ch:.5,su:.5});T('reparto configurable no altera rarezas',Math.abs(w2.filter((_,i)=>GU[i].r===3).reduce((a,b)=>a+b)-2)<1e-9);
let pity=0,maxGap=0,n=0,c=[0,0,0,0],cat={ch:0,su:0};
for(let i=0;i<400000;i++){const r=BAL.spin(GU,Math.random,pity);const u=GU[r.i];c[u.r]++;cat[u.cat]++;if(u.r>=2){pity=0;maxGap=Math.max(maxGap,n);n=0}else{pity=r.pity;n++}}
T('garantía: nunca más de 9 fallos (máx '+maxGap+')',maxGap<=9);
console.log('freq rarezas % (con garantía)',c.map(v=>(v/4000).toFixed(1)),'cat %',(cat.ch/4000).toFixed(1),(cat.su/4000).toFixed(1));
T('garantía fuerza épico+ con pity 9',[...Array(500)].every(()=>GU[BAL.spin(GU,Math.random,9).i].r>=2));
T('nuevo',BAL.grant({},{},'a').isNew===1);T('duplicado ★',BAL.grant({a:1},{a:2},'a').st===3);T('máx ★5 → +20',BAL.grant({a:1},{a:5},'a').refund===20);
T('ids únicos',new Set([...CH.CH.map(x=>x.id),...CH.SUP.map(x=>x.id)]).size===CH.CH.length+CH.SUP.length);
const SK=new Function(m.slice(ex('SK'),ex('CH'))+';return SK')();
CH.SUP.forEach(q=>q.sk.forEach(([k])=>T('habilidad existe '+k,!!SK[k])));
const SPN=new Function(m.slice(m.indexOf('const SPN='),m.indexOf('loadSprites(){')).replace(/,SI=\{\}.*$/s,'').replace(/;?\s*function\s*$/,'')+';return SPN')();
const OR=['saqueador','capitan','acechador','soldado','orco','sangrienta','demonio'];Object.keys(BAL.ARC).filter(k=>!OR.includes(k)).forEach(k=>T('sprite para '+k,!!SPN[k]&&fs.existsSync(__dirname+'/assets/monsters/'+SPN[k]+'.png')));
OR.forEach((k,i)=>{T('orco en ARC '+k,!!BAL.ARC[k]&&BAL.ARC[k][7]===999);['walk','attack'].forEach(a=>{const nm={soldado:'soldier',orco:'tinyorc',sangrienta:'blood',demonio:'demon'}[k],f=nm?'assets/orcs/'+nm+'_'+a+'.png':'assets/orcs/orc'+(i+1)+'_'+a+'.png';T('existe '+f,fs.existsSync(__dirname+'/'+f))})});T('desde la oleada real 20 solo orcos (100%), antes ninguno',m.includes('const id=waveId()')&&m.includes('o?orcPick():fodder')&&m.includes('BAL.eraOf(wv||1)'));for(let w=1;w<=60;w++)T('pick nunca da orco w'+w,!OR.includes(BAL.pick(w,Math.random)));T('sprite jefe',fs.existsSync(__dirname+'/assets/monsters/'+SPN.boss+'.png'));
const sw=fs.readFileSync(__dirname+'/sw.js','utf8');Object.values(SPN).forEach(n=>T('en caché '+n,sw.includes('assets/monsters/'+n+'.png')));
BAL.DIF.forEach(d=>T('índice amenaza '+d.n,Math.abs(d.pr*d.hp*d.dm*d.sp/d.idx-1)<.1));T('Colapso es ×10',BAL.DIF[3].idx===10&&BAL.DIF.every((d,i)=>!i||d.idx>BAL.DIF[i-1].idx&&d.cap>=BAL.DIF[i-1].cap&&d.cap<=110));
console.log('presión objetivo oleada 10, t=20s:',BAL.DIF.map(d=>(BAL.target(10+d.ramp,20)*d.pr).toFixed(0)).join(' / '));
const ROLES=new Set(['swarm','chaser','shooter','charger','flanker','bomber','tank','bruiser','support']);
Object.entries(BAL.ARC).forEach(([k,a])=>T('rol con patrón '+k+':'+a[1],ROLES.has(a[1])&&(a[1]==='swarm'||m.includes("R==='"+a[1]+"'"))));
console.log(ok+' ok, '+bad+' fallos');process.exit(bad?1:0);
