'use strict';
// ZOMBIE BASTION: TOGETHER — minimal Node.js static + WebSocket room server.
// No third-party dependencies. Usage: node server.js
const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const PORT=Number(process.env.PORT||8080);
const HOST=process.env.HOST||'0.0.0.0';
const WEB=path.join(__dirname,'..','www');
const rooms=new Map();
const clients=new Set();
const MAX_FRAME=512*1024;
function send(ws,obj){if(ws.closed)return;let data=Buffer.from(JSON.stringify(obj));if(data.length>MAX_FRAME)return;let header;if(data.length<126){header=Buffer.from([0x81,data.length])}else if(data.length<65536){header=Buffer.alloc(4);header[0]=0x81;header[1]=126;header.writeUInt16BE(data.length,2)}else{header=Buffer.alloc(10);header[0]=0x81;header[1]=127;header.writeBigUInt64BE(BigInt(data.length),2)}try{ws.socket.write(Buffer.concat([header,data]))}catch(_){disconnect(ws)}}
function roomCode(){let s;do{s=crypto.randomBytes(3).toString('hex').slice(0,6).toUpperCase()}while(rooms.has(s));return s}
function remove(ws){if(ws.closed)return;ws.closed=true;clients.delete(ws);const r=rooms.get(ws.room);if(!r)return;if(r.host===ws){rooms.delete(ws.room);if(r.guest){r.guest.room=null;r.guest.role=null;send(r.guest,{type:'ended',reason:'Ведущий вышел из игры'})}}else if(r.guest===ws){r.guest=null;if(r.host)send(r.host,{type:'peer_left',reason:'Напарник отключился'})}ws.room=null;ws.role=null}
function disconnect(ws){remove(ws);try{ws.socket.destroy()}catch(_){}}
function handle(ws,msg){if(!msg||typeof msg!=='object'||typeof msg.type!=='string')return;
 if(msg.type==='create'){
  if(ws.room)return send(ws,{type:'error',message:'Вы уже в комнате'});
  let code=roomCode();rooms.set(code,{host:ws,guest:null,created:Date.now()});ws.room=code;ws.role='host';send(ws,{type:'created',code});return;
 }
 if(msg.type==='join'){
  if(ws.room)return send(ws,{type:'error',message:'Сначала покиньте текущую комнату'});
  const code=String(msg.code||'').trim().toUpperCase();const r=rooms.get(code);
  if(!r)return send(ws,{type:'error',message:'Комната не найдена'});
  if(r.guest)return send(ws,{type:'error',message:'Комната заполнена (2 игрока)'});
  r.guest=ws;ws.room=code;ws.role='guest';send(ws,{type:'joined',code});send(r.host,{type:'peer_joined'});return;
 }
 if(msg.type==='leave'){remove(ws);send(ws,{type:'left'});return}
 const r=rooms.get(ws.room);if(!r)return;
 if(msg.type==='snapshot'&&ws.role==='host'&&r.guest){if(typeof msg.state==='object'&&msg.state!==null)send(r.guest,{type:'snapshot',state:msg.state});return}
 if(msg.type==='action'&&ws.role==='guest'&&r.host){if(msg.action&&typeof msg.action==='object')send(r.host,{type:'action',action:msg.action});return}
 if(msg.type==='notice'&&ws.role==='host'&&r.guest){send(r.guest,{type:'notice',message:String(msg.message||'').slice(0,160)});return}
}
function parse(ws,chunk){ws.buffer=Buffer.concat([ws.buffer,chunk]);if(ws.buffer.length>MAX_FRAME+32){disconnect(ws);return}while(ws.buffer.length>=2){const b=ws.buffer;const opcode=b[0]&15;const masked=!!(b[1]&0x80);let len=b[1]&127,head=2;if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);head=4}else if(len===127){if(b.length<10)return;let big=b.readBigUInt64BE(2);if(big>BigInt(MAX_FRAME)){disconnect(ws);return}len=Number(big);head=10}if(len>MAX_FRAME||!masked){disconnect(ws);return}if(b.length<head+4+len)return;const mask=b.subarray(head,head+4);const payload=Buffer.from(b.subarray(head+4,head+4+len));ws.buffer=b.subarray(head+4+len);for(let i=0;i<payload.length;i++)payload[i]^=mask[i%4];if(opcode===8){disconnect(ws);return}if(opcode===9){try{ws.socket.write(Buffer.from([0x8a,0x00]))}catch(_){disconnect(ws)}continue}if(opcode!==1){disconnect(ws);return}try{handle(ws,JSON.parse(payload.toString('utf8')))}catch(_){send(ws,{type:'error',message:'Некорректная команда'})}}
}
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.css':'text/css; charset=utf-8'};
const server=http.createServer((req,res)=>{
 if(req.method!=='GET'){res.writeHead(405);res.end();return}
 const pathname=new URL(req.url,'http://localhost').pathname;
 if(pathname==='/health'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({status:'ok',rooms:rooms.size,players:clients.size}));return}
 const name=pathname==='/'?'index.html':decodeURIComponent(pathname.slice(1));
 const target=path.resolve(WEB,name);
 if(!(target===WEB||target.startsWith(WEB+path.sep))){res.writeHead(403);res.end('Forbidden');return}
 fs.readFile(target,(err,data)=>{
  if(err){res.writeHead(404);res.end('File not found');return}
  const mime=MIME[path.extname(target)]||'application/octet-stream';
  res.writeHead(200,{'Content-Type':mime,'Cache-Control':name==='index.html'?'no-cache':'public, max-age=3600','X-Content-Type-Options':'nosniff'});res.end(data)
 });
});
server.on('upgrade',(req,socket)=>{if(req.url!=='/ws'||req.headers.upgrade?.toLowerCase()!=='websocket'||req.headers['sec-websocket-version']!=='13'||!req.headers['sec-websocket-key']){socket.destroy();return}const key=req.headers['sec-websocket-key'];if(!/^[A-Za-z0-9+/]{22}==$/.test(key)){socket.destroy();return}const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');const ws={socket,buffer:Buffer.alloc(0),room:null,role:null,closed:false};clients.add(ws);socket.on('data',c=>parse(ws,c));socket.on('error',()=>disconnect(ws));socket.on('close',()=>remove(ws));socket.setKeepAlive(true)});
server.listen(PORT,HOST,()=>{console.log(`ZOMBIE BASTION multiplayer server: http://localhost:${PORT}`);console.log('Open this address on host and second device (same LAN): http://<HOST-LAN-IP>:'+PORT) });
process.on('SIGTERM',()=>server.close(()=>process.exit(0)));
