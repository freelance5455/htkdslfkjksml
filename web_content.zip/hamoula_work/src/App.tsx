/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Shipment, UserRole, DriverOffer, VehicleCategory } from './types/shipment';
import { AdminSettings, ShipmentReport, BannedEntity } from './types/admin';
import {
  INITIAL_DEMO_SHIPMENTS,
  LIBYAN_CITIES,
  filterShipments,
} from './utils/freight';
import {
  DEFAULT_ADMIN_SETTINGS,
  INITIAL_SAMPLE_REPORTS,
  INITIAL_BANNED_ENTITIES,
  isSecretDevCode,
  isPhoneBanned,
} from './utils/admin';
import { Header } from './components/Header';
import { CategoryFilters } from './components/CategoryFilters';
import { ShipmentCard } from './components/ShipmentCard';
import { ShipmentModal } from './components/ShipmentModal';
import { PostShipmentForm } from './components/PostShipmentForm';
import { CalculatorModal } from './components/CalculatorModal';
import { SafetyGuide } from './components/SafetyGuide';
import { ProfileView } from './components/ProfileView';
import { BottomNav, ActiveTab } from './components/BottomNav';
import { Toast } from './components/Toast';
import { AdminDevPanel } from './components/AdminDevPanel';
import { ReportModal } from './components/ReportModal';
import { InstallAppModal } from './components/InstallAppModal';
import {
  PackagePlus,
  Truck,
  ShieldCheck,
  Calculator,
  Search,
  CheckCircle,
  MapPin,
  TrendingUp,
} from 'lucide-react';

export default function App() {
  // Navigation & Role states
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [role, setRole] = useState<UserRole>(() => {
    return (localStorage.getItem('hamoula_role') as UserRole) || 'owner';
  });

  // User posted shipments state
  const [myShipments, setMyShipments] = useState<Shipment[]>(() => {
    try {
      const saved = localStorage.getItem('hamoula_my');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Demo shipments with offer mutations
  const [demoShipments, setDemoShipments] = useState<Shipment[]>(() => {
    try {
      const savedDemo = localStorage.getItem('hamoula_demo');
      return savedDemo ? JSON.parse(savedDemo) : INITIAL_DEMO_SHIPMENTS;
    } catch {
      return INITIAL_DEMO_SHIPMENTS;
    }
  });

  // Driver details
  const [driverInfo, setDriverInfo] = useState(() => {
    try {
      const saved = localStorage.getItem('hamoula_driver');
      return saved
        ? JSON.parse(saved)
        : { name: '', vehicle: '', plate: '', isVerified: false };
    } catch {
      return { name: '', vehicle: '', plate: '', isVerified: false };
    }
  });

  // Admin & Developer Control States
  const [adminSettings, setAdminSettings] = useState<AdminSettings>(() => {
    try {
      const saved = localStorage.getItem('hamoula_admin_settings');
      return saved ? JSON.parse(saved) : DEFAULT_ADMIN_SETTINGS;
    } catch {
      return DEFAULT_ADMIN_SETTINGS;
    }
  });

  const [reports, setReports] = useState<ShipmentReport[]>(() => {
    try {
      const saved = localStorage.getItem('hamoula_reports');
      return saved ? JSON.parse(saved) : INITIAL_SAMPLE_REPORTS;
    } catch {
      return INITIAL_SAMPLE_REPORTS;
    }
  });

  const [bannedList, setBannedList] = useState<BannedEntity[]>(() => {
    try {
      const saved = localStorage.getItem('hamoula_banned');
      return saved ? JSON.parse(saved) : INITIAL_BANNED_ENTITIES;
    } catch {
      return INITIAL_BANNED_ENTITIES;
    }
  });

  const [isDevUnlocked, setIsDevUnlocked] = useState<boolean>(() => {
    return localStorage.getItem('hamoula_dev_unlocked') === 'true';
  });

  const [isDevPanelOpen, setIsDevPanelOpen] = useState(false);
  const [reportingShipment, setReportingShipment] = useState<Shipment | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [selectedCity, setSelectedCity] = useState('الكل');
  const [onlyUrgent, setOnlyUrgent] = useState(false);

  // Modals & UI helpers
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [toast, setToast] = useState<{
    message: string;
    type?: 'success' | 'info' | 'error';
  } | null>(null);

  // Prefill state for posting a shipment from calculator
  const [prefillRoute, setPrefillRoute] = useState<{
    origin: string;
    destination: string;
    vehicle?: VehicleCategory;
  } | null>(null);

  const showToast = (
    message: string,
    type: 'success' | 'info' | 'error' = 'success'
  ) => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Secret Developer Code Unlock Handler
  const handleUnlockDevWithCode = (code: string): boolean => {
    if (isSecretDevCode(code)) {
      setIsDevUnlocked(true);
      localStorage.setItem('hamoula_dev_unlocked', 'true');
      setIsDevPanelOpen(true);
      showToast('مرحباً بك! تم تفعيل وضع المطور ولوحة التحكم الإدارية الكاملة 👑', 'success');
      return true;
    }
    return false;
  };

  const handleLogoutAdmin = () => {
    setIsDevUnlocked(false);
    setIsDevPanelOpen(false);
    localStorage.removeItem('hamoula_dev_unlocked');
    showToast('تم إغلاق جلسة المطور والخروج بنجاح', 'info');
  };

  const handleUpdateAdminSettings = (newSettings: AdminSettings) => {
    setAdminSettings(newSettings);
    localStorage.setItem('hamoula_admin_settings', JSON.stringify(newSettings));
    showToast('تم حفظ وتحديث إعدادات المنصة والعمولة بنجاح!');
  };

  const handleAddBan = (newBan: BannedEntity) => {
    // Add to ban list
    const updated = [newBan, ...bannedList.filter((b) => b.phone !== newBan.phone)];
    setBannedList(updated);
    localStorage.setItem('hamoula_banned', JSON.stringify(updated));

    // Also remove any existing shipments from this banned phone
    const cleanedMy = myShipments.filter((s) => !isPhoneBanned(s.phone, updated));
    setMyShipments(cleanedMy);
    localStorage.setItem('hamoula_my', JSON.stringify(cleanedMy));

    const cleanedDemo = demoShipments.filter((s) => !isPhoneBanned(s.phone, updated));
    setDemoShipments(cleanedDemo);
    localStorage.setItem('hamoula_demo', JSON.stringify(cleanedDemo));

    showToast(`تم حظر الرقم ${newBan.phone} وإضافته إلى القائمة السوداء بنجاح 🚫`, 'info');
  };

  const handleRemoveBan = (phone: string) => {
    const updated = bannedList.filter((b) => b.phone !== phone);
    setBannedList(updated);
    localStorage.setItem('hamoula_banned', JSON.stringify(updated));
    showToast(`تم إلغاء الحظر عن الرقم ${phone}`);
  };

  const handleCreateReport = (report: ShipmentReport) => {
    const updated = [report, ...reports];
    setReports(updated);
    localStorage.setItem('hamoula_reports', JSON.stringify(updated));
    showToast('تم استلام بلاغك بنجاح وسيتم التحقق منه من قِبل إدارة المنصة 🛡️');
  };

  const handleUpdateReportStatus = (
    reportId: string,
    status: 'pending' | 'reviewed' | 'resolved'
  ) => {
    const updated = reports.map((r) => (r.id === reportId ? { ...r, status } : r));
    setReports(updated);
    localStorage.setItem('hamoula_reports', JSON.stringify(updated));
    showToast('تم تحديث حالة البلاغ');
  };

  const handleDeleteShipmentAsAdmin = (id: number | string) => {
    const updatedMy = myShipments.filter((s) => s.id !== id);
    setMyShipments(updatedMy);
    localStorage.setItem('hamoula_my', JSON.stringify(updatedMy));

    const updatedDemo = demoShipments.filter((s) => s.id !== id);
    setDemoShipments(updatedDemo);
    localStorage.setItem('hamoula_demo', JSON.stringify(updatedDemo));

    showToast('تم حذف الحمولة من المنصة بنجاح بواسطة المطور', 'info');
  };

  // Toggle Role handler
  const handleToggleRole = () => {
    const nextRole: UserRole = role === 'owner' ? 'driver' : 'owner';
    setRole(nextRole);
    localStorage.setItem('hamoula_role', nextRole);
    showToast(
      nextRole === 'owner'
        ? 'تم التحويل إلى وضع صاحب البضاعة 👤'
        : 'تم التحويل إلى وضع السائق / الناقل 🚚',
      'info'
    );
  };

  // Save new shipment
  const handleCreateShipment = (newShipment: Shipment) => {
    // Check if user phone is banned
    if (isPhoneBanned(newShipment.phone, bannedList)) {
      showToast('عذراً، هذا الرقم محظور من نشر الإعلانات في المنصة 🚫', 'error');
      return;
    }

    const updated = [newShipment, ...myShipments];
    setMyShipments(updated);
    localStorage.setItem('hamoula_my', JSON.stringify(updated));
    showToast('تم نشر حمولتك بنجاح وهي معروضة الآن لجميع السائقين!');
    setActiveTab('my');
  };

  // Delete shipment
  const handleDeleteShipment = (id: number | string) => {
    const updated = myShipments.filter((s) => s.id !== id);
    setMyShipments(updated);
    localStorage.setItem('hamoula_my', JSON.stringify(updated));
    showToast('تم حذف الإعلان من جهازك بنجاح', 'info');
  };

  // Toggle shipment completed status
  const handleToggleShipmentStatus = (id: number | string) => {
    const updated = myShipments.map((s) => {
      if (s.id === id) {
        return {
          ...s,
          status: s.status === 'completed' ? ('active' as const) : ('completed' as const),
        };
      }
      return s;
    });
    setMyShipments(updated);
    localStorage.setItem('hamoula_my', JSON.stringify(updated));
    showToast('تم تحديث حالة الإعلان');
  };

  // Clear all user shipments
  const handleClearMyShipments = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في مسح كافة إعلاناتك المحفوظة محلياً؟')) {
      setMyShipments([]);
      localStorage.removeItem('hamoula_my');
      showToast('تم مسح إعلاناتك المحفوظة', 'info');
    }
  };

  // Save driver information
  const handleSaveDriverInfo = (info: {
    name: string;
    vehicle: string;
    plate: string;
    isVerified: boolean;
  }) => {
    setDriverInfo(info);
    localStorage.setItem('hamoula_driver', JSON.stringify(info));
    showToast('تم حفظ بيانات ومعلومات السائق بنجاح');
  };

  // Add offer / bid to shipment
  const handleAddOffer = (shipmentId: number | string, offer: DriverOffer) => {
    // Check if driver is banned
    if (isPhoneBanned(offer.driverPhone, bannedList)) {
      showToast('عذراً، هذا الرقم محظور من تقديم العروض في المنصة 🚫', 'error');
      return;
    }

    // Check if in myShipments
    const inMy = myShipments.some((s) => s.id === shipmentId);
    if (inMy) {
      const updated = myShipments.map((s) => {
        if (s.id === shipmentId) {
          const offers = s.offers ? [...s.offers, offer] : [offer];
          return { ...s, offers };
        }
        return s;
      });
      setMyShipments(updated);
      localStorage.setItem('hamoula_my', JSON.stringify(updated));
    } else {
      // In demo shipments
      const updated = demoShipments.map((s) => {
        if (s.id === shipmentId) {
          const offers = s.offers ? [...s.offers, offer] : [offer];
          return { ...s, offers };
        }
        return s;
      });
      setDemoShipments(updated);
      localStorage.setItem('hamoula_demo', JSON.stringify(updated));
    }

    // Also update selected shipment in modal view
    setSelectedShipment((prev) => {
      if (prev && prev.id === shipmentId) {
        return {
          ...prev,
          offers: prev.offers ? [...prev.offers, offer] : [offer],
        };
      }
      return prev;
    });

    showToast(`تم إرسال عرض سعرك بقيمة ${offer.price} د.ل بنجاح!`);
  };

  // Filtered shipments excluding banned phone numbers
  const allShipments = useMemo(() => {
    return [...myShipments, ...demoShipments].filter(
      (s) => !isPhoneBanned(s.phone, bannedList)
    );
  }, [myShipments, demoShipments, bannedList]);

  const filteredShipments = useMemo(() => {
    return filterShipments(allShipments, {
      query: searchQuery,
      category: selectedCategory,
      fromCity: selectedCity,
      onlyUrgent,
    });
  }, [allShipments, searchQuery, selectedCategory, selectedCity, onlyUrgent]);

  const hasActiveFilters =
    selectedCategory !== 'الكل' || selectedCity !== 'الكل' || onlyUrgent || !!searchQuery;

  const handleResetFilters = () => {
    setSelectedCategory('الكل');
    setSelectedCity('الكل');
    setOnlyUrgent(false);
    setSearchQuery('');
  };

  const handleApplyRouteFromCalculator = (
    origin: string,
    destination: string,
    vehicle: VehicleCategory
  ) => {
    setPrefillRoute({ origin, destination, vehicle });
    setActiveTab('post');
    showToast(`تم تحديد المسار: من ${origin} إلى ${destination}`);
  };

  return (
    <div className="min-h-screen bg-[#f4f7f3] text-[#17231d] flex flex-col pb-24">
      {/* Top Header with developer trigger & broadcast notice */}
      <Header
        role={role}
        onToggleRole={handleToggleRole}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenCalculator={() => setIsCalculatorOpen(true)}
        isDevUnlocked={isDevUnlocked}
        onOpenDevPanel={() => setIsDevPanelOpen(true)}
        onUnlockDevWithCode={handleUnlockDevWithCode}
        broadcastNotice={adminSettings.broadcastNotice}
        isBroadcastActive={adminSettings.isBroadcastActive}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="max-w-5xl mx-auto w-full px-4 sm:px-6 pt-6 flex-1">
        {/* VIEW 1: HOME FEED */}
        {activeTab === 'home' && (
          <div className="space-y-6">
            {/* Quick Actions Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <button
                onClick={() => setActiveTab('post')}
                className="bg-white hover:bg-emerald-50/50 p-4 rounded-2xl border border-gray-200/90 text-right transition-all group shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-100/80 text-[#123b2c] flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform">
                  <PackagePlus className="w-5 h-5" />
                </div>
                <strong className="text-sm font-extrabold text-gray-900 block">
                  نشر حمولة جديدة
                </strong>
                <span className="text-xs text-gray-500">طلب شاحنة خلال ثوانٍ</span>
              </button>

              <button
                onClick={() => setIsCalculatorOpen(true)}
                className="bg-white hover:bg-emerald-50/50 p-4 rounded-2xl border border-gray-200/90 text-right transition-all group shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-[#d9f36a]/40 text-[#123b2c] flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform">
                  <Calculator className="w-5 h-5" />
                </div>
                <strong className="text-sm font-extrabold text-gray-900 block">
                  حاسبة الأجرة والمسافة
                </strong>
                <span className="text-xs text-gray-500">معرفة السعر العادل</span>
              </button>

              <button
                onClick={() => setOnlyUrgent((prev) => !prev)}
                className={`p-4 rounded-2xl border text-right transition-all group shadow-2xs ${
                  onlyUrgent
                    ? 'bg-amber-500 text-white border-amber-600'
                    : 'bg-white hover:bg-amber-50/40 border-gray-200/90'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform ${
                    onlyUrgent ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  <TrendingUp className="w-5 h-5" />
                </div>
                <strong
                  className={`text-sm font-extrabold block ${
                    onlyUrgent ? 'text-white' : 'text-gray-900'
                  }`}
                >
                  حمولات شحن عاجلة
                </strong>
                <span className={onlyUrgent ? 'text-white/80 text-xs' : 'text-xs text-gray-500'}>
                  {onlyUrgent ? 'مفعّل حالياً' : 'جاهزة للتحميل اليوم'}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('safety')}
                className="bg-white hover:bg-emerald-50/50 p-4 rounded-2xl border border-gray-200/90 text-right transition-all group shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-900 flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <strong className="text-sm font-extrabold text-gray-900 block">
                  دليل الأمان والبوليصة
                </strong>
                <span className="text-xs text-gray-500">سند استلام ونموذج عقد</span>
              </button>
            </div>

            {/* Category Filters */}
            <CategoryFilters
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              selectedCity={selectedCity}
              onSelectCity={setSelectedCity}
              onlyUrgent={onlyUrgent}
              onToggleUrgent={() => setOnlyUrgent((prev) => !prev)}
              onResetFilters={handleResetFilters}
              hasActiveFilters={hasActiveFilters}
              cities={LIBYAN_CITIES}
            />

            {/* Section Header */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black text-gray-900 m-0">
                  الحمولات المتاحة للنقل
                </h3>
                <span className="text-xs font-bold bg-[#123b2c] text-white px-2.5 py-0.5 rounded-full">
                  {filteredShipments.length} إعلان
                </span>
              </div>
              <span className="text-xs text-gray-500 hidden sm:inline">
                يتم تحديث الطلبات لحظياً بين المدن الليبية
              </span>
            </div>

            {/* Shipments Grid */}
            {filteredShipments.length === 0 ? (
              <div className="bg-white rounded-3xl border border-dashed border-gray-300 p-10 text-center space-y-3">
                <div className="w-14 h-14 bg-emerald-50 text-emerald-800 rounded-3xl mx-auto flex items-center justify-center text-2xl font-bold">
                  📦
                </div>
                <h4 className="text-base sm:text-lg font-extrabold text-gray-900 m-0">
                  لم يتم العثور على حمولات مطابقة لبحثك
                </h4>
                <p className="text-xs sm:text-sm text-gray-500 max-w-md mx-auto m-0 leading-relaxed">
                  جرّب تغيير فئة البضاعة أو اختيار &quot;كل المدن&quot;، أو كن أول من ينشر حمولة بهذا المسار.
                </p>
                <div className="pt-2 flex justify-center gap-2">
                  <button
                    onClick={handleResetFilters}
                    className="bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold py-2.5 px-4 rounded-xl transition-colors"
                  >
                    إعادة ضبط الفلاتر
                  </button>
                  <button
                    onClick={() => setActiveTab('post')}
                    className="bg-[#123b2c] hover:bg-[#1f6a4c] text-white text-xs font-bold py-2.5 px-4 rounded-xl transition-colors"
                  >
                    نشر حمولة جديدة
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredShipments.map((s) => (
                  <ShipmentCard
                    key={s.id}
                    shipment={s}
                    isOwn={myShipments.some((m) => m.id === s.id)}
                    userRole={role}
                    onViewDetails={(item) => setSelectedShipment(item)}
                    onOfferBid={(item) => setSelectedShipment(item)}
                    onDelete={handleDeleteShipment}
                    onToggleStatus={handleToggleShipmentStatus}
                    onReport={(item) => setReportingShipment(item)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 2: POST SHIPMENT FORM */}
        {activeTab === 'post' && (
          <div className="max-w-2xl mx-auto">
            <PostShipmentForm
              onShipmentCreated={handleCreateShipment}
              prefillOrigin={prefillRoute?.origin}
              prefillDestination={prefillRoute?.destination}
              prefillVehicle={prefillRoute?.vehicle}
            />
          </div>
        )}

        {/* VIEW 3: MY SHIPMENTS */}
        {activeTab === 'my' && (
          <div className="space-y-5 max-w-3xl mx-auto">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-black text-gray-900 m-0">
                  حمولاتي وإعلاناتي المحفوظة
                </h3>
                <p className="text-xs text-gray-500 m-0 mt-0.5">
                  إعلانات الشحن التي قمت بنشرها من هذا الجهاز
                </p>
              </div>
              <button
                onClick={() => setActiveTab('post')}
                className="bg-[#123b2c] hover:bg-[#1f6a4c] text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                <PackagePlus className="w-4 h-4 text-[#d9f36a]" />
                <span>إضافة حمولة</span>
              </button>
            </div>

            {myShipments.length === 0 ? (
              <div className="bg-white rounded-3xl border border-dashed border-gray-300 p-10 text-center space-y-3">
                <div className="w-14 h-14 bg-gray-100 text-gray-400 rounded-3xl mx-auto flex items-center justify-center text-2xl font-bold">
                  📋
                </div>
                <h4 className="text-base sm:text-lg font-extrabold text-gray-900 m-0">
                  لم تقم بنشر أي حمولة حتى الآن
                </h4>
                <p className="text-xs sm:text-sm text-gray-500 max-w-md mx-auto m-0 leading-relaxed">
                  انشر بضاعتك الآن مجاناً وستظهر فوراً للسائقين والناقلين في المدينة المحددة.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('post')}
                    className="bg-[#123b2c] hover:bg-[#1f6a4c] text-white text-xs sm:text-sm font-bold py-2.5 px-5 rounded-xl transition-colors"
                  >
                    ➕ نشر أول حمولة الآن
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myShipments.map((s) => (
                  <ShipmentCard
                    key={s.id}
                    shipment={s}
                    isOwn={true}
                    userRole={role}
                    onViewDetails={(item) => setSelectedShipment(item)}
                    onDelete={handleDeleteShipment}
                    onToggleStatus={handleToggleShipmentStatus}
                    onReport={(item) => setReportingShipment(item)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 4: CALCULATOR */}
        {activeTab === 'calculator' && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-3xl p-6 sm:p-7 border border-gray-200/90 shadow-sm space-y-4">
              <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
                <div className="w-10 h-10 rounded-2xl bg-[#d9f36a] text-[#123b2c] flex items-center justify-center font-bold">
                  <Calculator className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-gray-900 m-0">
                    حاسبة مسافات وأجرة الشحن بين المدن الليبية
                  </h3>
                  <p className="text-xs text-gray-500 m-0 mt-0.5">
                    احسب المسافة التقريبية والمدة الزمنية ونطاق السعر العادل للشاحنات
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsCalculatorOpen(true)}
                className="w-full bg-[#123b2c] hover:bg-[#1f6a4c] text-white py-3 px-5 rounded-2xl font-bold flex items-center justify-center gap-2"
              >
                <span>فتح الحاسبة التفاعلية للمدن</span>
              </button>
            </div>
          </div>
        )}

        {/* VIEW 5: SAFETY */}
        {activeTab === 'safety' && (
          <div className="max-w-4xl mx-auto">
            <SafetyGuide />
          </div>
        )}

        {/* VIEW 6: PROFILE */}
        {activeTab === 'profile' && (
          <div className="max-w-2xl mx-auto">
            <ProfileView
              role={role}
              onToggleRole={handleToggleRole}
              myShipmentsCount={myShipments.length}
              onClearMyShipments={handleClearMyShipments}
              driverInfo={driverInfo}
              onSaveDriverInfo={handleSaveDriverInfo}
              isDevUnlocked={isDevUnlocked}
              onOpenDevPanel={() => setIsDevPanelOpen(true)}
              onUnlockDevWithCode={handleUnlockDevWithCode}
              onOpenInstallModal={() => setIsInstallModalOpen(true)}
            />
          </div>
        )}
      </main>

      {/* Detail & Driver Offer Modal */}
      <ShipmentModal
        shipment={selectedShipment}
        isOpen={!!selectedShipment}
        onClose={() => setSelectedShipment(null)}
        userRole={role}
        onAddOffer={handleAddOffer}
        onReport={(item) => setReportingShipment(item)}
      />

      {/* User Report Modal */}
      <ReportModal
        shipment={reportingShipment}
        isOpen={!!reportingShipment}
        onClose={() => setReportingShipment(null)}
        onSubmitReport={handleCreateReport}
      />

      {/* Developer & Admin Control Dashboard */}
      <AdminDevPanel
        isOpen={isDevPanelOpen}
        onClose={() => setIsDevPanelOpen(false)}
        adminSettings={adminSettings}
        onUpdateSettings={handleUpdateAdminSettings}
        reports={reports}
        onUpdateReportStatus={handleUpdateReportStatus}
        bannedList={bannedList}
        onAddBan={handleAddBan}
        onRemoveBan={handleRemoveBan}
        shipments={allShipments}
        onDeleteShipment={handleDeleteShipmentAsAdmin}
        onLogoutAdmin={handleLogoutAdmin}
      />

      {/* Route & Freight Calculator Modal */}
      <CalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
        onApplyRoute={handleApplyRouteFromCalculator}
      />

      {/* App Install Guide Modal */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      {/* Floating Toast Notification */}
      <Toast
        message={toast?.message || null}
        type={toast?.type}
        onClose={() => setToast(null)}
      />

      {/* Sticky Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        myShipmentsCount={myShipments.length}
      />
    </div>
  );
}
