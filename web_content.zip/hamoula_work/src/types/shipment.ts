export type UserRole = 'owner' | 'driver';

export type CargoCategory =
  | 'خضروات وفواكه'
  | 'مواد بناء'
  | 'أثاث ونقل عفش'
  | 'أجهزة كهربائية'
  | 'بضائع عامة'
  | 'معدات ثقيلة'
  | 'مستلزمات طبية'
  | 'أخرى';

export type VehicleCategory =
  | 'سيارة نقل صغيرة (وانيت / كانتر)'
  | 'شاحنة متوسطة (إيفيكو / مرسيدس)'
  | 'شاحنة كبيرة (تريلا)'
  | 'براد تبريد (لحوم / خضار)'
  | 'سطحة لنقل السيارات'
  | 'قاطرة ومقطورة'
  | 'صهريج سوائل'
  | 'حسب المتاح';

export interface DriverOffer {
  id: string;
  driverName: string;
  driverPhone: string;
  vehicle: string;
  price: number;
  note?: string;
  createdAt: string;
}

export interface Shipment {
  id: number | string;
  type: CargoCategory;
  vehicle: VehicleCategory;
  from: string;
  to: string;
  weight: string;
  date: string;
  price: string | number; // in Libyan Dinars (LYD)
  phone: string;
  details?: string;
  requiresLabor?: boolean; // Needs loaders/workers
  isUrgent?: boolean;
  demo?: boolean;
  status?: 'active' | 'in_progress' | 'completed';
  createdAt?: string;
  offers?: DriverOffer[];
}
