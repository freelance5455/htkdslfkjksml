export interface AdminSettings {
  commissionActive: boolean;
  commissionRate: number; // e.g. 2.5%
  baseRateMultiplier: number; // e.g. 1.0
  minHaulFee: number; // e.g. 150 LYD
  broadcastNotice: string;
  isBroadcastActive: boolean;
}

export interface ShipmentReport {
  id: string;
  shipmentId: number | string;
  shipmentTitle: string;
  reportedPhone: string;
  reason: string;
  reporterPhone?: string;
  timestamp: string;
  status: 'pending' | 'reviewed' | 'resolved';
}

export interface BannedEntity {
  id: string;
  phone: string;
  name: string;
  reason: string;
  bannedAt: string;
}
