import React, { useState } from 'react';
import {
  LIBYAN_CITIES,
  getLibyanDistanceKm,
  estimateFreightCost,
} from '../utils/freight';
import { VehicleCategory } from '../types/shipment';
import {
  X,
  MapPin,
  Truck,
  Calculator,
  ArrowLeftRight,
  Clock,
  Fuel,
  Check,
  Send,
} from 'lucide-react';

interface CalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyRoute: (origin: string, destination: string, vehicle: VehicleCategory) => void;
}

const VEHICLE_OPTIONS: VehicleCategory[] = [
  'سيارة نقل صغيرة (وانيت / كانتر)',
  'شاحنة متوسطة (إيفيكو / مرسيدس)',
  'شاحنة كبيرة (تريلا)',
  'براد تبريد (لحوم / خضار)',
  'سطحة لنقل السيارات',
  'قاطرة ومقطورة',
  'صهريج سوائل',
];

export const CalculatorModal: React.FC<CalculatorModalProps> = ({
  isOpen,
  onClose,
  onApplyRoute,
}) => {
  const [origin, setOrigin] = useState('طرابلس');
  const [destination, setDestination] = useState('بنغازي');
  const [vehicle, setVehicle] = useState<VehicleCategory>('شاحنة كبيرة (تريلا)');
  const [isUrgent, setIsUrgent] = useState(false);

  if (!isOpen) return null;

  const distance = getLibyanDistanceKm(origin, destination);
  const estimate = estimateFreightCost(origin, destination, vehicle, isUrgent);

  // Approximate diesel fuel in liters (average 32 liters per 100km for freight trucks)
  const approxDieselLiters = Math.round((distance * 32) / 100);

  const swapCities = () => {
    const temp = origin;
    setOrigin(destination);
    setDestination(temp);
  };

  const handleUseInPost = () => {
    onApplyRoute(origin, destination, vehicle);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="calculatorModalTitle"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150"
    >
      <div
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col overflow-hidden border border-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#123b2c] text-white p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#d9f36a] text-[#123b2c] flex items-center justify-center font-bold">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 id="calculatorModalTitle" className="text-lg font-extrabold m-0">
                حاسبة مسافات وأجرة الشحن
              </h3>
              <p className="text-xs text-emerald-200/80 m-0">
                مؤشرات استرشادية لشبكة الطرق الليبية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="إغلاق الحاسبة"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-sm">
          {/* City Selection with Swap */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-700 block">خط السير والمدن</label>
            <div className="flex items-center gap-2">
              <div className="flex-1">
                <span className="text-[11px] text-gray-500 block mb-1">من (مدينة التحميل)</span>
                <select
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm font-bold text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
                >
                  {LIBYAN_CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="button"
                onClick={swapCities}
                aria-label="تبديل المدينتين"
                className="mt-4 p-2.5 rounded-xl border border-gray-200 bg-gray-50 hover:bg-emerald-50 text-emerald-800 hover:border-emerald-300 transition-colors shrink-0"
              >
                <ArrowLeftRight className="w-4 h-4" />
              </button>

              <div className="flex-1">
                <span className="text-[11px] text-gray-500 block mb-1">إلى (مدينة التسليم)</span>
                <select
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm font-bold text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
                >
                  {LIBYAN_CITIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Vehicle Type */}
          <div>
            <label className="text-xs font-bold text-gray-700 block mb-1">نوع الشاحنة أو المركبة</label>
            <select
              value={vehicle}
              onChange={(e) => setVehicle(e.target.value as VehicleCategory)}
              className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm font-bold text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
            >
              {VEHICLE_OPTIONS.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>

          {/* Urgent checkbox */}
          <label className="flex items-center gap-2 bg-gray-50 p-2.5 rounded-xl border border-gray-200 cursor-pointer">
            <input
              type="checkbox"
              checked={isUrgent}
              onChange={(e) => setIsUrgent(e.target.checked)}
              className="w-4 h-4 text-emerald-700 rounded"
            />
            <span className="text-xs font-semibold text-gray-800">
              حساب تكلفة النقل العاجل أو الفوري (+25% تقديراً للسرعة وتفضيل المسار)
            </span>
          </label>

          {/* Result Card */}
          <div className="bg-gradient-to-br from-emerald-50 to-[#edf4ee] border border-emerald-200 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-emerald-200/60">
              <div>
                <span className="text-xs text-emerald-800 font-bold block">
                  المسافة التقريبية بالطريق البري
                </span>
                <span className="text-2xl font-black text-[#123b2c]">
                  {distance > 0 ? `${distance} كم` : 'نقل داخلي في المدينة'}
                </span>
              </div>
              <div className="text-left">
                <span className="text-xs text-emerald-800 font-bold block">
                  وقت الرحلة المتوقع للشاحنة
                </span>
                <span className="text-base font-extrabold text-[#123b2c] flex items-center justify-end gap-1">
                  <Clock className="w-4 h-4 text-emerald-700" />
                  <span>{estimate.travelHours} ساعة</span>
                </span>
              </div>
            </div>

            {/* Estimated Price Range */}
            <div>
              <span className="text-xs text-gray-600 block mb-1">
                نطاق الأجرة العادلة المقترحة في السوق الليبي:
              </span>
              <div className="flex items-baseline justify-between">
                <div className="text-2xl sm:text-3xl font-black text-[#123b2c]">
                  {estimate.minPrice} - {estimate.maxPrice} <span className="text-base font-bold">د.ل</span>
                </div>
                <div className="text-xs font-bold text-emerald-800 bg-white px-2.5 py-1 rounded-lg border border-emerald-200">
                  المتوسط: {estimate.averagePrice} د.ل
                </div>
              </div>
            </div>

            {/* Extra benchmarks: Fuel & Highway hints */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-emerald-200/50 text-xs text-gray-600">
              <div className="flex items-center gap-1.5 bg-white/70 p-2 rounded-xl">
                <Fuel className="w-3.5 h-3.5 text-emerald-700" />
                <span>ديزل متوقع: ~{approxDieselLiters} لتر</span>
              </div>
              <div className="flex items-center gap-1.5 bg-white/70 p-2 rounded-xl">
                <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                <span>محطات وبوابات رئيسية</span>
              </div>
            </div>
          </div>

          <p className="text-[11px] text-gray-500 leading-relaxed m-0">
            * تنويه: هذه الأسعار استرشادية بحسب معدلات أسعار النقل بين المدن في ليبيا وقد تختلف حسب مواسم الحصاد الزراعي، أسعار الوقود، وحجم البضاعة الدقيق.
          </p>

          {/* Action button: Use this route in post form */}
          <button
            onClick={handleUseInPost}
            className="w-full bg-[#123b2c] hover:bg-[#1f6a4c] text-white py-3 px-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-sm"
          >
            <Send className="w-4 h-4 text-[#d9f36a]" />
            <span>نشر حمولة جديدة بهذا المسار ({origin} ← {destination})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
