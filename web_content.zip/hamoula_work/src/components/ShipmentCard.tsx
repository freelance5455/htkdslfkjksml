import React from 'react';
import { Shipment, UserRole } from '../types/shipment';
import { getLibyanDistanceKm, formatPhoneForWhatsApp } from '../utils/freight';
import {
  Calendar,
  Package,
  Phone,
  MessageCircle,
  Clock,
  Trash2,
  CheckCircle2,
  Users,
  Zap,
  ArrowLeft,
  Truck,
  Flag,
} from 'lucide-react';

interface ShipmentCardProps {
  shipment: Shipment;
  isOwn?: boolean;
  userRole: UserRole;
  onViewDetails: (shipment: Shipment) => void;
  onDelete?: (id: number | string) => void;
  onToggleStatus?: (id: number | string) => void;
  onOfferBid?: (shipment: Shipment) => void;
  onReport?: (shipment: Shipment) => void;
}

export const ShipmentCard: React.FC<ShipmentCardProps> = ({
  shipment,
  isOwn = false,
  userRole,
  onViewDetails,
  onDelete,
  onToggleStatus,
  onOfferBid,
  onReport,
}) => {
  const distance = getLibyanDistanceKm(shipment.from, shipment.to);
  const waNumber = formatPhoneForWhatsApp(shipment.phone);
  const waMessage = encodeURIComponent(
    `السلام عليكم، بخصوص إعلان الحمولة في حمولة ليبيا:\nمن ${shipment.from} إلى ${shipment.to}\nنوع الحمولة: ${shipment.type}\nهل لا زالت متاحة للنقل؟`
  );

  const priceText =
    shipment.price && Number(shipment.price) > 0
      ? `${shipment.price} د.ل`
      : 'قابل للتفاوض';

  const isCompleted = shipment.status === 'completed';

  return (
    <article
      className={`bg-white rounded-2xl border transition-all duration-200 hover:shadow-md flex flex-col justify-between overflow-hidden relative ${
        isCompleted
          ? 'border-gray-200 bg-gray-50/70 opacity-80'
          : 'border-gray-200/90 hover:border-emerald-700/40'
      }`}
    >
      {/* Top badges bar */}
      <div className="p-4 sm:p-5 pb-3">
        <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-bold bg-emerald-50 text-emerald-900 border border-emerald-200 px-2.5 py-1 rounded-full">
              {shipment.type}
            </span>
            <span className="text-xs font-medium bg-gray-100 text-gray-700 px-2.5 py-1 rounded-full flex items-center gap-1">
              <Truck className="w-3 h-3 text-emerald-800" />
              {shipment.vehicle}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {shipment.isUrgent && (
              <span className="text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded-full flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-600 fill-amber-500" />
                عاجل
              </span>
            )}
            {shipment.requiresLabor && (
              <span className="text-[11px] font-medium bg-blue-50 text-blue-800 border border-blue-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                <Users className="w-3 h-3 text-blue-600" />
                عمال تحميل
              </span>
            )}
            {isOwn && (
              <span className="text-[11px] font-bold bg-[#123b2c] text-white px-2 py-0.5 rounded-full">
                إعلاني
              </span>
            )}
          </div>
        </div>

        {/* Route Visualizer */}
        <div className="bg-[#f7faf8] rounded-xl p-3 border border-gray-100 my-2">
          <div className="flex items-center justify-between gap-2">
            {/* Origin */}
            <div className="flex-1">
              <div className="flex items-center gap-1.5 text-xs text-gray-500 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 ring-2 ring-emerald-100"></span>
                <span>مكان التحميل</span>
              </div>
              <div className="text-base sm:text-lg font-black text-[#17231d] mt-0.5">
                {shipment.from}
              </div>
            </div>

            {/* Road connector */}
            <div className="flex flex-col items-center px-2">
              {distance > 0 && (
                <span className="text-[11px] font-bold text-emerald-800 bg-white px-2 py-0.5 rounded-full border border-emerald-100 shadow-2xs">
                  {distance} كم
                </span>
              )}
              <div className="flex items-center text-emerald-600 mt-1">
                <span className="w-6 sm:w-12 border-b-2 border-dashed border-emerald-300"></span>
                <ArrowLeft className="w-4 h-4 text-emerald-700" />
              </div>
            </div>

            {/* Destination */}
            <div className="flex-1 text-left">
              <div className="flex items-center justify-end gap-1.5 text-xs text-gray-500 font-medium">
                <span>مكان التسليم</span>
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 ring-2 ring-amber-100"></span>
              </div>
              <div className="text-base sm:text-lg font-black text-[#17231d] mt-0.5 text-left">
                {shipment.to}
              </div>
            </div>
          </div>
        </div>

        {/* Metadata info: Weight, Date, Offers */}
        <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 mt-3 pt-1">
          <div className="flex items-center gap-1.5 bg-gray-50 p-2 rounded-lg">
            <Package className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="font-semibold text-gray-800 truncate" title={shipment.weight}>
              {shipment.weight}
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-gray-50 p-2 rounded-lg">
            <Calendar className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span className="font-medium text-gray-700">
              {shipment.date || 'فوري'}
            </span>
          </div>
        </div>

        {shipment.offers && shipment.offers.length > 0 && (
          <div className="mt-2 text-xs text-emerald-900 bg-emerald-50/90 border border-emerald-100 rounded-lg px-2.5 py-1.5 flex items-center justify-between">
            <span className="font-semibold">
              🚚 عروض السائقين: {shipment.offers.length} عرض
            </span>
            <span className="text-[11px] text-emerald-700">
              أفضل عرض: {Math.min(...shipment.offers.map((o) => o.price))} د.ل
            </span>
          </div>
        )}
      </div>

      {/* Bottom price and actions */}
      <div className="p-4 sm:p-5 pt-3 bg-gray-50/70 border-t border-gray-100 mt-2">
        <div className="flex items-center justify-between gap-3 mb-3">
          <div>
            <div className="text-xs text-gray-500 font-medium">الأجرة المقترحة</div>
            <div className="text-xl font-extrabold text-[#123b2c] tracking-tight">
              {priceText}
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {onReport && (
              <button
                onClick={() => onReport(shipment)}
                title="إبلاغ عن إعلان مشبوه"
                aria-label={`إبلاغ عن الحمولة من ${shipment.from} إلى ${shipment.to}`}
                className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
              >
                <Flag className="w-3.5 h-3.5" />
              </button>
            )}

            <button
              onClick={() => onViewDetails(shipment)}
              className="bg-[#123b2c] hover:bg-[#1f6a4c] text-white text-xs sm:text-sm font-bold px-3.5 py-2 rounded-xl transition-colors shadow-2xs"
            >
              التفاصيل
            </button>

            {userRole === 'driver' && onOfferBid && (
              <button
                onClick={() => onOfferBid(shipment)}
                className="bg-[#d9f36a] hover:bg-[#cbe65d] text-[#123b2c] text-xs sm:text-sm font-extrabold px-3 py-2 rounded-xl transition-colors shadow-2xs"
              >
                قدّم عرضاً
              </button>
            )}
          </div>
        </div>

        {/* Quick direct communication buttons */}
        {!shipment.demo && (
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-gray-200/60">
            <a
              href={`tel:${shipment.phone}`}
              className="flex items-center justify-center gap-1.5 bg-white hover:bg-gray-100 border border-gray-200 text-gray-800 text-xs font-bold py-1.5 px-2 rounded-xl transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-700" />
              <span>اتصال مباشر</span>
            </a>
            <a
              href={`https://wa.me/${waNumber}?text=${waMessage}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-1.5 px-2 rounded-xl transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>واتساب</span>
            </a>
          </div>
        )}

        {/* Owner actions (Delete, Mark as Completed) */}
        {isOwn && (
          <div className="flex items-center justify-between gap-2 pt-2 border-t border-gray-200/60 mt-2">
            {onToggleStatus && (
              <button
                onClick={() => onToggleStatus(shipment.id)}
                className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isCompleted ? 'إعادة التنشيط' : 'تمييز كمكتمل / تم الاتفاق'}</span>
              </button>
            )}
            {onDelete && (
              <button
                onClick={() => onDelete(shipment.id)}
                aria-label={`حذف الإعلان ${shipment.from} إلى ${shipment.to}`}
                className="text-xs text-rose-700 hover:text-rose-900 font-semibold flex items-center gap-1 p-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>حذف</span>
              </button>
            )}
          </div>
        )}
      </div>
    </article>
  );
};
