import React, { useState } from 'react';
import { AdminSettings, ShipmentReport, BannedEntity } from '../types/admin';
import { Shipment } from '../types/shipment';
import {
  X,
  Shield,
  Coins,
  Ban,
  AlertTriangle,
  Radio,
  Trash2,
  CheckCircle,
  Plus,
  Percent,
  Sliders,
  Bell,
  Eye,
  LogOut,
  RefreshCw,
  Truck,
  Download,
} from 'lucide-react';

interface AdminDevPanelProps {
  isOpen: boolean;
  onClose: () => void;
  adminSettings: AdminSettings;
  onUpdateSettings: (newSettings: AdminSettings) => void;
  reports: ShipmentReport[];
  onUpdateReportStatus: (reportId: string, status: 'pending' | 'reviewed' | 'resolved') => void;
  bannedList: BannedEntity[];
  onAddBan: (ban: BannedEntity) => void;
  onRemoveBan: (phone: string) => void;
  shipments: Shipment[];
  onDeleteShipment: (id: number | string) => void;
  onLogoutAdmin: () => void;
}

type AdminTab = 'commission' | 'reports' | 'blacklist' | 'shipments' | 'broadcast';

export const AdminDevPanel: React.FC<AdminDevPanelProps> = ({
  isOpen,
  onClose,
  adminSettings,
  onUpdateSettings,
  reports,
  onUpdateReportStatus,
  bannedList,
  onAddBan,
  onRemoveBan,
  shipments,
  onDeleteShipment,
  onLogoutAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('commission');

  // Form states for manual ban
  const [newBanPhone, setNewBanPhone] = useState('');
  const [newBanName, setNewBanName] = useState('');
  const [newBanReason, setNewBanReason] = useState('');
  const [banError, setBanError] = useState('');

  // Settings local state
  const [commissionActive, setCommissionActive] = useState(adminSettings.commissionActive);
  const [commissionRate, setCommissionRate] = useState(adminSettings.commissionRate);
  const [minHaulFee, setMinHaulFee] = useState(adminSettings.minHaulFee);
  const [baseRateMultiplier, setBaseRateMultiplier] = useState(adminSettings.baseRateMultiplier);
  const [broadcastNotice, setBroadcastNotice] = useState(adminSettings.broadcastNotice);
  const [isBroadcastActive, setIsBroadcastActive] = useState(adminSettings.isBroadcastActive);

  if (!isOpen) return null;

  const handleSaveCommission = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      ...adminSettings,
      commissionActive,
      commissionRate: Number(commissionRate),
      minHaulFee: Number(minHaulFee),
      baseRateMultiplier: Number(baseRateMultiplier),
    });
  };

  const handleSaveBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      ...adminSettings,
      broadcastNotice: broadcastNotice.trim(),
      isBroadcastActive,
    });
  };

  const handleCreateBan = (e: React.FormEvent) => {
    e.preventDefault();
    setBanError('');
    if (!newBanPhone.trim()) {
      setBanError('يرجى إدخال رقم الهاتف للحظر');
      return;
    }
    const newBan: BannedEntity = {
      id: `ban-${Date.now()}`,
      phone: newBanPhone.trim(),
      name: newBanName.trim() || 'مستخدم محظور',
      reason: newBanReason.trim() || 'حظر يدوي من لوحة المطور',
      bannedAt: new Date().toISOString().split('T')[0],
    };
    onAddBan(newBan);
    setNewBanPhone('');
    setNewBanName('');
    setNewBanReason('');
  };

  const pendingReportsCount = reports.filter((r) => r.status === 'pending').length;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="adminPanelTitle"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
    >
      <div
        className="bg-[#121c17] text-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-emerald-500/30"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="bg-gradient-to-r from-[#172b21] to-[#0f1f17] px-6 py-4 border-b border-emerald-500/20 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#d9f36a] text-[#123b2c] flex items-center justify-center font-black text-xl shadow-lg">
              ⚙️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="adminPanelTitle" className="text-lg sm:text-xl font-black m-0 text-white">
                  لوحة المطور والتحكم الإداري
                </h3>
                <span className="text-[10px] font-black bg-[#d9f36a]/20 text-[#d9f36a] px-2 py-0.5 rounded-full border border-[#d9f36a]/40">
                  DEVELOPER ROOT
                </span>
              </div>
              <p className="text-xs text-emerald-200/70 m-0">
                إدارة كاملة: العمولة، حظر المستخدمين، استلام البلاغات، وبث الطوارئ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="/hamoula-libya-project.zip"
              download="hamoula-libya-project.zip"
              title="تنزيل حزمة المشروع الكاملة ZIP"
              className="text-xs bg-emerald-900/90 hover:bg-emerald-800 text-[#d9f36a] border border-emerald-600/50 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors font-bold"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل المشروع (ZIP)</span>
            </a>

            <button
              onClick={onLogoutAdmin}
              title="تسجيل خروج من وضع المطور"
              className="text-xs bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800/60 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>إغلاق الجلسة</span>
            </button>
            <button
              onClick={onClose}
              aria-label="إغلاق لوحة المطور"
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-4 sm:px-6 pt-3 border-b border-emerald-950/60 overflow-x-auto bg-[#14231b] shrink-0">
          <button
            onClick={() => setActiveTab('commission')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition-all border-b-2 ${
              activeTab === 'commission'
                ? 'border-[#d9f36a] text-[#d9f36a] bg-emerald-950/40'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>العمولة والتسعير</span>
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition-all border-b-2 relative ${
              activeTab === 'reports'
                ? 'border-[#d9f36a] text-[#d9f36a] bg-emerald-950/40'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>البلاغات والشكاوى</span>
            {pendingReportsCount > 0 && (
              <span className="w-4 h-4 bg-rose-600 text-white rounded-full text-[10px] flex items-center justify-center font-bold">
                {pendingReportsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('blacklist')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition-all border-b-2 ${
              activeTab === 'blacklist'
                ? 'border-[#d9f36a] text-[#d9f36a] bg-emerald-950/40'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Ban className="w-4 h-4" />
            <span>الحظر والقائمة السوداء ({bannedList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('shipments')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition-all border-b-2 ${
              activeTab === 'shipments'
                ? 'border-[#d9f36a] text-[#d9f36a] bg-emerald-950/40'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>الحمولات المباشرة ({shipments.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('broadcast')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition-all border-b-2 ${
              activeTab === 'broadcast'
                ? 'border-[#d9f36a] text-[#d9f36a] bg-emerald-950/40'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>بث الطوارئ</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-sm bg-[#0d1612]">
          {/* TAB 1: COMMISSION & PRICING */}
          {activeTab === 'commission' && (
            <div className="space-y-6 max-w-2xl">
              <div className="bg-[#14231b] border border-emerald-900/60 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-emerald-950">
                  <div>
                    <h4 className="font-extrabold text-base text-white m-0">
                      التحكم في عمولة التطبيق (زيادة أو تقليص)
                    </h4>
                    <p className="text-xs text-gray-400 m-0 mt-0.5">
                      تعديل نسبة العمولة المقتطعة من أجور الشحن أو جعل الخدمة مجانية 0%
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-label="تفعيل أو تعطيل العمولة"
                    aria-checked={commissionActive}
                    onClick={() => setCommissionActive(!commissionActive)}
                    className={`w-12 h-6 rounded-full transition-colors relative p-0.5 flex items-center ${
                      commissionActive ? 'bg-emerald-600' : 'bg-gray-700'
                    }`}
                  >
                    <span
                      className={`w-5 h-5 bg-white rounded-full block shadow-md transition-transform ${
                        commissionActive ? 'mr-0' : 'mr-6'
                      }`}
                    />
                  </button>
                </div>

                <form onSubmit={handleSaveCommission} className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-bold text-gray-300">
                        نسبة العمولة الحالية:
                      </label>
                      <span className="text-lg font-black text-[#d9f36a]">
                        {commissionActive ? `${commissionRate}%` : 'معطلة (0% مجاني)'}
                      </span>
                    </div>

                    <div className="flex items-center gap-4">
                      <input
                        type="range"
                        min="0"
                        max="15"
                        step="0.5"
                        disabled={!commissionActive}
                        value={commissionRate}
                        onChange={(e) => setCommissionRate(parseFloat(e.target.value))}
                        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[#d9f36a]"
                      />
                      <input
                        type="number"
                        min="0"
                        max="25"
                        step="0.5"
                        disabled={!commissionActive}
                        value={commissionRate}
                        onChange={(e) => setCommissionRate(parseFloat(e.target.value))}
                        className="w-20 bg-gray-800 border border-gray-700 rounded-xl px-2.5 py-1 text-center font-bold text-white text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        الحد الأدنى لأجرة النقل (د.ل)
                      </label>
                      <input
                        type="number"
                        value={minHaulFee}
                        onChange={(e) => setMinHaulFee(Number(e.target.value))}
                        className="w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2 text-white font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        معامل تسعير الكيلومتر (1.0 = طبيعي)
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        min="0.5"
                        max="2.5"
                        value={baseRateMultiplier}
                        onChange={(e) => setBaseRateMultiplier(Number(e.target.value))}
                        className="w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2 text-white font-bold"
                      />
                    </div>
                  </div>

                  {/* Commission calculation preview */}
                  <div className="bg-[#0f1b14] border border-emerald-900/40 rounded-xl p-3 text-xs space-y-1.5">
                    <span className="font-bold text-emerald-300 block">
                      معاينة احتساب العمولة على حمولة بقيمة 1,000 د.ل:
                    </span>
                    <div className="flex justify-between text-gray-300">
                      <span>عمولة المنصة المحتسبة:</span>
                      <strong className="text-[#d9f36a]">
                        {commissionActive ? `${(1000 * (commissionRate / 100)).toFixed(1)} د.ل` : '0 د.ل'}
                      </strong>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>صافي دخل السائق المستلم:</span>
                      <strong className="text-white">
                        {commissionActive ? `${(1000 - (1000 * (commissionRate / 100))).toFixed(1)} د.ل` : '1,000 د.ل'}
                      </strong>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#1f6a4c] hover:bg-[#288862] text-white font-bold py-2.5 rounded-xl transition-all shadow-sm"
                  >
                    حفظ وتطبيق إعدادات العمولة فوراً
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 2: REPORTS & COMPLAINTS */}
          {activeTab === 'reports' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-base text-white m-0">
                  البلاغات والشكاوى الواردة من المستخدمين ({reports.length})
                </h4>
                <span className="text-xs text-gray-400">
                  {pendingReportsCount} بلاغ جديد بانتظار المراجعة
                </span>
              </div>

              {reports.length === 0 ? (
                <div className="bg-[#14231b] border border-dashed border-gray-700 rounded-2xl p-8 text-center text-gray-400">
                  لا توجد بلاغات مسجلة حالياً.
                </div>
              ) : (
                <div className="space-y-3">
                  {reports.map((rep) => (
                    <div
                      key={rep.id}
                      className="bg-[#14231b] border border-emerald-950 rounded-2xl p-4 space-y-2.5"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              rep.status === 'pending'
                                ? 'bg-rose-500'
                                : rep.status === 'reviewed'
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                            }`}
                          />
                          <strong className="text-white font-bold text-sm">
                            {rep.shipmentTitle}
                          </strong>
                          <span className="text-xs bg-gray-800 text-gray-300 px-2 py-0.5 rounded-md">
                            المبلغ عنه: {rep.reportedPhone}
                          </span>
                        </div>
                        <span className="text-xs text-gray-400">{rep.timestamp}</span>
                      </div>

                      <div className="bg-[#0e1813] border border-gray-800 rounded-xl p-2.5 text-xs text-rose-200">
                        <strong>سبب الشكوى:</strong> {rep.reason}
                        {rep.reporterPhone && (
                          <span className="block text-gray-400 mt-1">
                            رقم هاتف مقدم البلاغ: {rep.reporterPhone}
                          </span>
                        )}
                      </div>

                      {/* Admin actions on report */}
                      <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-gray-800/60">
                        <button
                          onClick={() => {
                            onDeleteShipment(rep.shipmentId);
                            onUpdateReportStatus(rep.id, 'resolved');
                          }}
                          className="bg-rose-900/70 hover:bg-rose-800 text-rose-200 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>حذف الحمولة المبلغ عنها فوراً</span>
                        </button>

                        <button
                          onClick={() => {
                            onAddBan({
                              id: `ban-${Date.now()}`,
                              phone: rep.reportedPhone,
                              name: 'محظور بسبب بلاغ مستخدم',
                              reason: rep.reason,
                              bannedAt: new Date().toISOString().split('T')[0],
                            });
                            onUpdateReportStatus(rep.id, 'resolved');
                          }}
                          className="bg-gray-800 hover:bg-gray-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1"
                        >
                          <Ban className="w-3.5 h-3.5 text-rose-400" />
                          <span>حظر هذا الرقم نهائياً</span>
                        </button>

                        <button
                          onClick={() => onUpdateReportStatus(rep.id, 'resolved')}
                          className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 text-xs font-bold px-3 py-1.5 rounded-lg mr-auto flex items-center gap-1"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>تعيين كـ &quot;تمت المعالجة&quot;</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BLACKLIST & BANS */}
          {activeTab === 'blacklist' && (
            <div className="space-y-5">
              {/* Add new ban manually */}
              <div className="bg-[#14231b] border border-gray-800 rounded-2xl p-4 sm:p-5">
                <h4 className="font-extrabold text-sm text-white mb-3 flex items-center gap-2">
                  <Ban className="w-4 h-4 text-rose-400" />
                  <span>إضافة رقم هاتف أو ناقل للقائمة السوداء (حظر فوري)</span>
                </h4>

                {banError && (
                  <div className="bg-rose-950/80 text-rose-200 text-xs p-2 rounded-lg mb-3">
                    {banError}
                  </div>
                )}

                <form onSubmit={handleCreateBan} className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                  <input
                    type="tel"
                    placeholder="رقم الهاتف (091xxxxxxx)"
                    value={newBanPhone}
                    onChange={(e) => setNewBanPhone(e.target.value)}
                    className="bg-gray-800 border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500"
                    required
                  />
                  <input
                    type="text"
                    placeholder="اسم المستخدم أو الصفة"
                    value={newBanName}
                    onChange={(e) => setNewBanName(e.target.value)}
                    className="bg-gray-800 border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500"
                  />
                  <input
                    type="text"
                    placeholder="سبب الحظر"
                    value={newBanReason}
                    onChange={(e) => setNewBanReason(e.target.value)}
                    className="bg-gray-800 border border-gray-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-rose-500"
                  />
                  <button
                    type="submit"
                    className="bg-rose-800 hover:bg-rose-700 text-white text-xs font-bold py-2 px-4 rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>تأكيد الحظر</span>
                  </button>
                </form>
              </div>

              {/* Banned list table */}
              <div className="space-y-3">
                <h4 className="font-bold text-xs text-gray-400">
                  الحسابات والأرقام المحظورة حالياً ({bannedList.length}):
                </h4>

                {bannedList.length === 0 ? (
                  <div className="bg-[#14231b] border border-dashed border-gray-800 rounded-xl p-6 text-center text-xs text-gray-400">
                    القائمة السوداء فارغة، لا يوجد مستخدمين محظورين.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {bannedList.map((item) => (
                      <div
                        key={item.id}
                        className="bg-[#14231b] border border-rose-950/40 rounded-xl p-3 flex items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <div className="font-bold text-rose-300 flex items-center gap-2">
                            <span>🚫 {item.phone}</span>
                            <span className="text-gray-400 font-normal">({item.name})</span>
                          </div>
                          <p className="text-gray-400 text-[11px] mt-0.5 m-0">
                            السبب: {item.reason} • تاريخ الحظر: {item.bannedAt}
                          </p>
                        </div>
                        <button
                          onClick={() => onRemoveBan(item.phone)}
                          className="bg-gray-800 hover:bg-emerald-900 text-gray-300 hover:text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-colors"
                        >
                          إلغاء الحظر
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: ALL SHIPMENTS MODERATION */}
          {activeTab === 'shipments' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-base text-white m-0">
                  إدارة كافة إعلانات الحمولات النشطة ({shipments.length})
                </h4>
                <span className="text-xs text-gray-400">
                  يمكنك حذف أي إعلان مخالف مباشرة
                </span>
              </div>

              <div className="space-y-2.5">
                {shipments.map((s) => (
                  <div
                    key={s.id}
                    className="bg-[#14231b] border border-gray-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <strong className="text-white text-sm block">
                        من {s.from} إلى {s.to} • {s.type}
                      </strong>
                      <span className="text-gray-400 block mt-0.5">
                        الشاحنة: {s.vehicle} | الوزن: {s.weight} | السعر: {s.price} د.ل | الهاتف: {s.phone}
                      </span>
                    </div>

                    <button
                      onClick={() => onDeleteShipment(s.id)}
                      className="bg-rose-950 text-rose-300 hover:bg-rose-900 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>حذف الإعلان</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: EMERGENCY BROADCAST BANNER */}
          {activeTab === 'broadcast' && (
            <div className="space-y-4 max-w-2xl">
              <div className="bg-[#14231b] border border-gray-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-gray-800">
                  <div>
                    <h4 className="font-extrabold text-base text-white m-0">
                      شريط تنبيهات الطوارئ والبث العام
                    </h4>
                    <p className="text-xs text-gray-400 m-0 mt-0.5">
                      يظهر كشريط تنبيه أحمر/أصفر بأعلى التطبيق لجميع المستخدمين والسائقين
                    </p>
                  </div>
                  <button
                    type="button"
                    role="switch"
                    aria-label="تفعيل أو تعطيل بث الطوارئ"
                    aria-checked={isBroadcastActive}
                    onClick={() => setIsBroadcastActive(!isBroadcastActive)}
                    className={`w-12 h-6 rounded-full transition-colors relative p-0.5 flex items-center ${
                      isBroadcastActive ? 'bg-amber-600' : 'bg-gray-700'
                    }`}
                  >
                    <span
                      className={`w-5 h-5 bg-white rounded-full block shadow-md transition-transform ${
                        isBroadcastActive ? 'mr-0' : 'mr-6'
                      }`}
                    />
                  </button>
                </div>

                <form onSubmit={handleSaveBroadcast} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      نص التنبيه أو إشعار الطرق
                    </label>
                    <textarea
                      rows={3}
                      value={broadcastNotice}
                      onChange={(e) => setBroadcastNotice(e.target.value)}
                      placeholder="مثال: تنبيه: إغلاق مؤقت لبوابة الدافنية أو أعمال صيانة على طريق سرت..."
                      className="w-full bg-gray-800 border border-gray-700 rounded-xl p-3 text-xs sm:text-sm text-white outline-none focus:border-amber-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-600 hover:bg-amber-500 text-black font-extrabold py-2.5 rounded-xl transition-all"
                  >
                    تحديث شريط البث العام
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
