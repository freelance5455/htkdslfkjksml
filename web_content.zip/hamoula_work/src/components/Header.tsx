import React, { useState } from 'react';
import { UserRole } from '../types/shipment';
import { isSecretDevCode } from '../utils/admin';
import {
  Search,
  Truck,
  UserCheck,
  ShieldCheck,
  MapPin,
  X,
  Settings,
  Radio,
  Crown,
  Download,
} from 'lucide-react';

interface HeaderProps {
  role: UserRole;
  onToggleRole: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenCalculator: () => void;
  isDevUnlocked: boolean;
  onOpenDevPanel: () => void;
  onUnlockDevWithCode?: (code: string) => boolean;
  broadcastNotice?: string;
  isBroadcastActive?: boolean;
  onOpenInstallModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  role,
  onToggleRole,
  searchQuery,
  onSearchChange,
  onOpenCalculator,
  isDevUnlocked,
  onOpenDevPanel,
  onUnlockDevWithCode,
  broadcastNotice,
  isBroadcastActive,
  onOpenInstallModal,
}) => {
  const [logoClicks, setLogoClicks] = useState(0);

  // Secret logo click trigger: 5 rapid clicks unlocks developer mode
  const handleLogoClick = () => {
    const nextCount = logoClicks + 1;
    setLogoClicks(nextCount);
    if (nextCount >= 5) {
      setLogoClicks(0);
      if (onUnlockDevWithCode) {
        onUnlockDevWithCode('admin777');
      } else {
        onOpenDevPanel();
      }
    }
    setTimeout(() => {
      setLogoClicks(0);
    }, 3500);
  };

  // Check secret developer code entered in search
  const handleSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (isSecretDevCode(val)) {
      onSearchChange('');
      if (onUnlockDevWithCode) {
        onUnlockDevWithCode(val);
      } else {
        onOpenDevPanel();
      }
      return;
    }
    onSearchChange(val);
  };

  return (
    <>
      {/* Emergency broadcast banner across top if enabled by dev */}
      {isBroadcastActive && broadcastNotice && (
        <div className="bg-amber-500 text-black px-4 py-2 text-xs sm:text-sm font-black flex items-center justify-center gap-2 text-center shadow-md border-b border-amber-600 animate-in slide-in-from-top duration-200">
          <Radio className="w-4 h-4 animate-pulse shrink-0" />
          <span>{broadcastNotice}</span>
        </div>
      )}

      <header className="bg-gradient-to-b from-[#123b2c] to-[#184836] text-white pt-6 pb-8 px-4 sm:px-6 rounded-b-[32px] shadow-lg border-b border-emerald-950/20">
        <div className="max-w-5xl mx-auto">
          {/* Top bar with brand & role switcher */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {/* Clickable logo with secret dev trigger */}
              <button
                type="button"
                onClick={handleLogoClick}
                title="اضغط 5 مرات لفتح وضع المطور"
                className="w-12 h-12 rounded-2xl bg-[#d9f36a] text-[#123b2c] flex items-center justify-center font-extrabold text-2xl shadow-md border-2 border-white/20 select-none cursor-pointer hover:scale-105 active:scale-95 transition-transform"
              >
                ح
              </button>

              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white m-0">
                    حمولة ليبيا
                  </h1>
                  <span className="text-xs bg-[#d9f36a]/20 text-[#d9f36a] px-2 py-0.5 rounded-full font-semibold border border-[#d9f36a]/30">
                    شحن ونقل
                  </span>

                  {isDevUnlocked && (
                    <span className="text-[10px] bg-amber-400 text-black px-2 py-0.5 rounded-full font-black animate-pulse flex items-center gap-1">
                      <Crown className="w-3 h-3" />
                      مطور
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-emerald-100/80 m-0">
                  من بابك إلى وجهتك عبر كافة المدن 🇱🇾
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Developer Dashboard Button (shown when unlocked) */}
              {isDevUnlocked && (
                <button
                  onClick={onOpenDevPanel}
                  aria-label="لوحة تحكم المطور"
                  className="text-xs bg-amber-500 hover:bg-amber-400 text-black font-extrabold rounded-2xl px-3 py-2 flex items-center gap-1.5 transition-all shadow-md"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span>لوحة المطور</span>
                </button>
              )}

              <button
                onClick={onOpenCalculator}
                aria-label="حاسبة أجرة الشحن والمسافات"
                className="text-xs bg-white/10 hover:bg-white/15 text-white border border-white/20 rounded-2xl px-3 py-2 flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <MapPin className="w-3.5 h-3.5 text-[#d9f36a]" />
                <span className="hidden sm:inline">حاسبة</span> الأجرة والمسافات
              </button>

              {onOpenInstallModal && (
                <button
                  onClick={onOpenInstallModal}
                  aria-label="تنزيل وتثبيت التطبيق على الهاتف"
                  className="text-xs bg-[#d9f36a] hover:bg-[#cbe65d] text-[#123b2c] font-black rounded-2xl px-3 py-2 flex items-center gap-1.5 transition-all shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تثبيت التطبيق 📲</span>
                </button>
              )}

              <button
                id="roleButton"
                onClick={onToggleRole}
                aria-label="تبديل الدور بين صاحب البضاعة والناقل"
                className="text-xs sm:text-sm font-semibold rounded-2xl px-3.5 py-2 flex items-center gap-2 transition-all shadow-sm border border-white/25 bg-white/10 hover:bg-white/20 text-white"
              >
                {role === 'owner' ? (
                  <>
                    <UserCheck className="w-4 h-4 text-[#d9f36a]" />
                    <span>وضع صاحب البضاعة</span>
                  </>
                ) : (
                  <>
                    <Truck className="w-4 h-4 text-[#d9f36a]" />
                    <span>وضع السائق / الناقل</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Hero title & value proposition */}
          <div className="mt-6 sm:mt-7">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-snug">
              {role === 'owner'
                ? 'نقل بضاعتك في ليبيا صار أسهل وأوضح 🚚'
                : 'ابحث عن حمولات تناسب شاحنتك وخط سيرك 🚛'}
            </h2>
            <p className="text-emerald-100/85 text-sm sm:text-base mt-2 max-w-2xl leading-relaxed">
              {role === 'owner'
                ? 'اعرض حمولتك للناقلين وسائقي الشاحنات في جميع المدن الليبية، تواصل بالهاتف أو الواتساب فوراً دون عمولة.'
                : 'تصفح طلبات الشحن النشطة من طرابلس وبنغازي ومصراتة والجنوب، قدّم عروض أسعارك مباشرة.'}
            </p>
          </div>

          {/* Search Bar - Typing 'admin777' or 'devlibya' unlocks Developer Mode */}
          <div className="mt-5 relative">
            <div className="flex items-center bg-white rounded-2xl shadow-xl overflow-hidden p-1.5 border border-emerald-900/10 focus-within:ring-2 focus-within:ring-[#d9f36a]">
              <div className="pr-3 pl-2 text-emerald-800 flex items-center">
                <Search className="w-5 h-5" />
              </div>
              <input
                id="searchInput"
                type="text"
                value={searchQuery}
                onChange={handleSearchInputChange}
                placeholder="ابحث عن مدينة أو نوع حمولة (اكتب admin777 للدخول للمطور)..."
                className="w-full py-2.5 px-2 text-[#17231d] placeholder:text-gray-400 text-sm sm:text-base bg-transparent border-none outline-none font-medium"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  aria-label="مسح البحث"
                  className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => onSearchChange(searchQuery)}
                className="bg-[#d9f36a] hover:bg-[#cbe65d] text-[#123b2c] font-bold text-sm px-4 sm:px-6 py-2.5 rounded-xl transition-colors shrink-0 shadow-sm"
              >
                بحث
              </button>
            </div>
          </div>

          {/* Quick Highlights / Badges */}
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-emerald-100/90">
            <div className="flex items-center gap-1.5 bg-white/10 px-2.5 py-1 rounded-full border border-white/10">
              <ShieldCheck className="w-3.5 h-3.5 text-[#d9f36a]" />
              <span>تواصل ومفاوضة مباشرة دون وسيط مالي</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 px-2.5 py-1 rounded-full border border-white/10">
              <Truck className="w-3.5 h-3.5 text-[#d9f36a]" />
              <span>من شاحنات النقل الخفيف إلى التريلات</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 px-2.5 py-1 rounded-full border border-white/10">
              <MapPin className="w-3.5 h-3.5 text-[#d9f36a]" />
              <span>تغطية الطرق الساحلية والصحراوية</span>
            </div>
          </div>
        </div>
      </header>
    </>
  );
};
