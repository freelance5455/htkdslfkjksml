import React from 'react';
import { Home, PlusCircle, ClipboardList, Calculator, ShieldCheck, User } from 'lucide-react';

export type ActiveTab = 'home' | 'post' | 'my' | 'calculator' | 'safety' | 'profile';

interface BottomNavProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  myShipmentsCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  myShipmentsCount,
}) => {
  const navItems: { tab: ActiveTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      tab: 'home',
      label: 'الرئيسية',
      icon: <Home className="w-5 h-5" />,
    },
    {
      tab: 'post',
      label: 'نشر حمولة',
      icon: <PlusCircle className="w-5 h-5" />,
    },
    {
      tab: 'my',
      label: 'حمولاتي',
      icon: <ClipboardList className="w-5 h-5" />,
      badge: myShipmentsCount > 0 ? myShipmentsCount : undefined,
    },
    {
      tab: 'calculator',
      label: 'الحاسبة',
      icon: <Calculator className="w-5 h-5" />,
    },
    {
      tab: 'safety',
      label: 'الأمان',
      icon: <ShieldCheck className="w-5 h-5" />,
    },
    {
      tab: 'profile',
      label: 'حسابي',
      icon: <User className="w-5 h-5" />,
    },
  ];

  return (
    <nav
      aria-label="التنقل الرئيسي للتطبيق"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-gray-200/90 shadow-lg"
    >
      <div className="max-w-3xl mx-auto px-2 py-1.5 flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.tab;
          return (
            <button
              key={item.tab}
              onClick={() => onChangeTab(item.tab)}
              aria-current={isActive ? 'page' : undefined}
              className={`flex-1 py-1.5 px-1 rounded-2xl flex flex-col items-center justify-center transition-all relative ${
                isActive
                  ? 'text-[#123b2c] font-black'
                  : 'text-gray-500 hover:text-gray-800 font-medium'
              }`}
            >
              <div className="relative">
                <span
                  className={`transition-transform duration-200 block ${
                    isActive ? 'scale-110 text-[#123b2c]' : 'text-gray-500'
                  }`}
                >
                  {item.icon}
                </span>
                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-2 bg-emerald-600 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className={`text-[11px] sm:text-xs mt-1 ${isActive ? 'font-bold' : ''}`}>
                {item.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#123b2c] mt-0.5"></span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
