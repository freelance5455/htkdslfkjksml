import React, { useState } from 'react';
import { Shipment } from '../types/shipment';
import { ShipmentReport } from '../types/admin';
import { isValidLibyanPhone } from '../utils/freight';
import { X, AlertTriangle, Send } from 'lucide-react';

interface ReportModalProps {
  shipment: Shipment | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmitReport: (report: ShipmentReport) => void;
}

const REPORT_REASONS = [
  'طلب تحويل مالي أو عربون مشبوه مسبقاً',
  'رقم الهاتف وهمي أو مغلق باستمرار',
  'بضاعة مخالفة أو معلومات غير صحيحة',
  'سوء تعامل أو إلغاء غير مبرر بعد الاتفاق',
  'إعلان متكرر (سبام)',
  'سبب آخر...',
];

export const ReportModal: React.FC<ReportModalProps> = ({
  shipment,
  isOpen,
  onClose,
  onSubmitReport,
}) => {
  const [selectedReason, setSelectedReason] = useState(REPORT_REASONS[0]);
  const [customReason, setCustomReason] = useState('');
  const [reporterPhone, setReporterPhone] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen || !shipment) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (reporterPhone && !isValidLibyanPhone(reporterPhone)) {
      setErrorMsg('يرجى إدخال رقم هاتف ليبي صحيح لمتابعة البلاغ معك');
      return;
    }

    const finalReason =
      selectedReason === 'سبب آخر...' && customReason.trim()
        ? customReason.trim()
        : selectedReason;

    const newReport: ShipmentReport = {
      id: `rep-${Date.now()}`,
      shipmentId: shipment.id,
      shipmentTitle: `${shipment.from} ← ${shipment.to} (${shipment.type})`,
      reportedPhone: shipment.phone,
      reason: finalReason,
      reporterPhone: reporterPhone.trim() || undefined,
      timestamp: 'الآن',
      status: 'pending',
    };

    onSubmitReport(newReport);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="reportModalTitle"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150"
    >
      <div
        className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden border border-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-rose-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-500/30 text-rose-200 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 id="reportModalTitle" className="text-base sm:text-lg font-black m-0">
                إبلاغ عن إعلان أو مستخدم مشبوه
              </h3>
              <p className="text-xs text-rose-200/80 m-0">
                يصل بلاغك فوراً إلى إدارة المنصة للتحقق
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="إغلاق نافذة البلاغ"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs sm:text-sm">
          <div className="bg-gray-50 border border-gray-200 rounded-2xl p-3">
            <span className="text-xs text-gray-500 block">الإعلان المبلغ عنه:</span>
            <strong className="text-gray-900 font-bold block mt-0.5">
              من {shipment.from} إلى {shipment.to} • {shipment.type}
            </strong>
            <span className="text-xs text-gray-600 block mt-1">
              رقم الهاتف: {shipment.phone}
            </span>
          </div>

          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-2.5 rounded-xl text-xs font-bold">
              {errorMsg}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1.5">
              سبب الإبلاغ <span className="text-rose-500">*</span>
            </label>
            <select
              value={selectedReason}
              onChange={(e) => setSelectedReason(e.target.value)}
              className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm font-medium outline-none focus:ring-2 focus:ring-rose-800"
            >
              {REPORT_REASONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          {selectedReason === 'سبب آخر...' && (
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                توضيح السبب
              </label>
              <textarea
                rows={2}
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                placeholder="اكتب تفاصيل الشكوى هنا..."
                className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm outline-none focus:ring-2 focus:ring-rose-800"
                required
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">
              رقم هاتفك للتواصل معك (اختياري)
            </label>
            <input
              type="tel"
              placeholder="مثال: 0912345678"
              value={reporterPhone}
              onChange={(e) => setReporterPhone(e.target.value)}
              className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm outline-none focus:ring-2 focus:ring-rose-800"
            />
          </div>

          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 py-2.5 rounded-xl font-bold text-xs"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex-1 bg-rose-800 hover:bg-rose-900 text-white py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال البلاغ</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
