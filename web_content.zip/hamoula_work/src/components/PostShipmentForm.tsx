import React, { useState, useEffect } from 'react';
import { CargoCategory, VehicleCategory, Shipment } from '../types/shipment';
import {
  LIBYAN_CITIES,
  getLibyanDistanceKm,
  estimateFreightCost,
  isValidLibyanPhone,
} from '../utils/freight';
import {
  PackagePlus,
  Truck,
  MapPin,
  Calendar,
  Banknote,
  Phone,
  FileText,
  AlertCircle,
  HelpCircle,
  Sparkles,
  Zap,
  Users,
} from 'lucide-react';

interface PostShipmentFormProps {
  onShipmentCreated: (shipment: Shipment) => void;
  prefillOrigin?: string;
  prefillDestination?: string;
  prefillVehicle?: VehicleCategory;
}

const CARGO_TYPES: CargoCategory[] = [
  'خضروات وفواكه',
  'مواد بناء',
  'أثاث ونقل عفش',
  'أجهزة كهربائية',
  'بضائع عامة',
  'معدات ثقيلة',
  'مستلزمات طبية',
  'أخرى',
];

const VEHICLE_TYPES: VehicleCategory[] = [
  'سيارة نقل صغيرة (وانيت / كانتر)',
  'شاحنة متوسطة (إيفيكو / مرسيدس)',
  'شاحنة كبيرة (تريلا)',
  'براد تبريد (لحوم / خضار)',
  'سطحة لنقل السيارات',
  'قاطرة ومقطورة',
  'صهريج سوائل',
  'حسب المتاح',
];

export const PostShipmentForm: React.FC<PostShipmentFormProps> = ({
  onShipmentCreated,
  prefillOrigin = '',
  prefillDestination = '',
  prefillVehicle,
}) => {
  const [cargoType, setCargoType] = useState<CargoCategory>('بضائع عامة');
  const [vehicleType, setVehicleType] = useState<VehicleCategory>(
    prefillVehicle || 'شاحنة كبيرة (تريلا)'
  );
  const [fromCity, setFromCity] = useState(prefillOrigin || 'طرابلس');
  const [toCity, setToCity] = useState(prefillDestination || 'بنغازي');
  const [weight, setWeight] = useState('');
  const [loadDate, setLoadDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [budget, setBudget] = useState('');
  const [phone, setPhone] = useState('');
  const [details, setDetails] = useState('');
  const [requiresLabor, setRequiresLabor] = useState(false);
  const [isUrgent, setIsUrgent] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Live estimate based on route and vehicle
  const distance = getLibyanDistanceKm(fromCity, toCity);
  const costEstimate = estimateFreightCost(fromCity, toCity, vehicleType, isUrgent);

  useEffect(() => {
    if (prefillOrigin) setFromCity(prefillOrigin);
    if (prefillDestination) setToCity(prefillDestination);
  }, [prefillOrigin, prefillDestination]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!fromCity.trim() || !toCity.trim()) {
      setErrorMessage('يرجى تحديد مدينة التحميل ومدينة التسليم');
      return;
    }

    if (fromCity.trim() === toCity.trim()) {
      setErrorMessage('مدينة التحميل والتسليم متطابقتان، يرجى كتابة عنوانين مختلفين إذا كان النقل داخلياً');
    }

    if (!weight.trim()) {
      setErrorMessage('يرجى كتابة الوزن أو حجم البضاعة التقريبي');
      return;
    }

    if (!isValidLibyanPhone(phone)) {
      setErrorMessage(
        'رقم الهاتف غير صحيح. يرجى إدخال رقم ليبي صالح يبدأ بـ 091 أو 092 أو 094 أو 093 أو 095'
      );
      return;
    }

    const newShipment: Shipment = {
      id: Date.now(),
      type: cargoType,
      vehicle: vehicleType,
      from: fromCity.trim(),
      to: toCity.trim(),
      weight: weight.trim(),
      date: loadDate,
      price: budget ? Number(budget) : costEstimate.averagePrice,
      phone: phone.trim(),
      details: details.trim(),
      requiresLabor,
      isUrgent,
      demo: false,
      status: 'active',
      createdAt: 'الآن',
      offers: [],
    };

    onShipmentCreated(newShipment);
    setWeight('');
    setBudget('');
    setDetails('');
  };

  return (
    <div className="bg-white rounded-3xl border border-gray-200/90 shadow-sm p-5 sm:p-7">
      <div className="flex items-center justify-between pb-5 border-b border-gray-100 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-100/70 text-[#123b2c] flex items-center justify-center font-bold">
            <PackagePlus className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg sm:text-xl font-black text-gray-900 m-0">
              نشر حمولة جديدة
            </h3>
            <p className="text-xs text-gray-500 m-0 mt-0.5">
              اعرض بضاعتك مجاناً وستصلك اتصالات وعروض من سائقين معتمدين
            </p>
          </div>
        </div>
        <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 hidden sm:inline">
          نشر فوري مباشر
        </span>
      </div>

      {errorMessage && (
        <div className="mb-5 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl p-3.5 text-xs sm:text-sm font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Cargo & Vehicle selection */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="cargoType" className="block text-xs font-bold text-gray-700 mb-1.5">
              نوع الحمولة <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <select
                id="cargoType"
                value={cargoType}
                onChange={(e) => setCargoType(e.target.value as CargoCategory)}
                required
                className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-bold text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c] focus:border-transparent transition-all"
              >
                {CARGO_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="vehicleType" className="block text-xs font-bold text-gray-700 mb-1.5">
              نوع الشاحنة المطلوبة <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <select
                id="vehicleType"
                value={vehicleType}
                onChange={(e) => setVehicleType(e.target.value as VehicleCategory)}
                required
                className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-bold text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c] focus:border-transparent transition-all"
              >
                {VEHICLE_TYPES.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Route: From & To Cities */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="fromCity" className="block text-xs font-bold text-gray-700 mb-1.5">
              مدينة التحميل (نقطة الانطلاق) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <select
                id="fromCity"
                value={fromCity}
                onChange={(e) => setFromCity(e.target.value)}
                required
                className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-bold text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
              >
                {LIBYAN_CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="toCity" className="block text-xs font-bold text-gray-700 mb-1.5">
              مدينة التسليم (الوجهة) <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <select
                id="toCity"
                value={toCity}
                onChange={(e) => setToCity(e.target.value)}
                required
                className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-bold text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
              >
                {LIBYAN_CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Route Hint & Benchmark Preview */}
        {distance > 0 && (
          <div className="bg-emerald-50/80 border border-emerald-200/80 rounded-2xl p-3 sm:p-4 text-xs flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
              <div>
                <span className="font-bold text-emerald-950">
                  المسافة البرية: {distance} كم (تقريباً {costEstimate.travelHours} ساعة قيادة للشاحنة)
                </span>
                <span className="block text-gray-600 mt-0.5">
                  متوسط الأجرة السوقية التقديرية في ليبيا: {costEstimate.minPrice} - {costEstimate.maxPrice} د.ل
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setBudget(costEstimate.averagePrice.toString())}
              className="text-[11px] font-bold bg-white text-emerald-800 px-3 py-1.5 rounded-xl border border-emerald-300 hover:bg-emerald-100 transition-colors"
            >
              استخدام المقترح ({costEstimate.averagePrice} د.ل)
            </button>
          </div>
        )}

        {/* Weight & Loading Date */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="weight" className="block text-xs font-bold text-gray-700 mb-1.5">
              الوزن أو الحجم التقريبي <span className="text-rose-500">*</span>
            </label>
            <input
              id="weight"
              type="text"
              placeholder="مثال: 5 طن، 50 صندوق، أثاث شقة 3 غرف..."
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              required
              className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-medium text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
            />
          </div>

          <div>
            <label htmlFor="loadDate" className="block text-xs font-bold text-gray-700 mb-1.5">
              موعد التحميل المستهدف <span className="text-rose-500">*</span>
            </label>
            <input
              id="loadDate"
              type="date"
              value={loadDate}
              onChange={(e) => setLoadDate(e.target.value)}
              required
              className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-medium text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
            />
          </div>
        </div>

        {/* Price & Phone */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="budget" className="block text-xs font-bold text-gray-700 mb-1.5">
              السعر المقترح (د.ل) <span className="text-gray-400 font-normal">(اختياري)</span>
            </label>
            <input
              id="budget"
              type="number"
              min="0"
              placeholder={`اتركه فارغاً للتفاوض أو اقترح (مثال: ${costEstimate.averagePrice})`}
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-medium text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
            />
          </div>

          <div>
            <label htmlFor="phone" className="block text-xs font-bold text-gray-700 mb-1.5">
              رقم هاتف التواصل الليبي <span className="text-rose-500">*</span>
            </label>
            <input
              id="phone"
              type="tel"
              placeholder="مثال: 0912345678 أو 092xxxxxxx"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl px-3.5 py-3 text-sm font-medium text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c]"
            />
          </div>
        </div>

        {/* Checkbox Options: Helpers & Urgency */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <label className="flex items-center gap-2.5 p-3 rounded-2xl bg-gray-50 border border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors">
            <input
              type="checkbox"
              checked={requiresLabor}
              onChange={(e) => setRequiresLabor(e.target.checked)}
              className="w-4 h-4 rounded text-emerald-700 focus:ring-emerald-700"
            />
            <div className="text-xs">
              <span className="font-bold text-gray-800 block">أحتاج عمال مساعدة في التحميل</span>
              <span className="text-gray-500">للمساعدة في رفع وتنزيل الأغراض الثقيلة</span>
            </div>
          </label>

          <label className="flex items-center gap-2.5 p-3 rounded-2xl bg-gray-50 border border-gray-200 cursor-pointer hover:bg-gray-100 transition-colors">
            <input
              type="checkbox"
              checked={isUrgent}
              onChange={(e) => setIsUrgent(e.target.checked)}
              className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
            />
            <div className="text-xs">
              <span className="font-bold text-gray-800 block">حمولة عاجلة (شحن فوري اليوم)</span>
              <span className="text-gray-500">تمييز الإعلان بلون خاص لجذب السائقين فوراً</span>
            </div>
          </label>
        </div>

        {/* Details & Notes */}
        <div>
          <label htmlFor="details" className="block text-xs font-bold text-gray-700 mb-1.5">
            تفاصيل إضافية وعناوين التسليم
          </label>
          <textarea
            id="details"
            rows={3}
            placeholder="مثال: مكان التحميل بالتحديد، وجود رافعة شوكية، حالة الطريق، أي تعليمات خاصة للشاحنة..."
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-3.5 text-sm font-medium text-gray-800 outline-none focus:ring-2 focus:ring-[#123b2c] resize-y"
          ></textarea>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-[#123b2c] hover:bg-[#1a523d] text-white text-base font-extrabold py-3.5 px-6 rounded-2xl shadow-md transition-all flex items-center justify-center gap-2"
          >
            <PackagePlus className="w-5 h-5 text-[#d9f36a]" />
            <span>نشر الإعلان وعرضه للسائقين</span>
          </button>
        </div>

        <p className="text-[11px] text-gray-500 text-center leading-relaxed">
          نصيحة أمان: لا تقم بتحويل عربون مالي مقدماً دون فحص ومقابلة الناقل والتأكد من مطابقة شاحنته وبياناته.
        </p>
      </form>
    </div>
  );
};
