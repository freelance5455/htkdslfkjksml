import React, { useState } from 'react';
import { UserRole } from '../types/shipment';
import {
  User,
  Truck,
  ShieldCheck,
  RotateCcw,
  BadgeCheck,
  CheckCircle,
  HelpCircle,
  Smartphone,
  MapPin,
} from 'lucide-react';

interface ProfileViewProps {
  role: UserRole;
  onToggleRole: () => void;
  myShipmentsCount: number;
  onClearMyShipments: () => void;
  driverInfo: {
    name: string;
    vehicle: string;
    plate: string;
    isVerified: boolean;
  };
  onSaveDriverInfo: (info: {
    name: string;
    vehicle: string;
    plate: string;
    isVerified: boolean;
  }) => void;
  isDevUnlocked: boolean;
  onOpenDevPanel: () => void;
  onUnlockDevWithCode: (code: string) => boolean;
  onOpenInstallModal?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  role,
  onToggleRole,
  myShipmentsCount,
  onClearMyShipments,
  driverInfo,
  onSaveDriverInfo,
  isDevUnlocked,
  onOpenDevPanel,
  onUnlockDevWithCode,
  onOpenInstallModal,
}) => {
  const [driverName, setDriverName] = useState(driverInfo.name || '');
  const [driverVehicle, setDriverVehicle] = useState(driverInfo.vehicle || '');
  const [driverPlate, setDriverPlate] = useState(driverInfo.plate || '');
  const [isVerified, setIsVerified] = useState(driverInfo.isVerified || false);
  const [devCodeInput, setDevCodeInput] = useState('');
  const [devCodeError, setDevCodeError] = useState('');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveDriver = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveDriverInfo({
      name: driverName.trim(),
      vehicle: driverVehicle.trim(),
      plate: driverPlate.trim(),
      isVerified,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Profile summary card */}
      <div className="bg-white rounded-3xl border border-gray-200/90 p-5 sm:p-7 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-gray-100">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-[#123b2c] flex items-center justify-center font-extrabold text-2xl shadow-xs">
              {role === 'owner' ? '👤' : '🚛'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-extrabold text-gray-900 m-0">
                  {role === 'owner' ? 'حساب صاحب البضاعة' : 'حساب الناقل / السائق'}
                </h3>
                {isVerified && role === 'driver' && (
                  <span className="flex items-center gap-1 text-[11px] bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full">
                    <BadgeCheck className="w-3.5 h-3.5 text-emerald-600" />
                    ناقل معتمد
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500 m-0 mt-1">
                {role === 'owner'
                  ? 'يمكنك نشر حمولات والتفاوض المباشر مع السائقين'
                  : 'يمكنك تصفح الحمولات المتاحة وتقديم عروض أسعار تنافسية'}
              </p>
            </div>
          </div>

          <button
            onClick={onToggleRole}
            className="bg-[#123b2c] hover:bg-[#1f6a4c] text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-2xl transition-all shadow-xs flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4 text-[#d9f36a]" />
            <span>التبديل إلى {role === 'owner' ? 'وضع السائق' : 'وضع صاحب البضاعة'}</span>
          </button>
        </div>

        {/* Quick stats strip */}
        <div className="grid grid-cols-3 gap-3 pt-6 text-center">
          <div className="bg-[#f7faf8] p-4 rounded-2xl border border-gray-100">
            <strong className="text-2xl font-black text-[#123b2c] block">
              {myShipmentsCount}
            </strong>
            <small className="text-xs text-gray-500 font-medium">حمولاتي المسجلة</small>
          </div>
          <div className="bg-[#f7faf8] p-4 rounded-2xl border border-gray-100">
            <strong className="text-2xl font-black text-[#123b2c] block">
              🇱🇾 ليبيا
            </strong>
            <small className="text-xs text-gray-500 font-medium">نطاق التغطية الكامل</small>
          </div>
          <div className="bg-[#f7faf8] p-4 rounded-2xl border border-gray-100">
            <strong className="text-2xl font-black text-emerald-600 block">
              0%
            </strong>
            <small className="text-xs text-gray-500 font-medium">عمولة الوساطة</small>
          </div>
        </div>
      </div>

      {/* Driver verification profile (for drivers) */}
      {role === 'driver' && (
        <div className="bg-white rounded-3xl border border-gray-200/90 p-5 sm:p-7 shadow-xs">
          <div className="flex items-center gap-3 pb-4 border-b border-gray-100 mb-4">
            <Truck className="w-6 h-6 text-emerald-700" />
            <div>
              <h4 className="font-extrabold text-base sm:text-lg text-gray-900 m-0">
                بيانات شاحنتك وشارة التوثيق
              </h4>
              <p className="text-xs text-gray-500 m-0 mt-0.5">
                تظهر هذه البيانات لأصحاب البضائع عند تقديم عروض الأسعار
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveDriver} className="space-y-4">
            {savedSuccess && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold p-3 rounded-2xl flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>تم حفظ بيانات السائق بنجاح!</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  اسم السائق أو المشغل
                </label>
                <input
                  type="text"
                  placeholder="مثال: يوسف الترهوني"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm font-medium outline-none focus:ring-2 focus:ring-[#123b2c]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  نوع وموديل الشاحنة
                </label>
                <input
                  type="text"
                  placeholder="مثال: تريلا مرسيدس أكتروس 1844"
                  value={driverVehicle}
                  onChange={(e) => setDriverVehicle(e.target.value)}
                  className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm font-medium outline-none focus:ring-2 focus:ring-[#123b2c]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                رقم اللوحة الليبية (اختياري)
              </label>
              <input
                type="text"
                placeholder="مثال: 5 - طرابلس - 123456"
                value={driverPlate}
                onChange={(e) => setDriverPlate(e.target.value)}
                className="w-full bg-[#fbfdfb] border border-gray-300 rounded-xl p-2.5 text-xs sm:text-sm font-medium outline-none focus:ring-2 focus:ring-[#123b2c]"
              />
            </div>

            <label className="flex items-center gap-2.5 bg-emerald-50/70 p-3 rounded-xl border border-emerald-200 cursor-pointer">
              <input
                type="checkbox"
                checked={isVerified}
                onChange={(e) => setIsVerified(e.target.checked)}
                className="w-4 h-4 text-emerald-700 rounded"
              />
              <div className="text-xs">
                <span className="font-bold text-emerald-950 block">تفعيل شارة السائق الموثوق</span>
                <span className="text-gray-600">
                  إقرار بحمل رخصة قيادة نقل ثقيل وبطاقة تشغيل سارية في ليبيا
                </span>
              </div>
            </label>

            <button
              type="submit"
              className="bg-[#123b2c] hover:bg-[#1f6a4c] text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded-xl transition-all"
            >
              حفظ بيانات الشاحنة
            </button>
          </form>
        </div>
      )}

      {/* App Install Banner */}
      <div className="bg-gradient-to-r from-emerald-50 to-[#edf4ee] rounded-3xl border border-emerald-200 p-5 sm:p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#123b2c] text-[#d9f36a] flex items-center justify-center font-bold text-xl shrink-0">
            📲
          </div>
          <div>
            <h4 className="font-extrabold text-base text-gray-900 m-0">
              تنزيل التطبيق على شاشة هاتفك
            </h4>
            <p className="text-xs text-gray-600 m-0 mt-0.5">
              تثبيت مباشر وسريع على هواتف أندرويد وآيفون لفتح التطبيق بلمسة واحدة
            </p>
          </div>
        </div>

        {onOpenInstallModal && (
          <button
            onClick={onOpenInstallModal}
            className="bg-[#123b2c] hover:bg-[#1a523d] text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl transition-all shadow-xs flex items-center gap-2"
          >
            <span>عرض خطوات التنزيل والرابط 📲</span>
          </button>
        )}
      </div>

      {/* Developer & Admin Gate */}
      <div className="bg-[#121c17] text-white rounded-3xl border border-emerald-900/60 p-5 sm:p-7 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#d9f36a] text-[#123b2c] flex items-center justify-center font-black text-lg">
              ⚙️
            </div>
            <div>
              <h4 className="font-extrabold text-base text-white m-0">
                بوابة المطور والتحكم الإداري
              </h4>
              <p className="text-xs text-gray-400 m-0 mt-0.5">
                تتيح لك إدارة العمولة، الحظر، البلاغات، وإعلانات الطوارئ
              </p>
            </div>
          </div>

          {isDevUnlocked && (
            <span className="text-[11px] font-black bg-[#d9f36a] text-[#123b2c] px-3 py-1 rounded-full">
              وضع المطور نشط 👑
            </span>
          )}
        </div>

        {isDevUnlocked ? (
          <div className="pt-2 flex flex-wrap gap-2">
            <button
              onClick={onOpenDevPanel}
              className="bg-[#d9f36a] hover:bg-[#cbe65d] text-[#123b2c] font-black text-xs sm:text-sm px-5 py-2.5 rounded-xl transition-all shadow-sm flex items-center gap-2"
            >
              <span>فتح لوحة تحكم المطور الكاملة</span>
            </button>
          </div>
        ) : (
          <div className="pt-2">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setDevCodeError('');
                const success = onUnlockDevWithCode(devCodeInput);
                if (!success) {
                  setDevCodeError('الرمز السري غير صحيح. جرّب: admin777');
                } else {
                  setDevCodeInput('');
                }
              }}
              className="flex flex-col sm:flex-row gap-2"
            >
              <input
                type="password"
                placeholder="أدخل رمز المطور السري (مثال: admin777)"
                value={devCodeInput}
                onChange={(e) => setDevCodeInput(e.target.value)}
                className="bg-gray-800 border border-gray-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white outline-none focus:border-[#d9f36a] flex-1"
              />
              <button
                type="submit"
                className="bg-[#1f6a4c] hover:bg-[#288862] text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded-xl transition-all shrink-0"
              >
                تفعيل وتحكم
              </button>
            </form>
            {devCodeError && (
              <p className="text-xs text-rose-400 mt-2 font-bold m-0">{devCodeError}</p>
            )}
            <p className="text-[11px] text-gray-400 mt-2 m-0">
              * تلميح: يمكنك أيضاً كتابة الرمز <code className="text-[#d9f36a] bg-gray-800 px-1 py-0.5 rounded">admin777</code> مباشرة في شريط البحث في أي وقت، أو النقر 5 مرات على شعار التطبيق (ح).
            </p>
          </div>
        )}
      </div>

      {/* Local Storage & Device Data Controls */}
      <div className="bg-white rounded-3xl border border-gray-200/90 p-5 sm:p-7 shadow-xs space-y-4">
        <div>
          <h4 className="font-extrabold text-base text-gray-900 m-0">
            إدارة البيانات المحفوظة
          </h4>
          <p className="text-xs text-gray-500 m-0 mt-1">
            يتم تخزين إعلاناتك وإعداداتك بشكل آمن على متصفح جهازك بواسطة LocalStorage.
          </p>
        </div>

        <div className="pt-2 flex flex-wrap gap-3">
          <button
            onClick={onClearMyShipments}
            className="text-xs text-rose-700 hover:text-white hover:bg-rose-600 border border-rose-200 px-4 py-2.5 rounded-xl font-bold transition-all"
          >
            مسح إعلاناتي المحفوظة محلياً
          </button>
        </div>
      </div>
    </div>
  );
};
