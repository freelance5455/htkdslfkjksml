import React from 'react';
import { CargoCategory } from '../types/shipment';
import { Sparkles, Zap, RotateCcw } from 'lucide-react';

interface CategoryFiltersProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  selectedCity: string;
  onSelectCity: (city: string) => void;
  onlyUrgent: boolean;
  onToggleUrgent: () => void;
  onResetFilters: () => void;
  hasActiveFilters: boolean;
  cities: readonly string[];
}

const CATEGORIES: { label: string; icon: string }[] = [
  { label: 'الكل', icon: '📦' },
  { label: 'خضروات وفواكه', icon: '🥬' },
  { label: 'مواد بناء', icon: '🧱' },
  { label: 'أثاث ونقل عفش', icon: '🛋️' },
  { label: 'أجهزة كهربائية', icon: '📺' },
  { label: 'بضائع عامة', icon: '📦' },
  { label: 'معدات ثقيلة', icon: '🏗️' },
  { label: 'مستلزمات طبية', icon: '🩺' },
];

export const CategoryFilters: React.FC<CategoryFiltersProps> = ({
  selectedCategory,
  onSelectCategory,
  selectedCity,
  onSelectCity,
  onlyUrgent,
  onToggleUrgent,
  onResetFilters,
  hasActiveFilters,
  cities,
}) => {
  return (
    <div className="space-y-3">
      {/* Category horizontal scrolling pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none select-none">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat.label;
          return (
            <button
              key={cat.label}
              onClick={() => onSelectCategory(cat.label)}
              className={`shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs sm:text-sm font-semibold transition-all border shadow-xs ${
                isActive
                  ? 'bg-[#123b2c] text-white border-[#123b2c] shadow-sm'
                  : 'bg-white text-gray-700 hover:bg-gray-50 border-gray-200'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Secondary filter strip: City selector & Urgent toggle */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1">
        <div className="flex items-center gap-2">
          {/* City filter */}
          <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-xl px-3 py-1.5 text-xs text-gray-700 shadow-xs">
            <span className="text-gray-400 font-medium">المدينة:</span>
            <select
              value={selectedCity}
              onChange={(e) => onSelectCity(e.target.value)}
              aria-label="تصفية حسب المدينة"
              className="bg-transparent font-bold text-gray-800 outline-none cursor-pointer"
            >
              <option value="الكل">كل المدن</option>
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Urgent filter toggle */}
          <button
            onClick={onToggleUrgent}
            aria-pressed={onlyUrgent}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
              onlyUrgent
                ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${onlyUrgent ? 'text-white' : 'text-amber-500'}`} />
            <span>عاجل فقط</span>
          </button>
        </div>

        {hasActiveFilters && (
          <button
            onClick={onResetFilters}
            className="flex items-center gap-1 text-xs text-emerald-800 hover:text-emerald-950 font-bold px-2 py-1 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            <span>إعادة ضبط الفلاتر</span>
          </button>
        )}
      </div>
    </div>
  );
};
