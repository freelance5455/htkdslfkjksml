import React, { useState } from 'react';
import {
  ShieldCheck,
  FileText,
  AlertTriangle,
  UserCheck,
  Truck,
  Camera,
  CheckCircle2,
  Copy,
  Printer,
} from 'lucide-react';

export const SafetyGuide: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const sampleWaybill = `نموذج إشعار استلام وحمولة بضاعة (حمولة ليبيا)
-----------------------------------------------
تاريخ النقل: ..................
مدينة التحميل (الانطلاق): ..................
مدينة التسليم (الوجهة): ..................

بيانات صاحب البضاعة (المرسل):
الاسم الثلاثي: ..................
رقم الهاتف: ..................

بيانات السائق / الناقل:
الاسم الثلاثي: ..................
رقم الهوية / الجواز: ..................
رقم هاتف السائق: ..................
نوع وموديل الشاحنة: ..................
رقم لوحة الشاحنة: ..................

وصف وتفاصيل الحمولة:
نوع البضاعة: ..................
الكمية أو الوزن: ..................
الحالة عند الاستلام (سليمة / مغلفة): ..................

الأجرة المتفق عليها: .................. دينار ليبي
طريقة الدفع (عند التحميل / عند التسليم): ..................

توقيع المستلم (السائق):                      توقيع المرسل:
......................                      ......................`;

  const handleCopyWaybill = () => {
    navigator.clipboard.writeText(sampleWaybill);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Intro banner */}
      <div className="bg-gradient-to-r from-[#123b2c] to-[#1e5841] text-white rounded-3xl p-6 sm:p-7 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-2xl bg-[#d9f36a] text-[#123b2c] flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-xl sm:text-2xl font-black m-0">
            دليل الأمان والموثوقية لنقل البضائع في ليبيا 🛡️
          </h3>
        </div>
        <p className="text-emerald-100/90 text-sm leading-relaxed max-w-2xl mt-2 m-0">
          حماية بضاعتك وحقوقك تبدأ من التوثيق السليم والاتفاق المكتوب قبل انطلاق الشاحنة.
          اتبع هذه الإرشادات البسيطة لضمان رحلة نقل آمنة وسلسة بين كافة المدن.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Advice for Cargo Owners */}
        <div className="bg-white rounded-3xl border border-gray-200/90 p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-gray-100 text-[#123b2c]">
            <UserCheck className="w-5 h-5 text-emerald-700" />
            <h4 className="font-extrabold text-base sm:text-lg m-0">
              إرشادات لصاحب البضاعة (التاجر أو المواطن)
            </h4>
          </div>

          <ul className="space-y-3 text-xs sm:text-sm text-gray-700 leading-relaxed list-none p-0 m-0">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>التحقق من الهوية واللوحة:</strong> اطلب الاطلاع على رخصة القيادة وبطاقة الهوية ورقم لوحة الشاحنة وصورها بهاتفك قبل تحميل أي غرض.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <Camera className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>توثيق البضاعة بالصور:</strong> التقط صوراً واضحة للأغراض وحالتها أثناء رصها في صندوق الشاحنة لتكون مرجعاً بحال حدوث أي خدش أو كسر.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>الاتفاق على الأجرة وموعد الوصول:</strong> حدد مسبقاً المبلغ الإجمالي بالدينار الليبي، وهل يشمل عمال التحميل، وموعد التسليم المستهدف.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                <strong>عدم دفع كامل المبلغ مقدماً:</strong> ادفع جزءاً بسيطاً لتغطية وقود الطريق (إن لزم) والباقي يدفع عند الاستلام والمعاينة في مدينة الوصول.
              </span>
            </li>
          </ul>
        </div>

        {/* Advice for Drivers / Transporters */}
        <div className="bg-white rounded-3xl border border-gray-200/90 p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-gray-100 text-[#123b2c]">
            <Truck className="w-5 h-5 text-emerald-700" />
            <h4 className="font-extrabold text-base sm:text-lg m-0">
              إرشادات للسائق والناقل (أصحاب الشاحنات)
            </h4>
          </div>

          <ul className="space-y-3 text-xs sm:text-sm text-gray-700 leading-relaxed list-none p-0 m-0">
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>معاينة الحمولة قبل التحرك:</strong> لا تنقل أي صناديق مغلقة دون معرفة محتواها والتأكد من أنها مواد قانونية ومصرح بها في البوابات الأمنية.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>الربط والتغطية المحكمة:</strong> استخدم أحزمة الشد (الزناجيل/السبتات) والمشمع لحماية الأغراض من حرارة الشمس وأتربة الرياح على الطرق الصحراوية.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>التبريد للخضار واللحوم:</strong> في شاحنات البراد، تأكد من كفاءة محرك التبريد واضبط الدرجة المناسبة قبل الانطلاق وتفقدها في كل استراحة.
              </span>
            </li>
            <li className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>تحديث العميل بالمسار:</strong> إرسال رسالة عند المرور بالبوابات الرئيسية (مثل بوابة الدافنية، رأس لانوف، أجدابيا، الشويرف) يبني الثقة والتقييم العالي.
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Printable / Copyable Waybill Template */}
      <div className="bg-white rounded-3xl border border-emerald-200 p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-emerald-700" />
            <div>
              <h4 className="font-extrabold text-base sm:text-lg text-gray-900 m-0">
                نموذج بوليصة شحن وسند استلام استرشادي
              </h4>
              <p className="text-xs text-gray-500 m-0 mt-0.5">
                يمكنك نسخ هذا النموذج وكتابته باليد أو طباعته لتوقيعه بين السائق والتاجر
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyWaybill}
              className="flex items-center gap-1.5 text-xs font-bold bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100 px-3.5 py-2 rounded-xl transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'تم النسخ!' : 'نسخ النموذج'}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 text-xs font-bold bg-gray-100 text-gray-700 hover:bg-gray-200 px-3.5 py-2 rounded-xl transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة</span>
            </button>
          </div>
        </div>

        <pre className="mt-4 bg-[#f8faf8] border border-gray-200 rounded-2xl p-4 text-xs font-mono text-gray-800 whitespace-pre-wrap leading-relaxed overflow-x-auto">
          {sampleWaybill}
        </pre>
      </div>
    </div>
  );
};
