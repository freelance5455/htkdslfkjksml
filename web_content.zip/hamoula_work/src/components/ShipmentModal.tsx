import React, { useState } from 'react';
import { Shipment, UserRole } from '../types/shipment';
import {
  getLibyanDistanceKm,
  estimateFreightCost,
  formatPhoneForWhatsApp,
  isValidLibyanPhone,
} from '../utils/freight';
import {
  X,
  Phone,
  MessageCircle,
  Truck,
  Package,
  Calendar,
  Clock,
  ShieldAlert,
  Send,
  UserCheck,
  CheckCircle,
  AlertCircle,
  Flag,
} from 'lucide-react';

interface ShipmentModalProps {
  shipment: Shipment | null;
  isOpen: boolean;
  onClose: () => void;
  userRole: UserRole;
  onAddOffer: (shipmentId: number | string, offer: any) => void;
  onReport?: (shipment: Shipment) => void;
}

export const ShipmentModal: React.FC<ShipmentModalProps> = ({
  shipment,
  isOpen,
  onClose,
  userRole,
  onAddOffer,
  onReport,
}) => {
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [driverVehicle, setDriverVehicle] = useState('');
  const [offerPrice, setOfferPrice] = useState('');
  const [offerNote, setOfferNote] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [offerSuccess, setOfferSuccess] = useState(false);

  if (!isOpen || !shipment) return null;

  const distance = getLibyanDistanceKm(shipment.from, shipment.to);
  const benchmark = estimateFreightCost(shipment.from, shipment.to, shipment.vehicle, shipment.isUrgent);
  const waNumber = formatPhoneForWhatsApp(shipment.phone);
  const waMessage = encodeURIComponent(
    `السلام عليكم، أتواصل معك بخصوص إعلان حمولة من ${shipment.from} إلى ${shipment.to} (${shipment.type}) المنشور على تطبيق حمولة ليبيا.`
  );

  const handleSubmitOffer = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!driverName.trim()) {
      setErrorMsg('الرجاء كتابة اسم السائق أو شركة النقل');
      return;
    }
    if (!isValidLibyanPhone(driverPhone)) {
      setErrorMsg('الرجاء إدخال رقم هاتف ليبي صحيح (مثال: 0912345678)');
      return;
    }
    const priceNum = Number(offerPrice);
    if (!priceNum || priceNum <= 0) {
      setErrorMsg('الرجاء إدخال قيمة عرض سعر صحيحة بالدينار الليبي');
      return;
    }

    const newOffer = {
      id: `off-${Date.now()}`,
      driverName: driverName.trim(),
      driverPhone: driverPhone.trim(),
      vehicle: driverVehicle.trim() || shipment.vehicle,
      price: priceNum,
      note: offerNote.trim(),
      createdAt: 'الآن',
    };

    onAddOffer(shipment.id, newOffer);
    setOfferSuccess(true);
    setTimeout(() => {
      setOfferSuccess(false);
      setOfferPrice('');
      setOfferNote('');
    }, 2500);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modalTitle"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150"
    >
      <div
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col overflow-hidden border border-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#123b2c] text-white p-5 flex items-center justify-between shrink-0">
          <div>
            <div className="text-xs text-[#d9f36a] font-bold">تفاصيل الحمولة والمسار</div>
            <h3 id="modalTitle" className="text-xl font-extrabold mt-0.5">
              من {shipment.from} إلى {shipment.to}
            </h3>
          </div>
          <button
            onClick={onClose}
            aria-label="إغلاق النافذة"
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-sm text-gray-800">
          {/* Route & Distance Banner */}
          <div className="bg-emerald-50/70 border border-emerald-100 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <div className="text-xs text-emerald-800 font-semibold">المسافة المقدرة عبر الطريق</div>
              <div className="text-xl font-black text-[#123b2c]">
                {distance > 0 ? `${distance} كم` : 'داخل المدينة'}
              </div>
            </div>
            {benchmark.travelHours > 0 && (
              <div className="text-left">
                <div className="text-xs text-emerald-800 font-semibold">وقت القيادة للشاحنات</div>
                <div className="text-sm font-bold text-emerald-950 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>حوالي {benchmark.travelHours} ساعة</span>
                </div>
              </div>
            )}
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-3 bg-gray-50 p-4 rounded-2xl border border-gray-100">
            <div>
              <span className="text-xs text-gray-500 block">نوع الحمولة</span>
              <strong className="text-gray-900 font-bold">{shipment.type}</strong>
            </div>
            <div>
              <span className="text-xs text-gray-500 block">الشاحنة المطلوبة</span>
              <strong className="text-gray-900 font-bold">{shipment.vehicle}</strong>
            </div>
            <div>
              <span className="text-xs text-gray-500 block">الكمية أو الوزن</span>
              <strong className="text-gray-900 font-bold">{shipment.weight}</strong>
            </div>
            <div>
              <span className="text-xs text-gray-500 block">موعد التحميل</span>
              <strong className="text-gray-900 font-bold">{shipment.date || 'جاهز للتحميل'}</strong>
            </div>
            <div>
              <span className="text-xs text-gray-500 block">الأجرة المقترحة</span>
              <strong className="text-lg font-black text-[#123b2c]">
                {shipment.price ? `${shipment.price} د.ل` : 'قابل للتفاوض'}
              </strong>
            </div>
            <div>
              <span className="text-xs text-gray-500 block">عمال للمساعدة في التحميل</span>
              <strong className="text-gray-900 font-bold">
                {shipment.requiresLabor ? 'نعم مطلوب عمال' : 'غير مطلوب'}
              </strong>
            </div>
          </div>

          {/* Additional notes */}
          {shipment.details && (
            <div className="bg-white border border-gray-200 rounded-2xl p-3.5">
              <span className="text-xs text-gray-500 block mb-1 font-semibold">
                ملاحظات وتفاصيل إضافية من صاحب البضاعة:
              </span>
              <p className="text-gray-800 text-sm leading-relaxed whitespace-pre-wrap m-0">
                {shipment.details}
              </p>
            </div>
          )}

          {/* Safety Notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-xs text-amber-900 flex items-start justify-between gap-2.5">
            <div className="flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>نصيحة أمان:</strong> تأكد من فحص هوية السائق ورقم اللوحة، وتوثيق استلام البضاعة كتابياً (بوليصة شحن أو وصل استلام) قبل الانطلاق.
              </div>
            </div>
            {onReport && (
              <button
                type="button"
                onClick={() => onReport(shipment)}
                className="text-[11px] font-bold text-rose-700 hover:text-rose-900 bg-white border border-rose-200 hover:bg-rose-50 px-2.5 py-1 rounded-xl shrink-0 flex items-center gap-1 transition-colors"
              >
                <Flag className="w-3 h-3" />
                <span>إبلاغ</span>
              </button>
            )}
          </div>

          {/* Contact actions */}
          {shipment.demo ? (
            <div className="p-3 bg-gray-100 rounded-2xl text-center text-xs text-gray-600">
              هذا إعلان تجريبي استرشادي لعرض آلية العمل في حمولة ليبيا.
            </div>
          ) : (
            <div className="space-y-2">
              <div className="text-xs font-bold text-gray-700">التواصل المباشر مع صاحب البضاعة:</div>
              <div className="grid grid-cols-2 gap-2.5">
                <a
                  href={`tel:${shipment.phone}`}
                  className="flex items-center justify-center gap-2 bg-[#123b2c] hover:bg-[#1a523d] text-white py-3 px-4 rounded-2xl font-bold transition-all shadow-sm"
                >
                  <Phone className="w-4 h-4" />
                  <span>اتصال ({shipment.phone})</span>
                </a>
                <a
                  href={`https://wa.me/${waNumber}?text=${waMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20ba5a] text-white py-3 px-4 rounded-2xl font-bold transition-all shadow-sm"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>محادثة واتساب</span>
                </a>
              </div>
            </div>
          )}

          {/* Driver Offer Submission Form (if in driver mode or want to bid) */}
          <div className="border-t border-gray-200 pt-4 mt-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-sm text-[#123b2c] flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-emerald-700" />
                <span>تقديم عرض سعر كسائق أو ناقل</span>
              </h4>
              <span className="text-xs text-gray-500">مباشر لصاحب الإعلان</span>
            </div>

            {offerSuccess ? (
              <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl p-3 text-xs flex items-center gap-2 font-bold animate-in fade-in">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>تم إرسال عرض سعرك بنجاح وتم تسجيله!</span>
              </div>
            ) : (
              <form onSubmit={handleSubmitOffer} className="space-y-2.5 bg-gray-50 p-3.5 rounded-2xl border border-gray-200">
                {errorMsg && (
                  <div className="text-xs text-rose-700 font-bold flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errorMsg}</span>
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="اسم السائق أو الشركة"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-xs outline-none focus:border-emerald-700"
                    required
                  />
                  <input
                    type="tel"
                    placeholder="رقم الهاتف (مثال: 0912345678)"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    className="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-xs outline-none focus:border-emerald-700"
                    required
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="نوع وموديل شاحنتك"
                    value={driverVehicle}
                    onChange={(e) => setDriverVehicle(e.target.value)}
                    className="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-xs outline-none focus:border-emerald-700"
                  />
                  <input
                    type="number"
                    placeholder="عرض سعرك المقترح (د.ل)"
                    value={offerPrice}
                    onChange={(e) => setOfferPrice(e.target.value)}
                    min="1"
                    className="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-xs font-bold outline-none focus:border-emerald-700"
                    required
                  />
                </div>
                <input
                  type="text"
                  placeholder="ملاحظة (مثال: جاهز للتحميل غداً 9 صباحاً، الشاحنة مجهزة برباطات)"
                  value={offerNote}
                  onChange={(e) => setOfferNote(e.target.value)}
                  className="w-full bg-white border border-gray-300 rounded-xl px-3 py-2 text-xs outline-none focus:border-emerald-700"
                />
                <button
                  type="submit"
                  className="w-full bg-[#123b2c] hover:bg-[#1f6a4c] text-white font-bold py-2 px-3 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Send className="w-3.5 h-3.5 text-[#d9f36a]" />
                  <span>تأكيد وإرسال عرض السعر</span>
                </button>
              </form>
            )}
          </div>

          {/* Existing Offers List */}
          {shipment.offers && shipment.offers.length > 0 && (
            <div className="border-t border-gray-200 pt-3">
              <h4 className="font-bold text-xs text-gray-700 mb-2">
                العروض المقدمة على هذه الحمولة ({shipment.offers.length}):
              </h4>
              <div className="space-y-2">
                {shipment.offers.map((offer) => (
                  <div
                    key={offer.id}
                    className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-2.5 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-gray-900 flex items-center gap-1.5">
                        <UserCheck className="w-3 h-3 text-emerald-700" />
                        <span>{offer.driverName}</span>
                        {offer.vehicle && (
                          <span className="text-gray-500 font-normal">({offer.vehicle})</span>
                        )}
                      </div>
                      {offer.note && <p className="text-gray-600 text-[11px] mt-0.5 m-0">{offer.note}</p>}
                    </div>
                    <div className="text-left shrink-0">
                      <span className="font-extrabold text-sm text-[#123b2c] block">
                        {offer.price} د.ل
                      </span>
                      <span className="text-[10px] text-gray-400">{offer.createdAt}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
