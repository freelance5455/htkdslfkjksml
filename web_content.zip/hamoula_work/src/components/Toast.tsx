import React from 'react';

interface ToastProps {
  message: string | null;
  type?: 'success' | 'info' | 'error';
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type = 'success', onClose }) => {
  if (!message) return null;

  const bg =
    type === 'error'
      ? 'bg-rose-700 text-white'
      : type === 'info'
      ? 'bg-emerald-900 text-white'
      : 'bg-[#17231d] text-white';

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 max-w-[92vw] sm:max-w-md w-auto"
    >
      <div
        className={`${bg} shadow-xl border border-white/10 rounded-2xl px-5 py-3.5 flex items-center gap-3 text-sm font-medium transition-all animate-in fade-in duration-200`}
      >
        <span className="text-base">
          {type === 'error' ? '⚠️' : type === 'info' ? 'ℹ️' : '✅'}
        </span>
        <span className="flex-1">{message}</span>
        <button
          onClick={onClose}
          aria-label="إغلاق التنبيه"
          className="text-white/60 hover:text-white p-1 text-xs rounded"
        >
          ✕
        </button>
      </div>
    </div>
  );
};
