import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  Smartphone,
  Share2,
  Copy,
  Check,
  ExternalLink,
  Apple,
  Chrome,
  ArrowRight,
} from 'lucide-react';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [activeDeviceTab, setActiveDeviceTab] = useState<'android' | 'iphone'>('android');

  // Detect user agent for auto device tab selection
  useEffect(() => {
    const isIOS = /iphone|ipad|ipod/.test(navigator.userAgent.toLowerCase());
    if (isIOS) {
      setActiveDeviceTab('iphone');
    }

    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  if (!isOpen) return null;

  // The application shared URL
  const appUrl = window.location.origin;

  const handleNativeInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDeferredPrompt(null);
        onClose();
      }
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="installModalTitle"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150"
    >
      <div
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col overflow-hidden border border-gray-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#123b2c] to-[#1c553f] text-white p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#d9f36a] text-[#123b2c] flex items-center justify-center font-black text-xl shadow-md">
              📲
            </div>
            <div>
              <h3 id="installModalTitle" className="text-lg sm:text-xl font-black m-0 text-white">
                تنزيل وتثبيت التطبيق على هاتفك
              </h3>
              <p className="text-xs text-emerald-100/80 m-0">
                يعمل كتطبيق كامل وسريع بدون الحاجة لمتجر تطبيقات
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="إغلاق النافذة"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm text-gray-800">
          {/* Native Browser Install Prompt if available */}
          {deferredPrompt && (
            <div className="bg-gradient-to-r from-emerald-50 to-[#edf4ee] border border-emerald-300 rounded-2xl p-4 text-center space-y-2.5">
              <span className="text-xs font-bold text-emerald-900 block">
                متصفحك يدعم التثبيت المباشر بنقرة واحدة!
              </span>
              <button
                onClick={handleNativeInstall}
                className="w-full bg-[#123b2c] hover:bg-[#1a523d] text-white py-3 px-4 rounded-xl font-black text-sm flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <Download className="w-4 h-4 text-[#d9f36a]" />
                <span>تثبيت التطبيق على الهاتف الآن</span>
              </button>
            </div>
          )}

          {/* Device Tabs: Android vs iPhone */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-gray-700">اختر نوع هاتفك للخطوات:</span>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-gray-100 p-1 rounded-2xl">
              <button
                onClick={() => setActiveDeviceTab('android')}
                className={`py-2 px-3 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 transition-all ${
                  activeDeviceTab === 'android'
                    ? 'bg-white text-[#123b2c] shadow-xs'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Chrome className="w-4 h-4 text-emerald-700" />
                <span>هواتف أندرويد (سامسونج / ردمي...)</span>
              </button>

              <button
                onClick={() => setActiveDeviceTab('iphone')}
                className={`py-2 px-3 rounded-xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 transition-all ${
                  activeDeviceTab === 'iphone'
                    ? 'bg-white text-[#123b2c] shadow-xs'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Apple className="w-4 h-4 text-gray-900" />
                <span>هواتف آيفون (iPhone / iPad)</span>
              </button>
            </div>
          </div>

          {/* Android Steps */}
          {activeDeviceTab === 'android' && (
            <div className="bg-[#f8faf8] border border-gray-200 rounded-2xl p-4 space-y-3">
              <h4 className="font-bold text-xs sm:text-sm text-gray-900 flex items-center gap-2 m-0">
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">
                  ✓
                </span>
                <span>خطوات التثبيت على نظام أندرويد (متصفح Chrome):</span>
              </h4>

              <ol className="text-xs sm:text-sm text-gray-700 space-y-2.5 pr-4 m-0 leading-relaxed list-decimal">
                <li>
                  افتح الرابط في متصفح <strong>Google Chrome</strong> على هاتفك.
                </li>
                <li>
                  اضغط على أيقونة <strong>الخيارات (الثلاث نقاط ⋮)</strong> في أعلى أو أسفل يمين الشاشة.
                </li>
                <li>
                  اختر من القائمة: <strong>«تثبيت التطبيق»</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong> (Install App).
                </li>
                <li>
                  اضغط <strong>«تثبيت»</strong> وسينزل التطبيق على شاشة هاتفك الرئيسية فوراً كأيقونة مستقلة سريعة!
                </li>
              </ol>
            </div>
          )}

          {/* iPhone Steps */}
          {activeDeviceTab === 'iphone' && (
            <div className="bg-[#f8faf8] border border-gray-200 rounded-2xl p-4 space-y-3">
              <h4 className="font-bold text-xs sm:text-sm text-gray-900 flex items-center gap-2 m-0">
                <span className="w-5 h-5 rounded-full bg-gray-900 text-white flex items-center justify-center text-xs">
                  ✓
                </span>
                <span>خطوات التثبيت على هواتف iPhone (متصفح Safari):</span>
              </h4>

              <ol className="text-xs sm:text-sm text-gray-700 space-y-2.5 pr-4 m-0 leading-relaxed list-decimal">
                <li>
                  افتح الرابط في متصفح <strong>Safari</strong> الأساسي في الآيفون.
                </li>
                <li>
                  اضغط على زر <strong>المشاركة ⎋</strong> (أيقونة المربع التي يخرج منها سهم للأعلى في أسفل الشاشة).
                </li>
                <li>
                  مرر للأسفل واضغط على: <strong>«إضافة إلى الشاشة الرئيسية» (Add to Home Screen)</strong>.
                </li>
                <li>
                  اضغط على <strong>«إضافة» (Add)</strong> في أعلى اليمين، وسيظهر التطبيق على شاشة هاتفك مباشرة كأي تطبيق نظام!
                </li>
              </ol>
            </div>
          )}

          {/* Share & Copy Link Section */}
          <div className="border-t border-gray-200 pt-4 space-y-3">
            <span className="text-xs font-bold text-gray-700 block">
              رابط المنصة المباشر للمشاركة مع السائقين وأصحاب البضائع:
            </span>

            <div className="flex items-center gap-2 bg-gray-50 p-2 rounded-2xl border border-gray-200">
              <input
                type="text"
                readOnly
                value={appUrl}
                className="flex-1 bg-transparent text-xs text-gray-800 font-mono px-2 outline-none select-all"
              />
              <button
                onClick={handleCopyLink}
                className="bg-[#123b2c] hover:bg-[#1a523d] text-white text-xs font-bold py-1.5 px-3 rounded-xl flex items-center gap-1.5 transition-colors shrink-0"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-[#d9f36a]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isCopied ? 'تم النسخ!' : 'نسخ الرابط'}</span>
              </button>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <a
                href={`https://wa.me/?text=${encodeURIComponent('تطبيق حمولة ليبيا لنقل وشحن البضائع بين المدن: ' + appUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-[#25D366] hover:bg-[#20ba5a] text-white text-xs font-bold py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-colors text-center"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>مشاركة الرابط عبر الواتساب</span>
              </a>

              <a
                href="/hamoula-libya-project.zip"
                download="hamoula-libya-project.zip"
                className="bg-gray-900 hover:bg-black text-[#d9f36a] text-xs font-black py-2.5 px-3.5 rounded-xl flex items-center justify-center gap-1.5 transition-colors text-center shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تحميل المشروع كاملاً (ZIP)</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
