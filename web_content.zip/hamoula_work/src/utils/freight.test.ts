import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getLibyanDistanceKm,
  estimateFreightCost,
  isValidLibyanPhone,
  formatPhoneForWhatsApp,
  filterShipments,
  INITIAL_DEMO_SHIPMENTS,
} from './freight';

test('getLibyanDistanceKm returns expected distance between major cities', () => {
  assert.equal(getLibyanDistanceKm('طرابلس', 'بنغازي'), 1020);
  assert.equal(getLibyanDistanceKm('طرابلس', 'مصراتة'), 210);
  assert.equal(getLibyanDistanceKm('بنغازي', 'طبرق'), 470);
  assert.equal(getLibyanDistanceKm('طرابلس', 'طرابلس'), 0);
  assert.equal(getLibyanDistanceKm('', 'بنغازي'), 0);
});

test('estimateFreightCost provides valid price and travel hours', () => {
  const result = estimateFreightCost('طرابلس', 'مصراتة', 'شاحنة كبيرة (تريلا)', false);
  assert.ok(result.distanceKm > 200);
  assert.ok(result.travelHours > 2);
  assert.ok(result.averagePrice > 300);
  assert.ok(result.minPrice <= result.maxPrice);

  // Urgent shipment cost should be higher than normal
  const normal = estimateFreightCost('طرابلس', 'بنغازي', 'شاحنة متوسطة', false);
  const urgent = estimateFreightCost('طرابلس', 'بنغازي', 'شاحنة متوسطة', true);
  assert.ok(urgent.averagePrice > normal.averagePrice);
});

test('isValidLibyanPhone validates Libyan phone numbers correctly', () => {
  assert.equal(isValidLibyanPhone('0912345678'), true);
  assert.equal(isValidLibyanPhone('0923456789'), true);
  assert.equal(isValidLibyanPhone('0945678901'), true);
  assert.equal(isValidLibyanPhone('+218912345678'), true);
  assert.equal(isValidLibyanPhone('00218921112233'), true);
  assert.equal(isValidLibyanPhone('091 234 5678'), true);

  // Invalid formats
  assert.equal(isValidLibyanPhone('12345'), false);
  assert.equal(isValidLibyanPhone('0812345678'), false); // 08 is not a Libyan mobile code
  assert.equal(isValidLibyanPhone('abcdefghijk'), false);
  assert.equal(isValidLibyanPhone(''), false);
});

test('formatPhoneForWhatsApp formats properly for wa.me links', () => {
  assert.equal(formatPhoneForWhatsApp('0912345678'), '218912345678');
  assert.equal(formatPhoneForWhatsApp('+218921234567'), '218921234567');
  assert.equal(formatPhoneForWhatsApp('00218941234567'), '218941234567');
});

test('filterShipments filters by category, keyword, and city', () => {
  const sample = INITIAL_DEMO_SHIPMENTS;

  // Filter by category
  const veg = filterShipments(sample, { category: 'خضروات وفواكه' });
  assert.equal(veg.length, 1);
  assert.equal(veg[0].from, 'سبها');

  // Filter by search query
  const misrata = filterShipments(sample, { query: 'مصراتة' });
  assert.ok(misrata.length >= 2);

  // Filter by urgency
  const urgentOnly = filterShipments(sample, { onlyUrgent: true });
  assert.ok(urgentOnly.every((s) => s.isUrgent));

  // Reset to all
  const all = filterShipments(sample, { category: 'الكل' });
  assert.equal(all.length, sample.length);
});
