import { Shipment, CargoCategory, VehicleCategory } from '../types/shipment';

export const LIBYAN_CITIES = [
  'طرابلس',
  'بنغازي',
  'مصراتة',
  'الزاوية',
  'سبها',
  'البيضاء',
  'طبرق',
  'زليتن',
  'الخمس',
  'سرت',
  'غريان',
  'أجدابيا',
  'درنة',
  'الكفرة',
  'غدامس',
  'ترهونة',
  'صبراتة',
  'زوارة',
  'بني وليد',
  'نالوت',
  'صرمان',
  'شحات',
  'المرج',
  'الجفرة (هون)',
  'غات',
] as const;

// Approximate road distances between major Libyan transportation hubs in kilometers
const CITY_ROAD_DISTANCES: Record<string, Record<string, number>> = {
  'طرابلس': {
    'بنغازي': 1020,
    'مصراتة': 210,
    'الزاوية': 45,
    'سبها': 770,
    'البيضاء': 1220,
    'طبرق': 1480,
    'زليتن': 155,
    'الخمس': 120,
    'سرت': 450,
    'غريان': 85,
    'أجدابيا': 860,
    'درنة': 1300,
    'الكفرة': 1780,
    'غدامس': 590,
    'ترهونة': 80,
    'صبراتة': 70,
    'زوارة': 110,
    'بني وليد': 180,
    'نالوت': 280,
  },
  'مصراتة': {
    'بنغازي': 810,
    'سبها': 660,
    'سرت': 240,
    'أجدابيا': 650,
    'الزاوية': 255,
    'زليتن': 55,
    'الخمس': 90,
    'طبرق': 1270,
    'البيضاء': 1010,
    'درنة': 1090,
  },
  'بنغازي': {
    'البيضاء': 200,
    'طبرق': 470,
    'أجدابيا': 160,
    'درنة': 280,
    'الكفرة': 930,
    'سرت': 570,
    'سبها': 1100,
    'المرج': 100,
    'شحات': 220,
  },
  'سبها': {
    'أجدابيا': 920,
    'الكفرة': 1250,
    'الجفرة (هون)': 340,
    'غات': 560,
    'سرت': 580,
  },
};

/**
 * Calculates road distance between two Libyan cities (in kilometers).
 */
export function getLibyanDistanceKm(fromCity: string, toCity: string): number {
  const c1 = fromCity.trim();
  const c2 = toCity.trim();

  if (!c1 || !c2 || c1 === c2) return 0;

  // Direct lookup
  if (CITY_ROAD_DISTANCES[c1]?.[c2]) return CITY_ROAD_DISTANCES[c1][c2];
  if (CITY_ROAD_DISTANCES[c2]?.[c1]) return CITY_ROAD_DISTANCES[c2][c1];

  // Hub-and-spoke via Tripoli or Benghazi
  const viaTripoli1 = CITY_ROAD_DISTANCES['طرابلس']?.[c1] || 150;
  const viaTripoli2 = CITY_ROAD_DISTANCES['طرابلس']?.[c2] || 150;
  if (CITY_ROAD_DISTANCES['طرابلس']?.[c1] && CITY_ROAD_DISTANCES['طرابلس']?.[c2]) {
    // If on same side of Tripoli vs different sides
    return Math.abs(viaTripoli1 - viaTripoli2) > 0 ? Math.abs(viaTripoli1 - viaTripoli2) + 40 : 120;
  }

  // Default fallback estimation based on general Libyan geography
  return 350;
}

/**
 * Calculates estimated freight cost (in Libyan Dinars - LYD) and road duration.
 */
export function estimateFreightCost(
  fromCity: string,
  toCity: string,
  vehicle: string,
  isUrgent: boolean = false
): {
  distanceKm: number;
  travelHours: number;
  minPrice: number;
  maxPrice: number;
  averagePrice: number;
} {
  const distanceKm = getLibyanDistanceKm(fromCity, toCity);
  if (distanceKm === 0) {
    return { distanceKm: 0, travelHours: 0, minPrice: 0, maxPrice: 0, averagePrice: 0 };
  }

  // Driving time for commercial heavy vehicles average 70 km/h with checkpoint stops
  const travelHours = Math.max(1, Math.round((distanceKm / 65) * 10) / 10);

  // Multiplier by vehicle type
  let baseRatePerKm = 1.35; // LYD per km for small trucks
  if (vehicle.includes('متوسطة')) {
    baseRatePerKm = 1.85;
  } else if (vehicle.includes('كبيرة') || vehicle.includes('تريلا')) {
    baseRatePerKm = 2.4;
  } else if (vehicle.includes('براد')) {
    baseRatePerKm = 2.8; // refrigeration fuel costs
  } else if (vehicle.includes('سطحة')) {
    baseRatePerKm = 1.95;
  } else if (vehicle.includes('قاطرة') || vehicle.includes('حاوية')) {
    baseRatePerKm = 2.7;
  } else if (vehicle.includes('صهريج')) {
    baseRatePerKm = 2.5;
  }

  let basePrice = distanceKm * baseRatePerKm;
  // minimum haul fee in Libya
  if (basePrice < 150) basePrice = 150;

  if (isUrgent) {
    basePrice *= 1.25;
  }

  const minPrice = Math.round(basePrice * 0.88 / 25) * 25;
  const maxPrice = Math.round(basePrice * 1.18 / 25) * 25;
  const averagePrice = Math.round((minPrice + maxPrice) / 2 / 10) * 10;

  return {
    distanceKm,
    travelHours,
    minPrice,
    maxPrice,
    averagePrice,
  };
}

/**
 * Validates Libyan phone numbers:
 * Supports formats like 091xxxxxxx, 092xxxxxxx, 094xxxxxxx, 093xxxxxxx, 095xxxxxxx,
 * +21891xxxxxxx, 0021891xxxxxxx, or numbers with spaces/dashes.
 */
export function isValidLibyanPhone(phone: string): boolean {
  if (!phone) return false;
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  // Matches Libyan mobile numbers
  // 09[1-6] followed by 7 digits
  // or +2189[1-6] or 002189[1-6] or 2189[1-6] followed by 7 digits
  const localRegex = /^09[1-6]\d{7}$/;
  const intlRegex = /^(\+218|00218|218)9[1-6]\d{7}$/;
  const generalLibyan = /^((\+218|00218|218)?0?9[1-6]\d{7})$/;

  return localRegex.test(cleaned) || intlRegex.test(cleaned) || generalLibyan.test(cleaned);
}

/**
 * Standardizes a Libyan phone into international format for WhatsApp links (e.g., 21891xxxxxxx).
 */
export function formatPhoneForWhatsApp(phone: string): string {
  const digits = phone.replace(/[^\d+]/g, '');
  if (digits.startsWith('+218')) {
    return digits.slice(1);
  }
  if (digits.startsWith('00218')) {
    return digits.slice(2);
  }
  if (digits.startsWith('218')) {
    return digits;
  }
  if (digits.startsWith('09')) {
    return '218' + digits.slice(1);
  }
  if (digits.startsWith('9') && digits.length === 9) {
    return '218' + digits;
  }
  return digits;
}

/**
 * Pure filter function for shipments.
 */
export function filterShipments(
  shipments: Shipment[],
  filters: {
    query?: string;
    category?: string;
    vehicle?: string;
    fromCity?: string;
    toCity?: string;
    onlyUrgent?: boolean;
  }
): Shipment[] {
  const { query, category, vehicle, fromCity, toCity, onlyUrgent } = filters;
  const q = (query || '').trim().toLowerCase();

  return shipments.filter((item) => {
    if (category && category !== 'الكل' && item.type !== category) {
      return false;
    }
    if (vehicle && vehicle !== 'الكل' && item.vehicle !== vehicle) {
      return false;
    }
    if (fromCity && fromCity !== 'الكل' && item.from !== fromCity) {
      return false;
    }
    if (toCity && toCity !== 'الكل' && item.to !== toCity) {
      return false;
    }
    if (onlyUrgent && !item.isUrgent) {
      return false;
    }
    if (q) {
      const matchString = `${item.from} ${item.to} ${item.type} ${item.vehicle} ${item.weight} ${item.details || ''} ${item.price}`.toLowerCase();
      if (!matchString.includes(q)) {
        return false;
      }
    }
    return true;
  });
}

export const INITIAL_DEMO_SHIPMENTS: Shipment[] = [
  {
    id: 101,
    type: 'مواد بناء',
    vehicle: 'شاحنة كبيرة (تريلا)',
    from: 'طرابلس',
    to: 'مصراتة',
    weight: '12 طن أسمنت ومواد عزل',
    date: '2026-11-02',
    price: 850,
    phone: '0912345678',
    details: 'البضاعة مغلفة بالكامل على طبالي جاهزة للرفع بواسطة رافعة شوكية.',
    requiresLabor: false,
    isUrgent: false,
    demo: true,
    status: 'active',
    createdAt: 'منذ ساعتين',
    offers: [
      {
        id: 'off-1',
        driverName: 'أسامة الورفلي',
        driverPhone: '0925551234',
        vehicle: 'تريلا مرسيدس أكتروس',
        price: 800,
        note: 'جاهز للتحميل غداً صباحاً 8:00',
        createdAt: 'منذ 30 دقيقة',
      },
    ],
  },
  {
    id: 102,
    type: 'خضروات وفواكه',
    vehicle: 'براد تبريد (لحوم / خضار)',
    from: 'سبها',
    to: 'طرابلس',
    weight: '4 طن تمور وخضروات مزارع',
    date: '2026-11-03',
    price: 1350,
    phone: '0923456789',
    details: 'درجة حرارة البراد مطلوبة 4 درجات مئوية طوال الرحلة لضمان الجودة.',
    requiresLabor: true,
    isUrgent: true,
    demo: true,
    status: 'active',
    createdAt: 'منذ 3 ساعات',
    offers: [],
  },
  {
    id: 103,
    type: 'أثاث ونقل عفش',
    vehicle: 'سيارة نقل صغيرة (وانيت / كانتر)',
    from: 'بنغازي',
    to: 'البيضاء',
    weight: 'عفش شقة (غرفة نوم + صالون)',
    date: '2026-11-05',
    price: 450,
    phone: '0945678901',
    details: 'الأثاث مغلف بالنايلون والكرتون، مطلوب سائق معه عامل تحميل إضافي.',
    requiresLabor: true,
    isUrgent: false,
    demo: true,
    status: 'active',
    createdAt: 'منذ 5 ساعات',
    offers: [],
  },
  {
    id: 104,
    type: 'بضائع عامة',
    vehicle: 'قاطرة ومقطورة',
    from: 'مصراتة',
    to: 'أجدابيا',
    weight: '18 طن سيراميك ورخام',
    date: '2026-11-06',
    price: 1900,
    phone: '0917654321',
    details: 'خروج من المنطقة الحرة بمصراتة، الأوراق الجمركية جاهزة بالكامل.',
    requiresLabor: false,
    isUrgent: false,
    demo: true,
    status: 'active',
    createdAt: 'اليوم',
    offers: [
      {
        id: 'off-2',
        driverName: 'عمر المجبري',
        driverPhone: '0919988776',
        vehicle: 'قاطرة فولفو FH',
        price: 1850,
        note: 'متواجد في مصراتة وجاهز فوراً',
        createdAt: 'منذ ساعة',
      },
    ],
  },
  {
    id: 105,
    type: 'أجهزة كهربائية',
    vehicle: 'شاحنة متوسطة (إيفيكو / مرسيدس)',
    from: 'طرابلس',
    to: 'الزاوية',
    weight: '35 كرتونة مكيفات وثلاجات',
    date: '2026-11-04',
    price: 300,
    phone: '0934567890',
    details: 'أجهزة حساسة تحتاج شاحنة مغلقة ونقل حذر.',
    requiresLabor: true,
    isUrgent: true,
    demo: true,
    status: 'active',
    createdAt: 'اليوم',
    offers: [],
  },
  {
    id: 106,
    type: 'معدات ثقيلة',
    vehicle: 'سطحة لنقل السيارات',
    from: 'بنغازي',
    to: 'طبرق',
    weight: 'رافعة شوكية 4 طن',
    date: '2026-11-07',
    price: 1100,
    phone: '0928877665',
    details: 'نقل ونش شوكي من ميناء بنغازي إلى مخازن طبرق، مطلوب سلاسل ربط قوية.',
    requiresLabor: false,
    isUrgent: false,
    demo: true,
    status: 'active',
    createdAt: 'أمس',
    offers: [],
  },
];
