import { AdminSettings, ShipmentReport, BannedEntity } from '../types/admin';

export const SECRET_DEV_CODES = [
  'admin777',
  'devlibya',
  'hamoula-dev',
  'مطور-ليبيا',
  '777',
] as const;

export const DEFAULT_ADMIN_SETTINGS: AdminSettings = {
  commissionActive: false, // 0% promotional default
  commissionRate: 2.5, // 2.5% when enabled
  baseRateMultiplier: 1.0,
  minHaulFee: 150,
  broadcastNotice: 'تنبيه أمني: يُرجى من كافة السائقين التأكد من أوراق الحمولات الرسمية عند البوابات.',
  isBroadcastActive: false,
};

export const INITIAL_SAMPLE_REPORTS: ShipmentReport[] = [
  {
    id: 'rep-1',
    shipmentId: 104,
    shipmentTitle: 'مصراتة ← أجدابيا (18 طن سيراميك)',
    reportedPhone: '0917654321',
    reason: 'الرقم مغلق ولا يرد على المكالمات عند الاتفاق على التحميل',
    reporterPhone: '0921112233',
    timestamp: 'اليوم 14:30',
    status: 'pending',
  },
  {
    id: 'rep-2',
    shipmentId: 105,
    shipmentTitle: 'طرابلس ← الزاوية (أجهزة كهربائية)',
    reportedPhone: '0934567890',
    reason: 'اشتباه بطلب وسيط مالي غير رسمي خارج المنصة',
    reporterPhone: '0945556677',
    timestamp: 'أمس 18:20',
    status: 'reviewed',
  },
];

export const INITIAL_BANNED_ENTITIES: BannedEntity[] = [
  {
    id: 'ban-1',
    phone: '0910009999',
    name: 'سائق غير ملتزم (رقم وهمي)',
    reason: 'تكرار إلغاء الرحلات بعد الاتفاق وطلب دفع مالي مسبق',
    bannedAt: '2026-10-15',
  },
  {
    id: 'ban-2',
    phone: '0928887777',
    name: 'حساب إعلانات وهمية',
    reason: 'نشر حمولات وهمية متكررة دون بضاعة حقيقية',
    bannedAt: '2026-10-20',
  },
];

/**
 * Checks whether an input string matches any secret developer access code.
 */
export function isSecretDevCode(code: string): boolean {
  if (!code) return false;
  const clean = code.trim().toLowerCase();
  return (
    SECRET_DEV_CODES.some((secret) => secret.toLowerCase() === clean) ||
    clean === 'admin777' ||
    clean === 'devlibya'
  );
}

/**
 * Calculates platform commission in Libyan Dinars.
 */
export function calculateCommission(
  price: number,
  settings: AdminSettings
): {
  isCommissionActive: boolean;
  commissionRate: number;
  commissionAmount: number;
  netToDriver: number;
} {
  if (!settings.commissionActive || settings.commissionRate <= 0 || price <= 0) {
    return {
      isCommissionActive: false,
      commissionRate: 0,
      commissionAmount: 0,
      netToDriver: price,
    };
  }

  const commissionAmount = Math.round((price * (settings.commissionRate / 100)) * 10) / 10;
  const netToDriver = Math.max(0, price - commissionAmount);

  return {
    isCommissionActive: true,
    commissionRate: settings.commissionRate,
    commissionAmount,
    netToDriver,
  };
}

/**
 * Checks if a given phone number is currently in the banned blacklist.
 */
export function isPhoneBanned(phone: string, bannedList: BannedEntity[]): boolean {
  if (!phone) return false;
  const cleaned = phone.replace(/[\s\-\(\)\+]/g, '');
  return bannedList.some((item) => {
    const itemCleaned = item.phone.replace(/[\s\-\(\)\+]/g, '');
    return (
      itemCleaned === cleaned ||
      (cleaned.length >= 8 && itemCleaned.includes(cleaned)) ||
      (itemCleaned.length >= 8 && cleaned.includes(itemCleaned))
    );
  });
}
