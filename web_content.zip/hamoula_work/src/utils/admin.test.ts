import test from 'node:test';
import assert from 'node:assert/strict';
import {
  isSecretDevCode,
  calculateCommission,
  isPhoneBanned,
  DEFAULT_ADMIN_SETTINGS,
  INITIAL_BANNED_ENTITIES,
} from './admin';

test('isSecretDevCode identifies valid developer codes', () => {
  assert.equal(isSecretDevCode('admin777'), true);
  assert.equal(isSecretDevCode('ADMIN777'), true);
  assert.equal(isSecretDevCode('  admin777  '), true);
  assert.equal(isSecretDevCode('devlibya'), true);
  assert.equal(isSecretDevCode('777'), true);

  assert.equal(isSecretDevCode('wrongcode'), false);
  assert.equal(isSecretDevCode(''), false);
  assert.equal(isSecretDevCode('admin'), false);
});

test('calculateCommission calculates correct commission and net payout', () => {
  const inactiveSettings = { ...DEFAULT_ADMIN_SETTINGS, commissionActive: false };
  const res1 = calculateCommission(1000, inactiveSettings);
  assert.equal(res1.isCommissionActive, false);
  assert.equal(res1.commissionAmount, 0);
  assert.equal(res1.netToDriver, 1000);

  const activeSettings = {
    ...DEFAULT_ADMIN_SETTINGS,
    commissionActive: true,
    commissionRate: 5,
  };
  const res2 = calculateCommission(1000, activeSettings);
  assert.equal(res2.isCommissionActive, true);
  assert.equal(res2.commissionAmount, 50);
  assert.equal(res2.netToDriver, 950);
});

test('isPhoneBanned checks blacklist accurately', () => {
  const sampleBans = INITIAL_BANNED_ENTITIES;
  assert.equal(isPhoneBanned('0910009999', sampleBans), true);
  assert.equal(isPhoneBanned('091 000 9999', sampleBans), true);
  assert.equal(isPhoneBanned('0912345678', sampleBans), false);
});
