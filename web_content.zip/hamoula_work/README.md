# حمولة ليبيا | نقل البضائع والشحن 🇱🇾

منصة وتطبيق متكامل لربط أصحاب البضائع والتجار بسائقي الشاحنات والناقلين في كافة المدن الليبية، مع حاسبة للمسافات والأجور، ونظام عروض أسعار، ولوحة تحكم متطورة للمطور.

---

## 🚀 التشغيل السريع (Local Development)

### 1. تثبيت الحزم:
```bash
npm install
```

### 2. بدء سيرفر التطوير:
```bash
npm run dev
```
افتح المتصفح على: `http://localhost:3000`

### 3. بناء نسخة الإنتاج:
```bash
npm run build
```

---

## 📱 بناء تطبيق أندرويد (APK) باستخدام Capacitor:

```bash
# 1. بناء المشروع
npm run build

# 2. تثبيت كاباسيتور
npm install @capacitor/core @capacitor/cli @capacitor/android

# 3. تهيئة المشروع
npx cap init "حمولة ليبيا" com.hamoula.libya --web-dir dist

# 4. إضافة ومزامنة الأندرويد
npx cap add android
npx cap sync

# 5. فتح في Android Studio واستخراج APK
npx cap open android
```

---

## 🗂️ هيكل المجلدات:

- `src/App.tsx`: التطبيق الرئيسي والملاحة بين التبويبات.
- `src/components/`:
  - `Header.tsx`: الشريط العلوي، البحث، تبديل الأدوار، والدخول السري للمطور.
  - `ShipmentCard.tsx`: كرت تفاصيل الحمولة وأزرار الاتصال والواتساب.
  - `PostShipmentForm.tsx`: نموذج نشر حمولة جديدة مع التسعير الآلي.
  - `CalculatorModal.tsx`: حاسبة مسافات وأجور الشحن بين المدن الليبية.
  - `AdminDevPanel.tsx`: لوحة تحكم المطور (العمولة، الحظر، البلاغات، البث).
  - `SafetyGuide.tsx`: إرشادات الأمان ونموذج بوليصة الشحن وسند الاستلام.
  - `InstallAppModal.tsx`: نافذة تثبيت التطبيق وتحميل الكود المصدري.
- `src/utils/freight.ts`: جدول المدن الليبية، المسافات بالكيلومتر، وحساب تسعيرة الشحن.
- `src/utils/admin.ts`: خوارزميات العمولة والتحقق من القائمة السوداء والأكواد السرية (`admin777`).
- `public/`: أيقونات التطبيق وملف `manifest.json` لتقنية PWA.

---

## ☁️ ربط قاعدة البيانات (Supabase، بدون Firebase)

تمت إضافة أساس الربط مع Supabase:
- `src/lib/supabase.ts`: عميل Supabase مع حفظ جلسة الدخول وتجديدها.
- `supabase/migrations/202611040001_initial_schema.sql`: جداول الحسابات والحمولات والعروض والبلاغات والحظر والإعدادات، مع سياسات Row Level Security.

### الإعداد
1. أنشئ مشروعًا في [Supabase](https://supabase.com/).
2. افتح **SQL Editor** وشغّل محتوى ملف migration أعلاه.
3. انسخ `.env.example` إلى `.env.local`، ثم ضع رابط المشروع ومفتاح **publishable/anon** الخاص به في `VITE_SUPABASE_URL` و`VITE_SUPABASE_ANON_KEY`.
4. ثبّت الحزم وشغّل التطبيق:
   ```bash
   npm install
   npm run dev
   ```

**تنبيه أمني:** لا تضع `service_role` أو أي مفتاح سري في متغير يبدأ بـ `VITE_` أو في كود المتصفح. صلاحيات المدير يجب أن تُمنح من Supabase Auth `app_metadata` عبر إجراء موثوق من جهة الخادم، وليس من واجهة التطبيق.

> هذه المرحلة تضيف قاعدة البيانات وعميل الاتصال والسياسات الأمنية. واجهة التطبيق الحالية ما زالت تستخدم `localStorage` لبعض الوظائف؛ يلزم ربط إجراءات الواجهة بالجداول وإضافة تسجيل الدخول قبل اعتبار التطبيق متعدد المستخدمين وجاهزًا للإطلاق.
