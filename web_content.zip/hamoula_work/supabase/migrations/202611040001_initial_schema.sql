-- Hamoula Libya initial schema for Supabase (Postgres + Auth + RLS)
-- Run this in the Supabase SQL Editor after creating a project.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  phone text not null default '',
  user_role text not null default 'owner' check (user_role in ('owner', 'driver')),
  vehicle text,
  plate text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  cargo_type text not null,
  vehicle_type text not null,
  origin_city text not null,
  destination_city text not null,
  weight text not null,
  pickup_date date not null,
  price numeric(12,2) not null check (price >= 0),
  phone text not null,
  details text,
  requires_labor boolean not null default false,
  is_urgent boolean not null default false,
  status text not null default 'active' check (status in ('active', 'in_progress', 'completed', 'cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists shipments_status_created_idx on public.shipments(status, created_at desc);
create index if not exists shipments_owner_created_idx on public.shipments(owner_id, created_at desc);
create index if not exists shipments_route_idx on public.shipments(origin_city, destination_city);

create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  driver_id uuid not null references auth.users(id) on delete cascade,
  driver_name text not null,
  driver_phone text not null,
  vehicle text not null,
  price numeric(12,2) not null check (price >= 0),
  note text,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'rejected', 'withdrawn')),
  created_at timestamptz not null default now(),
  unique (shipment_id, driver_id)
);

create index if not exists offers_shipment_created_idx on public.offers(shipment_id, created_at desc);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid references public.shipments(id) on delete set null,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reported_user_id uuid references auth.users(id) on delete set null,
  reason text not null,
  status text not null default 'pending' check (status in ('pending', 'reviewed', 'resolved')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.user_bans (
  user_id uuid primary key references auth.users(id) on delete cascade,
  reason text not null,
  banned_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.platform_settings (
  id boolean primary key default true check (id),
  commission_active boolean not null default false,
  commission_rate numeric(5,2) not null default 2.5 check (commission_rate between 0 and 100),
  base_rate_multiplier numeric(6,3) not null default 1,
  min_haul_fee numeric(12,2) not null default 150,
  broadcast_notice text not null default '',
  broadcast_active boolean not null default false,
  updated_at timestamptz not null default now()
);

insert into public.platform_settings (id) values (true) on conflict (id) do nothing;

-- Admin privileges are assigned only through trusted server-side Supabase Auth app_metadata.
create or replace function public.is_user_banned(target_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.user_bans where user_id = target_user_id);
$$;

revoke all on function public.is_user_banned(uuid) from public;
grant execute on function public.is_user_banned(uuid) to authenticated;

create or replace function public.is_admin()
returns boolean
language sql
stable
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin', false);
$$;

alter table public.profiles enable row level security;
alter table public.shipments enable row level security;
alter table public.offers enable row level security;
alter table public.reports enable row level security;
alter table public.user_bans enable row level security;
alter table public.platform_settings enable row level security;

-- Profiles: public read for marketplace cards; users can only change their own profile.
drop policy if exists "profiles are readable" on public.profiles;
create policy "users read own profile and admins read all" on public.profiles for select using (auth.uid() = id or public.is_admin());
drop policy if exists "users insert own profile" on public.profiles;
create policy "users insert own profile" on public.profiles for insert with check (auth.uid() = id);
drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles for update using (auth.uid() = id or public.is_admin()) with check (auth.uid() = id or public.is_admin());

-- Shipments: public can browse active listings; owner/admin can manage own/their listings.
drop policy if exists "active shipments are public" on public.shipments;
create policy "active shipments are public" on public.shipments for select using (status = 'active' or owner_id = auth.uid() or public.is_admin());
drop policy if exists "authenticated users create shipments" on public.shipments;
create policy "authenticated users create shipments" on public.shipments for insert to authenticated with check (owner_id = auth.uid() and not public.is_user_banned(auth.uid()));
drop policy if exists "owners update shipments" on public.shipments;
create policy "owners update shipments" on public.shipments for update to authenticated using (owner_id = auth.uid() or public.is_admin()) with check (owner_id = auth.uid() or public.is_admin());
drop policy if exists "owners or admins delete shipments" on public.shipments;
create policy "owners or admins delete shipments" on public.shipments for delete to authenticated using (owner_id = auth.uid() or public.is_admin());

-- Offers: shipment owner and offer author can read; authenticated drivers can submit their own.
drop policy if exists "participants read offers" on public.offers;
create policy "participants read offers" on public.offers for select to authenticated using (driver_id = auth.uid() or exists (select 1 from public.shipments s where s.id = shipment_id and s.owner_id = auth.uid()) or public.is_admin());
drop policy if exists "drivers create own offers" on public.offers;
create policy "drivers create own offers" on public.offers for insert to authenticated with check (driver_id = auth.uid() and not public.is_user_banned(auth.uid()) and exists (select 1 from public.shipments s where s.id = shipment_id and s.status = 'active' and s.owner_id <> auth.uid()));
drop policy if exists "offer participants update offers" on public.offers;
create policy "offer participants update offers" on public.offers for update to authenticated using (driver_id = auth.uid() or exists (select 1 from public.shipments s where s.id = shipment_id and s.owner_id = auth.uid()) or public.is_admin()) with check (driver_id = auth.uid() or exists (select 1 from public.shipments s where s.id = shipment_id and s.owner_id = auth.uid()) or public.is_admin());

-- Reports: users submit and see their own; admins can review all.
drop policy if exists "reporters and admins read reports" on public.reports;
create policy "reporters and admins read reports" on public.reports for select to authenticated using (reporter_id = auth.uid() or public.is_admin());
drop policy if exists "users create reports" on public.reports;
create policy "users create reports" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
drop policy if exists "admins update reports" on public.reports;
create policy "admins update reports" on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Ban list and settings are admin-only.
drop policy if exists "admins manage bans" on public.user_bans;
create policy "admins manage bans" on public.user_bans for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "settings readable" on public.platform_settings;
create policy "settings readable" on public.platform_settings for select using (true);
drop policy if exists "admins update settings" on public.platform_settings;
create policy "admins update settings" on public.platform_settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Automatically create a profile after signup.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, phone)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', ''), coalesce(new.raw_user_meta_data ->> 'phone', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
